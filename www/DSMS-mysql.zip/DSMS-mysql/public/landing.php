<?php
header('Location: index.php?action=landing');
exit;
