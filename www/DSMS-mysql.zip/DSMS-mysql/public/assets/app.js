document.addEventListener('DOMContentLoaded', () => {
    const alertClose = document.querySelector('[data-alert-close]');
    if (alertClose) {
        alertClose.addEventListener('click', () => {
            alertClose.parentElement.style.display = 'none';
        });
    }

    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.dataset.originalText = submitBtn.dataset.originalText || submitBtn.textContent;
                submitBtn.textContent = 'Processing...';
                // Re-enable after 8 seconds in case the page doesn't navigate
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.textContent = submitBtn.dataset.originalText || 'Submit';
                }, 8000);
            }
        });
    });

    document.querySelectorAll('[data-confirm]').forEach(element => {
        element.addEventListener('click', (e) => {
            if (!confirm(element.dataset.confirm)) {
                e.preventDefault();
            }
        });
    });
});

// ==================== PHARMACY INVENTORY: MEDICINE PICKER ====================
// Unit price is ALWAYS read-only and comes from inventory (data-price on the
// option). Doctors never edit price. Quantity drives line total client-side
// for the summary display; the server recomputes and stores the snapshot.

function dsmsMedicineAlternatives(categoryId, excludeId) {
    if (!window.DSMS_MEDICINES) {
        return [];
    }
    return window.DSMS_MEDICINES.filter(function (m) {
        return m.category_id === categoryId && m.id !== excludeId && m.status === 'Available' && m.quantity > 0;
    });
}

function dsmsFormatMoney(n) {
    var num = Number(n) || 0;
    return num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function dsmsUpdateLineTotal(row) {
    if (!row) return;
    var priceInput = row.querySelector('[data-price-field]');
    var qtyInput = row.querySelector('[data-qty-field]') || row.querySelector('input[name="quantity"]');
    var totalField = row.querySelector('[data-line-total-field]');
    if (!totalField) return;
    var price = parseFloat(priceInput && priceInput.value ? priceInput.value.replace(/,/g, '') : '0') || 0;
    var qty = parseInt(qtyInput && qtyInput.value ? qtyInput.value : '0', 10) || 0;
    if (price > 0 && qty > 0) {
        totalField.value = 'TZS ' + dsmsFormatMoney(price * qty);
    } else {
        totalField.value = '—';
    }
}

function dsmsUpdateMedicineRow(select) {
    var row = select.closest('.prescription-row') || select.closest('form');
    if (!row) {
        return;
    }
    var infoBox = row.querySelector('.medicine-stock-info');
    var medicationInput = row.querySelector('[data-medication-field]');
    var dosageInput = row.querySelector('[data-dosage-field]');
    var priceInput = row.querySelector('[data-price-field]');
    var option = select.options[select.selectedIndex];

    if (!option || !option.value) {
        if (infoBox) {
            infoBox.innerHTML = '';
        }
        if (priceInput) {
            priceInput.value = '';
        }
        dsmsUpdateLineTotal(row);
        return;
    }

    var id = parseInt(option.value, 10);
    var categoryId = parseInt(option.dataset.categoryId, 10);
    var qty = parseInt(option.dataset.qty, 10);
    var status = option.dataset.status;
    var unitPrice = parseFloat(option.dataset.price) || 0;

    if (medicationInput) {
        medicationInput.value = option.dataset.name || '';
    }
    if (dosageInput && !dosageInput.value) {
        dosageInput.value = option.dataset.form || '';
    }
    if (priceInput) {
        // Always overwrite — price is inventory-locked, never doctor-editable
        priceInput.value = unitPrice > 0 ? unitPrice.toFixed(2) : '0.00';
        priceInput.readOnly = true;
    }

    dsmsUpdateLineTotal(row);

    if (!infoBox) {
        return;
    }

    var isOos = option.dataset.oos === '1' || status === 'Out of Stock' || !(status === 'Available' && qty > 0);
    var stockClass = option.dataset.stockClass || (isOos ? 'oos' : 'ok');
    var overrideBox = row.querySelector('.rx-oos-override');
    var overrideChk = row.querySelector('.rx-stock-override');

    if (!isOos) {
        var lowNote = (stockClass === 'low')
            ? '<span class="status-badge status-waiting">Low stock: ' + qty + ' unit(s)</span>'
            : '<span class="status-badge status-paid">In stock: ' + qty + ' unit(s)</span>';
        infoBox.innerHTML = lowNote
            + ' <span class="dsms-hint">Unit price TZS ' + dsmsFormatMoney(unitPrice) + ' (inventory)</span>';
        if (overrideBox) {
            overrideBox.hidden = true;
        }
        if (overrideChk) {
            overrideChk.checked = false;
            overrideChk.required = false;
        }
        select.classList.remove('rx-select-oos');
        return;
    }

    // Out of stock — show block state + force pharmacy override confirmation
    select.classList.add('rx-select-oos');
    var alternatives = dsmsMedicineAlternatives(categoryId, id);
    var html = '<div class="rx-stock-panel rx-stock-oos">'
        + '<span class="status-badge status-warning">Out of stock</span>'
        + ' <span class="dsms-hint">Cannot prescribe unless you request pharmacy confirmation below.</span>';
    if (alternatives.length > 0) {
        html += '<div class="dsms-hint" style="margin-top:8px;"><strong>In-stock alternatives</strong> (same category): '
            + alternatives.slice(0, 4).map(function (alt) {
                return '<button type="button" class="btn btn-secondary btn-small dsms-alt-btn" data-alt-id="' + alt.id +
                    '" style="margin:2px;">' + alt.name + ' (' + alt.quantity + ')</button>';
            }).join(' ')
            + '</div>';
    } else {
        html += '<div class="dsms-hint" style="margin-top:8px;">No in-stock alternative in this treatment category.</div>';
    }
    html += '</div>';
    infoBox.innerHTML = html;
    if (overrideBox) {
        overrideBox.hidden = false;
    }
    if (overrideChk) {
        overrideChk.required = true;
        overrideChk.checked = false;
    }
}

// Guard submit when OOS without override
document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || !form.querySelector) return;
    var selects = form.querySelectorAll('select.medicine-select');
    if (!selects.length) return;
    for (var i = 0; i < selects.length; i++) {
        var sel = selects[i];
        var opt = sel.options[sel.selectedIndex];
        if (!opt || !opt.value) continue;
        var oos = opt.dataset.oos === '1' || opt.dataset.status === 'Out of Stock' || parseInt(opt.dataset.qty || '0', 10) <= 0;
        if (!oos) continue;
        var row = sel.closest('.prescription-row') || form;
        var chk = row.querySelector('.rx-stock-override') || form.querySelector('.rx-stock-override') || form.querySelector('[name="stock_override_confirm"]');
        if (!chk || !chk.checked) {
            e.preventDefault();
            alert('This medicine is out of stock. Tick “Prescribe anyway (request pharmacy confirmation)” or pick an in-stock alternative.');
            if (chk) chk.focus();
            // re-enable submit buttons disabled by global handler
            var btn = form.querySelector('button[type="submit"]');
            if (btn) {
                btn.disabled = false;
                if (btn.dataset.originalText) btn.textContent = btn.dataset.originalText;
            }
            return false;
        }
    }
}, true);

document.addEventListener('change', function (e) {
    if (e.target.matches('.medicine-select')) {
        dsmsUpdateMedicineRow(e.target);
    }
});

document.addEventListener('input', function (e) {
    if (e.target.matches('[data-qty-field]') || e.target.matches('input[name="quantity"]')) {
        var row = e.target.closest('.prescription-row') || e.target.closest('form');
        dsmsUpdateLineTotal(row);
    }
});

document.addEventListener('click', function (e) {
    if (e.target.matches('.dsms-alt-btn')) {
        var row = e.target.closest('.prescription-row') || e.target.closest('form');
        var select = row ? row.querySelector('.medicine-select') : null;
        if (select) {
            select.value = e.target.dataset.altId;
            dsmsUpdateMedicineRow(select);
        }
    }
});
