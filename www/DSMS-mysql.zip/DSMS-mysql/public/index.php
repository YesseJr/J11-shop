<?php

// Facility runs on East Africa Time (UTC+3)
date_default_timezone_set('Africa/Nairobi');

session_start();

require_once __DIR__ . '/../src/Database.php';
require_once __DIR__ . '/../src/Rbac.php';
require_once __DIR__ . '/../src/Models/Staff.php';
require_once __DIR__ . '/../src/Models/Patient.php';
require_once __DIR__ . '/../src/Models/QueueManager.php';
require_once __DIR__ . '/../src/Models/Vital.php';
require_once __DIR__ . '/../src/Models/Consultation.php';
require_once __DIR__ . '/../src/Models/Payment.php';
require_once __DIR__ . '/../src/Models/Prescription.php';
require_once __DIR__ . '/../src/Models/Dispensation.php';
require_once __DIR__ . '/../src/Models/PharmacyBill.php';
require_once __DIR__ . '/../src/Models/LabRequest.php';
require_once __DIR__ . '/../src/Models/LabTestCatalog.php';
require_once __DIR__ . '/../src/Models/LabResult.php';
require_once __DIR__ . '/../src/Models/MedicationHistory.php';
require_once __DIR__ . '/../src/Models/ProcedureCatalog.php';
require_once __DIR__ . '/../src/Models/MedicineCategory.php';
require_once __DIR__ . '/../src/Models/Medicine.php';
require_once __DIR__ . '/../src/Models/MedicinePurchaseRequest.php';
require_once __DIR__ . '/../src/Models/LabEquipment.php';
require_once __DIR__ . '/../src/Models/LabEquipmentRequest.php';
require_once __DIR__ . '/../src/Models/Budget.php';
require_once __DIR__ . '/../src/Models/Billing.php';
require_once __DIR__ . '/../src/Models/AuditLog.php';
require_once __DIR__ . '/../src/Models/PatientHistory.php';
require_once __DIR__ . '/../src/Models/Notification.php';
require_once __DIR__ . '/../src/Models/RecoveryLog.php';
require_once __DIR__ . '/../src/Models/Workflow.php';
require_once __DIR__ . '/../src/Models/Search.php';
require_once __DIR__ . '/../src/Models/Analytics.php';

// Initialize database
Database::getConnection();

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/**
 * Inline SVG icon (stroke). Use semantic keys: reception, doctor, lab, billing, etc.
 */
function dsms_icon(string $name, int $size = 20): string
{
    static $map = [
        'clipboard' => '<path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4"/>',
        'pill' => '<path d="M10.5 3.5 3.5 10.5a4.95 4.95 0 0 0 7 7L17.5 10.5a4.95 4.95 0 1 0-7-7z"/><path d="m8.5 8.5 7 7"/>',
        'bell' => '<path d="M18 8A6 6 0 1 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
        'compass' => '<circle cx="12" cy="12" r="10"/><path d="m16.24 7.76-2.12 6.36-6.36 2.12 2.12-6.36z"/>',
        'reception' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
        'stethoscope' => '<path d="M11 2v2"/><path d="M5 4h4"/><path d="M7 4v5a5 5 0 0 0 10 0V9"/><path d="M17 9v2a5 5 0 0 1-5 5"/><circle cx="12" cy="19" r="2"/>',
        'lab' => '<path d="M9 3h6v6l4 8a2 2 0 0 1-1.8 2.9H6.8A2 2 0 0 1 5 17l4-8V3z"/><path d="M8 14h8"/>',
        'billing' => '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/><path d="M6 15h2M12 15h4"/>',
        'shield' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        'book' => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
        'equipment' => '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
        'package' => '<path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/>',
        'cart' => '<circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/>',
        'inbox' => '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
        'receipt' => '<path d="M4 2v20l4-2 4 2 4-2 4 2V2l-4 2-4-2-4 2z"/><path d="M8 10h8M8 14h6"/>',
        'home' => '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
        'chart' => '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
        'alert' => '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
        'radio' => '<path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9"/><path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.4"/><circle cx="12" cy="12" r="2"/><path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.4"/><path d="M19.1 4.9C23 8.8 23 15.1 19.1 19"/>',
        'scroll' => '<path d="M8 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-1"/><path d="M12 3v18"/><path d="M8 8h2M14 8h2M8 12h2M14 12h2"/>',
        'clock' => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
        'trending' => '<path d="M22 7 13.5 15.5 8.5 10.5 2 17"/><path d="M16 7h6v6"/>',
        'file' => '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><path d="M14 2v6h6"/>',
        'search' => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
        'building' => '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18z"/><path d="M6 12h12"/><path d="M6 16h12"/><path d="M10 6h4"/><path d="M10 22v-4h4v4"/>',
        'check' => '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/>',
        'check-circle' => '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/>',
        'user' => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
        'hospital' => '<path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-6h6v6"/><path d="M10 9h4"/><path d="M12 7v4"/>',
        'camera' => '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
        'mail' => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 7L2 7"/>',
        'phone' => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>',
        'lock' => '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'eye' => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
        'calendar' => '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        'chair' => '<path d="M5 11h14"/><path d="M6 11v6"/><path d="M18 11v6"/><path d="M4 17h16"/><path d="M8 11V8a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v3"/><path d="M6 17v3"/><path d="M18 17v3"/>',
        'activity' => '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
        'cash' => '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 12h.01M18 12h.01"/>',
        'card' => '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
        'smartphone' => '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>',
        'bank' => '<path d="m3 10 9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/>',
        'print' => '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/>',
        'wifi' => '<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><path d="M12 20h.01"/>',
        'circle' => '<circle cx="12" cy="12" r="9"/>',
        'x-circle' => '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/>',
        'ban' => '<circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/>',
        'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'briefcase' => '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>',
        'heart-pulse' => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5H20"/>',
        'flask' => '<path d="M9 3h6v6l4 8a2 2 0 0 1-1.8 2.9H6.8A2 2 0 0 1 5 17l4-8V3z"/><path d="M8 14h8"/>',
        'dollar' => '<path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
        'warning' => '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
        'plus' => '<path d="M12 5v14"/><path d="M5 12h14"/>',
        'user-plus' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6"/><path d="M22 11h-6"/>',
        'list' => '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
        'settings' => '<circle cx="12" cy="12" r="3"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>',
        'dot' => '<circle cx="12" cy="12" r="6"/>',
    ];
    $paths = $map[$name] ?? $map['file'];
    $s = max(12, min(48, $size));
    return '<svg class="dsms-icon" width="' . $s . '" height="' . $s . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $paths . '</svg>';
}


/**
 * Builds <optgroup>/<option> markup for a medicine picker, grouped by
 * treatment category, with stock data attached as data-* attributes so
 * the client-side script (app.js) can show live stock and suggest
 * alternatives without a page reload. Expects rows shaped like
 * Medicine::allActive() (already ordered by category name, then name).
 */
function renderMedicineSelectOptions(array $medicines, bool $blockOutOfStock = true): string
{
    $html = '<option value="">-- Select medicine from inventory --</option>';
    $currentCategory = null;
    foreach ($medicines as $medicine) {
        if ($medicine['category_name'] !== $currentCategory) {
            if ($currentCategory !== null) {
                $html .= '</optgroup>';
            }
            $currentCategory = $medicine['category_name'];
            $html .= '<optgroup label="' . h($currentCategory) . '">';
        }
        $qty = (int)$medicine['quantity'];
        $isOos = $medicine['status'] !== 'Available' || $qty <= 0;
        $reorder = (int)($medicine['reorder_level'] ?? 0);
        $isLow = !$isOos && $reorder > 0 && $qty <= $reorder;
        if ($isOos) {
            $stockLabel = 'OUT OF STOCK';
            $stockClass = 'oos';
        } elseif ($isLow) {
            $stockLabel = 'Low: ' . $qty . ' left';
            $stockClass = 'low';
        } else {
            $stockLabel = 'In stock: ' . $qty;
            $stockClass = 'ok';
        }
        // OOS remain selectable so doctor can request pharmacy override — UI + server enforce confirmation
        $html .= '<option value="' . h((string)$medicine['id']) . '"'
            . ' data-name="' . h($medicine['name']) . '"'
            . ' data-form="' . h($medicine['dosage_form']) . '"'
            . ' data-price="' . h((string)$medicine['unit_price']) . '"'
            . ' data-qty="' . h((string)$qty) . '"'
            . ' data-status="' . h($isOos ? 'Out of Stock' : $medicine['status']) . '"'
            . ' data-stock-class="' . $stockClass . '"'
            . ' data-category-id="' . h((string)$medicine['category_id']) . '"'
            . ' data-oos="' . ($isOos ? '1' : '0') . '">'
            . h($medicine['name'] . ' (' . $medicine['dosage_form'] . ') — ' . $stockLabel)
            . '</option>';
    }
    if ($currentCategory !== null) {
        $html .= '</optgroup>';
    }
    return $html;
}

function getCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
    }

    return $_SESSION['csrf_token'];
}

function validateCsrfToken(string $token): bool
{
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function setFlash(string $message, string $type = 'success'): void
{
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
}

function getFlash(): array
{
    $message = $_SESSION['flash_message'] ?? '';
    $type = $_SESSION['flash_type'] ?? 'success';
    unset($_SESSION['flash_message'], $_SESSION['flash_type']);

    return ['message' => $message, 'type' => $type];
}

function isLoggedIn(): bool
{
    return isset($_SESSION['staff_id']) && isset($_SESSION['staff_role']);
}

function getCurrentStaff(): ?array
{
    if (!isLoggedIn()) {
        return null;
    }

    return Staff::find((int)$_SESSION['staff_id']);
}

function requireLogin(): void
{
    if (!isLoggedIn()) {
        header('Location: ?action=login');
        exit;
    }
}

function requireRole(string $role): void
{
    requireLogin();
    if (($_SESSION['staff_role'] ?? '') !== $role) {
        setFlash('Access denied. This page requires the ' . $role . ' role.', 'error');
        $home = ($_SESSION['staff_role'] ?? '') ? ($_SESSION['staff_role'] . '_dashboard') : 'login';
        header('Location: ?action=' . urlencode($home));
        exit;
    }
}

function requireAnyRole(array $roles): void
{
    requireLogin();
    $role = $_SESSION['staff_role'] ?? '';
    if (!in_array($role, $roles, true)) {
        setFlash('Access denied for role: ' . $role, 'error');
        header('Location: ?action=' . urlencode($role ? $role . '_dashboard' : 'login'));
        exit;
    }
}


// Handle staff self-registration (pending admin activation)
if (isset($_GET['action']) && $_GET['action'] === 'register' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $first = trim($_POST['first_name'] ?? '');
    $last = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $staffCode = trim($_POST['staff_id'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirm'] ?? '';
    $agree = isset($_POST['agree']);

    $allowedRoles = ['doctor', 'receptionist', 'billing', 'pharmacy', 'lab'];
    try {
        if (!$agree) {
            throw new RuntimeException('You must agree to the Terms and Privacy Policy.');
        }
        if ($first === '' || $last === '' || $email === '' || $password === '') {
            throw new RuntimeException('Please fill in all required fields.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Enter a valid email address.');
        }
        if ($password !== $confirm) {
            throw new RuntimeException('Passwords do not match.');
        }
        if (strlen($password) < 6) {
            throw new RuntimeException('Password must be at least 6 characters.');
        }
        if (!in_array($role, $allowedRoles, true)) {
            throw new RuntimeException('Select a valid role.');
        }
        $username = $staffCode !== '' ? $staffCode : strtolower(preg_replace('/[^a-z0-9]/i', '', $first . $last));
        if ($username === '') {
            $username = 'staff' . random_int(1000, 9999);
        }
        $fullName = trim($first . ' ' . $last);
        $spec = $department !== '' ? $department : null;
        $id = Staff::create($username, $email, $fullName, $role, $password, $spec);
        // Deactivate until admin approves
        Staff::updateStatus($id, false);
        try {
            Notification::notifyRole(
                'admin',
                'staff_registration',
                'New staff account pending activation',
                $fullName . ' registered as ' . $role . '. Activate their account before they can sign in.',
                'admin_dashboard',
                $id,
                'high'
            );
        } catch (\Throwable $ignore) {}
        setFlash('Account created for ' . $fullName . '. An administrator must activate it before you can sign in.');
        header('Location: ?action=login');
        exit;
    } catch (Throwable $e) {
        $msg = $e->getMessage();
        if (str_contains($msg, 'Duplicate') || str_contains($msg, '1062')) {
            $msg = 'Username or email already exists. Try a different Staff ID or email.';
        }
        setFlash($msg, 'error');
        header('Location: ?action=register');
        exit;
    }
}

// Handle login
if (isset($_GET['action']) && $_GET['action'] === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $result = Staff::authenticate($username, $password);
        $staff = $result['staff'];

        if ($staff) {
            session_regenerate_id(true); // prevent session fixation
            $_SESSION['staff_id'] = $staff['id'];
            $_SESSION['staff_role'] = $staff['role'];
            if (class_exists('Rbac') && !in_array($staff['role'], Rbac::ROLES, true)) {
                session_destroy();
                setFlash('This account has an invalid role configuration. Contact admin.', 'error');
                header('Location: ?action=login');
                exit;
            }
            $_SESSION['staff_name'] = $staff['full_name'];
            setFlash('Welcome, ' . h($staff['full_name']) . '!');
            header('Location: ?action=dashboard');
            exit;
        } elseif ($result['error'] === 'inactive') {
            setFlash('This account has been deactivated. Please contact an administrator.', 'error');
        } else {
            setFlash('Invalid username or password', 'error');
        }
    }
}

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header('Location: ?action=login');
    exit;
}

// Determine current action and role
$action = $_GET['action'] ?? 'dashboard';

if (!isLoggedIn() && $action !== 'login' && $action !== 'register' && $action !== 'landing') {
    $action = 'landing';
}

$flash = getFlash();
$currentStaff = getCurrentStaff();

// Billing routes (Billing Center, invoices, payments, receipts) — must be
// required after $action/$flash exist, since the route blocks in this file
// check $action directly.
require_once __DIR__ . '/../src/Routes/billing_routes.php';
require_once __DIR__ . '/../src/Routes/workflow_routes.php';
require_once __DIR__ . '/../src/Routes/production_routes.php';

// Login page

if ($action === 'register') {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Create Account — DSMS</title>
        <link rel="stylesheet" href="assets/styles.css">
        <link rel="stylesheet" href="assets/auth.css">
    </head>
    <body class="auth-body">
        <div class="auth-shell auth-shell-register">
            <div class="auth-form-pane auth-form-pane-wide">
                <div class="auth-topbar auth-topbar-center">
                    <div class="auth-logo">
                        <span class="auth-logo-mark">+</span>
                        <div>
                            <strong>DSMS</strong>
                            <small>Hospital Management System</small>
                        </div>
                    </div>
                </div>

                <div class="auth-card auth-card-wide">
                    <div class="auth-card-icon auth-card-icon-user"><?php echo dsms_icon('user', 28); ?></div>
                    <h2>Create Your Account</h2>
                    <p class="auth-subtitle">Fill in the details below to get started</p>

                    <?php if ($flash['message']) {
                        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
                    } ?>

                    <form method="post" action="?action=register" class="auth-form" enctype="multipart/form-data">
                        <div class="auth-reg-grid">
                            <div class="auth-photo-box">
                                <div class="auth-photo-placeholder"><?php echo dsms_icon('camera', 28); ?></div>
                                <span>Upload Photo</span>
                                <small>JPG, PNG (optional)</small>
                                <input type="file" name="avatar" accept="image/*" class="auth-photo-input">
                            </div>
                            <div class="auth-reg-fields">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>First Name</label>
                                        <div class="auth-input-wrap">
                                            <span class="auth-input-ico"><?php echo dsms_icon('user', 16); ?></span>
                                            <input type="text" name="first_name" required placeholder="Enter first name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Last Name</label>
                                        <div class="auth-input-wrap">
                                            <span class="auth-input-ico"><?php echo dsms_icon('user', 16); ?></span>
                                            <input type="text" name="last_name" required placeholder="Enter last name">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Email Address</label>
                                        <div class="auth-input-wrap">
                                            <span class="auth-input-ico"><?php echo dsms_icon('mail', 16); ?></span>
                                            <input type="email" name="email" required placeholder="Enter email address">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Phone Number</label>
                                        <div class="auth-input-wrap">
                                            <span class="auth-input-ico"><?php echo dsms_icon('phone', 16); ?></span>
                                            <input type="tel" name="phone" placeholder="Enter phone number">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Staff ID</label>
                                        <div class="auth-input-wrap">
                                            <span class="auth-input-ico">🆔</span>
                                            <input type="text" name="staff_id" placeholder="Enter staff ID (username)">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Department</label>
                                        <div class="auth-input-wrap">
                                            <span class="auth-input-ico"><?php echo dsms_icon('hospital', 16); ?></span>
                                            <select name="department">
                                                <option value="">Select department</option>
                                                <option>General Medicine</option>
                                                <option>Pediatrics</option>
                                                <option>Laboratory</option>
                                                <option>Pharmacy</option>
                                                <option>Billing</option>
                                                <option>Reception</option>
                                                <option>Surgery</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Role</label>
                                        <div class="auth-input-wrap">
                                            <span class="auth-input-ico"><?php echo dsms_icon('briefcase', 16); ?></span>
                                            <select name="role" required>
                                                <option value="">Select role</option>
                                                <option value="doctor">Doctor</option>
                                                <option value="receptionist">Receptionist</option>
                                                <option value="billing">Billing</option>
                                                <option value="pharmacy">Pharmacy</option>
                                                <option value="lab">Laboratory</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <div class="auth-input-wrap">
                                            <span class="auth-input-ico"><?php echo dsms_icon('lock', 16); ?></span>
                                            <input type="password" name="password" id="reg-password" required placeholder="Enter password">
                                            <button type="button" class="auth-eye" onclick="authTogglePwd('reg-password', this)"><?php echo dsms_icon('eye', 16); ?></button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Confirm Password</label>
                                    <div class="auth-input-wrap">
                                        <span class="auth-input-ico"><?php echo dsms_icon('lock', 16); ?></span>
                                        <input type="password" name="password_confirm" id="reg-password2" required placeholder="Confirm password">
                                        <button type="button" class="auth-eye" onclick="authTogglePwd('reg-password2', this)"><?php echo dsms_icon('eye', 16); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <label class="auth-check auth-check-block">
                            <input type="checkbox" name="agree" value="1" required>
                            I agree to the Terms and Conditions and Privacy Policy.
                        </label>

                        <button type="submit" class="auth-btn auth-btn-teal">Create Account <span>→</span></button>
                    </form>

                    <p class="auth-switch">Already have an account? <a href="?action=login">Login</a></p>
                </div>
                <p class="auth-footer">© <?php echo date('Y'); ?> DSMS Hospital Management System</p>
            </div>
        </div>
        <script>
        function authTogglePwd(id, btn) {
            var el = document.getElementById(id);
            if (!el) return;
            el.type = el.type === 'password' ? 'text' : 'password';
        }
        </script>
    </body>
    </html>
    <?php
    exit;
}

if ($action === 'login') {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login — DSMS Hospital Management</title>
        <link rel="stylesheet" href="assets/styles.css">
        <link rel="stylesheet" href="assets/auth.css">
    </head>
    <body class="auth-body">
        <div class="auth-shell auth-shell-login">
            <div class="auth-brand-pane">
                <div class="auth-topbar">
                    <div class="auth-logo">
                        <span class="auth-logo-mark">+</span>
                        <div>
                            <strong>DSMS</strong>
                            <small>Hospital Management System</small>
                        </div>
                    </div>
                </div>

                <div class="auth-brand-content">
                    <h1>Better <span>Care</span>,<br>Better <span>Life</span></h1>
                    <p class="auth-lead">A smart solution to manage your hospital efficiently.</p>

                    <div class="auth-photo-stage" aria-hidden="true">
                        <div class="auth-photo-frame">
                            <img class="auth-photo-img" src="assets/images/login-hero.png" alt="DSMS Hospital">
                            <div class="auth-photo-overlay"></div>
                            <div class="auth-photo-badge">DSMS Hospital</div>
                        </div>
                    </div>
                </div>

                <div class="auth-features">
                    <div class="auth-feature">
                        <span class="auth-feature-ico"><?php echo dsms_icon('shield', 20); ?></span>
                        <div><strong>Secure &amp; Reliable</strong><small>Enterprise-grade protection for clinical data.</small></div>
                    </div>
                    <div class="auth-feature">
                        <span class="auth-feature-ico"><?php echo dsms_icon('clock', 20); ?></span>
                        <div><strong>Efficient Workflow</strong><small>Streamlined operations across departments.</small></div>
                    </div>
                    <div class="auth-feature">
                        <span class="auth-feature-ico"><?php echo dsms_icon('users', 20); ?></span>
                        <div><strong>Better Patient Care</strong><small>Focus on patients with intelligent tools.</small></div>
                    </div>
                </div>
            </div>

            <div class="auth-form-pane">
                <div class="auth-card">
                    <div class="auth-card-icon">+</div>
                    <h2>Welcome Back!</h2>
                    <p class="auth-subtitle">Sign in to continue to your account</p>

                    <?php if ($flash['message']) {
                        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
                    } ?>

                    <form method="post" action="?action=login" class="auth-form">
                        <div class="form-group">
                            <label>Username or Email</label>
                            <div class="auth-input-wrap">
                                <span class="auth-input-ico"><?php echo dsms_icon('mail', 16); ?></span>
                                <input type="text" name="username" required autofocus placeholder="Enter username or email">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <div class="auth-input-wrap">
                                <span class="auth-input-ico"><?php echo dsms_icon('lock', 16); ?></span>
                                <input type="password" name="password" id="login-password" required placeholder="Password">
                                <button type="button" class="auth-eye" onclick="authTogglePwd('login-password', this)" aria-label="Show password"><?php echo dsms_icon('eye', 16); ?></button>
                            </div>
                        </div>
                        <div class="auth-row-between">
                            <label class="auth-check"><input type="checkbox" name="remember"> Remember Me</label>
                            <span class="auth-muted">Contact admin if locked out</span>
                        </div>
                        <button type="submit" class="auth-btn auth-btn-primary">Login <span>→</span></button>
                    </form>

                    <p class="auth-switch">Don't have an account? <a href="?action=register">Register</a></p>
                </div>
                <p class="auth-footer">© <?php echo date('Y'); ?> DSMS Hospital Management System</p>
            </div>
        </div>
        <script>
        function authTogglePwd(id, btn) {
            var el = document.getElementById(id);
            if (!el) return;
            el.type = el.type === 'password' ? 'text' : 'password';
        }
        </script>
    </body>
    </html>
    <?php
    exit;
}

if ($action === 'landing') {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>DSMS — Hospital Management System</title>
        <link rel="stylesheet" href="assets/styles.css">
        <link rel="stylesheet" href="assets/landing.css">
    </head>
    <body class="lp-body">
        <header class="lp-nav">
            <div class="lp-nav-inner">
                <a class="lp-brand" href="?action=landing">
                    <span class="lp-brand-mark">+</span>
                    <span>
                        <strong>DSMS</strong>
                        <small>Hospital Management System</small>
                    </span>
                </a>
                <nav class="lp-nav-links">
                    <a href="#features">Capabilities</a>
                    <a href="#departments">Departments</a>
                    <a href="#workflow">Patient journey</a>
                </nav>
                <div class="lp-nav-actions">
                    <a href="?action=login" class="lp-btn lp-btn-ghost">Staff Login</a>
                    <a href="?action=register" class="lp-btn lp-btn-solid">Request Access</a>
                </div>
            </div>
        </header>

        <section class="lp-hero">
            <div class="lp-hero-copy">
                <span class="lp-eyebrow">Clinical operations platform</span>
                <h1>One system for the<br><span>entire patient visit.</span></h1>
                <p>
                    DSMS connects reception, consultation, laboratory, billing, and pharmacy
                    in a single secure workflow — so every patient moves forward with clarity,
                    and every team knows what to do next.
                </p>
                <div class="lp-hero-cta">
                    <a href="?action=login" class="lp-btn lp-btn-primary">Staff Login</a>
                    <a href="?action=register" class="lp-btn lp-btn-outline">Create staff account</a>
                </div>
                <div class="lp-trust">
                    <div><strong>6</strong><span>Clinical roles</span></div>
                    <div><strong>1</strong><span>Unified invoice</span></div>
                    <div><strong>EAT</strong><span>Live facility time</span></div>
                </div>
            </div>

            <div class="lp-slider" id="lp-slider" aria-label="Facility highlights" aria-live="polite">
                <div class="lp-slides">
                    <article class="lp-slide is-active" data-slide="0" style="--slide-accent:#2563a8">
                        <img class="lp-slide-img" src="assets/images/slide-reception.jpeg" alt="Reception desk welcoming a patient">
                        <div class="lp-slide-shade"></div>
                        <div class="lp-slide-copy">
                            <div class="lp-slide-badge">Reception</div>
                            <h3>Warm welcome. Clear registration.</h3>
                            <p>Check in patients, record vitals, and place them on the doctor queue — without paper delays.</p>
                        </div>
                    </article>
                    <article class="lp-slide" data-slide="1" style="--slide-accent:#1e4b82">
                        <img class="lp-slide-img" src="assets/images/slide-consultation.jpeg" alt="Doctor consulting with a patient">
                        <div class="lp-slide-shade"></div>
                        <div class="lp-slide-copy">
                            <div class="lp-slide-badge">Consultation</div>
                            <h3>Quality care, every patient, every time.</h3>
                            <p>Doctors review history, request labs, prescribe from inventory, and finalize treatment in one workspace.</p>
                        </div>
                    </article>
                    <article class="lp-slide" data-slide="2" style="--slide-accent:#0f766e">
                        <img class="lp-slide-img" src="assets/images/slide-lab.jpeg" alt="Laboratory scientist using a microscope">
                        <div class="lp-slide-shade"></div>
                        <div class="lp-slide-copy">
                            <div class="lp-slide-badge">Laboratory</div>
                            <h3>Accurate tests. Better treatment.</h3>
                            <p>Investigations stay on the worklist until results are uploaded — then the ordering clinician is notified.</p>
                        </div>
                    </article>
                    <article class="lp-slide" data-slide="3" style="--slide-accent:#163a66">
                        <img class="lp-slide-img" src="assets/images/slide-billing.jpeg" alt="Billing counter accepting card payment">
                        <div class="lp-slide-shade"></div>
                        <div class="lp-slide-copy">
                            <div class="lp-slide-badge">Billing</div>
                            <h3>Transparent. Efficient. Reliable.</h3>
                            <p>One visit invoice for consultation, labs, and medicines — cash, card, mobile money, or insurance.</p>
                        </div>
                    </article>
                </div>
                <div class="lp-slider-controls">
                    <button type="button" class="lp-slider-btn" id="lp-prev" aria-label="Previous slide">‹</button>
                    <div class="lp-dots" id="lp-dots" role="tablist" aria-label="Slide indicators"></div>
                    <button type="button" class="lp-slider-btn" id="lp-next" aria-label="Next slide">›</button>
                </div>
            </div>
        </section>

        <section class="lp-section" id="features">
            <div class="lp-section-head">
                <h2>Built for real hospital days</h2>
                <p>The same rules your teams already follow — encoded in software.</p>
            </div>
            <div class="lp-feature-grid">
                <div class="lp-feature-card">
                    <div class="lp-feature-ico" style="--c:#2563a8"><?php echo dsms_icon('clipboard', 22); ?></div>
                    <h3>End-to-end visits</h3>
                    <p>Registration → consult → lab → prescribe → pay → dispense, with status at every stage.</p>
                </div>
                <div class="lp-feature-card">
                    <div class="lp-feature-ico" style="--c:#7c3aed"><?php echo dsms_icon('pill', 22); ?></div>
                    <h3>Inventory-locked pricing</h3>
                    <p>Doctors prescribe quantity; unit price comes from pharmacy stock. Dispense matches the order.</p>
                </div>
                <div class="lp-feature-card">
                    <div class="lp-feature-ico" style="--c:#0f766e"><?php echo dsms_icon('bell', 22); ?></div>
                    <h3>Live department alerts</h3>
                    <p>Queue, lab results, new bills, and paid invoices notify the right role automatically.</p>
                </div>
                <div class="lp-feature-card">
                    <div class="lp-feature-ico" style="--c:#c2410c"><?php echo dsms_icon('compass', 22); ?></div>
                    <h3>Admin recovery tools</h3>
                    <p>Find stalled patients, regenerate invoices, and keep the visit trail intact.</p>
                </div>
            </div>
        </section>

        <section class="lp-section lp-section-alt" id="departments">
            <div class="lp-section-head">
                <h2>Departments on one platform</h2>
                <p>Role-based dashboards — each team sees only what they need.</p>
            </div>
            <div class="lp-dept-row">
                <div class="lp-dept"><span class="lp-dept-ico"><?php echo dsms_icon('reception', 26); ?></span><strong>Reception</strong><small>Register &amp; queue</small></div>
                <div class="lp-dept"><span class="lp-dept-ico"><?php echo dsms_icon('stethoscope', 26); ?></span><strong>Doctors</strong><small>Consult &amp; prescribe</small></div>
                <div class="lp-dept"><span class="lp-dept-ico"><?php echo dsms_icon('lab', 26); ?></span><strong>Laboratory</strong><small>Investigate &amp; report</small></div>
                <div class="lp-dept"><span class="lp-dept-ico"><?php echo dsms_icon('billing', 26); ?></span><strong>Billing</strong><small>Invoice &amp; collect</small></div>
                <div class="lp-dept"><span class="lp-dept-ico"><?php echo dsms_icon('pill', 26); ?></span><strong>Pharmacy</strong><small>Dispense safely</small></div>
                <div class="lp-dept"><span class="lp-dept-ico"><?php echo dsms_icon('shield', 26); ?></span><strong>Admin</strong><small>Govern &amp; recover</small></div>
            </div>
        </section>

        <section class="lp-section" id="workflow">
            <div class="lp-section-head">
                <h2>A journey patients can follow</h2>
                <p>Clear stages. No silent drop-offs between desks.</p>
            </div>
            <div class="lp-flow">
                <div class="lp-flow-step"><span>1</span>Register</div>
                <div class="lp-flow-step"><span>2</span>Consult</div>
                <div class="lp-flow-step"><span>3</span>Lab</div>
                <div class="lp-flow-step"><span>4</span>Prescribe</div>
                <div class="lp-flow-step"><span>5</span>Pay</div>
                <div class="lp-flow-step"><span>6</span>Dispense</div>
            </div>
            <div class="lp-cta-banner">
                <div>
                    <h3>Ready to run your facility on DSMS?</h3>
                    <p>Sign in with an activated staff account, or register and wait for admin approval.</p>
                </div>
                <div class="lp-hero-cta">
                    <a href="?action=login" class="lp-btn lp-btn-primary">Staff Login</a>
                    <a href="?action=register" class="lp-btn lp-btn-outline">Request Access</a>
                </div>
            </div>
        </section>

        <footer class="lp-footer">
            <div class="lp-footer-inner">
                <div class="lp-brand">
                    <span class="lp-brand-mark">+</span>
                    <span><strong>DSMS</strong><small style="display:block;font-size:.7rem;color:#94a3b8;font-weight:500;">Hospital Management System</small></span>
                </div>
                <p>© <?php echo date('Y'); ?> DSMS · East Africa Time (EAT) · Secure clinical operations</p>
            </div>
        </footer>

        <script>
        (function () {
            var root = document.getElementById('lp-slider');
            var slides = Array.prototype.slice.call(document.querySelectorAll('.lp-slide'));
            var dotsWrap = document.getElementById('lp-dots');
            var i = 0, timer = null, locked = false;
            if (!slides.length || !root) return;

            slides.forEach(function (_, idx) {
                var b = document.createElement('button');
                b.type = 'button';
                b.className = 'lp-dot' + (idx === 0 ? ' is-active' : '');
                b.setAttribute('role', 'tab');
                b.setAttribute('aria-label', 'Show slide ' + (idx + 1));
                b.addEventListener('click', function () { go(idx); });
                dotsWrap.appendChild(b);
            });

            function paint() {
                slides.forEach(function (s, idx) {
                    var on = idx === i;
                    s.classList.toggle('is-active', on);
                    s.setAttribute('aria-hidden', on ? 'false' : 'true');
                });
                Array.prototype.forEach.call(dotsWrap.children, function (d, idx) {
                    d.classList.toggle('is-active', idx === i);
                });
            }

            function go(n) {
                if (locked) return;
                locked = true;
                i = (n + slides.length) % slides.length;
                paint();
                window.setTimeout(function () { locked = false; }, 700);
                restart();
            }

            function restart() {
                clearInterval(timer);
                timer = setInterval(function () { go(i + 1); }, 5600);
            }

            document.getElementById('lp-prev').addEventListener('click', function () { go(i - 1); });
            document.getElementById('lp-next').addEventListener('click', function () { go(i + 1); });

            root.addEventListener('mouseenter', function () { clearInterval(timer); });
            root.addEventListener('mouseleave', restart);
            root.addEventListener('focusin', function () { clearInterval(timer); });
            root.addEventListener('focusout', function (e) {
                if (!root.contains(e.relatedTarget)) restart();
            });

            // Touch swipe
            var tx = 0;
            root.addEventListener('touchstart', function (e) {
                tx = e.changedTouches[0].clientX;
            }, { passive: true });
            root.addEventListener('touchend', function (e) {
                var dx = e.changedTouches[0].clientX - tx;
                if (Math.abs(dx) < 48) return;
                go(dx < 0 ? i + 1 : i - 1);
            }, { passive: true });

            paint();
            restart();
        })();
        </script>
    </body>
    </html>
    <?php
    exit;
}

// All other pages require login + RBAC on the requested action
requireLogin();
Rbac::enforce($action);

// Handle role-specific actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!validateCsrfToken($csrfToken)) {
        setFlash('Invalid request. Please try again.', 'error');
        header('Location: ?action=' . urlencode($_SESSION['staff_role'] . '_dashboard'));
        exit;
    }

    // RECEPTIONIST actions
    if ($_SESSION['staff_role'] === 'receptionist' && $action === 'register_patient') {
        $patientId = Patient::create([
            'full_name' => trim($_POST['full_name'] ?? ''),
            'gender' => trim($_POST['gender'] ?? ''),
            'blood_type' => trim($_POST['blood_type'] ?? '') ?: null,
            'date_of_birth' => trim($_POST['date_of_birth'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
            'emergency_contact' => trim($_POST['emergency_contact'] ?? ''),
            'allergies' => trim($_POST['allergies'] ?? '') ?: null,
            'chronic_conditions' => trim($_POST['chronic_conditions'] ?? '') ?: null,
            'medical_notes' => trim($_POST['medical_notes'] ?? '') ?: null,
            'registered_by_staff_id' => (int)$_SESSION['staff_id'],
        ]);
        $patient = Patient::find($patientId);
        AuditLog::log((int)$_SESSION['staff_id'], 'patients', $patientId, 'register', "name={$patient['full_name']}");
        setFlash('Patient registered successfully. ID: ' . h($patient['patient_id']));
        header('Location: ?action=receptionist_dashboard');
        exit;
    }

    
    if ($_SESSION['staff_role'] === 'receptionist' && $action === 'clear_queue') {
        $mode = $_POST['mode'] ?? 'single';
        $reason = trim($_POST['reason'] ?? '') ?: null;
        $staffId = (int)$_SESSION['staff_id'];
        try {
            if ($mode === 'all') {
                $n = QueueManager::clearAllActive($staffId);
                AuditLog::log($staffId, 'queue_entries', 0, 'clear_all', "count={$n}");
                setFlash($n ? "Cleared {$n} patient(s) from the queue." : 'No clearable patients in the queue.');
            } elseif ($mode === 'selected') {
                $ids = $_POST['queue_ids'] ?? [];
                if (!is_array($ids)) {
                    $ids = [$ids];
                }
                $n = QueueManager::clearMany($ids, $staffId, $reason);
                AuditLog::log($staffId, 'queue_entries', 0, 'clear_selected', "count={$n}");
                setFlash($n ? "Cleared {$n} selected patient(s) from the queue." : 'No selected entries could be cleared.');
            } else {
                $queueId = (int)($_POST['queue_id'] ?? 0);
                QueueManager::clear($queueId, $staffId, $reason);
                AuditLog::log($staffId, 'queue_entries', $queueId, 'clear', $reason);
                setFlash('Patient removed from the queue.');
            }
        } catch (Throwable $e) {
            setFlash($e->getMessage(), 'error');
        }
        header('Location: ?action=receptionist_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'receptionist' && $action === 'add_to_queue') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        $assignedDoctorId = (int)($_POST['assigned_doctor_id'] ?? 0) ?: null;
        if ($patientId > 0) {
            try {
                QueueManager::addToQueue($patientId, (int)$_SESSION['staff_id'], $assignedDoctorId);
                Patient::updateStatus($patientId, 'Waiting for Consultation');
                AuditLog::log((int)$_SESSION['staff_id'], 'patients', $patientId, 'add_to_queue', $assignedDoctorId ? "assigned_doctor={$assignedDoctorId}" : null);
                try {
                    $pt = Patient::find($patientId);
                    $ptLabel = $pt ? (($pt['patient_id'] ?? '') . ' — ' . ($pt['full_name'] ?? 'Patient')) : ('Patient #' . $patientId);
                    $msg = $ptLabel . ' is waiting for consultation.';
                    if ($assignedDoctorId) {
                        Notification::create(
                            $assignedDoctorId,
                            'doctor',
                            'queue_assigned',
                            'New patient assigned to you',
                            $msg,
                            'doctor_dashboard',
                            $patientId,
                            'high'
                        );
                    } else {
                        Notification::notifyRole(
                            'doctor',
                            'queue_new',
                            'New patient in consultation queue',
                            $msg,
                            'doctor_dashboard',
                            $patientId,
                            'normal'
                        );
                    }
                } catch (\Throwable $ignore) {}
                setFlash('Patient added to consultation queue.');
            } catch (\Throwable $e) {
                setFlash($e->getMessage(), 'error');
            }
        }
        header('Location: ?action=receptionist_dashboard');
        exit;
    }

    // DOCTOR actions
    if ($_SESSION['staff_role'] === 'receptionist' && $action === 'record_vitals') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        if ($patientId > 0) {
            Vital::record($patientId, [
                'weight' => (float)($_POST['weight'] ?? 0),
                'height' => (float)($_POST['height'] ?? 0),
                'temperature' => (float)($_POST['temperature'] ?? 0),
                'blood_pressure' => trim($_POST['blood_pressure'] ?? ''),
                'pulse_rate' => (int)($_POST['pulse_rate'] ?? 0),
            ]);
            AuditLog::log((int)$_SESSION['staff_id'], 'patients', $patientId, 'record_vitals');
            setFlash('Vitals recorded successfully.');
        }
        header('Location: ?action=receptionist_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'doctor' && $action === 'request_additional_lab_test') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        $queueId = (int)($_POST['queue_id'] ?? 0);
        $catalogId = (int)($_POST['lab_test_catalog_id'] ?? 0);

        try {
            $consultation = $patientId > 0 ? Consultation::latestForPatient($patientId) : null;
            $catalogTest = $catalogId > 0 ? LabTestCatalog::find($catalogId) : null;

            if (!$consultation) {
                throw new \Exception('No consultation found for this patient.');
            }
            if (!$catalogTest || (int)$catalogTest['is_active'] !== 1) {
                throw new \Exception('Please select a valid lab test.');
            }

            $labRequestId = LabRequest::create((int)$consultation['id'], $catalogTest['test_name'], (float)$catalogTest['price']);
            AuditLog::log((int)$_SESSION['staff_id'], 'lab_requests', $labRequestId, 'request_additional', "test={$catalogTest['test_name']}");
            Patient::updateStatus($patientId, 'Lab Investigation Required');
            try {
                Notification::notifyRole(
                    'lab',
                    'lab_request',
                    'Additional lab test requested',
                    $catalogTest['test_name'] . ' — patient returned to lab queue.',
                    'lab_dashboard',
                    $labRequestId,
                    'high'
                );
            } catch (\Throwable $ignore) {}
            setFlash('Additional lab test requested — patient sent back to the lab queue.');
        } catch (\Throwable $e) {
            setFlash('Could not request lab test: ' . $e->getMessage(), 'error');
        }

        header('Location: ?action=doctor_review_lab&queue_id=' . urlencode((string)$queueId));
        exit;
    }

    if ($_SESSION['staff_role'] === 'doctor' && $action === 'finalize_treatment') {
        $consultationId = (int)($_POST['consultation_id'] ?? 0);
        $confirmed = isset($_POST['confirmed']) && $_POST['confirmed'] === '1';

        if ($consultationId <= 0) {
            setFlash('Invalid consultation.', 'error');
            header('Location: ?action=doctor_dashboard');
            exit;
        }

        // Step 1: show read-only cost summary before locking
        if (!$confirmed) {
            header('Location: ?action=finalize_preview&consultation_id=' . urlencode((string)$consultationId));
            exit;
        }

        // Step 2: transactional finalize (lock Rx + generate invoice + audit)
        try {
            $invoiceId = Billing::finalizeTreatment($consultationId, (int)$_SESSION['staff_id']);
            // Notify billing desk (workflow layer — does not alter billing engine)
            try {
                Notification::notifyRole(
                    'billing',
                    'new_bill',
                    'New bill ready',
                    'A doctor finalized treatment. Invoice #' . ($invoiceId ?: '—') . ' is in the Billing Queue.',
                    'billing_queue',
                    $invoiceId ?: null,
                    'high'
                );
            } catch (\Throwable $ignore) {}
            setFlash(
                'Treatment finalized. Prescription locked and invoice #'
                . ($invoiceId ?: '—')
                . ' created. Patient has been forwarded to Billing for payment.'
            );
        } catch (\Throwable $e) {
            setFlash('Could not finalize treatment: ' . $e->getMessage(), 'error');
        }
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'doctor' && $action === 'save_consultation') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        $outcome = trim($_POST['outcome'] ?? 'Healthy');
        if ($patientId > 0) {
            try {
                $consultationId = Consultation::create(
                    $patientId,
                    (int)$_SESSION['staff_id'],
                    trim($_POST['symptoms'] ?? ''),
                    trim($_POST['examination'] ?? ''),
                    trim($_POST['diagnosis'] ?? ''),
                    $outcome,
                    trim($_POST['note'] ?? '') ?: null
                );

                if ($consultationId <= 0) {
                    throw new \RuntimeException('Consultation could not be saved. Please try again.');
                }
                AuditLog::log((int)$_SESSION['staff_id'], 'consultations', $consultationId, 'create', "outcome={$outcome}");

                if ($outcome === 'Lab Investigation Required') {
                    $catalogId = (int)($_POST['lab_test_catalog_id'] ?? 0);
                    $catalogTest = $catalogId > 0 ? LabTestCatalog::find($catalogId) : null;

                    if ($catalogTest && (int)$catalogTest['is_active'] === 1) {
                        $labRequestId = LabRequest::create($consultationId, $catalogTest['test_name'], (float)$catalogTest['price']);
                        AuditLog::log((int)$_SESSION['staff_id'], 'lab_requests', $labRequestId, 'request', "test={$catalogTest['test_name']}");
                        try {
                            Notification::notifyRole(
                                'lab',
                                'lab_request',
                                'New lab investigation requested',
                                $catalogTest['test_name'] . ' is waiting for investigation.',
                                'lab_dashboard',
                                $labRequestId,
                                'high'
                            );
                        } catch (\Throwable $ignore) {}
                        setFlash('Consultation saved and lab request created.');
                    } else {
                        setFlash('Consultation saved. Please select a valid lab test to create a lab request.');
                    }
                } else {
                    setFlash('Consultation saved.');
                }
            } catch (\Throwable $e) {
                setFlash('Could not save consultation/lab request: ' . $e->getMessage(), 'error');
            }
        }
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    
    if ($_SESSION['staff_role'] === 'doctor' && $action === 'add_consultation_procedure') {
        $consultationId = (int)($_POST['consultation_id'] ?? 0);
        $catalogId = (int)($_POST['procedure_catalog_id'] ?? 0);
        $qty = max(1, (int)($_POST['quantity'] ?? 1));
        try {
            if ($consultationId <= 0 || $catalogId <= 0) {
                throw new RuntimeException('Select a procedure.');
            }
            ProcedureCatalog::addToConsultation($consultationId, $catalogId, $qty);
            setFlash('Procedure added to this consultation.');
        } catch (Throwable $e) {
            setFlash($e->getMessage(), 'error');
        }
        $redirect = !empty($_POST['return_to']) ? $_POST['return_to'] : ('?action=finalize_preview&consultation_id=' . urlencode((string)$consultationId));
        header('Location: ' . $redirect);
        exit;
    }

    
    if ($_SESSION['staff_role'] === 'doctor' && $action === 'transfer_patient') {
        $queueId = (int)($_POST['queue_id'] ?? 0);
        $toDoctorId = (int)($_POST['to_doctor_id'] ?? 0);
        try {
            QueueManager::transfer($queueId, (int)$_SESSION['staff_id'], $toDoctorId, false);
            $to = Staff::getById($toDoctorId);
            AuditLog::log((int)$_SESSION['staff_id'], 'queue_entries', $queueId, 'transfer', 'to_doctor=' . $toDoctorId);
            try {
                Notification::create(
                    $toDoctorId,
                    'doctor',
                    'patient_transfer',
                    'Patient transferred to you',
                    'A colleague transferred a patient case to your queue.',
                    'doctor_dashboard',
                    $queueId,
                    'high'
                );
            } catch (Throwable $ignore) {}
            setFlash('Patient transferred to ' . h($to['full_name'] ?? 'doctor') . '.');
        } catch (Throwable $e) {
            setFlash($e->getMessage(), 'error');
        }
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'doctor' && $action === 'claim_patient') {
        $queueId = (int)($_POST['queue_id'] ?? 0);
        try {
            QueueManager::claim($queueId, (int)$_SESSION['staff_id']);
            AuditLog::log((int)$_SESSION['staff_id'], 'queue_entries', $queueId, 'claim', null);
            setFlash('Patient claimed — only you can access this case until you transfer it.');
        } catch (Throwable $e) {
            setFlash($e->getMessage(), 'error');
        }
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'doctor' && $action === 'create_prescription') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        $queueId = (int)($_POST['queue_id'] ?? 0);
        if ($patientId > 0) {
            // Support both single-row form and multi-row arrays
            $medicineIds = $_POST['medicine_id'] ?? [];
            $medications = $_POST['medication'] ?? [];
            $dosages = $_POST['dosage'] ?? [];
            $frequencies = $_POST['frequency'] ?? [];
            $durations = $_POST['duration'] ?? [];
            $quantities = $_POST['quantity'] ?? [];
            $instructions = $_POST['instructions'] ?? [];

            foreach (['medicineIds' => &$medicineIds, 'medications' => &$medications, 'dosages' => &$dosages,
                      'frequencies' => &$frequencies, 'durations' => &$durations, 'quantities' => &$quantities,
                      'instructions' => &$instructions] as $k => &$arr) {
                if (!is_array($arr)) {
                    $arr = [$arr];
                }
            }
            unset($arr);

            $createdCount = 0;
            $errors = [];

            $activeConsultation = Consultation::latestForPatient($patientId);
            $consultationId = $activeConsultation ? (int)$activeConsultation['id'] : null;

            // Block new prescriptions on an already-finalized consultation
            if ($activeConsultation && (int)$activeConsultation['treatment_finalized'] === 1) {
                setFlash('This consultation is already finalized. No further prescriptions can be added.', 'error');
                header('Location: ?action=' . ($queueId > 0 ? 'doctor_consult&queue_id=' . urlencode((string)$queueId) : 'doctor_dashboard'));
                exit;
            }

            $pdo = Database::getConnection();
            $pdo->beginTransaction();
            try {
                foreach ($medications as $index => $medication) {
                    $medication = trim((string)$medication);
                    $dosage = trim((string)($dosages[$index] ?? ''));
                    $frequency = trim((string)($frequencies[$index] ?? ''));
                    $duration = trim((string)($durations[$index] ?? '')) ?: null;
                    $quantity = (int)($quantities[$index] ?? 0);
                    $instruction = trim((string)($instructions[$index] ?? '')) ?: null;
                    $medicineId = isset($medicineIds[$index]) && $medicineIds[$index] !== ''
                        ? (int)$medicineIds[$index] : null;

                    // Price is NEVER taken from the form — only from inventory
                    if ($medicineId === null || $medicineId <= 0) {
                        $errors[] = 'Please select a medicine from the inventory catalog.';
                        continue;
                    }
                    if ($quantity < 1) {
                        $errors[] = 'Quantity must be at least 1 for each medicine.';
                        continue;
                    }
                    if (!$dosage || !$frequency) {
                        $errors[] = 'Dosage and frequency are required.';
                        continue;
                    }

                    $medRow = Medicine::find($medicineId);
                    if (!$medRow || !(int)$medRow['is_active']) {
                        $errors[] = 'Selected medicine is not available in inventory.';
                        continue;
                    }
                    $stockQty = (int)$medRow['quantity'];
                    $isOos = ($medRow['status'] !== 'Available') || $stockQty <= 0;
                    $overrides = $_POST['stock_override'] ?? [];
                    if (!is_array($overrides)) {
                        $overrides = [$overrides];
                    }
                    // Also accept a single checkbox stock_override_confirm
                    $globalOverride = !empty($_POST['stock_override_confirm']);
                    $lineOverride = !empty($overrides[$index]) || $globalOverride;
                    if ($isOos && !$lineOverride) {
                        $errors[] = h($medRow['name']) . ' is out of stock. Request pharmacy confirmation (prescribe anyway) before ordering it.';
                        continue;
                    }
                    if ($isOos && $lineOverride) {
                        // Pharmacy must be notified so they can source / substitute
                        try {
                            Notification::notifyRole(
                                'pharmacy',
                                'stock_override_prescription',
                                'Out-of-stock prescription',
                                'Dr. ' . ($_SESSION['staff_name'] ?? 'Doctor') . ' prescribed ' . $medRow['name']
                                    . ' (qty ' . $quantity . ') while stock is 0. Please source, substitute, or advise.',
                                'pharmacy_dashboard',
                                $patientId,
                                'high'
                            );
                        } catch (Throwable $ignore) {}
                        $instruction = trim(($instruction ? $instruction . ' ' : '') . '[OUT-OF-STOCK OVERRIDE — pharmacy confirmation requested]');
                    }

                    Prescription::create(
                        $patientId,
                        (int)$_SESSION['staff_id'],
                        $medication, // name will be overwritten from inventory
                        $dosage,
                        $frequency,
                        $quantity,
                        $duration,
                        $instruction,
                        $consultationId,
                        $medicineId
                    );
                    $createdCount++;
                }

                if ($createdCount === 0) {
                    throw new \RuntimeException(
                        $errors ? implode(' ', $errors) : 'Please select a medicine, dosage, frequency, and quantity.'
                    );
                }

                $pdo->commit();
                Patient::updateStatus($patientId, 'Prescription Uploaded');
                setFlash(
                    $createdCount . ' prescription line(s) saved. Unit prices locked from inventory. '
                    . 'Finalize treatment when ready to send the bill to Billing.'
                );
            } catch (\Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                setFlash('Could not save prescription: ' . $e->getMessage(), 'error');
            }
        }

        if ($queueId > 0) {
            header('Location: ?action=doctor_consult&queue_id=' . urlencode((string)$queueId));
        } else {
            header('Location: ?action=doctor_dashboard');
        }
        exit;
    }

    // ADMIN actions
    if ($_SESSION['staff_role'] === 'admin' && $action === 'create_staff') {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $fullName = trim($_POST['full_name'] ?? '');
        $role = trim($_POST['role'] ?? '');
        $password = $_POST['password'] ?? '';
        $specialization = trim($_POST['specialization'] ?? '') ?: null;

        if ($username && $email && $fullName && $role && $password) {
            try {
                Staff::create($username, $email, $fullName, $role, $password, $specialization);
                setFlash('Staff account created successfully.');
            } catch (\Exception $e) {
                setFlash('Error creating staff: ' . $e->getMessage(), 'error');
            }
        }
        header('Location: ?action=admin_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'save_budget') {
        $departmentSelect = trim($_POST['department_select'] ?? '');
        $departmentNew = trim($_POST['department_new'] ?? '');
        $department = ($departmentSelect === '__other__') ? $departmentNew : $departmentSelect;
        $allocated = (float)($_POST['allocated'] ?? 0);
        $fiscalYear = trim($_POST['fiscal_year'] ?? '');

        if ($department && $allocated > 0) {
            try {
                Budget::create($department, $allocated, $fiscalYear ?: null);
                setFlash('Budget created successfully.');
            } catch (\Exception $e) {
                setFlash('Error creating budget: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please provide a department name and valid allocated amount.', 'error');
        }

        header('Location: ?action=budget_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'update_budget_allocation') {
        $budgetId = (int)($_POST['budget_id'] ?? 0);
        $allocated = (float)($_POST['allocated'] ?? 0);

        if ($budgetId > 0 && $allocated > 0) {
            try {
                Budget::updateAllocated($budgetId, $allocated);
                setFlash('Budget allocation updated successfully.');
            } catch (\Exception $e) {
                setFlash('Error updating budget: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please provide a valid allocated amount.', 'error');
        }

        header('Location: ?action=budget_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'delete_budget') {
        $budgetId = (int)($_POST['budget_id'] ?? 0);

        if ($budgetId > 0) {
            try {
                Budget::delete($budgetId);
                setFlash('Budget deleted successfully.');
            } catch (\Exception $e) {
                setFlash('Error deleting budget: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Invalid budget selected.', 'error');
        }

        header('Location: ?action=budget_dashboard');
        exit;
    }

    if (in_array($_SESSION['staff_role'], ['pharmacy', 'admin'], true) && $action === 'submit_medicine_purchase_request') {
        $medicineId = (int)($_POST['medicine_id'] ?? 0);
        $quantity = (int)($_POST['quantity'] ?? 0);
        $unitCost = (float)($_POST['unit_cost'] ?? 0);
        $notes = trim($_POST['notes'] ?? '');

        try {
            $reqId = MedicinePurchaseRequest::create($medicineId, (int)$_SESSION['staff_id'], $quantity, $unitCost, $notes ?: null);
            try {
                Notification::notifyRole(
                    'admin',
                    'purchase_request',
                    'Medicine purchase request',
                    'Pharmacy requested stock (qty ' . $quantity . '). Review under Purchase Approvals.',
                    'purchase_approvals',
                    is_int($reqId) ? $reqId : null,
                    'high'
                );
            } catch (\Throwable $ignore) {}
            setFlash('Purchase request submitted for admin approval.');
        } catch (\Exception $e) {
            setFlash('Error submitting request: ' . $e->getMessage(), 'error');
        }

        header('Location: ?action=medicine_purchase_requests');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'approve_medicine_purchase') {
        $requestId = (int)($_POST['request_id'] ?? 0);
        try {
            MedicinePurchaseRequest::approve($requestId, (int)$_SESSION['staff_id']);
            setFlash('Purchase approved — stock and budget updated.');
        } catch (\Exception $e) {
            setFlash('Error approving purchase: ' . $e->getMessage(), 'error');
        }

        header('Location: ?action=purchase_approvals');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'reject_medicine_purchase') {
        $requestId = (int)($_POST['request_id'] ?? 0);
        $reason = trim($_POST['decision_note'] ?? '');
        try {
            MedicinePurchaseRequest::reject($requestId, (int)$_SESSION['staff_id'], $reason ?: null);
            setFlash('Purchase request rejected.');
        } catch (\Exception $e) {
            setFlash('Error rejecting request: ' . $e->getMessage(), 'error');
        }

        header('Location: ?action=purchase_approvals');
        exit;
    }

    if ($_SESSION['staff_role'] === 'lab' && $action === 'submit_lab_equipment_request') {
        $requestType = $_POST['request_type'] ?? 'New';
        $equipmentId = !empty($_POST['equipment_id']) ? (int)$_POST['equipment_id'] : null;
        $nameSelect = trim($_POST['equipment_name_select'] ?? '');
        $nameOther = trim($_POST['equipment_name_other'] ?? '');
        $equipmentName = ($nameSelect === '__other__') ? $nameOther : $nameSelect;
        $category = trim($_POST['category'] ?? '');
        $unitCost = (float)($_POST['unit_cost'] ?? 0);
        $notes = trim($_POST['notes'] ?? '');

        try {
            $eqReqId = LabEquipmentRequest::create($requestType, $equipmentName, $category ?: null, $unitCost, (int)$_SESSION['staff_id'], $equipmentId, $notes ?: null);
            try {
                Notification::notifyRole(
                    'admin',
                    'equipment_request',
                    'Lab equipment request',
                    ($equipmentName ?: 'Equipment') . ' (' . $requestType . ') needs approval.',
                    'purchase_approvals',
                    is_int($eqReqId) ? $eqReqId : null,
                    'high'
                );
            } catch (\Throwable $ignore) {}
            setFlash('Equipment request submitted for admin approval.');
        } catch (\Exception $e) {
            setFlash('Error submitting request: ' . $e->getMessage(), 'error');
        }

        header('Location: ?action=lab_equipment');
        exit;
    }

    if ($_SESSION['staff_role'] === 'lab' && $action === 'register_existing_equipment') {
        $nameSelect = trim($_POST['name_select'] ?? '');
        $nameOther = trim($_POST['name_other'] ?? '');
        $name = ($nameSelect === '__other__') ? $nameOther : $nameSelect;
        $category = trim($_POST['category'] ?? '');
        $status = $_POST['status'] ?? 'Operational';
        $notes = trim($_POST['notes'] ?? '');

        try {
            if (!$name) {
                throw new \Exception('Equipment name is required.');
            }
            LabEquipment::registerExisting($name, $category ?: null, $status, $notes ?: null);
            setFlash('Equipment added to the register.');
        } catch (\Exception $e) {
            setFlash('Error registering equipment: ' . $e->getMessage(), 'error');
        }

        header('Location: ?action=lab_equipment');
        exit;
    }

    if ($_SESSION['staff_role'] === 'lab' && $action === 'flag_lab_equipment_status') {
        $equipmentId = (int)($_POST['equipment_id'] ?? 0);
        $status = $_POST['status'] ?? '';
        $notes = trim($_POST['notes'] ?? '');

        try {
            LabEquipment::flagStatus($equipmentId, $status, $notes ?: null);
            setFlash('Equipment status updated.');
        } catch (\Exception $e) {
            setFlash('Error updating equipment: ' . $e->getMessage(), 'error');
        }

        header('Location: ?action=lab_equipment');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'approve_lab_equipment') {
        $requestId = (int)($_POST['request_id'] ?? 0);
        try {
            LabEquipmentRequest::approve($requestId, (int)$_SESSION['staff_id']);
            setFlash('Equipment purchase approved — register and budget updated.');
        } catch (\Exception $e) {
            setFlash('Error approving purchase: ' . $e->getMessage(), 'error');
        }

        header('Location: ?action=purchase_approvals');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'reject_lab_equipment') {
        $requestId = (int)($_POST['request_id'] ?? 0);
        $reason = trim($_POST['decision_note'] ?? '');
        try {
            LabEquipmentRequest::reject($requestId, (int)$_SESSION['staff_id'], $reason ?: null);
            setFlash('Equipment request rejected.');
        } catch (\Exception $e) {
            setFlash('Error rejecting request: ' . $e->getMessage(), 'error');
        }

        header('Location: ?action=purchase_approvals');
        exit;
    }

    if ($_SESSION['staff_role'] === 'billing' && $action === 'record_payment') {
        setFlash('Consultation fees are now billed centrally through the Billing Center after treatment, not collected up front.');
        header('Location: ?action=billing_center');
        exit;
    }

    if ($_SESSION['staff_role'] === 'billing' && $action === 'record_medicine_payment') {
        setFlash('Medicine charges are now billed centrally through the Billing Center, not collected separately.');
        header('Location: ?action=billing_center');
        exit;
    }

    // ------------------------------------------------------------------
    // The following five actions belonged to the old fragmented-payment
    // system (separate pharmacy bills, separate per-test lab payments)
    // that centralized billing replaced. Routes are kept as harmless
    // redirects — rather than removed outright — in case anything old
    // still links to them, but none of them do real work anymore.
    // ------------------------------------------------------------------
    if ($_SESSION['staff_role'] === 'billing' && $action === 'record_pharmacy_bill_payment') {
        setFlash('Pharmacy charges are now billed centrally through the Billing Center, not as separate pharmacy bills.');
        header('Location: ?action=billing_center');
        exit;
    }

    if ($_SESSION['staff_role'] === 'pharmacy' && $action === 'create_pharmacy_bill') {
        setFlash('Pharmacy charges are now billed centrally through the Billing Center — no separate pharmacy bill is needed.');
        header('Location: ?action=pharmacy_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'pharmacy' && $action === 'save_pharmacy_bill') {
        setFlash('Pharmacy charges are now billed centrally through the Billing Center — no separate pharmacy bill is needed.');
        header('Location: ?action=pharmacy_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'billing' && $action === 'collect_pharmacy_bill_payment') {
        setFlash('Pharmacy charges are now billed centrally through the Billing Center, not as separate pharmacy bills.');
        header('Location: ?action=billing_center');
        exit;
    }

    if ($_SESSION['staff_role'] === 'lab' && $action === 'record_lab_payment') {
        setFlash('Lab charges are now billed centrally through the Billing Center — there is no separate per-test payment step.');
        header('Location: ?action=lab_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'lab' && $action === 'upload_lab_result') {
        $labRequestId = (int)($_POST['lab_request_id'] ?? 0);
        $result = trim($_POST['result'] ?? '');
        $comments = trim($_POST['comments'] ?? '');
        $resultValue = trim($_POST['result_value'] ?? '');
        if ($result === '' && $resultValue !== '') {
            $result = $resultValue;
        }

        if ($labRequestId > 0 && $result !== '') {
            try {
                LabResult::upload($labRequestId, $result, $comments ?: null, (int)$_SESSION['staff_id'], [
                    'result_value' => trim($_POST['result_value'] ?? '') ?: null,
                    'result_unit' => trim($_POST['result_unit'] ?? '') ?: null,
                    'reference_range' => trim($_POST['reference_range'] ?? '') ?: null,
                    'result_flag' => trim($_POST['result_flag'] ?? '') ?: null,
                ]);
                AuditLog::log((int)$_SESSION['staff_id'], 'lab_requests', $labRequestId, 'upload_result');
                try {
                    $pdoN = Database::getConnection();
                    $stmtN = $pdoN->prepare(
                        'SELECT c.doctor_staff_id, c.patient_id, l.test_type, p.patient_id AS patient_code, p.full_name
                         FROM lab_requests l
                         JOIN consultations c ON c.id = l.consultation_id
                         JOIN patients p ON p.id = c.patient_id
                         WHERE l.id = :id'
                    );
                    $stmtN->execute([':id' => $labRequestId]);
                    $meta = $stmtN->fetch() ?: null;
                    $title = 'Lab results ready for review';
                    $msg = ($meta
                        ? (($meta['patient_code'] ?? '') . ' — ' . ($meta['full_name'] ?? 'Patient') . ': ' . ($meta['test_type'] ?? 'Test'))
                        : ('Lab request #' . $labRequestId)) . ' results are ready.';
                    if ($meta && !empty($meta['doctor_staff_id'])) {
                        Notification::create(
                            (int)$meta['doctor_staff_id'],
                            'doctor',
                            'lab_result',
                            $title,
                            $msg,
                            'doctor_dashboard',
                            $labRequestId,
                            'high'
                        );
                    } else {
                        Notification::notifyRole('doctor', 'lab_result', $title, $msg, 'doctor_dashboard', $labRequestId, 'high');
                    }
                } catch (\Throwable $ignore) {}
                setFlash('Lab result uploaded successfully.');
            } catch (\Exception $e) {
                setFlash('Error uploading result: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please provide a valid lab request and result details.', 'error');
        }

        header('Location: ?action=lab_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'pharmacy' && $action === 'record_dispense') {
        $prescriptionId = (int)($_POST['prescription_id'] ?? 0);
        $note = trim($_POST['note'] ?? '');

        // Always dispense the doctor-prescribed quantity — never trust a free-form POST qty.
        $quantity = 0;
        if ($prescriptionId > 0) {
            $rxForQty = Prescription::find($prescriptionId);
            $quantity = max(1, (int)($rxForQty['quantity'] ?? 0));
        }

        if ($prescriptionId > 0 && $quantity > 0) {
            try {
                Dispensation::record($prescriptionId, (int)$_SESSION['staff_id'], $quantity, $note ?: null);
                
                // Get patient ID and check if all prescriptions have been dispensed
                $pdo = Database::getConnection();
                $stmt = $pdo->prepare('SELECT patient_id FROM prescriptions WHERE id = :id');
                $stmt->execute([':id' => $prescriptionId]);
                $rx = $stmt->fetch();
                
                if ($rx) {
                    $patientId = (int)$rx['patient_id'];
                    
                    // Check if all prescriptions for this patient have been dispensed
                    $stmt = $pdo->prepare('
                        SELECT COUNT(*) as pending
                        FROM prescriptions p
                        LEFT JOIN dispensations d ON p.id = d.prescription_id
                        WHERE p.patient_id = :patient_id AND d.id IS NULL
                    ');
                    $stmt->execute([':patient_id' => $patientId]);
                    $pending = $stmt->fetch();
                    
                    // If no pending prescriptions remain, update patient status to "Completed"
                    if (!$pending || (int)$pending['pending'] === 0) {
                        Patient::updateStatus($patientId, 'Completed');
                        try {
                            $pt = Patient::find($patientId);
                            $label = $pt ? (($pt['patient_id'] ?? '') . ' — ' . ($pt['full_name'] ?? '')) : ('#' . $patientId);
                            Notification::notifyRole(
                                'receptionist',
                                'visit_complete',
                                'Visit completed',
                                $label . ' — all medicines dispensed; visit marked completed.',
                                'receptionist_dashboard',
                                $patientId,
                                'normal'
                            );
                        } catch (\Throwable $ignore) {}
                    }
                }
                
                setFlash('Medication dispensed and recorded.');
            } catch (\Exception $e) {
                setFlash('Error dispensing medication: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please enter a valid prescription and quantity.', 'error');
        }

        header('Location: ?action=pharmacy_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'update_staff') {
        $staffId = (int)($_POST['staff_id'] ?? 0);
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $fullName = trim($_POST['full_name'] ?? '');
        $role = trim($_POST['role'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $specialization = trim($_POST['specialization'] ?? '') ?: null;

        if ($staffId > 0 && $username && $email && $fullName && $role) {
            try {
                Staff::update($staffId, $username, $email, $fullName, $role, $password !== '' ? $password : null, $specialization);
                setFlash('Staff record updated successfully.');
            } catch (\Exception $e) {
                setFlash('Error updating staff: ' . $e->getMessage(), 'error');
            }
        }
        header('Location: ?action=admin_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'toggle_staff_status') {
        $staffId = (int)($_POST['staff_id'] ?? 0);

        if ($staffId > 0 && $staffId !== (int)$_SESSION['staff_id']) {
            $target = Staff::getById($staffId);
            if ($target) {
                $newStatus = !$target['is_active'];
                Staff::updateStatus($staffId, $newStatus);
                setFlash($newStatus
                    ? 'Staff account activated.'
                    : 'Staff account deactivated.');
            }
        }
        header('Location: ?action=admin_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'delete_staff') {
        $staffId = (int)($_POST['staff_id'] ?? 0);

        if ($staffId > 0 && $staffId !== (int)$_SESSION['staff_id']) {
            try {
                Staff::delete($staffId);
                setFlash('Staff account removed successfully.');
            } catch (\Exception $e) {
                setFlash('Unable to remove staff account: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Cannot delete the active admin account.', 'error');
        }

        header('Location: ?action=admin_dashboard');
        exit;
    }
}

// Determine dashboard to show based on role
if ($action === 'dashboard') {
    $role = $_SESSION['staff_role'] ?? null;
    $action = $role ? $role . '_dashboard' : 'login';
}

// Include header for all pages
function renderHeader(string $title, string $role): void
{
    global $action;

    // Role -> sidebar nav items. "My Profile" is included for every role
    // since it's a self-service page regardless of department.
    $navByRole = [
        'receptionist' => [
            ['label' => 'Reception Desk', 'action' => 'receptionist_dashboard', 'icon' => 'reception'],
        ],
        'doctor' => [
            ['label' => 'Consultations', 'action' => 'doctor_dashboard', 'icon' => 'stethoscope'],
            ['label' => 'Patient History', 'action' => 'patient_history', 'icon' => 'book'],
        ],
        'lab' => [
            ['label' => 'Lab Workflow', 'action' => 'lab_dashboard', 'icon' => 'lab'],
            ['label' => 'Equipment', 'action' => 'lab_equipment', 'icon' => 'equipment'],
        ],
        'pharmacy' => [
            ['label' => 'Pharmacy', 'action' => 'pharmacy_dashboard', 'icon' => 'pill'],
            ['label' => 'Medicine Inventory', 'action' => 'medicine_inventory', 'icon' => 'package'],
            ['label' => 'Purchase Requests', 'action' => 'medicine_purchase_requests', 'icon' => 'cart'],
            ['label' => 'Medication History', 'action' => 'medication_history', 'icon' => 'book'],
            ['label' => 'Dispensary Margins', 'action' => 'dispensary_margins', 'icon' => 'trending'],
        ],
        'billing' => [
            ['label' => 'Billing Queue', 'action' => 'billing_queue', 'icon' => 'inbox'],
            ['label' => 'Billing Center', 'action' => 'billing_center', 'icon' => 'receipt'],
        ],
        'admin' => [
            ['label' => 'Admin Home', 'action' => 'admin_dashboard', 'icon' => 'home'],
            ['label' => 'MOIC Dashboard', 'action' => 'moic_dashboard', 'icon' => 'chart'],
            ['label' => 'Lost Patients', 'action' => 'lost_patients', 'icon' => 'alert'],
            ['label' => 'Workflow Monitor', 'action' => 'workflow_monitor', 'icon' => 'radio'],
            ['label' => 'Recovery History', 'action' => 'recovery_history', 'icon' => 'scroll'],
            ['label' => 'Escalations', 'action' => 'escalations', 'icon' => 'clock'],
            ['label' => 'Analytics', 'action' => 'analytics', 'icon' => 'trending'],
            ['label' => 'Reports', 'action' => 'reports', 'icon' => 'file'],
            ['label' => 'Audit Trail', 'action' => 'audit_browser', 'icon' => 'search'],
            ['label' => 'Budgets', 'action' => 'budget_dashboard', 'icon' => 'building'],
            ['label' => 'Purchase Approvals', 'action' => 'purchase_approvals', 'icon' => 'check'],
            ['label' => 'Lab Test Prices', 'action' => 'lab_test_catalog', 'icon' => 'lab'],
            ['label' => 'Medicine Inventory', 'action' => 'medicine_inventory', 'icon' => 'package'],
            ['label' => 'All Patients', 'action' => 'patient_history', 'icon' => 'book'],
        ],
    ];
    $navItems = $navByRole[$_SESSION['staff_role'] ?? ''] ?? [];
    $navItems[] = ['label' => 'My Profile', 'action' => 'my_profile', 'icon' => 'user'];
    if (class_exists('Rbac')) {
        $navItems = Rbac::filterNav($navItems, $_SESSION['staff_role'] ?? null);
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo h($title); ?> - DSMS</title>
        <link rel="stylesheet" href="assets/styles.css">
    </head>

    <body>
        <aside class="dsms-sidebar" id="dsms-sidebar">
            <div class="dsms-sidebar-brand">
                <span class="dsms-sidebar-logo"><?php echo dsms_icon('hospital', 22); ?></span>
                <span class="dsms-sidebar-brand-text">DSMS</span>
                <button type="button" class="dsms-sidebar-toggle" onclick="dsmsToggleSidebar()" title="Collapse sidebar">‹</button>
            </div>
            <nav class="dsms-sidebar-nav">
                <?php foreach ($navItems as $item): ?>
                    <a href="?action=<?php echo h($item['action']); ?>"
                        class="dsms-sidebar-link<?php echo $action === $item['action'] ? ' active' : ''; ?>"
                        title="<?php echo h($item['label']); ?>">
                        <span class="dsms-sidebar-link-icon"><?php echo dsms_icon($item['icon'], 20); ?></span>
                        <span class="dsms-sidebar-link-label"><?php echo h($item['label']); ?></span>
                    </a>
                <?php endforeach; ?>
            </nav>
            <div class="dsms-sidebar-footer">
                <a href="?action=logout" class="dsms-sidebar-link">
                    <span class="dsms-sidebar-link-icon"><?php echo dsms_icon('logout', 20); ?></span>
                    <span class="dsms-sidebar-link-label">Logout</span>
                </a>
            </div>
        </aside>

        <div class="dsms-main-wrap" id="dsms-main-wrap">
            <header class="header">
                <div class="container">
                    <div class="header-top">
                        <div class="header-title">
                            <button type="button" class="dsms-sidebar-open-btn" id="dsms-sidebar-open-btn" onclick="dsmsToggleSidebar()" title="Show sidebar"><?php echo dsms_icon('menu', 18); ?></button>
                            <div class="header-title-text">
                                <h1>DSMS</h1>
                                <p class="header-page-label"><?php echo h($title); ?></p>
                            </div>
                        </div>

                        <div class="dsms-header-center" title="East Africa Time (EAT)">
                            <div class="dsms-header-pill dsms-header-date-pill">
                                <span class="dsms-header-pill-ico" aria-hidden="true">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
                                </span>
                                <span class="dsms-header-date" id="dsms-header-date"><?php
                                    $day = (int)date('j');
                                    $suf = ($day % 10 === 1 && $day !== 11) ? 'st' : (($day % 10 === 2 && $day !== 12) ? 'nd' : (($day % 10 === 3 && $day !== 13) ? 'rd' : 'th'));
                                    echo h($day . $suf . ' ' . date('F Y'));
                                ?></span>
                            </div>
                            <span class="dsms-header-divider" aria-hidden="true"></span>
                            <div class="dsms-header-pill dsms-header-time-pill">
                                <span class="dsms-header-pill-ico" aria-hidden="true">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
                                </span>
                                <span class="dsms-header-time" id="dsms-header-time"><?php echo h(date('H:i:s')); ?></span>
                            </div>
                        </div>

                        <div class="header-user">
                            <div class="dsms-global-search">
                                <input type="search" id="dsms-search-input" placeholder="Search patients, bills, meds…" autocomplete="off">
                                <div id="dsms-search-results"></div>
                            </div>

                            <div class="dsms-notif-wrap">
                                <button type="button" id="dsms-notif-btn" class="dsms-header-icon-btn" title="Notifications" aria-label="Notifications">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 1 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                                    <span id="dsms-notif-badge" class="dsms-notif-badge" style="display:none;">0</span>
                                </button>
                                <div id="dsms-notif-panel" class="dsms-notif-panel" style="display:none;">
                                    <div class="dsms-notif-panel-head">
                                        <strong>Notifications</strong>
                                        <form method="post" action="?action=mark_notification_read" style="margin:0;">
                                            <input type="hidden" name="csrf_token" value="<?php echo h(getCsrfToken()); ?>">
                                            <button type="submit" class="btn btn-secondary btn-small">Mark all read</button>
                                        </form>
                                    </div>
                                    <div id="dsms-notif-list"><div class="dsms-hint">Loading…</div></div>
                                </div>
                            </div>

                            <a href="?action=my_profile" class="dsms-header-profile">
                                <?php
                                $currentStaffForHeader = Staff::getById((int)($_SESSION['staff_id'] ?? 0));
                                $avatarPath = $currentStaffForHeader['avatar'] ?? null;
                                $staffName = $_SESSION['staff_name'] ?? 'Staff';
                                $initials = '';
                                foreach (preg_split('/\s+/', trim($staffName)) as $part) {
                                    if ($part !== '') {
                                        $initials .= strtoupper(substr($part, 0, 1));
                                    }
                                    if (strlen($initials) >= 2) {
                                        break;
                                    }
                                }
                                if ($initials === '') {
                                    $initials = 'S';
                                }
                                if ($avatarPath) {
                                    echo '<img src="' . h($avatarPath) . '" alt="Profile" class="dsms-header-avatar-big">';
                                } else {
                                    echo '<span class="dsms-header-avatar-big dsms-header-avatar-fallback">' . h($initials) . '</span>';
                                }
                                ?>
                                <div class="dsms-header-profile-text">
                                    <div class="dsms-header-profile-name"><?php echo h($staffName); ?></div>
                                    <div class="dsms-header-profile-role"><?php echo h($role); ?></div>
                                </div>
                            </a>

                            <a href="?action=logout" class="dsms-header-icon-btn dsms-header-logout" title="Logout" aria-label="Logout">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            <script>
            (function(){
                var btn = document.getElementById('dsms-notif-btn');
                var panel = document.getElementById('dsms-notif-panel');
                var badge = document.getElementById('dsms-notif-badge');
                var list = document.getElementById('dsms-notif-list');
                if (!btn) return;
                var lastCount = -1;
                function escapeHtml(s){
                    return String(s == null ? '' : s)
                        .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
                        .replace(/"/g,'&quot;');
                }
                function notifHref(n){
                    var a = n.link_action || '';
                    var id = n.entity_id;
                    if (a === 'view_invoice' && id) return '?action=view_invoice&invoice_id=' + id;
                    if (a === 'billing_queue') return '?action=billing_queue';
                    if (a === 'pharmacy_dashboard') return '?action=pharmacy_dashboard';
                    if (a === 'lab_dashboard') return '?action=lab_dashboard';
                    if (a === 'doctor_dashboard') return '?action=doctor_dashboard';
                    if (a === 'receptionist_dashboard') return '?action=receptionist_dashboard';
                    if (a === 'medicine_inventory') return '?action=medicine_inventory';
                    if (a === 'purchase_approvals') return '?action=purchase_approvals';
                    if (a === 'admin_dashboard') return '?action=admin_dashboard';
                    if (a === 'lost_patients') return '?action=lost_patients';
                    if (a === 'notification_history') return '?action=notification_history';
                    if (a) return '?action=' + encodeURIComponent(a) + (id ? '&id=' + id : '');
                    return '?action=notification_history';
                }
                function shakeBell(){
                    btn.classList.remove('dsms-bell-shake');
                    void btn.offsetWidth;
                    btn.classList.add('dsms-bell-shake');
                    setTimeout(function(){ btn.classList.remove('dsms-bell-shake'); }, 900);
                }
                function loadNotifs(){
                    fetch('?action=notifications_json').then(function(r){return r.json();}).then(function(data){
                        var count = parseInt(data.count, 10) || 0;
                        if (count > 0) {
                            badge.style.display = 'inline-flex';
                            badge.textContent = count > 99 ? '99+' : String(count);
                            btn.classList.add('dsms-bell-has-unread');
                        } else {
                            badge.style.display = 'none';
                            btn.classList.remove('dsms-bell-has-unread');
                        }
                        if (lastCount >= 0 && count > lastCount) {
                            shakeBell();
                        }
                        lastCount = count;
                        if (!data.items || !data.items.length) {
                            list.innerHTML = '<div class="dsms-hint" style="padding:12px;">No notifications yet.</div>';
                            return;
                        }
                        list.innerHTML = data.items.map(function(n){
                            var unread = !parseInt(n.is_read, 10);
                            var href = notifHref(n);
                            var pri = (n.priority || 'normal');
                            return '<a class="dsms-notif-item' + (unread ? ' is-unread' : '') + '" href="' + href + '">'
                                + '<div class="dsms-notif-item-top">'
                                + '<span class="dsms-notif-item-title">' + escapeHtml(n.title || '') + '</span>'
                                + (pri === 'urgent' || pri === 'high' ? '<span class="dsms-notif-pri">' + escapeHtml(pri) + '</span>' : '')
                                + '</div>'
                                + '<div class="dsms-notif-item-msg">' + escapeHtml(n.message || '') + '</div>'
                                + '</a>';
                        }).join('');
                    }).catch(function(){});
                }
                btn.addEventListener('click', function(e){
                    e.preventDefault();
                    if (panel.style.display === 'block') {
                        panel.style.display = 'none';
                    } else {
                        panel.style.display = 'block';
                        loadNotifs();
                    }
                });
                document.addEventListener('click', function(e){
                    if (!panel.contains(e.target) && e.target!==btn && !btn.contains(e.target)) panel.style.display='none';
                });
                loadNotifs();
                setInterval(loadNotifs, 8000);
            
            (function(){
                var input = document.getElementById('dsms-search-input');
                var box = document.getElementById('dsms-search-results');
                if (!input || !box) return;
                var t = null;
                input.addEventListener('input', function(){
                    clearTimeout(t);
                    var q = input.value.trim();
                    if (q.length < 2) { box.style.display='none'; return; }
                    t = setTimeout(function(){
                        fetch('?action=global_search&q=' + encodeURIComponent(q))
                          .then(function(r){ return r.json(); })
                          .then(function(data){
                            var items = data.results || [];
                            if (!items.length) { box.innerHTML = '<div style="padding:12px;color:#64748b;">No results</div>'; box.style.display='block'; return; }
                            var html = '';
                            var cat = '';
                            items.forEach(function(it){
                                if (it.category !== cat) { cat = it.category; html += '<div style="padding:6px 12px;font-size:0.7rem;font-weight:700;color:#64748b;background:#f8fafc;">'+cat+'</div>'; }
                                html += '<a href="'+it.url+'" style="display:block;padding:8px 12px;text-decoration:none;color:#0f172a;border-bottom:1px solid #e2e8f0;"><div style="font-weight:600;font-size:0.88rem;">'+it.title+'</div><div style="font-size:0.75rem;color:#64748b;">'+ (it.subtitle||'') +'</div></a>';
                            });
                            box.innerHTML = html; box.style.display='block';
                          });
                    }, 250);
                });
                document.addEventListener('click', function(e){
                    if (!box.contains(e.target) && e.target !== input) box.style.display='none';
                });
            })();

            // Live clock — always East Africa Time (Africa/Nairobi)
            (function(){
                var dateEl = document.getElementById('dsms-header-date');
                var timeEl = document.getElementById('dsms-header-time');
                if (!dateEl || !timeEl) return;
                var monthsLong = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                function pad(n){ return n < 10 ? '0' + n : '' + n; }
                function ordinal(n){
                    var v = n % 100;
                    if (v >= 11 && v <= 13) return n + 'th';
                    return n + ({1:'st',2:'nd',3:'rd'}[n % 10] || 'th');
                }
                function tick(){
                    try {
                        var parts = new Intl.DateTimeFormat('en-GB', {
                            timeZone: 'Africa/Nairobi',
                            day: 'numeric', month: 'long', year: 'numeric',
                            hour: '2-digit', minute: '2-digit', second: '2-digit',
                            hour12: false
                        }).formatToParts(new Date());
                        var map = {};
                        parts.forEach(function(p){ if (p.type !== 'literal') map[p.type] = p.value; });
                        var dayNum = parseInt(map.day, 10);
                        dateEl.textContent = ordinal(dayNum) + ' ' + map.month + ' ' + map.year;
                        timeEl.textContent = map.hour + ':' + map.minute + ':' + map.second;
                    } catch (e) {
                        var now = new Date();
                        dateEl.textContent = ordinal(now.getDate()) + ' ' + monthsLong[now.getMonth()] + ' ' + now.getFullYear();
                        timeEl.textContent = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
                    }
                }
                tick();
                setInterval(tick, 1000);
            })();

            })();
            </script>

            <div class="container">
                <div class="dashboard">
    <?php
}

function renderFooter(): void
{
    ?>
                </div>
            </div>
        </div>
        <script>
            (function() {
                var sidebar = document.getElementById('dsms-sidebar');
                var mainWrap = document.getElementById('dsms-main-wrap');
                var collapsed = localStorage.getItem('dsms_sidebar_collapsed') === '1';
                if (collapsed) {
                    sidebar.classList.add('collapsed');
                    mainWrap.classList.add('sidebar-collapsed');
                }
                window.dsmsToggleSidebar = function() {
                    sidebar.classList.toggle('collapsed');
                    mainWrap.classList.toggle('sidebar-collapsed');
                    localStorage.setItem('dsms_sidebar_collapsed', sidebar.classList.contains('collapsed') ? '1' : '0');
                };
            })();
        </script>
        <script src="assets/app.js"></script>
    </body>

    </html>
    <?php
}

// RECEPTIONIST DASHBOARD
if ($action === 'receptionist_dashboard') {
    requireRole('receptionist');
    renderHeader('Reception - Patient Registration', 'receptionist');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $patients = Patient::all();
    $waitingQueue = QueueManager::getActive();
    $todayPatients = array_filter($patients, function ($p) {
        return isset($p['created_at']) && substr($p['created_at'], 0, 10) === date('Y-m-d');
    });
    $pendingBookings = array_filter($waitingQueue, fn($q) => $q['status'] !== 'Accepted');

    echo '<div class="page-title"><h2>Reception Desk</h2><p>Register new patients, manage the queue, and record patient vitals.</p></div>';

    echo '<div class="grid grid-3" style="margin-bottom: 8px;">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('calendar', 18) . ' <span>Pending Bookings</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('calendar', 28) . '</div><div class="card-stat-text"><h4>In Queue</h4><p>' . count($pendingBookings) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('users', 18) . ' <span>Today\'s Patients</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('users', 22) . '</div><div class="card-stat-text"><h4>Registered Today</h4><p>' . count($todayPatients) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('chair', 18) . ' <span>In Consultation Queue</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('chair', 28) . '</div><div class="card-stat-text"><h4>Right Now</h4><p>' . count($waitingQueue) . '</p></div></div></div>';
    echo '</div>';

    // -------- Tabbed action panel: Register / Vitals / Queue --------
    echo '<div class="dsms-recep-panel" style="margin-bottom: 24px;">';
    echo '<div class="dsms-tab-grid" id="recep-tab-grid">
            <button type="button" class="dsms-method-btn active" data-tab="register" onclick="dsmsRecepTab(this)">
                <span class="dsms-method-icon">' . dsms_icon('user', 20) . '</span><span>Register Patient</span>
            </button>
            <button type="button" class="dsms-method-btn" data-tab="vitals" onclick="dsmsRecepTab(this)">
                <span class="dsms-method-icon">' . dsms_icon('activity', 20) . '</span><span>Record Vitals</span>
            </button>
            <button type="button" class="dsms-method-btn" data-tab="queue" onclick="dsmsRecepTab(this)">
                <span class="dsms-method-icon">' . dsms_icon('clipboard', 20) . '</span><span>Add to Queue</span>
            </button>
          </div>';

    // Register New Patient
    echo '<div class="dsms-tab-panel" id="recep-panel-register">';
    echo '<form method="post" action="?action=register_patient">
        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
        <div class="form-row">
            <label>Full Name<br><input type="text" name="full_name" required autocomplete="name" placeholder="Patient full name"></label>
            <label>Gender<br><select name="gender"><option>Male</option><option>Female</option><option>Other</option></select></label>
        </div>
        <div class="form-row">
            <label>Date of Birth<br><input type="date" name="date_of_birth" required></label>
            <label>Blood Type<br><select name="blood_type"><option value="">Unknown</option><option>A+</option><option>A-</option><option>B+</option><option>B-</option><option>AB+</option><option>AB-</option><option>O+</option><option>O-</option></select></label>
        </div>
        <div class="form-row">
            <label>Phone<br><input type="tel" name="phone" autocomplete="tel" placeholder="e.g. 07XX XXX XXX"></label>
            <label>Email<br><input type="email" name="email" autocomplete="email" placeholder="optional@email.com"></label>
        </div>
        <div class="form-row full">
            <label>Address<br><textarea name="address" rows="2" placeholder="Home / clinic address"></textarea></label>
        </div>
        <div class="form-row full">
            <label>Emergency Contact<br><input type="text" name="emergency_contact" placeholder="Name and phone"></label>
        </div>
        <div class="form-row full">
            <label>Allergies<br><textarea name="allergies" rows="2" placeholder="e.g. Penicillin, Sulfa — or None known"></textarea></label>
        </div>
        <div class="form-row full">
            <label>Chronic conditions<br><textarea name="chronic_conditions" rows="2" placeholder="e.g. Hypertension, Diabetes mellitus"></textarea></label>
        </div>
        <div class="form-row full">
            <label>Medical notes<br><textarea name="medical_notes" rows="2" placeholder="Other relevant medical history"></textarea></label>
        </div>
        <button type="submit" class="dsms-submit-btn">Register Patient</button>
    </form>
    </div>';

    // Record Vitals
    echo '<div class="dsms-tab-panel" id="recep-panel-vitals" style="display:none;">';
    if (empty($patients)) {
        echo '<div class="no-data"><p>No registered patients available.</p></div>';
    } else {
        echo '<form method="post" action="?action=record_vitals">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <label>Select Patient<br><select name="patient_id">';
        foreach ($patients as $p) {
            echo '<option value="' . h($p['id']) . '">' . h($p['patient_id'] . ' - ' . $p['full_name']) . '</option>';
        }
        echo '</select></label>
            <div class="form-row">
                <label>Weight (kg)<br><input type="number" step="0.1" name="weight" required></label>
                <label>Height (cm)<br><input type="number" step="0.1" name="height" required></label>
            </div>
            <div class="form-row">
                <label>Temperature (°C)<br><input type="number" step="0.1" name="temperature" required></label>
                <label>Pulse Rate<br><input type="number" name="pulse_rate" required></label>
            </div>
            <div class="form-row full">
                <label>Blood Pressure<br><input type="text" name="blood_pressure" required placeholder="e.g. 120/80"></label>
            </div>
            <button type="submit" class="dsms-submit-btn">Save Vitals</button>
        </form>';
    }
    echo '</div>';

    // Add to Queue
    echo '<div class="dsms-tab-panel" id="recep-panel-queue" style="display:none;">';
    if (empty($patients)) {
        echo '<div class="no-data"><p>No registered patients yet.</p></div>';
    } else {
        $availableDoctors = Staff::getDoctors();
        echo '<form method="post" action="?action=add_to_queue">
        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
        <label>Select Patient<br><select name="patient_id">';
        foreach ($patients as $p) {
            echo '<option value="' . h($p['id']) . '">' . h($p['patient_id'] . ' - ' . $p['full_name']) . '</option>';
        }
        echo '</select></label>
        <label style="margin-top:14px; display:block;">Assign Doctor<br><select name="assigned_doctor_id">
            <option value="">-- Any available doctor --</option>';
        foreach ($availableDoctors as $doc) {
            echo '<option value="' . h($doc['id']) . '">Dr. ' . h($doc['full_name']) . ($doc['specialization'] ? ' — ' . h($doc['specialization']) : ' — General') . '</option>';
        }
        echo '</select></label>
        <button type="submit" class="dsms-submit-btn" style="margin-top: 14px;">Add to Queue</button>
    </form>';
    }
    echo '</div>';

    echo '</div>'; // .dsms-recep-panel

    echo '<script>
    function dsmsRecepTab(btn) {
        document.querySelectorAll("#recep-tab-grid .dsms-method-btn").forEach(function(b) { b.classList.remove("active"); });
        btn.classList.add("active");
        var tab = btn.getAttribute("data-tab");
        ["register", "vitals", "queue"].forEach(function(name) {
            document.getElementById("recep-panel-" + name).style.display = (name === tab) ? "block" : "none";
        });
    }
    </script>';

    // Waiting Queue Table — with single / multi clear
    $csrf = h(getCsrfToken());
    $clearable = array_filter($waitingQueue, fn($e) => in_array($e['status'], QueueManager::clearableStatuses(), true));
    echo '<div class="card" style="margin-top: 24px;">';
    echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px;">';
    echo '<h3 style="margin:0;">Current Consultation Queue (' . count($waitingQueue) . ')</h3>';
    if (!empty($clearable)) {
        echo '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
        echo '<button type="button" class="btn btn-secondary btn-small" onclick="dsmsQueueSelectAll(true)">Select all</button>';
        echo '<button type="button" class="btn btn-secondary btn-small" onclick="dsmsQueueSelectAll(false)">Clear selection</button>';
        echo '<form method="post" action="?action=clear_queue" style="display:inline;" onsubmit="return confirm(\'Clear ALL patients currently listed in the consultation queue? This includes in-consultation entries.\');">';
        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
        echo '<input type="hidden" name="mode" value="all">';
        echo '<button type="submit" class="btn btn-secondary btn-small" style="color:#b91c1c;">Clear entire queue</button>';
        echo '</form></div>';
    }
    echo '</div>';
    if (empty($waitingQueue)) {
        echo '<div class="no-data"><p>No patients in the queue.</p></div>';
    } else {
        echo '<form method="post" action="?action=clear_queue" id="queue-clear-form" onsubmit="return dsmsConfirmClearSelected();">';
        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
        echo '<input type="hidden" name="mode" value="selected">';
        echo '<div class="table-responsive"><table>
        <thead><tr>
            <th style="width:36px;"><input type="checkbox" id="queue-check-all" onclick="dsmsQueueSelectAll(this.checked)" title="Select all clearable"></th>
            <th>Patient ID</th><th>Name</th><th>Queued At</th><th>Status</th><th>Actions</th>
        </tr></thead>
        <tbody>';
        foreach ($waitingQueue as $entry) {
            $canClear = in_array($entry['status'], QueueManager::clearableStatuses(), true);
            $statusLabel = $entry['status'] === 'Accepted' ? 'Accepted' : ($entry['status'] === 'In Consultation' ? 'In Consultation' : 'Waiting');
            $statusClass = $entry['status'] === 'Accepted' ? 'status-accepted' : 'status-waiting';
            echo '<tr>';
            echo '<td>';
            if ($canClear) {
                echo '<input type="checkbox" class="queue-check" name="queue_ids[]" value="' . h((string)$entry['queue_id']) . '">';
            } else {
                echo '—';
            }
            echo '</td>';
            echo '<td><strong>' . h($entry['patient_code']) . '</strong></td>';
            echo '<td>' . h($entry['full_name']) . '</td>';
            echo '<td>' . h(date('M d, H:i', strtotime($entry['queued_at']))) . '</td>';
            echo '<td><span class="status-badge ' . $statusClass . '">' . h($statusLabel) . '</span></td>';
            echo '<td>';
            if ($canClear) {
                echo '<button type="submit" class="btn btn-secondary btn-small" style="color:#b91c1c;" formaction="?action=clear_queue" name="queue_id" value="' . h((string)$entry['queue_id']) . '" formmethod="post" onclick="this.form.mode.value=\'single\'; return confirm(\'Remove this patient from the queue?\');">Clear</button>';
            } else {
                echo '<span class="dsms-hint">In progress</span>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
        echo '<div style="margin-top:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">';
        echo '<button type="submit" class="btn btn-secondary" style="color:#b91c1c;">Clear selected</button>';
        echo '<span class="dsms-hint">You can clear waiting, accepted, or abandoned in-consultation visits (e.g. patient left). Confirm carefully.</span>';
        echo '</div></form>';
        echo '<script>
        function dsmsQueueSelectAll(on) {
            document.querySelectorAll(".queue-check").forEach(function(c){ c.checked = !!on; });
            var master = document.getElementById("queue-check-all");
            if (master) master.checked = !!on;
        }
        function dsmsConfirmClearSelected() {
            var form = document.getElementById("queue-clear-form");
            if (form && form.mode && form.mode.value === "single") return true;
            var n = document.querySelectorAll(".queue-check:checked").length;
            if (n < 1) { alert("Select at least one patient to clear."); return false; }
            return confirm("Clear " + n + " selected patient(s) from the queue?");
        }
        </script>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

// DOCTOR DASHBOARD

// Doctor / clinical medicine availability lookup (JSON)
if ($action === 'medicine_lookup') {
    requireAnyRole(['doctor', 'admin']);
    header('Content-Type: application/json; charset=utf-8');
    $q = trim($_GET['q'] ?? '');
    if (mb_strlen($q) < 1) {
        echo json_encode(['ok' => true, 'items' => []]);
        exit;
    }
    $rows = Medicine::searchCatalog($q, 24);
    $items = array_map(static function (array $m): array {
        $qty = (int)$m['quantity'];
        $reorder = (int)($m['reorder_level'] ?? 0);
        $oos = ($m['status'] !== 'Available') || $qty <= 0;
        $low = !$oos && $reorder > 0 && $qty <= $reorder;
        return [
            'id' => (int)$m['id'],
            'name' => $m['name'],
            'form' => $m['dosage_form'],
            'category' => $m['category_name'],
            'quantity' => $qty,
            'reorder_level' => $reorder,
            'unit_price' => (float)$m['unit_price'],
            'status' => $oos ? 'Out of Stock' : ($low ? 'Low Stock' : 'Available'),
            'stock_level' => $oos ? 'oos' : ($low ? 'low' : 'ok'),
            'expiry' => $m['expiry_date'] ?? null,
        ];
    }, $rows);
    echo json_encode(['ok' => true, 'items' => $items]);
    exit;
}

if ($action === 'doctor_dashboard') {
    requireRole('doctor');
    renderHeader('Doctor - Consultations', 'doctor');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $doctorId = (int)$_SESSION['staff_id'];
    $waitingQueue = QueueManager::getWaiting($doctorId);
    $unassignedPool = QueueManager::getUnassignedWaiting();

    // Lab results ready — only for patients assigned to this doctor
    $pdo = Database::getConnection();
    $stmt = $pdo->prepare('
        SELECT DISTINCT p.id, p.patient_id, p.full_name, q.id as queue_id, q.queued_at, q.status, q.assigned_doctor_id
        FROM patients p
        JOIN queue_entries q ON p.id = q.patient_id
        WHERE p.status = "Results Ready"
          AND q.assigned_doctor_id = :did
        ORDER BY q.queued_at DESC
    ');
    $stmt->execute([':did' => $doctorId]);
    $resultsReadyQueue = $stmt->fetchAll() ?: [];

    // Consultations this doctor has written up (diagnosis set) where every
    // requested lab has a result, but treatment hasn't been finalized yet —
    // i.e. ready to send to Billing.
    $stmt = $pdo->prepare(
        "SELECT c.id AS consultation_id, c.patient_id, c.created_at, pt.patient_id AS patient_code, pt.full_name
         FROM consultations c
         JOIN patients pt ON pt.id = c.patient_id
         LEFT JOIN lab_requests l ON l.consultation_id = c.id
         LEFT JOIN lab_results r ON r.lab_request_id = l.id
         WHERE c.doctor_staff_id = :did AND c.treatment_finalized = 0
           AND c.diagnosis IS NOT NULL AND c.diagnosis != ''
         GROUP BY c.id
         HAVING SUM(CASE WHEN l.id IS NOT NULL AND r.id IS NULL THEN 1 ELSE 0 END) = 0
         ORDER BY c.created_at DESC"
    );
    $stmt->execute([':did' => (int)$_SESSION['staff_id']]);
    $readyToFinalize = $stmt->fetchAll() ?: [];

    echo '<div class="page-title"><h2>Consultation Management</h2><p>Review patients waiting for consultation, lab results, and treatment finalization.</p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('stethoscope', 18) . ' <span>Waiting for Consultation</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('stethoscope', 28) . '</div><div class="card-stat-text"><h4>Patients</h4><p>' . count($waitingQueue) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('lab', 18) . ' <span>Lab Results Ready</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('lab', 28) . '</div><div class="card-stat-text"><h4>To Review</h4><p>' . count($resultsReadyQueue) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('receipt', 18) . ' <span>Ready to Finalize</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('receipt', 28) . '</div><div class="card-stat-text"><h4>To Billing</h4><p>' . count($readyToFinalize) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="dsms-priority-card dsms-priority-warning" style="margin-top: 24px;">';
    echo '<h3><span class="dsms-priority-dot">Action</span>Ready to Finalize &amp; Send to Billing'
        . '<span class="dsms-priority-chip">' . count($readyToFinalize) . ' patient' . (count($readyToFinalize) === 1 ? '' : 's') . '</span></h3>';
    if (empty($readyToFinalize)) {
        echo '<div class="no-data"><p>Nothing waiting to be finalized right now.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
        <thead><tr><th>Patient ID</th><th>Name</th><th>Consultation Date</th><th>Action</th></tr></thead>
        <tbody>';
        foreach ($readyToFinalize as $entry) {
            echo '<tr>
            <td><strong>' . h($entry['patient_code']) . '</strong></td>
            <td>' . h($entry['full_name']) . '</td>
            <td>' . h(date('M d, H:i', strtotime($entry['created_at']))) . '</td>
            <td>
                <a href="?action=finalize_preview&consultation_id=' . h($entry['consultation_id']) . '" class="btn btn-primary btn-small">Review Costs &amp; Finalize</a>
            </td>
            </tr>';
        }
        echo '</tbody></table></div>';
        echo '<p class="dsms-hint">Make sure all prescriptions and lab requests for the visit are entered before finalizing — Billing generates the invoice from what\'s recorded at this point.</p>';
    }
    echo '</div>';

    echo '<div class="dsms-priority-card dsms-priority-info" style="margin-top: 20px;">';
    echo '<h3><span class="dsms-priority-dot">Review</span>Patients with Lab Results Ready'
        . '<span class="dsms-priority-chip">' . count($resultsReadyQueue) . ' ready</span></h3>';
    if (empty($resultsReadyQueue)) {
        echo '<div class="no-data"><p>No patients have lab results ready for review.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
        <thead><tr><th>Patient ID</th><th>Name</th><th>Results At</th><th>Action</th></tr></thead>
        <tbody>';
        foreach ($resultsReadyQueue as $entry) {
            echo '<tr>
            <td><strong>' . h($entry['patient_id']) . '</strong></td>
            <td>' . h($entry['full_name']) . '</td>
            <td>' . h(date('M d, H:i', strtotime($entry['queued_at']))) . '</td>
            <td><a href="?action=doctor_review_lab&queue_id=' . h($entry['queue_id']) . '" class="btn btn-info btn-small">Review &amp; Prescribe</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="dsms-priority-card dsms-priority-neutral" style="margin-top: 20px;">';
    echo '<h3><span class="dsms-priority-dot">Queue</span>Patients Waiting for Consultation'
        . '<span class="dsms-priority-chip">' . count($waitingQueue) . ' waiting</span></h3>';
    if (empty($waitingQueue)) {
        echo '<div class="no-data"><p>No patients are waiting for consultation.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
        <thead><tr><th>Patient ID</th><th>Name</th><th>Queued At</th><th>Action</th></tr></thead>
        <tbody>';
        foreach ($waitingQueue as $entry) {
            echo '<tr>
            <td><strong>' . h($entry['patient_code']) . '</strong></td>
            <td>' . h($entry['full_name']) . '</td>
            <td>' . h(date('M d, H:i', strtotime($entry['queued_at']))) . '</td>
            <td><a href="?action=doctor_consult&queue_id=' . h($entry['queue_id']) . '" class="btn btn-primary btn-small">Open case</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    // Unassigned pool — claim to lock exclusivity
    echo '<div class="card" style="margin-top:18px;">';
    echo '<h3>Unassigned patients</h3>';
    echo '<p class="dsms-hint" style="margin-top:0;">Claim a patient to lock the case to you. Other doctors cannot open it until you transfer them.</p>';
    if (empty($unassignedPool)) {
        echo '<div class="no-data"><p>No unassigned patients waiting.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>ID</th><th>Name</th><th>Queued</th><th></th></tr></thead><tbody>';
        foreach ($unassignedPool as $entry) {
            echo '<tr>
                <td><strong>' . h($entry['patient_code']) . '</strong></td>
                <td>' . h($entry['full_name']) . '</td>
                <td>' . h(date('M d, H:i', strtotime($entry['queued_at']))) . '</td>
                <td>
                    <form method="post" action="?action=claim_patient" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                        <input type="hidden" name="queue_id" value="' . h($entry['queue_id']) . '">
                        <button type="submit" class="btn btn-secondary btn-small">Claim</button>
                    </form>
                </td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';


    // Medicine availability search
    echo '<div class="card med-lookup-panel" style="margin-top:20px;">';
    echo '<div class="med-lookup-head">';
    echo '<div><h3 style="margin:0;">Medicine availability</h3>';
    echo '<p class="dsms-hint" style="margin:4px 0 0;">Search inventory before prescribing — live stock from pharmacy.</p></div>';
    echo '</div>';
    echo '<div class="med-lookup-search">';
    echo '<span class="med-lookup-ico">' . dsms_icon('search', 18) . '</span>';
    echo '<input type="search" id="med-lookup-input" placeholder="Search by name, form, or category…" autocomplete="off">';
    echo '</div>';
    echo '<div id="med-lookup-results" class="med-lookup-results"></div>';
    echo '</div>';

    echo '<style>
    .med-lookup-panel{overflow:visible}
    .med-lookup-search{position:relative;margin-top:14px}
    .med-lookup-ico{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#64748b;pointer-events:none;display:flex}
    .med-lookup-search input{width:100%;padding:13px 16px 13px 42px;border:1.5px solid #e2e8f0;border-radius:14px;background:#f8fafc;font-size:.95rem;outline:none;transition:border-color .15s,box-shadow .15s,background .15s}
    .med-lookup-search input:focus{border-color:#2563a8;background:#fff;box-shadow:0 0 0 4px rgba(37,99,168,.12)}
    .med-lookup-results{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:12px;margin-top:14px}
    .med-card{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:14px 16px;box-shadow:0 4px 14px rgba(15,23,42,.04);transition:transform .2s,box-shadow .2s,border-color .2s;position:relative;overflow:hidden}
    .med-card:hover{transform:translateY(-3px);box-shadow:0 12px 28px rgba(37,99,168,.1)}
    .med-card::before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--accent,#94a3b8)}
    .med-card[data-level="ok"]{--accent:#10b981}
    .med-card[data-level="low"]{--accent:#f59e0b}
    .med-card[data-level="oos"]{--accent:#ef4444}
    .med-card-top{display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:8px}
    .med-card-name{font-weight:800;font-size:.95rem;color:#0f172a;line-height:1.25;margin:0}
    .med-card-form{font-size:.8rem;color:#64748b;margin:2px 0 0}
    .med-badge{font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.04em;padding:3px 8px;border-radius:999px;white-space:nowrap}
    .med-badge-ok{background:#ecfdf5;color:#047857}
    .med-badge-low{background:#fffbeb;color:#b45309}
    .med-badge-oos{background:#fef2f2;color:#b91c1c}
    .med-card-meta{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
    .med-pill{background:#f1f5f9;border-radius:8px;padding:6px 10px;font-size:.75rem;color:#475569}
    .med-pill b{display:block;font-size:.9rem;color:#0f172a;font-weight:700}
    .med-lookup-empty,.med-lookup-hint{grid-column:1/-1;text-align:center;padding:18px;color:#64748b;font-size:.9rem}
    .med-lookup-loading{opacity:.6}
    </style>';

    echo '<script>
    (function(){
      var input = document.getElementById("med-lookup-input");
      var box = document.getElementById("med-lookup-results");
      if (!input || !box) return;
      var timer = null;
      function badge(level, status){
        var cls = level === "ok" ? "med-badge-ok" : (level === "low" ? "med-badge-low" : "med-badge-oos");
        return \'<span class="med-badge \' + cls + \'">\' + status + \'</span>\';
      }
      function money(n){
        return Number(n||0).toLocaleString(undefined,{minimumFractionDigits:0,maximumFractionDigits:0});
      }
      function render(items, q){
        if (!q){ box.innerHTML = \'<div class="med-lookup-hint">Type a medicine name to check stock.</div>\'; return; }
        if (!items.length){ box.innerHTML = \'<div class="med-lookup-empty">No medicines matched “\' + q.replace(/[<>&]/g,\'\') + \'”.</div>\'; return; }
        box.innerHTML = items.map(function(m){
          var exp = m.expiry ? (\'<div class="med-pill"><b>\' + m.expiry + \'</b>Expiry</div>\') : \'\';
          return \'<article class="med-card" data-level="\' + m.stock_level + \'">\' +
            \'<div class="med-card-top"><div><p class="med-card-name">\' + m.name + \'</p>\' +
            \'<p class="med-card-form">\' + m.form + \' · \' + m.category + \'</p></div>\' +
            badge(m.stock_level, m.status) + \'</div>\' +
            \'<div class="med-card-meta">\' +
            \'<div class="med-pill"><b>\' + m.quantity + \'</b>In stock</div>\' +
            \'<div class="med-pill"><b>TZS \' + money(m.unit_price) + \'</b>Unit price</div>\' +
            exp +
            \'</div></article>\';
        }).join("");
      }
      function lookup(q){
        box.classList.add("med-lookup-loading");
        fetch("?action=medicine_lookup&q=" + encodeURIComponent(q))
          .then(function(r){ return r.json(); })
          .then(function(data){ box.classList.remove("med-lookup-loading"); render(data.items || [], q); })
          .catch(function(){ box.classList.remove("med-lookup-loading"); box.innerHTML = \'<div class="med-lookup-empty">Could not load results.</div>\'; });
      }
      input.addEventListener("input", function(){
        var q = input.value.trim();
        clearTimeout(timer);
        if (!q){ render([], ""); return; }
        timer = setTimeout(function(){ lookup(q); }, 220);
      });
      render([], "");
    })();
    </script>';


    echo '<p class="dsms-hint" style="margin-top:14px;">Assigned cases are private to the treating doctor. Use <strong>Transfer</strong> on the consultation page to hand a patient to a colleague.</p>';

    renderFooter();
    exit;
}

if ($action === 'accept_for_billing') {
    requireRole('doctor');
    // Obsolete: consultation no longer requires pre-payment. Billing now
    // happens once, after treatment is finalized, covering consultation +
    // labs + pharmacy together. Just send the doctor back to their queue.
    setFlash('Patients no longer need to be "accepted for billing" before consultation — start the consultation directly from the queue.');
    header('Location: ?action=doctor_dashboard');
    exit;
}

// DOCTOR REVIEW LAB RESULTS & PRESCRIBE
if ($action === 'doctor_review_lab') {
    requireRole('doctor');

    $queueId = (int)($_GET['queue_id'] ?? 0);
    if ($queueId <= 0) {
        setFlash('Please select a patient from the queue.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    $queueEntry = QueueManager::find($queueId);
    if (!$queueEntry) {
        setFlash('Queue entry not found.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    $patient = Patient::find((int)$queueEntry['patient_row_id']);
    if (!$patient) {
        setFlash('Patient record not found.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    renderHeader('Review Lab Results & Prescribe', 'doctor');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Lab Results Review for ' . h($patient['full_name']) . '</h2><p>Review lab investigation results and prescribe medication based on findings.</p></div>';

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3>Patient Details</h3>';
    echo '<p><strong>ID:</strong> ' . h($patient['patient_id']) . '</p>';
    echo '<p><strong>Name:</strong> ' . h($patient['full_name']) . '</p>';
    echo '<p><strong>Gender:</strong> ' . h($patient['gender']) . '</p>';
    echo '<p><strong>Phone:</strong> ' . h($patient['phone']) . '</p>';
    echo '<p><strong>Email:</strong> ' . h($patient['email']) . '</p>';
    echo '<p><strong>Current Status:</strong> <span class="status-badge status-accepted">Results Ready</span></p>';
    echo '</div>';

    // Get lab requests with results
    $labRequests = LabRequest::getForPatient($patient['id']);
    echo '<div class="card"><h3>Lab Investigation Results</h3>';
    if (empty($labRequests)) {
        echo '<div class="no-data"><p>No lab requests found for this patient.</p></div>';
    } else {
        foreach ($labRequests as $request) {
            $labResult = LabResult::findByLabRequestId((int)$request['id']);
            echo '<div style="margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #eee;">';
            echo '<p><strong>Test Type:</strong> ' . h($request['test_type']) . '</p>';
            echo '<p><strong>Status:</strong> ' . h($request['status']) . '</p>';
            echo '<p><strong>Requested:</strong> ' . h(date('M d, H:i', strtotime($request['created_at']))) . '</p>';
            if ($labResult) {
                echo '<p><strong>Result:</strong> <span style="background-color: #f0f8ff; padding: 8px; border-radius: 4px; display: block; margin-top: 8px;">' . h($labResult['result']) . '</span></p>';
                if ($labResult['comments']) {
                    echo '<p><strong>Comments:</strong> ' . h($labResult['comments']) . '</p>';
                }
            } else {
                echo '<p><strong>Result:</strong> <em>Pending</em></p>';
            }
            echo '</div>';
        }
    }
    echo '</div>';

    echo '</div>';

    echo '<div class="dsms-priority-card dsms-priority-info" style="margin-top: 20px;">';
    echo '<h3><span class="dsms-priority-dot">Review</span>Request Additional Investigation</h3>';
    echo '<p class="dsms-hint" style="margin-bottom: 14px;">If findings so far are inconclusive, request another test. The patient will return to the lab queue and come back here once results are ready.</p>';
    echo '<form method="post" action="?action=request_additional_lab_test">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<input type="hidden" name="patient_id" value="' . h($patient['id']) . '">';
    echo '<input type="hidden" name="queue_id" value="' . h($queueEntry['queue_id']) . '">';
    echo '<div class="form-row">';
    echo '<label>Lab Test<br><select name="lab_test_catalog_id" required>';
    echo '<option value="">-- Select a test --</option>';
    foreach (LabTestCatalog::active() as $test) {
        echo '<option value="' . h($test['id']) . '">' . h($test['test_name']) . ' — TZS ' . h(number_format((float)$test['price'], 2)) . '</option>';
    }
    echo '</select></label>';
    echo '<div style="align-self:flex-end;"><button type="submit" class="btn btn-secondary" style="width:100%;">Request Test</button></div>';
    echo '</div>';
    echo '</form>';
    echo '</div>';

    $catalogMedicines = Medicine::allActive();
    echo '<script>window.DSMS_MEDICINES = ' . json_encode(array_map(static function (array $m): array {
        return [
            'id' => (int)$m['id'],
            'category_id' => (int)$m['category_id'],
            'name' => $m['name'],
            'quantity' => (int)$m['quantity'],
            'status' => $m['status'],
            'unit_price' => (float)$m['unit_price'],
        ];
    }, $catalogMedicines)) . ';</script>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Prescribe Medication Based on Lab Findings</h3>';
    echo '<p class="dsms-hint">Select from inventory. <strong>Green = in stock</strong>, <strong>amber = low</strong>, <strong>red = out of stock</strong>. Out-of-stock items need an explicit pharmacy override before you can prescribe.</p>';
    echo '<form method="post" action="?action=create_prescription" id="rx-form">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<input type="hidden" name="patient_id" value="' . h($patient['id']) . '">';
    echo '<input type="hidden" name="queue_id" value="' . h($queueEntry['queue_id']) . '">';
    echo '<div id="prescription-entries">';
    echo '<div class="prescription-row">';
    echo '<input type="hidden" name="medication[]" data-medication-field value="">';
    echo '<div class="form-row full">';
    echo '<label>Medicine (from inventory) *<br><select class="medicine-select" name="medicine_id[]" required>' . renderMedicineSelectOptions($catalogMedicines) . '</select></label>';
    echo '</div>';
    echo '<div class="medicine-stock-info" style="margin-bottom: 10px;"></div>';
    echo '<div class="rx-oos-override" hidden style="margin-bottom:12px;padding:12px 14px;border-radius:12px;border:1px solid #fecaca;background:#fef2f2;">';
    echo '<label class="auth-check" style="align-items:flex-start;gap:10px;">';
    echo '<input type="checkbox" name="stock_override[]" value="1" class="rx-stock-override">';
    echo '<span><strong>Prescribe anyway (request pharmacy confirmation)</strong><br><span class="dsms-hint">This medicine is out of stock. Pharmacy will be notified to source, substitute, or advise before dispensing.</span></span>';
    echo '</label></div>';
    echo '<div class="form-row">';
    echo '<label>Dosage *<br><input type="text" name="dosage[]" data-dosage-field placeholder="e.g., 500mg" required></label>';
    echo '<label>Frequency *<br><input type="text" name="frequency[]" placeholder="e.g., 3 times daily" required></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Duration<br><input type="text" name="duration[]" placeholder="e.g., 7 days"></label>';
    echo '<label>Quantity / Units *<br><input type="number" name="quantity[]" min="1" step="1" value="1" required data-qty-field></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Unit Price (TZS) — from inventory<br><input type="text" data-price-field readonly tabindex="-1" placeholder="Select a medicine" style="background:#f1f5f9; font-weight:700; color:#1d4ed8;"></label>';
    echo '<label>Line Total (auto)<br><input type="text" data-line-total-field readonly tabindex="-1" value="—" style="background:#f1f5f9; font-weight:700;"></label>';
    echo '</div>';
    echo '<div class="form-row full">';
    echo '<label>Instructions<br><textarea name="instructions[]" placeholder="e.g., Take after meals" rows="3"></textarea></label>';
    echo '</div>';
    echo '<button type="button" class="btn btn-secondary btn-small remove-prescription" style="margin-top: 12px;">Remove</button>';
    echo '</div>';
    echo '</div>';
    echo '<button type="button" class="btn btn-secondary" id="add-prescription">Add Another Medicine</button>';
    echo '<button type="submit" class="btn btn-primary">Save Prescription Lines</button>';
    echo '<a href="?action=doctor_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Back to Dashboard</a>';
    echo '</form>';
    echo '<script>
        document.getElementById("add-prescription").addEventListener("click", function () {
            var container = document.getElementById("prescription-entries");
            var row = container.querySelector(".prescription-row").cloneNode(true);
            row.querySelectorAll("input, textarea").forEach(function (field) {
                field.value = "";
            });
            row.querySelectorAll("select.medicine-select").forEach(function (select) {
                select.selectedIndex = 0;
            });
            row.querySelectorAll(".medicine-stock-info").forEach(function (box) {
                box.innerHTML = "";
            });
            container.appendChild(row);
        });
        document.getElementById("prescription-entries").addEventListener("click", function (event) {
            if (event.target.matches(".remove-prescription")) {
                var rows = document.querySelectorAll(".prescription-row");
                if (rows.length > 1) {
                    event.target.closest(".prescription-row").remove();
                }
            }
        });
    </script>';
    echo '</div>';

    renderFooter();
    exit;
}

// DOCTOR CONSULTATION PAGE
if ($action === 'doctor_consult') {
    requireRole('doctor');

    $queueId = (int)($_GET['queue_id'] ?? 0);
    if ($queueId <= 0) {
        setFlash('Please select a patient from the queue.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    $queueEntry = QueueManager::find($queueId);
    if (!$queueEntry) {
        setFlash('Queue entry not found.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    // Exclusive assignment: only the assigned doctor (or claim unassigned) may open this case
    $doctorId = (int)$_SESSION['staff_id'];
    $assigned = $queueEntry['assigned_doctor_id'] ?? null;
    if ($assigned !== null && $assigned !== '' && (int)$assigned !== $doctorId) {
        setFlash('Access denied. This patient is assigned to another doctor. They must transfer the case to you first.', 'error');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    try {
        if (in_array($queueEntry['status'], ['Waiting for Consultation', 'Accepted', 'Paid', 'Results Ready'], true)) {
            QueueManager::startConsultation($queueId, $doctorId);
            $queueEntry = QueueManager::find($queueId) ?: $queueEntry;
        } elseif ($queueEntry['status'] !== 'In Consultation') {
            setFlash('This patient is not currently available for consultation (status: ' . h($queueEntry['status']) . ').', 'error');
            header('Location: ?action=doctor_dashboard');
            exit;
        } elseif ($assigned === null || $assigned === '') {
            // Already in consult but unassigned — claim
            QueueManager::claim($queueId, $doctorId);
            $queueEntry = QueueManager::find($queueId) ?: $queueEntry;
        }
    } catch (Throwable $e) {
        setFlash($e->getMessage(), 'error');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    $patient = Patient::find((int)$queueEntry['patient_row_id']);
    if (!$patient) {
        setFlash('Patient record not found.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    renderHeader('Doctor Consultation', 'doctor');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $queueEntry = QueueManager::find($queueId) ?: $queueEntry;
    $latestVital = Vital::latestForPatient((int)$patient['id']);
    $otherDoctors = array_filter(Staff::getDoctors(), fn($d) => (int)$d['id'] !== (int)$_SESSION['staff_id']);
    $csrf = h(getCsrfToken());
    $status = $queueEntry['status'] ?? '';
    $statusClass = match (true) {
        $status === 'In Consultation' => 'status-accepted',
        $status === 'Accepted' => 'status-accepted',
        $status === 'Results Ready' => 'status-paid',
        default => 'status-waiting',
    };
    $startedAt = $queueEntry['accepted_at'] ?? null;
    $queuedAt = $queueEntry['queued_at'] ?? null;

    // ---- Top patient bar ----
    echo '<div class="consult-top">';
    echo '<div class="consult-top-main">';
    echo '<a href="?action=doctor_dashboard" class="btn btn-secondary btn-small">← Queue</a>';
    echo '<div>';
    echo '<h2 class="consult-patient-name">' . h($patient['full_name']) . '</h2>';
    echo '<p class="consult-patient-meta">'
        . '<span>' . h($patient['patient_id']) . '</span>'
        . '<span>' . h($patient['gender'] ?? '—') . '</span>'
        . '<span>' . h($patient['date_of_birth'] ?? '—') . '</span>'
        . '<span>' . h($patient['phone'] ?? '—') . '</span>'
        . '</p>';
    echo '</div></div>';
    echo '<div class="consult-top-status">';
    echo '<span class="status-badge ' . $statusClass . '">' . h($status) . '</span>';
    if ($queuedAt) {
        echo '<small>Queued ' . h(date('M d, H:i', strtotime($queuedAt))) . '</small>';
    }
    if ($startedAt) {
        echo '<small>Started ' . h(date('M d, H:i', strtotime($startedAt))) . '</small>';
    }
    echo '</div></div>';

    // Safety chips
    $allergy = trim((string)($patient['allergies'] ?? ''));
    $chronic = trim((string)($patient['chronic_conditions'] ?? ''));
    $blood = trim((string)($patient['blood_type'] ?? ''));
    echo '<div class="consult-safety">';
    echo '<span class="consult-chip"><strong>Blood</strong> ' . h($blood !== '' ? $blood : '—') . '</span>';
    echo '<span class="consult-chip' . ($allergy !== '' ? ' consult-chip-warn' : '') . '"><strong>Allergies</strong> ' . h($allergy !== '' ? $allergy : 'None recorded') . '</span>';
    echo '<span class="consult-chip"><strong>Chronic</strong> ' . h($chronic !== '' ? $chronic : 'None recorded') . '</span>';
    echo '</div>';

    echo '<div class="consult-layout">';

    // ===== MAIN COLUMN =====
    echo '<div class="consult-main">';

    // Consultation notes
    echo '<div class="card consult-card">';
    echo '<h3>Consultation notes</h3>';
    echo '<form method="post" action="?action=save_consultation">';
    echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
    echo '<input type="hidden" name="patient_id" value="' . h($patient['id']) . '">';
    echo '<div class="form-row">';
    echo '<label>Symptoms<br><textarea name="symptoms" rows="3" required placeholder="Chief complaint and symptoms"></textarea></label>';
    echo '<label>Examination<br><textarea name="examination" rows="3" required placeholder="Clinical findings"></textarea></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Diagnosis<br><textarea name="diagnosis" rows="2" required placeholder="Working diagnosis"></textarea></label>';
    echo '<label>Outcome<br><select name="outcome">';
    echo '<option value="Healthy">Healthy / discharge advice</option>';
    echo '<option value="Lab Investigation Required">Lab investigation required</option>';
    echo '<option value="Medicine Required">Medicine required</option>';
    echo '</select></label>';
    echo '</div>';
    echo '<div class="form-row full lab-fields">';
    echo '<label>Lab test (if needed)<br><select name="lab_test_catalog_id"><option value="">— None —</option>';
    foreach (LabTestCatalog::active() as $test) {
        echo '<option value="' . h($test['id']) . '">' . h($test['test_name']) . ' — TZS ' . h(number_format((float)$test['price'], 2)) . '</option>';
    }
    echo '</select></label>';
    echo '</div>';
    echo '<div class="form-row full">';
    echo '<label>Additional notes<br><textarea name="note" rows="2" placeholder="Optional clinical notes"></textarea></label>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary">Save consultation</button>';
    echo '</form></div>';

    // Prescribe
    $catalogMedicines = Medicine::allActive();
    echo '<script>window.DSMS_MEDICINES = ' . json_encode(array_map(static function (array $m): array {
        return [
            'id' => (int)$m['id'],
            'category_id' => (int)$m['category_id'],
            'name' => $m['name'],
            'quantity' => (int)$m['quantity'],
            'status' => $m['status'],
            'unit_price' => (float)$m['unit_price'],
        ];
    }, $catalogMedicines)) . ';</script>';

    echo '<div class="card consult-card">';
    echo '<h3>Prescribe medication</h3>';
    echo '<p class="dsms-hint" style="margin-top:0;">Green = in stock · Amber = low · Red = out of stock (needs pharmacy override).</p>';
    echo '<form method="post" action="?action=create_prescription" class="prescription-row">';
    echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
    echo '<input type="hidden" name="patient_id" value="' . h($patient['id']) . '">';
    echo '<input type="hidden" name="queue_id" value="' . h($queueId) . '">';
    echo '<input type="hidden" name="medication" data-medication-field value="">';
    echo '<div class="form-row full">';
    echo '<label>Medicine *<br><select class="medicine-select" name="medicine_id" required>' . renderMedicineSelectOptions($catalogMedicines) . '</select></label>';
    echo '</div>';
    echo '<div class="medicine-stock-info" style="margin-bottom:10px;"></div>';
    echo '<div class="rx-oos-override" hidden style="margin-bottom:12px;padding:12px 14px;border-radius:12px;border:1px solid #fecaca;background:#fef2f2;">';
    echo '<label class="auth-check" style="align-items:flex-start;gap:10px;">';
    echo '<input type="checkbox" name="stock_override_confirm" value="1" class="rx-stock-override">';
    echo '<span><strong>Prescribe anyway (notify pharmacy)</strong><br><span class="dsms-hint">Out of stock — pharmacy will source or substitute.</span></span>';
    echo '</label></div>';
    echo '<div class="form-row">';
    echo '<label>Dosage *<br><input type="text" name="dosage" data-dosage-field required placeholder="e.g. 500mg"></label>';
    echo '<label>Frequency *<br><input type="text" name="frequency" required placeholder="e.g. twice daily"></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Duration<br><input type="text" name="duration" placeholder="e.g. 7 days"></label>';
    echo '<label>Quantity *<br><input type="number" name="quantity" min="1" step="1" value="1" required data-qty-field></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Unit price (inventory)<br><input type="text" data-price-field readonly tabindex="-1" placeholder="—" style="background:#f1f5f9;font-weight:700;color:#1d4ed8;"></label>';
    echo '<label>Line total<br><input type="text" data-line-total-field readonly tabindex="-1" value="—" style="background:#f1f5f9;font-weight:700;"></label>';
    echo '</div>';
    echo '<div class="form-row full">';
    echo '<label>Instructions<br><textarea name="instructions" rows="2" placeholder="e.g. After meals"></textarea></label>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary">Save prescription</button>';
    echo '</form></div>';

    // Existing prescriptions compact
    $prescriptions = Prescription::getForPatient((int)$patient['id']);
    echo '<div class="card consult-card">';
    echo '<h3>Prescriptions this visit</h3>';
    if (empty($prescriptions)) {
        echo '<p class="dsms-hint">No medication orders yet.</p>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Medicine</th><th>Dose</th><th>Qty</th><th>Total</th><th>Status</th></tr></thead><tbody>';
        foreach (array_slice($prescriptions, 0, 12) as $rx) {
            echo '<tr><td>' . h($rx['medication']) . '</td><td>' . h($rx['dosage']) . ' · ' . h($rx['frequency']) . '</td><td>' . h((string)($rx['quantity'] ?? 1)) . '</td><td>' . h(number_format((float)($rx['line_total'] ?? 0), 0)) . '</td><td><span class="status-badge">' . h($rx['status'] ?? 'Draft') . '</span></td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '</div>'; // main

    // ===== SIDEBAR =====
    echo '<aside class="consult-side">';

    // Vitals
    echo '<div class="card consult-card">';
    echo '<h3>Reception vitals</h3>';
    if (!$latestVital) {
        echo '<p class="dsms-hint">No vitals recorded yet.</p>';
    } else {
        echo '<div class="consult-vital-grid">';
        $pairs = [
            'BP' => $latestVital['blood_pressure'] ?? '—',
            'Pulse' => ($latestVital['pulse_rate'] ?? '—') . (isset($latestVital['pulse_rate']) ? ' bpm' : ''),
            'Temp' => ($latestVital['temperature'] ?? '—') . (isset($latestVital['temperature']) ? ' °C' : ''),
            'Weight' => ($latestVital['weight'] ?? '—') . (isset($latestVital['weight']) ? ' kg' : ''),
            'Height' => ($latestVital['height'] ?? '—') . (isset($latestVital['height']) ? ' cm' : ''),
        ];
        foreach ($pairs as $label => $val) {
            echo '<div><small>' . h($label) . '</small><strong>' . h((string)$val) . '</strong></div>';
        }
        echo '</div>';
        if (!empty($latestVital['recorded_at'])) {
            echo '<p class="dsms-hint" style="margin:10px 0 0;">Recorded ' . h(date('M d, H:i', strtotime($latestVital['recorded_at']))) . '</p>';
        }
    }
    echo '</div>';

    // Patient contact card compact
    echo '<div class="card consult-card">';
    echo '<h3>Patient profile</h3>';
    echo '<dl class="consult-dl">';
    echo '<div><dt>Email</dt><dd>' . h($patient['email'] ?: '—') . '</dd></div>';
    echo '<div><dt>Address</dt><dd>' . h($patient['address'] ?: '—') . '</dd></div>';
    echo '<div><dt>Emergency</dt><dd>' . h($patient['emergency_contact'] ?: '—') . '</dd></div>';
    if (!empty($patient['medical_notes'])) {
        echo '<div><dt>Notes</dt><dd>' . h($patient['medical_notes']) . '</dd></div>';
    }
    echo '</dl></div>';

    // Labs
    $labRequests = LabRequest::getForPatient((int)$patient['id']);
    echo '<div class="card consult-card">';
    echo '<h3>Lab requests</h3>';
    if (empty($labRequests)) {
        echo '<p class="dsms-hint">None yet.</p>';
    } else {
        echo '<ul class="consult-list">';
        foreach (array_slice($labRequests, 0, 8) as $request) {
            $labResult = LabResult::findByLabRequestId((int)$request['id']);
            echo '<li><strong>' . h($request['test_type']) . '</strong> <span class="status-badge">' . h($request['status']) . '</span>';
            if ($labResult && !empty($labResult['result'])) {
                echo '<div class="dsms-hint">' . h(mb_strimwidth((string)$labResult['result'], 0, 80, '…')) . '</div>';
            }
            echo '</li>';
        }
        echo '</ul>';
    }
    echo '</div>';

    // Quick medicine lookup on consult
    echo '<div class="card consult-card">';
    echo '<h3>Check stock</h3>';
    echo '<p class="dsms-hint" style="margin-top:0;">Search pharmacy inventory without leaving this visit.</p>';
    echo '<div class="med-lookup-search" style="margin-top:8px;">';
    echo '<span class="med-lookup-ico">' . dsms_icon('search', 16) . '</span>';
    echo '<input type="search" id="med-lookup-input-consult" placeholder="Search medicine…" autocomplete="off" style="padding:10px 12px 10px 38px;font-size:.85rem;">';
    echo '</div>';
    echo '<div id="med-lookup-results-consult" class="med-lookup-results" style="grid-template-columns:1fr;margin-top:10px;"></div>';
    echo '</div>';

    // Transfer compact
    echo '<div class="card consult-card consult-transfer">';
    echo '<h3>Transfer patient</h3>';
    echo '<p class="dsms-hint">Hand case to a colleague. You lose access until transferred back.</p>';
    if (empty($otherDoctors)) {
        echo '<p class="dsms-hint">No other active doctors.</p>';
    } else {
        echo '<form method="post" action="?action=transfer_patient" onsubmit="return confirm(\'Transfer this patient?\');">';
        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
        echo '<input type="hidden" name="queue_id" value="' . h($queueId) . '">';
        echo '<label>Doctor<br><select name="to_doctor_id" required><option value="">Select…</option>';
        foreach ($otherDoctors as $d) {
            echo '<option value="' . h($d['id']) . '">' . h($d['full_name']) . ($d['specialization'] ? ' — ' . h($d['specialization']) : '') . '</option>';
        }
        echo '</select></label>';
        echo '<button type="submit" class="btn btn-secondary btn-small" style="margin-top:10px;width:100%;">Transfer</button>';
        echo '</form>';
    }
    echo '</div>';

    echo '</aside>';
    echo '</div>'; // layout

    echo '<style>
    .consult-top{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:14px}
    .consult-top-main{display:flex;align-items:flex-start;gap:12px}
    .consult-patient-name{margin:0 0 4px;font-size:1.45rem;font-weight:800;letter-spacing:-.02em;color:#0f172a}
    .consult-patient-meta{margin:0;display:flex;flex-wrap:wrap;gap:10px;color:#64748b;font-size:.85rem}
    .consult-patient-meta span:not(:last-child)::after{content:""; }
    .consult-top-status{display:flex;flex-direction:column;align-items:flex-end;gap:4px}
    .consult-top-status small{color:#64748b;font-size:.75rem}
    .consult-safety{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px}
    .consult-chip{background:#fff;border:1px solid #e2e8f0;border-radius:999px;padding:6px 12px;font-size:.8rem;color:#334155}
    .consult-chip strong{color:#0f172a;margin-right:4px}
    .consult-chip-warn{border-color:#fecaca;background:#fef2f2;color:#991b1b}
    .consult-layout{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(260px,.9fr);gap:16px;align-items:start}
    .consult-card{margin-bottom:0}
    .consult-main,.consult-side{display:flex;flex-direction:column;gap:14px}
    .consult-vital-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}
    .consult-vital-grid small{display:block;font-size:.68rem;text-transform:uppercase;letter-spacing:.04em;color:#94a3b8;font-weight:600}
    .consult-vital-grid strong{font-size:.95rem;color:#0f172a}
    .consult-dl{margin:0;display:flex;flex-direction:column;gap:8px}
    .consult-dl div{display:grid;grid-template-columns:88px 1fr;gap:8px;font-size:.85rem}
    .consult-dl dt{color:#94a3b8;font-weight:600;margin:0}
    .consult-dl dd{margin:0;color:#334155}
    .consult-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:10px}
    .consult-list li{font-size:.85rem}
    .consult-transfer{border-color:#bfdbfe}
    @media (max-width:980px){.consult-layout{grid-template-columns:1fr}}
    </style>';

        echo '<script>
    (function(){
      var input = document.getElementById("med-lookup-input-consult");
      var box = document.getElementById("med-lookup-results-consult");
      if (!input || !box) return;
      var timer = null;
      function money(n){ return Number(n||0).toLocaleString(undefined,{maximumFractionDigits:0}); }
      function render(items,q){
        if (!q){ box.innerHTML=""; return; }
        if (!items.length){ box.innerHTML="<div class=\\"med-lookup-empty\\" style=\\"padding:10px;\\">No matches</div>"; return; }
        box.innerHTML = items.slice(0,6).map(function(m){
          var cls = m.stock_level==="ok"?"med-badge-ok":(m.stock_level==="low"?"med-badge-low":"med-badge-oos");
          return "<article class=\\"med-card\\" data-level=\\""+m.stock_level+"\\" style=\\"padding:10px 12px;\\">"+
            "<div class=\\"med-card-top\\"><div><p class=\\"med-card-name\\" style=\\"font-size:.88rem;\\">"+m.name+"</p>"+
            "<p class=\\"med-card-form\\">"+m.form+"</p></div>"+
            "<span class=\\"med-badge "+cls+"\\">"+m.status+"</span></div>"+
            "<div class=\\"med-card-meta\\"><div class=\\"med-pill\\"><b>"+m.quantity+"</b>Stock</div>"+
            "<div class=\\"med-pill\\"><b>TZS "+money(m.unit_price)+"</b>Price</div></div></article>";
        }).join("");
      }
      input.addEventListener("input", function(){
        var q = input.value.trim();
        clearTimeout(timer);
        if (!q){ render([],""); return; }
        timer = setTimeout(function(){
          fetch("?action=medicine_lookup&q="+encodeURIComponent(q)).then(function(r){return r.json();})
            .then(function(d){ render(d.items||[], q); });
        }, 220);
      });
    })();
    </script>';

    renderFooter();
    exit;
}


if ($action === 'finalize_preview') {
    requireRole('doctor');
    $consultationId = (int)($_GET['consultation_id'] ?? 0);
    $pdo = Database::getConnection();
    $stmt = $pdo->prepare(
        'SELECT c.*, pt.patient_id AS patient_code, pt.full_name
         FROM consultations c
         JOIN patients pt ON pt.id = c.patient_id
         WHERE c.id = :id AND c.doctor_staff_id = :did'
    );
    $stmt->execute([':id' => $consultationId, ':did' => (int)$_SESSION['staff_id']]);
    $consultation = $stmt->fetch();

    if (!$consultation) {
        setFlash('Consultation not found or not assigned to you.', 'error');
        header('Location: ?action=doctor_dashboard');
        exit;
    }
    if ((int)$consultation['treatment_finalized'] === 1) {
        setFlash('This consultation is already finalized.', 'error');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    $prescriptions = Prescription::getForConsultation($consultationId);
    $pharmacyTotal = 0.0;
    foreach ($prescriptions as $rx) {
        $pharmacyTotal += (float)($rx['line_total'] ?? ((float)($rx['unit_price'] ?? 0) * max(1, (int)($rx['quantity'] ?? 1))));
    }

    // Lab charges (from existing lab_requests.bill — display only; Billing engine still owns totals)
    $labStmt = $pdo->prepare('SELECT test_type, bill FROM lab_requests WHERE consultation_id = :cid');
    $labStmt->execute([':cid' => $consultationId]);
    $labs = $labStmt->fetchAll();
    $labTotal = 0.0;
    foreach ($labs as $lab) {
        $labTotal += (float)($lab['bill'] ?? 0);
    }
    $procedures = ProcedureCatalog::forConsultation($consultationId);
    $procedureTotal = 0.0;
    foreach ($procedures as $pr) {
        $procedureTotal += (float)($pr['line_total'] ?? 0);
    }
    $procedureCatalog = ProcedureCatalog::active();
    $consultationFee = 5000.00; // mirrors Billing::CONSULTATION_FEE for display
    $grandTotal = $consultationFee + $labTotal + $pharmacyTotal + $procedureTotal;

    // Queue link for "Back to Edit"
    $qStmt = $pdo->prepare('SELECT id FROM queue_entries WHERE patient_id = :pid ORDER BY id DESC LIMIT 1');
    $qStmt->execute([':pid' => $consultation['patient_id']]);
    $queueRow = $qStmt->fetch();
    $backUrl = $queueRow
        ? ('?action=doctor_consult&queue_id=' . urlencode((string)$queueRow['id']))
        : '?action=doctor_dashboard';

    renderHeader('Confirm Finalization', 'doctor');
    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Final Confirmation</h2>
        <p>Patient <strong>' . h($consultation['patient_code'] . ' — ' . $consultation['full_name']) . '</strong>.
        Review all charges. Finalizing locks prescriptions and creates the bill for Billing.</p></div>';

    echo '<div class="card"><h3>Medicines</h3>';
    if (empty($prescriptions)) {
        echo '<div class="no-data"><p>No prescriptions on this consultation.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Medicine</th><th>Unit Price (TZS)</th><th>Quantity</th><th>Line Total (TZS)</th></tr></thead><tbody>';
        foreach ($prescriptions as $rx) {
            echo '<tr>
                <td>' . h($rx['medication']) . '<br><small>' . h($rx['dosage'] . ' · ' . $rx['frequency']) . '</small></td>
                <td>' . h(number_format((float)($rx['unit_price'] ?? 0), 2)) . '</td>
                <td>' . h((string)($rx['quantity'] ?? 1)) . '</td>
                <td><strong>' . h(number_format((float)($rx['line_total'] ?? 0), 2)) . '</strong></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top:16px;"><h3>Charge Summary</h3>
        <div class="table-responsive"><table>
            <tr><td>Consultation Fee</td><td style="text-align:right;">TZS ' . h(number_format($consultationFee, 2)) . '</td></tr>';
    if (!empty($labs)) {
        foreach ($labs as $lab) {
            echo '<tr><td>Lab: ' . h($lab['test_type']) . '</td><td style="text-align:right;">TZS ' . h(number_format((float)$lab['bill'], 2)) . '</td></tr>';
        }
    } else {
        echo '<tr><td>Laboratory Charges</td><td style="text-align:right;">TZS 0.00</td></tr>';
    }
    if (!empty($procedures)) {
        foreach ($procedures as $pr) {
            echo '<tr><td>Procedure: ' . h($pr['name']) . ' ×' . h($pr['quantity']) . '</td><td style="text-align:right;">TZS ' . h(number_format((float)$pr['line_total'], 2)) . '</td></tr>';
        }
    } else {
        echo '<tr><td>Procedures</td><td style="text-align:right;">TZS 0.00</td></tr>';
    }
    echo '<tr><td>Pharmacy (medicines)</td><td style="text-align:right;">TZS ' . h(number_format($pharmacyTotal, 2)) . '</td></tr>
        <tr class="total-row"><td><strong>Grand Total</strong></td><td style="text-align:right;font-weight:800;color:#1d4ed8;font-size:1.15rem;">TZS ' . h(number_format($grandTotal, 2)) . '</td></tr>
        </table></div>
        <p class="dsms-hint">Prices are from inventory / procedure catalog. Doctors cannot change unit prices.</p>
    </div>';

    echo '<div class="card" style="margin-top:16px;"><h3>Add procedure</h3>
        <form method="post" action="?action=add_consultation_procedure" class="form-row">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="consultation_id" value="' . h($consultationId) . '">
            <input type="hidden" name="return_to" value="?action=finalize_preview&consultation_id=' . h($consultationId) . '">
            <label>Procedure<br><select name="procedure_catalog_id" required><option value="">Select…</option>';
    foreach ($procedureCatalog as $pc) {
        echo '<option value="' . h($pc['id']) . '">' . h($pc['name']) . ' — TZS ' . h(number_format((float)$pc['unit_price'], 2)) . '</option>';
    }
    echo '</select></label>
            <label>Qty<br><input type="number" name="quantity" min="1" value="1" style="width:80px;"></label>
            <div style="align-self:flex-end;"><button type="submit" class="btn btn-secondary">Add</button></div>
        </form>
    </div>';

    echo '<form method="post" action="?action=finalize_treatment" style="margin-top:18px;display:flex;gap:12px;flex-wrap:wrap;">
        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
        <input type="hidden" name="consultation_id" value="' . h((string)$consultationId) . '">
        <input type="hidden" name="confirmed" value="1">
        <a href="' . h($backUrl) . '" class="btn btn-secondary">Back to Edit</a>
        <button type="submit" class="btn btn-primary">Finalize Treatment</button>
    </form>';

    renderFooter();
    exit;
}

// BILLING DASHBOARD
if ($action === 'billing_dashboard') {
    requireRole('billing');
    // This dashboard predates centralized billing (Billing Center) and
    // worked off separate consultation/lab/pharmacy payments that no
    // longer happen. Redirect rather than show stale, disconnected data.
    header('Location: ?action=billing_center');
    exit;
}

if ($action === 'legacy_billing_dashboard_disabled') {
    requireRole('billing');

    renderHeader('Billing & Payments', 'billing');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $acceptedQueue = QueueManager::getAccepted();
    $payments = Payment::all();
    $pharmacyBills = PharmacyBill::getPending();

    echo '<div class="page-title"><h2>Billing Desk</h2><p>Collect payments for consultations, lab tests, and medications.</p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('card', 18) . ' <span>Consultations Pending</span></h3><div class="card-stat"><div class="card-stat-text"><h4>Awaiting</h4><p>' . count($acceptedQueue) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('receipt', 18) . ' <span>Pharmacy Bills Pending</span></h3><div class="card-stat"><div class="card-stat-text"><h4>Awaiting</h4><p>' . count($pharmacyBills) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('check', 18) . ' <span>Total Collected</span></h3><div class="card-stat"><div class="card-stat-text"><h4>Payments</h4><p>' . count($payments) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Pharmacy Bills Pending Payment</h3>';
    if (empty($pharmacyBills)) {
        echo '<div class="no-data"><p>No pharmacy bills are awaiting payment.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient ID</th><th>Name</th><th>Amount</th><th>Created</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($pharmacyBills as $bill) {
            echo '<tr>
                <td>' . h($bill['patient_code']) . '</td>
                <td>' . h($bill['full_name']) . '</td>
                <td>' . h(number_format((float)$bill['amount'], 2)) . '</td>
                <td>' . h(date('M d, H:i', strtotime($bill['created_at']))) . '</td>
                <td><a href="?action=collect_pharmacy_bill_payment&bill_id=' . h($bill['id']) . '" class="btn btn-primary btn-small">Collect Payment</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Accepted Consultations - Collect Consultation Payment</h3>';
    if (empty($acceptedQueue)) {
        echo '<div class="no-data"><p>No accepted consultations awaiting payment.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient ID</th><th>Name</th><th>Queued At</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($acceptedQueue as $entry) {
            echo '<tr>
                <td>' . h($entry['patient_code']) . '</td>
                <td>' . h($entry['full_name']) . '</td>
                <td>' . h(date('M d, H:i', strtotime($entry['queued_at']))) . '</td>
                <td><span class="status-badge status-accepted">Accepted</span></td>
                <td><a href="?action=collect_payment&queue_id=' . h($entry['queue_id']) . '" class="btn btn-secondary btn-small">Collect Payment</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Recent Payments</h3>';
    if (empty($payments)) {
        echo '<div class="no-data"><p>No payments have been recorded yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Control Number</th><th>Patient</th><th>Type</th><th>Amount</th><th>Paid At</th></tr></thead>
            <tbody>';
        foreach ($payments as $payment) {
            echo '<tr>
                <td>' . h($payment['receipt_number']) . '</td>
                <td>' . h($payment['patient_code'] . ' - ' . $payment['full_name']) . '</td>
                <td>' . h($payment['type']) . '</td>
                <td>' . h(number_format((float)$payment['amount'], 2)) . '</td>
                <td>' . h(date('M d, H:i', strtotime($payment['paid_at']))) . '</td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

// ------------------------------------------------------------------
// Medication History — lets pharmacy staff look up everything a given
// patient has ever been dispensed, not just today's queue. Closes a
// real gap: MedicationHistory::getForPatient() existed but nothing in
// the UI ever called it.
// ------------------------------------------------------------------

if ($action === 'dispensary_margins') {
    requireAnyRole(['pharmacy', 'admin']);
    renderHeader('Dispensary Margins', $_SESSION['staff_role']);
    $from = trim($_GET['from'] ?? date('Y-m-01'));
    $to = trim($_GET['to'] ?? date('Y-m-d 23:59:59'));
    if (strlen($to) === 10) {
        $to .= ' 23:59:59';
    }
    $rows = MedicationHistory::dispensaryMargins($from, $to);
    $rev = array_sum(array_map(fn($r) => (float)$r['revenue'], $rows));
    $cogs = array_sum(array_map(fn($r) => (float)$r['cogs'], $rows));
    $margin = $rev - $cogs;
    echo '<div class="page-title"><h2>Dispensary margin report</h2><p>Revenue vs cost price for dispensed medicines. Set cost price on inventory for accurate margins.</p></div>';
    echo '<div class="card" style="margin-bottom:16px;"><form method="get" class="form-row">';
    echo '<input type="hidden" name="action" value="dispensary_margins">';
    echo '<label>From<br><input type="date" name="from" value="' . h(substr($from, 0, 10)) . '"></label>';
    echo '<label>To<br><input type="date" name="to" value="' . h(substr($to, 0, 10)) . '"></label>';
    echo '<div style="align-self:flex-end;"><button class="btn btn-primary" type="submit">Filter</button></div></form></div>';
    echo '<div class="grid grid-3" style="margin-bottom:16px;">';
    echo '<div class="card"><h3>Revenue</h3><p style="font-size:1.4rem;font-weight:800;">TZS ' . h(number_format($rev, 2)) . '</p></div>';
    echo '<div class="card"><h3>COGS</h3><p style="font-size:1.4rem;font-weight:800;">TZS ' . h(number_format($cogs, 2)) . '</p></div>';
    echo '<div class="card"><h3>Margin</h3><p style="font-size:1.4rem;font-weight:800;color:' . ($margin >= 0 ? '#0f766e' : '#dc2626') . ';">TZS ' . h(number_format($margin, 2)) . '</p></div>';
    echo '</div>';
    echo '<div class="card"><div class="table-responsive"><table><thead><tr><th>Medicine</th><th>Qty</th><th>Sell</th><th>Cost</th><th>Revenue</th><th>COGS</th><th>Margin</th><th>%</th></tr></thead><tbody>';
    if (empty($rows)) {
        echo '<tr><td colspan="8">No dispensations in this period.</td></tr>';
    } else {
        foreach ($rows as $r) {
            echo '<tr><td>' . h($r['medicine'] ?? '-') . '</td><td>' . h($r['qty_dispensed']) . '</td><td>' . h(number_format((float)$r['sell_price'], 2)) . '</td><td>' . h(number_format((float)$r['cost_price'], 2)) . '</td><td>' . h(number_format((float)$r['revenue'], 2)) . '</td><td>' . h(number_format((float)$r['cogs'], 2)) . '</td><td>' . h(number_format((float)$r['margin'], 2)) . '</td><td>' . ($r['margin_pct'] !== null ? h($r['margin_pct']) . '%' : '—') . '</td></tr>';
        }
    }
    echo '</tbody></table></div></div>';
    renderFooter();
    exit;
}

if ($action === 'medication_history') {
    $callerRole = $_SESSION['staff_role'] ?? '';
    if ($callerRole !== 'pharmacy' && $callerRole !== 'admin') {
        setFlash('You do not have access to medication history.', 'error');
        header('Location: ?action=dashboard');
        exit;
    }

    renderHeader('Medication History', $callerRole);

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $searchTerm = trim($_GET['q'] ?? '');
    $selectedPatientId = (int)($_GET['patient_id'] ?? 0);

    echo '<div class="page-title"><h2>Patient Medication History</h2><p>Look up everything a patient has ever been dispensed — not just today\'s queue.</p></div>';

    echo '<div class="card" style="margin-bottom: 20px;">';
    echo '<form method="get" action="">';
    echo '<input type="hidden" name="action" value="medication_history">';
    echo '<div class="form-row">';
    echo '<label>Search by Patient Name or ID<br><input type="text" name="q" value="' . h($searchTerm) . '" placeholder="e.g., PT-00012 or Jane Doe"></label>';
    echo '<div style="align-self:flex-end;"><button type="submit" class="dsms-submit-btn">Search</button></div>';
    echo '</div>';
    echo '</form>';
    echo '</div>';

    if ($searchTerm !== '') {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT id, patient_id AS patient_code, full_name FROM patients
             WHERE patient_id LIKE :term1 OR full_name LIKE :term2
             ORDER BY full_name ASC LIMIT 20"
        );
        $likeTerm = '%' . $searchTerm . '%';
        $stmt->execute([':term1' => $likeTerm, ':term2' => $likeTerm]);
        $matches = $stmt->fetchAll();

        echo '<div class="card" style="margin-bottom: 20px;"><h3>Search Results</h3>';
        if (empty($matches)) {
            echo '<div class="no-data"><p>No patients matched "' . h($searchTerm) . '".</p></div>';
        } else {
            echo '<div class="table-responsive"><table><thead><tr><th>Patient ID</th><th>Name</th><th></th></tr></thead><tbody>';
            foreach ($matches as $m) {
                echo '<tr>
                    <td><strong>' . h($m['patient_code']) . '</strong></td>
                    <td>' . h($m['full_name']) . '</td>
                    <td><a href="?action=medication_history&q=' . urlencode($searchTerm) . '&patient_id=' . h($m['id']) . '" class="btn btn-info btn-small">View History</a></td>
                </tr>';
            }
            echo '</tbody></table></div>';
        }
        echo '</div>';
    }

    if ($selectedPatientId > 0) {
        $patient = Patient::find($selectedPatientId);
        if ($patient) {
            $history = MedicationHistory::getForPatient($selectedPatientId);
            $usage = MedicationHistory::usageSummary($selectedPatientId);

            echo '<div class="dsms-priority-card dsms-priority-info"><h3><span class="dsms-priority-dot"></span>' . h($patient['full_name']) . ' (' . h($patient['patient_id']) . ')</h3>';
            if (!empty($patient['allergies']) || !empty($patient['chronic_conditions']) || !empty($patient['blood_type'])) {
                echo '<p class="dsms-hint" style="margin:8px 0 12px;"><strong>Profile:</strong> '
                    . (!empty($patient['blood_type']) ? 'Blood ' . h($patient['blood_type']) . ' · ' : '')
                    . (!empty($patient['allergies']) ? 'Allergies: ' . h($patient['allergies']) . ' · ' : '')
                    . (!empty($patient['chronic_conditions']) ? 'Chronic: ' . h($patient['chronic_conditions']) : '')
                    . '</p>';
            }
            if (!empty($usage)) {
                echo '<h4 style="margin:12px 0 8px;">Usage overview</h4>';
                echo '<div class="table-responsive"><table><thead><tr><th>Medicine</th><th>Dose / Freq</th><th>Events</th><th>Total qty</th><th>First</th><th>Last</th></tr></thead><tbody>';
                foreach ($usage as $u) {
                    echo '<tr><td>' . h($u['medication']) . '</td><td>' . h(trim(($u['dosage'] ?? '') . ' ' . ($u['frequency'] ?? ''))) . '</td><td>' . h($u['dispense_events']) . '</td><td>' . h($u['total_quantity']) . '</td><td>' . h(date('M d, Y', strtotime($u['first_dispensed']))) . '</td><td>' . h(date('M d, Y', strtotime($u['last_dispensed']))) . '</td></tr>';
                }
                echo '</tbody></table></div>';
            }
            if (empty($history)) {
                echo '<div class="no-data"><p>No medication history recorded for this patient yet.</p></div>';
            } else {
                echo '<h4 style="margin:16px 0 8px;">Dispense log</h4>';
                echo '<div class="table-responsive"><table><thead><tr><th>Medication</th><th>Dosage</th><th>Frequency</th><th>Qty Dispensed</th><th>Dispensed By</th><th>Date</th></tr></thead><tbody>';
                foreach ($history as $h) {
                    echo '<tr>
                        <td>' . h($h['medication'] ?? '-') . '</td>
                        <td>' . h($h['dosage'] ?? '-') . '</td>
                        <td>' . h($h['frequency'] ?? '-') . '</td>
                        <td>' . h($h['quantity']) . '</td>
                        <td>' . h($h['pharmacist_name'] ?? '-') . '</td>
                        <td>' . h(date('M d, Y H:i', strtotime($h['dispensed_at']))) . '</td>
                    </tr>';
                }
                echo '</tbody></table></div>';
                echo '<p class="dsms-hint" style="margin-top:10px;">' . count($history) . ' medicine' . (count($history) === 1 ? '' : 's') . ' dispensed in total.</p>';
            }
            echo '</div>';
        }
    }

    renderFooter();
    exit;
}

if ($action === 'pharmacy_dashboard') {
    requireRole('pharmacy');

    renderHeader('Pharmacy', 'pharmacy');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $payable = Dispensation::getPayableAndPending();       // invoice Paid, not yet dispensed
    $awaitingPayment = Dispensation::getPendingPaymentPrescriptions(); // not paid yet
    $dispensations = Dispensation::all();
    $lowStockMedicines = Medicine::lowStock();
    $expiredMedicines = Medicine::expired();

    echo '<div class="page-title" style="display:flex; align-items:flex-end; justify-content:space-between; flex-wrap:wrap; gap:12px;">
        <div><h2>Pharmacy Dispensing</h2><p>Medicines can only be dispensed once the patient\'s bill is paid (or fully covered by insurance).</p></div>
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="?action=medicine_inventory" class="btn btn-secondary">' . dsms_icon('package', 16) . ' Medicine Inventory</a>
            <a href="?action=medicine_purchase_requests" class="btn btn-secondary">' . dsms_icon('cart', 16) . ' Purchase Requests</a>
            <a href="?action=medication_history" class="btn btn-secondary">' . dsms_icon('book', 16) . ' Patient Medication History</a>
        </div>
    </div>';

    if (!empty($expiredMedicines) || !empty($lowStockMedicines)) {
        echo '<div class="grid grid-2" style="margin-bottom: 4px;">';
        if (!empty($expiredMedicines)) {
            echo '<div class="dsms-priority-card dsms-priority-warning"><h3><span class="dsms-priority-dot">Action</span>Expired Medicines<span class="dsms-priority-chip">' . count($expiredMedicines) . '</span></h3>';
            echo '<ul style="margin:0; padding:12px 18px 16px 34px;">';
            foreach (array_slice($expiredMedicines, 0, 5) as $medicine) {
                echo '<li>' . h($medicine['name']) . ' (' . h($medicine['category_name']) . ') — expired ' . h(date('M d, Y', strtotime($medicine['expiry_date']))) . '</li>';
            }
            echo '</ul>';
            if (count($expiredMedicines) > 5) {
                echo '<p class="dsms-hint">+' . (count($expiredMedicines) - 5) . ' more. See Medicine Inventory for the full list.</p>';
            }
            echo '</div>';
        }
        if (!empty($lowStockMedicines)) {
            echo '<div class="dsms-priority-card dsms-priority-warning"><h3><span class="dsms-priority-dot">Action</span>Low Stock<span class="dsms-priority-chip">' . count($lowStockMedicines) . '</span></h3>';
            echo '<ul style="margin:0; padding:12px 18px 16px 34px;">';
            foreach (array_slice($lowStockMedicines, 0, 5) as $medicine) {
                echo '<li>' . h($medicine['name']) . ' (' . h($medicine['category_name']) . ') — ' . (int)$medicine['quantity'] . ' unit(s) left</li>';
            }
            echo '</ul>';
            if (count($lowStockMedicines) > 5) {
                echo '<p class="dsms-hint">+' . (count($lowStockMedicines) - 5) . ' more. See Medicine Inventory for the full list.</p>';
            }
            echo '</div>';
        }
        echo '</div>';
    }

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('dot', 18) . ' <span>Ready to Dispense (Paid)</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('dot', 28) . '</div><div class="card-stat-text"><h4>Prescriptions</h4><p>' . count($payable) . '</p></div></div></div>';
    echo '<div class="card"><h3>⏳ Awaiting Payment</h3><div class="card-stat"><div class="card-stat-icon">⏳</div><div class="card-stat-text"><h4>Prescriptions</h4><p>' . count($awaitingPayment) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="dsms-priority-card dsms-priority-success" style="margin-top: 24px;">';
    echo '<h3><span class="dsms-priority-dot">Ready</span>Ready to Dispense — Payment Confirmed<span class="dsms-priority-chip">' . count($payable) . '</span></h3>';
    if (empty($payable)) {
        echo '<div class="no-data"><p>No paid prescriptions are waiting to be dispensed right now.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient</th><th>Medication</th><th>Dosage</th><th>Frequency</th><th>Qty</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($payable as $prescription) {
            echo '<tr>
                <td>' . h($prescription['patient_code'] . ' - ' . $prescription['full_name']) . '</td>
                <td>' . h($prescription['medication']) . '</td>
                <td>' . h($prescription['dosage']) . '</td>
                <td>' . h($prescription['frequency']) . '</td>
                <td><strong>' . h((string)max(1, (int)($prescription['quantity'] ?? 1))) . '</strong></td>
                <td><a href="?action=dispense_medication&prescription_id=' . h($prescription['id']) . '" class="btn btn-primary btn-small">Dispense</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="dsms-priority-card dsms-priority-warning" style="margin-top: 20px;">';
    echo '<h3><span class="dsms-priority-dot">Hold</span>Awaiting Payment — Cannot Dispense Yet<span class="dsms-priority-chip">' . count($awaitingPayment) . '</span></h3>';
    if (empty($awaitingPayment)) {
        echo '<div class="no-data"><p>Nothing waiting on payment right now.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient</th><th>Medication</th><th>Dosage</th><th>Frequency</th><th>Qty</th><th>Status</th></tr></thead>
            <tbody>';
        foreach ($awaitingPayment as $prescription) {
            echo '<tr>
                <td>' . h($prescription['patient_code'] . ' - ' . $prescription['full_name']) . '</td>
                <td>' . h($prescription['medication']) . '</td>
                <td>' . h($prescription['dosage']) . '</td>
                <td>' . h($prescription['frequency']) . '</td>
                <td><strong>' . h((string)max(1, (int)($prescription['quantity'] ?? 1))) . '</strong></td>
                <td><span class="status-badge status-pending">Unpaid</span></td>
            </tr>';
        }
        echo '</tbody></table></div>';
        echo '<p class="dsms-hint" style="margin-top: 10px;">These will move to "Ready to Dispense" automatically once Billing records payment on the patient\'s invoice.</p>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 20px;"><h3>Dispensation History</h3>';
    if (empty($dispensations)) {
        echo '<div class="no-data"><p>No dispensed medication records yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Prescription</th><th>Patient</th><th>Qty</th><th>Pharmacist</th><th>Dispensed At</th></tr></thead>
            <tbody>';
        foreach ($dispensations as $dispense) {
            echo '<tr>
                <td>' . h($dispense['medication']) . '</td>
                <td>' . h($dispense['patient_code']) . '</td>
                <td>' . h($dispense['quantity']) . '</td>
                <td>' . h($dispense['staff_name']) . '</td>
                <td>' . h(date('M d, H:i', strtotime($dispense['dispensed_at']))) . '</td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}


if ($action === 'moic_dashboard') {
    requireRole('admin');

    renderHeader('MOIC Dashboard', 'admin');

    // Summary metrics
    $pdo = Database::getConnection();
    $totalPatients = (int)$pdo->query('SELECT COUNT(*) AS cnt FROM patients')->fetch()['cnt'];
    $totalRevenue = (float)$pdo->query('SELECT IFNULL(SUM(amount),0) AS s FROM payments')->fetch()['s'];
    $paymentsByTypeStmt = $pdo->query('SELECT type, IFNULL(SUM(amount),0) AS total FROM payments GROUP BY type');
    $paymentsByType = $paymentsByTypeStmt->fetchAll();
    $budgets = Budget::all();

    echo '<div class="page-title" style="display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap;">';
    echo '<div><h2>MOIC Dashboard</h2><p>High-level operational and financial metrics for oversight.</p></div>';
    echo '<a href="?action=print_moic_report" target="_blank" class="btn btn-primary">' . dsms_icon('print', 16) . ' View / Print Report</a>';
    echo '</div>';
    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('users', 18) . ' <span>Total Patients</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('users', 22) . '</div><div class="card-stat-text"><h4>Registered</h4><p>' . h((string)$totalPatients) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('dollar', 18) . ' <span>Total Revenue (All-Time)</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('dollar', 28) . '</div><div class="card-stat-text"><h4>Collected</h4><p>' . h(number_format($totalRevenue,2)) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="dsms-section-title" style="margin-top: 8px;">' . dsms_icon('chart', 18) . ' Revenue by Type</div>';
    echo '<div class="card">';
    echo '<div class="table-responsive"><table><thead><tr><th>Type</th><th>Total</th></tr></thead><tbody>';
    foreach ($paymentsByType as $row) {
        echo '<tr><td>' . h($row['type']) . '</td><td>' . h(number_format((float)$row['total'],2)) . '</td></tr>';
    }
    echo '</tbody></table></div></div>';

    echo '<div class="dsms-section-title">' . dsms_icon('building', 18) . ' Budgets</div>';
    echo '<div class="card">';
    if (empty($budgets)) {
        echo '<div class="no-data"><p>No budgets configured yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Department</th><th>Allocated</th><th>Spent</th><th>Fiscal Year</th></tr></thead><tbody>';
        foreach ($budgets as $b) {
            echo '<tr><td>' . h($b['department']) . '</td><td>' . h(number_format((float)$b['allocated'],2)) . '</td><td>' . h(number_format((float)$b['spent'],2)) . '</td><td>' . h($b['fiscal_year']) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    // --- Billing widgets ---
    require_once __DIR__ . '/../src/Models/Billing.php';
    $todayRevenue = Billing::revenueBetween(date('Y-m-d 00:00:00'), date('Y-m-d 23:59:59'));
    $outstandingInvoices = Billing::getOutstanding();
    $outstandingTotal = array_sum(array_column($outstandingInvoices, 'balance'));
    $byDept = Billing::revenueByDepartment();
    $byMethod = Billing::revenueByPaymentMethod();

    echo '<div class="dsms-section-title">' . dsms_icon('receipt', 18) . ' Billing Overview</div>';
    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('cash', 18) . ' <span>Today\'s Revenue</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('cash', 28) . '</div><div class="card-stat-text"><p>' . h(number_format($todayRevenue, 2)) . '</p></div></div></div>';
    echo '<div class="card"><h3>⏳ Outstanding Bills</h3><div class="card-stat"><div class="card-stat-icon">⏳</div><div class="card-stat-text"><h4>' . count($outstandingInvoices) . ' invoices</h4><p>' . h(number_format($outstandingTotal, 2)) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('clipboard', 18) . ' <span>Awaiting Billing</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('clipboard', 28) . '</div><div class="card-stat-text"><p>' . count(Billing::getPatientsAwaitingBilling()) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3>Revenue by Department</h3><table><thead><tr><th>Department</th><th>Total</th></tr></thead><tbody>';
    foreach ($byDept as $row) {
        echo '<tr><td>' . h($row['service_type']) . '</td><td>' . h(number_format((float)$row['total'], 2)) . '</td></tr>';
    }
    echo '</tbody></table></div>';

    echo '<div class="card"><h3>Revenue by Payment Method</h3><table><thead><tr><th>Method</th><th>Total</th></tr></thead><tbody>';
    foreach ($byMethod as $row) {
        echo '<tr><td>' . h($row['payment_method']) . '</td><td>' . h(number_format((float)$row['total'], 2)) . '</td></tr>';
    }
    echo '</tbody></table></div>';
    echo '</div>';

    // --- Financial Performance: one facility-wide profit/loss figure,
    // not a per-department scorecard. Patient revenue funds an
    // integrated system — pharmacy, lab, and consultation aren't run
    // as separate businesses, so this is reported as a single result.
    // See src/Models/Budget.php for how "spent" is calculated.
    $budgetTotals = Budget::totals();
    $netResult = $totalRevenue - $budgetTotals['spent'];
    $netColor = $netResult >= 0 ? '#1d4ed8' : '#dc2626';
    $netVerdict = $netResult >= 0 ? 'Net Profit' : 'Net Loss';
    $revenueByDeptMap = [];
    foreach ($byDept as $row) {
        $revenueByDeptMap[$row['service_type']] = (float)$row['total'];
    }
    $pharmacyBudgetTotals = Budget::departmentTotals('pharmacy');
    $labBudgetTotals = Budget::departmentTotals('laboratory');

    echo '<div class="dsms-section-title">' . dsms_icon('trending', 18) . ' Financial Performance</div>';
    echo '<div class="card" style="background:#f8fafc;">';
    echo '<div class="grid grid-3">';
    echo '<div><p style="margin:0;color:#64748b;font-size:13px;">Total Revenue (All-Time)</p><p style="margin:4px 0 0;font-size:22px;font-weight:700;">TZS ' . h(number_format($totalRevenue, 2)) . '</p></div>';
    echo '<div><p style="margin:0;color:#64748b;font-size:13px;">Total Procurement Spend</p><p style="margin:4px 0 0;font-size:22px;font-weight:700;">TZS ' . h(number_format($budgetTotals['spent'], 2)) . '</p></div>';
    echo '<div><p style="margin:0;color:#64748b;font-size:13px;">' . $netVerdict . '</p><p style="margin:4px 0 0;font-size:22px;font-weight:700;color:' . $netColor . ';">TZS ' . h(number_format(abs($netResult), 2)) . '</p></div>';
    echo '</div>';
    echo '<p class="dsms-hint" style="margin:14px 0 0;">Revenue is all-time patient payments collected. Procurement Spend is the real cost of approved pharmacy stock and lab equipment purchases (see Budgets). This is a facility-wide result, not a department comparison.</p>';
    echo '</div>';

    echo '<div class="card" style="margin-top:12px;"><h3 style="font-size:15px;">Revenue vs. Procurement Spend by Service Area <span style="font-weight:400;color:#94a3b8;font-size:12.5px;">(for context only)</span></h3>';
    echo '<table><thead><tr><th>Service Area</th><th>Revenue</th><th>Procurement Spend</th></tr></thead><tbody>';
    echo '<tr><td>Pharmacy</td><td>TZS ' . h(number_format($revenueByDeptMap['Pharmacy'] ?? 0.0, 2)) . '</td><td>TZS ' . h(number_format($pharmacyBudgetTotals['spent'], 2)) . '</td></tr>';
    echo '<tr><td>Laboratory</td><td>TZS ' . h(number_format($revenueByDeptMap['Lab'] ?? 0.0, 2)) . '</td><td>TZS ' . h(number_format($labBudgetTotals['spent'], 2)) . '</td></tr>';
    echo '</tbody></table>';
    echo '<p class="dsms-hint" style="margin:10px 0 0;">Shown for transparency only — patient revenue isn\'t earmarked to the department that generated it, so this isn\'t a per-department profit/loss verdict. The Net Result above is the number that matters.</p>';
    echo '</div>';

    // --- Laboratory statistics ---
    $labPending = (int)$pdo->query(
        "SELECT COUNT(*) AS c FROM lab_requests l LEFT JOIN lab_results r ON r.lab_request_id = l.id WHERE r.id IS NULL"
    )->fetch()['c'];
    $labCompleted = (int)$pdo->query('SELECT COUNT(*) AS c FROM lab_results')->fetch()['c'];
    $topLabTests = $pdo->query(
        'SELECT test_type, COUNT(*) AS c FROM lab_requests GROUP BY test_type ORDER BY c DESC LIMIT 5'
    )->fetchAll();

    echo '<div class="dsms-section-title">' . dsms_icon('lab', 18) . ' Laboratory Overview</div>';
    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('lab', 18) . ' <span>Pending Investigations</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('lab', 28) . '</div><div class="card-stat-text"><p>' . $labPending . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('check', 18) . ' <span>Completed Investigations</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('check', 28) . '</div><div class="card-stat-text"><p>' . $labCompleted . '</p></div></div></div>';
    echo '</div>';
    echo '<div class="card"><h3>Most Requested Lab Tests</h3>';
    if (empty($topLabTests)) {
        echo '<div class="no-data"><p>No lab requests yet.</p></div>';
    } else {
        echo '<table><thead><tr><th>Test</th><th>Requests</th></tr></thead><tbody>';
        foreach ($topLabTests as $t) {
            echo '<tr><td>' . h($t['test_type']) . '</td><td>' . h($t['c']) . '</td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';

    // --- Pharmacy statistics ---
    $pharmacyPending = (int)$pdo->query(
        'SELECT COUNT(*) AS c FROM prescriptions p LEFT JOIN dispensations d ON d.prescription_id = p.id WHERE d.id IS NULL'
    )->fetch()['c'];
    $pharmacyDispensed = (int)$pdo->query('SELECT COUNT(*) AS c FROM dispensations')->fetch()['c'];
    $topMedicines = $pdo->query(
        'SELECT medication, COUNT(*) AS c FROM prescriptions GROUP BY medication ORDER BY c DESC LIMIT 5'
    )->fetchAll();

    echo '<div class="dsms-section-title">' . dsms_icon('pill', 18) . ' Pharmacy Overview</div>';
    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('pill', 18) . ' <span>Pending Prescriptions</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('pill', 28) . '</div><div class="card-stat-text"><p>' . $pharmacyPending . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('package', 18) . ' <span>Medicines Dispensed</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('package', 28) . '</div><div class="card-stat-text"><p>' . $pharmacyDispensed . '</p></div></div></div>';
    echo '</div>';
    echo '<div class="card"><h3>Most Dispensed Medicines</h3>';
    if (empty($topMedicines)) {
        echo '<div class="no-data"><p>No prescriptions yet.</p></div>';
    } else {
        echo '<table><thead><tr><th>Medicine</th><th>Times Prescribed</th></tr></thead><tbody>';
        foreach ($topMedicines as $m) {
            echo '<tr><td>' . h($m['medication']) . '</td><td>' . h($m['c']) . '</td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';

    // --- Payment summary ---
    $paidCount = count(Billing::getPaid());
    $outstandingCount = count($outstandingInvoices);
    echo '<div class="dsms-section-title">' . dsms_icon('card', 18) . ' Payment Summary</div>';
    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('check', 18) . ' <span>Paid Invoices</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('check', 28) . '</div><div class="card-stat-text"><p>' . $paidCount . '</p></div></div></div>';
    echo '<div class="card"><h3>⏳ Unpaid / Partial Invoices</h3><div class="card-stat"><div class="card-stat-icon">⏳</div><div class="card-stat-text"><p>' . $outstandingCount . '</p></div></div></div>';
    echo '</div>';

    renderFooter();
    exit;
}

// ------------------------------------------------------------------
// Printable / viewable MOIC report — a standalone document (no sidebar
// or app chrome) built from the exact same queries as the MOIC
// Dashboard above, so the figures always match what the admin sees
// on screen. Revenue by Department is pulled straight from
// Billing::revenueByDepartment(), same as the dashboard.
// ------------------------------------------------------------------
if ($action === 'print_moic_report') {
    requireRole('admin');

    $pdo = Database::getConnection();
    $totalPatients = (int)$pdo->query('SELECT COUNT(*) AS cnt FROM patients')->fetch()['cnt'];
    $totalRevenue = (float)$pdo->query('SELECT IFNULL(SUM(amount),0) AS s FROM payments')->fetch()['s'];
    $paymentsByType = $pdo->query('SELECT type, IFNULL(SUM(amount),0) AS total FROM payments GROUP BY type')->fetchAll();
    $budgets = Budget::all();

    require_once __DIR__ . '/../src/Models/Billing.php';
    $todayRevenue = Billing::revenueBetween(date('Y-m-d 00:00:00'), date('Y-m-d 23:59:59'));
    $outstandingInvoices = Billing::getOutstanding();
    $outstandingTotal = array_sum(array_column($outstandingInvoices, 'balance'));
    $byDept = Billing::revenueByDepartment();
    $byMethod = Billing::revenueByPaymentMethod();
    $awaitingBilling = count(Billing::getPatientsAwaitingBilling());
    $paidCount = count(Billing::getPaid());

    $budgetTotals = Budget::totals();
    $netResult = $totalRevenue - $budgetTotals['spent'];
    $netColor = $netResult >= 0 ? '#1d4ed8' : '#dc2626';
    $netVerdict = $netResult >= 0 ? 'Net Profit' : 'Net Loss';
    $revenueByDeptMap = [];
    foreach ($byDept as $row) {
        $revenueByDeptMap[$row['service_type']] = (float)$row['total'];
    }
    $pharmacyBudgetTotals = Budget::departmentTotals('pharmacy');
    $labBudgetTotals = Budget::departmentTotals('laboratory');

    $labPending = (int)$pdo->query(
        "SELECT COUNT(*) AS c FROM lab_requests l LEFT JOIN lab_results r ON r.lab_request_id = l.id WHERE r.id IS NULL"
    )->fetch()['c'];
    $labCompleted = (int)$pdo->query('SELECT COUNT(*) AS c FROM lab_results')->fetch()['c'];
    $topLabTests = $pdo->query(
        'SELECT test_type, COUNT(*) AS c FROM lab_requests GROUP BY test_type ORDER BY c DESC LIMIT 5'
    )->fetchAll();

    $pharmacyPending = (int)$pdo->query(
        'SELECT COUNT(*) AS c FROM prescriptions p LEFT JOIN dispensations d ON d.prescription_id = p.id WHERE d.id IS NULL'
    )->fetch()['c'];
    $pharmacyDispensed = (int)$pdo->query('SELECT COUNT(*) AS c FROM dispensations')->fetch()['c'];
    $topMedicines = $pdo->query(
        'SELECT medication, COUNT(*) AS c FROM prescriptions GROUP BY medication ORDER BY c DESC LIMIT 5'
    )->fetchAll();

    $generatedBy = $_SESSION['staff_name'] ?? 'Admin';
    $generatedAt = date('M d, Y H:i');

    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>MOIC Report - DSMS</title>';
    echo '<style>
        * { box-sizing: border-box; }
        body {
            font-family: "Segoe UI", Roboto, Arial, sans-serif;
            margin: 0;
            padding: 32px 16px;
            background: linear-gradient(135deg, #f2f6fe 0%, #dbe7fd 100%);
            color: #0f172a;
            min-height: 100vh;
        }
        .report-card {
            max-width: 860px;
            margin: 0 auto;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 20px 50px rgba(15, 118, 110, 0.14);
            overflow: hidden;
        }
        .report-head {
            background: linear-gradient(135deg, #1d4ed8 0%, #2f6fed 100%);
            color: #fff;
            text-align: center;
            padding: 28px 20px 22px;
        }
        .report-head .logo { font-size: 30px; margin-bottom: 6px; }
        .report-head .hospital-name { font-size: 19px; font-weight: 800; letter-spacing: -0.01em; }
        .report-head .sub { font-size: 12.5px; opacity: 0.9; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.08em; }
        .report-body { padding: 22px 28px 8px; }
        .report-meta { text-align: right; color: #64748b; font-size: 12.5px; margin-bottom: 6px; }
        .report-section-title { font-size: 14px; font-weight: 800; color: #1d4ed8; text-transform: uppercase; letter-spacing: 0.04em; margin: 26px 0 10px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 4px; }
        td, th { padding: 8px 6px; border-bottom: 1px dashed #e2e8f0; font-size: 13.5px; text-align: left; vertical-align: top; }
        th { color: #64748b; font-weight: 700; text-transform: uppercase; font-size: 11px; letter-spacing: 0.03em; }
        td:last-child, th:last-child { text-align: right; }
        .summary-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 4px; }
        .summary-box { background: #f2f6fe; border: 1px solid #dbe7fd; border-radius: 12px; padding: 14px 16px; }
        .summary-box .label { font-size: 11.5px; color: #1d4ed8; font-weight: 700; text-transform: uppercase; letter-spacing: 0.03em; }
        .summary-box .value { font-size: 19px; font-weight: 800; color: #0f172a; margin-top: 4px; }
        .actions { padding: 20px 28px 26px; text-align: center; display: flex; gap: 10px; }
        .actions button, .actions a {
            flex: 1; padding: 11px; border-radius: 10px; border: none; font-weight: 700; font-size: 13.5px;
            cursor: pointer; text-decoration: none; display: inline-block;
        }
        .actions button { background: #1d4ed8; color: #fff; }
        .actions a { background: #f1f5f9; color: #334155; }
        .report-footer { text-align: center; padding: 0 28px 26px; color: #94a3b8; font-size: 11.5px; }
        @media print {
            @page { size: A4; margin: 12mm; }
            body { background: #fff !important; padding: 0 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .report-card { box-shadow: none !important; border-radius: 0 !important; max-width: 100% !important; }
            .report-head { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .actions { display: none !important; }
            .summary-box { break-inside: avoid; }
            table { break-inside: auto; }
            tr { break-inside: avoid; }
        }
    </style></head><body>';

    echo '<div class="report-card">';
    echo '<div class="report-head">';
    echo '<div class="logo">' . dsms_icon('hospital', 28) . '</div>';
    echo '<div class="hospital-name">DSMS Hospital</div>';
    echo '<div class="sub">MOIC Operational &amp; Financial Report</div>';
    echo '</div>';

    echo '<div class="report-body">';
    echo '<div class="report-meta">Generated by ' . h($generatedBy) . ' &middot; ' . h($generatedAt) . '</div>';

    echo '<div class="summary-grid">';
    echo '<div class="summary-box"><div class="label">Total Patients</div><div class="value">' . h((string)$totalPatients) . '</div></div>';
    echo '<div class="summary-box"><div class="label">Total Revenue (All-Time)</div><div class="value">TZS ' . h(number_format($totalRevenue, 2)) . '</div></div>';
    echo '</div>';

    echo '<div class="report-section-title">Revenue by Type</div>';
    echo '<table><thead><tr><th>Type</th><th>Total</th></tr></thead><tbody>';
    if (empty($paymentsByType)) {
        echo '<tr><td colspan="2">No data.</td></tr>';
    } else {
        foreach ($paymentsByType as $row) {
            echo '<tr><td>' . h($row['type']) . '</td><td>TZS ' . h(number_format((float)$row['total'], 2)) . '</td></tr>';
        }
    }
    echo '</tbody></table>';

    echo '<div class="report-section-title">Budgets</div>';
    echo '<table><thead><tr><th>Department</th><th>Allocated</th><th>Spent</th><th>Remaining</th><th>Utilized</th><th>Fiscal Year</th></tr></thead><tbody>';
    if (empty($budgets)) {
        echo '<tr><td colspan="6">No budgets configured yet.</td></tr>';
    } else {
        foreach ($budgets as $b) {
            $allocated = (float)$b['allocated'];
            $spent = (float)$b['spent'];
            $remaining = $allocated - $spent;
            $pct = $allocated > 0 ? round(($spent / $allocated) * 100, 1) : 0.0;
            echo '<tr><td>' . h($b['department']) . '</td><td>TZS ' . h(number_format($allocated, 2)) . '</td><td>TZS ' . h(number_format($spent, 2)) . '</td><td>TZS ' . h(number_format($remaining, 2)) . '</td><td>' . h((string)$pct) . '%</td><td>' . h((string)$b['fiscal_year']) . '</td></tr>';
        }
    }
    echo '</tbody></table>';

    echo '<div class="report-section-title">Billing Overview</div>';
    echo '<div class="summary-grid">';
    echo '<div class="summary-box"><div class="label">Today\'s Revenue</div><div class="value">TZS ' . h(number_format($todayRevenue, 2)) . '</div></div>';
    echo '<div class="summary-box"><div class="label">Outstanding Bills</div><div class="value">' . count($outstandingInvoices) . ' &middot; TZS ' . h(number_format($outstandingTotal, 2)) . '</div></div>';
    echo '<div class="summary-box"><div class="label">Awaiting Billing</div><div class="value">' . $awaitingBilling . '</div></div>';
    echo '<div class="summary-box"><div class="label">Paid Invoices</div><div class="value">' . $paidCount . '</div></div>';
    echo '</div>';

    echo '<div class="report-section-title">Revenue by Department</div>';
    echo '<table><thead><tr><th>Department</th><th>Total</th></tr></thead><tbody>';
    if (empty($byDept)) {
        echo '<tr><td colspan="2">No data.</td></tr>';
    } else {
        foreach ($byDept as $row) {
            echo '<tr><td>' . h($row['service_type']) . '</td><td>TZS ' . h(number_format((float)$row['total'], 2)) . '</td></tr>';
        }
    }
    echo '</tbody></table>';

    echo '<div class="report-section-title">Revenue by Payment Method</div>';
    echo '<table><thead><tr><th>Method</th><th>Total</th></tr></thead><tbody>';
    if (empty($byMethod)) {
        echo '<tr><td colspan="2">No data.</td></tr>';
    } else {
        foreach ($byMethod as $row) {
            echo '<tr><td>' . h($row['payment_method']) . '</td><td>TZS ' . h(number_format((float)$row['total'], 2)) . '</td></tr>';
        }
    }
    echo '</tbody></table>';

    echo '<div class="report-section-title">Financial Performance</div>';
    echo '<div class="summary-grid">';
    echo '<div class="summary-box"><div class="label">Total Revenue</div><div class="value">TZS ' . h(number_format($totalRevenue, 2)) . '</div></div>';
    echo '<div class="summary-box"><div class="label">Total Procurement Spend</div><div class="value">TZS ' . h(number_format($budgetTotals['spent'], 2)) . '</div></div>';
    echo '<div class="summary-box" style="grid-column: span 2;"><div class="label">' . $netVerdict . '</div><div class="value" style="color:' . $netColor . ';">TZS ' . h(number_format(abs($netResult), 2)) . '</div></div>';
    echo '</div>';
    echo '<p style="font-size:12px;color:#94a3b8;margin:8px 0 14px;">This is a facility-wide result, not a per-department comparison — patient revenue funds one integrated system rather than separate department accounts. The breakdown below is shown for context only.</p>';
    echo '<table><thead><tr><th>Service Area</th><th>Revenue</th><th>Procurement Spend</th></tr></thead><tbody>';
    echo '<tr><td>Pharmacy</td><td>TZS ' . h(number_format($revenueByDeptMap['Pharmacy'] ?? 0.0, 2)) . '</td><td>TZS ' . h(number_format($pharmacyBudgetTotals['spent'], 2)) . '</td></tr>';
    echo '<tr><td>Laboratory</td><td>TZS ' . h(number_format($revenueByDeptMap['Lab'] ?? 0.0, 2)) . '</td><td>TZS ' . h(number_format($labBudgetTotals['spent'], 2)) . '</td></tr>';
    echo '</tbody></table>';

    echo '<div class="report-section-title">Laboratory Overview</div>';
    echo '<div class="summary-grid">';
    echo '<div class="summary-box"><div class="label">Pending Investigations</div><div class="value">' . $labPending . '</div></div>';
    echo '<div class="summary-box"><div class="label">Completed Investigations</div><div class="value">' . $labCompleted . '</div></div>';
    echo '</div>';
    echo '<table><thead><tr><th>Test</th><th>Requests</th></tr></thead><tbody>';
    if (empty($topLabTests)) {
        echo '<tr><td colspan="2">No lab requests yet.</td></tr>';
    } else {
        foreach ($topLabTests as $t) {
            echo '<tr><td>' . h($t['test_type']) . '</td><td>' . h($t['c']) . '</td></tr>';
        }
    }
    echo '</tbody></table>';

    echo '<div class="report-section-title">Pharmacy Overview</div>';
    echo '<div class="summary-grid">';
    echo '<div class="summary-box"><div class="label">Pending Prescriptions</div><div class="value">' . $pharmacyPending . '</div></div>';
    echo '<div class="summary-box"><div class="label">Medicines Dispensed</div><div class="value">' . $pharmacyDispensed . '</div></div>';
    echo '</div>';
    echo '<table><thead><tr><th>Medicine</th><th>Times Prescribed</th></tr></thead><tbody>';
    if (empty($topMedicines)) {
        echo '<tr><td colspan="2">No prescriptions yet.</td></tr>';
    } else {
        foreach ($topMedicines as $m) {
            echo '<tr><td>' . h($m['medication']) . '</td><td>' . h($m['c']) . '</td></tr>';
        }
    }
    echo '</tbody></table>';

    echo '</div>'; // .report-body

    echo '<div class="report-footer">DSMS Hospital &middot; Confidential internal report</div>';

    echo '<div class="actions">';
    echo '<button onclick="window.print()">' . dsms_icon('print', 16) . ' Print</button>';
    echo '<a href="?action=moic_dashboard">Back to Dashboard</a>';
    echo '</div>';
    echo '</div>'; // .report-card

    echo '</body></html>';
    exit;
}

if ($action === 'lab_test_catalog') {
    requireRole('admin');

    renderHeader('Lab Test Prices', 'admin');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $tests = LabTestCatalog::all();

    echo '<div class="page-title"><h2>Lab Test Price List</h2><p>These test/price pairs feed the doctor\'s lab request dropdown and the billing invoice items directly — keep them accurate.</p></div>';

    echo '<div class="card"><h3>Add New Test</h3>';
    echo '<form method="post" action="?action=add_lab_test">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<div class="form-row">';
    echo '<label>Test Name<br><input type="text" name="test_name" required></label>';
    echo '<label>Price (TZS)<br><input type="number" step="0.01" min="0" name="price" required></label>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary" style="margin-top: 8px;">Add Test</button>';
    echo '</form>';
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Existing Tests</h3>';
    if (empty($tests)) {
        echo '<div class="no-data"><p>No lab tests configured yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Test Name</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        foreach ($tests as $test) {
            echo '<tr>
                <td>
                    <form method="post" action="?action=update_lab_test" style="display:flex; gap:8px; align-items:center;">
                        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                        <input type="hidden" name="id" value="' . h($test['id']) . '">
                        <input type="text" name="test_name" value="' . h($test['test_name']) . '" style="min-width:220px;">
                </td>
                <td>
                        <input type="number" step="0.01" min="0" name="price" value="' . h($test['price']) . '" style="width:120px;">
                </td>
                <td>' . ($test['is_active'] ? '<span class="status-badge status-accepted">Active</span>' : '<span class="status-badge status-waiting">Inactive</span>') . '</td>
                <td>
                        <button type="submit" class="btn btn-secondary btn-small">Save</button>
                    </form>
                    <form method="post" action="?action=toggle_lab_test" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                        <input type="hidden" name="id" value="' . h($test['id']) . '">
                        <button type="submit" class="btn btn-secondary btn-small">' . ($test['is_active'] ? 'Deactivate' : 'Activate') . '</button>
                    </form>
                </td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'add_lab_test' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('admin');
    $testName = trim($_POST['test_name'] ?? '');
    $price = (float)($_POST['price'] ?? 0);

    try {
        if (!$testName || $price <= 0) {
            throw new \Exception('Test name and a positive price are required.');
        }
        LabTestCatalog::create($testName, $price);
        AuditLog::log((int)$_SESSION['staff_id'], 'lab_test_catalog', null, 'create', "test={$testName} price={$price}");
        setFlash('Lab test added.');
    } catch (\Throwable $e) {
        setFlash('Could not add test: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=lab_test_catalog');
    exit;
}

if ($action === 'update_lab_test' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('admin');
    $id = (int)($_POST['id'] ?? 0);
    $testName = trim($_POST['test_name'] ?? '');
    $price = (float)($_POST['price'] ?? 0);

    try {
        if ($id <= 0 || !$testName || $price <= 0) {
            throw new \Exception('Test name and a positive price are required.');
        }
        LabTestCatalog::update($id, $testName, $price);
        AuditLog::log((int)$_SESSION['staff_id'], 'lab_test_catalog', $id, 'update', "test={$testName} price={$price}");
        setFlash('Lab test updated. Note: this does not change the price of lab requests already created.');
    } catch (\Throwable $e) {
        setFlash('Could not update test: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=lab_test_catalog');
    exit;
}

if ($action === 'toggle_lab_test' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('admin');
    $id = (int)($_POST['id'] ?? 0);

    try {
        $test = LabTestCatalog::find($id);
        if (!$test) {
            throw new \Exception('Test not found.');
        }
        LabTestCatalog::setActive($id, !$test['is_active']);
        AuditLog::log((int)$_SESSION['staff_id'], 'lab_test_catalog', $id, 'toggle_active');
        setFlash('Lab test status updated.');
    } catch (\Throwable $e) {
        setFlash('Could not update status: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=lab_test_catalog');
    exit;
}

// ==================== PHARMACY INVENTORY ====================
// Shared between pharmacy staff (day-to-day stock work) and admin
// (oversight/setup), same access pattern as lab_test_catalog above.

if ($action === 'medicine_inventory') {
    requireAnyRole(['pharmacy', 'admin']);

    renderHeader('Medicine Inventory', ucfirst($_SESSION['staff_role']));

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $categories = MedicineCategory::all();
    $medicines = Medicine::all();
    $lowStockMedicines = Medicine::lowStock();
    $expiredMedicines = Medicine::expired();
    $expiringSoonMedicines = Medicine::expiringSoon();
    $activeCount = count(array_filter($medicines, fn($m) => (int)$m['is_active'] === 1));
    $csrf = h(getCsrfToken());
    $editId = (int)($_GET['edit'] ?? 0);

    // Group medicines by category for cleaner scanning
    $byCategory = [];
    foreach ($medicines as $m) {
        $key = $m['category_name'] ?? 'Uncategorized';
        $byCategory[$key][] = $m;
    }
    ksort($byCategory);

    echo '<div class="page-title" style="display:flex;align-items:flex-end;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div><h2>Medicine Inventory</h2><p>Stock, pricing, and categories — keep the catalog tight and current.</p></div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <a class="btn btn-secondary btn-small" href="#inv-categories">Categories</a>
            <a class="btn btn-primary btn-small" href="#inv-add">+ Add medicine</a>
        </div>
    </div>';

    // Compact KPI strip
    echo '<div class="inv-kpi-row">';
    echo '<div class="inv-kpi"><span class="inv-kpi-ico">' . dsms_icon('package', 18) . '</span><div><strong>' . $activeCount . '</strong><small>Active</small></div></div>';
    echo '<div class="inv-kpi' . (count($lowStockMedicines) ? ' inv-kpi-warn' : '') . '"><span class="inv-kpi-ico">' . dsms_icon('warning', 18) . '</span><div><strong>' . count($lowStockMedicines) . '</strong><small>Low stock</small></div></div>';
    echo '<div class="inv-kpi' . (count($expiredMedicines) ? ' inv-kpi-danger' : '') . '"><span class="inv-kpi-ico">' . dsms_icon('ban', 18) . '</span><div><strong>' . count($expiredMedicines) . '</strong><small>Expired</small></div></div>';
    echo '<div class="inv-kpi"><span class="inv-kpi-ico">' . dsms_icon('clipboard', 18) . '</span><div><strong>' . count($categories) . '</strong><small>Categories</small></div></div>';
    echo '</div>';

    if (!empty($expiringSoonMedicines)) {
        echo '<div class="dsms-priority-card dsms-priority-warning" style="margin-top:14px;">';
        echo '<h3><span class="dsms-priority-dot"></span>Expiring within 60 days</h3><p style="margin:0;font-size:0.88rem;">';
        $bits = [];
        foreach (array_slice($expiringSoonMedicines, 0, 6) as $medicine) {
            $bits[] = h($medicine['name']) . ' <span class="dsms-hint">(' . h(date('M Y', strtotime($medicine['expiry_date']))) . ')</span>';
        }
        echo implode(' · ', $bits);
        if (count($expiringSoonMedicines) > 6) {
            echo ' · +' . (count($expiringSoonMedicines) - 6) . ' more';
        }
        echo '</p></div>';
    }

    // Categories — compact chips + collapsible manager
    echo '<div class="card inv-section" id="inv-categories" style="margin-top:18px;">';
    echo '<div class="inv-section-head"><h3>Treatment categories</h3>';
    echo '<button type="button" class="btn btn-secondary btn-small" onclick="document.getElementById(\'inv-cat-manage\').classList.toggle(\'open\')">Manage</button></div>';
    echo '<div class="inv-chip-row">';
    foreach (MedicineCategory::allWithMedicineCounts() as $category) {
        echo '<span class="inv-chip">' . h($category['name']) . ' <em>' . (int)$category['medicine_count'] . '</em></span>';
    }
    if (empty($categories)) {
        echo '<span class="dsms-hint">No categories yet — add one below.</span>';
    }
    echo '</div>';

    echo '<div id="inv-cat-manage" class="inv-cat-manage">';
    echo '<div class="inv-cat-grid">';
    echo '<form method="post" action="?action=add_medicine_category" class="inv-cat-add">';
    echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
    echo '<strong>New category</strong>';
    echo '<input type="text" name="name" placeholder="Name" required>';
    echo '<input type="text" name="description" placeholder="Description (optional)">';
    echo '<button type="submit" class="btn btn-primary btn-small">Add</button>';
    echo '</form>';
    foreach (MedicineCategory::allWithMedicineCounts() as $category) {
        $cnt = (int)$category['medicine_count'];
        echo '<div class="inv-cat-card">';
        echo '<form method="post" action="?action=update_medicine_category">';
        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
        echo '<input type="hidden" name="id" value="' . h((string)$category['id']) . '">';
        echo '<input type="text" name="name" value="' . h($category['name']) . '" required>';
        echo '<input type="text" name="description" value="' . h($category['description'] ?? '') . '" placeholder="Description">';
        echo '<div class="inv-cat-actions">';
        echo '<button type="submit" class="btn btn-secondary btn-small">Save</button>';
        echo '</div></form>';
        echo '<form method="post" action="?action=delete_medicine_category" onsubmit="return confirm(\'Delete this empty category?\');">';
        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
        echo '<input type="hidden" name="id" value="' . h((string)$category['id']) . '">';
        echo '<button type="submit" class="btn btn-secondary btn-small inv-btn-danger"' . ($cnt > 0 ? ' disabled title="Has medicines"' : '') . '>Delete</button>';
        echo '</form></div>';
    }
    echo '</div></div></div>';

    // Add medicine — compact, collapsed by default via anchor
    echo '<div class="card inv-section" id="inv-add" style="margin-top:16px;">';
    echo '<div class="inv-section-head"><h3>Add medicine</h3></div>';
    if (empty($categories)) {
        echo '<p class="dsms-hint">Create a category first.</p>';
    } else {
        echo '<form method="post" action="?action=add_medicine" class="inv-add-form">';
        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
        echo '<input type="text" name="name" placeholder="Medicine name *" required>';
        echo '<select name="category_id" required><option value="">Category *</option>';
        foreach ($categories as $category) {
            echo '<option value="' . h((string)$category['id']) . '">' . h($category['name']) . '</option>';
        }
        echo '</select>';
        echo '<input type="text" name="dosage_form" placeholder="Dosage / form *" required>';
        echo '<input type="number" step="0.01" min="0" name="unit_price" placeholder="Sell price *" required>';
        echo '<input type="number" step="0.01" min="0" name="cost_price" placeholder="Cost price">';
        echo '<input type="number" min="0" name="quantity" value="0" placeholder="Qty" required>';
        echo '<input type="number" min="0" name="reorder_level" value="10" placeholder="Reorder" required>';
        echo '<input type="date" name="expiry_date" title="Expiry">';
        echo '<button type="submit" class="btn btn-primary btn-small">Save medicine</button>';
        echo '</form>';
    }
    echo '</div>';

    // Catalog — card rows grouped by category
    echo '<div class="inv-section" style="margin-top:20px;">';
    echo '<div class="inv-section-head"><h3>Catalog</h3>';
    echo '<input type="search" id="inv-filter" class="inv-filter" placeholder="Filter medicines…" oninput="dsmsInvFilter(this.value)"></div>';

    if (empty($medicines)) {
        echo '<div class="no-data"><p>No medicines in the catalog yet.</p></div>';
    } else {
        foreach ($byCategory as $catName => $items) {
            echo '<div class="inv-group" data-inv-group>';
            echo '<div class="inv-group-title">' . h($catName) . ' <span>' . count($items) . '</span></div>';
            echo '<div class="inv-card-list">';
            foreach ($items as $medicine) {
                $isExpired = !empty($medicine['expiry_date']) && strtotime($medicine['expiry_date']) < time();
                $isLowStock = (int)$medicine['quantity'] <= (int)$medicine['reorder_level'];
                $isEditing = $editId === (int)$medicine['id'];
                $tags = [];
                if (!(int)$medicine['is_active']) {
                    $tags[] = '<span class="inv-tag inv-tag-muted">Inactive</span>';
                }
                if ($isExpired) {
                    $tags[] = '<span class="inv-tag inv-tag-danger">Expired</span>';
                } elseif ($isLowStock) {
                    $tags[] = '<span class="inv-tag inv-tag-warn">Low stock</span>';
                } elseif ($medicine['status'] === 'Available') {
                    $tags[] = '<span class="inv-tag inv-tag-ok">In stock</span>';
                }

                echo '<div class="inv-med-card' . ($isEditing ? ' is-editing' : '') . '" data-inv-name="' . h(strtolower($medicine['name'] . ' ' . $medicine['dosage_form'] . ' ' . $catName)) . '">';
                echo '<div class="inv-med-main">';
                echo '<div class="inv-med-info">';
                echo '<strong>' . h($medicine['name']) . '</strong>';
                echo '<span class="inv-med-meta">' . h($medicine['dosage_form']) . '</span>';
                echo '<div class="inv-med-tags">' . implode('', $tags) . '</div>';
                echo '</div>';
                echo '<div class="inv-med-stats">';
                echo '<div><small>Qty</small><b>' . (int)$medicine['quantity'] . '</b></div>';
                echo '<div><small>Sell</small><b>' . h(number_format((float)$medicine['unit_price'], 0)) . '</b></div>';
                echo '<div><small>Cost</small><b>' . h(number_format((float)($medicine['cost_price'] ?? 0), 0)) . '</b></div>';
                echo '<div><small>Expiry</small><b>' . ($medicine['expiry_date'] ? h(date('M Y', strtotime($medicine['expiry_date']))) : '—') . '</b></div>';
                echo '</div>';
                echo '<div class="inv-med-actions">';
                echo '<a class="btn btn-secondary btn-small" href="?action=medicine_inventory&edit=' . h((string)$medicine['id']) . '#med-' . h((string)$medicine['id']) . '">Edit</a>';
                echo '<form method="post" action="?action=toggle_medicine_status" style="display:inline;">';
                echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
                echo '<input type="hidden" name="id" value="' . h((string)$medicine['id']) . '">';
                echo '<button type="submit" class="btn btn-secondary btn-small">' . ((int)$medicine['is_active'] ? 'Off' : 'On') . '</button></form>';
                echo '<form method="post" action="?action=delete_medicine" style="display:inline;" onsubmit="return confirm(\'Remove this medicine?\');">';
                echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
                echo '<input type="hidden" name="id" value="' . h((string)$medicine['id']) . '">';
                echo '<button type="submit" class="btn btn-secondary btn-small inv-btn-danger">Del</button></form>';
                echo '</div></div>';

                // Inline editor
                echo '<div class="inv-med-edit" id="med-' . h((string)$medicine['id']) . '"' . ($isEditing ? ' style="display:block"' : '') . '>';
                echo '<form method="post" action="?action=update_medicine" class="inv-edit-form">';
                echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
                echo '<input type="hidden" name="id" value="' . h((string)$medicine['id']) . '">';
                echo '<label>Name<input type="text" name="name" value="' . h($medicine['name']) . '" required></label>';
                echo '<label>Category<select name="category_id" required>';
                foreach ($categories as $category) {
                    $sel = (int)$category['id'] === (int)$medicine['category_id'] ? ' selected' : '';
                    echo '<option value="' . h((string)$category['id']) . '"' . $sel . '>' . h($category['name']) . '</option>';
                }
                echo '</select></label>';
                echo '<label>Form<input type="text" name="dosage_form" value="' . h($medicine['dosage_form']) . '" required></label>';
                echo '<label>Reorder<input type="number" min="0" name="reorder_level" value="' . h((string)$medicine['reorder_level']) . '"></label>';
                echo '<label>Sell<input type="number" step="0.01" min="0" name="unit_price" value="' . h((string)$medicine['unit_price']) . '" required></label>';
                echo '<label>Cost<input type="number" step="0.01" min="0" name="cost_price" value="' . h((string)($medicine['cost_price'] ?? '')) . '"></label>';
                echo '<label>Expiry<input type="date" name="expiry_date" value="' . h($medicine['expiry_date'] ?? '') . '"></label>';
                echo '<div class="inv-edit-actions">';
                echo '<button type="submit" class="btn btn-primary btn-small">Save changes</button>';
                echo '<a class="btn btn-secondary btn-small" href="?action=medicine_inventory">Cancel</a>';
                echo '</div></form>';
                echo '<form method="post" action="?action=adjust_medicine_stock" class="inv-stock-form">';
                echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
                echo '<input type="hidden" name="id" value="' . h((string)$medicine['id']) . '">';
                echo '<label>Adjust stock (±)<input type="number" name="delta" placeholder="e.g. 50 or -5" required></label>';
                echo '<button type="submit" class="btn btn-secondary btn-small">Apply</button>';
                echo '</form></div>';

                echo '</div>'; // card
            }
            echo '</div></div>'; // list + group
        }
    }
    echo '</div>';

    echo '<script>
    function dsmsInvFilter(q){
      q = (q||"").toLowerCase().trim();
      document.querySelectorAll("[data-inv-name]").forEach(function(el){
        el.style.display = !q || el.getAttribute("data-inv-name").indexOf(q) !== -1 ? "" : "none";
      });
      document.querySelectorAll("[data-inv-group]").forEach(function(g){
        var any = Array.prototype.some.call(g.querySelectorAll("[data-inv-name]"), function(c){ return c.style.display !== "none"; });
        g.style.display = any ? "" : "none";
      });
    }
    </script>';

    // Page-scoped styles
    echo '<style>
    .inv-kpi-row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:4px}
    .inv-kpi{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--border,#e2e8f0);border-radius:14px;padding:14px 16px;box-shadow:0 1px 2px rgba(15,23,42,.04)}
    .inv-kpi strong{display:block;font-size:1.35rem;font-weight:800;line-height:1.1;color:#0f172a}
    .inv-kpi small{color:#64748b;font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em}
    .inv-kpi-ico{width:36px;height:36px;border-radius:10px;background:#eef4fa;color:var(--primary,#2563a8);display:flex;align-items:center;justify-content:center;flex-shrink:0}
    .inv-kpi-warn .inv-kpi-ico{background:#fff7ed;color:#c2410c}
    .inv-kpi-danger .inv-kpi-ico{background:#fef2f2;color:#b91c1c}
    .inv-section-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px}
    .inv-section-head h3{margin:0;font-size:1rem;font-weight:700}
    .inv-chip-row{display:flex;flex-wrap:wrap;gap:8px}
    .inv-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:999px;background:#f1f5f9;color:#334155;font-size:.82rem;font-weight:600}
    .inv-chip em{font-style:normal;background:#fff;border-radius:999px;padding:1px 7px;font-size:.72rem;color:#64748b}
    .inv-cat-manage{display:none;margin-top:14px;padding-top:14px;border-top:1px solid var(--border,#e2e8f0)}
    .inv-cat-manage.open{display:block}
    .inv-cat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}
    .inv-cat-add,.inv-cat-card{background:#f8fafc;border:1px solid var(--border,#e2e8f0);border-radius:12px;padding:12px;display:flex;flex-direction:column;gap:8px}
    .inv-cat-add input,.inv-cat-card input{width:100%;padding:8px 10px;border-radius:8px;border:1px solid #e2e8f0;font-size:.85rem}
    .inv-cat-actions{display:flex;gap:6px}
    .inv-add-form{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;align-items:end}
    .inv-add-form input,.inv-add-form select{width:100%;padding:9px 10px;border-radius:8px;border:1px solid #e2e8f0;font-size:.85rem}
    .inv-filter{padding:8px 12px;border-radius:10px;border:1px solid #e2e8f0;min-width:200px;font-size:.85rem}
    .inv-group{margin-bottom:18px}
    .inv-group-title{font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#64748b;margin:0 0 8px;display:flex;align-items:center;gap:8px}
    .inv-group-title span{background:#e2e8f0;border-radius:999px;padding:1px 8px;font-size:.7rem;color:#475569}
    .inv-card-list{display:flex;flex-direction:column;gap:8px}
    .inv-med-card{background:#fff;border:1px solid var(--border,#e2e8f0);border-radius:14px;padding:12px 14px;transition:box-shadow .15s,border-color .15s}
    .inv-med-card.is-editing,.inv-med-card:hover{border-color:#bfdbfe;box-shadow:0 8px 24px rgba(37,99,168,.08)}
    .inv-med-main{display:grid;grid-template-columns:minmax(140px,1.4fr) minmax(200px,1.2fr) auto;gap:12px;align-items:center}
    .inv-med-info strong{display:block;font-size:.95rem;color:#0f172a}
    .inv-med-meta{font-size:.8rem;color:#64748b}
    .inv-med-tags{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px}
    .inv-tag{font-size:.68rem;font-weight:700;padding:2px 8px;border-radius:999px}
    .inv-tag-ok{background:#ecfdf5;color:#047857}
    .inv-tag-warn{background:#fff7ed;color:#c2410c}
    .inv-tag-danger{background:#fef2f2;color:#b91c1c}
    .inv-tag-muted{background:#f1f5f9;color:#64748b}
    .inv-med-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;text-align:center}
    .inv-med-stats small{display:block;font-size:.65rem;text-transform:uppercase;letter-spacing:.04em;color:#94a3b8;font-weight:600}
    .inv-med-stats b{font-size:.9rem;color:#0f172a}
    .inv-med-actions{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}
    .inv-med-edit{display:none;margin-top:12px;padding-top:12px;border-top:1px dashed #e2e8f0}
    .inv-edit-form{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;align-items:end}
    .inv-edit-form label{font-size:.72rem;font-weight:600;color:#64748b;display:flex;flex-direction:column;gap:4px}
    .inv-edit-form input,.inv-edit-form select{padding:8px 10px;border-radius:8px;border:1px solid #e2e8f0;font-size:.85rem;font-weight:500;color:#0f172a}
    .inv-edit-actions{display:flex;gap:8px;align-items:end}
    .inv-stock-form{display:flex;gap:8px;align-items:end;margin-top:10px;flex-wrap:wrap}
    .inv-stock-form label{font-size:.72rem;font-weight:600;color:#64748b;display:flex;flex-direction:column;gap:4px}
    .inv-stock-form input{padding:8px 10px;border-radius:8px;border:1px solid #e2e8f0;width:140px}
    .inv-btn-danger{color:#b91c1c !important}
    @media (max-width:900px){
      .inv-kpi-row{grid-template-columns:repeat(2,1fr)}
      .inv-med-main{grid-template-columns:1fr;gap:10px}
      .inv-med-actions{justify-content:flex-start}
    }
    </style>';

    renderFooter();
    exit;
}


if ($action === 'medicine_purchase_requests') {
    requireAnyRole(['pharmacy', 'admin']);

    renderHeader('Purchase Requests', ucfirst($_SESSION['staff_role']));

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $medicines = Medicine::allActive();
    $myRequests = MedicinePurchaseRequest::getForStaff((int)$_SESSION['staff_id']);
    $pharmacyTotals = Budget::departmentTotals('pharmacy');

    echo '<div class="page-title"><h2>Medicine Purchase Requests</h2><p>Request new stock for a catalog medicine. Admin approval deducts the cost from the pharmacy budget and adds the stock automatically.</p></div>';

    echo '<div class="card" style="background:#f2f6fe;border:1px solid #dbe7fd;margin-bottom:16px;"><p style="margin:0;font-size:13.5px;color:#1d4ed8;">Pharmacy budget remaining: TZS ' . h(number_format($pharmacyTotals['remaining'], 2)) . ' of TZS ' . h(number_format($pharmacyTotals['allocated'], 2)) . ' allocated.</p></div>';

    echo '<div class="card"><h3>Request Stock</h3>';
    if (empty($medicines)) {
        echo '<div class="no-data"><p>Add a medicine to the catalog first (Medicine Inventory), then request stock for it here.</p></div>';
    } else {
        echo '<form method="post" action="?action=submit_medicine_purchase_request">';
        echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
        echo '<div class="form-row">';
        echo '<label>Medicine<br><select name="medicine_id" required><option value="">-- Select --</option>';
        foreach ($medicines as $medicine) {
            echo '<option value="' . h((string)$medicine['id']) . '">' . h($medicine['name']) . ' (' . h($medicine['dosage_form']) . ') — currently ' . (int)$medicine['quantity'] . ' in stock</option>';
        }
        echo '</select></label>';
        echo '<label>Quantity to Order<br><input type="number" min="1" name="quantity" required></label>';
        echo '</div>';
        echo '<div class="form-row">';
        echo '<label>Cost Per Unit (TZS)<br><input type="number" step="0.01" min="0.01" name="unit_cost" required></label>';
        echo '<label>Notes (optional)<br><input type="text" name="notes" placeholder="Supplier, quote reference, etc."></label>';
        echo '</div>';
        echo '<button type="submit" class="btn btn-primary" style="margin-top:8px;">Submit Request</button>';
        echo '</form>';
    }
    echo '</div>';

    echo '<div class="dsms-section-title" style="margin-top: 24px;"><span></span>My Requests</div>';
    if (empty($myRequests)) {
        echo '<div class="no-data"><p>You have not submitted any purchase requests yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Medicine</th><th>Quantity</th><th>Unit Cost</th><th>Total Cost</th><th>Status</th><th>Requested</th></tr></thead><tbody>';
        foreach ($myRequests as $r) {
            $badgeClass = $r['status'] === 'Approved' ? 'status-paid' : ($r['status'] === 'Rejected' ? 'status-warning' : 'status-waiting');
            echo '<tr>';
            echo '<td>' . h($r['medicine_name']) . ' (' . h($r['dosage_form']) . ')</td>';
            echo '<td>' . (int)$r['quantity'] . '</td>';
            echo '<td>TZS ' . h(number_format((float)$r['unit_cost'], 2)) . '</td>';
            echo '<td>TZS ' . h(number_format((float)$r['total_cost'], 2)) . '</td>';
            echo '<td><span class="status-badge ' . $badgeClass . '">' . h($r['status']) . '</span></td>';
            echo '<td>' . h(date('M d, Y', strtotime($r['requested_at']))) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    renderFooter();
    exit;
}

if ($action === 'lab_equipment') {
    requireRole('lab');

    renderHeader('Lab Equipment', ucfirst($_SESSION['staff_role']));

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $equipment = LabEquipment::all();
    $wornEquipment = LabEquipment::needsAttention();
    $labTotals = Budget::departmentTotals('laboratory');

    // Common lab equipment names mapped to a typical category, used to
    // power the dropdowns below so category fills in automatically.
    $commonLabEquipment = [
        'Microscope' => 'Diagnostic',
        'Centrifuge' => 'Diagnostic',
        'Autoclave' => 'Sterilization',
        'Incubator' => 'Diagnostic',
        'Refrigerator' => 'Storage',
        'Freezer' => 'Storage',
        'Hematology Analyzer' => 'Diagnostic',
        'Chemistry Analyzer' => 'Diagnostic',
        'Urine Analyzer' => 'Diagnostic',
        'Spectrophotometer' => 'Diagnostic',
        'Weighing Scale' => 'Diagnostic',
        'pH Meter' => 'Diagnostic',
        'Water Bath' => 'Diagnostic',
        'Vortex Mixer' => 'Diagnostic',
        'Biosafety Cabinet' => 'Safety',
        'Fume Hood' => 'Safety',
        'Fire Extinguisher' => 'Safety',
        'ECG Machine' => 'Diagnostic',
        'Ultrasound Machine' => 'Diagnostic',
        'X-Ray Machine' => 'Diagnostic',
        'Glucometer' => 'Diagnostic',
        'Blood Pressure Monitor' => 'Diagnostic',
        'Sterilizer' => 'Sterilization',
    ];
    $renderEquipmentNameOptions = static function (array $list): string {
        $html = '';
        foreach ($list as $name => $category) {
            $html .= '<option value="' . h($name) . '" data-category="' . h($category) . '">' . h($name) . '</option>';
        }
        return $html;
    };

    echo '<div class="page-title"><h2>Lab Equipment</h2><p>Track equipment condition, and request new or replacement equipment when something is worn out or missing.</p></div>';

    echo '<div class="card" style="background:#f2f6fe;border:1px solid #dbe7fd;margin-bottom:16px;"><p style="margin:0;font-size:13.5px;color:#1d4ed8;">Laboratory budget remaining: TZS ' . h(number_format($labTotals['remaining'], 2)) . ' of TZS ' . h(number_format($labTotals['allocated'], 2)) . ' allocated.</p></div>';

    echo '<div class="dsms-section-title"><span></span>Request Equipment</div>';
    echo '<div class="card">';
    echo '<form method="post" action="?action=submit_lab_equipment_request" id="equipRequestForm">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<div class="form-row">';
    echo '<label>Request Type<br><select name="request_type" id="requestTypeSelect" onchange="document.getElementById(\'replacementField\').style.display = this.value === \'Replacement\' ? \'block\' : \'none\';"><option value="New">New Equipment</option><option value="Replacement">Replacement for Worn/Broken Equipment</option></select></label>';
    echo '<label>Equipment Name<br><select name="equipment_name_select" id="reqEquipNameSelect" required onchange="
        document.getElementById(\'reqEquipOtherField\').style.display = this.value === \'__other__\' ? \'block\' : \'none\';
        document.getElementById(\'reqEquipOtherInput\').required = this.value === \'__other__\';
        if (this.value !== \'__other__\') { document.getElementById(\'reqCategoryInput\').value = this.options[this.selectedIndex].getAttribute(\'data-category\') || \'\'; }
    "><option value="">-- Select --</option>' . $renderEquipmentNameOptions($commonLabEquipment) . '<option value="__other__">+ Other (type below)&hellip;</option></select></label>';
    echo '</div>';
    echo '<div class="form-row full" id="reqEquipOtherField" style="display:none;">';
    echo '<label>Equipment Name (specify)<br><input type="text" id="reqEquipOtherInput" name="equipment_name_other" placeholder="e.g., Refractometer"></label>';
    echo '</div>';
    echo '<div class="form-row" id="replacementField" style="display:none;">';
    if (empty($wornEquipment)) {
        echo '<div class="no-data" style="margin:0;"><p>No equipment is currently flagged as Needs Repair or Worn Out. Flag one below first, then it will show up here.</p></div>';
        echo '<div></div>';
    } else {
        echo '<label>Equipment Being Replaced (Needs Repair / Worn Out only)<br><select name="equipment_id"><option value="">-- Select --</option>';
        foreach ($wornEquipment as $eq) {
            echo '<option value="' . h((string)$eq['id']) . '">' . h($eq['name']) . ' (' . h($eq['status']) . ')</option>';
        }
        echo '</select></label>';
        echo '<div></div>';
    }
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Category<br><input type="text" id="reqCategoryInput" name="category" placeholder="e.g., Diagnostic, Safety"></label>';
    echo '<label>Cost (TZS)<br><input type="number" step="0.01" min="0.01" name="unit_cost" required></label>';
    echo '</div>';
    echo '<div class="form-row full">';
    echo '<label>Notes (optional)<br><input type="text" name="notes" placeholder="Supplier, condition of old unit, etc."></label>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary" style="margin-top:8px;">Submit Request</button>';
    echo '</form>';
    echo '</div>';

    echo '<div class="dsms-section-title" style="margin-top: 24px;"><span></span>Register Existing Equipment</div>';
    echo '<div class="card">';
    echo '<p class="dsms-hint" style="margin-top:0;">For equipment already physically in the lab that was never entered into the system — this doesn\'t touch the budget or need admin approval, it just logs what\'s already here so it can be tracked and flagged.</p>';
    echo '<form method="post" action="?action=register_existing_equipment">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<div class="form-row">';
    echo '<label>Equipment Name<br><select name="name_select" id="regEquipNameSelect" required onchange="
        document.getElementById(\'regEquipOtherField\').style.display = this.value === \'__other__\' ? \'block\' : \'none\';
        document.getElementById(\'regEquipOtherInput\').required = this.value === \'__other__\';
        if (this.value !== \'__other__\') { document.getElementById(\'regCategoryInput\').value = this.options[this.selectedIndex].getAttribute(\'data-category\') || \'\'; }
    "><option value="">-- Select --</option>' . $renderEquipmentNameOptions($commonLabEquipment) . '<option value="__other__">+ Other (type below)&hellip;</option></select></label>';
    echo '<label>Category<br><input type="text" id="regCategoryInput" name="category" placeholder="e.g., Diagnostic, Safety"></label>';
    echo '</div>';
    echo '<div class="form-row full" id="regEquipOtherField" style="display:none;">';
    echo '<label>Equipment Name (specify)<br><input type="text" id="regEquipOtherInput" name="name_other" placeholder="e.g., Refractometer"></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Current Condition<br><select name="status">';
    foreach (['Operational', 'Needs Repair', 'Worn Out'] as $statusOpt) {
        echo '<option value="' . h($statusOpt) . '">' . h($statusOpt) . '</option>';
    }
    echo '</select></label>';
    echo '<label>Notes (optional)<br><input type="text" name="notes" placeholder="Condition detail, location, etc."></label>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary" style="margin-top:8px;">Add to Register</button>';
    echo '</form>';
    echo '</div>';

    echo '<div class="dsms-section-title" style="margin-top: 24px;"><span></span>Flag Equipment Condition</div>';
    $flaggableEquipment = array_values(array_filter($equipment, fn($eq) => $eq['status'] !== 'Retired'));
    if (empty($flaggableEquipment)) {
        echo '<div class="no-data"><p>No equipment to flag yet — add one via "Register Existing Equipment" above, or get a "New Equipment" request approved.</p></div>';
    } else {
        echo '<div class="card">';
        echo '<form method="post" action="?action=flag_lab_equipment_status">';
        echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
        echo '<div class="form-row">';
        echo '<label>Equipment<br><select name="equipment_id" required><option value="">-- Select --</option>';
        foreach ($flaggableEquipment as $eq) {
            echo '<option value="' . h((string)$eq['id']) . '">' . h($eq['name']) . ' (currently ' . h($eq['status']) . ')</option>';
        }
        echo '</select></label>';
        echo '<label>Condition<br><select name="status" required>';
        foreach (['Operational', 'Needs Repair', 'Worn Out'] as $statusOpt) {
            echo '<option value="' . h($statusOpt) . '">' . h($statusOpt) . '</option>';
        }
        echo '</select></label>';
        echo '</div>';
        echo '<div class="form-row full">';
        echo '<label>Notes (optional)<br><input type="text" name="notes" placeholder="e.g., making a grinding noise, cracked casing"></label>';
        echo '</div>';
        echo '<button type="submit" class="btn btn-primary" style="margin-top:8px;">Flag Equipment</button>';
        echo '</form>';
        echo '</div>';
    }

    echo '<div class="dsms-section-title" style="margin-top: 24px;"><span></span>Equipment Register</div>';
    if (empty($equipment)) {
        echo '<div class="no-data"><p>No equipment registered yet — submit a "New Equipment" request above and have it approved to get started.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Name</th><th>Category</th><th>Status</th><th>Purchase Cost</th><th>Purchased</th><th>Update Status</th></tr></thead><tbody>';
        foreach ($equipment as $eq) {
            $badgeClass = $eq['status'] === 'Operational' ? 'status-paid' : ($eq['status'] === 'Retired' ? 'status-registered' : 'status-warning');
            echo '<tr>';
            echo '<td>' . h($eq['name']) . ($eq['condition_notes'] ? '<br><span class="dsms-hint">' . h($eq['condition_notes']) . '</span>' : '') . '</td>';
            echo '<td>' . h($eq['category'] ?? '') . '</td>';
            echo '<td><span class="status-badge ' . $badgeClass . '">' . h($eq['status']) . '</span></td>';
            echo '<td>TZS ' . h(number_format((float)$eq['purchase_cost'], 2)) . '</td>';
            echo '<td>' . h($eq['purchased_at'] ? date('M d, Y', strtotime($eq['purchased_at'])) : '—') . '</td>';
            if ($eq['status'] === 'Retired') {
                echo '<td>—</td>';
            } else {
                echo '<td><form method="post" action="?action=flag_lab_equipment_status" style="display:flex;gap:4px;flex-wrap:wrap;">';
                echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
                echo '<input type="hidden" name="equipment_id" value="' . (int)$eq['id'] . '">';
                echo '<select name="status" style="min-width:120px;">';
                foreach (['Operational', 'Needs Repair', 'Worn Out'] as $statusOpt) {
                    $selected = $eq['status'] === $statusOpt ? ' selected' : '';
                    echo '<option value="' . h($statusOpt) . '"' . $selected . '>' . h($statusOpt) . '</option>';
                }
                echo '</select>';
                echo '<input type="text" name="notes" placeholder="Condition note" style="min-width:130px;">';
                echo '<button type="submit" class="btn btn-secondary" style="padding:6px 10px;font-size:12px;">Update</button>';
                echo '</form></td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    renderFooter();
    exit;
}


if ($action === 'update_medicine_category' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAnyRole(['pharmacy', 'admin']);
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    try {
        if ($id <= 0 || $name === '') {
            throw new RuntimeException('Category name is required.');
        }
        MedicineCategory::update($id, $name, $description ?: null);
        setFlash('Category updated.');
    } catch (Throwable $e) {
        setFlash($e->getMessage(), 'error');
    }
    header('Location: ?action=medicine_inventory');
    exit;
}

if ($action === 'delete_medicine_category' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAnyRole(['pharmacy', 'admin']);
    $id = (int)($_POST['id'] ?? 0);
    try {
        MedicineCategory::delete($id);
        setFlash('Category deleted.');
    } catch (Throwable $e) {
        setFlash($e->getMessage(), 'error');
    }
    header('Location: ?action=medicine_inventory');
    exit;
}

if ($action === 'delete_medicine' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAnyRole(['pharmacy', 'admin']);
    $id = (int)($_POST['id'] ?? 0);
    try {
        try {
            Medicine::delete($id, true);
            setFlash('Medicine removed from catalog.');
        } catch (Throwable $e) {
            Medicine::delete($id, false);
            setFlash('Medicine deactivated (kept for prescription history).');
        }
    } catch (Throwable $e) {
        setFlash($e->getMessage(), 'error');
    }
    header('Location: ?action=medicine_inventory');
    exit;
}

if ($action === 'add_medicine_category' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAnyRole(['pharmacy', 'admin']);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');

    try {
        if (!$name) {
            throw new \Exception('Category name is required.');
        }
        $categoryId = MedicineCategory::create($name, $description ?: null);
        AuditLog::log((int)$_SESSION['staff_id'], 'medicine_categories', $categoryId, 'create', "name={$name}");
        setFlash('Treatment category added.');
    } catch (\Throwable $e) {
        setFlash('Could not add category: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=medicine_inventory');
    exit;
}

if ($action === 'add_medicine' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAnyRole(['pharmacy', 'admin']);
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $dosageForm = trim($_POST['dosage_form'] ?? '');
    $quantity = (int)($_POST['quantity'] ?? 0);
    $reorderLevel = (int)($_POST['reorder_level'] ?? 10);
    $unitPrice = (float)($_POST['unit_price'] ?? 0);
    $costPrice = isset($_POST['cost_price']) && $_POST['cost_price'] !== '' ? (float)$_POST['cost_price'] : null;
    $expiryDate = trim($_POST['expiry_date'] ?? '') ?: null;

    try {
        if ($categoryId <= 0 || !$name || !$dosageForm || $unitPrice <= 0) {
            throw new \Exception('Category, name, dosage/form, and a positive unit price are required.');
        }
        $medicineId = Medicine::create($categoryId, $name, $dosageForm, max(0, $quantity), $unitPrice, $expiryDate, max(0, $reorderLevel), $costPrice);
        AuditLog::log((int)$_SESSION['staff_id'], 'medicines', $medicineId, 'create', "name={$name} qty={$quantity}");
        setFlash('Medicine added to inventory.');
    } catch (\Throwable $e) {
        setFlash('Could not add medicine: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=medicine_inventory');
    exit;
}

if ($action === 'update_medicine' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAnyRole(['pharmacy', 'admin']);
    $id = (int)($_POST['id'] ?? 0);
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $dosageForm = trim($_POST['dosage_form'] ?? '');
    $reorderLevel = (int)($_POST['reorder_level'] ?? 10);
    $unitPrice = (float)($_POST['unit_price'] ?? 0);
    $costPrice = isset($_POST['cost_price']) && $_POST['cost_price'] !== '' ? (float)$_POST['cost_price'] : null;
    $expiryDate = trim($_POST['expiry_date'] ?? '') ?: null;

    try {
        if ($id <= 0 || $categoryId <= 0 || !$name || !$dosageForm || $unitPrice <= 0) {
            throw new \Exception('Category, name, dosage/form, and a positive unit price are required.');
        }
        Medicine::update($id, $categoryId, $name, $dosageForm, $unitPrice, $expiryDate, max(0, $reorderLevel), $costPrice);
        AuditLog::log((int)$_SESSION['staff_id'], 'medicines', $id, 'update', "name={$name}");
        setFlash('Medicine updated.');
    } catch (\Throwable $e) {
        setFlash('Could not update medicine: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=medicine_inventory');
    exit;
}

if ($action === 'adjust_medicine_stock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAnyRole(['pharmacy', 'admin']);
    $id = (int)($_POST['id'] ?? 0);
    $delta = (int)($_POST['delta'] ?? 0);

    try {
        if ($id <= 0 || $delta === 0) {
            throw new \Exception('Enter a non-zero quantity to adjust (e.g. 50 for a delivery, -5 for a correction).');
        }
        Medicine::adjustStock($id, $delta);
        AuditLog::log((int)$_SESSION['staff_id'], 'medicines', $id, 'adjust_stock', "delta={$delta}");
        setFlash('Stock adjusted.');
    } catch (\Throwable $e) {
        setFlash('Could not adjust stock: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=medicine_inventory');
    exit;
}

if ($action === 'toggle_medicine_status' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAnyRole(['pharmacy', 'admin']);
    $id = (int)($_POST['id'] ?? 0);

    try {
        $medicine = Medicine::find($id);
        if (!$medicine) {
            throw new \Exception('Medicine not found.');
        }
        Medicine::setActive($id, !$medicine['is_active']);
        AuditLog::log((int)$_SESSION['staff_id'], 'medicines', $id, 'toggle_active');
        setFlash('Medicine status updated.');
    } catch (\Throwable $e) {
        setFlash('Could not update status: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=medicine_inventory');
    exit;
}

if ($action === 'budget_dashboard') {
    requireRole('admin');

    // Focus view: Pharmacy vs Laboratory allocations & spend
    $budgets = Budget::all();
    $overall = Budget::totals();
    $pharmacyTotals = Budget::departmentTotals('pharmacy');
    $labTotals = Budget::departmentTotals('laboratory');

    $utilizationPct = static function (array $t): float {
        return $t['allocated'] > 0 ? min(100, round(($t['spent'] / $t['allocated']) * 100, 1)) : 0.0;
    };
    $barColor = static function (float $pct): string {
        if ($pct >= 90) return '#dc2626';
        if ($pct >= 70) return '#d97706';
        return '#1d4ed8';
    };
    $renderUtilBar = static function (array $t) use ($utilizationPct, $barColor): string {
        $pct = $utilizationPct($t);
        $color = $barColor($pct);
        return '<div style="background:#e2e8f0;border-radius:8px;height:10px;overflow:hidden;margin-top:8px;">'
            . '<div style="width:' . $pct . '%;background:' . $color . ';height:100%;"></div></div>'
            . '<div style="font-size:12px;color:#64748b;margin-top:4px;">' . $pct . '% utilized &middot; Remaining TZS ' . h(number_format($t['remaining'], 2)) . '</div>';
    };

    renderHeader('Budget Management', 'admin');
    echo '<div class="page-title"><h2>Budget Management</h2><p>Pharmacy and Laboratory budget totals, utilization, and procurement spend — plus overall allocations.</p></div>';
    echo '<div class="card" style="background:#f2f6fe;border:1px solid #dbe7fd;margin-bottom:16px;"><p style="margin:0;font-size:13.5px;color:#1d4ed8;">Each department funds its own restocking — there is no central procurement department. "Spent" is the real cost of approved purchases (medicine stock, lab equipment), not the value of what was sold or billed.</p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3> Total Allocated</h3><div class="card-stat"><div class="card-stat-text"><h4>All Departments</h4><p>TZS ' . h(number_format($overall['allocated'], 2)) . '</p></div></div></div>';
    echo '<div class="card"><h3> Total Spent</h3><div class="card-stat"><div class="card-stat-text"><h4>All Departments</h4><p>TZS ' . h(number_format($overall['spent'], 2)) . '</p></div></div></div>';
    echo '<div class="card"><h3> Total Remaining</h3><div class="card-stat"><div class="card-stat-text"><h4>All Departments</h4><p>TZS ' . h(number_format($overall['remaining'], 2)) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="grid grid-2" style="margin-top:16px;">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('pill', 18) . ' <span>Pharmacy Budget</span></h3>';
    echo '<p style="margin:4px 0;">Allocated: TZS ' . h(number_format($pharmacyTotals['allocated'], 2)) . ' &middot; Spent: TZS ' . h(number_format($pharmacyTotals['spent'], 2)) . '</p>';
    echo $renderUtilBar($pharmacyTotals);
    if ($pharmacyTotals['allocated'] <= 0) {
        echo '<p class="no-data" style="margin-top:8px;">No pharmacy budget configured yet — create one below with department "pharmacy".</p>';
    }
    echo '</div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('lab', 18) . ' <span>Laboratory Budget</span></h3>';
    echo '<p style="margin:4px 0;">Allocated: TZS ' . h(number_format($labTotals['allocated'], 2)) . ' &middot; Spent: TZS ' . h(number_format($labTotals['spent'], 2)) . '</p>';
    echo $renderUtilBar($labTotals);
    if ($labTotals['allocated'] <= 0) {
        echo '<p class="no-data" style="margin-top:8px;">No laboratory budget configured yet — create one below with department "laboratory".</p>';
    }
    echo '</div>';
    echo '</div>';

    echo '<p class="dsms-hint" style="margin: 12px 0 0;">Looking for profit/loss? That\'s a facility-wide figure now, on the <a href="?action=moic_dashboard">MOIC Dashboard</a> — revenue and spend aren\'t cleanly separable by department in one integrated system, so it\'s reported as one number rather than a per-department scorecard.</p>';

    echo '<div class="grid grid-2" style="margin-top:16px;">';
    echo '<div class="card"><h3>Create New Budget</h3>';
    echo '<form method="post" action="?action=save_budget">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<div class="form-row">';
    echo '<label>Department<br><select name="department_select" onchange="document.getElementById(\'newDeptField\').style.display = this.value === \'__other__\' ? \'block\' : \'none\'; document.getElementById(\'newDeptInput\').required = this.value === \'__other__\';">';
    $existingDepartments = Budget::distinctDepartments();
    if (empty($existingDepartments)) {
        $existingDepartments = ['pharmacy', 'laboratory'];
    }
    foreach ($existingDepartments as $dept) {
        echo '<option value="' . h($dept) . '">' . h(ucfirst($dept)) . '</option>';
    }
    echo '<option value="__other__">+ New department&hellip;</option>';
    echo '</select></label>';
    echo '<label>Allocated Amount<br><input type="number" step="0.01" name="allocated" required></label>';
    echo '</div>';
    echo '<div class="form-row" id="newDeptField" style="display:none;">';
    echo '<label>New Department Name<br><input type="text" id="newDeptInput" name="department_new" placeholder="e.g. radiology"></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Fiscal Year<br><input type="text" name="fiscal_year" placeholder="' . h(date('Y')) . '"></label>';
    echo '</div>';
    echo '<button type="submit" class="dsms-submit-btn">Create Budget</button>';
    echo '</form>';
    echo '</div>';

    echo '<div class="card"><h3>Current Budgets</h3>';
    if (empty($budgets)) {
        echo '<div class="no-data"><p>No budgets configured yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Department</th><th>Allocated</th><th>Spent</th><th>Remaining</th><th>Fiscal Year</th><th>Adjust</th><th></th></tr></thead><tbody>';
        foreach ($budgets as $budget) {
            $remaining = (float)$budget['allocated'] - (float)$budget['spent'];
            echo '<tr>';
            echo '<td>' . h($budget['department']) . '</td>';
            echo '<td>' . h(number_format((float)$budget['allocated'], 2)) . '</td>';
            echo '<td>' . h(number_format((float)$budget['spent'], 2)) . '</td>';
            echo '<td>' . h(number_format($remaining, 2)) . '</td>';
            echo '<td>' . h((string)$budget['fiscal_year']) . '</td>';
            echo '<td><form method="post" action="?action=update_budget_allocation" style="display:flex;gap:4px;">';
            echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
            echo '<input type="hidden" name="budget_id" value="' . (int)$budget['id'] . '">';
            echo '<input type="number" step="0.01" name="allocated" value="' . h((string)$budget['allocated']) . '" style="width:110px;" required>';
            echo '<button type="submit" class="btn btn-secondary" style="padding:6px 10px;font-size:12px;">Update</button>';
            echo '</form></td>';
            echo '<td><form method="post" action="?action=delete_budget" onsubmit="return confirm(\'Delete the ' . h(addslashes($budget['department'])) . ' budget for ' . h(addslashes((string)$budget['fiscal_year'])) . '? This cannot be undone.\');">';
            echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
            echo '<input type="hidden" name="budget_id" value="' . (int)$budget['id'] . '">';
            echo '<button type="submit" class="btn btn-danger" style="padding:6px 10px;font-size:12px;">Delete</button>';
            echo '</form></td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'purchase_approvals') {
    requireRole('admin');

    renderHeader('Purchase Approvals', 'admin');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $pendingMedicine = MedicinePurchaseRequest::getPending();
    $pendingEquipment = LabEquipmentRequest::getPending();
    $allMedicineRequests = MedicinePurchaseRequest::getAll();
    $allEquipmentRequests = LabEquipmentRequest::getAll();

    echo '<div class="page-title"><h2>Purchase Approvals</h2><p>Review pharmacy stock requests and lab equipment requests. Approving deducts the cost from that department\'s budget and updates inventory/equipment automatically.</p></div>';

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3>⏳ Pending Medicine Purchases</h3><div class="card-stat"><div class="card-stat-text"><h4>Awaiting Decision</h4><p>' . count($pendingMedicine) . '</p></div></div></div>';
    echo '<div class="card"><h3>⏳ Pending Equipment Requests</h3><div class="card-stat"><div class="card-stat-text"><h4>Awaiting Decision</h4><p>' . count($pendingEquipment) . '</p></div></div></div>';
    echo '</div>';

    $renderDecisionForms = static function (string $approveAction, string $rejectAction, int $requestId): string {
        $csrf = h(getCsrfToken());
        return '<div style="display:flex;gap:6px;flex-wrap:wrap;">'
            . '<form method="post" action="?action=' . $approveAction . '" onsubmit="return confirm(\'Approve this request? This deducts the budget and updates stock/equipment immediately.\');">'
            . '<input type="hidden" name="csrf_token" value="' . $csrf . '">'
            . '<input type="hidden" name="request_id" value="' . $requestId . '">'
            . '<button type="submit" class="btn btn-primary" style="padding:6px 10px;font-size:12px;">Approve</button>'
            . '</form>'
            . '<form method="post" action="?action=' . $rejectAction . '" onsubmit="return confirm(\'Reject this request?\');" style="display:flex;gap:4px;">'
            . '<input type="hidden" name="csrf_token" value="' . $csrf . '">'
            . '<input type="hidden" name="request_id" value="' . $requestId . '">'
            . '<input type="text" name="decision_note" placeholder="Reason (optional)" style="width:120px;">'
            . '<button type="submit" class="btn btn-danger" style="padding:6px 10px;font-size:12px;">Reject</button>'
            . '</form>'
            . '</div>';
    };

    // --- Medicine purchase requests ---
    echo '<div class="dsms-section-title" style="margin-top: 24px;"><span></span>Medicine Purchase Requests</div>';
    if (empty($allMedicineRequests)) {
        echo '<div class="no-data"><p>No medicine purchase requests yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Medicine</th><th>Qty</th><th>Unit Cost</th><th>Total Cost</th><th>Requested By</th><th>Status</th><th>Action</th></tr></thead><tbody>';
        foreach ($allMedicineRequests as $r) {
            $badgeClass = $r['status'] === 'Approved' ? 'status-paid' : ($r['status'] === 'Rejected' ? 'status-warning' : 'status-waiting');
            echo '<tr>';
            echo '<td>' . h($r['medicine_name']) . ' (' . h($r['dosage_form']) . ')</td>';
            echo '<td>' . (int)$r['quantity'] . '</td>';
            echo '<td>TZS ' . h(number_format((float)$r['unit_cost'], 2)) . '</td>';
            echo '<td>TZS ' . h(number_format((float)$r['total_cost'], 2)) . '</td>';
            echo '<td>' . h($r['requested_by_name']) . '</td>';
            echo '<td><span class="status-badge ' . $badgeClass . '">' . h($r['status']) . '</span></td>';
            echo '<td>' . ($r['status'] === 'Pending' ? $renderDecisionForms('approve_medicine_purchase', 'reject_medicine_purchase', (int)$r['id']) : ($r['decided_by_name'] ? 'by ' . h($r['decided_by_name']) : '—')) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    // --- Lab equipment requests ---
    echo '<div class="dsms-section-title" style="margin-top: 24px;"><span></span>Lab Equipment Requests</div>';
    if (empty($allEquipmentRequests)) {
        echo '<div class="no-data"><p>No lab equipment requests yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Type</th><th>Equipment</th><th>Cost</th><th>Requested By</th><th>Status</th><th>Action</th></tr></thead><tbody>';
        foreach ($allEquipmentRequests as $r) {
            $badgeClass = $r['status'] === 'Approved' ? 'status-paid' : ($r['status'] === 'Rejected' ? 'status-warning' : 'status-waiting');
            echo '<tr>';
            echo '<td>' . h($r['request_type']) . '</td>';
            echo '<td>' . h($r['equipment_name']) . ($r['category'] ? ' <span class="dsms-hint">(' . h($r['category']) . ')</span>' : '') . '</td>';
            echo '<td>TZS ' . h(number_format((float)$r['unit_cost'], 2)) . '</td>';
            echo '<td>' . h($r['requested_by_name']) . '</td>';
            echo '<td><span class="status-badge ' . $badgeClass . '">' . h($r['status']) . '</span></td>';
            echo '<td>' . ($r['status'] === 'Pending' ? $renderDecisionForms('approve_lab_equipment', 'reject_lab_equipment', (int)$r['id']) : ($r['decided_by_name'] ? 'by ' . h($r['decided_by_name']) : '—')) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    renderFooter();
    exit;
}

if ($action === 'dispense_for_patient') {
    requireRole('pharmacy');
    // Obsolete: dispensing is now gated per-prescription via
    // Billing::isPrescriptionPayable(), not per-patient payment status.
    // Use the Pharmacy dashboard's "Ready to Dispense" list instead.
    setFlash('Use the Pharmacy dashboard to dispense — prescriptions unlock individually once their invoice is paid.');
    header('Location: ?action=pharmacy_dashboard');
    exit;
}

if ($action === 'dispense_medication') {
    requireRole('pharmacy');

    $prescriptionId = (int)($_GET['prescription_id'] ?? 0);
    $prescription = Prescription::find($prescriptionId);

    if (!$prescription) {
        setFlash('Prescription not found.', 'error');
        header('Location: ?action=pharmacy_dashboard');
        exit;
    }

    renderHeader('Dispense Medication', 'pharmacy');

    $linkedMedicine = !empty($prescription['medicine_id']) ? Medicine::find((int)$prescription['medicine_id']) : null;

    $prescribedQty = max(1, (int)($prescription['quantity'] ?? 1));

    echo '<div class="page-title"><h2>Dispense Medication</h2><p>Dispense the exact quantity prescribed by the doctor.</p></div>';
    echo '<div class="card" style="max-width: 680px;">
        <form method="post" action="?action=record_dispense">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="prescription_id" value="' . h($prescription['id']) . '">
            <input type="hidden" name="quantity" value="' . h((string)$prescribedQty) . '">
            <p><strong>Patient:</strong> ' . h($prescription['patient_code'] . ' - ' . $prescription['full_name']) . '</p>
            <p><strong>Medication:</strong> ' . h($prescription['medication']) . '</p>
            <p><strong>Dosage:</strong> ' . h($prescription['dosage']) . '</p>
            <p><strong>Frequency:</strong> ' . h($prescription['frequency']) . '</p>';

    if (!empty($prescription['duration'])) {
        echo '<p><strong>Duration:</strong> ' . h($prescription['duration']) . '</p>';
    }
    if (!empty($prescription['instructions'])) {
        echo '<p><strong>Instructions:</strong> ' . h($prescription['instructions']) . '</p>';
    }

    if ($linkedMedicine) {
        $stockBadgeClass = (int)$linkedMedicine['quantity'] > 0 ? 'status-paid' : 'status-warning';
        echo '<p><strong>Inventory Stock:</strong> <span class="status-badge ' . $stockBadgeClass . '">' . (int)$linkedMedicine['quantity'] . ' unit(s) available</span></p>';
        if ((int)$linkedMedicine['quantity'] < $prescribedQty) {
            echo '<p class="dsms-hint" style="color:var(--danger);"> Stock is below the prescribed quantity (' . $prescribedQty . '). Restock before dispensing.</p>';
        } elseif ((int)$linkedMedicine['quantity'] <= (int)$linkedMedicine['reorder_level']) {
            echo '<p class="dsms-hint"> This medicine is at or below its reorder level.</p>';
        }
    } else {
        echo '<p class="dsms-hint">This prescription isn\'t linked to a catalog medicine, so stock won\'t be tracked for this dispense.</p>';
    }

    echo '
            <div class="form-row full">
                <label>Quantity to dispense (prescribed by doctor)</label>
                <div class="dsms-qty-locked">
                    <strong>' . h((string)$prescribedQty) . '</strong>
                    <span class="status-badge status-info">Prescribed</span>
                    <p class="dsms-hint">Locked to the doctor\'s order — pharmacy dispenses this exact amount.</p>
                </div>
            </div>
            <div class="form-row full">
                <label>Notes (optional)<br><textarea name="note" rows="2" placeholder="e.g. counselled patient on with-food dosing"></textarea></label>
            </div>
            <button type="submit" class="btn btn-primary">Record Dispense</button>
            <a href="?action=pharmacy_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>
        </form>
    </div>';

    renderFooter();
    exit;
}

if ($action === 'collect_medicine_payment') {
    requireRole('billing');
    setFlash('Medicine charges are now billed centrally through the Billing Center, not collected separately.');
    header('Location: ?action=billing_center');
    exit;
}

if ($action === 'collect_payment') {
    requireRole('billing');
    setFlash('Consultation fees are now billed centrally through the Billing Center after treatment, not collected up front.');
    header('Location: ?action=billing_center');
    exit;
}

if ($action === 'lab_dashboard') {
    requireRole('lab');

    renderHeader('Lab Services', 'lab');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $pendingPayments = LabRequest::getPendingPayment(); // legacy rows only, see note below
    $pendingInvestigations = LabRequest::getPendingInvestigation();
    $completedToday = array_filter(LabRequest::getCompleted(), function ($r) {
        return substr($r['created_at'], 0, 10) === date('Y-m-d');
    });

    echo '<div class="page-title" style="display:flex; align-items:flex-end; justify-content:space-between; flex-wrap:wrap; gap:12px;">
        <div><h2>Lab Workflow</h2><p>Perform requested investigations and record results. Payment is handled centrally by Billing, not per test.</p></div>
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="?action=lab_equipment" class="btn btn-secondary"> Equipment</a>
        </div>
    </div>';

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('lab', 18) . ' <span>Pending Investigations</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('lab', 28) . '</div><div class="card-stat-text"><h4>Ready</h4><p>' . count($pendingInvestigations) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('check', 18) . ' <span>Completed Today</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('check', 28) . '</div><div class="card-stat-text"><h4>Results</h4><p>' . count($completedToday) . '</p></div></div></div>';
    echo '</div>';

    if (!empty($pendingPayments)) {
        echo '<div class="dsms-priority-card dsms-priority-warning" style="margin-top: 24px;">';
        echo '<h3><span class="dsms-priority-dot">Action</span>Legacy Requests Awaiting Old Payment Step<span class="dsms-priority-chip">' . count($pendingPayments) . '</span></h3>';
        echo '<p class="dsms-hint">These predate centralized billing. Use "Collect Payment" once to move them into the normal investigation queue.</p>';
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient</th><th>Test Type</th><th>Bill</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($pendingPayments as $request) {
            echo '<tr>
                <td>' . h($request['patient_code'] . ' - ' . $request['full_name']) . '</td>
                <td>' . h($request['test_type']) . '</td>
                <td>' . h(number_format((float)$request['bill'], 2)) . '</td>
                <td><span class="status-badge status-waiting">' . h($request['status']) . '</span></td>
                <td><a href="?action=lab_collect_payment&lab_request_id=' . h($request['id']) . '" class="btn btn-primary btn-small">Collect Payment</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
        echo '</div>';
    }

    echo '<div class="dsms-priority-card dsms-priority-info" style="margin-top: 20px;">';
    echo '<h3><span class="dsms-priority-dot">Review</span>Requests Ready for Investigation<span class="dsms-priority-chip">' . count($pendingInvestigations) . '</span></h3>';
    if (empty($pendingInvestigations)) {
        echo '<div class="no-data"><p>No lab requests are awaiting results.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient</th><th>Test Type</th><th>Bill</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($pendingInvestigations as $request) {
            echo '<tr>
                <td>' . h($request['patient_code'] . ' - ' . $request['full_name']) . '</td>
                <td>' . h($request['test_type']) . '</td>
                <td>' . h(number_format((float)$request['bill'], 2)) . '</td>
                <td><span class="status-badge status-accepted">' . h($request['status']) . '</span></td>
                <td><a href="?action=lab_upload_result&lab_request_id=' . h($request['id']) . '" class="btn btn-primary btn-small">Upload Result</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'lab_collect_payment') {
    requireRole('lab');

    $labRequestId = (int)($_GET['lab_request_id'] ?? 0);
    $labRequest = LabRequest::find($labRequestId);

    if (!$labRequest || $labRequest['status'] !== 'Pending Payment') {
        setFlash('Selected lab request is not available for payment.', 'error');
        header('Location: ?action=lab_dashboard');
        exit;
    }

    $consultation = Consultation::find((int)$labRequest['consultation_id']);
    $patient = $consultation ? Patient::find((int)$consultation['patient_id']) : null;

    renderHeader('Lab Payment', 'lab');

    echo '<div class="page-title"><h2>Collect Lab Payment</h2><p>Complete payment for the selected lab request.</p></div>';
    echo '<div class="card" style="max-width: 680px;">
        <form method="post" action="?action=record_lab_payment">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="lab_request_id" value="' . h($labRequestId) . '">
            <p><strong>Patient:</strong> ' . h($patient ? $patient['patient_id'] . ' - ' . $patient['full_name'] : 'Unknown') . '</p>
            <p><strong>Test Type:</strong> ' . h($labRequest['test_type']) . '</p>
            <p><strong>Amount Due:</strong> ' . h(number_format((float)$labRequest['bill'], 2)) . '</p>
            <div class="form-row">
                <label>Payment Amount<br><input type="number" step="0.01" name="amount" required value="' . h(number_format((float)$labRequest['bill'], 2)) . '"></label>
            </div>
            <button type="submit" class="btn btn-primary">Record Lab Payment</button>
            <a href="?action=lab_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>
        </form>
    </div>';

    renderFooter();
    exit;
}

if ($action === 'lab_upload_result') {
    requireRole('lab');

    $labRequestId = (int)($_GET['lab_request_id'] ?? 0);
    $labRequest = LabRequest::find($labRequestId);

    if (!$labRequest || !in_array($labRequest['status'], ['Pending Investigation', 'Paid'], true)) {
        setFlash('Selected lab request is not ready for result upload.', 'error');
        header('Location: ?action=lab_dashboard');
        exit;
    }

    $consultation = Consultation::find((int)$labRequest['consultation_id']);
    $patient = $consultation ? Patient::find((int)$consultation['patient_id']) : null;

    renderHeader('Upload Lab Result', 'lab');

    echo '<div class="page-title"><h2>Upload Lab Result</h2><p>Provide the test findings and any comments.</p></div>';
    echo '<div class="card" style="max-width: 680px;">
        <form method="post" action="?action=upload_lab_result">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="lab_request_id" value="' . h($labRequestId) . '">
            <p><strong>Patient:</strong> ' . h($patient ? $patient['patient_id'] . ' - ' . $patient['full_name'] : 'Unknown') . '</p>
            <p><strong>Test Type:</strong> ' . h($labRequest['test_type']) . '</p>
            <div class="form-row">
                <label>Result value<br><input type="text" name="result_value" placeholder="e.g. 5.2 or Positive"></label>
                <label>Unit<br><input type="text" name="result_unit" placeholder="e.g. mmol/L, g/dL"></label>
            </div>
            <div class="form-row">
                <label>Reference range<br><input type="text" name="reference_range" placeholder="e.g. 3.5-5.5"></label>
                <label>Flag<br><select name="result_flag"><option value="">Auto / none</option><option>Normal</option><option>Low</option><option>High</option><option>Abnormal</option><option>Positive</option><option>Negative</option></select></label>
            </div>
            <div class="form-row full">
                <label>Narrative result (optional if value filled)<br><textarea name="result" rows="3" placeholder="Full result text"></textarea></label>
            </div>
            <div class="form-row full">
                <label>Comments<br><textarea name="comments" rows="2"></textarea></label>
            </div>
            <button type="submit" class="btn btn-primary">Upload Result</button>
            <a href="?action=lab_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>
        </form>
    </div>';

    renderFooter();
    exit;
}

// ADMIN EDIT STAFF PAGE
if ($action === 'edit_staff') {
    requireRole('admin');

    $staffId = (int)($_GET['id'] ?? 0);
    $staff = Staff::getById($staffId);

    if (!$staff) {
        setFlash('Staff member not found.', 'error');
        header('Location: ?action=admin_dashboard');
        exit;
    }

    renderHeader('Edit Staff Member', 'admin');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Edit Team Member</h2><p>Update account details, role and access status for hospital staff.</p></div>';

    $knownSpecializations = ['General Physician', 'Dentist', 'Pediatrician', 'Gynecologist/Obstetrician', 'General Surgeon', 'Orthopedic Surgeon', 'Cardiologist', 'Dermatologist', 'Ophthalmologist', 'ENT Specialist', 'Psychiatrist', 'Radiologist', 'Anesthesiologist', 'Internal Medicine', 'Urologist', 'Neurologist', 'Oncologist', 'Nutritionist'];
    $currentSpecialization = $staff['specialization'] ?? '';
    $isKnownSpecialization = in_array($currentSpecialization, $knownSpecializations, true);
    $specializationOptionsHtml = '';
    foreach ($knownSpecializations as $spec) {
        $specializationOptionsHtml .= '<option value="' . h($spec) . '"' . ($currentSpecialization === $spec ? ' selected' : '') . '>' . h($spec) . '</option>';
    }

    echo '<div class="card" style="max-width: 680px; margin-bottom: 24px;">
        <form method="post" action="?action=update_staff">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="staff_id" value="' . h($staff['id']) . '">
            <div class="form-row">
                <label>Username<br><input type="text" name="username" value="' . h($staff['username']) . '" required></label>
                <label>Email<br><input type="email" name="email" value="' . h($staff['email']) . '" required></label>
            </div>
            <div class="form-row">
                <label>Full Name<br><input type="text" name="full_name" value="' . h($staff['full_name']) . '" required></label>
                <label>Role<br><select name="role" id="edit-staff-role" onchange="dsmsToggleSpecialization(\'edit\')">
                    <option value="admin"' . ($staff['role'] === 'admin' ? ' selected' : '') . '>Admin</option>
                    <option value="doctor"' . ($staff['role'] === 'doctor' ? ' selected' : '') . '>Doctor</option>
                    <option value="receptionist"' . ($staff['role'] === 'receptionist' ? ' selected' : '') . '>Receptionist</option>
                    <option value="billing"' . ($staff['role'] === 'billing' ? ' selected' : '') . '>Billing</option>
                    <option value="lab"' . ($staff['role'] === 'lab' ? ' selected' : '') . '>Lab</option>
                    <option value="pharmacy"' . ($staff['role'] === 'pharmacy' ? ' selected' : '') . '>Pharmacy</option>
                </select></label>
            </div>
            <div class="form-row full" id="edit-specialization-row" style="' . ($staff['role'] === 'doctor' ? '' : 'display:none;') . '">
                <label>Specialization<br><select id="edit-specialization-select" onchange="dsmsSpecializationChanged(\'edit\')">
                    <option value="">-- Select specialization --</option>
                    ' . $specializationOptionsHtml . '
                    <option value="__other__"' . ($currentSpecialization !== '' && !$isKnownSpecialization ? ' selected' : '') . '>Other (specify)</option>
                </select></label>
                <input type="text" name="specialization" id="edit-specialization-input" placeholder="Enter specialization" value="' . h($currentSpecialization) . '" style="' . ($currentSpecialization !== '' && !$isKnownSpecialization ? 'display:block;' : 'display:none;') . ' margin-top:10px;">
            </div>
            <div class="form-row full">
                <p style="margin:4px 0;">Status: <strong>' . ($staff['is_active'] ? 'Active' : 'Inactive') . '</strong> &mdash; use the Activate/Deactivate button on the staff list to change this.</p>
            </div>
            <div class="form-row full">
                <label>New Password (leave blank to keep current)<br><input type="password" name="password"></label>
            </div>
            <button type="submit" class="dsms-submit-btn" style="width:auto; display:inline-block; padding:11px 26px;">Save Changes</button>
            <a href="?action=admin_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>
        </form>
    </div>';

    echo '<script>
    function dsmsToggleSpecialization(prefix) {
        var role = document.getElementById(prefix + "-staff-role").value;
        var row = document.getElementById(prefix + "-specialization-row");
        row.style.display = (role === "doctor") ? "block" : "none";
    }
    function dsmsSpecializationChanged(prefix) {
        var select = document.getElementById(prefix + "-specialization-select");
        var input = document.getElementById(prefix + "-specialization-input");
        if (select.value === "__other__") {
            input.style.display = "block";
            input.value = "";
            input.focus();
        } else {
            input.style.display = "none";
            input.value = select.value;
        }
    }
    </script>';

    renderFooter();
    exit;
}

// ---------------------------------------------------------------------
// Admin recovery: regenerate missing bill for a consultation
// ---------------------------------------------------------------------
if ($action === 'admin_regenerate_bill' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('admin');
    $consultationId = (int)($_POST['consultation_id'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    try {
        if ($consultationId <= 0) {
            throw new \RuntimeException('Invalid consultation.');
        }
        if ($reason === '') {
            throw new \RuntimeException('Recovery reason is required.');
        }
        $pdo = Database::getConnection();
        $c = $pdo->prepare('SELECT patient_id FROM consultations WHERE id = :id');
        $c->execute([':id' => $consultationId]);
        $crow = $c->fetch();
        $patientId = $crow ? (int)$crow['patient_id'] : 0;

        $invoiceId = Billing::regenerateBillForConsultation($consultationId, (int)$_SESSION['staff_id']);
        if ($patientId > 0) {
            RecoveryLog::record(
                (int)$_SESSION['staff_id'],
                $patientId,
                $consultationId,
                $invoiceId ?: null,
                'regenerate_bill',
                'Missing/incomplete bill',
                'Invoice ready',
                trim($_POST['reason'] ?? '') ?: 'Admin regenerated missing bill'
            );
            Notification::notifyRole(
                'billing',
                'bill_regenerated',
                'Bill regenerated',
                'Admin regenerated invoice #' . $invoiceId . ' — open it to collect payment.',
                'view_invoice',
                $invoiceId ?: null
            );
        }
        setFlash('Bill regenerated successfully. Invoice ID #' . $invoiceId . ' is now available in Billing.');
    } catch (\Throwable $e) {
        setFlash('Recovery failed: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=lost_patients');
    exit;
}

if ($action === 'admin_view_workflow') {
    requireRole('admin');
    $consultationId = (int)($_GET['consultation_id'] ?? 0);
    $patientId = (int)($_GET['patient_id'] ?? 0);

    renderHeader('Workflow History', 'admin');
    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Complete Workflow History</h2>
        <p>Audit trail for consultation #' . h((string)$consultationId) . ' / patient #' . h((string)$patientId) . '.</p></div>';

    $logs = [];
    $pdo = Database::getConnection();
    if ($consultationId > 0) {
        $logs = array_merge($logs, AuditLog::forEntity('consultations', $consultationId));
        $rx = Prescription::getForConsultation($consultationId);
        foreach ($rx as $r) {
            $logs = array_merge($logs, AuditLog::forEntity('prescriptions', (int)$r['id']));
        }
        $stmt = $pdo->prepare('SELECT id FROM invoices WHERE consultation_id = :cid');
        $stmt->execute([':cid' => $consultationId]);
        foreach ($stmt->fetchAll() as $inv) {
            $logs = array_merge($logs, AuditLog::forEntity('invoices', (int)$inv['id']));
        }
    }
    if ($patientId > 0) {
        $logs = array_merge($logs, AuditLog::forEntity('patients', $patientId));
    }

    usort($logs, static function ($a, $b) {
        return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
    });

    echo '<div class="card">';
    if (empty($logs)) {
        echo '<div class="no-data"><p>No audit events found.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>When</th><th>Staff</th><th>Entity</th><th>Action</th><th>Details</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            echo '<tr>
                <td>' . h(date('M d, Y H:i:s', strtotime($log['created_at']))) . '</td>
                <td>' . h($log['staff_name'] ?? '—') . '</td>
                <td>' . h($log['entity_type'] . ' #' . $log['entity_id']) . '</td>
                <td>' . h($log['action']) . '</td>
                <td>' . h($log['details'] ?? '') . '</td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '<a href="?action=billing_gaps" class="btn btn-secondary" style="margin-top:14px;">Back to Gaps</a>';
    echo '</div>';
    renderFooter();
    exit;
}

// ---------------------------------------------------------------------
// Admin: Billing Gaps dashboard
// ---------------------------------------------------------------------
if ($action === 'billing_gaps') {
    requireRole('admin');
    $gaps = Prescription::findBillingGaps();

    $q = trim($_GET['q'] ?? '');
    $stepFilter = trim($_GET['step'] ?? '');

    $enriched = [];
    foreach ($gaps as $g) {
        $missingStep = 'Unknown';
        if (empty($g['invoice_id']) && (int)($g['treatment_finalized'] ?? 0) === 1) {
            $missingStep = 'Bill never generated';
        } elseif ((int)($g['treatment_finalized'] ?? 0) === 1 && empty($g['invoice_item_id']) && ($g['prescription_status'] ?? '') === 'Finalized') {
            $missingStep = 'Prescription not on invoice';
        } elseif (($g['prescription_status'] ?? '') === 'Draft' && (int)($g['treatment_finalized'] ?? 0) === 1) {
            $missingStep = 'Prescription still Draft after finalize';
        } elseif (empty($g['invoice_id'])) {
            $missingStep = 'Not yet sent to Billing';
        } elseif (($g['invoice_status'] ?? '') === 'Pending' && empty($g['invoice_item_id'])) {
            $missingStep = 'Invoice exists but pharmacy line missing';
        } else {
            $missingStep = 'Billing incomplete';
        }

        $lastActivity = $g['locked_at'] ?: ($g['finalized_at'] ?: $g['prescription_date']);
        $seconds = max(0, time() - strtotime($lastActivity ?: 'now'));
        $hours = intdiv($seconds, 3600);
        $mins = intdiv($seconds % 3600, 60);
        $timeSince = $hours > 0 ? "{$hours}h {$mins}m" : "{$mins}m";

        $row = $g + [
            'missing_step' => $missingStep,
            'time_since' => $timeSince,
            'last_activity' => $lastActivity,
        ];

        if ($q !== '') {
            $hay = strtolower(($g['patient_name'] ?? '') . ' ' . ($g['patient_code'] ?? '') . ' ' . ($g['doctor_name'] ?? '') . ' ' . ($g['medication'] ?? ''));
            if (strpos($hay, strtolower($q)) === false) {
                continue;
            }
        }
        if ($stepFilter !== '' && stripos($missingStep, $stepFilter) === false) {
            continue;
        }
        $enriched[] = $row;
    }

    renderHeader('Billing Gaps', 'admin');
    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Patients Missing from Billing</h2>
        <p>Prescriptions or visits that never produced a complete, visible billing record. Use recovery actions to regenerate bills safely.</p></div>';

    echo '<div class="card" style="margin-bottom:18px;">
        <form method="get" action="" style="display:flex; gap:12px; flex-wrap:wrap; align-items:end;">
            <input type="hidden" name="action" value="billing_gaps">
            <label>Search<br><input type="search" name="q" value="' . h($q) . '" placeholder="Patient, doctor, medicine" style="min-width:220px;"></label>
            <label>Missing step contains<br><input type="text" name="step" value="' . h($stepFilter) . '" placeholder="e.g. never generated"></label>
            <button type="submit" class="btn btn-secondary">Filter</button>
            <a href="?action=billing_gaps" class="btn btn-secondary">Clear</a>
        </form>
    </div>';

    echo '<div class="card">';
    echo '<p><strong>' . count($enriched) . '</strong> gap record(s) shown.</p>';
    if (empty($enriched)) {
        echo '<div class="no-data"><p>No billing gaps detected. Every prescription has a traceable billing record.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr>
                <th>Patient</th><th>Patient #</th><th>Doctor</th><th>Department</th>
                <th>Prescription</th><th>Rx Date</th><th>Missing Step</th>
                <th>Status</th><th>Idle</th><th>Actions</th>
            </tr></thead><tbody>';
        foreach ($enriched as $row) {
            echo '<tr>
                <td>' . h($row['patient_name']) . '</td>
                <td><strong>' . h($row['patient_code']) . '</strong></td>
                <td>' . h($row['doctor_name'] ?? '-') . '</td>
                <td>' . h($row['department'] ?? '-') . '</td>
                <td>' . h($row['medication'] ?? '-') . ' x' . h((string)($row['quantity'] ?? 1)) . '</td>
                <td>' . h(date('M d, H:i', strtotime($row['prescription_date']))) . '</td>
                <td><span class="status-badge status-warning">' . h($row['missing_step']) . '</span></td>
                <td>Rx: ' . h($row['prescription_status'] ?? '-') . '<br>Inv: ' . h($row['invoice_status'] ?? 'none') . '</td>
                <td>' . h($row['time_since']) . '</td>
                <td style="white-space:nowrap;">';
            if (!empty($row['consultation_id'])) {
                echo '<form method="post" action="?action=admin_regenerate_bill" style="display:inline; margin-right:4px;">
                    <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                    <input type="hidden" name="consultation_id" value="' . h((string)$row['consultation_id']) . '">
                    <button type="submit" class="btn btn-primary btn-small" onclick="return confirm(\'Regenerate / attach bill for this consultation?\')">Regenerate Bill</button>
                </form>';
                echo '<a class="btn btn-secondary btn-small" href="?action=admin_view_workflow&consultation_id=' . h((string)$row['consultation_id']) . '&patient_id=' . h((string)$row['patient_pk']) . '">History</a>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

// ADMIN DASHBOARD
if ($action === 'admin_dashboard') {
    requireRole('admin');
    renderHeader('Admin - System Management', 'admin');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $allStaff = Staff::all();
    $allPatients = Patient::all();

    echo '<div class="page-title"><h2>System Administration</h2><p>Manage staff, monitor system usage, and view operational metrics.</p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('users', 18) . ' <span>Total Staff</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('users', 28) . '</div><div class="card-stat-text"><h4>Active Users</h4><p>' . count($allStaff) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('hospital', 18) . ' <span>Total Patients</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('hospital', 28) . '</div><div class="card-stat-text"><h4>Registered</h4><p>' . count($allPatients) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('chart', 18) . ' <span>System</span></h3><div class="card-stat"><div class="card-stat-icon">' . dsms_icon('chart', 28) . '</div><div class="card-stat-text"><h4>Status</h4><p style="color: var(--success);">Online</p></div></div></div>';
    echo '</div>';

    $pendingApprovalsCount = count(MedicinePurchaseRequest::getPending()) + count(LabEquipmentRequest::getPending());

    $billingGapsCount = count(Prescription::findBillingGaps());

    echo '<div class="dsms-section-title"><span></span>Quick Access</div>';
    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('trending', 18) . ' <span>MOIC Oversight</span></h3><p>View high-level metrics and department reporting.</p><a href="?action=moic_dashboard" class="btn btn-primary">Open MOIC Dashboard</a></div>';
    echo '<div class="card"><h3> Billing Gaps' . ($billingGapsCount > 0 ? ' <span class="status-badge status-warning">' . $billingGapsCount . '</span>' : '') . '</h3><p>Patients or prescriptions that never reached a billable invoice.</p><a href="?action=billing_gaps" class="btn btn-secondary">Open Gaps Dashboard</a></div>';
    echo '<div class="card"><h3> Budgets</h3><p>Manage departmental budget allocations and review spend.</p><a href="?action=budget_dashboard" class="btn btn-secondary">Open Budget Manager</a></div>';
    echo '<div class="card"><h3> Purchase Approvals' . ($pendingApprovalsCount > 0 ? ' <span class="status-badge status-waiting">' . $pendingApprovalsCount . ' pending</span>' : '') . '</h3><p>Review pharmacy stock and lab equipment requests.</p><a href="?action=purchase_approvals" class="btn btn-secondary">Review Requests</a></div>';
    echo '</div>';

    
    // Workflow monitoring snapshot
    try {
        $wfCounts = Workflow::stageCounts();
        echo '<div class="dsms-section-title"><span></span>Workflow Monitoring</div>';
        echo '<div class="grid grid-3">';
        $wfCards = [
            ['waiting_consultation', 'Waiting Consultation', '?action=admin_dashboard'],
            ['in_laboratory', 'In Laboratory', '?action=lab_dashboard'],
            ['waiting_billing', 'Waiting Billing', '?action=lost_patients&step=' . urlencode('never')],
            ['awaiting_payment', 'Awaiting Payment', '?action=billing_queue'],
            ['waiting_pharmacy', 'Waiting Pharmacy', '?action=pharmacy_dashboard'],
            ['lost_patients', 'Lost Patients', '?action=lost_patients'],
            ['completed_visits', 'Completed Visits', '?action=moic_dashboard'],
        ];
        foreach ($wfCards as $wc) {
            $n = (int)($wfCounts[$wc[0]] ?? 0);
            $border = ($wc[0] === 'lost_patients' && $n > 0) ? 'border:2px solid #dc2626;' : '';
            echo '<a href="' . h($wc[2]) . '" class="card" style="text-decoration:none;color:inherit;' . $border . '">
                <h3>' . h($wc[1]) . '</h3>
                <div class="card-stat"><div class="card-stat-text"><h4>Now</h4><p>' . $n . '</p></div></div>
            </a>';
        }
        echo '</div>';
        echo '<p style="margin:8px 0 18px;"><a class="btn btn-secondary btn-small" href="?action=workflow_monitor">Open full monitor</a></p>';
    } catch (\Throwable $e) {
        // schema may not be migrated yet on first hit
    }

echo '<div class="dsms-section-title"><span></span>Add New Staff Member</div>';
    // Create New Staff
    echo '<div class="card" style="max-width: 600px;">
    <form method="post" action="?action=create_staff">
        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
        <div class="form-row">
            <label>Username<br><input type="text" name="username" required></label>
            <label>Email<br><input type="email" name="email" required></label>
        </div>
        <div class="form-row">
            <label>Full Name<br><input type="text" name="full_name" required></label>
            <label>Role<br><select name="role" id="create-staff-role" onchange="dsmsToggleSpecialization(\'create\')"><option value="receptionist">Receptionist</option><option value="doctor">Doctor</option><option value="billing">Billing</option><option value="lab">Lab</option><option value="pharmacy">Pharmacy</option><option value="admin">Admin</option></select></label>
        </div>
        <div class="form-row full" id="create-specialization-row" style="display:none;">
            <label>Specialization<br><select name="specialization_select" id="create-specialization-select" onchange="dsmsSpecializationChanged(\'create\')">
                <option value="">-- Select specialization --</option>
                <option value="General Physician">General Physician</option>
                <option value="Dentist">Dentist</option>
                <option value="Pediatrician">Pediatrician</option>
                <option value="Gynecologist/Obstetrician">Gynecologist/Obstetrician</option>
                <option value="General Surgeon">General Surgeon</option>
                <option value="Orthopedic Surgeon">Orthopedic Surgeon</option>
                <option value="Cardiologist">Cardiologist</option>
                <option value="Dermatologist">Dermatologist</option>
                <option value="Ophthalmologist">Ophthalmologist</option>
                <option value="ENT Specialist">ENT Specialist</option>
                <option value="Psychiatrist">Psychiatrist</option>
                <option value="Radiologist">Radiologist</option>
                <option value="Anesthesiologist">Anesthesiologist</option>
                <option value="Internal Medicine">Internal Medicine</option>
                <option value="Urologist">Urologist</option>
                <option value="Neurologist">Neurologist</option>
                <option value="Oncologist">Oncologist</option>
                <option value="Nutritionist">Nutritionist</option>
                <option value="__other__">Other (specify)</option>
            </select></label>
            <input type="text" name="specialization" id="create-specialization-input" placeholder="Enter specialization" style="display:none; margin-top:10px;">
        </div>
        <div class="form-row full">
            <label>Password<br><input type="password" name="password" required></label>
        </div>
        <button type="submit" class="dsms-submit-btn">Create Staff Account</button>
    </form>
    </div>';

    echo '<script>
    function dsmsToggleSpecialization(prefix) {
        var role = document.getElementById(prefix + "-staff-role").value;
        var row = document.getElementById(prefix + "-specialization-row");
        row.style.display = (role === "doctor") ? "block" : "none";
    }
    function dsmsSpecializationChanged(prefix) {
        var select = document.getElementById(prefix + "-specialization-select");
        var input = document.getElementById(prefix + "-specialization-input");
        if (select.value === "__other__") {
            input.style.display = "block";
            input.value = "";
            input.focus();
        } else {
            input.style.display = "none";
            input.value = select.value;
        }
    }
    </script>';

    echo '<div class="dsms-section-title"><span></span>Staff Directory (' . count($allStaff) . ')</div>';
    // Staff List
    echo '<div class="card">';
    echo '<div class="table-responsive"><table>
    <thead><tr><th>Username</th><th>Name</th><th>Email</th><th>Role</th><th>Specialization</th><th>Last Login</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>';
    foreach ($allStaff as $staff) {
        $lastLogin = $staff['last_login'] ? date('M d, H:i', strtotime($staff['last_login'])) : 'Never';
        echo '<tr>
        <td><strong>' . h($staff['username']) . '</strong></td>
        <td>' . h($staff['full_name']) . '</td>
        <td>' . h($staff['email']) . '</td>
        <td><span class="badge badge-' . ($staff['role'] === 'admin' ? 'primary' : ($staff['role'] === 'doctor' ? 'accent' : ($staff['role'] === 'billing' ? 'success' : 'secondary'))) . '">' . h($staff['role']) . '</span></td>
        <td>' . ($staff['role'] === 'doctor' ? h($staff['specialization'] ?: 'General') : '-') . '</td>
        <td>' . $lastLogin . '</td>
        <td>' . ((int)$staff['is_active'] ? '<span class="status-badge status-accepted">Active</span>' : '<span class="status-badge status-warning">Pending activation</span>') . '</td>
        <td><div class="action-buttons">
            <a href="?action=edit_staff&id=' . h($staff['id']) . '" class="btn btn-secondary btn-small">Edit</a>' .
            ((int)$staff['id'] !== (int)$_SESSION['staff_id'] ? '<form method="post" action="?action=toggle_staff_status" style="display:inline;margin:0;" onsubmit="return confirm(\'' . ($staff['is_active'] ? 'Deactivate' : 'Activate') . ' this staff account?\');">
                <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                <input type="hidden" name="staff_id" value="' . h($staff['id']) . '">
                <button type="submit" class="btn btn-secondary btn-small">' . ($staff['is_active'] ? 'Deactivate' : 'Activate') . '</button>
            </form>' : '') .
            ((int)$staff['id'] !== (int)$_SESSION['staff_id'] ? '<form method="post" action="?action=delete_staff" style="display:inline;margin:0;">
                <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                <input type="hidden" name="staff_id" value="' . h($staff['id']) . '">
                <button type="submit" class="btn btn-danger btn-small">Delete</button>
            </form>' : '') .
        '</div></td>
        </tr>';
    }
    echo '</tbody></table></div>';
    echo '</div>';

    renderFooter();
    exit;
}

// ------------------------------------------------------------------
// Patient Treatment History — doctors see only patients they've
// personally treated; admins see every patient with full detail.
// ------------------------------------------------------------------
if ($action === 'patient_history') {
    $role = $_SESSION['staff_role'] ?? '';
    if ($role !== 'doctor' && $role !== 'admin') {
        setFlash('You do not have access to patient history.', 'error');
        header('Location: ?action=dashboard');
        exit;
    }

    $isAdmin = $role === 'admin';
    $patients = $isAdmin
        ? PatientHistory::all()
        : PatientHistory::forDoctor((int)$_SESSION['staff_id']);

    renderHeader('Patient History', $role);

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>' . ($isAdmin ? 'All Patients' : 'My Patients') . '</h2><p>' .
        ($isAdmin
            ? 'Every registered patient, with full treatment and billing history.'
            : 'Patients you have personally consulted. Click a patient to see their full visit history with you.') .
        '</p></div>';

    echo '<div class="card">';
    if (empty($patients)) {
        echo '<div class="no-data"><p>No patients to show yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient ID</th><th>Name</th><th>Gender</th><th>Visits' . ($isAdmin ? '' : ' With You') . '</th><th>Last Visit</th><th></th></tr></thead>
            <tbody>';
        foreach ($patients as $p) {
            echo '<tr>
                <td><strong>' . h($p['patient_code']) . '</strong></td>
                <td>' . h($p['full_name']) . '</td>
                <td>' . h($p['gender'] ?? '-') . '</td>
                <td>' . h($p['visit_count']) . '</td>
                <td>' . ($p['last_visit'] ? h(date('M d, Y', strtotime($p['last_visit']))) : '-') . '</td>
                <td><a href="?action=patient_history_detail&patient_id=' . h($p['id']) . '" class="btn btn-info btn-small">View History</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'patient_history_detail') {
    $role = $_SESSION['staff_role'] ?? '';
    if ($role !== 'doctor' && $role !== 'admin') {
        setFlash('You do not have access to patient history.', 'error');
        header('Location: ?action=dashboard');
        exit;
    }

    $patientId = (int)($_GET['patient_id'] ?? 0);
    $patient = Patient::find($patientId);
    if ($role === 'doctor' && $patient && !QueueManager::doctorMayAccessPatient((int)$_SESSION['staff_id'], $patientId, false)) {
        $active = QueueManager::findActiveForPatient($patientId);
        if ($active && !empty($active['assigned_doctor_id']) && (int)$active['assigned_doctor_id'] !== (int)$_SESSION['staff_id']) {
            setFlash('This patient is under another doctor\'s care for the current visit. Access is blocked until they transfer the case.', 'error');
            header('Location: ?action=patient_history');
            exit;
        }
    }
    if (!$patient) {
        setFlash('Patient not found.', 'error');
        header('Location: ?action=patient_history');
        exit;
    }

    $isAdmin = $role === 'admin';
    // Doctors are restricted to patients they've personally treated —
    // checked here regardless of what the model query itself does, so a
    // doctor can never view another doctor's patient by guessing an id.
    if (!$isAdmin && !PatientHistory::doctorHasTreated((int)$_SESSION['staff_id'], $patientId)) {
        setFlash('You can only view history for patients you have personally treated.', 'error');
        header('Location: ?action=patient_history');
        exit;
    }

    $timeline = PatientHistory::timelineForPatient($patientId, $isAdmin ? null : (int)$_SESSION['staff_id'], $isAdmin);

    renderHeader('Patient History', $role);

    $csrf = h(getCsrfToken());
    $allergy = trim((string)($patient['allergies'] ?? ''));
    $chronic = trim((string)($patient['chronic_conditions'] ?? ''));
    $blood = trim((string)($patient['blood_type'] ?? ''));

    echo '<div class="ph-top">';
    echo '<div class="ph-top-main">';
    echo '<a href="?action=patient_history" class="btn btn-secondary btn-small">← Patient list</a>';
    echo '<div>';
    echo '<h2 class="ph-name">' . h($patient['full_name']) . '</h2>';
    echo '<p class="ph-meta">'
        . '<span>' . h($patient['patient_id']) . '</span>'
        . '<span>' . h($patient['gender'] ?? '—') . '</span>'
        . '<span>DOB ' . h($patient['date_of_birth'] ?? '—') . '</span>'
        . '<span>' . h($patient['phone'] ?? '—') . '</span>'
        . '</p>';
    echo '</div></div>';
    echo '<div class="ph-top-count"><strong>' . count($timeline) . '</strong><small>Visit' . (count($timeline) === 1 ? '' : 's') . '</small></div>';
    echo '</div>';

    echo '<div class="ph-safety">';
    echo '<span class="ph-chip"><strong>Blood</strong> ' . h($blood !== '' ? $blood : '—') . '</span>';
    echo '<span class="ph-chip' . ($allergy !== '' ? ' ph-chip-warn' : '') . '"><strong>Allergies</strong> ' . h($allergy !== '' ? $allergy : 'None recorded') . '</span>';
    echo '<span class="ph-chip"><strong>Chronic</strong> ' . h($chronic !== '' ? $chronic : 'None recorded') . '</span>';
    echo '</div>';

    if ($isAdmin) {
        $registeredBy = PatientHistory::registeredByName($patientId);
        echo '<div class="card ph-card" style="margin-bottom:16px;">';
        echo '<h3>Contact & registration</h3>';
        echo '<div class="ph-contact-grid">';
        echo '<div><small>Phone</small><strong>' . h($patient['phone'] ?? '—') . '</strong></div>';
        echo '<div><small>Email</small><strong>' . h($patient['email'] ?? '—') . '</strong></div>';
        echo '<div><small>Address</small><strong>' . h($patient['address'] ?? '—') . '</strong></div>';
        echo '<div><small>Emergency</small><strong>' . h($patient['emergency_contact'] ?? '—') . '</strong></div>';
        echo '<div><small>Registered by</small><strong>' . h($registeredBy ?? 'Not recorded') . '</strong></div>';
        echo '</div></div>';
    }

    if (empty($timeline)) {
        echo '<div class="card ph-card"><div class="no-data"><p>No consultations recorded' . ($isAdmin ? ' for this patient yet.' : ' with you yet.') . '</p></div></div>';
    }

    foreach ($timeline as $idx => $visit) {
        $status = (string)($visit['status'] ?? '');
        $statusClass = match (true) {
            str_contains(strtolower($status), 'lab') => 'status-paid',
            str_contains(strtolower($status), 'medicine') => 'status-waiting',
            str_contains(strtolower($status), 'healthy') => 'status-accepted',
            default => 'status-completed',
        };
        $visitNum = count($timeline) - $idx;

        echo '<article class="ph-visit card">';
        echo '<header class="ph-visit-head">';
        echo '<div>';
        echo '<span class="ph-visit-num">Visit #' . $visitNum . '</span>';
        echo '<h3>' . h(date('D, M j, Y · H:i', strtotime($visit['created_at']))) . '</h3>';
        echo '<p class="dsms-hint" style="margin:0;">Dr. ' . h($visit['doctor_name']) . '</p>';
        echo '</div>';
        echo '<div class="ph-visit-badges">';
        echo '<span class="status-badge ' . $statusClass . '">' . h($status !== '' ? $status : 'Recorded') . '</span>';
        if ((int)($visit['treatment_finalized'] ?? 0) === 1) {
            echo '<span class="status-badge status-paid">Finalized</span>';
        }
        echo '</div></header>';

        // Clinical findings
        echo '<div class="ph-findings">';
        echo '<div class="ph-finding"><small>Symptoms</small><p>' . h($visit['symptoms'] ?: '—') . '</p></div>';
        echo '<div class="ph-finding"><small>Examination</small><p>' . h($visit['examination'] ?: '—') . '</p></div>';
        echo '<div class="ph-finding"><small>Diagnosis</small><p>' . h($visit['diagnosis'] ?: '—') . '</p></div>';
        if (!empty($visit['note'])) {
            echo '<div class="ph-finding ph-finding-full"><small>Notes</small><p>' . h($visit['note']) . '</p></div>';
        }
        echo '</div>';

        if ($isAdmin && !empty($visit['vitals'])) {
            $v = $visit['vitals'];
            echo '<div class="ph-section">';
            echo '<h4>Vitals</h4>';
            echo '<div class="ph-vital-row">';
            echo '<span><small>Weight</small><b>' . h((string)($v['weight'] ?? '—')) . ' kg</b></span>';
            echo '<span><small>Height</small><b>' . h((string)($v['height'] ?? '—')) . ' cm</b></span>';
            echo '<span><small>Temp</small><b>' . h((string)($v['temperature'] ?? '—')) . ' °C</b></span>';
            echo '<span><small>BP</small><b>' . h((string)($v['blood_pressure'] ?? '—')) . '</b></span>';
            echo '<span><small>Pulse</small><b>' . h((string)($v['pulse_rate'] ?? '—')) . '</b></span>';
            echo '</div>';
            if (!empty($v['recorded_by_name'])) {
                echo '<p class="dsms-hint" style="margin:8px 0 0;">Recorded by ' . h($v['recorded_by_name']) . '</p>';
            }
            echo '</div>';
        }

        if (!empty($visit['lab_requests'])) {
            echo '<div class="ph-section">';
            echo '<h4>Laboratory</h4>';
            echo '<div class="table-responsive"><table><thead><tr><th>Test</th><th>Result</th><th>Comments</th>' . ($isAdmin ? '<th>By</th>' : '') . '<th>Date</th></tr></thead><tbody>';
            foreach ($visit['lab_requests'] as $lab) {
                $res = $lab['result'] ?? 'Pending';
                $pending = ($res === 'Pending' || $res === '' || $res === null);
                echo '<tr>
                    <td><strong>' . h($lab['test_type']) . '</strong></td>
                    <td>' . ($pending ? '<span class="status-badge status-waiting">Pending</span>' : h($res)) . '</td>
                    <td>' . h($lab['comments'] ?? '—') . '</td>'
                    . ($isAdmin ? '<td>' . h($lab['uploaded_by_name'] ?? '—') . '</td>' : '') .
                    '<td>' . (!empty($lab['uploaded_at']) ? h(date('M d, Y', strtotime($lab['uploaded_at']))) : '—') . '</td>
                </tr>';
            }
            echo '</tbody></table></div></div>';
        }

        if (!empty($visit['prescriptions'])) {
            echo '<div class="ph-section">';
            echo '<h4>Prescriptions</h4>';
            echo '<div class="table-responsive"><table><thead><tr><th>Medication</th><th>Dosage</th><th>Frequency</th><th>Dispensed</th>' . ($isAdmin ? '<th>By</th>' : '') . '</tr></thead><tbody>';
            foreach ($visit['prescriptions'] as $rx) {
                echo '<tr>
                    <td><strong>' . h($rx['medication']) . '</strong></td>
                    <td>' . h($rx['dosage']) . '</td>
                    <td>' . h($rx['frequency']) . '</td>
                    <td>' . (!empty($rx['dispensed_at'])
                        ? '<span class="status-badge status-paid">Dispensed ' . h(date('M d', strtotime($rx['dispensed_at']))) . '</span>'
                        : '<span class="status-badge status-waiting">Not yet</span>') . '</td>'
                    . ($isAdmin ? '<td>' . h($rx['dispensed_by'] ?? '—') . '</td>' : '') .
                    '</tr>';
            }
            echo '</tbody></table></div></div>';
        }

        if ($isAdmin && !empty($visit['invoice'])) {
            $inv = $visit['invoice'];
            $invoiceBadgeClass = match ($inv['status'] ?? '') {
                'Paid' => 'status-paid',
                'Partial' => 'status-waiting',
                default => 'status-warning',
            };
            echo '<div class="ph-section">';
            echo '<h4>Billing</h4>';
            echo '<p style="margin:0;"><strong>' . h($inv['invoice_number'] ?? 'Invoice') . '</strong> — TZS '
                . h(number_format((float)($inv['total_amount'] ?? 0), 2))
                . ' <span class="status-badge ' . $invoiceBadgeClass . '">' . h($inv['status'] ?? '') . '</span></p>';
            echo '</div>';
        }

        if ($isAdmin) {
            $staffInvolved = [];
            $staffInvolved[] = 'Reception: ' . ($visit['queued_by_name'] ?? '—');
            if (!empty($visit['vitals']['recorded_by_name'])) {
                $staffInvolved[] = 'Vitals: ' . $visit['vitals']['recorded_by_name'];
            }
            $staffInvolved[] = 'Doctor: ' . ($visit['doctor_name'] ?? '—');
            if (!empty($visit['lab_requests'])) {
                $labStaff = array_unique(array_filter(array_column($visit['lab_requests'], 'uploaded_by_name')));
                if ($labStaff) {
                    $staffInvolved[] = 'Lab: ' . implode(', ', $labStaff);
                }
            }
            if (!empty($visit['prescriptions'])) {
                $pharmacyStaff = array_unique(array_filter(array_column($visit['prescriptions'], 'dispensed_by')));
                if ($pharmacyStaff) {
                    $staffInvolved[] = 'Pharmacy: ' . implode(', ', $pharmacyStaff);
                }
            }
            if (!empty($visit['invoice'])) {
                $staffInvolved[] = 'Billing: ' . ($visit['billing_staff']['generated_by'] ?? '—');
            }
            echo '<div class="ph-staff">';
            foreach ($staffInvolved as $entry) {
                echo '<span class="ph-staff-pill">' . h($entry) . '</span>';
            }
            echo '</div>';
        }

        echo '</article>';
    }

    echo '<style>
    .ph-top{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:14px}
    .ph-top-main{display:flex;align-items:flex-start;gap:12px}
    .ph-name{margin:0 0 4px;font-size:1.45rem;font-weight:800;letter-spacing:-.02em;color:#0f172a}
    .ph-meta{margin:0;display:flex;flex-wrap:wrap;gap:10px;color:#64748b;font-size:.85rem}
    .ph-top-count{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:10px 16px;text-align:center;min-width:72px}
    .ph-top-count strong{display:block;font-size:1.35rem;font-weight:800;color:#1e4b82;line-height:1.1}
    .ph-top-count small{font-size:.7rem;color:#64748b;text-transform:uppercase;letter-spacing:.04em;font-weight:600}
    .ph-safety{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px}
    .ph-chip{background:#fff;border:1px solid #e2e8f0;border-radius:999px;padding:6px 12px;font-size:.8rem;color:#334155}
    .ph-chip strong{color:#0f172a;margin-right:4px}
    .ph-chip-warn{border-color:#fecaca;background:#fef2f2;color:#991b1b}
    .ph-card h3{margin-top:0}
    .ph-contact-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}
    .ph-contact-grid small{display:block;font-size:.68rem;text-transform:uppercase;letter-spacing:.04em;color:#94a3b8;font-weight:600}
    .ph-contact-grid strong{font-size:.9rem;color:#0f172a;font-weight:600}
    .ph-visit{margin-bottom:16px;padding:0;overflow:hidden}
    .ph-visit-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;padding:16px 18px;background:linear-gradient(120deg,#f8fafc,#eef4fb);border-bottom:1px solid #e2e8f0}
    .ph-visit-head h3{margin:4px 0 2px;font-size:1.05rem;font-weight:800;color:#0f172a}
    .ph-visit-num{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#2563a8}
    .ph-visit-badges{display:flex;flex-wrap:wrap;gap:6px;justify-content:flex-end}
    .ph-findings{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;padding:16px 18px}
    .ph-finding{background:#f8fafc;border:1px solid #eef2f7;border-radius:12px;padding:12px}
    .ph-finding-full{grid-column:1/-1}
    .ph-finding small{display:block;font-size:.68rem;text-transform:uppercase;letter-spacing:.04em;color:#94a3b8;font-weight:700;margin-bottom:4px}
    .ph-finding p{margin:0;font-size:.9rem;color:#0f172a;line-height:1.45;white-space:pre-wrap}
    .ph-section{padding:0 18px 16px}
    .ph-section h4{margin:0 0 10px;font-size:.78rem;text-transform:uppercase;letter-spacing:.05em;color:#64748b;font-weight:700}
    .ph-vital-row{display:flex;flex-wrap:wrap;gap:14px}
    .ph-vital-row span{min-width:72px}
    .ph-vital-row small{display:block;font-size:.65rem;text-transform:uppercase;color:#94a3b8;font-weight:600}
    .ph-vital-row b{font-size:.9rem;color:#0f172a}
    .ph-staff{display:flex;flex-wrap:wrap;gap:6px;padding:0 18px 16px}
    .ph-staff-pill{background:#f1f5f9;border-radius:999px;padding:4px 10px;font-size:.72rem;font-weight:600;color:#475569}
    @media (max-width:800px){.ph-findings{grid-template-columns:1fr}}
    </style>';

    renderFooter();
    exit;
}


if ($action === 'my_profile') {
    requireLogin();

    $me = Staff::getById((int)$_SESSION['staff_id']);
    if (!$me) {
        setFlash('Your account could not be found.', 'error');
        header('Location: ?action=logout');
        exit;
    }

    renderHeader('My Profile', $_SESSION['staff_role']);

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $myDashboardAction = $_SESSION['staff_role'] . '_dashboard';
    if ($_SESSION['staff_role'] === 'billing') {
        $myDashboardAction = 'billing_center';
    }

    echo '<div class="page-title" style="display:flex; align-items:flex-end; justify-content:space-between; flex-wrap:wrap; gap:12px;">
        <div><h2>My Profile</h2><p>Update your personal details, profile picture, and password.</p></div>
        <a href="?action=' . h($myDashboardAction) . '" class="btn btn-secondary">← Back to Dashboard</a>
    </div>';

    echo '<div class="dsms-profile-grid">';

    // ---- Avatar card ----
    echo '<div class="card dsms-profile-avatar-card">';
    if ($me['avatar']) {
        echo '<img src="' . h($me['avatar']) . '" alt="Profile picture" class="dsms-profile-avatar-img">';
    } else {
        echo '<div class="dsms-profile-avatar-img dsms-profile-avatar-fallback">' . h(strtoupper(substr($me['full_name'], 0, 1))) . '</div>';
    }
    echo '<h3 style="margin-top:16px;">' . h($me['full_name']) . '</h3>';
    echo '<p class="dsms-hint" style="margin-top:-6px;">@' . h($me['username']) . ' · ' . h(ucfirst($me['role'])) . '</p>';

    echo '<form method="post" action="?action=upload_avatar" enctype="multipart/form-data" style="margin-top:16px;">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<label class="dsms-label">Change Profile Picture</label>';
    echo '<input type="file" name="avatar" accept="image/png, image/jpeg, image/webp" class="dsms-text-input" style="margin-bottom:10px;">';
    echo '<button type="submit" class="dsms-submit-btn">Upload Photo</button>';
    echo '</form>';
    if ($me['avatar']) {
        echo '<form method="post" action="?action=remove_avatar" style="margin-top:8px;">';
        echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
        echo '<button type="submit" class="btn btn-secondary btn-small" style="width:100%;">Remove Photo</button>';
        echo '</form>';
    }
    echo '</div>';

    // ---- Details + password ----
    echo '<div>';

    echo '<div class="card" style="margin-bottom: 20px;"><h3>Account Details</h3>';
    echo '<form method="post" action="?action=update_my_profile">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<div class="form-row">';
    echo '<label>Full Name<br><input type="text" name="full_name" value="' . h($me['full_name']) . '" required></label>';
    echo '<label>Email<br><input type="email" name="email" value="' . h($me['email']) . '" required></label>';
    echo '</div>';
    echo '<p class="dsms-hint">Username (<strong>' . h($me['username']) . '</strong>) and role (<strong>' . h(ucfirst($me['role'])) . '</strong>) are managed by an administrator.</p>';
    echo '<button type="submit" class="dsms-submit-btn" style="margin-top: 8px;">Save Changes</button>';
    echo '</form>';
    echo '</div>';

    echo '<div class="card"><h3>Change Password</h3>';
    echo '<form method="post" action="?action=change_my_password">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<div class="form-row">';
    echo '<label>Current Password<br><input type="password" name="current_password" required></label>';
    echo '<label>New Password<br><input type="password" name="new_password" required minlength="6"></label>';
    echo '</div>';
    echo '<div class="form-row full">';
    echo '<label>Confirm New Password<br><input type="password" name="confirm_password" required minlength="6"></label>';
    echo '</div>';
    echo '<button type="submit" class="dsms-submit-btn">Change Password</button>';
    echo '</form>';
    echo '</div>';

    echo '</div>'; // details column
    echo '</div>'; // .dsms-profile-grid

    renderFooter();
    exit;
}

if ($action === 'update_my_profile' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireLogin();
    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    try {
        if (!$fullName || !$email) {
            throw new \Exception('Full name and email are required.');
        }
        Staff::updateOwnProfile((int)$_SESSION['staff_id'], $fullName, $email);
        $_SESSION['staff_name'] = $fullName;
        AuditLog::log((int)$_SESSION['staff_id'], 'staff', (int)$_SESSION['staff_id'], 'update_own_profile');
        setFlash('Profile updated successfully.');
    } catch (\Throwable $e) {
        $message = str_contains($e->getMessage(), 'Duplicate entry') ? 'That email is already in use by another account.' : $e->getMessage();
        setFlash('Could not update profile: ' . $message, 'error');
    }
    header('Location: ?action=my_profile');
    exit;
}

if ($action === 'change_my_password' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireLogin();
    $current = (string)($_POST['current_password'] ?? '');
    $new = (string)($_POST['new_password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    try {
        if (strlen($new) < 6) {
            throw new \Exception('New password must be at least 6 characters.');
        }
        if ($new !== $confirm) {
            throw new \Exception('New password and confirmation do not match.');
        }
        $ok = Staff::changeOwnPassword((int)$_SESSION['staff_id'], $current, $new);
        if (!$ok) {
            throw new \Exception('Current password is incorrect.');
        }
        AuditLog::log((int)$_SESSION['staff_id'], 'staff', (int)$_SESSION['staff_id'], 'change_own_password');
        setFlash('Password changed successfully.');
    } catch (\Throwable $e) {
        setFlash('Could not change password: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=my_profile');
    exit;
}

if ($action === 'upload_avatar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireLogin();

    try {
        if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
            throw new \Exception('Please choose an image file to upload.');
        }

        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        $tmpPath = $_FILES['avatar']['tmp_name'];
        $mime = function_exists('mime_content_type') ? mime_content_type($tmpPath) : $_FILES['avatar']['type'];

        if (!isset($allowed[$mime])) {
            throw new \Exception('Only JPG, PNG, or WEBP images are allowed.');
        }
        if ($_FILES['avatar']['size'] > 2 * 1024 * 1024) {
            throw new \Exception('Image must be smaller than 2MB.');
        }

        $uploadDir = __DIR__ . '/uploads/avatars';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $filename = 'staff_' . (int)$_SESSION['staff_id'] . '_' . time() . '.' . $allowed[$mime];
        $destination = $uploadDir . '/' . $filename;

        if (!move_uploaded_file($tmpPath, $destination)) {
            throw new \Exception('Could not save the uploaded file.');
        }

        // Remove the old avatar file, if any, to avoid orphaned files piling up.
        $me = Staff::getById((int)$_SESSION['staff_id']);
        if ($me && $me['avatar'] && is_file(__DIR__ . '/' . $me['avatar'])) {
            @unlink(__DIR__ . '/' . $me['avatar']);
        }

        Staff::updateAvatar((int)$_SESSION['staff_id'], 'uploads/avatars/' . $filename);
        AuditLog::log((int)$_SESSION['staff_id'], 'staff', (int)$_SESSION['staff_id'], 'upload_avatar');
        setFlash('Profile picture updated.');
    } catch (\Throwable $e) {
        setFlash('Could not upload photo: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=my_profile');
    exit;
}

if ($action === 'remove_avatar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireLogin();
    $me = Staff::getById((int)$_SESSION['staff_id']);
    if ($me && $me['avatar'] && is_file(__DIR__ . '/' . $me['avatar'])) {
        @unlink(__DIR__ . '/' . $me['avatar']);
    }
    Staff::removeAvatar((int)$_SESSION['staff_id']);
    AuditLog::log((int)$_SESSION['staff_id'], 'staff', (int)$_SESSION['staff_id'], 'remove_avatar');
    setFlash('Profile picture removed.');
    header('Location: ?action=my_profile');
    exit;
}

// Default - show role-based dashboard
requireLogin();
$defaultAction = $_SESSION['staff_role'] . '_dashboard';
if ($_SESSION['staff_role'] === 'billing') {
    $defaultAction = 'billing_center';
}
header('Location: ?action=' . $defaultAction);
