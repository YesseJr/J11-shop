<?php

/**
 * DSMS Database Configuration
 * ----------------------------
 * Fill in your MySQL connection details below.
 * Keep this file outside of version control — add it to .gitignore.
 */

return [
    'db_host' => '127.0.0.1',   // or 'localhost'
    'db_port' => '3307',
    'db_name' => 'dsms',        // the database you created: CREATE DATABASE dsms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    'db_user' => 'root',   // your MySQL username
    'db_pass' => '',   // your MySQL password
];
