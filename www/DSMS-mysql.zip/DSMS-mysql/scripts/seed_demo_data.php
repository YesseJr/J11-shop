<?php
/**
 * DSMS demo seed — staff, patients, lab tests, medicines, budgets.
 *
 * Usage (from project root):
 *   php scripts/seed_demo_data.php
 *
 * Safe to re-run: skips usernames / catalog rows that already exist.
 * Default password for all demo staff: Demo@1234
 */

declare(strict_types=1);

date_default_timezone_set('Africa/Nairobi');

require_once __DIR__ . '/../src/Database.php';
require_once __DIR__ . '/../src/Models/Staff.php';
require_once __DIR__ . '/../src/Models/Patient.php';
require_once __DIR__ . '/../src/Models/MedicineCategory.php';
require_once __DIR__ . '/../src/Models/Medicine.php';
require_once __DIR__ . '/../src/Models/LabTestCatalog.php';
require_once __DIR__ . '/../src/Models/Budget.php';

$pdo = Database::getConnection();
$now = date('c');
$password = 'Demo@1234';
$hash = password_hash($password, PASSWORD_BCRYPT);

echo "DSMS demo seed (EAT {$now})\n";
echo "Default password for all demo accounts: {$password}\n\n";

function staffExists(PDO $pdo, string $username): bool
{
    $s = $pdo->prepare('SELECT id FROM staff WHERE username = ? LIMIT 1');
    $s->execute([$username]);
    return (bool)$s->fetch();
}

function ensureStaff(
    PDO $pdo,
    string $username,
    string $email,
    string $fullName,
    string $role,
    string $hash,
    string $now,
    ?string $specialization = null,
    bool $active = true
): void {
    if (staffExists($pdo, $username)) {
        echo "  · staff exists: {$username} ({$role})\n";
        // Keep demo accounts active and password reset for stakeholder demos
        $pdo->prepare('UPDATE staff SET is_active = 1, password_hash = ?, updated_at = ? WHERE username = ?')
            ->execute([$hash, $now, $username]);
        return;
    }
    $stmt = $pdo->prepare(
        'INSERT INTO staff (username, email, password_hash, full_name, role, specialization, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $username,
        $email,
        $hash,
        $fullName,
        $role,
        $specialization,
        $active ? 1 : 0,
        $now,
        $now,
    ]);
    echo "  + staff created: {$username} ({$role})\n";
}

echo "Staff\n";
$demoStaff = [
    ['admin', 'admin@dsms.local', 'Amina Mwangi', 'admin', null],
    ['reception', 'reception@dsms.local', 'Grace Njeri', 'receptionist', null],
    ['doctor1', 'doctor1@dsms.local', 'Dr. James Ochieng', 'doctor', 'General Practice'],
    ['doctor2', 'doctor2@dsms.local', 'Dr. Sarah Kimani', 'doctor', 'Internal Medicine'],
    ['lab1', 'lab@dsms.local', 'Peter Otieno', 'lab', null],
    ['billing1', 'billing@dsms.local', 'Faith Wanjiku', 'billing', null],
    ['pharmacy1', 'pharmacy@dsms.local', 'Daniel Mutua', 'pharmacy', null],
];
foreach ($demoStaff as [$u, $e, $n, $r, $spec]) {
    ensureStaff($pdo, $u, $e, $n, $r, $hash, $now, $spec, true);
}

// Pending registration example (inactive) for admin activation demo
ensureStaff($pdo, 'pending.nurse', 'pending@dsms.local', 'Pending User', 'receptionist', $hash, $now, null, false);
echo "  · inactive demo account: pending.nurse (activate via Admin)\n";

echo "\nMedicine categories\n";
$categories = ['Analgesics', 'Antibiotics', 'Antimalarials', 'Chronic Care', 'Supplements'];
$catIds = [];
foreach ($categories as $name) {
    $s = $pdo->prepare('SELECT id FROM medicine_categories WHERE name = ? LIMIT 1');
    $s->execute([$name]);
    $row = $s->fetch();
    if ($row) {
        $catIds[$name] = (int)$row['id'];
        echo "  · category exists: {$name}\n";
        continue;
    }
    $pdo->prepare('INSERT INTO medicine_categories (name, created_at) VALUES (?, ?)')->execute([$name, $now]);
    $catIds[$name] = (int)$pdo->lastInsertId();
    echo "  + category: {$name}\n";
}

echo "\nMedicines\n";
$medicines = [
    ['Analgesics', 'Paracetamol 500mg', 'Tablet', 500, 50, 200.00, date('Y-m-d', strtotime('+18 months'))],
    ['Analgesics', 'Ibuprofen 400mg', 'Tablet', 300, 40, 350.00, date('Y-m-d', strtotime('+14 months'))],
    ['Antibiotics', 'Amoxicillin 500mg', 'Capsule', 250, 30, 800.00, date('Y-m-d', strtotime('+12 months'))],
    ['Antibiotics', 'Azithromycin 500mg', 'Tablet', 120, 20, 1500.00, date('Y-m-d', strtotime('+10 months'))],
    ['Antimalarials', 'AL (Artemether-Lumefantrine)', 'Tablet', 200, 25, 1200.00, date('Y-m-d', strtotime('+9 months'))],
    ['Chronic Care', 'Metformin 500mg', 'Tablet', 400, 50, 300.00, date('Y-m-d', strtotime('+20 months'))],
    ['Chronic Care', 'Amlodipine 5mg', 'Tablet', 180, 25, 450.00, date('Y-m-d', strtotime('+16 months'))],
    ['Supplements', 'ORS Sachet', 'Sachet', 600, 80, 150.00, date('Y-m-d', strtotime('+24 months'))],
    // Low stock + near expiry samples for alerts
    ['Analgesics', 'Diclofenac 50mg', 'Tablet', 8, 20, 400.00, date('Y-m-d', strtotime('+2 months'))],
];
foreach ($medicines as [$cat, $name, $form, $qty, $reorder, $price, $expiry]) {
    $s = $pdo->prepare('SELECT id FROM medicines WHERE name = ? LIMIT 1');
    $s->execute([$name]);
    if ($s->fetch()) {
        echo "  · medicine exists: {$name}\n";
        continue;
    }
    $status = $qty > 0 ? 'Available' : 'Out of Stock';
    $pdo->prepare(
        'INSERT INTO medicines (category_id, name, dosage_form, quantity, reorder_level, unit_price, expiry_date, status, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)'
    )->execute([$catIds[$cat], $name, $form, $qty, $reorder, $price, $expiry, $status, $now, $now]);
    echo "  + medicine: {$name}\n";
}

# Backfill cost prices (~60% of sell) for margin demos
$pdo->exec('UPDATE medicines SET cost_price = ROUND(unit_price * 0.6, 2) WHERE cost_price IS NULL');
echo "  · cost_price backfilled for margin reports\n";

echo "\nLab test catalog\n";
$tests = [
    ['Full Blood Count (FBC)', 15000.00],
    ['Malaria RDT', 5000.00],
    ['Blood Sugar (RBS)', 4000.00],
    ['Urinalysis', 6000.00],
    ['Lipid Profile', 18000.00],
    ['Liver Function Tests', 20000.00],
];
foreach ($tests as [$name, $price]) {
    $s = $pdo->prepare('SELECT id FROM lab_test_catalog WHERE test_name = ? LIMIT 1');
    $s->execute([$name]);
    if ($s->fetch()) {
        echo "  · lab test exists: {$name}\n";
        continue;
    }
    $pdo->prepare(
        'INSERT INTO lab_test_catalog (test_name, price, is_active, created_at, updated_at) VALUES (?, ?, 1, ?, ?)'
    )->execute([$name, $price, $now, $now]);
    echo "  + lab test: {$name}\n";
}

echo "\nBudgets\n";
$year = date('Y');
foreach (['Pharmacy' => 5000000, 'Laboratory' => 3500000, 'Administration' => 2000000] as $dept => $alloc) {
    $s = $pdo->prepare('SELECT id FROM budgets WHERE department = ? AND fiscal_year = ? LIMIT 1');
    $s->execute([$dept, $year]);
    if ($s->fetch()) {
        echo "  · budget exists: {$dept} {$year}\n";
        continue;
    }
    $pdo->prepare(
        'INSERT INTO budgets (department, allocated, spent, fiscal_year, created_at, updated_at) VALUES (?, ?, 0, ?, ?, ?)'
    )->execute([$dept, $alloc, $year, $now, $now]);
    echo "  + budget: {$dept} {$year}\n";
}

echo "\nSample patients\n";
$adminId = (int)$pdo->query("SELECT id FROM staff WHERE username = 'reception' LIMIT 1")->fetchColumn();
$patients = [
    ['Asha Hassan', 'Female', '1992-04-12', '0712000001', 'asha@example.com'],
    ['John Kamau', 'Male', '1985-11-03', '0712000002', 'john.k@example.com'],
    ['Mary Akinyi', 'Female', '2001-07-21', '0712000003', null],
    ['Brian Otieno', 'Male', '1978-01-30', '0712000004', null],
    ['Lucy Wambui', 'Female', '1995-09-08', '0712000005', 'lucy.w@example.com'],
];
foreach ($patients as [$name, $gender, $dob, $phone, $email]) {
    $s = $pdo->prepare('SELECT id FROM patients WHERE full_name = ? AND phone = ? LIMIT 1');
    $s->execute([$name, $phone]);
    if ($s->fetch()) {
        echo "  · patient exists: {$name}\n";
        continue;
    }
    $stmt = $pdo->prepare(
        'INSERT INTO patients (full_name, gender, date_of_birth, phone, email, address, emergency_contact, status, registered_by_staff_id, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $name, $gender, $dob, $phone, $email,
        'Nairobi', 'Next of kin', 'Registered', $adminId ?: null, $now, $now,
    ]);
    $id = (int)$pdo->lastInsertId();
    $code = sprintf('PT-%05d', $id);
    $pdo->prepare('UPDATE patients SET patient_id = ? WHERE id = ?')->execute([$code, $id]);
    echo "  + patient: {$code} {$name}\n";
}

echo "\nDone.\n";
echo "Login examples:\n";
echo "  admin / Demo@1234\n";
echo "  reception / Demo@1234\n";
echo "  doctor1 / Demo@1234\n";
echo "  lab1 / Demo@1234\n";
echo "  billing1 / Demo@1234\n";
echo "  pharmacy1 / Demo@1234\n";
echo "Then walk the E2E checklist in docs/E2E_TEST_CHECKLIST.md\n";
