# DSMS - Hospital & Dispensary Management System

A modern, role-based hospital management system with staff authentication and separate dashboards for different roles.

## Features

- **Staff-Only Authentication**: No patient login. Hospital staff only.
- **Role-Based Access**:
  - **Admin**: System administration, staff management, monitoring
  - **Doctor**: Consultation management, patient consultations, medical records
  - **Receptionist**: Patient registration, queue management
- **Patient Workflow**:
  1. Reception registers patient → generates Patient ID
  2. Patient added to consultation queue
  3. Doctor accepts patient and records vitals/consultation
  4. Lab investigations if required
  5. Payment tracking
- **Professional UI**: Teal/white/cyan color scheme, responsive design
- **Security**: CSRF protection, password hashing, role-based access control

## Default Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin123` |

## Installation & Usage

1. Place files in `xampp/htdocs/DSMS`
2. Open `http://localhost/DSMS/public/index.php`
3. Login with admin credentials
4. Create new staff accounts (Doctor, Receptionist) from Admin dashboard
5. Staff can login with their credentials

## Project Structure

```
DSMS/
├── public/
│   ├── index.php                 # Main application router
│   └── assets/
│       ├── styles.css            # Professional styling
│       └── app.js                # Client-side interactions
├── src/
│   ├── Database.php              # SQLite connection & schema
│   └── Models/
│       ├── Staff.php             # Staff authentication
│       ├── Patient.php           # Patient records
│       ├── QueueManager.php       # Queue operations
│       ├── Vital.php             # Vital signs recording
│       ├── Consultation.php       # Doctor consultations
│       ├── Payment.php           # Payment tracking
│       ├── LabRequest.php        # Lab request management
│       └── LabResult.php         # Lab result uploads
└── data/
    └── database.sqlite           # SQLite database (auto-created)
```

## Dashboard Features

### Admin Dashboard
- Staff directory and management
- Create new staff accounts
- System statistics
- User activity monitoring

### Doctor Dashboard
- View waiting patients queue
- Accept and consult patients
- Record vital signs
- Document symptoms, examination, diagnosis
- Create lab investigation requests

### Receptionist Dashboard
- Register new patients
- Add patients to consultation queue
- View current queue status
- Patient information management

### Pharmacy Dashboard
- Dispense prescriptions once the patient's invoice is paid (or insurance-covered)
- Live low-stock and expired-medicine warnings
- Patient medication history
- **Medicine Inventory** (shared with Admin) — manage treatment categories and the medicine catalog

## Pharmacy Inventory Subsystem

A lightweight inventory foundation sitting on top of the existing Pharmacy and Doctor modules:

- **Treatment categories** (Malaria, Typhoid, Diabetes, Hypertension, Pain Relief, Antibiotics, Respiratory,
  Gastrointestinal, HIV/AIDS, Vitamins & Supplements, plus any admin/pharmacy adds) group medicines for
  easy lookup.
- Each medicine tracks name, category, dosage/form, available quantity, reorder level, unit price, expiry
  date, and an `Available` / `Out of Stock` status that updates automatically as stock changes.
- **Doctor prescribing**: the prescription form includes a "Medicine (from inventory)" picker. Selecting a
  medicine shows its live stock instantly; if it's out of stock, the form suggests in-stock alternatives
  from the same treatment category (client-side, no page reload). Doctors can still type a medicine
  manually via "Not in catalog" for anything not yet in the inventory — this doesn't block prescribing.
- **Pharmacist dispensing**: dispensing a prescription linked to a catalog medicine automatically reduces
  its stock. Dispensing more than what's on hand is rejected with a clear error instead of allowing
  negative stock.
- **Warnings**: the Pharmacy Dashboard and Medicine Inventory page both surface low-stock (at/below
  reorder level) and expired/expiring-soon medicines.
- **Access**: `Medicine Inventory` (add categories, add/edit medicines, adjust stock, activate/deactivate)
  is available to both the `pharmacy` and `admin` roles, mirroring the existing `lab_test_catalog` pattern.

This is intentionally a foundation — `medicine_id` on `prescriptions` is nullable so all existing
free-text prescriptions keep working unchanged, and the schema/model layout leaves room for future phases
(suppliers, purchase orders, batch/lot tracking, expiry-based FEFO dispensing, etc.) without another
breaking migration.

## Color Scheme

- **Primary**: Teal (`#0f766e`)
- **Primary Light**: Cyan (`#14b8a6`)
- **Accent**: Sky Cyan (`#06b6d4`)
- **Backgrounds**: Mint green gradient
- **Professional**: Clean, modern, accessible

## Security Features

- Session-based authentication
- CSRF token validation on forms
- Password hashing with bcrypt
- Role-based access control (RBAC)
- SQL injection prevention via prepared statements
- XSS protection via HTML escaping

## Budget Management Subsystem

Each department (currently **Pharmacy** and **Laboratory**) is responsible for funding its own
restocking — there is no central procurement/purchasing department. This is a deliberate
design decision, not a placeholder:

- **Allocation**: Admin sets a yearly `allocated` amount per department (`?action=budget_dashboard`).
- **Expenditure**: since there's no purchase-order/supplier module yet, "spent" is calculated as the
  **consumption value** of what the department has issued — Pharmacy's spend is
  `unit_price × quantity` for every medicine dispensed (`Dispensation::record()`), Laboratory's
  spend is the billed amount of every completed test (`LabResult::upload()`). Both write through
  `Budget::recordExpenditure()`, which is best-effort and never blocks a dispense/result if no
  budget is configured for that department yet.
- **Dashboard**: `?action=budget_dashboard` shows total allocated/spent/remaining across all
  departments, dedicated Pharmacy and Laboratory utilization cards, and per-budget
  create/update/delete controls (admin only).
- If procurement is ever centralized under Admin, `Budget::recordExpenditure()` is the single
  place that would need to change (point it at one shared "procurement" department instead of
  the consuming department).

## Database Tables

- `staff`: Staff user accounts with roles
- `patients`: Patient demographic data
- `queue_entries`: Consultation queue management
- `vitals`: Patient vital signs records
- `payments`: Payment transaction records
- `consultations`: Doctor consultation notes
- `lab_requests`: Laboratory investigation requests
- `lab_results`: Lab result records
- `medicine_categories`: Pharmacy treatment categories (Malaria, Antibiotics, etc.)
- `medicines`: Pharmacy inventory catalog — stock, pricing, expiry, status
- `prescriptions.medicine_id`: nullable link from a prescription to its catalog medicine
- `budgets`: Departmental budget allocations and running expenditure (decentralized — see
  Budget Management Subsystem above)

## Development Notes

- Built with plain PHP + SQLite
- No external dependencies required
- Fully functional workflow from reception to lab
- Ready for extension with additional features

## Future Enhancements

- Patient search and filtering
- Consultation history viewer
- Lab result viewing
- Financial reports
- SMS/Email notifications
- Mobile-responsive improvements


## Demo seed data

```bash
php scripts/seed_demo_data.php
```

Creates active staff for every role (password `Demo@1234`), sample patients, medicines, lab tests, and budgets.  
Walk the flow using `docs/E2E_TEST_CHECKLIST.md`. Permissions notes: `docs/PERMISSIONS_AUDIT.md`.
