# DSMS permissions audit

## Auth primitives

| Helper | Behaviour |
|--------|-----------|
| `requireLogin()` | Session must have `staff_id` + `staff_role` |
| `requireRole($role)` | Exact role match |
| `requireAnyRole([...])` | Any listed role |
| `Staff::authenticate` | Rejects bad password **and** `is_active = 0` |

Self-registration creates staff with **`is_active = 0`** until admin runs **toggle_staff_status**.

## Dashboard gates (updated)

| Action | Required role |
|--------|----------------|
| `receptionist_dashboard` | receptionist |
| `doctor_dashboard` | doctor |
| `lab_dashboard` | lab |
| `pharmacy_dashboard` | pharmacy |
| `billing_center` / queue / invoice / receipt | billing |
| `admin_dashboard` / MOIC / catalogs / budgets | admin |

## POST action pattern

Sensitive POSTs in `index.php` are wrapped as:

```php
if ($_SESSION['staff_role'] === 'doctor' && $action === 'finalize_treatment') { ... }
```

or `requireRole()` / `requireAnyRole()` inside route files.

### Shared routes

| Action | Roles |
|--------|-------|
| Medicine inventory / purchase requests | pharmacy, admin |
| Lab equipment requests | lab (submit), admin (approve) |
| Notifications JSON / mark read | any logged-in staff |
| Global search | any logged-in staff |
| My profile | any logged-in staff |

## Recommended manual checks

1. Log in as `doctor1`, open `?action=billing_center` → should redirect away / deny.
2. Log in as inactive `pending.nurse` → blocked before dashboard.
3. Admin activates `pending.nurse` → login succeeds.
4. Reception cannot open `?action=finalize_treatment` via crafted POST without doctor session.

## Residual risk notes

- Some older GET pages may only call `requireLogin()` then show role-specific empty UI; prefer `requireRole` on every role dashboard (reception/doctor/admin fixed in this pass).
- CSRF tokens are required on state-changing POSTs via `getCsrfToken()` — keep that pattern for any new forms.
