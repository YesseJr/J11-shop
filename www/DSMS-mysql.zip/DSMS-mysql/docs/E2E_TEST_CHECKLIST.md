# DSMS end-to-end visit checklist

Run after `php scripts/seed_demo_data.php`.  
Default demo password: **Demo@1234**

Timezone: **Africa/Nairobi (EAT)**

---

## 0. Prep

| Step | Expected |
|------|----------|
| Open landing page | Photos + smooth slider |
| Login as `admin` | Admin dashboard, dark sidebar |
| Staff list shows demo users | All active except `pending.nurse` |
| Activate `pending.nurse` | Toggle works; can log in afterward |
| Log out | Returns to login |

---

## 1. Reception (`reception`)

| Step | Expected |
|------|----------|
| Register new patient | Patient code (PT-xxxxx), flash success |
| Record vitals | Saved without error |
| Add to queue — assign `Dr. James Ochieng` | Status “Waiting for Consultation” |
| Doctor notification | Doctor1 bell badge increases / shakes |

---

## 2. Doctor (`doctor1`)

| Step | Expected |
|------|----------|
| See patient on dashboard queue | Assigned patient listed |
| Open consult | Vitals visible if recorded |
| Save consultation with lab required | Pick e.g. Malaria RDT |
| Lab notified | Lab1 receives lab_request notification |
| (Optional path) Prescribe without lab | Medicines from inventory only |

### Lab path continues →

---

## 3. Laboratory (`lab1`)

| Step | Expected |
|------|----------|
| Pending investigation shows patient | Test name + patient |
| Upload result | Status completed |
| Doctor notified | “Lab results ready” for doctor1 |

---

## 4. Doctor finalize (`doctor1`)

| Step | Expected |
|------|----------|
| Review lab result | Result text visible |
| Add prescription(s) | Qty editable; price from stock |
| Finalize treatment (confirm) | Invoice created |
| Billing notified | “New bill ready” |

---

## 5. Billing (`billing1`)

| Step | Expected |
|------|----------|
| Billing Center / queue | Invoice for patient |
| Open invoice | Line items (consult / lab / meds) |
| Record full payment | Method simulation OK |
| Print receipt | Clean layout; actions hide on print |
| Pharmacy notified | Only when status = Paid |

---

## 6. Pharmacy (`pharmacy1`)

| Step | Expected |
|------|----------|
| Ready to dispense | Paid Rx listed |
| Dispense | Qty **read-only** = doctor qty |
| Stock decreases | Inventory reflects dispense |
| All meds dispensed | Patient status Completed; reception notified |

---

## 7. Cross-checks

| Check | Expected |
|------|----------|
| Wrong-role URL e.g. doctor opens `billing_center` | Redirect / denied |
| Inactive staff login | Blocked with message |
| MOIC report print (`admin`) | Printable page, no nav chrome |
| Notification “Mark all read” | Badge clears |
| Low stock | Diclofenac appears in low-stock if thresholds apply |

---

## Known intentional behaviours

- Lab/medicine charges are **centralized** on the visit invoice (not separate lab/pharmacy cash desks).
- Prescription quantity is locked at dispense time (server-side + UI).
- New self-registrations stay **inactive** until admin activates them.

---

## Bug log (fill during pass)

| Role | Step | Issue | Severity |
|------|------|-------|----------|
| | | | |
| | | | |
