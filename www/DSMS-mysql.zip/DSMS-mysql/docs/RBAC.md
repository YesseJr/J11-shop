# DSMS Role-Based Access Control

## Roles

| Role | Purpose |
|------|---------|
| `admin` | Staff, budgets, catalogs, approvals, analytics, recovery |
| `receptionist` | Registration, vitals, queue |
| `doctor` | Consultations, prescriptions, finalize treatment |
| `lab` | Investigations, results, lab equipment |
| `pharmacy` | Dispense, inventory, purchase requests, medication history |
| `billing` | Invoices, payments, receipts, insurance on bills |

## Enforcement

1. **Public**: `landing`, `login`, `register`
2. **Authenticated + permission map**: `Rbac::enforce($action)` runs after login on every other request
3. **Page-level**: existing `requireRole()` / `requireAnyRole()` remain as secondary checks
4. **Navigation**: sidebar items filtered with `Rbac::filterNav()`
5. **Deny by default**: unknown actions are **admin-only**

## Code

```php
// src/Rbac.php
Rbac::can('pharmacy', 'medicine_inventory'); // bool
Rbac::currentCan('billing_center');
Rbac::enforce($action); // redirect + flash if denied
```

## Adding a new action

1. Add the action key to `Rbac::map()` with allowed roles
2. Optionally keep `requireRole()` in the handler
3. Add a nav item only for roles that should see it

## Testing

| Try as | Open | Expect |
|--------|------|--------|
| doctor | `?action=billing_center` | Redirect + access denied |
| pharmacy | `?action=admin_dashboard` | Redirect + access denied |
| billing | `?action=medicine_inventory` | Redirect + access denied |
| receptionist | `?action=doctor_dashboard` | Redirect + access denied |
| any logged-in | `?action=my_profile` | Allowed |
