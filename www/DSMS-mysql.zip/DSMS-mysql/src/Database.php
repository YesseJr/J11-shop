<?php

class Database
{
    private static ?\PDO $pdo = null;

    public static function getConnection(): \PDO
    {
        if (self::$pdo) {
            return self::$pdo;
        }

        // Align PHP and MySQL session clocks to East Africa Time
        if (function_exists('date_default_timezone_set')) {
            date_default_timezone_set('Africa/Nairobi');
        }

        $config = require __DIR__ . '/../config.php';

        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            $config['db_host'],
            $config['db_port'],
            $config['db_name']
        );

        $pdo = new \PDO($dsn, $config['db_user'], $config['db_pass']);
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);

        // MySQL session: Africa/Nairobi is UTC+3 with no DST
        try {
            $pdo->exec("SET time_zone = '+03:00'");
        } catch (\Throwable $e) {
            // non-fatal if server disallows time_zone changes
        }

        self::$pdo = $pdo;

        self::initializeSchema();

        return self::$pdo;
    }

    private static function initializeSchema(): void
    {
        $sql = <<<SQL
CREATE TABLE IF NOT EXISTS staff (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(80)  NOT NULL UNIQUE,
    email       VARCHAR(160) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name   VARCHAR(160) NOT NULL,
    role        ENUM('admin','doctor','receptionist','billing','pharmacy','lab') NOT NULL,
    specialization VARCHAR(100) DEFAULT NULL,
    avatar      VARCHAR(255) DEFAULT NULL,
    is_active   TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
    last_login  VARCHAR(50)  DEFAULT NULL,
    created_at  VARCHAR(50)  NOT NULL,
    updated_at  VARCHAR(50)  NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS patients (
    id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id            VARCHAR(20)  UNIQUE DEFAULT NULL,
    full_name             VARCHAR(160) NOT NULL,
    gender                VARCHAR(20)  DEFAULT NULL,
    date_of_birth         VARCHAR(20)  DEFAULT NULL,
    phone                 VARCHAR(30)  DEFAULT NULL,
    email                 VARCHAR(160) DEFAULT NULL,
    address               TEXT         DEFAULT NULL,
    emergency_contact     VARCHAR(160) DEFAULT NULL,
    status                VARCHAR(60)  NOT NULL DEFAULT 'Registered',
    registered_by_staff_id INT UNSIGNED DEFAULT NULL,
    created_at            VARCHAR(50)  NOT NULL,
    updated_at            VARCHAR(50)  NOT NULL,
    FOREIGN KEY (registered_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS queue_entries (
    id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id            INT UNSIGNED NOT NULL,
    queued_by_staff_id    INT UNSIGNED DEFAULT NULL,
    assigned_doctor_id    INT UNSIGNED DEFAULT NULL,
    queued_at             VARCHAR(50)  NOT NULL,
    status                VARCHAR(60)  NOT NULL DEFAULT 'Waiting for Consultation',
    accepted_at           VARCHAR(50)  DEFAULT NULL,
    accepted_by_staff_id  INT UNSIGNED DEFAULT NULL,
    delayed_at            VARCHAR(50)  DEFAULT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (queued_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_doctor_id) REFERENCES staff(id) ON DELETE SET NULL,
    FOREIGN KEY (accepted_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vitals (
    id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id           INT UNSIGNED NOT NULL,
    weight               DECIMAL(6,2) DEFAULT NULL,
    height               DECIMAL(6,2) DEFAULT NULL,
    temperature          DECIMAL(5,2) DEFAULT NULL,
    blood_pressure       VARCHAR(20)  DEFAULT NULL,
    pulse_rate           SMALLINT UNSIGNED DEFAULT NULL,
    recorded_by_staff_id INT UNSIGNED DEFAULT NULL,
    recorded_at          VARCHAR(50)  NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS consultations (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id          INT UNSIGNED NOT NULL,
    doctor_staff_id     INT UNSIGNED NOT NULL,
    symptoms            TEXT DEFAULT NULL,
    examination         TEXT DEFAULT NULL,
    diagnosis           TEXT DEFAULT NULL,
    note                TEXT DEFAULT NULL,
    status              VARCHAR(80) NOT NULL,
    treatment_finalized TINYINT(1) NOT NULL DEFAULT 0,
    finalized_at        VARCHAR(50) DEFAULT NULL,
    created_at          VARCHAR(50) NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_staff_id) REFERENCES staff(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS prescriptions (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id      INT UNSIGNED NOT NULL,
    doctor_staff_id INT UNSIGNED NOT NULL,
    consultation_id INT UNSIGNED DEFAULT NULL,
    medication      VARCHAR(200) NOT NULL,
    dosage          VARCHAR(100) NOT NULL,
    frequency       VARCHAR(100) NOT NULL,
    instructions    TEXT DEFAULT NULL,
    unit_price      DECIMAL(12,2) DEFAULT NULL,
    created_at      VARCHAR(50)  NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_staff_id) REFERENCES staff(id) ON DELETE RESTRICT,
    FOREIGN KEY (consultation_id) REFERENCES consultations(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dispensations (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    prescription_id     INT UNSIGNED NOT NULL,
    pharmacy_staff_id   INT UNSIGNED NOT NULL,
    quantity            SMALLINT UNSIGNED NOT NULL,
    note                TEXT DEFAULT NULL,
    dispensed_at        VARCHAR(50) NOT NULL,
    FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE,
    FOREIGN KEY (pharmacy_staff_id) REFERENCES staff(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pharmacy_bills (
    id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id           INT UNSIGNED NOT NULL,
    pharmacist_staff_id  INT UNSIGNED NOT NULL,
    amount               DECIMAL(12,2) NOT NULL,
    created_at           VARCHAR(50)  NOT NULL,
    paid_at              VARCHAR(50)  DEFAULT NULL,
    paid_by_staff_id     INT UNSIGNED DEFAULT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (pharmacist_staff_id) REFERENCES staff(id) ON DELETE RESTRICT,
    FOREIGN KEY (paid_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lab_requests (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    consultation_id INT UNSIGNED NOT NULL,
    test_type       VARCHAR(200) NOT NULL,
    status          VARCHAR(60)  NOT NULL DEFAULT 'Pending Investigation',
    bill            DECIMAL(12,2) NOT NULL,
    created_at      VARCHAR(50)  NOT NULL,
    paid_at         VARCHAR(50)  DEFAULT NULL,
    FOREIGN KEY (consultation_id) REFERENCES consultations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lab_results (
    id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lab_request_id        INT UNSIGNED NOT NULL,
    result                TEXT         NOT NULL,
    comments              TEXT         DEFAULT NULL,
    uploaded_by_staff_id  INT UNSIGNED DEFAULT NULL,
    uploaded_at           VARCHAR(50)  NOT NULL,
    FOREIGN KEY (lab_request_id) REFERENCES lab_requests(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS medication_history (
    id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id           INT UNSIGNED NOT NULL,
    prescription_id      INT UNSIGNED DEFAULT NULL,
    pharmacy_staff_id    INT UNSIGNED DEFAULT NULL,
    quantity             SMALLINT UNSIGNED DEFAULT NULL,
    note                 TEXT DEFAULT NULL,
    dispensed_at         VARCHAR(50) NOT NULL,
    created_at           VARCHAR(50) NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE SET NULL,
    FOREIGN KEY (pharmacy_staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS budgets (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department  VARCHAR(100)  NOT NULL,
    allocated   DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    spent       DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    fiscal_year VARCHAR(10)   DEFAULT NULL,
    created_at  VARCHAR(50)   NOT NULL,
    updated_at  VARCHAR(50)   NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS invoices (
    id                        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_number            VARCHAR(40)  NOT NULL UNIQUE,
    patient_id                INT UNSIGNED NOT NULL,
    consultation_id           INT UNSIGNED NOT NULL,
    queue_entry_id            INT UNSIGNED NOT NULL,
    total_amount              DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    amount_paid               DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    balance                   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    status                    ENUM('Pending','Partially Paid','Paid','Cancelled') NOT NULL DEFAULT 'Pending',
    payer_type                ENUM('Cash','Insurance','Mixed') NOT NULL DEFAULT 'Cash',
    discount_amount           DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    insurance_covered_amount  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    generated_by              INT UNSIGNED DEFAULT NULL,
    generated_at              VARCHAR(50) NOT NULL,
    updated_at                VARCHAR(50) NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (consultation_id) REFERENCES consultations(id) ON DELETE RESTRICT,
    FOREIGN KEY (queue_entry_id) REFERENCES queue_entries(id) ON DELETE RESTRICT,
    FOREIGN KEY (generated_by) REFERENCES staff(id) ON DELETE SET NULL,
    UNIQUE KEY uniq_visit_invoice (queue_entry_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS invoice_items (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id    INT UNSIGNED NOT NULL,
    service_type  ENUM('Consultation','Lab','Pharmacy','Procedure','Other') NOT NULL,
    reference_id  INT UNSIGNED DEFAULT NULL,
    description   VARCHAR(255) NOT NULL,
    quantity      SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    unit_price    DECIMAL(12,2) NOT NULL,
    subtotal      DECIMAL(12,2) NOT NULL,
    added_by      INT UNSIGNED DEFAULT NULL,
    is_manual     TINYINT(1) NOT NULL DEFAULT 0,
    created_at    VARCHAR(50) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (added_by) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payment_transactions (
    id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id            INT UNSIGNED NOT NULL,
    control_number        VARCHAR(40) DEFAULT NULL UNIQUE,
    payment_method        ENUM('Cash','Debit Card','Credit Card','Mobile Money','Bank Transfer') NOT NULL,
    transaction_reference VARCHAR(100) DEFAULT NULL,
    amount_paid           DECIMAL(12,2) NOT NULL,
    received_by           INT UNSIGNED DEFAULT NULL,
    payment_date          VARCHAR(50) NOT NULL,
    payment_status        ENUM('Pending','Completed','Failed','Cancelled') NOT NULL DEFAULT 'Completed',
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (received_by) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS receipts (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    receipt_number  VARCHAR(40) NOT NULL UNIQUE,
    invoice_id      INT UNSIGNED NOT NULL,
    payment_id      INT UNSIGNED NOT NULL,
    printed_by      INT UNSIGNED DEFAULT NULL,
    printed_at      VARCHAR(50) NOT NULL,
    reprint_count   INT UNSIGNED NOT NULL DEFAULT 0,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (payment_id) REFERENCES payment_transactions(id) ON DELETE CASCADE,
    FOREIGN KEY (printed_by) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payments (
    id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id           INT UNSIGNED NOT NULL,
    invoice_id           INT UNSIGNED DEFAULT NULL,
    type                 VARCHAR(60)  NOT NULL,
    amount               DECIMAL(12,2) NOT NULL,
    receipt_number       VARCHAR(40)  UNIQUE DEFAULT NULL,
    recorded_by_staff_id INT UNSIGNED DEFAULT NULL,
    paid_at              VARCHAR(50)  NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE SET NULL,
    FOREIGN KEY (recorded_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS patient_insurance (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id          INT UNSIGNED NOT NULL,
    insurance_provider  VARCHAR(120) NOT NULL,
    insurance_number    VARCHAR(60)  NOT NULL,
    membership_status   ENUM('Active','Inactive','Expired') NOT NULL DEFAULT 'Active',
    coverage_percent    DECIMAL(5,2) NOT NULL DEFAULT 100.00,
    coverage_notes      TEXT DEFAULT NULL,
    valid_from          DATE DEFAULT NULL,
    valid_to            DATE DEFAULT NULL,
    created_at          VARCHAR(50) NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_provider_number (insurance_provider, insurance_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS insurance_claims (
    id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id            INT UNSIGNED NOT NULL,
    patient_insurance_id  INT UNSIGNED NOT NULL,
    claimed_amount        DECIMAL(12,2) NOT NULL,
    approved_amount       DECIMAL(12,2) DEFAULT NULL,
    status                ENUM('Pending Verification','Verified','Partially Approved','Rejected') NOT NULL DEFAULT 'Pending Verification',
    external_reference    VARCHAR(100) DEFAULT NULL,
    verified_by           INT UNSIGNED DEFAULT NULL,
    verified_at           VARCHAR(50) DEFAULT NULL,
    created_at            VARCHAR(50) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (patient_insurance_id) REFERENCES patient_insurance(id) ON DELETE RESTRICT,
    FOREIGN KEY (verified_by) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    staff_id     INT UNSIGNED DEFAULT NULL,
    entity_type  VARCHAR(60) NOT NULL,
    entity_id    INT UNSIGNED DEFAULT NULL,
    action       VARCHAR(100) NOT NULL,
    details      TEXT DEFAULT NULL,
    created_at   VARCHAR(50) NOT NULL,
    FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lab_test_catalog (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    test_name   VARCHAR(150) NOT NULL UNIQUE,
    price       DECIMAL(12,2) NOT NULL,
    is_active   TINYINT(1) NOT NULL DEFAULT 1,
    created_at  VARCHAR(50) NOT NULL,
    updated_at  VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS medicine_categories (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL,
    created_at  VARCHAR(50)  NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS medicines (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id    INT UNSIGNED NOT NULL,
    name           VARCHAR(150) NOT NULL,
    dosage_form    VARCHAR(100) NOT NULL,
    quantity       INT UNSIGNED NOT NULL DEFAULT 0,
    reorder_level  INT UNSIGNED NOT NULL DEFAULT 10,
    unit_price     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    expiry_date    DATE DEFAULT NULL,
    status         ENUM('Available','Out of Stock') NOT NULL DEFAULT 'Available',
    is_active      TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
    created_at     VARCHAR(50) NOT NULL,
    updated_at     VARCHAR(50) NOT NULL,
    FOREIGN KEY (category_id) REFERENCES medicine_categories(id) ON DELETE RESTRICT,
    UNIQUE KEY uniq_medicine_name_form (name, dosage_form)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS medicine_purchase_requests (
    id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    medicine_id           INT UNSIGNED NOT NULL,
    quantity              INT UNSIGNED NOT NULL,
    unit_cost             DECIMAL(12,2) NOT NULL,
    total_cost            DECIMAL(14,2) NOT NULL,
    status                ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    notes                 VARCHAR(255) DEFAULT NULL,
    requested_by_staff_id INT UNSIGNED NOT NULL,
    decided_by_staff_id   INT UNSIGNED DEFAULT NULL,
    decision_note         VARCHAR(255) DEFAULT NULL,
    requested_at          VARCHAR(50) NOT NULL,
    decided_at            VARCHAR(50) DEFAULT NULL,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,
    FOREIGN KEY (requested_by_staff_id) REFERENCES staff(id) ON DELETE RESTRICT,
    FOREIGN KEY (decided_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lab_equipment (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name             VARCHAR(150) NOT NULL,
    category         VARCHAR(100) DEFAULT NULL,
    status           ENUM('Operational','Needs Repair','Worn Out','Retired') NOT NULL DEFAULT 'Operational',
    condition_notes  VARCHAR(255) DEFAULT NULL,
    purchase_cost    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    purchased_at     VARCHAR(50) DEFAULT NULL,
    last_serviced_at VARCHAR(50) DEFAULT NULL,
    is_active        TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
    created_at       VARCHAR(50) NOT NULL,
    updated_at       VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lab_equipment_requests (
    id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_type          ENUM('New','Replacement') NOT NULL DEFAULT 'New',
    equipment_id          INT UNSIGNED DEFAULT NULL,
    equipment_name        VARCHAR(150) NOT NULL,
    category              VARCHAR(100) DEFAULT NULL,
    unit_cost             DECIMAL(12,2) NOT NULL,
    status                ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    notes                 VARCHAR(255) DEFAULT NULL,
    requested_by_staff_id INT UNSIGNED NOT NULL,
    decided_by_staff_id   INT UNSIGNED DEFAULT NULL,
    decision_note         VARCHAR(255) DEFAULT NULL,
    requested_at          VARCHAR(50) NOT NULL,
    decided_at            VARCHAR(50) DEFAULT NULL,
    FOREIGN KEY (equipment_id) REFERENCES lab_equipment(id) ON DELETE SET NULL,
    FOREIGN KEY (requested_by_staff_id) REFERENCES staff(id) ON DELETE RESTRICT,
    FOREIGN KEY (decided_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

        // Run each CREATE TABLE separately (PDO::exec doesn't support multi-statement)
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $statement) {
            if ($statement !== '') {
                self::$pdo->exec($statement);
            }
        }

        self::addPharmacyInventoryColumnsIfMissing();
        self::addBudgetProcurementColumnsIfMissing();
        self::addPrescriptionBillingColumnsIfMissing();
        self::addWorkflowTablesIfMissing();
        self::addClinicalDepthColumnsIfMissing();
        self::createIndexesIfMissing();
        self::seedDefaultAdmin();
        self::seedLabTestCatalog();
        self::seedMedicineInventory();
        self::seedProcedureCatalog();
    }

    /**
     * Workflow visibility tables + invoice assignment columns.
     * Safe to re-run. Does not alter billing calculation logic.
     */
    private static function addWorkflowTablesIfMissing(): void
    {
        self::$pdo->exec(
            "CREATE TABLE IF NOT EXISTS notifications (
                id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                staff_id     INT UNSIGNED DEFAULT NULL,
                role_target  VARCHAR(40) DEFAULT NULL,
                type         VARCHAR(60) NOT NULL,
                title        VARCHAR(200) NOT NULL,
                message      TEXT NOT NULL,
                link_action  VARCHAR(80) DEFAULT NULL,
                entity_id    INT UNSIGNED DEFAULT NULL,
                is_read      TINYINT(1) NOT NULL DEFAULT 0,
                read_at      VARCHAR(50) DEFAULT NULL,
                created_at   VARCHAR(50) NOT NULL,
                INDEX idx_notif_staff (staff_id, is_read),
                INDEX idx_notif_role (role_target, is_read),
                INDEX idx_notif_type (type, entity_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );

        self::$pdo->exec(
            "CREATE TABLE IF NOT EXISTS recovery_logs (
                id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                admin_staff_id   INT UNSIGNED NOT NULL,
                patient_id       INT UNSIGNED NOT NULL,
                consultation_id  INT UNSIGNED DEFAULT NULL,
                invoice_id       INT UNSIGNED DEFAULT NULL,
                action           VARCHAR(100) NOT NULL,
                previous_stage   VARCHAR(100) DEFAULT NULL,
                new_stage        VARCHAR(100) DEFAULT NULL,
                reason           TEXT DEFAULT NULL,
                details          TEXT DEFAULT NULL,
                created_at       VARCHAR(50) NOT NULL,
                INDEX idx_recovery_patient (patient_id),
                INDEX idx_recovery_admin (admin_staff_id),
                INDEX idx_recovery_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );

        self::$pdo->exec(
            "CREATE TABLE IF NOT EXISTS system_settings (
                setting_key   VARCHAR(80) PRIMARY KEY,
                setting_value TEXT NOT NULL,
                updated_at    VARCHAR(50) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );

        $check = self::$pdo->prepare('SELECT COUNT(*) FROM system_settings WHERE setting_key = :k');
        foreach ([
            'workflow_idle_minutes' => '120',
            'billing_idle_minutes' => '60',
        ] as $k => $v) {
            $check->execute([':k' => $k]);
            if ((int)$check->fetchColumn() === 0) {
                $ins = self::$pdo->prepare(
                    'INSERT INTO system_settings (setting_key, setting_value, updated_at) VALUES (:k, :v, :now)'
                );
                $ins->execute([':k' => $k, ':v' => $v, ':now' => date('c')]);
            }
        }

        $colCheck = self::$pdo->prepare(
            'SELECT COUNT(*) AS c FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = :t AND column_name = :c'
        );
        $invoiceCols = [
            'assigned_biller_id' => 'ADD COLUMN assigned_biller_id INT UNSIGNED DEFAULT NULL AFTER generated_by',
            'assigned_at' => 'ADD COLUMN assigned_at VARCHAR(50) DEFAULT NULL AFTER assigned_biller_id',
            'priority' => "ADD COLUMN priority ENUM('normal','high','urgent') NOT NULL DEFAULT 'normal' AFTER assigned_at",
        ];
        foreach ($invoiceCols as $col => $ddl) {
            $colCheck->execute([':t' => 'invoices', ':c' => $col]);
            if ((int)$colCheck->fetch()['c'] === 0) {
                try {
                    self::$pdo->exec('ALTER TABLE invoices ' . $ddl);
                } catch (\Throwable $e) {
                    // non-fatal
                }
            }
        }

        // Notification priority column
        $colCheck->execute([':t' => 'notifications', ':c' => 'priority']);
        if ((int)$colCheck->fetch()['c'] === 0) {
            try {
                self::$pdo->exec("ALTER TABLE notifications ADD COLUMN priority ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal' AFTER entity_id");
            } catch (\Throwable $e) {}
        }

        // Audit trail enrichment columns
        foreach ([
            'ip_address' => "ADD COLUMN ip_address VARCHAR(45) DEFAULT NULL",
            'user_agent' => "ADD COLUMN user_agent VARCHAR(255) DEFAULT NULL",
            'old_values' => "ADD COLUMN old_values TEXT DEFAULT NULL",
            'new_values' => "ADD COLUMN new_values TEXT DEFAULT NULL",
        ] as $col => $ddl) {
            $colCheck->execute([':t' => 'audit_logs', ':c' => $col]);
            if ((int)$colCheck->fetch()['c'] === 0) {
                try {
                    self::$pdo->exec('ALTER TABLE audit_logs ' . $ddl);
                } catch (\Throwable $e) {}
            }
        }

        // Default escalation thresholds
        foreach ([
            'escalation_billing_minutes' => '30',
            'escalation_pharmacy_minutes' => '20',
            'escalation_lab_minutes' => '60',
        ] as $k => $v) {
            $check->execute([':k' => $k]);
            if ((int)$check->fetchColumn() === 0) {
                $ins = self::$pdo->prepare(
                    'INSERT INTO system_settings (setting_key, setting_value, updated_at) VALUES (:k, :v, :now)'
                );
                $ins->execute([':k' => $k, ':v' => $v, ':now' => date('c')]);
            }
        }

    }

    /**
     * Prescription → billing integrity columns:
     * quantity, duration, line_total, status, locked_at.
     * Safe to re-run (information_schema checks).
     */
    private static function addPrescriptionBillingColumnsIfMissing(): void
    {
        $check = self::$pdo->prepare(
            'SELECT COUNT(*) AS c FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = :table AND column_name = :col'
        );

        $columns = [
            'quantity'  => "ADD COLUMN quantity INT UNSIGNED NOT NULL DEFAULT 1 AFTER unit_price",
            'duration'  => "ADD COLUMN duration VARCHAR(100) DEFAULT NULL AFTER frequency",
            'line_total'=> "ADD COLUMN line_total DECIMAL(12,2) DEFAULT NULL AFTER quantity",
            'status'    => "ADD COLUMN status ENUM('Draft','Finalized','Cancelled') NOT NULL DEFAULT 'Draft' AFTER line_total",
            'locked_at' => "ADD COLUMN locked_at VARCHAR(50) DEFAULT NULL AFTER status",
        ];

        foreach ($columns as $col => $ddl) {
            $check->execute([':table' => 'prescriptions', ':col' => $col]);
            if ((int)$check->fetch()['c'] === 0) {
                self::$pdo->exec("ALTER TABLE prescriptions {$ddl}");
            }
        }

        // Backfill line_total for existing rows that have a unit_price
        try {
            self::$pdo->exec(
                'UPDATE prescriptions
                 SET line_total = COALESCE(unit_price, 0) * COALESCE(quantity, 1)
                 WHERE line_total IS NULL AND unit_price IS NOT NULL'
            );
        } catch (\Throwable $e) {
            // non-fatal on fresh installs
        }
    }

    /**
     * Links prescriptions to the medicine catalog without touching the
     * original CREATE TABLE (which stays untouched for older installs).
     * ADD COLUMN ... IF NOT EXISTS isn't reliable pre-MySQL 8, so we check
     * information_schema first, same pattern as createIndexesIfMissing().
     */
    private static function addPharmacyInventoryColumnsIfMissing(): void
    {
        $stmt = self::$pdo->prepare(
            'SELECT COUNT(*) AS c FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = :table AND column_name = :col'
        );
        $stmt->execute([':table' => 'prescriptions', ':col' => 'medicine_id']);
        if ((int)$stmt->fetch()['c'] === 0) {
            self::$pdo->exec(
                'ALTER TABLE prescriptions
                 ADD COLUMN medicine_id INT UNSIGNED DEFAULT NULL AFTER consultation_id,
                 ADD CONSTRAINT fk_prescriptions_medicine FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE SET NULL'
            );
        }
    }

    /**
     * Adds the cost-price column used by the procurement/purchase-request
     * workflow, without touching the original CREATE TABLE (older installs
     * stay compatible). Same information_schema-first pattern as
     * addPharmacyInventoryColumnsIfMissing() above.
     */
    private static function addBudgetProcurementColumnsIfMissing(): void
    {
        $stmt = self::$pdo->prepare(
            'SELECT COUNT(*) AS c FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = :table AND column_name = :col'
        );
        $stmt->execute([':table' => 'medicines', ':col' => 'cost_price']);
        if ((int)$stmt->fetch()['c'] === 0) {
            self::$pdo->exec(
                'ALTER TABLE medicines ADD COLUMN cost_price DECIMAL(12,2) DEFAULT NULL AFTER unit_price'
            );
        }
    }

    /**
     * Clinical depth: patient medical profile, structured lab results,
     * procedure catalog. Safe to re-run.
     */
    private static function addClinicalDepthColumnsIfMissing(): void
    {
        $has = function (string $table, string $col): bool {
            $stmt = self::$pdo->prepare(
                'SELECT COUNT(*) AS c FROM information_schema.columns
                 WHERE table_schema = DATABASE() AND table_name = :table AND column_name = :col'
            );
            $stmt->execute([':table' => $table, ':col' => $col]);
            return (int)$stmt->fetch()['c'] > 0;
        };

        $patientCols = [
            'blood_type' => "ADD COLUMN blood_type VARCHAR(8) DEFAULT NULL AFTER gender",
            'allergies' => "ADD COLUMN allergies TEXT DEFAULT NULL AFTER emergency_contact",
            'chronic_conditions' => "ADD COLUMN chronic_conditions TEXT DEFAULT NULL AFTER allergies",
            'medical_notes' => "ADD COLUMN medical_notes TEXT DEFAULT NULL AFTER chronic_conditions",
        ];
        foreach ($patientCols as $col => $ddl) {
            if (!$has('patients', $col)) {
                self::$pdo->exec("ALTER TABLE patients {$ddl}");
            }
        }

        $labResultCols = [
            'result_value' => "ADD COLUMN result_value VARCHAR(80) DEFAULT NULL AFTER result",
            'result_unit' => "ADD COLUMN result_unit VARCHAR(40) DEFAULT NULL AFTER result_value",
            'reference_range' => "ADD COLUMN reference_range VARCHAR(80) DEFAULT NULL AFTER result_unit",
            'result_flag' => "ADD COLUMN result_flag VARCHAR(20) DEFAULT NULL AFTER reference_range",
        ];
        foreach ($labResultCols as $col => $ddl) {
            if (!$has('lab_results', $col)) {
                self::$pdo->exec("ALTER TABLE lab_results {$ddl}");
            }
        }

        $catalogCols = [
            'default_unit' => "ADD COLUMN default_unit VARCHAR(40) DEFAULT NULL AFTER price",
            'reference_range' => "ADD COLUMN reference_range VARCHAR(80) DEFAULT NULL AFTER default_unit",
        ];
        foreach ($catalogCols as $col => $ddl) {
            if (!$has('lab_test_catalog', $col)) {
                self::$pdo->exec("ALTER TABLE lab_test_catalog {$ddl}");
            }
        }

        self::$pdo->exec(
            "CREATE TABLE IF NOT EXISTS procedure_catalog (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(150) NOT NULL,
                description VARCHAR(255) DEFAULT NULL,
                unit_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at VARCHAR(50) NOT NULL,
                updated_at VARCHAR(50) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );

        self::$pdo->exec(
            "CREATE TABLE IF NOT EXISTS consultation_procedures (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                consultation_id INT UNSIGNED NOT NULL,
                procedure_catalog_id INT UNSIGNED DEFAULT NULL,
                name VARCHAR(150) NOT NULL,
                quantity INT UNSIGNED NOT NULL DEFAULT 1,
                unit_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                line_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                created_at VARCHAR(50) NOT NULL,
                FOREIGN KEY (consultation_id) REFERENCES consultations(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    }

    private static function seedProcedureCatalog(): void
    {
        try {
            $cnt = (int)self::$pdo->query('SELECT COUNT(*) AS c FROM procedure_catalog')->fetch()['c'];
            if ($cnt > 0) {
                return;
            }
            $now = date('c');
            $rows = [
                ['Wound dressing', 'Basic wound cleaning and dressing', 5000],
                ['Injection administration', 'IM/IV injection fee (drug billed separately)', 2000],
                ['Suturing (minor)', 'Minor laceration suture', 15000],
                ['Nebulization', 'Single nebulization session', 3500],
                ['ECG', 'Electrocardiogram recording', 12000],
            ];
            $stmt = self::$pdo->prepare(
                'INSERT INTO procedure_catalog (name, description, unit_price, is_active, created_at, updated_at)
                 VALUES (?, ?, ?, 1, ?, ?)'
            );
            foreach ($rows as [$n, $d, $p]) {
                $stmt->execute([$n, $d, $p, $now, $now]);
            }
        } catch (\Throwable $e) {
            // table may not exist on very old installs until migration runs
        }
    }

    /**
     * Indexes aren't safe to wrap in "IF NOT EXISTS" pre-MySQL 8, so we
     * check information_schema first. Harmless no-op on repeat calls.
     */
    private static function createIndexesIfMissing(): void
    {
        $wanted = [
            ['idx_invoices_status', 'invoices', '(status)'],
            ['idx_invoices_patient', 'invoices', '(patient_id)'],
            ['idx_invoices_patient_status', 'invoices', '(patient_id, status)'],
            ['idx_payment_tx_invoice', 'payment_transactions', '(invoice_id)'],
            ['idx_payment_tx_date', 'payment_transactions', '(payment_date)'],
            ['idx_invoice_items_invoice', 'invoice_items', '(invoice_id)'],
            ['idx_audit_entity', 'audit_logs', '(entity_type, entity_id)'],
            ['idx_medicines_category', 'medicines', '(category_id)'],
            ['idx_medicines_status', 'medicines', '(status)'],
            ['idx_medicines_expiry', 'medicines', '(expiry_date)'],
            ['idx_prescriptions_medicine', 'prescriptions', '(medicine_id)'],
            ['idx_purchase_requests_status', 'medicine_purchase_requests', '(status)'],
            ['idx_purchase_requests_medicine', 'medicine_purchase_requests', '(medicine_id)'],
            ['idx_equipment_status', 'lab_equipment', '(status)'],
            ['idx_equipment_requests_status', 'lab_equipment_requests', '(status)'],
            ['idx_equipment_requests_equipment', 'lab_equipment_requests', '(equipment_id)'],
        ];

        foreach ($wanted as [$indexName, $table, $columns]) {
            $stmt = self::$pdo->prepare(
                'SELECT COUNT(*) AS c FROM information_schema.statistics
                 WHERE table_schema = DATABASE() AND table_name = :table AND index_name = :idx'
            );
            $stmt->execute([':table' => $table, ':idx' => $indexName]);
            if ((int)$stmt->fetch()['c'] === 0) {
                self::$pdo->exec("CREATE INDEX {$indexName} ON {$table} {$columns}");
            }
        }
    }

    private static function seedLabTestCatalog(): void
    {
        try {
            $stmt = self::$pdo->query('SELECT COUNT(*) AS cnt FROM lab_test_catalog');
            $result = $stmt->fetch();
            if ((int)$result['cnt'] > 0) {
                return;
            }

            $defaults = [
                ['Complete Blood Count (CBC)', 15000.00],
                ['Malaria Test (MRDT)', 5000.00],
                ['Urinalysis', 8000.00],
                ['Blood Sugar (Random)', 5000.00],
                ['Widal Test (Typhoid)', 10000.00],
                ['Stool Analysis', 8000.00],
                ['Pregnancy Test (hCG)', 5000.00],
                ['HIV Test', 5000.00],
                ['Liver Function Test (LFT)', 25000.00],
                ['Kidney Function Test (KFT)', 25000.00],
                ['Hepatitis B Test', 12000.00],
                ['Blood Grouping', 6000.00],
            ];

            $now = date('c');
            $stmt = self::$pdo->prepare(
                'INSERT INTO lab_test_catalog (test_name, price, is_active, created_at, updated_at)
                 VALUES (?, ?, 1, ?, ?)'
            );
            foreach ($defaults as [$name, $price]) {
                $stmt->execute([$name, $price, $now, $now]);
            }
        } catch (\Exception $e) {
            // Silently skip if seeding fails (e.g. concurrent init)
        }
    }

    /**
     * Seeds a starter set of treatment categories and common medicines so
     * the Pharmacy Inventory module isn't empty on first use. Skipped
     * entirely once any category already exists (e.g. admin has started
     * customizing the catalog).
     */
    private static function seedMedicineInventory(): void
    {
        try {
            $stmt = self::$pdo->query('SELECT COUNT(*) AS cnt FROM medicine_categories');
            if ((int)$stmt->fetch()['cnt'] > 0) {
                return;
            }

            $now = date('c');
            $categories = [
                'Malaria' => 'Antimalarial treatments',
                'Typhoid' => 'Typhoid fever treatments',
                'Diabetes' => 'Blood sugar management',
                'Hypertension' => 'Blood pressure management',
                'Pain Relief' => 'Analgesics and anti-inflammatories',
                'Antibiotics' => 'Bacterial infection treatments',
                'Respiratory' => 'Cough, cold, and asthma treatments',
                'Gastrointestinal' => 'Digestive system treatments',
                'HIV/AIDS' => 'Antiretroviral therapy',
                'Vitamins & Supplements' => 'Nutritional supplements',
            ];

            $catStmt = self::$pdo->prepare(
                'INSERT INTO medicine_categories (name, description, created_at) VALUES (?, ?, ?)'
            );
            $categoryIds = [];
            foreach ($categories as $name => $description) {
                $catStmt->execute([$name, $description, $now]);
                $categoryIds[$name] = (int)self::$pdo->lastInsertId();
            }

            // [category, name, dosage/form, quantity, reorder level, unit price, expiry date]
            $medicines = [
                ['Malaria', 'Artemether-Lumefantrine (ALU)', '20mg/120mg tablet', 150, 20, 8000.00, '2027-06-30'],
                ['Malaria', 'Quinine Sulphate', '300mg tablet', 60, 15, 6000.00, '2027-03-15'],
                ['Typhoid', 'Ciprofloxacin', '500mg tablet', 100, 20, 3500.00, '2027-01-31'],
                ['Typhoid', 'Ceftriaxone', '1g injection', 40, 10, 15000.00, '2026-12-15'],
                ['Diabetes', 'Metformin', '500mg tablet', 200, 25, 2500.00, '2027-08-01'],
                ['Diabetes', 'Insulin (Regular)', '100IU/ml vial', 25, 10, 25000.00, '2026-11-01'],
                ['Hypertension', 'Amlodipine', '5mg tablet', 180, 20, 3000.00, '2027-05-01'],
                ['Hypertension', 'Losartan', '50mg tablet', 120, 20, 4500.00, '2027-04-10'],
                ['Pain Relief', 'Paracetamol', '500mg tablet', 300, 40, 2000.00, '2027-09-01'],
                ['Pain Relief', 'Ibuprofen', '400mg tablet', 150, 25, 2800.00, '2027-07-15'],
                ['Pain Relief', 'Diclofenac', '50mg tablet', 90, 20, 3200.00, '2027-02-20'],
                ['Antibiotics', 'Amoxicillin', '500mg capsule', 220, 30, 3000.00, '2027-06-01'],
                ['Antibiotics', 'Metronidazole', '400mg tablet', 140, 20, 2500.00, '2027-03-01'],
                ['Respiratory', 'Salbutamol Inhaler', '100mcg inhaler', 35, 10, 12000.00, '2027-01-01'],
                ['Respiratory', 'Cetirizine', '10mg tablet', 100, 20, 2200.00, '2027-10-01'],
                ['Gastrointestinal', 'Omeprazole', '20mg capsule', 130, 20, 3500.00, '2027-05-20'],
                ['Gastrointestinal', 'Oral Rehydration Salts (ORS)', 'sachet', 250, 40, 1500.00, '2027-12-01'],
                ['HIV/AIDS', 'Tenofovir/Lamivudine/Dolutegravir (TLD)', '300/300/50mg tablet', 80, 15, 50000.00, '2027-06-01'],
                ['Vitamins & Supplements', 'Multivitamin', 'tablet', 200, 30, 1800.00, '2027-11-01'],
                ['Vitamins & Supplements', 'Ferrous Sulphate + Folic Acid', 'tablet', 160, 25, 1500.00, '2027-08-15'],
            ];

            $medStmt = self::$pdo->prepare(
                'INSERT INTO medicines (category_id, name, dosage_form, quantity, reorder_level, unit_price, expiry_date, status, is_active, created_at, updated_at)
                 VALUES (:category_id, :name, :form, :qty, :reorder, :price, :expiry, :status, 1, :created, :updated)'
            );
            foreach ($medicines as [$categoryName, $name, $form, $qty, $reorder, $price, $expiry]) {
                if (!isset($categoryIds[$categoryName])) {
                    continue;
                }
                $medStmt->execute([
                    ':category_id' => $categoryIds[$categoryName],
                    ':name' => $name,
                    ':form' => $form,
                    ':qty' => $qty,
                    ':reorder' => $reorder,
                    ':price' => $price,
                    ':expiry' => $expiry,
                    ':status' => $qty > 0 ? 'Available' : 'Out of Stock',
                    ':created' => $now,
                    ':updated' => $now,
                ]);
            }
        } catch (\Exception $e) {
            // Silently skip if seeding fails (e.g. concurrent init)
        }
    }

    private static function seedDefaultAdmin(): void
    {
        try {
            $stmt = self::$pdo->prepare('SELECT COUNT(*) AS cnt FROM staff WHERE role = ?');
            $stmt->execute(['admin']);
            $result = $stmt->fetch();

            if ((int)$result['cnt'] === 0) {
                $hashedPassword = password_hash('admin123', PASSWORD_BCRYPT);
                $now = date('c');
                $stmt = self::$pdo->prepare(
                    'INSERT INTO staff (username, email, password_hash, full_name, role, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?)'
                );
                $stmt->execute(['admin', 'admin@dsms.local', $hashedPassword, 'Administrator', 'admin', $now, $now]);
            }
        } catch (\Exception $e) {
            // Silently fail on duplicate
        }
    }
}