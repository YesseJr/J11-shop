<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Patient.php';

class QueueManager
{
    /** Active visit statuses where doctor assignment still applies. */
    public static function activeStatuses(): array
    {
        return [
            'Waiting for Consultation',
            'In Consultation',
            'Accepted',
            'Paid',
            'Lab Investigation Required',
            'Results Ready',
            'Prescription Uploaded',
            'Awaiting Payment',
        ];
    }

    public static function addToQueue(int $patientId, ?int $queuedByStaffId = null, ?int $assignedDoctorId = null): void
    {
        $existing = self::findActiveForPatient($patientId);
        if ($existing) {
            throw new RuntimeException(
                'This patient is already in the active queue (status: ' . $existing['status'] . '). Clear or finish that visit first.'
            );
        }
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO queue_entries (patient_id, queued_by_staff_id, assigned_doctor_id, queued_at, status)
             VALUES (:patient_id, :queued_by, :assigned_doctor, :queued_at, :status)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':queued_by' => $queuedByStaffId,
            ':assigned_doctor' => $assignedDoctorId,
            ':queued_at' => date('c'),
            ':status' => 'Waiting for Consultation',
        ]);
    }

    /**
     * Waiting list for a doctor: only patients assigned to them.
     * Unassigned (NULL) are listed separately via getUnassignedWaiting().
     */
    public static function getWaiting(?int $doctorId = null): array
    {
        $pdo = Database::getConnection();
        $sql = 'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code,
                       q.queued_at, q.status, q.assigned_doctor_id,
                       s.full_name AS assigned_doctor_name
                FROM queue_entries q
                JOIN patients p ON p.id = q.patient_id
                LEFT JOIN staff s ON s.id = q.assigned_doctor_id
                WHERE q.status = "Waiting for Consultation"';
        $params = [];
        if ($doctorId !== null) {
            $sql .= ' AND q.assigned_doctor_id = :did';
            $params[':did'] = $doctorId;
        }
        $sql .= ' ORDER BY q.queued_at ASC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Pool of patients not yet claimed by any doctor. */
    public static function getUnassignedWaiting(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code,
                    q.queued_at, q.status, q.assigned_doctor_id
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.status = "Waiting for Consultation" AND q.assigned_doctor_id IS NULL
             ORDER BY q.queued_at ASC'
        );
        return $stmt->fetchAll();
    }

    public static function find(int $queueId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, q.patient_id, q.queued_by_staff_id,
                    q.assigned_doctor_id, q.queued_at, q.status, q.accepted_at, q.accepted_by_staff_id, q.delayed_at,
                    p.full_name, p.patient_id AS patient_code
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.id = :id'
        );
        $stmt->execute([':id' => $queueId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Latest active queue entry for a patient (if any). */
    public static function findActiveForPatient(int $patientId): ?array
    {
        $pdo = Database::getConnection();
        $statuses = self::activeStatuses();
        $placeholders = implode(',', array_fill(0, count($statuses), '?'));
        $stmt = $pdo->prepare(
            "SELECT q.*, p.full_name, p.patient_id AS patient_code
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.patient_id = ? AND q.status IN ($placeholders)
             ORDER BY q.id DESC LIMIT 1"
        );
        $stmt->execute(array_merge([$patientId], $statuses));
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /**
     * Whether a doctor may open this patient's clinical data for the active visit.
     * - Admin bypass is handled by callers.
     * - Assigned doctor: yes
     * - Unassigned: yes only when $allowUnassigned is true (e.g. claim flow)
     * - Other doctor: no
     */
    public static function doctorMayAccessPatient(int $doctorId, int $patientId, bool $allowUnassigned = false): bool
    {
        $entry = self::findActiveForPatient($patientId);
        if (!$entry) {
            // No active visit — historical review is allowed (read-only contexts)
            return true;
        }
        $assigned = $entry['assigned_doctor_id'] ?? null;
        if ($assigned === null || $assigned === '') {
            return $allowUnassigned;
        }
        return (int)$assigned === $doctorId;
    }

    public static function doctorMayAccessQueueEntry(int $doctorId, array $entry, bool $allowUnassigned = false): bool
    {
        $assigned = $entry['assigned_doctor_id'] ?? null;
        if ($assigned === null || $assigned === '') {
            return $allowUnassigned;
        }
        return (int)$assigned === $doctorId;
    }

    /** Claim an unassigned waiting patient (exclusive lock to this doctor). */
    public static function claim(int $queueId, int $doctorId): void
    {
        $pdo = Database::getConnection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT * FROM queue_entries WHERE id = :id FOR UPDATE');
            $stmt->execute([':id' => $queueId]);
            $row = $stmt->fetch();
            if (!$row) {
                throw new RuntimeException('Queue entry not found.');
            }
            if ($row['status'] !== 'Waiting for Consultation') {
                throw new RuntimeException('Patient is not waiting for consultation.');
            }
            if (!empty($row['assigned_doctor_id']) && (int)$row['assigned_doctor_id'] !== $doctorId) {
                throw new RuntimeException('This patient is already assigned to another doctor.');
            }
            $pdo->prepare(
                'UPDATE queue_entries SET assigned_doctor_id = :did WHERE id = :id'
            )->execute([':did' => $doctorId, ':id' => $queueId]);
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    /**
     * Hand off patient from current assigned doctor to another doctor.
     * Only the currently assigned doctor (or admin via $asAdmin) may transfer.
     */
    public static function transfer(int $queueId, int $fromDoctorId, int $toDoctorId, bool $asAdmin = false): void
    {
        if ($toDoctorId <= 0) {
            throw new RuntimeException('Select a doctor to transfer to.');
        }
        if (!$asAdmin && $fromDoctorId === $toDoctorId) {
            throw new RuntimeException('Patient is already assigned to you.');
        }
        $pdo = Database::getConnection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT * FROM queue_entries WHERE id = :id FOR UPDATE');
            $stmt->execute([':id' => $queueId]);
            $row = $stmt->fetch();
            if (!$row) {
                throw new RuntimeException('Queue entry not found.');
            }
            $assigned = (int)($row['assigned_doctor_id'] ?? 0);
            if (!$asAdmin && $assigned !== $fromDoctorId) {
                throw new RuntimeException('Only the assigned doctor can transfer this patient.');
            }
            $pdo->prepare(
                'UPDATE queue_entries SET assigned_doctor_id = :to WHERE id = :id'
            )->execute([':to' => $toDoctorId, ':id' => $queueId]);
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    public static function getActive(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code,
                    q.queued_at, q.status, q.assigned_doctor_id
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.status IN ("Waiting for Consultation", "Accepted", "In Consultation")
             ORDER BY q.queued_at ASC'
        );
        return $stmt->fetchAll();
    }

    public static function getAccepted(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code, q.queued_at, q.status
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.status = "Accepted"
             ORDER BY q.queued_at ASC'
        );
        return $stmt->fetchAll();
    }

    public static function accept(int $queueId, int $staffId): ?array
    {
        $entry = self::find($queueId);
        if (!$entry) {
            return null;
        }
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'UPDATE queue_entries SET status = :status, accepted_at = :accepted_at, accepted_by_staff_id = :staff_id WHERE id = :id'
        );
        $stmt->execute([
            ':status' => 'Accepted',
            ':accepted_at' => date('c'),
            ':staff_id' => $staffId,
            ':id' => $queueId,
        ]);
        Patient::updateStatus((int)$entry['patient_row_id'], 'Awaiting Payment');
        $entry['status'] = 'Accepted';
        $entry['accepted_at'] = date('c');
        return $entry;
    }

    public static function getPaid(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code, q.queued_at, q.status
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.status = "Paid"
             ORDER BY q.accepted_at ASC'
        );
        return $stmt->fetchAll();
    }

    public static function startConsultation(int $queueId, ?int $doctorId = null): ?array
    {
        $entry = self::find($queueId);
        if (!$entry || !in_array($entry['status'], ['Waiting for Consultation', 'Accepted', 'Paid', 'In Consultation', 'Results Ready'], true)) {
            return null;
        }

        if ($doctorId !== null) {
            $assigned = $entry['assigned_doctor_id'] ?? null;
            if ($assigned !== null && $assigned !== '' && (int)$assigned !== $doctorId) {
                throw new RuntimeException('This patient is assigned to another doctor. Ask them to transfer the case to you.');
            }
            // Auto-claim if unassigned when starting consult
            if ($assigned === null || $assigned === '') {
                self::claim($queueId, $doctorId);
                $entry = self::find($queueId);
            }
        }

        $pdo = Database::getConnection();
        $now = date('c');
        $stmt = $pdo->prepare(
            'UPDATE queue_entries
             SET status = :status,
                 accepted_at = COALESCE(accepted_at, :accepted_at),
                 accepted_by_staff_id = COALESCE(accepted_by_staff_id, :staff_id)
             WHERE id = :id'
        );
        $stmt->execute([
            ':status' => 'In Consultation',
            ':accepted_at' => $now,
            ':staff_id' => $doctorId,
            ':id' => $queueId,
        ]);
        Patient::updateStatus((int)$entry['patient_row_id'], 'In Consultation');
        $entry['status'] = 'In Consultation';
        if (empty($entry['accepted_at'])) {
            $entry['accepted_at'] = $now;
        }
        return $entry;
    }

    public static function acceptNext(): ?array
    {
        $waiting = self::getWaiting();
        if (empty($waiting)) {
            return null;
        }
        return self::accept((int)$waiting[0]['queue_id'], 0);
    }

    public static function delay(int $queueId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE queue_entries SET status = :status, delayed_at = :delayed_at WHERE id = :id');
        $stmt->execute([
            ':status' => 'Delayed',
            ':delayed_at' => date('c'),
            ':id' => $queueId,
        ]);
    }

    /**
     * Statuses reception may remove from the active queue.
     * Includes In Consultation so no-shows / abandoned visits can be cleared
     * when the patient left without completing care.
     */
    public static function clearableStatuses(): array
    {
        return [
            'Waiting for Consultation',
            'Accepted',
            'Paid',
            'In Consultation',
            'Lab Investigation Required',
            'Results Ready',
            'Delayed',
        ];
    }

    /**
     * Remove a queue entry (no-show / patient left / cancelled visit).
     * Soft-clear only — sets status to Cleared. History is kept.
     */
    public static function clear(int $queueId, int $staffId, ?string $reason = null, bool $force = false): void
    {
        $entry = self::find($queueId);
        if (!$entry) {
            throw new RuntimeException('Queue entry not found.');
        }
        $status = $entry['status'];
        if ($status === 'Cleared' || $status === 'Completed' || $status === 'Discharged') {
            throw new RuntimeException('This queue entry is already closed.');
        }
        if (!$force && !in_array($status, self::clearableStatuses(), true)) {
            throw new RuntimeException('Cannot clear status: ' . $status . '. Use force clear if needed.');
        }
        $pdo = Database::getConnection();
        $pdo->prepare(
            'UPDATE queue_entries SET status = :status, delayed_at = :cleared_at WHERE id = :id'
        )->execute([
            ':status' => 'Cleared',
            ':cleared_at' => date('c'),
            ':id' => $queueId,
        ]);
        $pid = (int)($entry['patient_row_id'] ?? $entry['patient_id'] ?? 0);
        if ($pid > 0) {
            Patient::updateStatus($pid, 'Registered');
        }
    }

    /** Clear several queue entries. Returns count cleared. */
    public static function clearMany(array $queueIds, int $staffId, ?string $reason = null, bool $force = false): int
    {
        $count = 0;
        foreach (array_unique(array_map('intval', $queueIds)) as $id) {
            if ($id <= 0) {
                continue;
            }
            try {
                self::clear($id, $staffId, $reason, $force);
                $count++;
            } catch (Throwable $e) {
                // skip failures
            }
        }
        return $count;
    }

    /** Clear all active queue entries visible on reception. */
    public static function clearAllActive(int $staffId, bool $force = true): int
    {
        $pdo = Database::getConnection();
        $statuses = self::clearableStatuses();
        $ph = implode(',', array_fill(0, count($statuses), '?'));
        $stmt = $pdo->prepare("SELECT id FROM queue_entries WHERE status IN ($ph)");
        $stmt->execute($statuses);
        $ids = array_map('intval', $stmt->fetchAll(\PDO::FETCH_COLUMN));
        return self::clearMany($ids, $staffId, 'bulk clear', $force);
    }
}
