<?php

require_once __DIR__ . '/../../src/Database.php';

class Medicine
{
    /** All active medicines, catalog-style, with their category name attached. */
    public static function allActive(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT m.*, c.name AS category_name
             FROM medicines m
             JOIN medicine_categories c ON c.id = m.category_id
             WHERE m.is_active = 1
             ORDER BY c.name ASC, m.name ASC'
        );
        return $stmt->fetchAll();
    }

    /** Everything, including deactivated medicines — for the admin/pharmacy inventory list. */
    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT m.*, c.name AS category_name
             FROM medicines m
             JOIN medicine_categories c ON c.id = m.category_id
             ORDER BY c.name ASC, m.name ASC'
        );
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT m.*, c.name AS category_name
             FROM medicines m
             JOIN medicine_categories c ON c.id = m.category_id
             WHERE m.id = :id'
        );
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public static function create(
        int $categoryId,
        string $name,
        string $dosageForm,
        int $quantity,
        float $unitPrice,
        ?string $expiryDate = null,
        int $reorderLevel = 10,
        ?float $costPrice = null
    ): int {
        $pdo = Database::getConnection();
        $now = date('c');
        $stmt = $pdo->prepare(
            'INSERT INTO medicines (category_id, name, dosage_form, quantity, reorder_level, unit_price, cost_price, expiry_date, status, is_active, created_at, updated_at)
             VALUES (:category_id, :name, :form, :qty, :reorder, :price, :cost, :expiry, :status, 1, :created, :updated)'
        );
        $stmt->execute([
            ':category_id' => $categoryId,
            ':name' => $name,
            ':form' => $dosageForm,
            ':qty' => $quantity,
            ':reorder' => $reorderLevel,
            ':price' => $unitPrice,
            ':cost' => $costPrice,
            ':expiry' => $expiryDate ?: null,
            ':status' => $quantity > 0 ? 'Available' : 'Out of Stock',
            ':created' => $now,
            ':updated' => $now,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(
        int $id,
        int $categoryId,
        string $name,
        string $dosageForm,
        float $unitPrice,
        ?string $expiryDate = null,
        int $reorderLevel = 10,
        ?float $costPrice = null
    ): void {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'UPDATE medicines
             SET category_id = :category_id, name = :name, dosage_form = :form,
                 unit_price = :price, cost_price = COALESCE(:cost, cost_price),
                 expiry_date = :expiry, reorder_level = :reorder, updated_at = :now
             WHERE id = :id'
        );
        $stmt->execute([
            ':category_id' => $categoryId,
            ':name' => $name,
            ':form' => $dosageForm,
            ':price' => $unitPrice,
            ':cost' => $costPrice,
            ':expiry' => $expiryDate ?: null,
            ':reorder' => $reorderLevel,
            ':now' => date('c'),
            ':id' => $id,
        ]);
    }

    /** Manual restock/adjustment by pharmacy or admin staff (e.g. new delivery received). */
    public static function adjustStock(int $id, int $delta): void
    {
        $pdo = Database::getConnection();
        $medicine = self::find($id);
        if (!$medicine) {
            throw new \Exception('Medicine not found.');
        }

        $newQuantity = max(0, (int)$medicine['quantity'] + $delta);
        $stmt = $pdo->prepare(
            'UPDATE medicines SET quantity = :qty, status = :status, updated_at = :now WHERE id = :id'
        );
        $stmt->execute([
            ':qty' => $newQuantity,
            ':status' => $newQuantity > 0 ? 'Available' : 'Out of Stock',
            ':now' => date('c'),
            ':id' => $id,
        ]);
    }

    /**
     * Records a completed procurement delivery: adds the purchased quantity
     * to stock and records the cost basis paid, for approved purchase
     * requests. Kept distinct from adjustStock() so restocking always has
     * a cost attached to it.
     */
    public static function receiveStock(int $id, int $quantity, float $unitCost): void
    {
        $pdo = Database::getConnection();
        $medicine = self::find($id);
        if (!$medicine) {
            throw new \Exception('Medicine not found.');
        }

        $newQuantity = (int)$medicine['quantity'] + $quantity;
        $stmt = $pdo->prepare(
            'UPDATE medicines SET quantity = :qty, cost_price = :cost, status = :status, updated_at = :now WHERE id = :id'
        );
        $stmt->execute([
            ':qty' => $newQuantity,
            ':cost' => $unitCost,
            ':status' => $newQuantity > 0 ? 'Available' : 'Out of Stock',
            ':now' => date('c'),
            ':id' => $id,
        ]);
    }

    /**
     * Reduces stock when a prescription tied to this medicine is dispensed.
     * Throws if there isn't enough stock on hand, so pharmacy can't oversell
     * what the inventory says it has.
     */
    public static function decrementStock(int $id, int $quantity): void
    {
        $pdo = Database::getConnection();
        $medicine = self::find($id);
        if (!$medicine) {
            throw new \Exception('Medicine not found in inventory.');
        }
        if ((int)$medicine['quantity'] < $quantity) {
            throw new \Exception(
                'Insufficient stock for ' . $medicine['name'] . '. Only ' . $medicine['quantity'] . ' unit(s) available.'
            );
        }

        $newQuantity = (int)$medicine['quantity'] - $quantity;
        $stmt = $pdo->prepare(
            'UPDATE medicines SET quantity = :qty, status = :status, updated_at = :now WHERE id = :id'
        );
        $stmt->execute([
            ':qty' => $newQuantity,
            ':status' => $newQuantity > 0 ? 'Available' : 'Out of Stock',
            ':now' => date('c'),
            ':id' => $id,
        ]);
    }

    public static function setActive(int $id, bool $active): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE medicines SET is_active = :active, updated_at = :now WHERE id = :id');
        $stmt->execute([':active' => $active ? 1 : 0, ':now' => date('c'), ':id' => $id]);
    }

    /** Medicines at or below their reorder level — for low-stock warnings. */
    public static function lowStock(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT m.*, c.name AS category_name
             FROM medicines m
             JOIN medicine_categories c ON c.id = m.category_id
             WHERE m.is_active = 1 AND m.quantity <= m.reorder_level
             ORDER BY m.quantity ASC'
        );
        return $stmt->fetchAll();
    }

    /** Medicines already past their expiry date. */
    public static function expired(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT m.*, c.name AS category_name
             FROM medicines m
             JOIN medicine_categories c ON c.id = m.category_id
             WHERE m.is_active = 1 AND m.expiry_date IS NOT NULL AND m.expiry_date < :today
             ORDER BY m.expiry_date ASC'
        );
        $stmt->execute([':today' => date('Y-m-d')]);
        return $stmt->fetchAll();
    }

    /** Medicines expiring within the next 60 days but not yet expired. */
    public static function expiringSoon(int $withinDays = 60): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT m.*, c.name AS category_name
             FROM medicines m
             JOIN medicine_categories c ON c.id = m.category_id
             WHERE m.is_active = 1 AND m.expiry_date IS NOT NULL
               AND m.expiry_date >= :today AND m.expiry_date <= :cutoff
             ORDER BY m.expiry_date ASC'
        );
        $today = new \DateTime('today');
        $cutoff = (clone $today)->modify("+{$withinDays} days");
        $stmt->execute([':today' => $today->format('Y-m-d'), ':cutoff' => $cutoff->format('Y-m-d')]);
        return $stmt->fetchAll();
    }

    /** Other in-stock medicines from the same treatment category — used to suggest a substitute. */
    public static function alternativesInCategory(int $categoryId, int $excludeMedicineId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT * FROM medicines
             WHERE category_id = :category_id AND id != :exclude_id
               AND is_active = 1 AND status = 'Available' AND quantity > 0
             ORDER BY quantity DESC"
        );
        $stmt->execute([':category_id' => $categoryId, ':exclude_id' => $excludeMedicineId]);
        return $stmt->fetchAll();
    }

    /**
     * Soft-delete by deactivating, or hard-delete when never used in prescriptions.
     * Prefer soft-delete to preserve history.
     */
    public static function delete(int $id, bool $hard = false): void
    {
        $pdo = Database::getConnection();
        $medicine = self::find($id);
        if (!$medicine) {
            throw new \Exception('Medicine not found.');
        }
        if (!$hard) {
            self::setActive($id, false);
            return;
        }
        $used = $pdo->prepare('SELECT COUNT(*) AS c FROM prescriptions WHERE medicine_id = :id');
        $used->execute([':id' => $id]);
        if ((int)$used->fetch()['c'] > 0) {
            throw new \Exception('This medicine is linked to prescriptions and cannot be permanently deleted. It was deactivated instead.');
        }
        $pdo->prepare('DELETE FROM medicines WHERE id = :id')->execute([':id' => $id]);
    }

    /**
     * Live catalog search for clinicians — name, form, or category.
     * Returns active medicines with stock signals for availability UI.
     */
    public static function searchCatalog(string $query, int $limit = 24): array
    {
        $q = trim($query);
        if ($q === '' || mb_strlen($q) < 1) {
            return [];
        }
        $pdo = Database::getConnection();
        $like = '%' . $q . '%';
        $stmt = $pdo->prepare(
            'SELECT m.*, c.name AS category_name
             FROM medicines m
             JOIN medicine_categories c ON c.id = m.category_id
             WHERE m.is_active = 1
               AND (m.name LIKE :q OR m.dosage_form LIKE :q2 OR c.name LIKE :q3)
             ORDER BY
               CASE WHEN m.name LIKE :exact THEN 0
                    WHEN m.name LIKE :prefix THEN 1
                    ELSE 2 END,
               m.name ASC
             LIMIT ' . (int)$limit
        );
        $stmt->execute([
            ':q' => $like,
            ':q2' => $like,
            ':q3' => $like,
            ':exact' => $q,
            ':prefix' => $q . '%',
        ]);
        return $stmt->fetchAll();
    }
}
