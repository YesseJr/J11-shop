<?php

require_once __DIR__ . '/../../src/Database.php';

class RecoveryLog
{
    public static function record(
        int $adminStaffId,
        int $patientId,
        ?int $consultationId,
        ?int $invoiceId,
        string $action,
        ?string $previousStage,
        ?string $newStage,
        ?string $reason = null,
        ?string $details = null
    ): int {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO recovery_logs
                (admin_staff_id, patient_id, consultation_id, invoice_id, action,
                 previous_stage, new_stage, reason, details, created_at)
             VALUES
                (:admin, :pid, :cid, :iid, :action, :prev, :new, :reason, :details, :now)'
        );
        $stmt->execute([
            ':admin' => $adminStaffId,
            ':pid' => $patientId,
            ':cid' => $consultationId,
            ':iid' => $invoiceId,
            ':action' => $action,
            ':prev' => $previousStage,
            ':new' => $newStage,
            ':reason' => $reason,
            ':details' => $details,
            ':now' => date('c'),
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function search(?string $q = null, int $limit = 100, int $offset = 0): array
    {
        $pdo = Database::getConnection();
        $sql = 'SELECT r.*, s.full_name AS admin_name, p.patient_id AS patient_code, p.full_name AS patient_name
                FROM recovery_logs r
                JOIN staff s ON s.id = r.admin_staff_id
                JOIN patients p ON p.id = r.patient_id
                WHERE 1=1';
        $params = [];
        if ($q !== null && $q !== '') {
            $sql .= ' AND (p.full_name LIKE :q OR p.patient_id LIKE :q2 OR r.action LIKE :q3 OR r.reason LIKE :q4 OR s.full_name LIKE :q5)';
            $like = '%' . $q . '%';
            $params = [':q' => $like, ':q2' => $like, ':q3' => $like, ':q4' => $like, ':q5' => $like];
        }
        $sql .= ' ORDER BY r.created_at DESC LIMIT ' . (int)$limit . ' OFFSET ' . (int)$offset;
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function count(?string $q = null): int
    {
        $pdo = Database::getConnection();
        $sql = 'SELECT COUNT(*) FROM recovery_logs r
                JOIN patients p ON p.id = r.patient_id
                JOIN staff s ON s.id = r.admin_staff_id WHERE 1=1';
        $params = [];
        if ($q !== null && $q !== '') {
            $sql .= ' AND (p.full_name LIKE :q OR p.patient_id LIKE :q2 OR r.action LIKE :q3 OR r.reason LIKE :q4 OR s.full_name LIKE :q5)';
            $like = '%' . $q . '%';
            $params = [':q' => $like, ':q2' => $like, ':q3' => $like, ':q4' => $like, ':q5' => $like];
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    }
}
