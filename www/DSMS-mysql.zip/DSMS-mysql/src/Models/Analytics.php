<?php

require_once __DIR__ . '/../../src/Database.php';

/**
 * Read-only analytics. Does not alter billing or clinical data.
 */
class Analytics
{
    public static function parseRange(?string $from, ?string $to, string $preset = 'day'): array
    {
        $now = new \DateTimeImmutable('now');
        if ($preset === 'week') {
            $fromDt = $now->modify('monday this week')->setTime(0, 0, 0);
            $toDt = $now->setTime(23, 59, 59);
        } elseif ($preset === 'month') {
            $fromDt = $now->modify('first day of this month')->setTime(0, 0, 0);
            $toDt = $now->setTime(23, 59, 59);
        } elseif ($preset === 'year') {
            $fromDt = $now->modify('first day of January this year')->setTime(0, 0, 0);
            $toDt = $now->setTime(23, 59, 59);
        } else {
            $fromDt = $now->setTime(0, 0, 0);
            $toDt = $now->setTime(23, 59, 59);
        }
        if ($from) {
            try {
                $fromDt = new \DateTimeImmutable($from);
            } catch (\Throwable $e) {
            }
        }
        if ($to) {
            try {
                $toDt = new \DateTimeImmutable($to);
            } catch (\Throwable $e) {
            }
        }
        return [$fromDt->format('c'), $toDt->format('c'), $fromDt, $toDt];
    }

    public static function dashboardStats(string $role): array
    {
        $pdo = Database::getConnection();
        $todayStart = (new \DateTimeImmutable('today'))->format('c');
        $stats = [];

        try {
            $stats['today_patients'] = (int)$pdo->query(
                "SELECT COUNT(*) FROM patients WHERE created_at >= '{$todayStart}'"
            )->fetchColumn();
        } catch (\Throwable $e) {
            $stats['today_patients'] = 0;
        }

        $stats['active_visits'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM consultations WHERE treatment_finalized = 0"
        )->fetchColumn();

        $stats['pending_bills'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM invoices WHERE status IN ('Pending','Partially Paid')"
        )->fetchColumn();

        $stats['outstanding_balance'] = (float)$pdo->query(
            "SELECT COALESCE(SUM(balance),0) FROM invoices WHERE status IN ('Pending','Partially Paid')"
        )->fetchColumn();

        $stats['paid_today'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM invoices WHERE status = 'Paid' AND updated_at >= '{$todayStart}'"
        )->fetchColumn();

        $stats['paid_today_amount'] = (float)$pdo->query(
            "SELECT COALESCE(SUM(amount_paid),0) FROM payment_transactions WHERE payment_date >= '{$todayStart}' AND payment_status = 'Completed'"
        )->fetchColumn();

        $stats['waiting_consultation'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM queue_entries WHERE status IN ('Waiting','Waiting for Consultation')"
        )->fetchColumn();

        $stats['lab_pending'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM lab_requests l LEFT JOIN lab_results r ON r.lab_request_id = l.id WHERE r.id IS NULL"
        )->fetchColumn();

        $stats['lab_completed_today'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM lab_results WHERE uploaded_at >= '{$todayStart}'"
        )->fetchColumn();

        $stats['pharmacy_pending'] = (int)$pdo->query(
            "SELECT COUNT(DISTINCT p.id) FROM prescriptions p
             JOIN invoices i ON i.consultation_id = p.consultation_id AND i.status = 'Paid'
             LEFT JOIN dispensations d ON d.prescription_id = p.id
             WHERE p.status = 'Finalized' AND d.id IS NULL"
        )->fetchColumn();

        $stats['dispensed_today'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM dispensations WHERE dispensed_at >= '{$todayStart}'"
        )->fetchColumn();

        require_once __DIR__ . '/Medicine.php';
        try {
            $stats['low_stock'] = count(Medicine::lowStock());
            $stats['expired'] = count(Medicine::expired());
        } catch (\Throwable $e) {
            $stats['low_stock'] = 0;
            $stats['expired'] = 0;
        }

        require_once __DIR__ . '/Workflow.php';
        try {
            $stats['lost_patients'] = count(Workflow::detectLostPatients());
            $stats['escalations'] = count(Workflow::detectEscalations());
        } catch (\Throwable $e) {
            $stats['lost_patients'] = 0;
            $stats['escalations'] = 0;
        }

        $stats['consultations_today'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM consultations WHERE created_at >= '{$todayStart}'"
        )->fetchColumn();

        $stats['results_ready'] = (int)$pdo->query(
            "SELECT COUNT(DISTINCT c.id) FROM consultations c
             JOIN lab_requests l ON l.consultation_id = c.id
             JOIN lab_results r ON r.lab_request_id = l.id
             WHERE c.treatment_finalized = 0"
        )->fetchColumn();

        return $stats;
    }

    public static function workflowTiming(?string $from = null, ?string $to = null, string $preset = 'day'): array
    {
        [$fromIso, $toIso] = self::parseRange($from, $to, $preset);
        $pdo = Database::getConnection();

        // Approximate stage times from available timestamps
        $rows = $pdo->prepare(
            "SELECT c.id, c.created_at AS consult_start, c.finalized_at,
                    i.generated_at, i.updated_at AS invoice_updated,
                    (SELECT MIN(d.dispensed_at) FROM dispensations d
                     JOIN prescriptions p ON p.id = d.prescription_id
                     WHERE p.consultation_id = c.id) AS first_dispense,
                    (SELECT MIN(r.uploaded_at) FROM lab_results r
                     JOIN lab_requests l ON l.id = r.lab_request_id
                     WHERE l.consultation_id = c.id) AS first_lab_result,
                    (SELECT MIN(l.created_at) FROM lab_requests l WHERE l.consultation_id = c.id) AS first_lab_request
             FROM consultations c
             LEFT JOIN invoices i ON i.consultation_id = c.id
             WHERE c.created_at >= :from AND c.created_at <= :to"
        );
        $rows->execute([':from' => $fromIso, ':to' => $toIso]);
        $data = $rows->fetchAll();

        $sums = ['consult' => [], 'lab' => [], 'billing' => [], 'pharmacy' => []];
        foreach ($data as $r) {
            $cStart = strtotime($r['consult_start'] ?: '');
            if ($r['finalized_at'] && $cStart) {
                $sums['consult'][] = max(0, strtotime($r['finalized_at']) - $cStart) / 60;
            }
            if ($r['first_lab_request'] && $r['first_lab_result']) {
                $sums['lab'][] = max(0, strtotime($r['first_lab_result']) - strtotime($r['first_lab_request'])) / 60;
            }
            if ($r['generated_at'] && $r['invoice_updated'] && ($r['invoice_updated'] !== $r['generated_at'])) {
                $sums['billing'][] = max(0, strtotime($r['invoice_updated']) - strtotime($r['generated_at'])) / 60;
            }
            if ($r['invoice_updated'] && $r['first_dispense']) {
                $sums['pharmacy'][] = max(0, strtotime($r['first_dispense']) - strtotime($r['invoice_updated'])) / 60;
            }
        }

        $avg = static function (array $arr): float {
            return empty($arr) ? 0.0 : array_sum($arr) / count($arr);
        };

        return [
            'avg_consultation_minutes' => round($avg($sums['consult']), 1),
            'avg_lab_minutes' => round($avg($sums['lab']), 1),
            'avg_billing_minutes' => round($avg($sums['billing']), 1),
            'avg_pharmacy_minutes' => round($avg($sums['pharmacy']), 1),
            'total_visits' => count($data),
            'from' => $fromIso,
            'to' => $toIso,
        ];
    }

    public static function dailyPatients(?string $from = null, ?string $to = null, string $preset = 'week'): array
    {
        [$fromIso, $toIso] = self::parseRange($from, $to, $preset);
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT DATE(created_at) AS day, COUNT(*) AS cnt
             FROM patients
             WHERE created_at >= :from AND created_at <= :to
             GROUP BY DATE(created_at)
             ORDER BY day ASC"
        );
        // created_at is ISO string — DATE() may not work; use substring
        try {
            $stmt->execute([':from' => $fromIso, ':to' => $toIso]);
            return $stmt->fetchAll();
        } catch (\Throwable $e) {
            $stmt = $pdo->prepare(
                "SELECT SUBSTRING(created_at,1,10) AS day, COUNT(*) AS cnt
                 FROM patients
                 WHERE created_at >= :from AND created_at <= :to
                 GROUP BY SUBSTRING(created_at,1,10)
                 ORDER BY day ASC"
            );
            $stmt->execute([':from' => $fromIso, ':to' => $toIso]);
            return $stmt->fetchAll();
        }
    }

    public static function revenueByDay(?string $from = null, ?string $to = null, string $preset = 'month'): array
    {
        [$fromIso, $toIso] = self::parseRange($from, $to, $preset);
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT SUBSTRING(payment_date,1,10) AS day, COALESCE(SUM(amount_paid),0) AS total
             FROM payment_transactions
             WHERE payment_status = 'Completed' AND payment_date >= :from AND payment_date <= :to
             GROUP BY SUBSTRING(payment_date,1,10)
             ORDER BY day ASC"
        );
        $stmt->execute([':from' => $fromIso, ':to' => $toIso]);
        return $stmt->fetchAll();
    }

    public static function recoveryCount(?string $from = null, ?string $to = null, string $preset = 'month'): int
    {
        [$fromIso, $toIso] = self::parseRange($from, $to, $preset);
        $pdo = Database::getConnection();
        try {
            $stmt = $pdo->prepare(
                'SELECT COUNT(*) FROM recovery_logs WHERE created_at >= :from AND created_at <= :to'
            );
            $stmt->execute([':from' => $fromIso, ':to' => $toIso]);
            return (int)$stmt->fetchColumn();
        } catch (\Throwable $e) {
            return 0;
        }
    }
}
