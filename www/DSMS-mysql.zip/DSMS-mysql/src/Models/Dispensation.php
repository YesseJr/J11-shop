<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Patient.php';
require_once __DIR__ . '/Prescription.php';
require_once __DIR__ . '/MedicationHistory.php';
require_once __DIR__ . '/Billing.php';
require_once __DIR__ . '/AuditLog.php';
require_once __DIR__ . '/Medicine.php';
require_once __DIR__ . '/Budget.php';

class Dispensation
{
    public static function record(int $prescriptionId, int $pharmacyStaffId, int $quantity, ?string $note = null): int
    {
        // Business rule: medicines cannot be dispensed until the invoice
        // covering this prescription is fully paid (cash/card/mobile
        // money/bank transfer) or insurance has covered it in full.
        if (!Billing::isPrescriptionPayable($prescriptionId)) {
            throw new \Exception('Payment has not been confirmed for this prescription yet. It cannot be dispensed until the patient\'s bill is paid or fully covered by insurance.');
        }

        $prescription = Prescription::find($prescriptionId);
        if (!$prescription) {
            throw new \Exception('Prescription not found.');
        }

        // Pharmacy must dispense the exact quantity the doctor prescribed.
        $prescribedQty = max(1, (int)($prescription['quantity'] ?? 0));
        if ($quantity !== $prescribedQty) {
            $quantity = $prescribedQty;
        }

        // If this prescription was written against a catalog medicine,
        // reduce inventory stock before recording the dispensation — if
        // there isn't enough stock on hand this throws and nothing is saved.
        // Note: this no longer touches the pharmacy budget. Budget spend
        // now happens when a MedicinePurchaseRequest is approved (real
        // procurement cost), not when stock is dispensed to a patient
        // (that's revenue, tracked via Billing instead).
        if (!empty($prescription['medicine_id'])) {
            Medicine::decrementStock((int)$prescription['medicine_id'], $quantity);
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO dispensations (prescription_id, pharmacy_staff_id, quantity, note, dispensed_at)
             VALUES (:prescription_id, :pharmacy_staff_id, :quantity, :note, :dispensed_at)'
        );
        $stmt->execute([
            ':prescription_id' => $prescriptionId,
            ':pharmacy_staff_id' => $pharmacyStaffId,
            ':quantity' => $quantity,
            ':note' => $note,
            ':dispensed_at' => date('c'),
        ]);
        $dispensationId = (int)$pdo->lastInsertId();

        if ($prescription) {
            Patient::updateStatus((int)$prescription['patient_id'], 'Medicine Dispensed');
            try {
                MedicationHistory::record((int)$prescription['patient_id'], $prescriptionId, $pharmacyStaffId, $quantity, $note ?: null, date('c'));
            } catch (\Exception $e) {
                // ignore history failures but keep dispense successful
            }
        }

        AuditLog::log($pharmacyStaffId, 'dispensations', $dispensationId, 'dispense', "prescription={$prescriptionId} qty={$quantity}");

        return $dispensationId;
    }

    /** Prescriptions the pharmacy can see as "pending" but not yet payable. */
    public static function getPendingPaymentPrescriptions(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            "SELECT p.*, pt.patient_id AS patient_code, pt.full_name
             FROM prescriptions p
             JOIN patients pt ON pt.id = p.patient_id
             LEFT JOIN dispensations d ON d.prescription_id = p.id
             LEFT JOIN invoice_items ii ON ii.service_type = 'Pharmacy' AND ii.reference_id = p.id
             LEFT JOIN invoices i ON i.id = ii.invoice_id
             WHERE d.id IS NULL AND (i.status IS NULL OR i.status != 'Paid')
             ORDER BY p.created_at DESC"
        );
        return $stmt->fetchAll();
    }

    /** Prescriptions that are paid and ready to actually dispense. */
    public static function getPayableAndPending(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            "SELECT p.*, pt.patient_id AS patient_code, pt.full_name
             FROM prescriptions p
             JOIN patients pt ON pt.id = p.patient_id
             LEFT JOIN dispensations d ON d.prescription_id = p.id
             JOIN invoice_items ii ON ii.service_type = 'Pharmacy' AND ii.reference_id = p.id
             JOIN invoices i ON i.id = ii.invoice_id
             WHERE d.id IS NULL AND i.status = 'Paid'
             ORDER BY p.created_at DESC"
        );
        return $stmt->fetchAll();
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT d.*, p.medication, pt.patient_id AS patient_code, pt.full_name AS patient_name, s.full_name AS staff_name
             FROM dispensations d
             JOIN prescriptions p ON p.id = d.prescription_id
             JOIN patients pt ON pt.id = p.patient_id
             JOIN staff s ON s.id = d.pharmacy_staff_id
             ORDER BY d.dispensed_at DESC'
        );
        return $stmt->fetchAll();
    }
}