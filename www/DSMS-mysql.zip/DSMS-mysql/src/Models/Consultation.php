<?php

require_once __DIR__ . '/../../src/Database.php';

class Consultation
{
    public static function create(int $patientId, int $doctorId, string $symptoms, string $examination, string $diagnosis, string $status, ?string $note = null): int
    {
        $pdo = Database::getConnection();
        $now = date('c');
        $stmt = $pdo->prepare(
            'INSERT INTO consultations (patient_id, doctor_staff_id, symptoms, examination, diagnosis, note, status, created_at)
             VALUES (:patient_id, :doctor_staff_id, :symptoms, :examination, :diagnosis, :note, :status, :created_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':doctor_staff_id' => $doctorId,
            ':symptoms' => $symptoms,
            ':examination' => $examination,
            ':diagnosis' => $diagnosis,
            ':note' => $note,
            ':status' => $status,
            ':created_at' => $now,
        ]);

        $id = (int)$pdo->lastInsertId();

        // Defensive fallback: on some setups (e.g. certain proxy/connection
        // pool configurations) lastInsertId() can come back empty even
        // though the row was written. If that happens, look the row back
        // up by its own created_at/patient/doctor instead of silently
        // returning 0 to the caller (which previously caused a confusing
        // FK violation in LabRequest::create()).
        if ($id <= 0) {
            $lookup = $pdo->prepare(
                'SELECT id FROM consultations
                 WHERE patient_id = :pid AND doctor_staff_id = :did AND created_at = :created_at
                 ORDER BY id DESC LIMIT 1'
            );
            $lookup->execute([':pid' => $patientId, ':did' => $doctorId, ':created_at' => $now]);
            $row = $lookup->fetch();
            $id = $row ? (int)$row['id'] : 0;
        }

        Patient::updateStatus($patientId, self::normalizeStatus($status));
        return $id;
    }

    private static function normalizeStatus(string $status): string
    {
        return match ($status) {
            'Healthy' => 'Consultation Completed',
            'Lab Investigation Required' => 'Lab Investigation Required',
            'Medicine Required' => 'Prescription Issued',
            'Results Reviewed Healthy' => 'Visit Completed',
            'Results Reviewed Medicine Required' => 'Prescription Issued',
            'Results Reviewed Referred' => 'Referred',
            default => $status,
        };
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM consultations WHERE id = :id');
        $stmt->execute([':id' => $id]);

        return $stmt->fetch() ?: null;
    }

    /** Most recent consultation for a patient — used to link prescriptions
     *  and billing back to "which visit is this". */
    public static function latestForPatient(int $patientId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM consultations WHERE patient_id = :pid ORDER BY created_at DESC LIMIT 1'
        );
        $stmt->execute([':pid' => $patientId]);
        return $stmt->fetch() ?: null;
    }
}