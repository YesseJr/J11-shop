<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Medicine.php';
require_once __DIR__ . '/Budget.php';
require_once __DIR__ . '/AuditLog.php';

/**
 * Pharmacy submits a request to restock a catalog medicine at a quoted
 * cost. Admin approves or rejects it. Approval is the moment stock and
 * budget actually move — nothing changes on submission alone.
 */
class MedicinePurchaseRequest
{
    public static function create(int $medicineId, int $requestedByStaffId, int $quantity, float $unitCost, ?string $notes = null): int
    {
        if ($quantity <= 0 || $unitCost <= 0) {
            throw new \Exception('Quantity and unit cost must be greater than zero.');
        }

        $medicine = Medicine::find($medicineId);
        if (!$medicine) {
            throw new \Exception('Medicine not found in catalog.');
        }

        $pdo = Database::getConnection();
        $totalCost = round($quantity * $unitCost, 2);
        $stmt = $pdo->prepare(
            'INSERT INTO medicine_purchase_requests
                (medicine_id, quantity, unit_cost, total_cost, status, notes, requested_by_staff_id, requested_at)
             VALUES (:medicine_id, :quantity, :unit_cost, :total_cost, "Pending", :notes, :staff_id, :requested_at)'
        );
        $stmt->execute([
            ':medicine_id' => $medicineId,
            ':quantity' => $quantity,
            ':unit_cost' => $unitCost,
            ':total_cost' => $totalCost,
            ':notes' => $notes ?: null,
            ':staff_id' => $requestedByStaffId,
            ':requested_at' => date('c'),
        ]);

        $id = (int)$pdo->lastInsertId();
        AuditLog::log($requestedByStaffId, 'medicine_purchase_requests', $id, 'request', "medicine={$medicineId} qty={$quantity} unit_cost={$unitCost}");

        return $id;
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT r.*, m.name AS medicine_name, m.dosage_form, s.full_name AS requested_by_name
             FROM medicine_purchase_requests r
             JOIN medicines m ON m.id = r.medicine_id
             JOIN staff s ON s.id = r.requested_by_staff_id
             WHERE r.id = :id'
        );
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public static function getPending(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT r.*, m.name AS medicine_name, m.dosage_form, s.full_name AS requested_by_name
             FROM medicine_purchase_requests r
             JOIN medicines m ON m.id = r.medicine_id
             JOIN staff s ON s.id = r.requested_by_staff_id
             WHERE r.status = "Pending"
             ORDER BY r.requested_at ASC'
        );
        return $stmt->fetchAll();
    }

    public static function getAll(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT r.*, m.name AS medicine_name, m.dosage_form, s.full_name AS requested_by_name,
                    d.full_name AS decided_by_name
             FROM medicine_purchase_requests r
             JOIN medicines m ON m.id = r.medicine_id
             JOIN staff s ON s.id = r.requested_by_staff_id
             LEFT JOIN staff d ON d.id = r.decided_by_staff_id
             ORDER BY r.requested_at DESC'
        );
        return $stmt->fetchAll();
    }

    public static function getForStaff(int $staffId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT r.*, m.name AS medicine_name, m.dosage_form
             FROM medicine_purchase_requests r
             JOIN medicines m ON m.id = r.medicine_id
             WHERE r.requested_by_staff_id = :staff_id
             ORDER BY r.requested_at DESC'
        );
        $stmt->execute([':staff_id' => $staffId]);
        return $stmt->fetchAll();
    }

    /**
     * Approves the request: deducts the total cost from the pharmacy
     * budget and adds the stock. Throws (and changes nothing) if the
     * request isn't pending, or if approving would push pharmacy spend
     * past its allocated budget — the admin has to raise the budget
     * first rather than silently overspending it.
     */
    public static function approve(int $id, int $decidedByStaffId): void
    {
        $request = self::find($id);
        if (!$request || $request['status'] !== 'Pending') {
            throw new \Exception('This request is no longer pending.');
        }

        $totals = Budget::departmentTotals('pharmacy');
        if ($totals['remaining'] < (float)$request['total_cost']) {
            throw new \Exception(
                'Approving this purchase (TZS ' . number_format((float)$request['total_cost'], 2) . ') would exceed the pharmacy budget\'s remaining balance (TZS ' . number_format($totals['remaining'], 2) . '). Raise the pharmacy budget allocation first.'
            );
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();
        try {
            Medicine::receiveStock((int)$request['medicine_id'], (int)$request['quantity'], (float)$request['unit_cost']);
            Budget::recordExpenditure('pharmacy', (float)$request['total_cost']);

            $stmt = $pdo->prepare(
                'UPDATE medicine_purchase_requests SET status = "Approved", decided_by_staff_id = :staff_id, decided_at = :decided_at WHERE id = :id'
            );
            $stmt->execute([':staff_id' => $decidedByStaffId, ':decided_at' => date('c'), ':id' => $id]);

            $pdo->commit();
        } catch (\Exception $e) {
            $pdo->rollBack();
            throw $e;
        }

        AuditLog::log($decidedByStaffId, 'medicine_purchase_requests', $id, 'approve', "medicine={$request['medicine_id']} total_cost={$request['total_cost']}");
    }

    public static function reject(int $id, int $decidedByStaffId, ?string $reason = null): void
    {
        $request = self::find($id);
        if (!$request || $request['status'] !== 'Pending') {
            throw new \Exception('This request is no longer pending.');
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'UPDATE medicine_purchase_requests SET status = "Rejected", decided_by_staff_id = :staff_id, decision_note = :note, decided_at = :decided_at WHERE id = :id'
        );
        $stmt->execute([':staff_id' => $decidedByStaffId, ':note' => $reason ?: null, ':decided_at' => date('c'), ':id' => $id]);

        AuditLog::log($decidedByStaffId, 'medicine_purchase_requests', $id, 'reject', $reason ?: '');
    }
}
