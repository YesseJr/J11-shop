<?php

require_once __DIR__ . '/../../src/Database.php';

class Vital
{
    public static function record(int $patientId, array $data): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO vitals (patient_id, weight, height, temperature, blood_pressure, pulse_rate, recorded_at)
             VALUES (:patient_id, :weight, :height, :temperature, :blood_pressure, :pulse_rate, :recorded_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':weight' => $data['weight'],
            ':height' => $data['height'],
            ':temperature' => $data['temperature'],
            ':blood_pressure' => $data['blood_pressure'],
            ':pulse_rate' => $data['pulse_rate'],
            ':recorded_at' => date('c'),
        ]);

        Patient::updateStatus($patientId, 'Vitals Recorded');
        return (int)$pdo->lastInsertId();
    }

    public static function latestForPatient(int $patientId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM vitals WHERE patient_id = :pid ORDER BY recorded_at DESC, id DESC LIMIT 1'
        );
        $stmt->execute([':pid' => $patientId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function forPatient(int $patientId, int $limit = 5): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM vitals WHERE patient_id = :pid ORDER BY recorded_at DESC, id DESC LIMIT ' . (int)$limit
        );
        $stmt->execute([':pid' => $patientId]);
        return $stmt->fetchAll();
    }
}
