<?php

require_once __DIR__ . '/../../src/Database.php';

class Notification
{
    public static function create(
        ?int $staffId,
        ?string $roleTarget,
        string $type,
        string $title,
        string $message,
        ?string $linkAction = null,
        ?int $entityId = null,
        string $priority = 'normal'
    ): int {
        $pdo = Database::getConnection();
        $pri = in_array($priority, ['low','normal','high','urgent'], true) ? $priority : 'normal';
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO notifications (staff_id, role_target, type, title, message, link_action, entity_id, priority, is_read, created_at)
                 VALUES (:staff, :role, :type, :title, :msg, :link, :eid, :pri, 0, :now)'
            );
            $stmt->execute([
                ':staff' => $staffId, ':role' => $roleTarget, ':type' => $type, ':title' => $title,
                ':msg' => $message, ':link' => $linkAction, ':eid' => $entityId, ':pri' => $pri, ':now' => date('c'),
            ]);
        } catch (\Throwable $e) {
            $stmt = $pdo->prepare(
                'INSERT INTO notifications (staff_id, role_target, type, title, message, link_action, entity_id, is_read, created_at)
                 VALUES (:staff, :role, :type, :title, :msg, :link, :eid, 0, :now)'
            );
            $stmt->execute([
                ':staff' => $staffId, ':role' => $roleTarget, ':type' => $type, ':title' => $title,
                ':msg' => $message, ':link' => $linkAction, ':eid' => $entityId, ':now' => date('c'),
            ]);
        }
        return (int)$pdo->lastInsertId();
    }

    /** Notify every active staff member with a given role. */
    public static function notifyRole(string $role, string $type, string $title, string $message, ?string $linkAction = null, ?int $entityId = null, string $priority = 'normal'): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT id FROM staff WHERE role = :role AND is_active = 1');
        $stmt->execute([':role' => $role]);
        $ids = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        if (empty($ids)) {
            // Still store a role-broadcast row so dashboards can show it
            self::create(null, $role, $type, $title, $message, $linkAction, $entityId, $priority);
            return;
        }
        foreach ($ids as $id) {
            self::create((int)$id, $role, $type, $title, $message, $linkAction, $entityId, $priority);
        }
    }

    public static function forStaff(int $staffId, int $limit = 30): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM notifications
             WHERE staff_id = :sid OR (staff_id IS NULL AND role_target = (SELECT role FROM staff WHERE id = :sid2))
             ORDER BY created_at DESC LIMIT ' . (int)$limit
        );
        $stmt->execute([':sid' => $staffId, ':sid2' => $staffId]);
        return $stmt->fetchAll();
    }

    public static function unreadCount(int $staffId): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM notifications
             WHERE is_read = 0 AND (
                staff_id = :sid
                OR (staff_id IS NULL AND role_target = (SELECT role FROM staff WHERE id = :sid2))
             )'
        );
        $stmt->execute([':sid' => $staffId, ':sid2' => $staffId]);
        return (int)$stmt->fetchColumn();
    }

    public static function markRead(int $id, int $staffId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'UPDATE notifications SET is_read = 1, read_at = :now
             WHERE id = :id AND (staff_id = :sid OR staff_id IS NULL)'
        );
        $stmt->execute([':now' => date('c'), ':id' => $id, ':sid' => $staffId]);
    }

    public static function markAllRead(int $staffId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'UPDATE notifications SET is_read = 1, read_at = :now
             WHERE is_read = 0 AND (
                staff_id = :sid
                OR (staff_id IS NULL AND role_target = (SELECT role FROM staff WHERE id = :sid2))
             )'
        );
        $stmt->execute([':now' => date('c'), ':sid' => $staffId, ':sid2' => $staffId]);
    }
}
