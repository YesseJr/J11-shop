<?php

require_once __DIR__ . '/../../src/Database.php';

class MedicineCategory
{
    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT * FROM medicine_categories ORDER BY name ASC');
        return $stmt->fetchAll();
    }

    public static function allWithMedicineCounts(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT c.*, COUNT(m.id) AS medicine_count
             FROM medicine_categories c
             LEFT JOIN medicines m ON m.category_id = c.id AND m.is_active = 1
             GROUP BY c.id
             ORDER BY c.name ASC'
        );
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM medicine_categories WHERE id = :id');
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public static function create(string $name, ?string $description = null): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO medicine_categories (name, description, created_at) VALUES (:name, :description, :created_at)'
        );
        $stmt->execute([
            ':name' => $name,
            ':description' => $description ?: null,
            ':created_at' => date('c'),
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, string $name, ?string $description = null): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'UPDATE medicine_categories SET name = :name, description = :description WHERE id = :id'
        );
        $stmt->execute([
            ':name' => $name,
            ':description' => $description ?: null,
            ':id' => $id,
        ]);
    }

    /** Deletes category only when no medicines reference it. */
    public static function delete(int $id): void
    {
        $pdo = Database::getConnection();
        $cnt = $pdo->prepare('SELECT COUNT(*) AS c FROM medicines WHERE category_id = :id');
        $cnt->execute([':id' => $id]);
        if ((int)$cnt->fetch()['c'] > 0) {
            throw new RuntimeException('Cannot delete category while medicines still use it. Move or remove those medicines first.');
        }
        $pdo->prepare('DELETE FROM medicine_categories WHERE id = :id')->execute([':id' => $id]);
    }
}
