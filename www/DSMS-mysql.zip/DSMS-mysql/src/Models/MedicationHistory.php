<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Patient.php';

class MedicationHistory
{
    public static function record(int $patientId, ?int $prescriptionId, int $pharmacyStaffId, int $quantity, ?string $note = null, ?string $dispensedAt = null): int
    {
        $pdo = Database::getConnection();
        $now = date('c');
        $dispensedAt = $dispensedAt ?: date('c');

        $stmt = $pdo->prepare(
            'INSERT INTO medication_history (patient_id, prescription_id, pharmacy_staff_id, quantity, note, dispensed_at, created_at)
             VALUES (:patient_id, :prescription_id, :pharmacy_staff_id, :quantity, :note, :dispensed_at, :created_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':prescription_id' => $prescriptionId,
            ':pharmacy_staff_id' => $pharmacyStaffId,
            ':quantity' => $quantity,
            ':note' => $note,
            ':dispensed_at' => $dispensedAt,
            ':created_at' => $now,
        ]);

        return (int)$pdo->lastInsertId();
    }

    public static function getForPatient(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT mh.*, p.medication, p.dosage, p.frequency, s.full_name AS pharmacist_name
             FROM medication_history mh
             LEFT JOIN prescriptions p ON p.id = mh.prescription_id
             LEFT JOIN staff s ON s.id = mh.pharmacy_staff_id
             WHERE mh.patient_id = :patient_id
             ORDER BY mh.dispensed_at DESC'
        );
        $stmt->execute([':patient_id' => $patientId]);
        return $stmt->fetchAll();
    }

    /** Aggregate dispense counts by medicine for adherence-style overview. */
    public static function usageSummary(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT
                COALESCE(p.medication, \'(unknown)\') AS medication,
                COALESCE(p.dosage, \'\') AS dosage,
                COALESCE(p.frequency, \'\') AS frequency,
                COUNT(mh.id) AS dispense_events,
                SUM(mh.quantity) AS total_quantity,
                MIN(mh.dispensed_at) AS first_dispensed,
                MAX(mh.dispensed_at) AS last_dispensed
             FROM medication_history mh
             LEFT JOIN prescriptions p ON p.id = mh.prescription_id
             WHERE mh.patient_id = :patient_id
             GROUP BY COALESCE(p.medication, \'(unknown)\'), COALESCE(p.dosage, \'\'), COALESCE(p.frequency, \'\')
             ORDER BY last_dispensed DESC'
        );
        $stmt->execute([':patient_id' => $patientId]);
        return $stmt->fetchAll();
    }

    /** Pharmacy margin snapshot from dispensed lines vs cost_price. */
    public static function dispensaryMargins(?string $from = null, ?string $to = null): array
    {
        $pdo = Database::getConnection();
        $sql = 'SELECT
                    m.name AS medicine,
                    m.unit_price AS sell_price,
                    COALESCE(m.cost_price, 0) AS cost_price,
                    SUM(d.quantity) AS qty_dispensed,
                    SUM(d.quantity * m.unit_price) AS revenue,
                    SUM(d.quantity * COALESCE(m.cost_price, 0)) AS cogs
                FROM dispensations d
                JOIN prescriptions p ON p.id = d.prescription_id
                LEFT JOIN medicines m ON m.id = p.medicine_id
                WHERE 1=1';
        $params = [];
        if ($from) {
            $sql .= ' AND d.dispensed_at >= :from';
            $params[':from'] = $from;
        }
        if ($to) {
            $sql .= ' AND d.dispensed_at <= :to';
            $params[':to'] = $to;
        }
        $sql .= ' GROUP BY m.id, m.name, m.unit_price, m.cost_price ORDER BY revenue DESC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        foreach ($rows as &$r) {
            $rev = (float)$r['revenue'];
            $cogs = (float)$r['cogs'];
            $r['margin'] = $rev - $cogs;
            $r['margin_pct'] = $rev > 0 ? round((($rev - $cogs) / $rev) * 100, 1) : null;
        }
        return $rows;
    }
}
