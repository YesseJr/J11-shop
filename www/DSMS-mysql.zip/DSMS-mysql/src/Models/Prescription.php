<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Medicine.php';
require_once __DIR__ . '/AuditLog.php';

/**
 * Prescription model — pricing is ALWAYS snapshotted from Pharmacy Inventory.
 * Doctors cannot supply or edit unit_price; only quantity/duration/dosage.
 */
class Prescription
{
    /**
     * Create a prescription line.
     * unit_price is taken exclusively from the medicine inventory row.
     * line_total = unit_price × quantity.
     */
    public static function create(
        int $patientId,
        int $doctorStaffId,
        string $medication,
        string $dosage,
        string $frequency,
        int $quantity,
        ?string $duration = null,
        ?string $instructions = null,
        ?int $consultationId = null,
        ?int $medicineId = null
    ): int {
        if ($quantity < 1) {
            throw new \InvalidArgumentException('Quantity must be at least 1.');
        }

        $pdo = Database::getConnection();

        // Lock pricing from inventory — doctors never set price
        $unitPrice = null;
        $resolvedName = $medication;
        $resolvedDosage = $dosage;

        if ($medicineId !== null && $medicineId > 0) {
            $med = Medicine::find($medicineId);
            if (!$med || !(int)$med['is_active']) {
                throw new \RuntimeException('Selected medicine is not available in inventory.');
            }
            $unitPrice = (float)$med['unit_price'];
            $resolvedName = $med['name'];
            if ($dosage === '' || $dosage === null) {
                $resolvedDosage = $med['dosage_form'];
            }
        } else {
            // Manual (non-catalog) entries are not billable at a pharmacy price
            // until linked to inventory — force unit_price = 0 and flag in audit.
            $unitPrice = 0.0;
        }

        $lineTotal = round($unitPrice * $quantity, 2);
        $now = date('c');

        $stmt = $pdo->prepare(
            'INSERT INTO prescriptions
                (patient_id, doctor_staff_id, consultation_id, medicine_id,
                 medication, dosage, frequency, duration, instructions,
                 unit_price, quantity, line_total, status, locked_at, created_at)
             VALUES
                (:patient_id, :doctor_staff_id, :consultation_id, :medicine_id,
                 :medication, :dosage, :frequency, :duration, :instructions,
                 :unit_price, :quantity, :line_total, \'Draft\', NULL, :created_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':doctor_staff_id' => $doctorStaffId,
            ':consultation_id' => $consultationId,
            ':medicine_id' => $medicineId,
            ':medication' => $resolvedName,
            ':dosage' => $resolvedDosage,
            ':frequency' => $frequency,
            ':duration' => $duration,
            ':instructions' => $instructions,
            ':unit_price' => $unitPrice,
            ':quantity' => $quantity,
            ':line_total' => $lineTotal,
            ':created_at' => $now,
        ]);

        $id = (int)$pdo->lastInsertId();

        AuditLog::log(
            $doctorStaffId,
            'prescriptions',
            $id,
            'create',
            sprintf(
                'med=%s qty=%d unit_price=%s line_total=%s medicine_id=%s',
                $resolvedName,
                $quantity,
                number_format($unitPrice, 2, '.', ''),
                number_format($lineTotal, 2, '.', ''),
                $medicineId ?? 'null'
            )
        );

        return $id;
    }

    public static function getForPatient(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM prescriptions WHERE patient_id = :patient_id ORDER BY created_at DESC'
        );
        $stmt->execute([':patient_id' => $patientId]);
        return $stmt->fetchAll();
    }

    public static function getForConsultation(int $consultationId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM prescriptions WHERE consultation_id = :cid AND status != \'Cancelled\' ORDER BY created_at ASC'
        );
        $stmt->execute([':cid' => $consultationId]);
        return $stmt->fetchAll();
    }

    public static function getDraftForConsultation(int $consultationId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM prescriptions WHERE consultation_id = :cid AND status = \'Draft\' ORDER BY created_at ASC'
        );
        $stmt->execute([':cid' => $consultationId]);
        return $stmt->fetchAll();
    }

    public static function getPendingForPatient(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT p.*
             FROM prescriptions p
             LEFT JOIN dispensations d ON d.prescription_id = p.id
             WHERE p.patient_id = :patient_id AND d.id IS NULL AND p.status != \'Cancelled\'
             ORDER BY p.created_at DESC'
        );
        $stmt->execute([':patient_id' => $patientId]);
        return $stmt->fetchAll();
    }

    public static function getPending(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT p.*, pt.patient_id AS patient_code, pt.full_name, s.full_name AS doctor_name
             FROM prescriptions p
             JOIN patients pt ON pt.id = p.patient_id
             JOIN staff s ON s.id = p.doctor_staff_id
             LEFT JOIN dispensations d ON d.prescription_id = p.id
             WHERE d.id IS NULL AND p.status != \'Cancelled\'
             ORDER BY p.created_at DESC'
        );
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT p.*, pt.patient_id AS patient_code, pt.full_name
             FROM prescriptions p
             JOIN patients pt ON pt.id = p.patient_id
             WHERE p.id = :id'
        );
        $stmt->execute([':id' => $id]);
        $prescription = $stmt->fetch();
        return $prescription ?: null;
    }

    /**
     * Lock all draft prescriptions for a consultation and refresh price
     * snapshots from inventory (in case inventory price changed after draft).
     * Must be called inside an open transaction.
     */
    public static function finalizeForConsultation(int $consultationId, int $staffId): array
    {
        $pdo = Database::getConnection();
        $now = date('c');

        $stmt = $pdo->prepare(
            'SELECT * FROM prescriptions WHERE consultation_id = :cid AND status = \'Draft\' FOR UPDATE'
        );
        $stmt->execute([':cid' => $consultationId]);
        $rows = $stmt->fetchAll();

        $update = $pdo->prepare(
            'UPDATE prescriptions
             SET unit_price = :price, quantity = :qty, line_total = :total,
                 status = \'Finalized\', locked_at = :locked
             WHERE id = :id AND status = \'Draft\''
        );

        $finalized = [];
        foreach ($rows as $row) {
            $price = (float)($row['unit_price'] ?? 0);
            $qty = max(1, (int)($row['quantity'] ?? 1));

            // Re-snapshot from inventory if linked
            if (!empty($row['medicine_id'])) {
                $med = Medicine::find((int)$row['medicine_id']);
                if ($med) {
                    $price = (float)$med['unit_price'];
                }
            }

            $lineTotal = round($price * $qty, 2);
            $update->execute([
                ':price' => $price,
                ':qty' => $qty,
                ':total' => $lineTotal,
                ':locked' => $now,
                ':id' => $row['id'],
            ]);

            AuditLog::log(
                $staffId,
                'prescriptions',
                (int)$row['id'],
                'finalize',
                sprintf(
                    'unit_price=%s qty=%d line_total=%s',
                    number_format($price, 2, '.', ''),
                    $qty,
                    number_format($lineTotal, 2, '.', '')
                )
            );

            $row['unit_price'] = $price;
            $row['quantity'] = $qty;
            $row['line_total'] = $lineTotal;
            $row['status'] = 'Finalized';
            $finalized[] = $row;
        }

        return $finalized;
    }

    /** Cancel a draft prescription (cannot cancel finalized). */
    public static function cancel(int $id, int $staffId): void
    {
        $pdo = Database::getConnection();
        $row = self::find($id);
        if (!$row) {
            throw new \RuntimeException('Prescription not found.');
        }
        if ($row['status'] === 'Finalized') {
            throw new \RuntimeException('Cannot cancel a finalized prescription.');
        }
        $stmt = $pdo->prepare(
            'UPDATE prescriptions SET status = \'Cancelled\' WHERE id = :id AND status = \'Draft\''
        );
        $stmt->execute([':id' => $id]);
        AuditLog::log($staffId, 'prescriptions', $id, 'cancel', 'med=' . $row['medication']);
    }

    /**
     * Patients/prescriptions that never reached a proper billing record.
     * Used by the Admin billing-gaps dashboard.
     */
    public static function findBillingGaps(): array
    {
        $pdo = Database::getConnection();

        // Prescriptions that exist but have no matching Pharmacy invoice_item
        // on any invoice for the same consultation, OR consultation finalized
        // with prescriptions but no invoice at all.
        $sql = "
            SELECT
                p.id AS prescription_id,
                p.medication,
                p.quantity,
                p.unit_price,
                p.line_total,
                p.status AS prescription_status,
                p.created_at AS prescription_date,
                p.locked_at,
                pt.id AS patient_pk,
                pt.patient_id AS patient_code,
                pt.full_name AS patient_name,
                pt.status AS patient_status,
                s.full_name AS doctor_name,
                s.specialization AS department,
                c.id AS consultation_id,
                c.treatment_finalized,
                c.finalized_at,
                i.id AS invoice_id,
                i.invoice_number,
                i.status AS invoice_status,
                ii.id AS invoice_item_id
            FROM prescriptions p
            JOIN patients pt ON pt.id = p.patient_id
            JOIN staff s ON s.id = p.doctor_staff_id
            LEFT JOIN consultations c ON c.id = p.consultation_id
            LEFT JOIN invoices i ON i.consultation_id = c.id
            LEFT JOIN invoice_items ii ON ii.reference_id = p.id AND ii.service_type = 'Pharmacy' AND ii.invoice_id = i.id
            WHERE p.status != 'Cancelled'
              AND (
                    (p.status = 'Finalized' AND ii.id IS NULL)
                 OR (p.status = 'Draft' AND c.treatment_finalized = 1)
                 OR (c.treatment_finalized = 1 AND i.id IS NULL)
              )
            ORDER BY p.created_at DESC
        ";
        return $pdo->query($sql)->fetchAll();
    }
}
