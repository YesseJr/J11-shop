<?php

require_once __DIR__ . '/../../src/Database.php';

class Budget
{
    public static function create(string $department, float $allocated, ?string $fiscalYear = null): int
    {
        $pdo = Database::getConnection();
        $now = date('c');
        $stmt = $pdo->prepare('INSERT INTO budgets (department, allocated, spent, fiscal_year, created_at, updated_at) VALUES (:department, :allocated, 0, :fiscal_year, :created_at, :updated_at)');
        $stmt->execute([
            ':department' => $department,
            ':allocated' => $allocated,
            ':fiscal_year' => $fiscalYear,
            ':created_at' => $now,
            ':updated_at' => $now,
        ]);

        return (int)$pdo->lastInsertId();
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT * FROM budgets ORDER BY fiscal_year DESC, department ASC');
        return $stmt->fetchAll();
    }

    public static function updateSpent(int $id, float $spent): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE budgets SET spent = spent + :spent, updated_at = :updated_at WHERE id = :id');
        $stmt->execute([':spent' => $spent, ':updated_at' => date('c'), ':id' => $id]);
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM budgets WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function updateAllocated(int $id, float $allocated): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE budgets SET allocated = :allocated, updated_at = :updated_at WHERE id = :id');
        $stmt->execute([':allocated' => $allocated, ':updated_at' => date('c'), ':id' => $id]);
    }

    public static function delete(int $id): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('DELETE FROM budgets WHERE id = :id');
        $stmt->execute([':id' => $id]);
    }

    /** Distinct department names already in use across all budgets, for
     *  populating a "create budget" dropdown instead of free-typing. */
    public static function distinctDepartments(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT DISTINCT department FROM budgets ORDER BY department ASC');
        return array_column($stmt->fetchAll(), 'department');
    }

    /** Case-insensitive lookup, preferring a budget row for the given fiscal
     *  year (defaults to the current year) and falling back to the most
     *  recent budget on record for that department if none matches. */
    public static function findByDepartment(string $department, ?string $fiscalYear = null): ?array
    {
        $pdo = Database::getConnection();
        $fiscalYear = $fiscalYear ?: date('Y');

        $stmt = $pdo->prepare('SELECT * FROM budgets WHERE LOWER(department) = LOWER(:department) AND fiscal_year = :fiscal_year LIMIT 1');
        $stmt->execute([':department' => $department, ':fiscal_year' => $fiscalYear]);
        $row = $stmt->fetch();
        if ($row) {
            return $row;
        }

        $stmt = $pdo->prepare('SELECT * FROM budgets WHERE LOWER(department) = LOWER(:department) ORDER BY fiscal_year DESC, id DESC LIMIT 1');
        $stmt->execute([':department' => $department]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Records real expenditure against whichever budget matches this
     *  department (e.g. "pharmacy", "laboratory"). Silently does nothing
     *  if no budget has been configured for that department yet, so
     *  dispensing/lab flows never break because budgeting hasn't been
     *  set up. Returns true if a budget was found and updated. */
    public static function recordExpenditure(string $department, float $amount, ?string $fiscalYear = null): bool
    {
        if ($amount <= 0) {
            return false;
        }

        $budget = self::findByDepartment($department, $fiscalYear);
        if (!$budget) {
            return false;
        }

        self::updateSpent((int)$budget['id'], $amount);
        return true;
    }

    /** Aggregate totals across every budget on record. */
    public static function totals(): array
    {
        $pdo = Database::getConnection();
        $row = $pdo->query('SELECT COALESCE(SUM(allocated),0) AS allocated, COALESCE(SUM(spent),0) AS spent FROM budgets')->fetch();
        $allocated = (float)$row['allocated'];
        $spent = (float)$row['spent'];
        return ['allocated' => $allocated, 'spent' => $spent, 'remaining' => $allocated - $spent];
    }

    /** Aggregate allocated/spent/remaining for every budget row matching a
     *  department name (case-insensitive), summed across fiscal years. */
    public static function departmentTotals(string $department): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT COALESCE(SUM(allocated),0) AS allocated, COALESCE(SUM(spent),0) AS spent FROM budgets WHERE LOWER(department) = LOWER(:department)');
        $stmt->execute([':department' => $department]);
        $row = $stmt->fetch();
        $allocated = (float)$row['allocated'];
        $spent = (float)$row['spent'];
        return ['allocated' => $allocated, 'spent' => $spent, 'remaining' => $allocated - $spent];
    }
}
