<?php

require_once __DIR__ . '/../../src/Database.php';

class LabRequest
{
    public static function create(int $consultationId, string $testType, float $bill): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO lab_requests (consultation_id, test_type, status, bill, created_at)
             VALUES (:consultation_id, :test_type, :status, :bill, :created_at)'
        );
        $stmt->execute([
            ':consultation_id' => $consultationId,
            ':test_type' => $testType,
            ':status' => 'Pending Investigation',
            ':bill' => $bill,
            ':created_at' => date('c'),
        ]);

        return (int)$pdo->lastInsertId();
    }

    /** Kept for backward compatibility with any old 'Pending Payment' rows
     *  from before centralized billing; not used by new lab requests. */
    public static function pay(int $labRequestId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE lab_requests SET status = :status, paid_at = :paid_at WHERE id = :id');
        $stmt->execute([':status' => 'Pending Investigation', ':paid_at' => date('c'), ':id' => $labRequestId]);
    }

    /** Old per-test payment gate — no longer used for new requests, since
     *  lab charges are now billed centrally with the rest of the visit.
     *  Left in place only so any pre-migration 'Pending Payment' rows are
     *  still visible somewhere rather than silently disappearing. */
    public static function getPendingPayment(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT l.id, l.consultation_id, l.test_type, l.bill, l.status, l.created_at,
                    c.patient_id, p.patient_id AS patient_code, p.full_name
             FROM lab_requests l
             JOIN consultations c ON c.id = l.consultation_id
             JOIN patients p ON p.id = c.patient_id
             WHERE l.status = "Pending Payment"
             ORDER BY l.created_at DESC'
        );

        return $stmt->fetchAll();
    }

    public static function getPendingInvestigation(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT l.id, l.consultation_id, l.test_type, l.bill, l.status, l.created_at,
                    c.patient_id, p.patient_id AS patient_code, p.full_name
             FROM lab_requests l
             JOIN consultations c ON c.id = l.consultation_id
             JOIN patients p ON p.id = c.patient_id
             LEFT JOIN lab_results r ON r.lab_request_id = l.id
             WHERE l.status IN ("Pending Investigation", "Paid") AND r.id IS NULL
             ORDER BY l.created_at DESC'
        );

        return $stmt->fetchAll();
    }

    public static function getCompleted(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT l.id, l.consultation_id, l.test_type, l.bill, l.status, l.created_at,
                    c.patient_id, p.patient_id AS patient_code, p.full_name
             FROM lab_requests l
             JOIN consultations c ON c.id = l.consultation_id
             JOIN patients p ON p.id = c.patient_id
             JOIN lab_results r ON r.lab_request_id = l.id
             ORDER BY l.created_at DESC'
        );

        return $stmt->fetchAll();
    }

    public static function getForPatient(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT l.*, c.id AS consultation_id, p.patient_id AS patient_code, p.full_name
             FROM lab_requests l
             JOIN consultations c ON c.id = l.consultation_id
             JOIN patients p ON p.id = c.patient_id
             WHERE p.id = :patient_id
             ORDER BY l.created_at DESC'
        );
        $stmt->execute([':patient_id' => $patientId]);

        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM lab_requests WHERE id = :id');
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }
}