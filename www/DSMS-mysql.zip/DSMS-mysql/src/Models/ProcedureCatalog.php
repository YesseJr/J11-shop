<?php

require_once __DIR__ . '/../../src/Database.php';

class ProcedureCatalog
{
    public static function active(): array
    {
        $pdo = Database::getConnection();
        return $pdo->query(
            'SELECT * FROM procedure_catalog WHERE is_active = 1 ORDER BY name ASC'
        )->fetchAll();
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        return $pdo->query('SELECT * FROM procedure_catalog ORDER BY name ASC')->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM procedure_catalog WHERE id = :id');
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public static function create(string $name, float $unitPrice, ?string $description = null): int
    {
        $pdo = Database::getConnection();
        $now = date('c');
        $stmt = $pdo->prepare(
            'INSERT INTO procedure_catalog (name, description, unit_price, is_active, created_at, updated_at)
             VALUES (:name, :description, :price, 1, :created, :updated)'
        );
        $stmt->execute([
            ':name' => $name,
            ':description' => $description,
            ':price' => $unitPrice,
            ':created' => $now,
            ':updated' => $now,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function addToConsultation(int $consultationId, int $catalogId, int $quantity = 1): int
    {
        $proc = self::find($catalogId);
        if (!$proc || !(int)$proc['is_active']) {
            throw new RuntimeException('Procedure not available.');
        }
        $qty = max(1, $quantity);
        $price = (float)$proc['unit_price'];
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO consultation_procedures
                (consultation_id, procedure_catalog_id, name, quantity, unit_price, line_total, created_at)
             VALUES (:cid, :pid, :name, :qty, :price, :total, :created)'
        );
        $stmt->execute([
            ':cid' => $consultationId,
            ':pid' => $catalogId,
            ':name' => $proc['name'],
            ':qty' => $qty,
            ':price' => $price,
            ':total' => $price * $qty,
            ':created' => date('c'),
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function forConsultation(int $consultationId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM consultation_procedures WHERE consultation_id = :cid ORDER BY id ASC'
        );
        $stmt->execute([':cid' => $consultationId]);
        return $stmt->fetchAll();
    }
}
