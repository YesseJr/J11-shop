<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/LabRequest.php';
require_once __DIR__ . '/Patient.php';

class LabResult
{
    public static function upload(int $labRequestId, string $result, ?string $comments = null, ?int $uploadedByStaffId = null, array $data = []): int
    {
        $pdo = Database::getConnection();

        $resultValue = $data['result_value'] ?? null;
        $resultUnit = $data['result_unit'] ?? null;
        $referenceRange = $data['reference_range'] ?? null;
        $resultFlag = $data['result_flag'] ?? null;

        if ($resultFlag === null && $resultValue !== null && $resultValue !== '' && $referenceRange) {
            $resultFlag = self::inferFlag($resultValue, $referenceRange);
        }

        if ($result === '' && $resultValue !== null && $resultValue !== '') {
            $result = trim($resultValue . ($resultUnit ? ' ' . $resultUnit : ''));
            if ($referenceRange) {
                $result .= ' (ref: ' . $referenceRange . ')';
            }
            if ($resultFlag) {
                $result .= ' [' . $resultFlag . ']';
            }
        }

        $stmt = $pdo->prepare(
            'INSERT INTO lab_results (
                lab_request_id, result, result_value, result_unit, reference_range, result_flag,
                comments, uploaded_by_staff_id, uploaded_at
             ) VALUES (
                :lab_request_id, :result, :result_value, :result_unit, :reference_range, :result_flag,
                :comments, :uploaded_by, :uploaded_at
             )'
        );
        $stmt->execute([
            ':lab_request_id' => $labRequestId,
            ':result' => $result,
            ':result_value' => $resultValue,
            ':result_unit' => $resultUnit,
            ':reference_range' => $referenceRange,
            ':result_flag' => $resultFlag,
            ':comments' => $comments,
            ':uploaded_by' => $uploadedByStaffId,
            ':uploaded_at' => date('c'),
        ]);

        $labRequest = LabRequest::find($labRequestId);
        if ($labRequest) {
            $stmt = $pdo->prepare('UPDATE consultations SET status = :status WHERE id = :id');
            $stmt->execute([':status' => 'Results Ready', ':id' => $labRequest['consultation_id']]);

            $stmt = $pdo->prepare('UPDATE lab_requests SET status = :status WHERE id = :id');
            $stmt->execute([':status' => 'Completed', ':id' => $labRequestId]);

            $patientId = self::fetchPatientIdForLabRequest($labRequestId);
            if ($patientId) {
                Patient::updateStatus($patientId, 'Results Ready');
            }
        }

        return (int)$pdo->lastInsertId();
    }

    public static function inferFlag(string $value, string $range): ?string
    {
        if (!preg_match('/^\s*(-?\d+(?:\.\d+)?)\s*$/', trim($value), $vm)) {
            return null;
        }
        $num = (float)$vm[1];
        if (preg_match('/(-?\d+(?:\.\d+)?)\s*[-–]\s*(-?\d+(?:\.\d+)?)/', $range, $m)) {
            $low = (float)$m[1];
            $high = (float)$m[2];
            if ($num < $low) return 'Low';
            if ($num > $high) return 'High';
            return 'Normal';
        }
        if (preg_match('/<\s*(-?\d+(?:\.\d+)?)/', $range, $m)) {
            return $num < (float)$m[1] ? 'Normal' : 'High';
        }
        if (preg_match('/>\s*(-?\d+(?:\.\d+)?)/', $range, $m)) {
            return $num > (float)$m[1] ? 'Normal' : 'Low';
        }
        return null;
    }

    public static function findByLabRequestId(int $labRequestId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM lab_results WHERE lab_request_id = :id');
        $stmt->execute([':id' => $labRequestId]);
        return $stmt->fetch() ?: null;
    }

    private static function fetchPatientIdForLabRequest(int $labRequestId): ?int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT c.patient_id FROM consultations c
             JOIN lab_requests l ON l.consultation_id = c.id
             WHERE l.id = :id'
        );
        $stmt->execute([':id' => $labRequestId]);
        $row = $stmt->fetch();
        return $row ? (int)$row['patient_id'] : null;
    }
}
