<?php

require_once __DIR__ . '/../../src/Database.php';

class AuditLog
{
    public static function log(
        ?int $staffId,
        string $entityType,
        ?int $entityId,
        string $action,
        ?string $details = null,
        ?array $oldValues = null,
        ?array $newValues = null
    ): void {
        $pdo = Database::getConnection();
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr((string)$_SERVER['HTTP_USER_AGENT'], 0, 255) : null;
        $oldJson = $oldValues !== null ? json_encode($oldValues, JSON_UNESCAPED_UNICODE) : null;
        $newJson = $newValues !== null ? json_encode($newValues, JSON_UNESCAPED_UNICODE) : null;

        try {
            $stmt = $pdo->prepare(
                'INSERT INTO audit_logs (staff_id, entity_type, entity_id, action, details, ip_address, user_agent, old_values, new_values, created_at)
                 VALUES (:staff, :etype, :eid, :action, :details, :ip, :ua, :old, :new, :now)'
            );
            $stmt->execute([
                ':staff' => $staffId,
                ':etype' => $entityType,
                ':eid' => $entityId,
                ':action' => $action,
                ':details' => $details,
                ':ip' => $ip,
                ':ua' => $ua,
                ':old' => $oldJson,
                ':new' => $newJson,
                ':now' => date('c'),
            ]);
        } catch (\Throwable $e) {
            // Fallback for installs without enrichment columns
            $stmt = $pdo->prepare(
                'INSERT INTO audit_logs (staff_id, entity_type, entity_id, action, details, created_at)
                 VALUES (:staff, :etype, :eid, :action, :details, :now)'
            );
            $stmt->execute([
                ':staff' => $staffId,
                ':etype' => $entityType,
                ':eid' => $entityId,
                ':action' => $action,
                ':details' => $details,
                ':now' => date('c'),
            ]);
        }
    }

    public static function forEntity(string $entityType, int $entityId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT a.*, s.full_name AS staff_name, s.role AS staff_role
             FROM audit_logs a
             LEFT JOIN staff s ON s.id = a.staff_id
             WHERE a.entity_type = :etype AND a.entity_id = :eid
             ORDER BY a.created_at DESC'
        );
        $stmt->execute([':etype' => $entityType, ':eid' => $entityId]);
        return $stmt->fetchAll();
    }

    public static function search(?string $q = null, ?string $action = null, int $limit = 100, int $offset = 0): array
    {
        $pdo = Database::getConnection();
        $sql = 'SELECT a.*, s.full_name AS staff_name, s.role AS staff_role
                FROM audit_logs a
                LEFT JOIN staff s ON s.id = a.staff_id
                WHERE 1=1';
        $params = [];
        if ($q) {
            $sql .= ' AND (a.entity_type LIKE :q OR a.action LIKE :q2 OR a.details LIKE :q3 OR s.full_name LIKE :q4)';
            $like = '%' . $q . '%';
            $params = [':q' => $like, ':q2' => $like, ':q3' => $like, ':q4' => $like];
        }
        if ($action) {
            $sql .= ' AND a.action = :act';
            $params[':act'] = $action;
        }
        $sql .= ' ORDER BY a.id DESC LIMIT ' . (int)$limit . ' OFFSET ' . (int)$offset;
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
