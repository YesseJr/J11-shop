<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Insurance.php';
require_once __DIR__ . '/AuditLog.php';

/**
 * Billing (v2)
 * ------------
 * Workflow changed from v1: invoices are now generated once the DOCTOR
 * finalizes treatment (consultations.treatment_finalized = 1) — i.e. after
 * consultation + all requested labs are resulted + prescriptions are
 * written, but BEFORE pharmacy dispenses anything. Payment (cash or
 * insurance) must be confirmed before Dispensation::record() will allow
 * dispensing — see the gate added in Dispensation.php.
 */
class Billing
{
    private const CONSULTATION_FEE = 5000.00;

    // ------------------------------------------------------------------
    // Visit readiness (now: pre-dispense)
    // ------------------------------------------------------------------

    public static function isVisitReadyForBilling(int $queueEntryId): bool
    {
        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            "SELECT c.id AS consultation_id, c.patient_id, c.treatment_finalized
             FROM queue_entries q
             JOIN consultations c ON c.patient_id = q.patient_id
             WHERE q.id = :qid
             ORDER BY c.created_at DESC LIMIT 1"
        );
        $stmt->execute([':qid' => $queueEntryId]);
        $consultation = $stmt->fetch();

        if (!$consultation || (int)$consultation['treatment_finalized'] !== 1) {
            return false; // doctor hasn't finalized treatment yet
        }
        $consultationId = (int)$consultation['consultation_id'];

        $stmt = $pdo->prepare(
            "SELECT COUNT(*) AS pending
             FROM lab_requests l
             LEFT JOIN lab_results r ON r.lab_request_id = l.id
             WHERE l.consultation_id = :cid AND r.id IS NULL"
        );
        $stmt->execute([':cid' => $consultationId]);
        if ((int)$stmt->fetch()['pending'] > 0) {
            return false;
        }

        $stmt = $pdo->prepare('SELECT COUNT(*) AS c FROM invoices WHERE queue_entry_id = :qid');
        $stmt->execute([':qid' => $queueEntryId]);
        if ((int)$stmt->fetch()['c'] > 0) {
            return false;
        }

        return true;
    }

    public static function getPatientsAwaitingBilling(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            "SELECT q.id AS queue_entry_id, p.id AS patient_id, p.patient_id AS patient_code,
                    p.full_name, c.id AS consultation_id, c.created_at AS consultation_date
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             JOIN consultations c ON c.patient_id = p.id
             LEFT JOIN invoices i ON i.queue_entry_id = q.id
             WHERE i.id IS NULL AND c.treatment_finalized = 1
             ORDER BY c.created_at ASC"
        );
        $rows = $stmt->fetchAll();

        return array_values(array_filter($rows, fn($r) => self::isVisitReadyForBilling((int)$r['queue_entry_id'])));
    }

    /**
     * Doctor's "Complete Treatment & Send to Billing" action.
     *
     * Runs inside a single transaction so that:
     *   - prescriptions are price-snapshotted & locked (Finalized),
     *   - the consultation is marked finalized,
     *   - an invoice is generated (if one does not already exist),
     *   - audit logs are written,
     * either ALL succeed or ALL roll back.
     *
     * Returns the invoice id (existing or newly created).
     */
    public static function finalizeTreatment(int $consultationId, int $doctorStaffId): int
    {
        require_once __DIR__ . '/Prescription.php';
        require_once __DIR__ . '/Patient.php';
        require_once __DIR__ . '/QueueManager.php';

        $pdo = Database::getConnection();
        $pdo->beginTransaction();
        try {
            // Lock consultation row
            $stmt = $pdo->prepare('SELECT * FROM consultations WHERE id = :id FOR UPDATE');
            $stmt->execute([':id' => $consultationId]);
            $consultation = $stmt->fetch();
            if (!$consultation) {
                throw new \RuntimeException('Consultation not found.');
            }
            if ((int)$consultation['treatment_finalized'] === 1) {
                // Already finalized — return existing invoice if any
                $stmt = $pdo->prepare('SELECT id FROM invoices WHERE consultation_id = :cid LIMIT 1');
                $stmt->execute([':cid' => $consultationId]);
                $existing = $stmt->fetch();
                $pdo->commit();
                return $existing ? (int)$existing['id'] : 0;
            }

            // 1) Lock & re-snapshot every draft prescription for this visit
            $finalizedRx = Prescription::finalizeForConsultation($consultationId, $doctorStaffId);

            // 2) Mark consultation finalized
            $now = date('c');
            $stmt = $pdo->prepare(
                'UPDATE consultations SET treatment_finalized = 1, finalized_at = :now WHERE id = :id'
            );
            $stmt->execute([':now' => $now, ':id' => $consultationId]);
            AuditLog::log($doctorStaffId, 'consultations', $consultationId, 'finalize_treatment');

            // 3) Resolve queue entry for this patient (latest accepted / active)
            $stmt = $pdo->prepare(
                'SELECT id FROM queue_entries WHERE patient_id = :pid ORDER BY id DESC LIMIT 1'
            );
            $stmt->execute([':pid' => $consultation['patient_id']]);
            $queue = $stmt->fetch();
            if (!$queue) {
                throw new \RuntimeException('No queue entry found for this patient — cannot generate invoice.');
            }
            $queueEntryId = (int)$queue['id'];

            // 4) Generate invoice if one does not already exist
            $stmt = $pdo->prepare('SELECT id FROM invoices WHERE consultation_id = :cid LIMIT 1');
            $stmt->execute([':cid' => $consultationId]);
            $existingInv = $stmt->fetch();

            if ($existingInv) {
                $invoiceId = (int)$existingInv['id'];
                AuditLog::log($doctorStaffId, 'invoices', $invoiceId, 'reuse_on_finalize', 'existing invoice kept');
            } else {
                $invoiceId = self::generateInvoiceInsideTransaction($queueEntryId, $consultationId, (int)$consultation['patient_id'], $doctorStaffId);
            }

            // 5) Update patient status so billing desk can see them
            Patient::updateStatus((int)$consultation['patient_id'], 'Awaiting Payment');

            $pdo->commit();

            AuditLog::log(
                $doctorStaffId,
                'invoices',
                $invoiceId,
                'auto_generated_on_finalize',
                sprintf('consultation=%d prescriptions=%d', $consultationId, count($finalizedRx))
            );

            return $invoiceId;
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    /**
     * Invoice generation that assumes the caller already holds an open transaction.
     * Used by finalizeTreatment so prescription lock + invoice are atomic.
     */
    private static function generateInvoiceInsideTransaction(
        int $queueEntryId,
        int $consultationId,
        int $patientId,
        int $generatedByStaffId
    ): int {
        $pdo = Database::getConnection();

        // Guard: one invoice per visit (uniq_visit_invoice on queue_entry_id)
        $stmt = $pdo->prepare(
            'SELECT id FROM invoices WHERE queue_entry_id = :qid OR consultation_id = :cid LIMIT 1'
        );
        $stmt->execute([':qid' => $queueEntryId, ':cid' => $consultationId]);
        $existing = $stmt->fetch();
        if ($existing) {
            $invoiceId = (int)$existing['id'];
            self::syncPharmacyItems($invoiceId, $consultationId, $generatedByStaffId);
            self::recalculateInvoiceTotals($invoiceId);
            AuditLog::log($generatedByStaffId, 'invoices', $invoiceId, 'reuse_existing_on_generate', "queue={$queueEntryId}");
            return $invoiceId;
        }

        $invoiceNumber = self::generateInvoiceNumber();
        $now = date('c');

        $stmt = $pdo->prepare(
            'INSERT INTO invoices (invoice_number, patient_id, consultation_id, queue_entry_id,
                total_amount, amount_paid, balance, status, payer_type, discount_amount,
                insurance_covered_amount, generated_by, generated_at, updated_at)
             VALUES (:num, :pid, :cid, :qid, 0, 0, 0, "Pending", "Cash", 0, 0, :gen, :now, :now2)'
        );
        $stmt->execute([
            ':num' => $invoiceNumber,
            ':pid' => $patientId,
            ':cid' => $consultationId,
            ':qid' => $queueEntryId,
            ':gen' => $generatedByStaffId,
            ':now' => $now,
            ':now2' => $now,
        ]);
        $invoiceId = (int)$pdo->lastInsertId();

        $total = 0.0;
        $total += self::addConsultationItem($invoiceId, $consultationId);
        $total += self::addLabItems($invoiceId, $consultationId);
        $total += self::addPharmacyItems($invoiceId, $consultationId);
        $total += self::addProcedureItems($invoiceId, $consultationId);

        $stmt = $pdo->prepare(
            'UPDATE invoices SET total_amount = :t, balance = :t2, updated_at = :now WHERE id = :id'
        );
        $stmt->execute([':t' => $total, ':t2' => $total, ':now' => date('c'), ':id' => $invoiceId]);

        AuditLog::log($generatedByStaffId, 'invoices', $invoiceId, 'generate', "total={$total}");

        return $invoiceId;
    }

    /**
     * Admin recovery: regenerate / attach pharmacy lines for a consultation
     * that is missing invoice items. Creates the invoice only if none exists
     * for this consultation OR its queue visit (uniq_visit_invoice on
     * queue_entry_id). Never inserts a duplicate invoice.
     */
    public static function regenerateBillForConsultation(int $consultationId, int $adminStaffId): int
    {
        require_once __DIR__ . '/Prescription.php';
        require_once __DIR__ . '/Patient.php';

        $pdo = Database::getConnection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT * FROM consultations WHERE id = :id FOR UPDATE');
            $stmt->execute([':id' => $consultationId]);
            $consultation = $stmt->fetch();
            if (!$consultation) {
                throw new \RuntimeException('Consultation not found.');
            }

            // Ensure prescriptions are finalized with current inventory prices
            Prescription::finalizeForConsultation($consultationId, $adminStaffId);

            if ((int)$consultation['treatment_finalized'] !== 1) {
                $stmt = $pdo->prepare(
                    'UPDATE consultations SET treatment_finalized = 1, finalized_at = :now WHERE id = :id'
                );
                $stmt->execute([':now' => date('c'), ':id' => $consultationId]);
            }

            $stmt = $pdo->prepare(
                'SELECT id FROM queue_entries WHERE patient_id = :pid ORDER BY id DESC LIMIT 1'
            );
            $stmt->execute([':pid' => $consultation['patient_id']]);
            $queue = $stmt->fetch();
            if (!$queue) {
                throw new \RuntimeException('No queue entry for patient.');
            }
            $queueEntryId = (int)$queue['id'];

            // Find existing invoice by consultation OR by visit (unique key).
            // Prefer consultation match; fall back to queue_entry_id so we
            // never violate uniq_visit_invoice.
            $stmt = $pdo->prepare(
                'SELECT id, consultation_id, status FROM invoices
                 WHERE consultation_id = :cid OR queue_entry_id = :qid
                 ORDER BY CASE WHEN consultation_id = :cid2 THEN 0 ELSE 1 END, id DESC
                 LIMIT 1'
            );
            $stmt->execute([
                ':cid' => $consultationId,
                ':qid' => $queueEntryId,
                ':cid2' => $consultationId,
            ]);
            $existing = $stmt->fetch();

            if ($existing) {
                $invoiceId = (int)$existing['id'];

                // Keep invoice linked to this consultation if it was orphaned
                if ((int)$existing['consultation_id'] !== $consultationId) {
                    $pdo->prepare(
                        'UPDATE invoices SET consultation_id = :cid, updated_at = :now WHERE id = :id'
                    )->execute([
                        ':cid' => $consultationId,
                        ':now' => date('c'),
                        ':id' => $invoiceId,
                    ]);
                }

                // Re-add any missing pharmacy / consult / lab lines then recalc
                self::syncPharmacyItems($invoiceId, $consultationId, $adminStaffId);
                self::ensureCoreInvoiceItems($invoiceId, $consultationId);
                self::recalculateInvoiceTotals($invoiceId);
                // Re-open for billing if anything is still owed (so it appears in queues)
                self::reopenInvoiceIfUnpaid($invoiceId);
            } else {
                $invoiceId = self::generateInvoiceInsideTransaction(
                    $queueEntryId,
                    $consultationId,
                    (int)$consultation['patient_id'],
                    $adminStaffId
                );
            }

            Patient::updateStatus((int)$consultation['patient_id'], 'Awaiting Payment');

            // Bump updated_at so the invoice sorts as freshly recovered
            $pdo->prepare(
                'UPDATE invoices SET updated_at = :now WHERE id = :id'
            )->execute([':now' => date('c'), ':id' => $invoiceId]);

            AuditLog::log(
                $adminStaffId,
                'invoices',
                $invoiceId,
                'admin_regenerate_bill',
                "consultation={$consultationId}"
            );

            $pdo->commit();
            return $invoiceId;
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    /**
     * Recalculate invoice total/balance from current line items.
     * Preserves amount_paid; only refreshes total and remaining balance.
     */
    private static function recalculateInvoiceTotals(int $invoiceId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT COALESCE(SUM(subtotal), 0) AS items_total FROM invoice_items WHERE invoice_id = :id'
        );
        $stmt->execute([':id' => $invoiceId]);
        $itemsTotal = (float)$stmt->fetchColumn();

        $inv = self::find($invoiceId);
        if (!$inv) {
            return;
        }
        $discount = (float)($inv['discount_amount'] ?? 0);
        $paid = (float)($inv['amount_paid'] ?? 0);
        $total = max(0, $itemsTotal - $discount);
        $balance = max(0, $total - $paid);

        $pdo->prepare(
            'UPDATE invoices SET total_amount = :t, balance = :b, updated_at = :now WHERE id = :id'
        )->execute([
            ':t' => $total,
            ':b' => $balance,
            ':now' => date('c'),
            ':id' => $invoiceId,
        ]);
    }

    /**
     * After recovery, if balance remains, force status back into the billing
     * queues (Pending / Partially Paid). Cancelled invoices with a balance
     * are also reopened so the biller can see them.
     */
    private static function reopenInvoiceIfUnpaid(int $invoiceId): void
    {
        $pdo = Database::getConnection();
        // Use the same total formula as recordPayment / applyInsurance
        self::recalculateTotals($invoiceId);
        $inv = self::find($invoiceId);
        if (!$inv) {
            return;
        }
        $balance = (float)$inv['balance'];
        $paid = (float)$inv['amount_paid'];
        if ($balance <= 0.0001) {
            $pdo->prepare(
                'UPDATE invoices SET status = \'Paid\', updated_at = :now WHERE id = :id'
            )->execute([':now' => date('c'), ':id' => $invoiceId]);
            return;
        }
        // Balance remains — must be collectible in the billing queue
        $status = $paid > 0.0001 ? 'Partially Paid' : 'Pending';
        $pdo->prepare(
            'UPDATE invoices SET status = :st, updated_at = :now WHERE id = :id'
        )->execute([':st' => $status, ':now' => date('c'), ':id' => $invoiceId]);
    }

    /**
     * Ensure consultation fee and lab lines exist on a recovered invoice
     * (pharmacy lines are handled by syncPharmacyItems).
     */
    private static function ensureCoreInvoiceItems(int $invoiceId, int $consultationId): void
    {
        $pdo = Database::getConnection();

        // Consultation fee
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM invoice_items
             WHERE invoice_id = :iid AND service_type = 'Consultation'"
        );
        $stmt->execute([':iid' => $invoiceId]);
        if ((int)$stmt->fetchColumn() === 0) {
            self::addConsultationItem($invoiceId, $consultationId);
        }

        // Lab lines missing from invoice
        $stmt = $pdo->prepare(
            "SELECT l.id, l.test_type, l.bill
             FROM lab_requests l
             WHERE l.consultation_id = :cid
               AND NOT EXISTS (
                   SELECT 1 FROM invoice_items ii
                   WHERE ii.invoice_id = :iid AND ii.service_type = 'Lab' AND ii.reference_id = l.id
               )"
        );
        $stmt->execute([':cid' => $consultationId, ':iid' => $invoiceId]);
        $labs = $stmt->fetchAll();
        if (!empty($labs)) {
            $ins = $pdo->prepare(
                'INSERT INTO invoice_items (invoice_id, service_type, reference_id, description, quantity, unit_price, subtotal, is_manual, created_at)
                 VALUES (:iid, "Lab", :ref, :desc, 1, :price, :subtotal, 0, :now)'
            );
            foreach ($labs as $lab) {
                $price = (float)$lab['bill'];
                $ins->execute([
                    ':iid' => $invoiceId,
                    ':ref' => $lab['id'],
                    ':desc' => 'Lab Test: ' . $lab['test_type'],
                    ':price' => $price,
                    ':subtotal' => $price,
                    ':now' => date('c'),
                ]);
            }
        }
    }

    /** Ensure every finalized prescription has a Pharmacy invoice_item. */
    private static function syncPharmacyItems(int $invoiceId, int $consultationId, int $staffId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT p.* FROM prescriptions p
             WHERE p.consultation_id = :cid AND p.status = 'Finalized'
               AND NOT EXISTS (
                   SELECT 1 FROM invoice_items ii
                   WHERE ii.invoice_id = :iid AND ii.service_type = 'Pharmacy' AND ii.reference_id = p.id
               )"
        );
        $stmt->execute([':cid' => $consultationId, ':iid' => $invoiceId]);
        $missing = $stmt->fetchAll();

        $ins = $pdo->prepare(
            'INSERT INTO invoice_items (invoice_id, service_type, reference_id, description, quantity, unit_price, subtotal, is_manual, created_at)
             VALUES (:iid, "Pharmacy", :ref, :desc, :qty, :price, :subtotal, 0, :now)'
        );
        $added = 0.0;
        foreach ($missing as $item) {
            $qty = max(1, (int)($item['quantity'] ?? 1));
            $price = (float)($item['unit_price'] ?? 0);
            $subtotal = (float)($item['line_total'] ?? ($price * $qty));
            $ins->execute([
                ':iid' => $invoiceId,
                ':ref' => $item['id'],
                ':desc' => 'Medicine: ' . $item['medication'] . ' × ' . $qty,
                ':qty' => $qty,
                ':price' => $price,
                ':subtotal' => $subtotal,
                ':now' => date('c'),
            ]);
            $added += $subtotal;
            AuditLog::log($staffId, 'invoice_items', (int)$pdo->lastInsertId(), 'sync_pharmacy_item', "prescription={$item['id']}");
        }

        if ($added > 0) {
            $pdo->prepare(
                'UPDATE invoices SET total_amount = total_amount + :a, balance = balance + :a2, updated_at = :now WHERE id = :id'
            )->execute([':a' => $added, ':a2' => $added, ':now' => date('c'), ':id' => $invoiceId]);
        }
    }

    // ------------------------------------------------------------------
    // Invoice generation
    // ------------------------------------------------------------------

    public static function generateInvoice(int $queueEntryId, int $generatedByStaffId): int
    {
        if (!self::isVisitReadyForBilling($queueEntryId)) {
            throw new \Exception('Visit is not ready for billing yet: consultation must be finalized and all labs resulted.');
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT c.id AS consultation_id, c.patient_id
             FROM queue_entries q
             JOIN consultations c ON c.patient_id = q.patient_id
             WHERE q.id = :qid ORDER BY c.created_at DESC LIMIT 1"
        );
        $stmt->execute([':qid' => $queueEntryId]);
        $visit = $stmt->fetch();
        if (!$visit) {
            throw new \Exception('No consultation found for this visit.');
        }

        $pdo->beginTransaction();
        try {
            $invoiceNumber = self::generateInvoiceNumber();
            $now = date('c');

            $stmt = $pdo->prepare(
                'INSERT INTO invoices (invoice_number, patient_id, consultation_id, queue_entry_id,
                    total_amount, amount_paid, balance, status, payer_type, discount_amount,
                    insurance_covered_amount, generated_by, generated_at, updated_at)
                 VALUES (:num, :pid, :cid, :qid, 0, 0, 0, "Pending", "Cash", 0, 0, :gen, :now, :now2)'
            );
            $stmt->execute([
                ':num' => $invoiceNumber, ':pid' => $visit['patient_id'], ':cid' => $visit['consultation_id'],
                ':qid' => $queueEntryId, ':gen' => $generatedByStaffId, ':now' => $now, ':now2' => $now,
            ]);
            $invoiceId = (int)$pdo->lastInsertId();

            $total = 0.0;
            $total += self::addConsultationItem($invoiceId, (int)$visit['consultation_id']);
            $total += self::addLabItems($invoiceId, (int)$visit['consultation_id']);
            $total += self::addPharmacyItems($invoiceId, (int)$visit['consultation_id']);

            $stmt = $pdo->prepare('UPDATE invoices SET total_amount = :t, balance = :t2, updated_at = :now WHERE id = :id');
            $stmt->execute([':t' => $total, ':t2' => $total, ':now' => date('c'), ':id' => $invoiceId]);

            AuditLog::log($generatedByStaffId, 'invoices', $invoiceId, 'generate', "total={$total}");

            $pdo->commit();
            return $invoiceId;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    
    private static function addProcedureItems(int $invoiceId, int $consultationId): float
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM consultation_procedures WHERE consultation_id = :cid'
        );
        $stmt->execute([':cid' => $consultationId]);
        $rows = $stmt->fetchAll();
        $sum = 0.0;
        $ins = $pdo->prepare(
            'INSERT INTO invoice_items (invoice_id, service_type, reference_id, description, quantity, unit_price, subtotal, is_manual, created_at)
             VALUES (:iid, \'Procedure\', :ref, :desc, :qty, :price, :sub, 0, :created)'
        );
        foreach ($rows as $row) {
            $sub = (float)$row['line_total'];
            $ins->execute([
                ':iid' => $invoiceId,
                ':ref' => $row['id'],
                ':desc' => $row['name'],
                ':qty' => (int)$row['quantity'],
                ':price' => (float)$row['unit_price'],
                ':sub' => $sub,
                ':created' => date('c'),
            ]);
            $sum += $sub;
        }
        return $sum;
    }

    private static function addConsultationItem(int $invoiceId, int $consultationId): float
    {
        $pdo = Database::getConnection();
        $fee = self::CONSULTATION_FEE;
        $stmt = $pdo->prepare(
            'INSERT INTO invoice_items (invoice_id, service_type, reference_id, description, quantity, unit_price, subtotal, is_manual, created_at)
             VALUES (:iid, "Consultation", :ref, "Consultation Fee", 1, :fee, :subtotal, 0, :now)'
        );
        $stmt->execute([':iid' => $invoiceId, ':ref' => $consultationId, ':fee' => $fee, ':subtotal' => $fee, ':now' => date('c')]);
        return $fee;
    }

    private static function addLabItems(int $invoiceId, int $consultationId): float
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT id, test_type, bill FROM lab_requests WHERE consultation_id = :cid');
        $stmt->execute([':cid' => $consultationId]);
        $labs = $stmt->fetchAll();

        $total = 0.0;
        $ins = $pdo->prepare(
            'INSERT INTO invoice_items (invoice_id, service_type, reference_id, description, quantity, unit_price, subtotal, is_manual, created_at)
             VALUES (:iid, "Lab", :ref, :desc, 1, :price, :subtotal, 0, :now)'
        );
        foreach ($labs as $lab) {
            $price = (float)$lab['bill'];
            $ins->execute([':iid' => $invoiceId, ':ref' => $lab['id'], ':desc' => 'Lab Test: ' . $lab['test_type'], ':price' => $price, ':subtotal' => $price, ':now' => date('c')]);
            $total += $price;
        }
        return $total;
    }

    /**
     * Bill every non-cancelled prescription for the consultation using the
     * snapshotted unit_price × quantity (line_total). Quantity drives cost.
     * Dispensing happens AFTER payment — we never wait for a dispensation row.
     */
    private static function addPharmacyItems(int $invoiceId, int $consultationId): float
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT id, medication, unit_price, quantity, line_total, status
             FROM prescriptions
             WHERE consultation_id = :cid AND status != 'Cancelled'"
        );
        $stmt->execute([':cid' => $consultationId]);
        $items = $stmt->fetchAll();

        $total = 0.0;
        $ins = $pdo->prepare(
            'INSERT INTO invoice_items (invoice_id, service_type, reference_id, description, quantity, unit_price, subtotal, is_manual, created_at)
             VALUES (:iid, "Pharmacy", :ref, :desc, :qty, :price, :subtotal, 0, :now)'
        );
        foreach ($items as $item) {
            $qty = max(1, (int)($item['quantity'] ?? 1));
            $price = (float)($item['unit_price'] ?? 0);
            $subtotal = (float)($item['line_total'] ?? ($price * $qty));
            $ins->execute([
                ':iid' => $invoiceId,
                ':ref' => $item['id'],
                ':desc' => 'Medicine: ' . $item['medication'] . ' × ' . $qty,
                ':qty' => $qty,
                ':price' => $price,
                ':subtotal' => $subtotal,
                ':now' => date('c'),
            ]);
            $total += $subtotal;
        }
        return $total;
    }

    // ------------------------------------------------------------------
    // Biller-managed manual items / discounts
    // ------------------------------------------------------------------

    public static function addManualItem(int $invoiceId, string $serviceType, string $description, int $quantity, float $unitPrice, int $staffId): int
    {
        $invoice = self::find($invoiceId);
        if (!$invoice || $invoice['status'] === 'Paid') {
            throw new \Exception('Cannot modify a paid or missing invoice.');
        }
        $pdo = Database::getConnection();
        $subtotal = $unitPrice * $quantity;

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO invoice_items (invoice_id, service_type, reference_id, description, quantity, unit_price, subtotal, added_by, is_manual, created_at)
                 VALUES (:iid, :type, NULL, :desc, :qty, :price, :sub, :staff, 1, :now)'
            );
            $stmt->execute([
                ':iid' => $invoiceId, ':type' => $serviceType, ':desc' => $description,
                ':qty' => $quantity, ':price' => $unitPrice, ':sub' => $subtotal, ':staff' => $staffId, ':now' => date('c'),
            ]);
            $itemId = (int)$pdo->lastInsertId();

            self::recalculateTotals($invoiceId);
            AuditLog::log($staffId, 'invoice_items', $itemId, 'add_manual_item', "invoice={$invoiceId} desc={$description} amount={$subtotal}");

            $pdo->commit();
            return $itemId;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function removeItem(int $invoiceItemId, int $staffId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM invoice_items WHERE id = :id');
        $stmt->execute([':id' => $invoiceItemId]);
        $item = $stmt->fetch();
        if (!$item) {
            throw new \Exception('Item not found.');
        }
        if (!$item['is_manual']) {
            throw new \Exception('Only manually-added items can be removed. System-generated charges reflect services actually rendered.');
        }
        $invoice = self::find((int)$item['invoice_id']);
        if ($invoice['status'] === 'Paid') {
            throw new \Exception('Cannot modify a paid invoice.');
        }

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('DELETE FROM invoice_items WHERE id = :id');
            $stmt->execute([':id' => $invoiceItemId]);
            self::recalculateTotals((int)$item['invoice_id']);
            AuditLog::log($staffId, 'invoice_items', $invoiceItemId, 'remove_manual_item', "invoice={$item['invoice_id']}");
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function applyDiscount(int $invoiceId, float $discountAmount, int $staffId): void
    {
        $invoice = self::find($invoiceId);
        if (!$invoice || $invoice['status'] === 'Paid') {
            throw new \Exception('Cannot discount a paid or missing invoice.');
        }
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE invoices SET discount_amount = :d WHERE id = :id');
        $stmt->execute([':d' => $discountAmount, ':id' => $invoiceId]);
        self::recalculateTotals($invoiceId);
        AuditLog::log($staffId, 'invoices', $invoiceId, 'apply_discount', "amount={$discountAmount}");
    }

    private static function recalculateTotals(int $invoiceId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT COALESCE(SUM(subtotal),0) AS t FROM invoice_items WHERE invoice_id = :id');
        $stmt->execute([':id' => $invoiceId]);
        $itemsTotal = (float)$stmt->fetch()['t'];

        $invoice = self::find($invoiceId);
        $total = max(0, $itemsTotal - (float)$invoice['discount_amount']);
        $balance = max(0, $total - (float)$invoice['amount_paid'] - (float)$invoice['insurance_covered_amount']);

        $stmt = $pdo->prepare('UPDATE invoices SET total_amount = :t, balance = :b, updated_at = :now WHERE id = :id');
        $stmt->execute([':t' => $total, ':b' => $balance, ':now' => date('c'), ':id' => $invoiceId]);
    }

    // ------------------------------------------------------------------
    // Insurance
    // ------------------------------------------------------------------

    public static function applyInsurance(int $invoiceId, int $patientInsuranceId, int $staffId): array
    {
        self::recalculateTotals($invoiceId);
        $invoice = self::find($invoiceId);
        if (!$invoice) {
            throw new \Exception('Invoice not found.');
        }
        if ((float)$invoice['balance'] <= 0.0001) {
            throw new \Exception('Invoice is already fully paid.');
        }

        $claimableAmount = (float)$invoice['balance'];
        $result = Insurance::fileAndVerifyClaim($invoiceId, $patientInsuranceId, $claimableAmount, $staffId);
        $approved = (float)$result['approved_amount'];

        $pdo = Database::getConnection();
        $newCovered = (float)$invoice['insurance_covered_amount'] + $approved;
        $payerType = $approved >= $claimableAmount ? 'Insurance' : ($approved > 0 ? 'Mixed' : $invoice['payer_type']);

        $stmt = $pdo->prepare('UPDATE invoices SET insurance_covered_amount = :c, payer_type = :pt WHERE id = :id');
        $stmt->execute([':c' => $newCovered, ':pt' => $payerType, ':id' => $invoiceId]);
        self::recalculateTotals($invoiceId);

        $invoice = self::find($invoiceId);
        if ((float)$invoice['balance'] <= 0.0001) {
            $stmt = $pdo->prepare('UPDATE invoices SET status = "Paid", updated_at = :now WHERE id = :id');
            $stmt->execute([':now' => date('c'), ':id' => $invoiceId]);
        } elseif ($newCovered > 0) {
            $stmt = $pdo->prepare('UPDATE invoices SET status = "Partially Paid", updated_at = :now WHERE id = :id');
            $stmt->execute([':now' => date('c'), ':id' => $invoiceId]);
        }

        AuditLog::log($staffId, 'invoices', $invoiceId, 'apply_insurance', "approved={$approved} claim={$result['claim_id']}");

        return $result;
    }

    // ------------------------------------------------------------------
    // Payments
    // ------------------------------------------------------------------

    public static function recordPayment(
        int $invoiceId,
        string $paymentMethod,
        float $amount,
        ?int $receivedByStaffId = null,
        ?string $transactionReference = null
    ): int {
        $pdo = Database::getConnection();
        // Always recalc first so total/balance match line items (fixes mixed recovery state)
        self::recalculateTotals($invoiceId);
        $invoice = self::find($invoiceId);
        if (!$invoice) {
            throw new \Exception('Invoice not found.');
        }

        $balance = (float)$invoice['balance'];
        // Trust the numeric balance, not a stale status flag left over from recovery
        if ($balance <= 0.0001) {
            // Align status with reality
            $pdo->prepare(
                'UPDATE invoices SET status = \'Paid\', updated_at = :now WHERE id = :id'
            )->execute([':now' => date('c'), ':id' => $invoiceId]);
            throw new \Exception('Invoice is already fully paid.');
        }
        if ($amount <= 0) {
            throw new \Exception('Payment amount must be greater than zero.');
        }
        // Do not allow overpayment beyond remaining balance
        if ($amount > $balance + 0.009) {
            throw new \Exception(
                'Payment amount (TZS ' . number_format($amount, 2) . ') exceeds remaining balance (TZS ' . number_format($balance, 2) . ').'
            );
        }
        // Repair stale Paid status when balance still remains (e.g. after bill regenerate)
        if ($invoice['status'] === 'Paid' || $invoice['status'] === 'Cancelled') {
            $fixStatus = (float)$invoice['amount_paid'] > 0.0001 ? 'Partially Paid' : 'Pending';
            $pdo->prepare(
                'UPDATE invoices SET status = :st, updated_at = :now WHERE id = :id'
            )->execute([':st' => $fixStatus, ':now' => date('c'), ':id' => $invoiceId]);
            $invoice['status'] = $fixStatus;
        }

        $controlNumber = $paymentMethod === 'Mobile Money' ? self::generateControlNumber() : null;

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO payment_transactions (invoice_id, control_number, payment_method, transaction_reference,
                    amount_paid, received_by, payment_date, payment_status)
                 VALUES (:iid, :cn, :method, :ref, :amt, :staff, :now, "Completed")'
            );
            $stmt->execute([
                ':iid' => $invoiceId, ':cn' => $controlNumber, ':method' => $paymentMethod, ':ref' => $transactionReference,
                ':amt' => $amount, ':staff' => $receivedByStaffId, ':now' => date('c'),
            ]);
            $paymentId = (int)$pdo->lastInsertId();

            $newPaid = (float)$invoice['amount_paid'] + $amount;
            $stmt = $pdo->prepare('UPDATE invoices SET amount_paid = :paid WHERE id = :id');
            $stmt->execute([':paid' => $newPaid, ':id' => $invoiceId]);
            self::recalculateTotals($invoiceId);

            $invoice = self::find($invoiceId);
            $status = (float)$invoice['balance'] <= 0.0001 ? 'Paid' : 'Partially Paid';
            $stmt = $pdo->prepare('UPDATE invoices SET status = :status, updated_at = :now WHERE id = :id');
            $stmt->execute([':status' => $status, ':now' => date('c'), ':id' => $invoiceId]);

            $stmt = $pdo->prepare(
                'INSERT INTO payments (patient_id, invoice_id, type, amount, receipt_number, recorded_by_staff_id, paid_at)
                 VALUES (:pid, :iid, "Billing", :amt, :rcpt, :staff, :now)'
            );
            $stmt->execute([
                ':pid' => $invoice['patient_id'], ':iid' => $invoiceId, ':amt' => $amount,
                ':rcpt' => 'RCPT-' . strtoupper(bin2hex(random_bytes(4))), ':staff' => $receivedByStaffId, ':now' => date('c'),
            ]);

            self::generateReceipt($invoiceId, $paymentId, $receivedByStaffId);
            AuditLog::log($receivedByStaffId, 'payment_transactions', $paymentId, 'record_payment', "invoice={$invoiceId} amount={$amount} method={$paymentMethod}");

            $pdo->commit();
            return $paymentId;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private static function generateReceipt(int $invoiceId, int $paymentId, ?int $staffId): string
    {
        $pdo = Database::getConnection();
        $receiptNumber = 'RCT-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $stmt = $pdo->prepare(
            'INSERT INTO receipts (receipt_number, invoice_id, payment_id, printed_by, printed_at, reprint_count)
             VALUES (:num, :iid, :pid, :staff, :now, 0)'
        );
        $stmt->execute([':num' => $receiptNumber, ':iid' => $invoiceId, ':pid' => $paymentId, ':staff' => $staffId, ':now' => date('c')]);
        return $receiptNumber;
    }

    public static function reprintReceipt(int $receiptId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE receipts SET reprint_count = reprint_count + 1 WHERE id = :id');
        $stmt->execute([':id' => $receiptId]);
        $stmt = $pdo->prepare('SELECT * FROM receipts WHERE id = :id');
        $stmt->execute([':id' => $receiptId]);
        return $stmt->fetch();
    }

    // ------------------------------------------------------------------
    // Dispensing gate — used by Dispensation::record()
    // ------------------------------------------------------------------

    public static function isPrescriptionPayable(int $prescriptionId): bool
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT i.status
             FROM invoice_items ii
             JOIN invoices i ON i.id = ii.invoice_id
             WHERE ii.service_type = 'Pharmacy' AND ii.reference_id = :rid
             LIMIT 1"
        );
        $stmt->execute([':rid' => $prescriptionId]);
        $row = $stmt->fetch();

        return $row && $row['status'] === 'Paid';
    }

    // ------------------------------------------------------------------
    // Lookups
    // ------------------------------------------------------------------

    public static function find(int $invoiceId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM invoices WHERE id = :id');
        $stmt->execute([':id' => $invoiceId]);
        return $stmt->fetch() ?: null;
    }

    public static function getItems(int $invoiceId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM invoice_items WHERE invoice_id = :id ORDER BY id');
        $stmt->execute([':id' => $invoiceId]);
        return $stmt->fetchAll();
    }

    public static function getPayments(int $invoiceId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM payment_transactions WHERE invoice_id = :id ORDER BY payment_date');
        $stmt->execute([':id' => $invoiceId]);
        return $stmt->fetchAll();
    }

    public static function getOutstanding(): array
    {
        $pdo = Database::getConnection();
        // Prefer recently updated (e.g. admin-regenerated) invoices first
        $stmt = $pdo->query(
            "SELECT i.*, p.patient_id AS patient_code, p.full_name
             FROM invoices i JOIN patients p ON p.id = i.patient_id
             WHERE i.status IN ('Pending','Partially Paid')
                OR (i.status != 'Cancelled' AND i.balance > 0.009)
             ORDER BY i.updated_at DESC, i.generated_at ASC"
        );
        return $stmt->fetchAll();
    }

    public static function getPaid(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            "SELECT i.*, p.patient_id AS patient_code, p.full_name
             FROM invoices i JOIN patients p ON p.id = i.patient_id
             WHERE i.status = 'Paid' ORDER BY i.updated_at DESC"
        );
        return $stmt->fetchAll();
    }

    public static function getPatientHistory(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT i.*, GROUP_CONCAT(DISTINCT pt.payment_method) AS methods
             FROM invoices i
             LEFT JOIN payment_transactions pt ON pt.invoice_id = i.id
             WHERE i.patient_id = :pid GROUP BY i.id ORDER BY i.generated_at DESC'
        );
        $stmt->execute([':pid' => $patientId]);
        return $stmt->fetchAll();
    }

    // ------------------------------------------------------------------
    // Reports
    // ------------------------------------------------------------------

    public static function revenueBetween(string $fromDate, string $toDate): float
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT COALESCE(SUM(amount_paid),0) AS total FROM payment_transactions
             WHERE payment_status = "Completed" AND payment_date BETWEEN :from AND :to'
        );
        $stmt->execute([':from' => $fromDate, ':to' => $toDate]);
        return (float)$stmt->fetch()['total'];
    }

    public static function revenueByDepartment(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT service_type, COALESCE(SUM(subtotal),0) AS total FROM invoice_items GROUP BY service_type');
        return $stmt->fetchAll();
    }

    public static function revenueByPaymentMethod(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT payment_method, COALESCE(SUM(amount_paid),0) AS total FROM payment_transactions
             WHERE payment_status = "Completed" GROUP BY payment_method'
        );
        return $stmt->fetchAll();
    }

    public static function billingOfficerCollections(int $staffId, string $fromDate, string $toDate): float
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT COALESCE(SUM(amount_paid),0) AS total FROM payment_transactions
             WHERE received_by = :sid AND payment_status = "Completed" AND payment_date BETWEEN :from AND :to'
        );
        $stmt->execute([':sid' => $staffId, ':from' => $fromDate, ':to' => $toDate]);
        return (float)$stmt->fetch()['total'];
    }

    public static function insuranceStats(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            "SELECT status, COUNT(*) AS count, COALESCE(SUM(approved_amount),0) AS total_approved
             FROM insurance_claims GROUP BY status"
        );
        return $stmt->fetchAll();
    }

    // ------------------------------------------------------------------
    // Number generators
    // ------------------------------------------------------------------

    private static function generateInvoiceNumber(): string
    {
        return 'INV-' . date('Y') . '-' . str_pad((string)random_int(1, 999999), 6, '0', STR_PAD_LEFT);
    }

    private static function generateControlNumber(): string
    {
        return 'DSMS-' . date('Y') . '-' . str_pad((string)random_int(1, 999999), 6, '0', STR_PAD_LEFT);
    }
}