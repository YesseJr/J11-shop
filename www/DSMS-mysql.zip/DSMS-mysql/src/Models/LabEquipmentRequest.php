<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/LabEquipment.php';
require_once __DIR__ . '/Budget.php';
require_once __DIR__ . '/AuditLog.php';

/**
 * Lab's equivalent of MedicinePurchaseRequest — a request for either brand
 * new equipment, or a replacement for something worn out/broken. Approval
 * is what actually moves budget and updates the equipment register.
 */
class LabEquipmentRequest
{
    public static function create(
        string $requestType,
        string $equipmentName,
        ?string $category,
        float $unitCost,
        int $requestedByStaffId,
        ?int $equipmentId = null,
        ?string $notes = null
    ): int {
        if (!in_array($requestType, ['New', 'Replacement'], true)) {
            throw new \Exception('Invalid request type.');
        }
        if (trim($equipmentName) === '') {
            throw new \Exception('Equipment name is required.');
        }
        if ($unitCost <= 0) {
            throw new \Exception('Cost must be greater than zero.');
        }
        if ($requestType === 'Replacement' && !$equipmentId) {
            throw new \Exception('Select which equipment is being replaced.');
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO lab_equipment_requests
                (request_type, equipment_id, equipment_name, category, unit_cost, status, notes, requested_by_staff_id, requested_at)
             VALUES (:type, :equipment_id, :name, :category, :cost, "Pending", :notes, :staff_id, :requested_at)'
        );
        $stmt->execute([
            ':type' => $requestType,
            ':equipment_id' => $equipmentId,
            ':name' => $equipmentName,
            ':category' => $category ?: null,
            ':cost' => $unitCost,
            ':notes' => $notes ?: null,
            ':staff_id' => $requestedByStaffId,
            ':requested_at' => date('c'),
        ]);

        $id = (int)$pdo->lastInsertId();
        AuditLog::log($requestedByStaffId, 'lab_equipment_requests', $id, 'request', "{$requestType} {$equipmentName} cost={$unitCost}");

        return $id;
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT r.*, s.full_name AS requested_by_name
             FROM lab_equipment_requests r
             JOIN staff s ON s.id = r.requested_by_staff_id
             WHERE r.id = :id'
        );
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public static function getPending(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT r.*, s.full_name AS requested_by_name
             FROM lab_equipment_requests r
             JOIN staff s ON s.id = r.requested_by_staff_id
             WHERE r.status = "Pending"
             ORDER BY r.requested_at ASC'
        );
        return $stmt->fetchAll();
    }

    public static function getAll(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT r.*, s.full_name AS requested_by_name, d.full_name AS decided_by_name
             FROM lab_equipment_requests r
             JOIN staff s ON s.id = r.requested_by_staff_id
             LEFT JOIN staff d ON d.id = r.decided_by_staff_id
             ORDER BY r.requested_at DESC'
        );
        return $stmt->fetchAll();
    }

    public static function getForStaff(int $staffId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM lab_equipment_requests WHERE requested_by_staff_id = :staff_id ORDER BY requested_at DESC'
        );
        $stmt->execute([':staff_id' => $staffId]);
        return $stmt->fetchAll();
    }

    /**
     * Approves the request: deducts the cost from the laboratory budget,
     * then either registers new equipment or retires the old unit and
     * registers its replacement. Throws (and changes nothing) if the
     * request isn't pending or would exceed the laboratory budget's
     * remaining balance.
     */
    public static function approve(int $id, int $decidedByStaffId): void
    {
        $request = self::find($id);
        if (!$request || $request['status'] !== 'Pending') {
            throw new \Exception('This request is no longer pending.');
        }

        $totals = Budget::departmentTotals('laboratory');
        if ($totals['remaining'] < (float)$request['unit_cost']) {
            throw new \Exception(
                'Approving this purchase (TZS ' . number_format((float)$request['unit_cost'], 2) . ') would exceed the laboratory budget\'s remaining balance (TZS ' . number_format($totals['remaining'], 2) . '). Raise the laboratory budget allocation first.'
            );
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();
        try {
            if ($request['request_type'] === 'Replacement' && $request['equipment_id']) {
                LabEquipment::retire((int)$request['equipment_id'], 'Replaced via request #' . $id);
            }
            LabEquipment::create($request['equipment_name'], $request['category'], (float)$request['unit_cost']);
            Budget::recordExpenditure('laboratory', (float)$request['unit_cost']);

            $stmt = $pdo->prepare(
                'UPDATE lab_equipment_requests SET status = "Approved", decided_by_staff_id = :staff_id, decided_at = :decided_at WHERE id = :id'
            );
            $stmt->execute([':staff_id' => $decidedByStaffId, ':decided_at' => date('c'), ':id' => $id]);

            $pdo->commit();
        } catch (\Exception $e) {
            $pdo->rollBack();
            throw $e;
        }

        AuditLog::log($decidedByStaffId, 'lab_equipment_requests', $id, 'approve', "cost={$request['unit_cost']}");
    }

    public static function reject(int $id, int $decidedByStaffId, ?string $reason = null): void
    {
        $request = self::find($id);
        if (!$request || $request['status'] !== 'Pending') {
            throw new \Exception('This request is no longer pending.');
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'UPDATE lab_equipment_requests SET status = "Rejected", decided_by_staff_id = :staff_id, decision_note = :note, decided_at = :decided_at WHERE id = :id'
        );
        $stmt->execute([':staff_id' => $decidedByStaffId, ':note' => $reason ?: null, ':decided_at' => date('c'), ':id' => $id]);

        AuditLog::log($decidedByStaffId, 'lab_equipment_requests', $id, 'reject', $reason ?: '');
    }
}
