<?php

require_once __DIR__ . '/../../src/Database.php';

/**
 * Lab's equivalent of the medicine catalog: a simple asset register for
 * equipment (analyzers, microscopes, centrifuges, etc.) with a condition
 * status, rather than a consumable stock count. Lab doesn't hold
 * consumable inventory yet — this covers what it actually procures:
 * durable equipment that gets worn out and replaced.
 */
class LabEquipment
{
    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT * FROM lab_equipment ORDER BY status = "Retired" ASC, name ASC');
        return $stmt->fetchAll();
    }

    public static function active(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query("SELECT * FROM lab_equipment WHERE is_active = 1 AND status != 'Retired' ORDER BY name ASC");
        return $stmt->fetchAll();
    }

    /** Equipment currently flagged as worn out or needing repair — the pool a replacement request should be picked from. */
    public static function needsAttention(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query("SELECT * FROM lab_equipment WHERE is_active = 1 AND status IN ('Needs Repair', 'Worn Out') ORDER BY name ASC");
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM lab_equipment WHERE id = :id');
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    /** Registers a newly delivered piece of equipment (called on request approval). */
    public static function create(string $name, ?string $category, float $purchaseCost): int
    {
        $pdo = Database::getConnection();
        $now = date('c');
        $stmt = $pdo->prepare(
            'INSERT INTO lab_equipment (name, category, status, purchase_cost, purchased_at, is_active, created_at, updated_at)
             VALUES (:name, :category, "Operational", :cost, :purchased_at, 1, :created, :updated)'
        );
        $stmt->execute([
            ':name' => $name,
            ':category' => $category ?: null,
            ':cost' => $purchaseCost,
            ':purchased_at' => $now,
            ':created' => $now,
            ':updated' => $now,
        ]);
        return (int)$pdo->lastInsertId();
    }

    /**
     * Registers equipment that already physically exists in the lab but
     * was never entered into the system — no purchase, no budget impact.
     * Unlike create(), this lets you set the initial condition directly
     * (the equipment might already be worn when you first log it).
     */
    public static function registerExisting(string $name, ?string $category, string $status, ?string $conditionNotes = null): int
    {
        $allowed = ['Operational', 'Needs Repair', 'Worn Out'];
        if (!in_array($status, $allowed, true)) {
            throw new \Exception('Invalid equipment status.');
        }

        $pdo = Database::getConnection();
        $now = date('c');
        $stmt = $pdo->prepare(
            'INSERT INTO lab_equipment (name, category, status, condition_notes, purchase_cost, purchased_at, is_active, created_at, updated_at)
             VALUES (:name, :category, :status, :notes, 0.00, NULL, 1, :created, :updated)'
        );
        $stmt->execute([
            ':name' => $name,
            ':category' => $category ?: null,
            ':status' => $status,
            ':notes' => $conditionNotes ?: null,
            ':created' => $now,
            ':updated' => $now,
        ]);
        return (int)$pdo->lastInsertId();
    }

    /** Lab staff flagging equipment condition day-to-day — no cost/budget impact by itself. */
    public static function flagStatus(int $id, string $status, ?string $notes = null): void
    {
        $allowed = ['Operational', 'Needs Repair', 'Worn Out', 'Retired'];
        if (!in_array($status, $allowed, true)) {
            throw new \Exception('Invalid equipment status.');
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE lab_equipment SET status = :status, condition_notes = :notes, updated_at = :now WHERE id = :id');
        $stmt->execute([':status' => $status, ':notes' => $notes ?: null, ':now' => date('c'), ':id' => $id]);
    }

    /** Marks equipment as retired/replaced once a replacement has been approved. */
    public static function retire(int $id, ?string $notes = null): void
    {
        self::flagStatus($id, 'Retired', $notes);
    }

    public static function markServiced(int $id): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE lab_equipment SET last_serviced_at = :now, updated_at = :now WHERE id = :id');
        $stmt->execute([':now' => date('c'), ':id' => $id]);
    }
}
