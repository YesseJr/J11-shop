<?php

require_once __DIR__ . '/../../src/Database.php';

/**
 * Insurance
 * ---------
 * Local-only implementation now (no external provider API). Structured so
 * verifyClaim() is the one place a real insurer integration would plug in
 * later — everything else (coverage math, claim records) stays the same.
 */
class Insurance
{
    public static function addPolicy(
        int $patientId,
        string $provider,
        string $insuranceNumber,
        float $coveragePercent = 100.00,
        ?string $validFrom = null,
        ?string $validTo = null,
        ?string $notes = null
    ): int {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO patient_insurance (patient_id, insurance_provider, insurance_number, membership_status,
                coverage_percent, coverage_notes, valid_from, valid_to, created_at)
             VALUES (:pid, :provider, :num, "Active", :pct, :notes, :from, :to, :now)'
        );
        $stmt->execute([
            ':pid' => $patientId, ':provider' => $provider, ':num' => $insuranceNumber,
            ':pct' => $coveragePercent, ':notes' => $notes, ':from' => $validFrom, ':to' => $validTo,
            ':now' => date('c'),
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function activePolicyForPatient(int $patientId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT * FROM patient_insurance
             WHERE patient_id = :pid AND membership_status = 'Active'
               AND (valid_to IS NULL OR valid_to >= CURDATE())
             ORDER BY created_at DESC LIMIT 1"
        );
        $stmt->execute([':pid' => $patientId]);
        return $stmt->fetch() ?: null;
    }

    /**
     * Create a claim for an invoice and immediately "verify" it against the
     * policy's coverage_percent. This is the local stand-in for a real
     * insurer verification call — swap the body of this method for an HTTP
     * call to the provider's API when one becomes available; the return
     * shape (claim id + approved_amount) is what the rest of the system
     * depends on, so callers won't need to change.
     */
    public static function fileAndVerifyClaim(int $invoiceId, int $patientInsuranceId, float $claimedAmount, ?int $staffId = null): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM patient_insurance WHERE id = :id');
        $stmt->execute([':id' => $patientInsuranceId]);
        $policy = $stmt->fetch();
        if (!$policy) {
            throw new \Exception('Insurance policy not found.');
        }
        if ($policy['membership_status'] !== 'Active') {
            throw new \Exception('Insurance membership is not active.');
        }

        $approvedAmount = round($claimedAmount * ((float)$policy['coverage_percent'] / 100), 2);
        $status = $approvedAmount >= $claimedAmount ? 'Verified' : ($approvedAmount > 0 ? 'Partially Approved' : 'Rejected');

        $stmt = $pdo->prepare(
            'INSERT INTO insurance_claims (invoice_id, patient_insurance_id, claimed_amount, approved_amount,
                status, verified_by, verified_at, created_at)
             VALUES (:iid, :pid, :claimed, :approved, :status, :staff, :now, :now2)'
        );
        $stmt->execute([
            ':iid' => $invoiceId, ':pid' => $patientInsuranceId, ':claimed' => $claimedAmount,
            ':approved' => $approvedAmount, ':status' => $status, ':staff' => $staffId, ':now' => date('c'), ':now2' => date('c'),
        ]);
        $claimId = (int)$pdo->lastInsertId();

        AuditLog::log($staffId, 'insurance_claims', $claimId, 'file_and_verify',
            "invoice={$invoiceId} claimed={$claimedAmount} approved={$approvedAmount} status={$status}");

        return ['claim_id' => $claimId, 'approved_amount' => $approvedAmount, 'status' => $status];
    }

    public static function getClaimsForInvoice(int $invoiceId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM insurance_claims WHERE invoice_id = :iid ORDER BY created_at DESC');
        $stmt->execute([':iid' => $invoiceId]);
        return $stmt->fetchAll();
    }
}