<?php

require_once __DIR__ . '/../../src/Database.php';

class Staff
{
    public static function authenticate(string $username, string $password): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM staff WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$username, $username]);
        $staff = $stmt->fetch();

        if (!$staff || !password_verify($password, $staff['password_hash'])) {
            return ['staff' => null, 'error' => 'invalid'];
        }

        if (!$staff['is_active']) {
            return ['staff' => null, 'error' => 'inactive'];
        }

        $stmt = $pdo->prepare('UPDATE staff SET last_login = ? WHERE id = ?');
        $stmt->execute([date('c'), $staff['id']]);

        return ['staff' => $staff, 'error' => null];
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM staff WHERE id = ? AND is_active = 1');
        $stmt->execute([$id]);

        return $stmt->fetch() ?: null;
    }

    public static function create(string $username, string $email, string $fullName, string $role, string $password, ?string $specialization = null): int
    {
        $pdo = Database::getConnection();
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $now = date('c');

        $stmt = $pdo->prepare(
            'INSERT INTO staff (username, email, password_hash, full_name, role, specialization, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$username, $email, $hashedPassword, $fullName, $role, $specialization, $now, $now]);

        return (int)$pdo->lastInsertId();
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT id, username, email, full_name, role, specialization, is_active, last_login, created_at FROM staff ORDER BY created_at DESC');

        return $stmt->fetchAll();
    }

    /** Active doctors, for the receptionist's "assign a doctor" dropdown.
     *  Specialization is shown alongside the name so reception can route
     *  a patient to the right kind of doctor (e.g. Dentist vs General). */
    public static function getDoctors(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            "SELECT id, full_name, specialization FROM staff
             WHERE role = 'doctor' AND is_active = 1
             ORDER BY full_name ASC"
        );
        return $stmt->fetchAll();
    }

    public static function updateStatus(int $id, bool $isActive): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE staff SET is_active = ?, updated_at = ? WHERE id = ?');
        $stmt->execute([$isActive ? 1 : 0, date('c'), $id]);
    }

    public static function getById(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM staff WHERE id = ?');
        $stmt->execute([$id]);

        return $stmt->fetch() ?: null;
    }

    public static function update(int $id, string $username, string $email, string $fullName, string $role, ?string $password = null, ?string $specialization = null): void
    {
        $pdo = Database::getConnection();
        $params = [$username, $email, $fullName, $role, $specialization, date('c'), $id];
        $sql = 'UPDATE staff SET username = ?, email = ?, full_name = ?, role = ?, specialization = ?, updated_at = ?';

        if ($password !== null && $password !== '') {
            $sql .= ', password_hash = ?';
            $params = [$username, $email, $fullName, $role, $specialization, date('c'), password_hash($password, PASSWORD_BCRYPT), $id];
        }

        $sql .= ' WHERE id = ?';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    }

    public static function delete(int $id): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('DELETE FROM staff WHERE id = ?');
        $stmt->execute([$id]);
    }

    public static function getByRole(string $role): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT id, username, full_name, email, role FROM staff WHERE role = ? AND is_active = 1 ORDER BY full_name ASC');
        $stmt->execute([$role]);

        return $stmt->fetchAll();
    }

    // ------------------------------------------------------------------
    // Self-service profile (the logged-in staff member editing their own
    // account) — deliberately separate from update()/create() above,
    // which are the admin-only staff-management versions. A regular
    // staff member should never be able to change their own role or
    // active status through these methods.
    // ------------------------------------------------------------------

    /** Update the staff member's own display info. Username and role are
     *  intentionally not editable here — those stay admin-controlled. */
    public static function updateOwnProfile(int $id, string $fullName, string $email): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE staff SET full_name = ?, email = ?, updated_at = ? WHERE id = ?');
        $stmt->execute([$fullName, $email, date('c'), $id]);
    }

    /** Verifies the current password before setting a new one. Returns
     *  false (and changes nothing) if the current password is wrong. */
    public static function changeOwnPassword(int $id, string $currentPassword, string $newPassword): bool
    {
        $staff = self::getById($id);
        if (!$staff || !password_verify($currentPassword, $staff['password_hash'])) {
            return false;
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE staff SET password_hash = ?, updated_at = ? WHERE id = ?');
        $stmt->execute([password_hash($newPassword, PASSWORD_BCRYPT), date('c'), $id]);

        return true;
    }

    /** Stores the relative path (e.g. "uploads/avatars/staff_3_....jpg")
     *  to the staff member's profile picture. */
    public static function updateAvatar(int $id, string $relativePath): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE staff SET avatar = ?, updated_at = ? WHERE id = ?');
        $stmt->execute([$relativePath, date('c'), $id]);
    }

    public static function removeAvatar(int $id): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE staff SET avatar = NULL, updated_at = ? WHERE id = ?');
        $stmt->execute([date('c'), $id]);
    }
}