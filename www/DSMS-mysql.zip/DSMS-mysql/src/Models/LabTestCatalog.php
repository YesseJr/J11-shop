<?php

require_once __DIR__ . '/../../src/Database.php';

class LabTestCatalog
{
    public static function active(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT * FROM lab_test_catalog WHERE is_active = 1 ORDER BY test_name ASC');
        return $stmt->fetchAll();
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT * FROM lab_test_catalog ORDER BY test_name ASC');
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM lab_test_catalog WHERE id = :id');
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public static function create(string $testName, float $price, ?string $defaultUnit = null, ?string $referenceRange = null): int
    {
        $pdo = Database::getConnection();
        $now = date('c');
        $stmt = $pdo->prepare(
            'INSERT INTO lab_test_catalog (test_name, price, default_unit, reference_range, is_active, created_at, updated_at)
             VALUES (:name, :price, :unit, :ref, 1, :created, :updated)'
        );
        $stmt->execute([
            ':name' => $testName,
            ':price' => $price,
            ':unit' => $defaultUnit,
            ':ref' => $referenceRange,
            ':created' => $now,
            ':updated' => $now,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, string $testName, float $price, ?string $defaultUnit = null, ?string $referenceRange = null): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'UPDATE lab_test_catalog SET test_name = :name, price = :price, default_unit = :unit, reference_range = :ref, updated_at = :now WHERE id = :id'
        );
        $stmt->execute([
            ':name' => $testName,
            ':price' => $price,
            ':unit' => $defaultUnit,
            ':ref' => $referenceRange,
            ':now' => date('c'),
            ':id' => $id,
        ]);
    }

    public static function setActive(int $id, bool $active): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE lab_test_catalog SET is_active = :active, updated_at = :now WHERE id = :id');
        $stmt->execute([':active' => $active ? 1 : 0, ':now' => date('c'), ':id' => $id]);
    }
}
