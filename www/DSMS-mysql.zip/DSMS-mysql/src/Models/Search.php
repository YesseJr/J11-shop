<?php

require_once __DIR__ . '/../../src/Database.php';

/**
 * Permission-aware global search. Read-only.
 */
class Search
{
    public static function query(string $q, string $role, int $limit = 8): array
    {
        $q = trim($q);
        if (strlen($q) < 2) {
            return [];
        }
        $pdo = Database::getConnection();
        $like = '%' . $q . '%';
        $out = [];

        // Patients — all clinical roles
        if (in_array($role, ['admin', 'doctor', 'receptionist', 'billing', 'pharmacy', 'lab'], true)) {
            $stmt = $pdo->prepare(
                'SELECT id, patient_id, full_name, status FROM patients
                 WHERE patient_id LIKE :q OR full_name LIKE :q2 OR phone LIKE :q3
                 ORDER BY id DESC LIMIT ' . (int)$limit
            );
            $stmt->execute([':q' => $like, ':q2' => $like, ':q3' => $like]);
            foreach ($stmt->fetchAll() as $r) {
                $out[] = [
                    'category' => 'Patients',
                    'title' => $r['patient_id'] . ' — ' . $r['full_name'],
                    'subtitle' => $r['status'],
                    'url' => '?action=workflow_timeline&patient_id=' . (int)$r['id'],
                ];
            }
        }

        // Invoices — billing & admin
        if (in_array($role, ['admin', 'billing'], true)) {
            $stmt = $pdo->prepare(
                'SELECT i.id, i.invoice_number, i.status, i.balance, p.full_name
                 FROM invoices i JOIN patients p ON p.id = i.patient_id
                 WHERE i.invoice_number LIKE :q OR p.full_name LIKE :q2 OR p.patient_id LIKE :q3
                 ORDER BY i.id DESC LIMIT ' . (int)$limit
            );
            $stmt->execute([':q' => $like, ':q2' => $like, ':q3' => $like]);
            foreach ($stmt->fetchAll() as $r) {
                $out[] = [
                    'category' => 'Bills',
                    'title' => $r['invoice_number'] . ' — ' . $r['full_name'],
                    'subtitle' => $r['status'] . ' · bal ' . number_format((float)$r['balance'], 2),
                    'url' => '?action=view_invoice&invoice_id=' . (int)$r['id'],
                ];
            }
        }

        // Prescriptions
        if (in_array($role, ['admin', 'doctor', 'pharmacy'], true)) {
            $stmt = $pdo->prepare(
                'SELECT pr.id, pr.medication, pr.status, p.full_name, p.patient_id
                 FROM prescriptions pr JOIN patients p ON p.id = pr.patient_id
                 WHERE pr.medication LIKE :q OR p.full_name LIKE :q2 OR p.patient_id LIKE :q3
                 ORDER BY pr.id DESC LIMIT ' . (int)$limit
            );
            $stmt->execute([':q' => $like, ':q2' => $like, ':q3' => $like]);
            foreach ($stmt->fetchAll() as $r) {
                $out[] = [
                    'category' => 'Prescriptions',
                    'title' => $r['medication'] . ' — ' . $r['patient_id'],
                    'subtitle' => $r['full_name'] . ' · ' . ($r['status'] ?? ''),
                    'url' => '?action=pharmacy_dashboard',
                ];
            }
        }

        // Medicines
        if (in_array($role, ['admin', 'doctor', 'pharmacy'], true)) {
            $stmt = $pdo->prepare(
                'SELECT id, name, dosage_form, quantity, status FROM medicines
                 WHERE name LIKE :q ORDER BY name ASC LIMIT ' . (int)$limit
            );
            $stmt->execute([':q' => $like]);
            foreach ($stmt->fetchAll() as $r) {
                $out[] = [
                    'category' => 'Medicines',
                    'title' => $r['name'] . ' (' . $r['dosage_form'] . ')',
                    'subtitle' => $r['status'] . ' · stock ' . (int)$r['quantity'],
                    'url' => '?action=medicine_inventory',
                ];
            }
        }

        // Lab requests
        if (in_array($role, ['admin', 'doctor', 'lab'], true)) {
            $stmt = $pdo->prepare(
                'SELECT l.id, l.test_type, l.status, p.full_name, p.patient_id
                 FROM lab_requests l
                 JOIN consultations c ON c.id = l.consultation_id
                 JOIN patients p ON p.id = c.patient_id
                 WHERE l.test_type LIKE :q OR p.full_name LIKE :q2 OR p.patient_id LIKE :q3
                 ORDER BY l.id DESC LIMIT ' . (int)$limit
            );
            $stmt->execute([':q' => $like, ':q2' => $like, ':q3' => $like]);
            foreach ($stmt->fetchAll() as $r) {
                $out[] = [
                    'category' => 'Laboratory',
                    'title' => $r['test_type'] . ' — ' . $r['patient_id'],
                    'subtitle' => $r['full_name'] . ' · ' . ($r['status'] ?? ''),
                    'url' => '?action=lab_dashboard',
                ];
            }
        }

        // Staff — admin only
        if ($role === 'admin') {
            $stmt = $pdo->prepare(
                'SELECT id, full_name, role, username FROM staff
                 WHERE full_name LIKE :q OR username LIKE :q2 OR email LIKE :q3
                 ORDER BY full_name ASC LIMIT ' . (int)$limit
            );
            $stmt->execute([':q' => $like, ':q2' => $like, ':q3' => $like]);
            foreach ($stmt->fetchAll() as $r) {
                $out[] = [
                    'category' => 'Staff',
                    'title' => $r['full_name'],
                    'subtitle' => $r['role'] . ' · @' . $r['username'],
                    'url' => '?action=admin_dashboard',
                ];
            }
        }

        return $out;
    }
}
