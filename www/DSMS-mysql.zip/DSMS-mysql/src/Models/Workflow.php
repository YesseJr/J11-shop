<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Notification.php';

/**
 * Workflow visibility & lost-patient detection.
 * Does NOT generate invoices or change billing totals — that stays in Billing.php.
 */
class Workflow
{
    /** Default idle thresholds (minutes). Overridable via system_settings. */
    public const DEFAULT_IDLE_MINUTES = 120;
    public const DEFAULT_BILLING_IDLE_MINUTES = 60;

    public static function getSetting(string $key, $default = null)
    {
        $pdo = Database::getConnection();
        try {
            $stmt = $pdo->prepare('SELECT setting_value FROM system_settings WHERE setting_key = :k LIMIT 1');
            $stmt->execute([':k' => $key]);
            $row = $stmt->fetch();
            return $row ? $row['setting_value'] : $default;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    public static function setSetting(string $key, string $value): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO system_settings (setting_key, setting_value, updated_at)
             VALUES (:k, :v, :now)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)'
        );
        $stmt->execute([':k' => $key, ':v' => $value, ':now' => date('c')]);
    }

    public static function idleMinutes(): int
    {
        return max(15, (int)self::getSetting('workflow_idle_minutes', (string)self::DEFAULT_IDLE_MINUTES));
    }

    public static function billingIdleMinutes(): int
    {
        return max(10, (int)self::getSetting('billing_idle_minutes', (string)self::DEFAULT_BILLING_IDLE_MINUTES));
    }

    /**
     * Build a full timeline for a patient (latest visit / consultation preferred).
     */
    public static function timelineForPatient(int $patientId, ?int $consultationId = null): array
    {
        $pdo = Database::getConnection();

        $patient = $pdo->prepare('SELECT * FROM patients WHERE id = :id');
        $patient->execute([':id' => $patientId]);
        $pt = $patient->fetch();
        if (!$pt) {
            return [];
        }

        if ($consultationId === null) {
            $c = $pdo->prepare('SELECT id FROM consultations WHERE patient_id = :pid ORDER BY id DESC LIMIT 1');
            $c->execute([':pid' => $patientId]);
            $row = $c->fetch();
            $consultationId = $row ? (int)$row['id'] : null;
        }

        $steps = [];

        // Reception / registration
        $regStaff = null;
        if (!empty($pt['registered_by_staff_id'])) {
            $s = $pdo->prepare('SELECT full_name FROM staff WHERE id = :id');
            $s->execute([':id' => $pt['registered_by_staff_id']]);
            $regStaff = $s->fetchColumn() ?: null;
        }
        $steps[] = [
            'key' => 'reception',
            'label' => 'Reception',
            'status' => 'completed',
            'staff' => $regStaff,
            'at' => $pt['created_at'] ?? null,
            'detail' => 'Patient registered',
        ];

        // Queue / vitals
        $q = $pdo->prepare('SELECT * FROM queue_entries WHERE patient_id = :pid ORDER BY id DESC LIMIT 1');
        $q->execute([':pid' => $patientId]);
        $queue = $q->fetch() ?: null;
        $steps[] = [
            'key' => 'queue',
            'label' => 'Consultation Queue',
            'status' => $queue ? (($queue['status'] === 'Accepted' || $queue['accepted_at']) ? 'completed' : 'active') : 'pending',
            'staff' => null,
            'at' => $queue['queued_at'] ?? ($queue['accepted_at'] ?? null),
            'detail' => $queue ? ('Queue: ' . $queue['status']) : 'Not queued',
        ];

        // Consultation
        $consultation = null;
        if ($consultationId) {
            $c = $pdo->prepare(
                'SELECT c.*, s.full_name AS doctor_name, s.specialization
                 FROM consultations c
                 LEFT JOIN staff s ON s.id = c.doctor_staff_id
                 WHERE c.id = :id'
            );
            $c->execute([':id' => $consultationId]);
            $consultation = $c->fetch() ?: null;
        }
        $steps[] = [
            'key' => 'consultation',
            'label' => 'Consultation',
            'status' => $consultation
                ? ((int)$consultation['treatment_finalized'] === 1 || ($consultation['diagnosis'] ?? '') !== '' ? 'completed' : 'active')
                : 'pending',
            'staff' => $consultation['doctor_name'] ?? null,
            'at' => $consultation['created_at'] ?? null,
            'detail' => $consultation
                ? ('Diagnosis recorded' . ((int)$consultation['treatment_finalized'] === 1 ? ' · finalized' : ''))
                : 'Awaiting doctor',
        ];

        // Laboratory
        $labStatus = 'pending';
        $labAt = null;
        $labStaff = null;
        $labDetail = 'No lab requested';
        if ($consultationId) {
            $labs = $pdo->prepare(
                'SELECT l.*, r.uploaded_at, r.uploaded_by_staff_id, s.full_name AS lab_staff
                 FROM lab_requests l
                 LEFT JOIN lab_results r ON r.lab_request_id = l.id
                 LEFT JOIN staff s ON s.id = r.uploaded_by_staff_id
                 WHERE l.consultation_id = :cid ORDER BY l.id'
            );
            $labs->execute([':cid' => $consultationId]);
            $labRows = $labs->fetchAll();
            if (!empty($labRows)) {
                $pending = 0;
                $done = 0;
                foreach ($labRows as $lr) {
                    if (!empty($lr['uploaded_at'])) {
                        $done++;
                        $labAt = $lr['uploaded_at'];
                        $labStaff = $lr['lab_staff'];
                    } else {
                        $pending++;
                        $labAt = $lr['created_at'];
                    }
                }
                if ($pending === 0) {
                    $labStatus = 'completed';
                    $labDetail = $done . ' result(s) ready';
                } else {
                    $labStatus = 'active';
                    $labDetail = $pending . ' pending / ' . $done . ' ready';
                }
            }
        }
        $steps[] = [
            'key' => 'laboratory',
            'label' => 'Laboratory',
            'status' => $labStatus,
            'staff' => $labStaff,
            'at' => $labAt,
            'detail' => $labDetail,
        ];

        // Prescription
        $rxStatus = 'pending';
        $rxAt = null;
        $rxStaff = null;
        $rxDetail = 'No prescription';
        if ($consultationId) {
            $rx = $pdo->prepare(
                'SELECT p.*, s.full_name AS doctor_name FROM prescriptions p
                 LEFT JOIN staff s ON s.id = p.doctor_staff_id
                 WHERE p.consultation_id = :cid AND p.status != \'Cancelled\' ORDER BY p.id'
            );
            $rx->execute([':cid' => $consultationId]);
            $rxRows = $rx->fetchAll();
            if (!empty($rxRows)) {
                $finalized = 0;
                $draft = 0;
                foreach ($rxRows as $r) {
                    $rxStaff = $r['doctor_name'];
                    $rxAt = $r['locked_at'] ?: $r['created_at'];
                    if (($r['status'] ?? '') === 'Finalized') {
                        $finalized++;
                    } else {
                        $draft++;
                    }
                }
                if ($draft === 0 && $finalized > 0) {
                    $rxStatus = 'completed';
                    $rxDetail = $finalized . ' line(s) locked';
                } else {
                    $rxStatus = 'active';
                    $rxDetail = $draft . ' draft / ' . $finalized . ' finalized';
                }
            }
        }
        $steps[] = [
            'key' => 'prescription',
            'label' => 'Prescription',
            'status' => $rxStatus,
            'staff' => $rxStaff,
            'at' => $rxAt,
            'detail' => $rxDetail,
        ];

        // Billing / invoice
        $inv = null;
        if ($consultationId) {
            $i = $pdo->prepare(
                'SELECT i.*, s.full_name AS biller_name
                 FROM invoices i
                 LEFT JOIN staff s ON s.id = i.assigned_biller_id
                 WHERE i.consultation_id = :cid ORDER BY i.id DESC LIMIT 1'
            );
            $i->execute([':cid' => $consultationId]);
            $inv = $i->fetch() ?: null;
        }
        $billStatus = 'pending';
        $billDetail = 'No invoice';
        if ($inv) {
            if ($inv['status'] === 'Paid') {
                $billStatus = 'completed';
                $billDetail = 'Invoice ' . $inv['invoice_number'] . ' paid';
            } elseif ($inv['status'] === 'Cancelled') {
                $billStatus = 'cancelled';
                $billDetail = 'Invoice cancelled';
            } else {
                $billStatus = 'active';
                $billDetail = 'Invoice ' . $inv['invoice_number'] . ' · ' . $inv['status'];
                if (!empty($inv['assigned_biller_id'])) {
                    $billDetail .= ' · assigned to ' . ($inv['biller_name'] ?? 'biller');
                } else {
                    $billDetail .= ' · unassigned';
                }
            }
        } elseif ($consultation && (int)$consultation['treatment_finalized'] === 1) {
            $billStatus = 'blocked';
            $billDetail = 'Finalized but no invoice (lost bill)';
        }
        $steps[] = [
            'key' => 'billing',
            'label' => 'Billing',
            'status' => $billStatus,
            'staff' => $inv['biller_name'] ?? null,
            'at' => $inv['generated_at'] ?? ($consultation['finalized_at'] ?? null),
            'detail' => $billDetail,
        ];

        // Payment
        $payStatus = 'pending';
        $payAt = null;
        $payStaff = null;
        $payDetail = 'Awaiting payment';
        if ($inv) {
            if ($inv['status'] === 'Paid' || (float)$inv['balance'] <= 0.009) {
                $payStatus = 'completed';
                $payDetail = 'Fully paid';
                $ptx = $pdo->prepare(
                    'SELECT pt.*, s.full_name FROM payment_transactions pt
                     LEFT JOIN staff s ON s.id = pt.received_by
                     WHERE pt.invoice_id = :iid ORDER BY pt.id DESC LIMIT 1'
                );
                $ptx->execute([':iid' => $inv['id']]);
                $p = $ptx->fetch();
                if ($p) {
                    $payAt = $p['payment_date'];
                    $payStaff = $p['full_name'];
                }
            } elseif ((float)$inv['amount_paid'] > 0) {
                $payStatus = 'active';
                $payDetail = 'Partially paid · balance ' . number_format((float)$inv['balance'], 2);
            } else {
                $payStatus = 'active';
                $payDetail = 'Unpaid · due ' . number_format((float)$inv['total_amount'], 2);
            }
        }
        $steps[] = [
            'key' => 'payment',
            'label' => 'Payment',
            'status' => $payStatus,
            'staff' => $payStaff,
            'at' => $payAt,
            'detail' => $payDetail,
        ];

        // Pharmacy / dispensation
        $phStatus = 'pending';
        $phAt = null;
        $phStaff = null;
        $phDetail = 'Awaiting dispense';
        if ($consultationId) {
            $d = $pdo->prepare(
                'SELECT d.*, s.full_name FROM dispensations d
                 JOIN prescriptions p ON p.id = d.prescription_id
                 LEFT JOIN staff s ON s.id = d.pharmacy_staff_id
                 WHERE p.consultation_id = :cid ORDER BY d.id DESC'
            );
            $d->execute([':cid' => $consultationId]);
            $disp = $d->fetchAll();
            $rxCountStmt = $pdo->prepare(
                "SELECT COUNT(*) FROM prescriptions WHERE consultation_id = :cid AND status = 'Finalized'"
            );
            $rxCountStmt->execute([':cid' => $consultationId]);
            $rxCount = (int)$rxCountStmt->fetchColumn();
            if ($rxCount === 0) {
                $phStatus = 'skipped';
                $phDetail = 'No medicines prescribed';
            } elseif (count($disp) >= $rxCount) {
                $phStatus = 'completed';
                $phDetail = count($disp) . ' dispensation(s)';
                $phAt = $disp[0]['dispensed_at'] ?? null;
                $phStaff = $disp[0]['full_name'] ?? null;
            } elseif (count($disp) > 0) {
                $phStatus = 'active';
                $phDetail = count($disp) . '/' . $rxCount . ' dispensed';
                $phAt = $disp[0]['dispensed_at'] ?? null;
                $phStaff = $disp[0]['full_name'] ?? null;
            } elseif ($inv && ($inv['status'] === 'Paid' || (float)$inv['balance'] <= 0.009)) {
                $phStatus = 'active';
                $phDetail = 'Paid — ready to dispense';
            } else {
                $phStatus = 'pending';
                $phDetail = 'Waiting for payment before dispense';
            }
        }
        $steps[] = [
            'key' => 'pharmacy',
            'label' => 'Pharmacy',
            'status' => $phStatus,
            'staff' => $phStaff,
            'at' => $phAt,
            'detail' => $phDetail,
        ];

        // Completed
        $done = true;
        foreach ($steps as $st) {
            if (in_array($st['status'], ['active', 'blocked', 'pending'], true) && $st['key'] !== 'laboratory' && $st['status'] !== 'skipped') {
                // laboratory pending is ok if no lab; already handled
            }
        }
        $allTerminal = true;
        foreach ($steps as $st) {
            if (in_array($st['status'], ['active', 'blocked'], true)) {
                $allTerminal = false;
                break;
            }
            if ($st['status'] === 'pending' && !in_array($st['key'], ['laboratory', 'pharmacy'], true)) {
                // still early
            }
        }
        $completed = $inv && ($inv['status'] === 'Paid') && in_array($phStatus, ['completed', 'skipped'], true);
        $steps[] = [
            'key' => 'completed',
            'label' => 'Completed',
            'status' => $completed ? 'completed' : 'pending',
            'staff' => null,
            'at' => $completed ? ($phAt ?: $payAt) : null,
            'detail' => $completed ? 'Visit complete' : 'In progress',
        ];

        // Mark first non-completed / non-skipped as blocked highlight if idle?
        return [
            'patient' => $pt,
            'consultation' => $consultation,
            'invoice' => $inv,
            'queue' => $queue,
            'steps' => $steps,
            'blocked_key' => self::firstBlockedKey($steps),
        ];
    }

    private static function firstBlockedKey(array $steps): ?string
    {
        foreach ($steps as $st) {
            if ($st['status'] === 'blocked' || $st['status'] === 'active') {
                return $st['key'];
            }
        }
        return null;
    }

    /**
     * Detect lost / stalled patients across the facility.
     */
    public static function detectLostPatients(): array
    {
        $pdo = Database::getConnection();
        $idleMin = self::idleMinutes();
        $billingIdle = self::billingIdleMinutes();
        $now = time();
        $results = [];

        // Latest queue entry per patient (scalar subquery — ONLY_FULL_GROUP_BY safe)
        $latestQueueSql = '(SELECT q2.id FROM queue_entries q2 WHERE q2.patient_id = %s ORDER BY q2.id DESC LIMIT 1)';

        // 1) Finalized treatment, no invoice
        $sql1 = "
            SELECT c.id AS consultation_id, c.patient_id, c.finalized_at, c.created_at AS consult_at,
                   pt.patient_id AS patient_code, pt.full_name AS patient_name, pt.status AS patient_status,
                   s.full_name AS doctor_name, s.specialization AS department,
                   " . sprintf($latestQueueSql, 'c.patient_id') . " AS queue_entry_id,
                   'Bill never generated' AS missing_step,
                   'Finalized · no invoice' AS workflow_stage
            FROM consultations c
            JOIN patients pt ON pt.id = c.patient_id
            LEFT JOIN staff s ON s.id = c.doctor_staff_id
            LEFT JOIN invoices i ON i.consultation_id = c.id
            WHERE c.treatment_finalized = 1 AND i.id IS NULL
        ";
        foreach ($pdo->query($sql1)->fetchAll() as $row) {
            $results[] = self::enrichLostRow($row, $row['finalized_at'] ?: $row['consult_at'], $now);
        }

        // 2) Invoice exists, unassigned, idle
        $sql2 = "
            SELECT c.id AS consultation_id, c.patient_id, i.id AS invoice_id, i.invoice_number,
                   i.generated_at, i.status AS invoice_status, i.total_amount, i.balance,
                   i.assigned_biller_id, i.assigned_at, i.priority,
                   pt.patient_id AS patient_code, pt.full_name AS patient_name, pt.status AS patient_status,
                   s.full_name AS doctor_name, s.specialization AS department,
                   i.queue_entry_id AS queue_entry_id,
                   'Bill unassigned' AS missing_step,
                   'Billing · unassigned' AS workflow_stage
            FROM invoices i
            JOIN consultations c ON c.id = i.consultation_id
            JOIN patients pt ON pt.id = i.patient_id
            LEFT JOIN staff s ON s.id = c.doctor_staff_id
            WHERE i.status IN ('Pending','Partially Paid')
              AND (i.assigned_biller_id IS NULL OR i.assigned_biller_id = 0)
        ";
        foreach ($pdo->query($sql2)->fetchAll() as $row) {
            $last = $row['generated_at'];
            $ageMin = (int)(($now - strtotime($last ?: 'now')) / 60);
            if ($ageMin >= $billingIdle) {
                $results[] = self::enrichLostRow($row, $last, $now);
            }
        }

        // 3) Assigned but no payment activity beyond threshold
        $sql3 = "
            SELECT c.id AS consultation_id, c.patient_id, i.id AS invoice_id, i.invoice_number,
                   i.generated_at, i.status AS invoice_status, i.total_amount, i.balance,
                   i.assigned_biller_id, i.assigned_at, i.priority, i.updated_at,
                   pt.patient_id AS patient_code, pt.full_name AS patient_name, pt.status AS patient_status,
                   s.full_name AS doctor_name, s.specialization AS department,
                   b.full_name AS biller_name,
                   i.queue_entry_id AS queue_entry_id,
                   'Payment not started' AS missing_step,
                   'Billing · assigned, unpaid' AS workflow_stage
            FROM invoices i
            JOIN consultations c ON c.id = i.consultation_id
            JOIN patients pt ON pt.id = i.patient_id
            LEFT JOIN staff s ON s.id = c.doctor_staff_id
            LEFT JOIN staff b ON b.id = i.assigned_biller_id
            WHERE i.status = 'Pending'
              AND i.assigned_biller_id IS NOT NULL AND i.assigned_biller_id > 0
              AND i.amount_paid = 0
        ";
        foreach ($pdo->query($sql3)->fetchAll() as $row) {
            $last = $row['assigned_at'] ?: $row['updated_at'] ?: $row['generated_at'];
            $ageMin = (int)(($now - strtotime($last ?: 'now')) / 60);
            if ($ageMin >= $billingIdle) {
                $results[] = self::enrichLostRow($row, $last, $now);
            }
        }

        // 4) Patient status suggests left / inactive with open work
        // Use latest invoice per consultation via subquery to stay ONLY_FULL_GROUP_BY safe
        $sql4 = "
            SELECT c.id AS consultation_id, c.patient_id, c.created_at AS consult_at, c.finalized_at,
                   pt.patient_id AS patient_code, pt.full_name AS patient_name, pt.status AS patient_status,
                   s.full_name AS doctor_name, s.specialization AS department,
                   inv.id AS invoice_id, inv.status AS invoice_status, inv.balance,
                   " . sprintf($latestQueueSql, 'c.patient_id') . " AS queue_entry_id,
                   'Patient inactive / left' AS missing_step,
                   CONCAT('Patient status: ', pt.status) AS workflow_stage
            FROM patients pt
            JOIN consultations c ON c.patient_id = pt.id
            LEFT JOIN staff s ON s.id = c.doctor_staff_id
            LEFT JOIN invoices inv ON inv.id = (
                SELECT i2.id FROM invoices i2
                WHERE i2.consultation_id = c.id
                ORDER BY i2.id DESC LIMIT 1
            )
            WHERE pt.status IN ('Left','Absconded','Inactive','No Show')
               OR (c.treatment_finalized = 0 AND c.created_at IS NOT NULL)
        ";
        try {
            foreach ($pdo->query($sql4)->fetchAll() as $row) {
                $last = $row['finalized_at'] ?: $row['consult_at'];
                $ageMin = (int)(($now - strtotime($last ?: 'now')) / 60);
                if ($ageMin >= $idleMin || in_array($row['patient_status'], ['Left', 'Absconded', 'No Show'], true)) {
                    if (($row['invoice_status'] ?? '') === 'Paid') {
                        continue;
                    }
                    $results[] = self::enrichLostRow($row, $last, $now);
                }
            }
        } catch (\Throwable $e) {
            // status values may not include Left etc. on all installs — ignore
        }

        // 5) Prescription finalized lines without invoice_item (data integrity)
        $sql5 = "
            SELECT p.id AS prescription_id, p.consultation_id, p.patient_id, p.created_at AS rx_at, p.locked_at,
                   pt.patient_id AS patient_code, pt.full_name AS patient_name, pt.status AS patient_status,
                   s.full_name AS doctor_name, s.specialization AS department,
                   inv.id AS invoice_id, inv.status AS invoice_status,
                   " . sprintf($latestQueueSql, 'p.patient_id') . " AS queue_entry_id,
                   'Prescription not on invoice' AS missing_step,
                   'Billing data gap' AS workflow_stage
            FROM prescriptions p
            JOIN patients pt ON pt.id = p.patient_id
            LEFT JOIN staff s ON s.id = p.doctor_staff_id
            LEFT JOIN invoices inv ON inv.id = (
                SELECT i2.id FROM invoices i2
                WHERE i2.consultation_id = p.consultation_id
                ORDER BY i2.id DESC LIMIT 1
            )
            LEFT JOIN invoice_items ii ON ii.reference_id = p.id
                AND ii.service_type = 'Pharmacy'
                AND ii.invoice_id = inv.id
            WHERE p.status = 'Finalized' AND ii.id IS NULL
        ";
        foreach ($pdo->query($sql5)->fetchAll() as $row) {
            $results[] = self::enrichLostRow($row, $row['locked_at'] ?: $row['rx_at'], $now);
        }

        // Dedupe by consultation_id + missing_step
        $seen = [];
        $unique = [];
        foreach ($results as $r) {
            $key = ($r['consultation_id'] ?? 0) . '|' . ($r['missing_step'] ?? '') . '|' . ($r['patient_id'] ?? 0);
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $unique[] = $r;
        }

        usort($unique, static function ($a, $b) {
            return ($b['waiting_seconds'] ?? 0) <=> ($a['waiting_seconds'] ?? 0);
        });

        return $unique;
    }

    private static function enrichLostRow(array $row, ?string $lastActivity, int $now): array
    {
        $ts = $lastActivity ? strtotime($lastActivity) : $now;
        $seconds = max(0, $now - $ts);
        $hours = intdiv($seconds, 3600);
        $mins = intdiv($seconds % 3600, 60);
        $row['last_activity'] = $lastActivity;
        $row['waiting_seconds'] = $seconds;
        $row['time_waiting'] = $hours > 0 ? "{$hours}h {$mins}m" : "{$mins}m";
        $row['severity'] = $seconds >= 4 * 3600 ? 'critical' : ($seconds >= 2 * 3600 ? 'high' : 'normal');
        return $row;
    }

    /** Real-time stage counts for monitoring widgets. */
    public static function stageCounts(): array
    {
        $pdo = Database::getConnection();
        $counts = [
            'waiting_consultation' => 0,
            'in_laboratory' => 0,
            'waiting_billing' => 0,
            'awaiting_payment' => 0,
            'waiting_pharmacy' => 0,
            'completed_visits' => 0,
            'lost_patients' => 0,
        ];

        $counts['waiting_consultation'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM queue_entries WHERE status IN ('Waiting','Waiting for Consultation')"
        )->fetchColumn();

        $counts['in_laboratory'] = (int)$pdo->query(
            "SELECT COUNT(DISTINCT l.consultation_id) FROM lab_requests l
             LEFT JOIN lab_results r ON r.lab_request_id = l.id
             WHERE r.id IS NULL"
        )->fetchColumn();

        $counts['waiting_billing'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM consultations c
             LEFT JOIN invoices i ON i.consultation_id = c.id
             WHERE c.treatment_finalized = 1 AND i.id IS NULL"
        )->fetchColumn();

        $counts['awaiting_payment'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM invoices WHERE status IN ('Pending','Partially Paid')"
        )->fetchColumn();

        $counts['waiting_pharmacy'] = (int)$pdo->query(
            "SELECT COUNT(DISTINCT p.id) FROM prescriptions p
             JOIN invoices i ON i.consultation_id = p.consultation_id AND i.status = 'Paid'
             LEFT JOIN dispensations d ON d.prescription_id = p.id
             WHERE p.status = 'Finalized' AND d.id IS NULL"
        )->fetchColumn();

        $counts['completed_visits'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM invoices WHERE status = 'Paid'"
        )->fetchColumn();

        $counts['lost_patients'] = count(self::detectLostPatients());

        return $counts;
    }

    /**
     * Billing queue: every unpaid finalized visit / invoice.
     * Guarantees visibility until Paid or Cancelled.
     */
    public static function billingQueue(): array
    {
        $pdo = Database::getConnection();

        // Detect optional columns so older installs without migration still work
        $hasAssigned = false;
        $hasPriority = false;
        try {
            $col = $pdo->query(
                "SELECT column_name FROM information_schema.columns
                 WHERE table_schema = DATABASE() AND table_name = 'invoices'
                   AND column_name IN ('assigned_biller_id','priority')"
            )->fetchAll(\PDO::FETCH_COLUMN);
            $hasAssigned = in_array('assigned_biller_id', $col, true);
            $hasPriority = in_array('priority', $col, true);
        } catch (\Throwable $e) {
        }

        $billerSelect = $hasAssigned
            ? 'b.full_name AS biller_name, i.assigned_biller_id'
            : 'NULL AS biller_name, NULL AS assigned_biller_id';
        $billerJoin = $hasAssigned
            ? 'LEFT JOIN staff b ON b.id = i.assigned_biller_id'
            : '';
        $prioritySelect = $hasPriority ? 'i.priority' : "'normal' AS priority";

        // Include any invoice with a positive balance OR unpaid status.
        // This catches recovered invoices that may still have status quirks.
        $sql = "
            SELECT i.id, i.invoice_number, i.patient_id, i.consultation_id, i.queue_entry_id,
                   i.total_amount, i.amount_paid, i.balance, i.status, i.generated_at, i.updated_at,
                   {$prioritySelect},
                   pt.patient_id AS patient_code, pt.full_name AS patient_name,
                   c.id AS consultation_id, c.finalized_at,
                   s.full_name AS doctor_name,
                   {$billerSelect}
            FROM invoices i
            JOIN patients pt ON pt.id = i.patient_id
            JOIN consultations c ON c.id = i.consultation_id
            LEFT JOIN staff s ON s.id = c.doctor_staff_id
            {$billerJoin}
            WHERE i.status IN ('Pending','Partially Paid')
               OR (i.status != 'Cancelled' AND i.balance > 0.009)
            ORDER BY i.updated_at DESC, i.generated_at ASC
        ";

        try {
            $rows = $pdo->query($sql)->fetchAll();
        } catch (\Throwable $e) {
            // Absolute fallback — minimal columns
            $rows = $pdo->query(
                "SELECT i.*, pt.patient_id AS patient_code, pt.full_name AS patient_name,
                        c.finalized_at, NULL AS doctor_name, NULL AS biller_name, NULL AS assigned_biller_id
                 FROM invoices i
                 JOIN patients pt ON pt.id = i.patient_id
                 JOIN consultations c ON c.id = i.consultation_id
                 WHERE i.status IN ('Pending','Partially Paid') OR i.balance > 0.009
                 ORDER BY i.id DESC"
            )->fetchAll();
        }

        $now = time();
        foreach ($rows as &$r) {
            $start = $r['updated_at'] ?? ($r['generated_at'] ?: ($r['finalized_at'] ?? null));
            $secs = max(0, $now - strtotime($start ?: 'now'));
            $r['wait_minutes'] = intdiv($secs, 60);
            $r['time_waiting'] = $r['wait_minutes'] >= 60
                ? intdiv($r['wait_minutes'], 60) . 'h ' . ($r['wait_minutes'] % 60) . 'm'
                : $r['wait_minutes'] . 'm';
            if (empty($r['priority'])) {
                $r['priority'] = $r['wait_minutes'] >= 120 ? 'high' : 'normal';
            }
            // Surface recovered Paid-but-balance invoices as actionable
            if (($r['status'] ?? '') === 'Paid' && (float)($r['balance'] ?? 0) > 0.009) {
                $r['status'] = 'Partially Paid';
            }
        }
        unset($r);

        usort($rows, static function ($a, $b) {
            $po = ['urgent' => 0, 'high' => 1, 'normal' => 2];
            $pa = $po[$a['priority'] ?? 'normal'] ?? 2;
            $pb = $po[$b['priority'] ?? 'normal'] ?? 2;
            if ($pa !== $pb) {
                return $pa <=> $pb;
            }
            return ($b['wait_minutes'] ?? 0) <=> ($a['wait_minutes'] ?? 0);
        });

        return $rows;
    }

    public static function assignBiller(int $invoiceId, int $billerStaffId, int $adminStaffId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'UPDATE invoices SET assigned_biller_id = :b, assigned_at = :now, updated_at = :now2 WHERE id = :id AND status != \'Paid\''
        );
        $stmt->execute([
            ':b' => $billerStaffId,
            ':now' => date('c'),
            ':now2' => date('c'),
            ':id' => $invoiceId,
        ]);
        if ($stmt->rowCount() === 0) {
            // column may be missing on very old installs mid-request — try without fail
        }
        Notification::create(
            $billerStaffId,
            'billing',
            'assignment',
            'Invoice assigned to you',
            'Invoice #' . $invoiceId . ' was assigned for collection.',
            'view_invoice',
            $invoiceId
        );
    }

    public static function markPatientReturned(int $patientId, int $adminStaffId): void
    {
        require_once __DIR__ . '/Patient.php';
        Patient::updateStatus($patientId, 'Awaiting Payment');
        Notification::notifyRole(
            'billing',
            'patient_returned',
            'Patient returned',
            'Patient #' . $patientId . ' marked as returned and is ready for billing.',
            'billing_queue',
            $patientId
        );
    }

    /** Lightweight scan: flag lost cases and notify admin once per consultation. */
    public static function runLostPatientScan(): int
    {
        $lost = self::detectLostPatients();
        $pdo = Database::getConnection();
        $flagged = 0;
        foreach ($lost as $row) {
            $cid = (int)($row['consultation_id'] ?? 0);
            if ($cid <= 0) {
                continue;
            }
            // Avoid spamming: one unread admin alert per consultation per missing_step per day
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM notifications
                 WHERE type = 'lost_patient' AND entity_id = :cid AND is_read = 0
                   AND created_at >= :since"
            );
            $stmt->execute([
                ':cid' => $cid,
                ':since' => date('c', strtotime('-12 hours')),
            ]);
            if ((int)$stmt->fetchColumn() > 0) {
                continue;
            }
            Notification::notifyRole(
                'admin',
                'lost_patient',
                'Lost patient detected',
                ($row['patient_name'] ?? 'Patient') . ' — ' . ($row['missing_step'] ?? 'workflow stalled'),
                'lost_patients',
                $cid
            );
            $flagged++;
        }
        return $flagged;
    }

    /**
     * Escalations: idle beyond configurable thresholds (minutes).
     * Does not mutate clinical data — flags only + optional notifications.
     */
    public static function detectEscalations(): array
    {
        $pdo = Database::getConnection();
        $billingLimit = max(5, (int)self::getSetting('escalation_billing_minutes', '30'));
        $pharmacyLimit = max(5, (int)self::getSetting('escalation_pharmacy_minutes', '20'));
        $labLimit = max(5, (int)self::getSetting('escalation_lab_minutes', '60'));
        $now = time();
        $out = [];

        // Billing wait
        try {
            $rows = $pdo->query(
                "SELECT i.id AS invoice_id, i.invoice_number, i.generated_at, i.updated_at, i.balance, i.status,
                        pt.patient_id AS patient_code, pt.full_name AS patient_name, pt.id AS patient_id,
                        c.id AS consultation_id
                 FROM invoices i
                 JOIN patients pt ON pt.id = i.patient_id
                 JOIN consultations c ON c.id = i.consultation_id
                 WHERE i.status IN ('Pending','Partially Paid') OR i.balance > 0.009"
            )->fetchAll();
            foreach ($rows as $r) {
                $start = strtotime($r['generated_at'] ?: ($r['updated_at'] ?: 'now'));
                $mins = (int)(($now - $start) / 60);
                if ($mins >= $billingLimit) {
                    $out[] = [
                        'type' => 'billing_wait',
                        'label' => 'Waiting for Billing',
                        'threshold_minutes' => $billingLimit,
                        'waiting_minutes' => $mins,
                        'patient_code' => $r['patient_code'],
                        'patient_name' => $r['patient_name'],
                        'patient_id' => $r['patient_id'],
                        'consultation_id' => $r['consultation_id'],
                        'invoice_id' => $r['invoice_id'],
                        'detail' => $r['invoice_number'] . ' · balance ' . number_format((float)$r['balance'], 2),
                        'severity' => $mins >= $billingLimit * 2 ? 'critical' : 'high',
                    ];
                }
            }
        } catch (\Throwable $e) {
        }

        // Pharmacy wait after paid
        try {
            $rows = $pdo->query(
                "SELECT p.id AS prescription_id, p.medication, p.created_at, i.updated_at AS paid_at,
                        pt.patient_id AS patient_code, pt.full_name AS patient_name, pt.id AS patient_id,
                        p.consultation_id
                 FROM prescriptions p
                 JOIN invoices i ON i.consultation_id = p.consultation_id AND i.status = 'Paid'
                 JOIN patients pt ON pt.id = p.patient_id
                 LEFT JOIN dispensations d ON d.prescription_id = p.id
                 WHERE p.status = 'Finalized' AND d.id IS NULL"
            )->fetchAll();
            foreach ($rows as $r) {
                $start = strtotime($r['paid_at'] ?: ($r['created_at'] ?: 'now'));
                $mins = (int)(($now - $start) / 60);
                if ($mins >= $pharmacyLimit) {
                    $out[] = [
                        'type' => 'pharmacy_wait',
                        'label' => 'Waiting for Pharmacy',
                        'threshold_minutes' => $pharmacyLimit,
                        'waiting_minutes' => $mins,
                        'patient_code' => $r['patient_code'],
                        'patient_name' => $r['patient_name'],
                        'patient_id' => $r['patient_id'],
                        'consultation_id' => $r['consultation_id'],
                        'invoice_id' => null,
                        'detail' => $r['medication'],
                        'severity' => $mins >= $pharmacyLimit * 2 ? 'critical' : 'high',
                    ];
                }
            }
        } catch (\Throwable $e) {
        }

        // Lab overdue
        try {
            $rows = $pdo->query(
                "SELECT l.id AS lab_request_id, l.test_type, l.created_at, l.consultation_id,
                        pt.patient_id AS patient_code, pt.full_name AS patient_name, pt.id AS patient_id
                 FROM lab_requests l
                 JOIN consultations c ON c.id = l.consultation_id
                 JOIN patients pt ON pt.id = c.patient_id
                 LEFT JOIN lab_results r ON r.lab_request_id = l.id
                 WHERE r.id IS NULL"
            )->fetchAll();
            foreach ($rows as $r) {
                $start = strtotime($r['created_at'] ?: 'now');
                $mins = (int)(($now - $start) / 60);
                if ($mins >= $labLimit) {
                    $out[] = [
                        'type' => 'lab_overdue',
                        'label' => 'Laboratory result overdue',
                        'threshold_minutes' => $labLimit,
                        'waiting_minutes' => $mins,
                        'patient_code' => $r['patient_code'],
                        'patient_name' => $r['patient_name'],
                        'patient_id' => $r['patient_id'],
                        'consultation_id' => $r['consultation_id'],
                        'invoice_id' => null,
                        'detail' => $r['test_type'],
                        'severity' => $mins >= $labLimit * 2 ? 'critical' : 'high',
                    ];
                }
            }
        } catch (\Throwable $e) {
        }

        usort($out, static fn($a, $b) => ($b['waiting_minutes'] ?? 0) <=> ($a['waiting_minutes'] ?? 0));
        return $out;
    }

    public static function notifyEscalations(): int
    {
        $items = self::detectEscalations();
        $n = 0;
        foreach ($items as $item) {
            if (($item['severity'] ?? '') !== 'critical') {
                continue;
            }
            $role = match ($item['type'] ?? '') {
                'billing_wait' => 'billing',
                'pharmacy_wait' => 'pharmacy',
                'lab_overdue' => 'lab',
                default => 'admin',
            };
            try {
                Notification::notifyRole(
                    $role,
                    'escalation',
                    'Escalation: ' . ($item['label'] ?? 'Workflow delay'),
                    ($item['patient_name'] ?? '') . ' — waiting ' . ($item['waiting_minutes'] ?? 0) . ' min. ' . ($item['detail'] ?? ''),
                    'escalations',
                    (int)($item['consultation_id'] ?? 0) ?: null
                );
                Notification::notifyRole(
                    'admin',
                    'escalation',
                    'Escalation: ' . ($item['label'] ?? 'Workflow delay'),
                    ($item['patient_name'] ?? '') . ' — ' . ($item['detail'] ?? ''),
                    'escalations',
                    (int)($item['consultation_id'] ?? 0) ?: null
                );
                $n++;
            } catch (\Throwable $e) {
            }
        }
        return $n;
    }

}
