<?php

require_once __DIR__ . '/../../src/Database.php';

/**
 * PatientHistory
 * ---------------
 * Read-only views over clinical + billing data for the "Patient History"
 * screens. Doctors only ever see patients they have personally treated;
 * admins see everyone. Authorization is enforced here (doctorHasTreated)
 * as well as in the route handler, so this model is safe to call directly.
 */
class PatientHistory
{
    /** Patients a specific doctor has personally consulted at least once. */
    public static function forDoctor(int $doctorStaffId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT p.id, p.patient_id AS patient_code, p.full_name, p.gender, p.date_of_birth,
                    COUNT(c.id) AS visit_count, MAX(c.created_at) AS last_visit
             FROM patients p
             JOIN consultations c ON c.patient_id = p.id
             WHERE c.doctor_staff_id = :did
             GROUP BY p.id
             ORDER BY last_visit DESC'
        );
        $stmt->execute([':did' => $doctorStaffId]);
        return $stmt->fetchAll();
    }

    /** Every patient in the system, with a quick visit count — admin only. */
    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT p.id, p.patient_id AS patient_code, p.full_name, p.gender, p.date_of_birth,
                    COUNT(c.id) AS visit_count, MAX(c.created_at) AS last_visit
             FROM patients p
             LEFT JOIN consultations c ON c.patient_id = p.id
             GROUP BY p.id
             ORDER BY p.full_name ASC'
        );
        return $stmt->fetchAll();
    }

    /** The receptionist who originally registered this patient (whole-patient
     *  attribute, not per-visit — shown once on the admin detail page). */
    public static function registeredByName(int $patientId): ?string
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT s.full_name
             FROM patients p
             LEFT JOIN staff s ON s.id = p.registered_by_staff_id
             WHERE p.id = :pid'
        );
        $stmt->execute([':pid' => $patientId]);
        $row = $stmt->fetch();
        return $row['full_name'] ?? null;
    }

    /** True if this doctor has ever consulted this patient — used to gate
     *  access to a patient's detail/timeline view for non-admins. */
    public static function doctorHasTreated(int $doctorStaffId, int $patientId): bool
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) AS c FROM consultations WHERE doctor_staff_id = :did AND patient_id = :pid'
        );
        $stmt->execute([':did' => $doctorStaffId, ':pid' => $patientId]);
        return (int)$stmt->fetch()['c'] > 0;
    }

    /**
     * Full chronological treatment timeline for one patient: every
     * consultation, its lab requests/results, prescriptions/dispensations,
     * and the invoice/payment status for the visit. For a doctor caller,
     * pass $doctorStaffId to restrict to only that doctor's own
     * consultations with this patient (defense in depth alongside the
     * route-level authorization check).
     *
     * $includeStaffAttribution additionally resolves every staff member
     * who touched the visit (receptionist who queued it, whoever recorded
     * vitals, the doctor, lab technician, pharmacist, and biller) — this
     * is more query-heavy, so it's opt-in and intended for the admin view
     * only, not the doctor's own-patients view.
     */
    public static function timelineForPatient(int $patientId, ?int $doctorStaffId = null, bool $includeStaffAttribution = false): array
    {
        $pdo = Database::getConnection();

        $sql = 'SELECT c.*, s.full_name AS doctor_name
                FROM consultations c
                JOIN staff s ON s.id = c.doctor_staff_id
                WHERE c.patient_id = :pid';
        $params = [':pid' => $patientId];
        if ($doctorStaffId !== null) {
            $sql .= ' AND c.doctor_staff_id = :did';
            $params[':did'] = $doctorStaffId;
        }
        $sql .= ' ORDER BY c.created_at DESC';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $consultations = $stmt->fetchAll();

        foreach ($consultations as &$consultation) {
            $stmt = $pdo->prepare(
                'SELECT l.*, r.result, r.comments, r.uploaded_at, r.uploaded_by_staff_id,
                        ls.full_name AS uploaded_by_name
                 FROM lab_requests l
                 LEFT JOIN lab_results r ON r.lab_request_id = l.id
                 LEFT JOIN staff ls ON ls.id = r.uploaded_by_staff_id
                 WHERE l.consultation_id = :cid ORDER BY l.created_at ASC'
            );
            $stmt->execute([':cid' => $consultation['id']]);
            $consultation['lab_requests'] = $stmt->fetchAll();

            $stmt = $pdo->prepare(
                'SELECT p.*, d.quantity AS dispensed_quantity, d.dispensed_at, s.full_name AS dispensed_by
                 FROM prescriptions p
                 LEFT JOIN dispensations d ON d.prescription_id = p.id
                 LEFT JOIN staff s ON s.id = d.pharmacy_staff_id
                 WHERE p.consultation_id = :cid ORDER BY p.created_at ASC'
            );
            $stmt->execute([':cid' => $consultation['id']]);
            $consultation['prescriptions'] = $stmt->fetchAll();

            $stmt = $pdo->prepare('SELECT * FROM invoices WHERE consultation_id = :cid LIMIT 1');
            $stmt->execute([':cid' => $consultation['id']]);
            $consultation['invoice'] = $stmt->fetch() ?: null;

            if ($includeStaffAttribution) {
                // Receptionist who queued this visit: no direct FK between
                // queue_entries and consultations, so match the queue
                // entry closest before (or at) this consultation's start —
                // the same "closest prior record" heuristic already used
                // elsewhere in this codebase (e.g. Billing's visit linking).
                $stmt = $pdo->prepare(
                    'SELECT q.queued_at, s.full_name AS queued_by_name
                     FROM queue_entries q
                     LEFT JOIN staff s ON s.id = q.queued_by_staff_id
                     WHERE q.patient_id = :pid AND q.queued_at <= :created_at
                     ORDER BY q.queued_at DESC LIMIT 1'
                );
                $stmt->execute([':pid' => $patientId, ':created_at' => $consultation['created_at']]);
                $queueRow = $stmt->fetch();
                $consultation['queued_by_name'] = $queueRow['queued_by_name'] ?? null;

                // Vitals: most recent reading at or before this consultation.
                $stmt = $pdo->prepare(
                    'SELECT v.weight, v.height, v.temperature, v.blood_pressure, v.pulse_rate,
                            v.recorded_at, s.full_name AS recorded_by_name
                     FROM vitals v
                     LEFT JOIN staff s ON s.id = v.recorded_by_staff_id
                     WHERE v.patient_id = :pid AND v.recorded_at <= :created_at
                     ORDER BY v.recorded_at DESC LIMIT 1'
                );
                $stmt->execute([':pid' => $patientId, ':created_at' => $consultation['created_at']]);
                $consultation['vitals'] = $stmt->fetch() ?: null;

                // Biller(s): whoever generated the invoice and whoever
                // received each payment against it.
                $consultation['billing_staff'] = [];
                if ($consultation['invoice']) {
                    $stmt = $pdo->prepare('SELECT full_name FROM staff WHERE id = :id');
                    $stmt->execute([':id' => $consultation['invoice']['generated_by']]);
                    $generator = $stmt->fetch();
                    if ($generator) {
                        $consultation['billing_staff']['generated_by'] = $generator['full_name'];
                    }

                    $stmt = $pdo->prepare(
                        'SELECT DISTINCT s.full_name
                         FROM payment_transactions pt
                         JOIN staff s ON s.id = pt.received_by
                         WHERE pt.invoice_id = :iid'
                    );
                    $stmt->execute([':iid' => $consultation['invoice']['id']]);
                    $consultation['billing_staff']['received_by'] = array_column($stmt->fetchAll(), 'full_name');
                }
            }
        }
        unset($consultation);

        return $consultations;
    }
}