<?php

/**
 * Role-Based Access Control for DSMS.
 *
 * Single source of truth for which roles may perform which actions.
 * Use Rbac::enforce($action) after login, and Rbac::can() in UI.
 */
class Rbac
{
    public const ROLES = [
        'admin',
        'receptionist',
        'doctor',
        'lab',
        'pharmacy',
        'billing',
    ];

    /** Actions available without authentication. */
    private const PUBLIC_ACTIONS = [
        'landing',
        'login',
        'register',
    ];

    /**
     * action => list of roles allowed.
     * Missing actions fall back to admin-only (deny-by-default for unknown).
     * '*' means any authenticated role.
     */
    private static function map(): array
    {
        $all = self::ROLES;
        $clinical = ['doctor', 'admin'];
        $rx = ['pharmacy', 'admin'];
        $bill = ['billing', 'admin'];
        $lab = ['lab', 'admin'];
        $recep = ['receptionist', 'admin'];

        return [
            // Shared authenticated
            'dashboard' => $all,
            'my_profile' => $all,
            'update_my_profile' => $all,
            'change_my_password' => $all,
            'upload_avatar' => $all,
            'remove_avatar' => $all,
            'notifications_json' => $all,
            'mark_notification_read' => $all,
            'notification_history' => $all,
            'global_search' => $all,

            // Reception
            'receptionist_dashboard' => $recep,
            'register_patient' => $recep,
            'add_to_queue' => $recep,
            'record_vitals' => $recep,
            'clear_queue' => $recep,

            // Doctor
            'doctor_dashboard' => $clinical,
            'doctor_consult' => $clinical,
            'doctor_review_lab' => $clinical,
            'save_consultation' => $clinical,
            'create_prescription' => $clinical,
            'request_additional_lab_test' => $clinical,
            'add_consultation_procedure' => $clinical,
            'finalize_preview' => $clinical,
            'finalize_treatment' => $clinical,
            'transfer_patient' => $clinical,
            'claim_patient' => $clinical,
            'patient_history' => array_values(array_unique(array_merge($clinical, ['receptionist']))),
            'patient_history_detail' => array_values(array_unique(array_merge($clinical, ['receptionist', 'pharmacy']))),
            'medicine_lookup' => $clinical,

            // Lab
            'lab_dashboard' => $lab,
            'lab_upload_result' => $lab,
            'upload_lab_result' => $lab,
            'lab_collect_payment' => $lab, // legacy redirect
            'record_lab_payment' => $lab,
            'lab_equipment' => $lab,
            'submit_lab_equipment_request' => $lab,
            'register_existing_equipment' => $lab,
            'flag_lab_equipment_status' => $lab,

            // Pharmacy
            'pharmacy_dashboard' => $rx,
            'record_dispense' => $rx,
            'dispense_for_patient' => $rx,
            'dispense_medication' => $rx,
            'medicine_inventory' => $rx,
            'add_medicine' => $rx,
            'add_medicine_category' => $rx,
            'update_medicine' => $rx,
            'update_medicine_category' => $rx,
            'delete_medicine' => $rx,
            'delete_medicine_category' => $rx,
            'toggle_medicine_status' => $rx,
            'adjust_medicine_stock' => $rx,
            'medicine_purchase_requests' => $rx,
            'submit_medicine_purchase_request' => $rx,
            'medication_history' => $rx,
            'dispensary_margins' => $rx,
            'create_pharmacy_bill' => $rx,
            'save_pharmacy_bill' => $rx,
            'collect_pharmacy_bill_payment' => $bill,
            'record_pharmacy_bill_payment' => $bill,
            'collect_medicine_payment' => $bill,
            'record_medicine_payment' => $bill,

            // Billing
            'billing_dashboard' => $bill,
            'billing_center' => $bill,
            'billing_queue' => $bill,
            'generate_invoice' => $bill,
            'view_invoice' => $bill,
            'record_invoice_payment' => $bill,
            'record_payment' => $bill,
            'print_receipt' => $bill,
            'reprint_receipt' => $bill,
            'add_invoice_item' => $bill,
            'remove_invoice_item' => $bill,
            'apply_invoice_discount' => $bill,
            'add_patient_insurance' => $bill,
            'apply_invoice_insurance' => $bill,
            'claim_invoice' => $bill,
            'collect_payment' => $bill,
            'legacy_billing_dashboard_disabled' => $bill,

            // Admin
            'admin_dashboard' => ['admin'],
            'moic_dashboard' => ['admin'],
            'print_moic_report' => ['admin'],
            'create_staff' => ['admin'],
            'edit_staff' => ['admin'],
            'update_staff' => ['admin'],
            'delete_staff' => ['admin'],
            'toggle_staff_status' => ['admin'],
            'budget_dashboard' => ['admin'],
            'save_budget' => ['admin'],
            'update_budget_allocation' => ['admin'],
            'delete_budget' => ['admin'],
            'lab_test_catalog' => ['admin'],
            'add_lab_test' => ['admin'],
            'update_lab_test' => ['admin'],
            'toggle_lab_test' => ['admin'],
            'purchase_approvals' => ['admin'],
            'approve_medicine_purchase' => ['admin'],
            'reject_medicine_purchase' => ['admin'],
            'approve_lab_equipment' => ['admin'],
            'reject_lab_equipment' => ['admin'],
            'admin_regenerate_bill' => ['admin'],
            'admin_view_workflow' => ['admin'],
            'admin_send_to_billing' => ['admin'],
            'admin_assign_biller' => ['admin'],
            'admin_mark_returned' => ['admin'],
            'billing_gaps' => ['admin'],
            'lost_patients' => ['admin'],
            'workflow_monitor' => ['admin'],
            'workflow_timeline' => ['admin'],
            'recovery_history' => ['admin'],
            'save_workflow_settings' => ['admin'],
            'save_escalation_settings' => ['admin'],
            'escalations' => ['admin'],
            'analytics' => ['admin'],
            'reports' => ['admin'],
            'export_report' => ['admin'],
            'audit_browser' => ['admin'],
        ];
    }

    public static function isPublic(string $action): bool
    {
        return in_array($action, self::PUBLIC_ACTIONS, true);
    }

    public static function rolesFor(string $action): array
    {
        $map = self::map();
        if (!isset($map[$action])) {
            // Deny unknown actions to everyone except admin (ops safety)
            return ['admin'];
        }
        return $map[$action];
    }

    public static function can(?string $role, string $action): bool
    {
        if (self::isPublic($action)) {
            return true;
        }
        if ($role === null || $role === '') {
            return false;
        }
        if (!in_array($role, self::ROLES, true)) {
            return false;
        }
        return in_array($role, self::rolesFor($action), true);
    }

    public static function currentRole(): ?string
    {
        return $_SESSION['staff_role'] ?? null;
    }

    public static function currentCan(string $action): bool
    {
        return self::can(self::currentRole(), $action);
    }

    /**
     * Hard stop if the current session may not run $action.
     */
    public static function enforce(string $action): void
    {
        if (self::isPublic($action)) {
            return;
        }

        if (empty($_SESSION['staff_id']) || empty($_SESSION['staff_role'])) {
            header('Location: ?action=login');
            exit;
        }

        $role = (string)$_SESSION['staff_role'];
        if (!self::can($role, $action)) {
            if (function_exists('setFlash')) {
                setFlash('Access denied. Your role (' . $role . ') cannot perform this action.', 'error');
            }
            $home = $role . '_dashboard';
            // If their home dashboard is also denied, fall back to profile
            if (!self::can($role, $home)) {
                $home = 'my_profile';
            }
            header('Location: ?action=' . urlencode($home));
            exit;
        }
    }

    /** Filter nav items to those the role can open. */
    public static function filterNav(array $items, ?string $role = null): array
    {
        $role = $role ?? self::currentRole();
        return array_values(array_filter(
            $items,
            static fn(array $item) => self::can($role, $item['action'] ?? '')
        ));
    }

    public static function roleLabel(string $role): string
    {
        return match ($role) {
            'admin' => 'Administrator',
            'receptionist' => 'Receptionist',
            'doctor' => 'Doctor',
            'lab' => 'Laboratory',
            'pharmacy' => 'Pharmacy',
            'billing' => 'Billing',
            default => ucfirst($role),
        };
    }
}
