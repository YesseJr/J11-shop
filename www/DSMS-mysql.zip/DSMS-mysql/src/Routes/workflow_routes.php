<?php
/**
 * Workflow management routes — Lost Patients, Billing Queue, Recovery, Timeline.
 * Loaded from public/index.php. Does not replace billing_routes.php.
 */

// Lightweight auto-scan on admin/billing page loads (throttled in session)
if (!empty($_SESSION['staff_id']) && in_array($_SESSION['staff_role'] ?? '', ['admin', 'billing'], true)) {
    $lastScan = $_SESSION['workflow_scan_at'] ?? 0;
    if (time() - (int)$lastScan > 120) {
        try {
            Workflow::runLostPatientScan();
        } catch (\Throwable $e) {
            // never break page load
        }
        $_SESSION['workflow_scan_at'] = time();
    }
}

// ── Notifications API ───────────────────────────────────────────────────────
if ($action === 'notifications_json') {
    header('Content-Type: application/json; charset=utf-8');
    if (empty($_SESSION['staff_id'])) {
        echo json_encode(['count' => 0, 'items' => []]);
        exit;
    }
    $items = Notification::forStaff((int)$_SESSION['staff_id'], 15);
    $count = Notification::unreadCount((int)$_SESSION['staff_id']);
    echo json_encode(['count' => $count, 'items' => $items]);
    exit;
}

if ($action === 'mark_notification_read' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_SESSION['staff_id'])) {
        $nid = (int)($_POST['notification_id'] ?? 0);
        if ($nid > 0) {
            Notification::markRead($nid, (int)$_SESSION['staff_id']);
        } else {
            Notification::markAllRead((int)$_SESSION['staff_id']);
        }
    }
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '?action=dashboard'));
    exit;
}

// ── Billing Queue ───────────────────────────────────────────────────────────
if ($action === 'billing_queue') {
    requireRole('billing');
    $queue = Workflow::billingQueue();
    $mine = array_filter($queue, fn($r) => (int)($r['assigned_biller_id'] ?? 0) === (int)$_SESSION['staff_id']);
    $unassigned = array_filter($queue, fn($r) => empty($r['assigned_biller_id']));

    renderHeader('Billing Queue', 'billing');
    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Billing Queue</h2>
        <p>Every finalized patient remains here until payment is completed or the case is cancelled.
        <span id="dsms-queue-count" class="status-badge status-waiting">' . count($queue) . ' waiting</span>
        <meta http-equiv="refresh" content="60"></p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3>🆕 Unassigned</h3><div class="card-stat"><div class="card-stat-text"><h4>New</h4><p>' . count($unassigned) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('user', 18) . ' <span>Assigned to Me</span></h3><div class="card-stat"><div class="card-stat-text"><h4>My Queue</h4><p>' . count($mine) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('clipboard', 18) . ' <span>Total Open</span></h3><div class="card-stat"><div class="card-stat-text"><h4>All Billers</h4><p>' . count($queue) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top:20px;"><h3>Open Invoices</h3>';
    if (empty($queue)) {
        echo '<div class="no-data"><p>No patients waiting for billing right now.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr>
                <th>Priority</th><th>Patient</th><th>Invoice</th><th>Doctor</th>
                <th>Amount Due</th><th>Waiting</th><th>Biller</th><th>Action</th>
            </tr></thead><tbody>';
        foreach ($queue as $row) {
            $pri = $row['priority'] ?? 'normal';
            $badgeClass = $pri === 'urgent' ? 'status-warning' : ($pri === 'high' ? 'status-accepted' : 'status-waiting');
            echo '<tr>
                <td><span class="status-badge ' . $badgeClass . '">' . h(strtoupper($pri)) . '</span></td>
                <td><strong>' . h($row['patient_code']) . '</strong><br>' . h($row['patient_name']) . '</td>
                <td>' . h($row['invoice_number']) . '<br><small>' . h($row['status']) . '</small></td>
                <td>' . h($row['doctor_name'] ?? '—') . '</td>
                <td><strong>TZS ' . h(number_format((float)$row['balance'], 2)) . '</strong></td>
                <td>' . h($row['time_waiting']) . '</td>
                <td>' . h($row['biller_name'] ?? 'Unassigned') . '</td>
                <td style="white-space:nowrap;">
                    <a class="btn btn-primary btn-small" href="?action=view_invoice&invoice_id=' . h((string)$row['id']) . '">Open</a>
                    <form method="post" action="?action=claim_invoice" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                        <input type="hidden" name="invoice_id" value="' . h((string)$row['id']) . '">
                        <button type="submit" class="btn btn-secondary btn-small">Claim</button>
                    </form>
                </td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';
    echo '<p class="dsms-hint" style="margin-top:12px;">Page auto-refreshes every 60 seconds. New finalized patients appear here automatically.</p>';
    renderFooter();
    exit;
}

if ($action === 'claim_invoice' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('billing');
    $invoiceId = (int)($_POST['invoice_id'] ?? 0);
    try {
        Workflow::assignBiller($invoiceId, (int)$_SESSION['staff_id'], (int)$_SESSION['staff_id']);
        setFlash('Invoice claimed — it is now assigned to you.');
    } catch (\Throwable $e) {
        setFlash('Could not claim invoice: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=billing_queue');
    exit;
}

// ── Lost Patients dashboard ─────────────────────────────────────────────────
if ($action === 'lost_patients' || $action === 'billing_gaps') {
    requireRole('admin');

    $all = Workflow::detectLostPatients();
    $q = trim($_GET['q'] ?? '');
    $stepFilter = trim($_GET['step'] ?? '');
    $severity = trim($_GET['severity'] ?? '');
    $sort = trim($_GET['sort'] ?? 'wait_desc');
    $page = max(1, (int)($_GET['page'] ?? 1));
    $perPage = 20;

    $filtered = [];
    foreach ($all as $row) {
        if ($q !== '') {
            $hay = strtolower(($row['patient_name'] ?? '') . ' ' . ($row['patient_code'] ?? '') . ' ' . ($row['doctor_name'] ?? '') . ' ' . ($row['missing_step'] ?? ''));
            if (strpos($hay, strtolower($q)) === false) {
                continue;
            }
        }
        if ($stepFilter !== '' && stripos($row['missing_step'] ?? '', $stepFilter) === false) {
            continue;
        }
        if ($severity !== '' && ($row['severity'] ?? '') !== $severity) {
            continue;
        }
        $filtered[] = $row;
    }

    usort($filtered, static function ($a, $b) use ($sort) {
        if ($sort === 'wait_asc') {
            return ($a['waiting_seconds'] ?? 0) <=> ($b['waiting_seconds'] ?? 0);
        }
        if ($sort === 'name') {
            return strcmp($a['patient_name'] ?? '', $b['patient_name'] ?? '');
        }
        return ($b['waiting_seconds'] ?? 0) <=> ($a['waiting_seconds'] ?? 0);
    });

    $total = count($filtered);
    $pages = max(1, (int)ceil($total / $perPage));
    $page = min($page, $pages);
    $slice = array_slice($filtered, ($page - 1) * $perPage, $perPage);

    $billers = [];
    try {
        $pdo = Database::getConnection();
        $billers = $pdo->query("SELECT id, full_name FROM staff WHERE role = 'billing' AND is_active = 1 ORDER BY full_name")->fetchAll();
    } catch (\Throwable $e) {
    }

    renderHeader('Lost Patients', 'admin');
    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Lost Patients</h2>
        <p>Patients whose treatment or billing workflow stalled. Auto-detected every few minutes.
        <meta http-equiv="refresh" content="90">
        <span class="status-badge status-warning">' . $total . ' case(s)</span></p></div>';

    echo '<div class="card" style="margin-bottom:16px;">
        <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;">
            <input type="hidden" name="action" value="lost_patients">
            <label>Search<br><input type="search" name="q" value="' . h($q) . '" placeholder="Name, ID, doctor…" style="min-width:200px;"></label>
            <label>Missing step<br><input type="text" name="step" value="' . h($stepFilter) . '" placeholder="e.g. never generated"></label>
            <label>Severity<br><select name="severity">
                <option value="">All</option>
                <option value="critical"' . ($severity === 'critical' ? ' selected' : '') . '>Critical</option>
                <option value="high"' . ($severity === 'high' ? ' selected' : '') . '>High</option>
                <option value="normal"' . ($severity === 'normal' ? ' selected' : '') . '>Normal</option>
            </select></label>
            <label>Sort<br><select name="sort">
                <option value="wait_desc"' . ($sort === 'wait_desc' ? ' selected' : '') . '>Longest waiting</option>
                <option value="wait_asc"' . ($sort === 'wait_asc' ? ' selected' : '') . '>Shortest waiting</option>
                <option value="name"' . ($sort === 'name' ? ' selected' : '') . '>Patient name</option>
            </select></label>
            <button type="submit" class="btn btn-secondary">Apply</button>
            <a href="?action=lost_patients" class="btn btn-secondary">Clear</a>
            <a href="?action=recovery_history" class="btn btn-secondary">Recovery History</a>
        </form>
    </div>';

    echo '<div class="card">';
    if (empty($slice)) {
        echo '<div class="no-data"><p>No lost patients detected. Every visit has a clear path through billing.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr>
                <th>Patient ID</th><th>Name</th><th>Visit #</th><th>Doctor</th><th>Dept</th>
                <th>Stage</th><th>Missing Step</th><th>Last Activity</th><th>Waiting</th>
                <th>Status</th><th>Biller</th><th>Actions</th>
            </tr></thead><tbody>';
        foreach ($slice as $row) {
            $sev = $row['severity'] ?? 'normal';
            $sevClass = $sev === 'critical' ? 'status-warning' : ($sev === 'high' ? 'status-accepted' : 'status-waiting');
            $visitNo = $row['consultation_id'] ?? $row['queue_entry_id'] ?? '—';
            echo '<tr>
                <td><strong>' . h($row['patient_code'] ?? '') . '</strong></td>
                <td>' . h($row['patient_name'] ?? '') . '</td>
                <td>C-' . h((string)$visitNo) . '</td>
                <td>' . h($row['doctor_name'] ?? '—') . '</td>
                <td>' . h($row['department'] ?? '—') . '</td>
                <td>' . h($row['workflow_stage'] ?? '—') . '</td>
                <td><span class="status-badge ' . $sevClass . '">' . h($row['missing_step'] ?? '') . '</span></td>
                <td>' . ($row['last_activity'] ? h(date('M d, H:i', strtotime($row['last_activity']))) : '—') . '</td>
                <td>' . h($row['time_waiting'] ?? '') . '</td>
                <td>' . h($row['patient_status'] ?? '') . '</td>
                <td>' . h($row['biller_name'] ?? '—') . '</td>
                <td style="min-width:220px;">';
            if (!empty($row['consultation_id'])) {
                echo '<a class="btn btn-secondary btn-small" href="?action=workflow_timeline&patient_id=' . h((string)$row['patient_id']) . '&consultation_id=' . h((string)$row['consultation_id']) . '">Timeline</a> ';
                echo '<form method="post" action="?action=admin_regenerate_bill" style="display:inline;">
                    <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                    <input type="hidden" name="consultation_id" value="' . h((string)$row['consultation_id']) . '">
                    <input type="text" name="reason" required placeholder="Recovery reason *" style="width:140px;padding:4px 6px;" title="Mandatory">
                    <button type="submit" class="btn btn-primary btn-small" onclick="return confirm(\'Regenerate bill if missing (no duplicates)?\')">Regenerate Bill</button>
                </form> ';
            }
            if (!empty($row['invoice_id'])) {
                echo '<form method="post" action="?action=admin_send_to_billing" style="display:inline-block;margin:2px 0;">
                    <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                    <input type="hidden" name="invoice_id" value="' . h((string)$row['invoice_id']) . '">
                    <input type="hidden" name="patient_id" value="' . h((string)$row['patient_id']) . '">
                    <input type="hidden" name="consultation_id" value="' . h((string)($row['consultation_id'] ?? 0)) . '">
                    <input type="text" name="reason" required placeholder="Reason *" style="width:120px;padding:4px 6px;">
                    <button type="submit" class="btn btn-secondary btn-small">Send to Billing</button>
                </form> ';
                if (!empty($billers)) {
                    echo '<form method="post" action="?action=admin_assign_biller" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                        <input type="hidden" name="invoice_id" value="' . h((string)$row['invoice_id']) . '">
                        <input type="hidden" name="patient_id" value="' . h((string)$row['patient_id']) . '">
                        <input type="hidden" name="consultation_id" value="' . h((string)($row['consultation_id'] ?? 0)) . '">
                        <select name="biller_id" style="max-width:120px;">';
                    foreach ($billers as $b) {
                        echo '<option value="' . h((string)$b['id']) . '">' . h($b['full_name']) . '</option>';
                    }
                    echo '</select>
                        <button type="submit" class="btn btn-secondary btn-small">Assign</button>
                    </form>';
                }
            }
            echo '<form method="post" action="?action=admin_mark_returned" style="display:inline;margin-top:4px;">
                <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                <input type="hidden" name="patient_id" value="' . h((string)$row['patient_id']) . '">
                <input type="hidden" name="consultation_id" value="' . h((string)($row['consultation_id'] ?? 0)) . '">
                <button type="submit" class="btn btn-secondary btn-small">Mark Returned</button>
            </form>';
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';

        // Pagination
        if ($pages > 1) {
            echo '<div style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap;">';
            for ($i = 1; $i <= $pages; $i++) {
                $url = '?action=lost_patients&page=' . $i . '&q=' . urlencode($q) . '&step=' . urlencode($stepFilter) . '&severity=' . urlencode($severity) . '&sort=' . urlencode($sort);
                echo $i === $page
                    ? '<span class="btn btn-primary btn-small">' . $i . '</span>'
                    : '<a class="btn btn-secondary btn-small" href="' . h($url) . '">' . $i . '</a>';
            }
            echo '</div>';
        }
    }
    echo '</div>';

    echo '<div class="card" style="margin-top:16px;">
        <h3>Detection thresholds</h3>
        <form method="post" action="?action=save_workflow_settings" style="display:flex;gap:12px;flex-wrap:wrap;align-items:end;">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <label>General idle (minutes)<br><input type="number" min="15" name="workflow_idle_minutes" value="' . h((string)Workflow::idleMinutes()) . '"></label>
            <label>Billing idle (minutes)<br><input type="number" min="10" name="billing_idle_minutes" value="' . h((string)Workflow::billingIdleMinutes()) . '"></label>
            <button type="submit" class="btn btn-secondary">Save</button>
        </form>
    </div>';

    renderFooter();
    exit;
}

// ── Recovery actions ────────────────────────────────────────────────────────
if ($action === 'admin_send_to_billing' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('admin');
    $reason = trim($_POST['reason'] ?? '');
    if ($reason === '') {
        setFlash('Recovery reason is required.', 'error');
        header('Location: ?action=lost_patients');
        exit;
    }
    $invoiceId = (int)($_POST['invoice_id'] ?? 0);
    $patientId = (int)($_POST['patient_id'] ?? 0);
    $consultationId = (int)($_POST['consultation_id'] ?? 0);
    try {
        require_once __DIR__ . '/../Models/Patient.php';
        if ($patientId > 0) {
            Patient::updateStatus($patientId, 'Awaiting Payment');
        }
        Notification::notifyRole('billing', 'send_to_billing', 'Patient sent to Billing', 'Invoice #' . $invoiceId . ' needs attention.', 'view_invoice', $invoiceId);
        RecoveryLog::record((int)$_SESSION['staff_id'], $patientId, $consultationId ?: null, $invoiceId ?: null, 'send_to_billing', 'Lost/stalled', 'Awaiting Payment', $_POST['reason'] ?? 'Admin re-queued to billing');
        setFlash('Patient re-queued to Billing queue.');
    } catch (\Throwable $e) {
        setFlash('Failed: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=lost_patients');
    exit;
}

if ($action === 'admin_assign_biller' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('admin');
    $reason = trim($_POST['reason'] ?? '');
    if ($reason === '') {
        setFlash('Recovery reason is required.', 'error');
        header('Location: ?action=lost_patients');
        exit;
    }
    $invoiceId = (int)($_POST['invoice_id'] ?? 0);
    $billerId = (int)($_POST['biller_id'] ?? 0);
    $patientId = (int)($_POST['patient_id'] ?? 0);
    $consultationId = (int)($_POST['consultation_id'] ?? 0);
    try {
        if ($invoiceId <= 0 || $billerId <= 0) {
            throw new \RuntimeException('Invoice and biller are required.');
        }
        Workflow::assignBiller($invoiceId, $billerId, (int)$_SESSION['staff_id']);
        RecoveryLog::record((int)$_SESSION['staff_id'], $patientId, $consultationId ?: null, $invoiceId, 'assign_biller', 'Unassigned', 'Assigned to biller #' . $billerId, 'Admin assignment');
        setFlash('Biller assigned.');
    } catch (\Throwable $e) {
        setFlash('Failed: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=lost_patients');
    exit;
}

if ($action === 'admin_mark_returned' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('admin');
    $reason = trim($_POST['reason'] ?? '');
    if ($reason === '') {
        setFlash('Recovery reason is required.', 'error');
        header('Location: ?action=lost_patients');
        exit;
    }
    $patientId = (int)($_POST['patient_id'] ?? 0);
    $consultationId = (int)($_POST['consultation_id'] ?? 0);
    try {
        Workflow::markPatientReturned($patientId, (int)$_SESSION['staff_id']);
        RecoveryLog::record((int)$_SESSION['staff_id'], $patientId, $consultationId ?: null, null, 'mark_returned', 'Left/Inactive', 'Awaiting Payment', 'Patient returned to facility');
        setFlash('Patient marked as returned.');
    } catch (\Throwable $e) {
        setFlash('Failed: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=lost_patients');
    exit;
}

if ($action === 'save_workflow_settings' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('admin');
    Workflow::setSetting('workflow_idle_minutes', (string)max(15, (int)($_POST['workflow_idle_minutes'] ?? 120)));
    Workflow::setSetting('billing_idle_minutes', (string)max(10, (int)($_POST['billing_idle_minutes'] ?? 60)));
    setFlash('Workflow thresholds saved.');
    header('Location: ?action=lost_patients');
    exit;
}

// ── Workflow timeline ───────────────────────────────────────────────────────
if ($action === 'workflow_timeline') {
    if (empty($_SESSION['staff_id'])) {
        header('Location: ?action=login');
        exit;
    }
    $patientId = (int)($_GET['patient_id'] ?? 0);
    $consultationId = (int)($_GET['consultation_id'] ?? 0) ?: null;
    $data = Workflow::timelineForPatient($patientId, $consultationId);

    renderHeader('Workflow Timeline', $_SESSION['staff_role'] ?? 'admin');
    if (empty($data['patient'])) {
        echo '<div class="alert alert-error">Patient not found.</div>';
        renderFooter();
        exit;
    }
    $pt = $data['patient'];
    echo '<div class="page-title"><h2>Workflow Timeline</h2>
        <p><strong>' . h($pt['patient_id'] . ' — ' . $pt['full_name']) . '</strong>
        · Status: ' . h($pt['status']) . '</p></div>';

    echo '<div class="card"><div class="dsms-timeline">';
    foreach ($data['steps'] as $step) {
        $status = $step['status'];
        $blocked = ($data['blocked_key'] ?? null) === $step['key'];
        $dot = match ($status) {
            'completed' => 'done',
            'active' => 'active',
            'blocked' => 'blocked',
            'cancelled' => 'cancelled',
            'skipped' => '⏭',
            default => '○',
        };
        $style = $blocked ? 'border-left:4px solid #dc2626;background:#fef2f2;' : ($status === 'completed' ? 'border-left:4px solid #16a34a;' : 'border-left:4px solid #e2e8f0;');
        echo '<div class="dsms-timeline-step" style="padding:14px 16px;margin-bottom:10px;border-radius:10px;' . $style . '">
            <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                <div><strong>' . $dot . ' ' . h($step['label']) . '</strong>
                    ' . ($blocked ? ' <span class="status-badge status-warning">BLOCKED HERE</span>' : '') . '
                    <div class="dsms-hint">' . h($step['detail']) . '</div>
                </div>
                <div style="text-align:right;font-size:0.9rem;color:#64748b;">
                    ' . h($step['staff'] ?? '—') . '<br>
                    ' . ($step['at'] ? h(date('M d, Y H:i', strtotime($step['at']))) : '—') . '
                </div>
            </div>
        </div>';
    }
    echo '</div>';
    echo '<a href="?action=lost_patients" class="btn btn-secondary">Back</a> ';
    if (!empty($data['invoice']['id'])) {
        echo '<a href="?action=view_invoice&invoice_id=' . h((string)$data['invoice']['id']) . '" class="btn btn-primary">Open Invoice</a>';
    }
    echo '</div>';
    renderFooter();
    exit;
}

// ── Recovery history ────────────────────────────────────────────────────────
if ($action === 'recovery_history') {
    requireRole('admin');
    $q = trim($_GET['q'] ?? '');
    $page = max(1, (int)($_GET['page'] ?? 1));
    $perPage = 25;
    $total = RecoveryLog::count($q ?: null);
    $pages = max(1, (int)ceil($total / $perPage));
    $rows = RecoveryLog::search($q ?: null, $perPage, ($page - 1) * $perPage);

    renderHeader('Recovery History', 'admin');
    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }
    echo '<div class="page-title"><h2>Recovery History</h2>
        <p>Permanent log of every administrative recovery action.</p></div>';

    echo '<div class="card" style="margin-bottom:14px;">
        <form method="get"><input type="hidden" name="action" value="recovery_history">
            <label>Search<br><input type="search" name="q" value="' . h($q) . '" placeholder="Patient, action, admin, reason…" style="min-width:280px;"></label>
            <button type="submit" class="btn btn-secondary">Search</button>
        </form>
    </div>';

    echo '<div class="card">';
    if (empty($rows)) {
        echo '<div class="no-data"><p>No recovery actions recorded yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr>
                <th>When</th><th>Patient</th><th>Action</th><th>Administrator</th>
                <th>From → To</th><th>Reason</th>
            </tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr>
                <td>' . h(date('M d, Y H:i', strtotime($r['created_at']))) . '</td>
                <td><strong>' . h($r['patient_code']) . '</strong><br>' . h($r['patient_name']) . '</td>
                <td>' . h($r['action']) . '</td>
                <td>' . h($r['admin_name']) . '</td>
                <td>' . h(($r['previous_stage'] ?? '—') . ' → ' . ($r['new_stage'] ?? '—')) . '</td>
                <td>' . h($r['reason'] ?? ($r['details'] ?? '')) . '</td>
            </tr>';
        }
        echo '</tbody></table></div>';
        if ($pages > 1) {
            echo '<div style="margin-top:12px;display:flex;gap:6px;">';
            for ($i = 1; $i <= $pages; $i++) {
                echo $i === $page
                    ? '<span class="btn btn-primary btn-small">' . $i . '</span>'
                    : '<a class="btn btn-secondary btn-small" href="?action=recovery_history&page=' . $i . '&q=' . urlencode($q) . '">' . $i . '</a>';
            }
            echo '</div>';
        }
    }
    echo '</div>';
    renderFooter();
    exit;
}

// ── Workflow monitoring widget data (used by admin dashboard if requested) ─
if ($action === 'workflow_monitor') {
    requireRole('admin');
    $counts = Workflow::stageCounts();
    renderHeader('Workflow Monitor', 'admin');
    echo '<div class="page-title"><h2>Workflow Monitoring</h2><p>Live facility pipeline. Click a card to open the related list. <meta http-equiv="refresh" content="60"></p></div>';
    echo '<div class="grid grid-3">';
    $cards = [
        ['waiting_consultation', 'Patients Waiting for Consultation', 'queue', '?action=admin_dashboard'],
        ['in_laboratory', 'Patients in Laboratory', 'lab', '?action=lab_dashboard'],
        ['waiting_billing', 'Patients Waiting for Billing', 'billing', '?action=lost_patients&step=never'],
        ['awaiting_payment', 'Patients Awaiting Payment', 'payment', '?action=billing_queue'],
        ['waiting_pharmacy', 'Patients Waiting for Pharmacy', 'pharmacy', '?action=pharmacy_dashboard'],
        ['completed_visits', 'Completed Visits', 'done', '?action=moic_dashboard'],
        ['lost_patients', 'Lost Patients', 'lost', '?action=lost_patients'],
    ];
    foreach ($cards as [$key, $label, $icon, $href]) {
        $n = (int)($counts[$key] ?? 0);
        $warn = ($key === 'lost_patients' && $n > 0) ? ' style="border:2px solid #dc2626;"' : '';
        echo '<a href="' . h($href) . '" class="card" style="text-decoration:none;color:inherit;"' . $warn . '>
            <h3>' . h($label) . '</h3>
            <div class="card-stat"><div class="card-stat-text"><h4>Count</h4><p style="font-size:2rem;">' . $n . '</p></div></div>
        </a>';
    }
    echo '</div>';
    renderFooter();
    exit;
}
