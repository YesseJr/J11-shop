<?php
/**
 * billing_routes.php
 * -------------------
 * New centralized-billing actions for the DSMS billing officer role.
 * Save this file as src/Routes/billing_routes.php (create the Routes
 * folder), then in public/index.php add, alongside the other model
 * requires near the top:
 *
 *     require_once __DIR__ . '/../src/Models/Billing.php';
 *     require_once __DIR__ . '/../src/Models/Insurance.php';
 *     require_once __DIR__ . '/../src/Routes/billing_routes.php';
 *
 * It relies on functions/vars already defined in index.php: requireRole(),
 * renderHeader(), renderFooter(), h(), setFlash(), getCsrfToken(), $flash,
 * $action, $_SESSION. These are hoisted/available at runtime regardless of
 * require order, so placement right after the model requires is fine.
 *
 * This does NOT remove the old billing_dashboard/record_payment actions —
 * they keep working for anything already in flight. Point the nav link at
 * ?action=billing_center instead of ?action=billing_dashboard to switch
 * the billing officer over to the new flow.
 */

// ---------------------------------------------------------------------
// Billing Center — replacement main dashboard
// ---------------------------------------------------------------------
if ($action === 'billing_center') {
    requireRole('billing');
    renderHeader('Billing Center', 'billing');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $awaiting = Billing::getPatientsAwaitingBilling();
    $outstanding = Billing::getOutstanding();

    echo '<div class="page-title"><h2>Billing Center</h2><p>One invoice per completed visit — consultation, labs, and pharmacy combined.</p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('receipt', 18) . ' <span>Ready to Invoice</span></h3><div class="card-stat"><div class="card-stat-text"><h4>Visits</h4><p>' . count($awaiting) . '</p></div></div></div>';
    echo '<div class="card"><h3>⏳ Outstanding Invoices</h3><div class="card-stat"><div class="card-stat-text"><h4>Unpaid/Partial</h4><p>' . count($outstanding) . '</p></div></div></div>';
    echo '<div class="card"><h3 class="dsms-card-title">' . dsms_icon('dollar', 18) . ' <span>Outstanding Total</span></h3><div class="card-stat"><div class="card-stat-text"><h4>Balance</h4><p>' . h(number_format(array_sum(array_column($outstanding, 'balance')), 2)) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Visits Ready for Invoicing</h3>';
    if (empty($awaiting)) {
        echo '<div class="no-data"><p>No completed visits are waiting to be invoiced right now.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient ID</th><th>Name</th><th>Consultation Date</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($awaiting as $v) {
            echo '<tr>
                <td>' . h($v['patient_code']) . '</td>
                <td>' . h($v['full_name']) . '</td>
                <td>' . h(date('M d, H:i', strtotime($v['consultation_date']))) . '</td>
                <td><a href="?action=generate_invoice&queue_id=' . h($v['queue_entry_id']) . '" class="btn btn-primary btn-small">Generate Invoice</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Outstanding Invoices</h3>';
    if (empty($outstanding)) {
        echo '<div class="no-data"><p>Nothing outstanding.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Invoice #</th><th>Patient</th><th>Total</th><th>Paid</th><th>Balance</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($outstanding as $inv) {
            echo '<tr>
                <td>' . h($inv['invoice_number']) . '</td>
                <td>' . h($inv['patient_code'] . ' - ' . $inv['full_name']) . '</td>
                <td>' . h(number_format((float)$inv['total_amount'], 2)) . '</td>
                <td>' . h(number_format((float)$inv['amount_paid'], 2)) . '</td>
                <td>' . h(number_format((float)$inv['balance'], 2)) . '</td>
                <td><span class="status-badge status-accepted">' . h($inv['status']) . '</span></td>
                <td><a href="?action=view_invoice&invoice_id=' . h($inv['id']) . '" class="btn btn-secondary btn-small">Open</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

// ---------------------------------------------------------------------
// Generate invoice for a completed visit
// ---------------------------------------------------------------------
if ($action === 'generate_invoice') {
    requireRole('billing');
    $queueId = (int)($_GET['queue_id'] ?? 0);

    try {
        $invoiceId = Billing::generateInvoice($queueId, (int)$_SESSION['staff_id']);
        setFlash('Invoice generated successfully.');
        header('Location: ?action=view_invoice&invoice_id=' . urlencode((string)$invoiceId));
    } catch (\Throwable $e) {
        setFlash('Could not generate invoice: ' . $e->getMessage(), 'error');
        header('Location: ?action=billing_center');
    }
    exit;
}

// ---------------------------------------------------------------------
// View invoice + take payment
// ---------------------------------------------------------------------
if ($action === 'view_invoice') {
    requireRole('billing');
    $invoiceId = (int)($_GET['invoice_id'] ?? 0);
    $invoice = Billing::find($invoiceId);

    if (!$invoice) {
        setFlash('Invoice not found.', 'error');
        header('Location: ?action=billing_center');
        exit;
    }

    $patient = Patient::find((int)$invoice['patient_id']);
    $items = Billing::getItems($invoiceId);
    $payments = Billing::getPayments($invoiceId);

    renderHeader('Invoice ' . $invoice['invoice_number'], 'billing');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Invoice ' . h($invoice['invoice_number']) . '</h2><p>' . h($patient['patient_id'] . ' — ' . $patient['full_name']) . '</p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3>Total</h3><div class="card-stat"><div class="card-stat-text"><p>' . h(number_format((float)$invoice['total_amount'], 2)) . '</p></div></div></div>';
    echo '<div class="card"><h3>Paid</h3><div class="card-stat"><div class="card-stat-text"><p>' . h(number_format((float)$invoice['amount_paid'], 2)) . '</p></div></div></div>';
    echo '<div class="card"><h3>Balance</h3><div class="card-stat"><div class="card-stat-text"><p>' . h(number_format((float)$invoice['balance'], 2)) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Charges</h3>';
    echo '<div class="table-responsive"><table><thead><tr><th>Service</th><th>Description</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th><th></th></tr></thead><tbody>';
    foreach ($items as $item) {
        echo '<tr>
            <td>' . h($item['service_type']) . '</td>
            <td>' . h($item['description']) . ($item['is_manual'] ? ' <span class="status-badge status-pending">manual</span>' : '') . '</td>
            <td>' . h($item['quantity']) . '</td>
            <td>' . h(number_format((float)$item['unit_price'], 2)) . '</td>
            <td>' . h(number_format((float)$item['subtotal'], 2)) . '</td>
            <td>' . ($item['is_manual'] && $invoice['status'] !== 'Paid'
                ? '<a href="?action=remove_invoice_item&item_id=' . h($item['id']) . '&invoice_id=' . h($invoice['id']) . '" class="btn btn-secondary btn-small" onclick="return confirm(\'Remove this item?\')">Remove</a>'
                : '') . '</td>
        </tr>';
    }
    if ((float)$invoice['discount_amount'] > 0) {
        echo '<tr><td colspan="4" style="text-align:right;">Discount</td><td>-' . h(number_format((float)$invoice['discount_amount'], 2)) . '</td><td></td></tr>';
    }
    if ((float)$invoice['insurance_covered_amount'] > 0) {
        echo '<tr><td colspan="4" style="text-align:right;">Insurance Covered</td><td>-' . h(number_format((float)$invoice['insurance_covered_amount'], 2)) . '</td><td></td></tr>';
    }
    echo '</tbody></table></div></div>';

    if ($invoice['status'] !== 'Paid') {
        echo '<div class="card" style="margin-top: 24px;"><h3>Add Charge / Discount</h3>';
        echo '<div class="grid grid-2">';

        echo '<form method="post" action="?action=add_invoice_item">';
        echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
        echo '<input type="hidden" name="invoice_id" value="' . h($invoice['id']) . '">';
        echo '<h4>Add Billable Item</h4>';
        echo '<label>Type<br><select name="service_type" required>
                <option value="Procedure">Procedure</option>
                <option value="Other">Other</option>
              </select></label>';
        echo '<label>Description<br><input type="text" name="description" placeholder="e.g., Wound dressing" required></label>';
        echo '<div class="form-row">';
        echo '<label>Qty<br><input type="number" min="1" name="quantity" value="1" required></label>';
        echo '<label>Unit Price<br><input type="number" step="0.01" min="0" name="unit_price" required></label>';
        echo '</div>';
        echo '<button type="submit" class="btn btn-secondary" style="margin-top: 8px;">Add Item</button>';
        echo '</form>';

        echo '<form method="post" action="?action=apply_invoice_discount">';
        echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
        echo '<input type="hidden" name="invoice_id" value="' . h($invoice['id']) . '">';
        echo '<h4>Apply Discount</h4>';
        echo '<label>Discount Amount<br><input type="number" step="0.01" min="0" name="discount_amount" value="' . h($invoice['discount_amount']) . '"></label>';
        echo '<button type="submit" class="btn btn-secondary" style="margin-top: 8px;">Update Discount</button>';
        echo '</form>';

        echo '</div></div>';
    }

    if ((float)$invoice['balance'] > 0) {
        echo '<div class="dsms-pay-wrap">';
        echo '<div class="dsms-pay-head"><h3>Take Payment</h3><span class="dsms-pay-balance">Balance due · TZS ' . h(number_format((float)$invoice['balance'], 2)) . '</span></div>';

        echo '<div id="payment-setup-' . h($invoice['id']) . '">';

        // Method picker — segmented buttons instead of a plain <select>
        echo '<div class="dsms-method-grid" id="pay-method-grid">
                <button type="button" class="dsms-method-btn active" data-method="Cash" onclick="dsmsSelectMethod(this)">
                    <span class="dsms-method-icon">' . dsms_icon('cash', 20) . '</span><span>Cash</span>
                </button>
                <button type="button" class="dsms-method-btn" data-method="Debit Card" onclick="dsmsSelectMethod(this)">
                    <span class="dsms-method-icon">' . dsms_icon('card', 20) . '</span><span>Debit Card</span>
                </button>
                <button type="button" class="dsms-method-btn" data-method="Credit Card" onclick="dsmsSelectMethod(this)">
                    <span class="dsms-method-icon">' . dsms_icon('card', 20) . '</span><span>Credit Card</span>
                </button>
                <button type="button" class="dsms-method-btn" data-method="Mobile Money" onclick="dsmsSelectMethod(this)">
                    <span class="dsms-method-icon">' . dsms_icon('smartphone', 20) . '</span><span>Mobile Money</span>
                </button>
                <button type="button" class="dsms-method-btn" data-method="Bank Transfer" onclick="dsmsSelectMethod(this)">
                    <span class="dsms-method-icon">' . dsms_icon('bank', 20) . '</span><span>Bank Transfer</span>
                </button>
              </div>';
        echo '<input type="hidden" id="pay-method" value="Cash">';

        echo '<div class="dsms-field-panel">';

        echo '<div class="dsms-amount-field">';
        echo '<label class="dsms-label">Amount</label>';
        echo '<div class="dsms-amount-input"><span class="dsms-amount-prefix">TZS</span><input type="number" step="0.01" min="0.01" max="' . h($invoice['balance']) . '" id="pay-amount" value="' . h($invoice['balance']) . '" required></div>';
        echo '</div>';

        // Cash — nothing extra needed
        echo '<div id="pay-cash-fields" class="dsms-method-fields">';
        echo '<p class="dsms-hint">Confirm the cash amount received matches the amount above.</p>';
        echo '</div>';

        // Card fields — number only, never CVV/PIN/expiry
        echo '<div id="pay-card-fields" class="dsms-method-fields" style="display:none;">';
        echo '<label class="dsms-label">Card Number</label>';
        echo '<input class="dsms-text-input dsms-mono" id="pay-card-number" placeholder="1234 5678 9012 3456" maxlength="19" oninput="dsmsFormatCardNumber(); dsmsDetectCardNetwork();">';
        echo '<div id="pay-card-badge" class="dsms-badge-row"></div>';
        echo '<p class="dsms-hint dsms-hint-muted">Card is tapped/inserted on the terminal — no CVV or PIN is ever entered here.</p>';
        echo '</div>';

        // Bank transfer
        echo '<div id="pay-bank-fields" class="dsms-method-fields" style="display:none;">';
        echo '<label class="dsms-label">Bank Reference / Slip Number</label>';
        echo '<input class="dsms-text-input" id="pay-bank-ref" placeholder="e.g., CRDB-TT-88213">';
        echo '</div>';

        // Mobile Money fields
        echo '<div id="pay-momo-fields" class="dsms-method-fields" style="display:none;">';
        echo '<label class="dsms-label">Customer\'s Mobile Number</label>';
        echo '<input class="dsms-text-input dsms-mono" id="pay-phone" placeholder="e.g., 0754 123 456" maxlength="13" oninput="dsmsDetectNetwork()">';
        echo '<div id="pay-network-badge" class="dsms-badge-row"></div>';
        echo '</div>';

        echo '</div>'; // .dsms-field-panel

        echo '<button type="button" id="pay-action-btn" class="dsms-submit-btn" onclick="dsmsStartPayment()">Record Payment</button>';
        echo '</div>'; // #payment-setup

        // Simulation panel — a real step checklist, not just swapped text
        echo '<div id="payment-sim-' . h($invoice['id']) . '" class="dsms-sim-panel" style="display:none;">';
        echo '<div class="dsms-sim-avatar" id="sim-header-icon">⏳</div>';
        echo '<div class="dsms-sim-title" id="sim-header-text"></div>';
        echo '<div class="dsms-sim-steps" id="sim-steps"></div>';
        echo '</div>';

        // Real form — only ever submitted programmatically once the
        // simulation completes, so the actual backend call and DB write
        // are unchanged from before.
        echo '<form method="post" action="?action=record_invoice_payment" id="real-payment-form-' . h($invoice['id']) . '" style="display:none;">';
        echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
        echo '<input type="hidden" name="invoice_id" value="' . h($invoice['id']) . '">';
        echo '<input type="hidden" name="amount" id="real-amount">';
        echo '<input type="hidden" name="payment_method" id="real-method">';
        echo '<input type="hidden" name="transaction_reference" id="real-reference">';
        echo '</form>';

        echo '</div>'; // .dsms-pay-wrap

        echo '<script>
        (function() {
            function $(id) { return document.getElementById(id); }

            window.dsmsSelectMethod = function(btn) {
                document.querySelectorAll(".dsms-method-btn").forEach(function(b) { b.classList.remove("active"); });
                btn.classList.add("active");
                $("pay-method").value = btn.getAttribute("data-method");
                dsmsPaymentMethodChanged();
            };

            window.dsmsPaymentMethodChanged = function() {
                var method = $("pay-method").value;
                $("pay-momo-fields").style.display = method === "Mobile Money" ? "block" : "none";
                $("pay-card-fields").style.display = (method === "Debit Card" || method === "Credit Card") ? "block" : "none";
                $("pay-bank-fields").style.display = method === "Bank Transfer" ? "block" : "none";
                $("pay-cash-fields").style.display = method === "Cash" ? "block" : "none";
                $("pay-action-btn").textContent = method === "Mobile Money" ? "Send Payment Request" : "Record Payment";
                $("pay-network-badge").innerHTML = "";
                $("pay-card-badge").innerHTML = "";
            };

            // Approximate Tanzanian mobile network prefixes, for a
            // realistic-feeling demo only — not a real carrier lookup.
            var NETWORKS = [
                { prefixes: ["074","075","076"], name: "Vodacom M-Pesa", color: "#e60000" },
                { prefixes: ["078","068","069"], name: "Airtel Money", color: "#e2001a" },
                { prefixes: ["071","065","067"], name: "Tigo/Mixx by Yas", color: "#0072ce" },
                { prefixes: ["062","061"], name: "Halotel HaloPesa", color: "#f7941d" },
                { prefixes: ["073"], name: "TTCL Pesa", color: "#008751" }
            ];

            function normalizePhone(raw) {
                var digits = raw.replace(/\\D/g, "");
                if (digits.indexOf("255") === 0) { digits = "0" + digits.substring(3); }
                return digits;
            }

            function detectNetwork(raw) {
                var digits = normalizePhone(raw);
                if (digits.length < 3) { return null; }
                var prefix = digits.substring(0, 3);
                for (var i = 0; i < NETWORKS.length; i++) {
                    if (NETWORKS[i].prefixes.indexOf(prefix) !== -1) { return NETWORKS[i]; }
                }
                return null;
            }

            window.dsmsDetectNetwork = function() {
                var raw = $("pay-phone").value;
                var digits = normalizePhone(raw);
                var badge = $("pay-network-badge");
                if (digits.length < 10) {
                    badge.innerHTML = digits.length > 0 ? "<span style=\\"color:#6b7280; font-size:13px;\\">Enter a full 10-digit number…</span>" : "";
                    return;
                }
                var net = detectNetwork(raw);
                if (net) {
                    badge.innerHTML = "<span style=\\"display:inline-flex; align-items:center; gap:6px; background:" + net.color + "; color:#fff; padding:5px 12px; border-radius:20px; font-weight:600; font-size:13px;\\"> " + net.name + "</span>";
                } else {
                    badge.innerHTML = "<span style=\\"color:#b45309; font-size:13px;\\">Network not recognized — double-check the number</span>";
                }
            };

            window.dsmsFormatCardNumber = function() {
                var el = $("pay-card-number");
                var digits = el.value.replace(/\\D/g, "").substring(0, 16);
                var groups = digits.match(/.{1,4}/g) || [];
                el.value = groups.join(" ");
            };

            function detectCardNetwork(digits) {
                if (/^4/.test(digits)) { return { name: "Visa", color: "#1a1f71" }; }
                if (/^5[1-5]/.test(digits)) { return { name: "Mastercard", color: "#eb001b" }; }
                if (/^3[47]/.test(digits)) { return { name: "American Express", color: "#016fd0" }; }
                if (/^6(?:011|5)/.test(digits)) { return { name: "Discover", color: "#ff6000" }; }
                return null;
            }

            window.dsmsDetectCardNetwork = function() {
                var digits = $("pay-card-number").value.replace(/\\D/g, "");
                var badge = $("pay-card-badge");
                if (digits.length < 6) {
                    badge.innerHTML = "";
                    return;
                }
                var net = detectCardNetwork(digits);
                if (net) {
                    badge.innerHTML = "<span style=\\"display:inline-flex; align-items:center; gap:6px; background:" + net.color + "; color:#fff; padding:5px 12px; border-radius:20px; font-weight:600; font-size:13px;\\"> " + net.name + "</span>";
                } else {
                    badge.innerHTML = "<span style=\\"color:#6b7280; font-size:13px;\\">Card network not recognized</span>";
                }
            };

            function maskCard(digits) {
                if (digits.length < 4) { return digits; }
                return "•••• •••• •••• " + digits.slice(-4);
            }

            // Renders the checklist and steps through it, one item at a
            // time: pending (hollow circle) -> active (spinner) -> done
            // (checkmark), then calls onDone once every step is complete.
            function runSteps(headerIcon, headerText, steps, stepMs, onDone) {
                $("sim-header-icon").textContent = headerIcon;
                $("sim-header-text").textContent = headerText;

                var container = $("sim-steps");
                container.innerHTML = "";
                steps.forEach(function(step, i) {
                    var div = document.createElement("div");
                    div.className = "sim-step";
                    div.id = "sim-step-" + i;
                    div.innerHTML = "<span class=\\"sim-step-icon\\" id=\\"sim-step-icon-" + i + "\\">○</span><span class=\\"sim-step-label\\">" + step + "</span>";
                    container.appendChild(div);
                });

                var i = 0;
                function advance() {
                    if (i > 0) {
                        var prev = $("sim-step-" + (i - 1));
                        prev.classList.remove("active");
                        prev.classList.add("done");
                        $("sim-step-icon-" + (i - 1)).textContent = "✓";
                    }
                    if (i >= steps.length) {
                        $("sim-header-icon").textContent = "✓";
                        $("sim-header-icon").classList.add("dsms-success");
                        $("sim-header-text").textContent = "Payment Confirmed!";
                        setTimeout(onDone, 700);
                        return;
                    }
                    var cur = $("sim-step-" + i);
                    cur.classList.add("active");
                    $("sim-step-icon-" + i).innerHTML = "<span class=\\"spinner\\"></span>";
                    i++;
                    setTimeout(advance, stepMs);
                }
                advance();
            }

            window.dsmsStartPayment = function() {
                var invoiceId = "' . h($invoice['id']) . '";
                var amount = $("pay-amount").value;
                var method = $("pay-method").value;

                if (!amount || parseFloat(amount) <= 0) {
                    alert("Enter a valid amount.");
                    return;
                }

                function finish(finalReference) {
                    $("real-amount").value = amount;
                    $("real-method").value = method;
                    $("real-reference").value = finalReference;
                    document.getElementById("real-payment-form-" + invoiceId).submit();
                }

                if (method === "Mobile Money") {
                    var digits = normalizePhone($("pay-phone").value);
                    if (digits.length < 10) {
                        alert("Enter a valid 10-digit mobile number.");
                        return;
                    }
                    var net = detectNetwork($("pay-phone").value);
                    var netName = net ? net.name : "Mobile Money";

                    $("payment-setup-" + invoiceId).style.display = "none";
                    $("payment-sim-" + invoiceId).style.display = "block";

                    runSteps("M-Pesa", "Sending payment request to " + netName + "…", [
                        "Payment request sent to " + digits,
                        "Waiting for customer to confirm on their phone",
                        "Customer entering PIN",
                        "Verifying with " + netName
                    ], 1400, function() {
                        finish(netName + " - " + digits);
                    });

                } else if (method === "Debit Card" || method === "Credit Card") {
                    var cardDigits = $("pay-card-number").value.replace(/\\D/g, "");
                    if (cardDigits.length < 12) {
                        alert("Enter a valid card number.");
                        return;
                    }
                    var cardNet = detectCardNetwork(cardDigits);
                    var cardName = cardNet ? cardNet.name : method;

                    $("payment-setup-" + invoiceId).style.display = "none";
                    $("payment-sim-" + invoiceId).style.display = "block";

                    runSteps("Card", "Processing " + cardName + " payment…", [
                        "Reading card",
                        "Contacting " + cardName + " network",
                        "Authorizing transaction",
                        "Finalizing payment"
                    ], 1200, function() {
                        finish(cardName + " " + maskCard(cardDigits));
                    });

                } else if (method === "Bank Transfer") {
                    var bankRef = $("pay-bank-ref").value.trim();

                    $("payment-setup-" + invoiceId).style.display = "none";
                    $("payment-sim-" + invoiceId).style.display = "block";

                    runSteps("Bank", "Confirming bank transfer…", [
                        "Initiating transfer",
                        "Verifying with bank",
                        "Transfer confirmed"
                    ], 1200, function() {
                        finish(bankRef || "Bank Transfer");
                    });

                } else {
                    // Cash
                    $("payment-setup-" + invoiceId).style.display = "none";
                    $("payment-sim-" + invoiceId).style.display = "block";

                    runSteps("Cash", "Recording cash payment…", [
                        "Counting cash received",
                        "Confirming amount"
                    ], 900, function() {
                        finish("Cash");
                    });
                }
            };
        })();
        </script>';
    }




    echo '<div class="card" style="margin-top: 24px;">';
    echo '<div style="display:flex; align-items:center; justify-content:space-between;">';
    echo '<h3 style="margin:0;">Payment History</h3>';
    echo '<button type="button" class="btn btn-secondary btn-small" id="payment-history-toggle" onclick="dsmsTogglePaymentHistory()">Show History</button>';
    echo '</div>';
    echo '<div id="payment-history-body" style="display:none; margin-top:16px;">';
    if (empty($payments)) {
        echo '<div class="no-data"><p>No payments recorded yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Date</th><th>Method</th><th>Control #</th><th>Amount</th><th>Status</th><th>Receipt</th></tr></thead><tbody>';
        foreach ($payments as $p) {
            $receiptStmt = Database::getConnection()->prepare('SELECT id, receipt_number FROM receipts WHERE payment_id = :pid LIMIT 1');
            $receiptStmt->execute([':pid' => $p['id']]);
            $receipt = $receiptStmt->fetch();
            echo '<tr>
                <td>' . h(date('M d, H:i', strtotime($p['payment_date']))) . '</td>
                <td>' . h($p['payment_method']) . '</td>
                <td>' . h($p['control_number'] ?? '-') . '</td>
                <td>' . h(number_format((float)$p['amount_paid'], 2)) . '</td>
                <td>' . h($p['payment_status']) . '</td>
                <td>' . ($receipt ? '<a href="?action=print_receipt&receipt_id=' . h($receipt['id']) . '" class="btn btn-secondary btn-small" target="_blank">View/Print</a>' : '-') . '</td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>'; // #payment-history-body
    echo '</div>';

    echo '<script>
    window.dsmsTogglePaymentHistory = function() {
        var body = document.getElementById("payment-history-body");
        var btn = document.getElementById("payment-history-toggle");
        var isHidden = body.style.display === "none";
        body.style.display = isHidden ? "block" : "none";
        btn.textContent = isHidden ? "Hide History" : "Show History";
    };
    </script>';

    echo '<a href="?action=billing_center" class="btn btn-secondary" style="margin-top: 16px; display:inline-block;">Back to Billing Center</a>';

    renderFooter();
    exit;
}

// ---------------------------------------------------------------------
// Record a payment against an invoice
// ---------------------------------------------------------------------
if ($action === 'record_invoice_payment' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('billing');
    $invoiceId = (int)($_POST['invoice_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $method = trim($_POST['payment_method'] ?? '');
    $reference = trim($_POST['transaction_reference'] ?? '') ?: null;

    try {
        Billing::recordPayment($invoiceId, $method, $amount, (int)$_SESSION['staff_id'], $reference);
        // Notify pharmacy only when the invoice is fully paid (dispense unlocks)
        try {
            if (!class_exists('Notification')) {
                require_once __DIR__ . '/../Models/Notification.php';
            }
            $inv = Billing::find($invoiceId);
            if ($inv && ($inv['status'] ?? '') === 'Paid') {
                Notification::notifyRole(
                    'pharmacy',
                    'payment_complete',
                    'Payment completed — ready to dispense',
                    'Invoice ' . ($inv['invoice_number'] ?? ('#' . $invoiceId)) . ' is fully paid. Pharmacy may dispense.',
                    'pharmacy_dashboard',
                    $invoiceId,
                    'high'
                );
            }
        } catch (\Throwable $ignore) {}
        setFlash('Payment recorded successfully.');
    } catch (\Throwable $e) {
        setFlash('Payment failed: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=view_invoice&invoice_id=' . urlencode((string)$invoiceId));
    exit;
}

// ---------------------------------------------------------------------
// Printable receipt (own minimal layout, not the app header/nav)
// ---------------------------------------------------------------------
if ($action === 'print_receipt') {
    requireRole('billing');
    $receiptId = (int)($_GET['receipt_id'] ?? 0);

    $pdo = Database::getConnection();
    $stmt = $pdo->prepare('SELECT * FROM receipts WHERE id = :id');
    $stmt->execute([':id' => $receiptId]);
    $receipt = $stmt->fetch();

    if (!$receipt) {
        setFlash('Receipt not found.', 'error');
        header('Location: ?action=billing_center');
        exit;
    }

    $invoice = Billing::find((int)$receipt['invoice_id']);
    $patient = Patient::find((int)$invoice['patient_id']);
    $stmt = $pdo->prepare('SELECT * FROM payment_transactions WHERE id = :id');
    $stmt->execute([':id' => $receipt['payment_id']]);
    $payment = $stmt->fetch();
    $staffName = '';
    if ($payment['received_by']) {
        $stmt = $pdo->prepare('SELECT full_name FROM staff WHERE id = :id');
        $stmt->execute([':id' => $payment['received_by']]);
        $s = $stmt->fetch();
        $staffName = $s ? $s['full_name'] : '';
    }

    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Receipt ' . h($receipt['receipt_number']) . '</title>';
    echo '<style>
        * { box-sizing: border-box; }
        body {
            font-family: "Segoe UI", Roboto, Arial, sans-serif;
            margin: 0;
            padding: 32px 16px;
            background: linear-gradient(135deg, #f0fdf4 0%, #ccfbf1 100%);
            color: #0f172a;
            min-height: 100vh;
        }
        .receipt-card {
            max-width: 420px;
            margin: 0 auto;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 20px 50px rgba(15, 118, 110, 0.14);
            overflow: hidden;
        }
        .receipt-head {
            background: linear-gradient(135deg, #0f766e 0%, #14b8a6 100%);
            color: #fff;
            text-align: center;
            padding: 28px 20px 22px;
        }
        .receipt-head .logo { font-size: 30px; margin-bottom: 6px; }
        .receipt-head .hospital-name { font-size: 19px; font-weight: 800; letter-spacing: -0.01em; }
        .receipt-head .sub { font-size: 12.5px; opacity: 0.9; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.08em; }
        .receipt-body { padding: 22px 24px 8px; }
        table { width: 100%; border-collapse: collapse; }
        td, th { padding: 8px 2px; border-bottom: 1px dashed #e2e8f0; font-size: 13.5px; text-align: left; vertical-align: top; }
        td:first-child { color: #64748b; font-weight: 600; width: 46%; }
        td:last-child { text-align: right; font-weight: 600; color: #0f172a; }
        .total-row td { font-weight: 800; border-top: 2px solid #0f766e; border-bottom: none; font-size: 15px; color: #0f766e; padding-top: 12px; }
        .reprint-note { text-align: center; color: #b45309; background: #fffbeb; border-radius: 8px; padding: 8px; margin: 14px 24px 0; font-size: 12.5px; font-weight: 600; }
        .actions { padding: 18px 24px 24px; text-align: center; display: flex; gap: 10px; }
        .actions button, .actions a {
            flex: 1; padding: 11px; border-radius: 10px; border: none; font-weight: 700; font-size: 13.5px;
            cursor: pointer; text-decoration: none; display: inline-block;
        }
        .actions button { background: #0f766e; color: #fff; }
        .actions a { background: #f1f5f9; color: #334155; }
        .receipt-footer { text-align: center; padding: 0 24px 26px; color: #94a3b8; font-size: 11.5px; }
        @media print {
            @page { size: 80mm auto; margin: 4mm; }
            body { background: #fff !important; padding: 0 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .receipt-card { box-shadow: none !important; border-radius: 0 !important; max-width: 100% !important; }
            .receipt-head { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .actions { display: none !important; }
        }
    </style></head><body>';

    echo '<div class="receipt-card">';
    echo '<div class="receipt-head">';
    echo '<div class="logo">' . (function_exists('dsms_icon') ? dsms_icon('hospital', 28) : 'DSMS') . '</div>';
    echo '<div class="hospital-name">DSMS Hospital</div>';
    echo '<div class="sub">Official Payment Receipt</div>';
    echo '</div>';

    echo '<div class="receipt-body"><table>';
    echo '<tr><td>Receipt No.</td><td>' . h($receipt['receipt_number']) . '</td></tr>';
    echo '<tr><td>Invoice No.</td><td>' . h($invoice['invoice_number']) . '</td></tr>';
    echo '<tr><td>Patient</td><td>' . h($patient['patient_id'] . ' — ' . $patient['full_name']) . '</td></tr>';
    echo '<tr><td>Payment Method</td><td>' . h($payment['payment_method']) . '</td></tr>';
    if ($payment['control_number']) {
        echo '<tr><td>Control Number</td><td>' . h($payment['control_number']) . '</td></tr>';
    }
    echo '<tr><td>Cashier</td><td>' . h($staffName) . '</td></tr>';
    echo '<tr><td>Date &amp; Time</td><td>' . h(date('M d, Y H:i', strtotime($payment['payment_date']))) . '</td></tr>';
    echo '<tr class="total-row"><td>Amount Paid</td><td>TZS ' . h(number_format((float)$payment['amount_paid'], 2)) . '</td></tr>';
    echo '<tr><td>Remaining Balance</td><td>TZS ' . h(number_format((float)$invoice['balance'], 2)) . '</td></tr>';
    echo '</table></div>';

    if ((int)$receipt['reprint_count'] > 0) {
        echo '<div class="reprint-note">' . (function_exists('dsms_icon') ? dsms_icon('warning', 14) : '') . ' Reprinted copy (' . h($receipt['reprint_count']) . ')</div>';
    }

    echo '<div class="receipt-footer">Thank you for choosing DSMS Hospital</div>';

    echo '<div class="actions">';
    echo '<button onclick="window.print()">' . (function_exists('dsms_icon') ? dsms_icon('print', 16) : '') . ' Print</button>';
    echo '<a href="?action=reprint_receipt&receipt_id=' . h($receipt['id']) . '">Reprint</a>';
    echo '<a href="?action=view_invoice&invoice_id=' . h($invoice['id']) . '">Back</a>';
    echo '</div>';
    echo '</div>'; // .receipt-card

    echo '</body></html>';
    exit;
}

if ($action === 'reprint_receipt') {
    requireRole('billing');
    $receiptId = (int)($_GET['receipt_id'] ?? 0);
    Billing::reprintReceipt($receiptId);
    header('Location: ?action=print_receipt&receipt_id=' . urlencode((string)$receiptId));
    exit;
}

// ---------------------------------------------------------------------
// Manual invoice items
// ---------------------------------------------------------------------
if ($action === 'add_invoice_item' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('billing');
    $invoiceId = (int)($_POST['invoice_id'] ?? 0);
    $serviceType = trim($_POST['service_type'] ?? 'Other');
    $description = trim($_POST['description'] ?? '');
    $quantity = max(1, (int)($_POST['quantity'] ?? 1));
    $unitPrice = (float)($_POST['unit_price'] ?? 0);

    try {
        if (!$description || $unitPrice <= 0) {
            throw new \Exception('Description and a positive unit price are required.');
        }
        Billing::addManualItem($invoiceId, $serviceType, $description, $quantity, $unitPrice, (int)$_SESSION['staff_id']);
        setFlash('Item added to invoice.');
    } catch (\Throwable $e) {
        setFlash('Could not add item: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=view_invoice&invoice_id=' . urlencode((string)$invoiceId));
    exit;
}

if ($action === 'remove_invoice_item') {
    requireRole('billing');
    $itemId = (int)($_GET['item_id'] ?? 0);
    $invoiceId = (int)($_GET['invoice_id'] ?? 0);

    try {
        Billing::removeItem($itemId, (int)$_SESSION['staff_id']);
        setFlash('Item removed.');
    } catch (\Throwable $e) {
        setFlash('Could not remove item: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=view_invoice&invoice_id=' . urlencode((string)$invoiceId));
    exit;
}

if ($action === 'apply_invoice_discount' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('billing');
    $invoiceId = (int)($_POST['invoice_id'] ?? 0);
    $discount = (float)($_POST['discount_amount'] ?? 0);

    try {
        Billing::applyDiscount($invoiceId, max(0, $discount), (int)$_SESSION['staff_id']);
        setFlash('Discount updated.');
    } catch (\Throwable $e) {
        setFlash('Could not apply discount: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=view_invoice&invoice_id=' . urlencode((string)$invoiceId));
    exit;
}

// ---------------------------------------------------------------------
// Insurance
// ---------------------------------------------------------------------
if ($action === 'add_patient_insurance' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('billing');
    $patientId = (int)($_POST['patient_id'] ?? 0);
    $invoiceId = (int)($_POST['invoice_id'] ?? 0);
    $provider = trim($_POST['insurance_provider'] ?? '');
    $number = trim($_POST['insurance_number'] ?? '');
    $coverage = (float)($_POST['coverage_percent'] ?? 100);

    try {
        if (!$provider || !$number) {
            throw new \Exception('Provider and member number are required.');
        }
        Insurance::addPolicy($patientId, $provider, $number, $coverage);
        setFlash('Insurance policy added.');
    } catch (\Throwable $e) {
        setFlash('Could not add insurance policy: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=view_invoice&invoice_id=' . urlencode((string)$invoiceId));
    exit;
}

if ($action === 'apply_invoice_insurance' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('billing');
    $invoiceId = (int)($_POST['invoice_id'] ?? 0);
    $patientInsuranceId = (int)($_POST['patient_insurance_id'] ?? 0);

    try {
        $result = Billing::applyInsurance($invoiceId, $patientInsuranceId, (int)$_SESSION['staff_id']);
        setFlash('Insurance applied: ' . h(number_format((float)$result['approved_amount'], 2)) . ' approved (' . h($result['status']) . ').');
    } catch (\Throwable $e) {
        setFlash('Could not apply insurance: ' . $e->getMessage(), 'error');
    }
    header('Location: ?action=view_invoice&invoice_id=' . urlencode((string)$invoiceId));
    exit;
}