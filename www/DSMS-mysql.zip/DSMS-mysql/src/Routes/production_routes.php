<?php
/**
 * Production enhancements — search, analytics, escalations, reports, notification history.
 * Additive only; does not replace billing/workflow engines.
 */

// Low-stock / expiry alerts for pharmacy & admin (throttled; once per 5 min)
if (!empty($_SESSION['staff_id']) && in_array($_SESSION['staff_role'] ?? '', ['pharmacy', 'admin'], true)) {
    $last = $_SESSION['stock_alert_at'] ?? 0;
    if (time() - (int)$last > 300) {
        try {
            $low = Medicine::lowStock();
            $exp = Medicine::expired();
            if (count($low) > 0) {
                Notification::notifyRole('pharmacy', 'low_stock', 'Low stock alert', count($low) . ' medicine(s) at or below reorder level.', 'medicine_inventory', null, 'high');
            }
            if (count($exp) > 0) {
                Notification::notifyRole('pharmacy', 'expired_stock', 'Expired medicines', count($exp) . ' medicine(s) past expiry date.', 'medicine_inventory', null, 'urgent');
                Notification::notifyRole('admin', 'expired_stock', 'Expired medicines', count($exp) . ' medicine(s) past expiry.', 'medicine_inventory', null, 'high');
            }
        } catch (\Throwable $e) {
            // non-fatal
        }
        $_SESSION['stock_alert_at'] = time();
    }
}

// Escalation notifications throttled for admin (once per 3 min)
if (!empty($_SESSION['staff_id']) && ($_SESSION['staff_role'] ?? '') === 'admin') {
    $last = $_SESSION['escalation_notify_at'] ?? 0;
    if (time() - (int)$last > 180) {
        try {
            Workflow::notifyEscalations();
        } catch (\Throwable $e) {
            // non-fatal
        }
        $_SESSION['escalation_notify_at'] = time();
    }
}

// ── Global search API ───────────────────────────────────────────────────────
if ($action === 'global_search') {
    header('Content-Type: application/json; charset=utf-8');
    if (empty($_SESSION['staff_id'])) {
        echo json_encode(['results' => []]);
        exit;
    }
    $q = trim($_GET['q'] ?? '');
    $results = Search::query($q, $_SESSION['staff_role'] ?? '', 6);
    echo json_encode(['results' => $results]);
    exit;
}

// ── Notification history ────────────────────────────────────────────────────
if ($action === 'notification_history') {
    if (empty($_SESSION['staff_id'])) {
        header('Location: ?action=login');
        exit;
    }
    $items = Notification::forStaff((int)$_SESSION['staff_id'], 100);
    renderHeader('Notifications', $_SESSION['staff_role'] ?? 'admin');
    echo '<div class="page-title"><h2>Notification Center</h2>
        <p>Real-time alerts poll every few seconds while you work. <meta http-equiv="refresh" content="30"></p></div>';
    echo '<div class="card">';
    if (empty($items)) {
        echo '<div class="no-data"><p>No notifications yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr>
            <th>When</th><th>Priority</th><th>Title</th><th>Message</th><th>Status</th><th></th>
        </tr></thead><tbody>';
        foreach ($items as $n) {
            $pri = $n['priority'] ?? 'normal';
            $priClass = $pri === 'urgent' || $pri === 'high' ? 'status-warning' : 'status-waiting';
            $href = '#';
            if (($n['link_action'] ?? '') === 'view_invoice' && !empty($n['entity_id'])) {
                $href = '?action=view_invoice&invoice_id=' . (int)$n['entity_id'];
            } elseif (!empty($n['link_action'])) {
                $href = '?action=' . urlencode($n['link_action']);
            }
            echo '<tr style="' . (!(int)$n['is_read'] ? 'background:#f0fdf4;' : '') . '">
                <td>' . h(date('M d, H:i', strtotime($n['created_at']))) . '</td>
                <td><span class="status-badge ' . $priClass . '">' . h(strtoupper($pri)) . '</span></td>
                <td><strong>' . h($n['title']) . '</strong></td>
                <td>' . h($n['message']) . '</td>
                <td>' . ((int)$n['is_read'] ? 'Read' : 'Unread') . '</td>
                <td>' . ($href !== '#' ? '<a class="btn btn-secondary btn-small" href="' . h($href) . '">Open</a>' : '') . '</td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '<form method="post" action="?action=mark_notification_read" style="margin-top:12px;">
        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
        <button type="submit" class="btn btn-secondary">Mark all read</button>
    </form></div>';
    renderFooter();
    exit;
}

// Faster JSON poll (used by header) — already in workflow_routes; reduce interval via JS later

// ── Escalations panel ───────────────────────────────────────────────────────
if ($action === 'escalations') {
    if (empty($_SESSION['staff_id']) || !in_array($_SESSION['staff_role'], ['admin', 'billing', 'pharmacy', 'lab'], true)) {
        header('Location: ?action=login');
        exit;
    }
    $items = Workflow::detectEscalations();
    if ($_SESSION['staff_role'] !== 'admin') {
        $map = ['billing' => 'billing_wait', 'pharmacy' => 'pharmacy_wait', 'lab' => 'lab_overdue'];
        $want = $map[$_SESSION['staff_role']] ?? '';
        $items = array_values(array_filter($items, fn($i) => ($i['type'] ?? '') === $want));
    }

    renderHeader('Escalations', $_SESSION['staff_role']);
    echo '<div class="page-title"><h2>Workflow Escalations</h2>
        <p>Cases exceeding configured waiting thresholds. <meta http-equiv="refresh" content="60"></p></div>';
    echo '<div class="card">';
    if (empty($items)) {
        echo '<div class="no-data"><p>No escalations right now.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr>
            <th>Severity</th><th>Type</th><th>Patient</th><th>Detail</th><th>Waiting</th><th>Threshold</th><th></th>
        </tr></thead><tbody>';
        foreach ($items as $i) {
            $sev = $i['severity'] ?? 'high';
            echo '<tr>
                <td><span class="status-badge status-warning">' . h(strtoupper($sev)) . '</span></td>
                <td>' . h($i['label'] ?? '') . '</td>
                <td><strong>' . h($i['patient_code'] ?? '') . '</strong><br>' . h($i['patient_name'] ?? '') . '</td>
                <td>' . h($i['detail'] ?? '') . '</td>
                <td>' . h((string)($i['waiting_minutes'] ?? 0)) . ' min</td>
                <td>' . h((string)($i['threshold_minutes'] ?? 0)) . ' min</td>
                <td>';
            if (!empty($i['patient_id'])) {
                echo '<a class="btn btn-secondary btn-small" href="?action=workflow_timeline&patient_id=' . (int)$i['patient_id'] . '&consultation_id=' . (int)($i['consultation_id'] ?? 0) . '">Timeline</a> ';
            }
            if (!empty($i['invoice_id'])) {
                echo '<a class="btn btn-primary btn-small" href="?action=view_invoice&invoice_id=' . (int)$i['invoice_id'] . '">Invoice</a>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    if ($_SESSION['staff_role'] === 'admin') {
        echo '<div class="card" style="margin-top:16px;"><h3>Escalation thresholds (minutes)</h3>
            <form method="post" action="?action=save_escalation_settings" style="display:flex;gap:12px;flex-wrap:wrap;align-items:end;">
                <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                <label>Billing<br><input type="number" min="5" name="escalation_billing_minutes" value="' . h((string)Workflow::getSetting('escalation_billing_minutes', '30')) . '"></label>
                <label>Pharmacy<br><input type="number" min="5" name="escalation_pharmacy_minutes" value="' . h((string)Workflow::getSetting('escalation_pharmacy_minutes', '20')) . '"></label>
                <label>Laboratory<br><input type="number" min="5" name="escalation_lab_minutes" value="' . h((string)Workflow::getSetting('escalation_lab_minutes', '60')) . '"></label>
                <button type="submit" class="btn btn-secondary">Save</button>
            </form></div>';
    }
    renderFooter();
    exit;
}

if ($action === 'save_escalation_settings' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireRole('admin');
    Workflow::setSetting('escalation_billing_minutes', (string)max(5, (int)($_POST['escalation_billing_minutes'] ?? 30)));
    Workflow::setSetting('escalation_pharmacy_minutes', (string)max(5, (int)($_POST['escalation_pharmacy_minutes'] ?? 20)));
    Workflow::setSetting('escalation_lab_minutes', (string)max(5, (int)($_POST['escalation_lab_minutes'] ?? 60)));
    setFlash('Escalation thresholds saved.');
    header('Location: ?action=escalations');
    exit;
}

// ── Analytics ───────────────────────────────────────────────────────────────
if ($action === 'analytics') {
    requireRole('admin');
    $preset = $_GET['preset'] ?? 'week';
    $from = $_GET['from'] ?? null;
    $to = $_GET['to'] ?? null;
    $timing = Analytics::workflowTiming($from, $to, $preset);
    $daily = Analytics::dailyPatients($from, $to, $preset);
    $revenue = Analytics::revenueByDay($from, $to, $preset);
    $recovered = Analytics::recoveryCount($from, $to, $preset);
    $lost = 0;
    try {
        $lost = count(Workflow::detectLostPatients());
    } catch (\Throwable $e) {
    }
    $stats = Analytics::dashboardStats('admin');

    renderHeader('Workflow Analytics', 'admin');
    echo '<div class="page-title"><h2>Workflow Analytics</h2>
        <p>Operational performance. Existing billing logic is not modified.</p></div>';

    echo '<div class="card" style="margin-bottom:16px;">
        <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;">
            <input type="hidden" name="action" value="analytics">
            <label>Period<br><select name="preset">
                <option value="day"' . ($preset === 'day' ? ' selected' : '') . '>Today</option>
                <option value="week"' . ($preset === 'week' ? ' selected' : '') . '>This week</option>
                <option value="month"' . ($preset === 'month' ? ' selected' : '') . '>This month</option>
                <option value="year"' . ($preset === 'year' ? ' selected' : '') . '>This year</option>
            </select></label>
            <button type="submit" class="btn btn-secondary">Apply</button>
            <a class="btn btn-secondary" href="?action=export_report&type=analytics&preset=' . h($preset) . '&format=csv">Export CSV</a>
        </form>
    </div>';

    echo '<div class="grid grid-3">';
    $cards = [
        ['Avg Consultation (min)', $timing['avg_consultation_minutes']],
        ['Avg Laboratory (min)', $timing['avg_lab_minutes']],
        ['Avg Billing (min)', $timing['avg_billing_minutes']],
        ['Avg Pharmacy (min)', $timing['avg_pharmacy_minutes']],
        ['Visits in period', $timing['total_visits']],
        ['Recovered patients', $recovered],
        ['Lost patients (now)', $lost],
        ['Pending bills', $stats['pending_bills']],
        ['Outstanding (TZS)', number_format($stats['outstanding_balance'], 0)],
    ];
    foreach ($cards as [$label, $val]) {
        echo '<div class="card"><h3>' . h($label) . '</h3><div class="card-stat"><div class="card-stat-text"><h4>Metric</h4><p>' . h((string)$val) . '</p></div></div></div>';
    }
    echo '</div>';

    // Simple bar charts via pure CSS/HTML
    echo '<div class="card" style="margin-top:20px;"><h3>Daily registrations</h3>';
    if (empty($daily)) {
        echo '<div class="no-data"><p>No data in range.</p></div>';
    } else {
        $max = max(1, max(array_map(fn($r) => (int)$r['cnt'], $daily)));
        echo '<div style="display:flex;align-items:flex-end;gap:6px;height:160px;padding:12px 0;">';
        foreach ($daily as $d) {
            $hgt = max(4, (int)(((int)$d['cnt'] / $max) * 140));
            echo '<div title="' . h($d['day'] . ': ' . $d['cnt']) . '" style="flex:1;background:#14b8a6;height:' . $hgt . 'px;border-radius:6px 6px 0 0;"></div>';
        }
        echo '</div><div style="display:flex;gap:6px;font-size:0.65rem;color:#64748b;">';
        foreach ($daily as $d) {
            echo '<div style="flex:1;text-align:center;overflow:hidden;">' . h(substr($d['day'], 5)) . '</div>';
        }
        echo '</div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top:20px;"><h3>Daily revenue (TZS)</h3>';
    if (empty($revenue)) {
        echo '<div class="no-data"><p>No payments in range.</p></div>';
    } else {
        $max = max(1.0, max(array_map(fn($r) => (float)$r['total'], $revenue)));
        echo '<div style="display:flex;align-items:flex-end;gap:6px;height:160px;padding:12px 0;">';
        foreach ($revenue as $d) {
            $hgt = max(4, (int)(((float)$d['total'] / $max) * 140));
            echo '<div title="' . h($d['day'] . ': ' . number_format((float)$d['total'], 0)) . '" style="flex:1;background:#0f766e;height:' . $hgt . 'px;border-radius:6px 6px 0 0;"></div>';
        }
        echo '</div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

// ── Reports export (CSV) ────────────────────────────────────────────────────
if ($action === 'export_report') {
    if (empty($_SESSION['staff_id']) || !in_array($_SESSION['staff_role'], ['admin', 'billing'], true)) {
        header('Location: ?action=login');
        exit;
    }
    $type = $_GET['type'] ?? 'revenue';
    $preset = $_GET['preset'] ?? 'month';
    $format = $_GET['format'] ?? 'csv';

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="dsms_' . preg_replace('/[^a-z0-9_]/', '', $type) . '_' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');

    if ($type === 'revenue' || $type === 'analytics') {
        fputcsv($out, ['Day', 'Revenue_TZS']);
        foreach (Analytics::revenueByDay(null, null, $preset) as $row) {
            fputcsv($out, [$row['day'], $row['total']]);
        }
    } elseif ($type === 'patients') {
        fputcsv($out, ['Day', 'Registrations']);
        foreach (Analytics::dailyPatients(null, null, $preset) as $row) {
            fputcsv($out, [$row['day'], $row['cnt']]);
        }
    } elseif ($type === 'outstanding') {
        fputcsv($out, ['Invoice', 'Patient', 'Total', 'Paid', 'Balance', 'Status']);
        foreach (Billing::getOutstanding() as $inv) {
            fputcsv($out, [
                $inv['invoice_number'],
                ($inv['patient_code'] ?? '') . ' ' . ($inv['full_name'] ?? ''),
                $inv['total_amount'],
                $inv['amount_paid'],
                $inv['balance'],
                $inv['status'],
            ]);
        }
    } elseif ($type === 'audit') {
        fputcsv($out, ['When', 'Staff', 'Role', 'Entity', 'Action', 'Details', 'IP']);
        foreach (AuditLog::search(null, null, 500, 0) as $a) {
            fputcsv($out, [
                $a['created_at'],
                $a['staff_name'] ?? '',
                $a['staff_role'] ?? '',
                $a['entity_type'] . '#' . $a['entity_id'],
                $a['action'],
                $a['details'] ?? '',
                $a['ip_address'] ?? '',
            ]);
        }
    }
    fclose($out);
    exit;
}

// ── Advanced audit browser ──────────────────────────────────────────────────
if ($action === 'audit_browser') {
    requireRole('admin');
    $q = trim($_GET['q'] ?? '');
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per = 40;
    $rows = AuditLog::search($q ?: null, null, $per, ($page - 1) * $per);

    renderHeader('Audit Trail', 'admin');
    echo '<div class="page-title"><h2>Advanced Audit Trail</h2>
        <p>Immutable activity log with user, IP, and action details.</p></div>';
    echo '<div class="card" style="margin-bottom:14px;">
        <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;">
            <input type="hidden" name="action" value="audit_browser">
            <input type="search" name="q" value="' . h($q) . '" placeholder="Search actions, staff, details…" style="min-width:260px;">
            <button class="btn btn-secondary" type="submit">Search</button>
            <a class="btn btn-secondary" href="?action=export_report&type=audit&format=csv">Export CSV</a>
        </form>
    </div>';
    echo '<div class="card"><div class="table-responsive"><table>
        <thead><tr><th>When</th><th>Staff</th><th>Dept</th><th>Entity</th><th>Action</th><th>Details</th><th>IP</th></tr></thead><tbody>';
    foreach ($rows as $a) {
        echo '<tr>
            <td>' . h(date('M d, H:i:s', strtotime($a['created_at']))) . '</td>
            <td>' . h($a['staff_name'] ?? '—') . '</td>
            <td>' . h($a['staff_role'] ?? '—') . '</td>
            <td>' . h($a['entity_type'] . ' #' . $a['entity_id']) . '</td>
            <td>' . h($a['action']) . '</td>
            <td>' . h($a['details'] ?? '') . '</td>
            <td>' . h($a['ip_address'] ?? '—') . '</td>
        </tr>';
    }
    echo '</tbody></table></div>
        <div style="margin-top:12px;">
            <a class="btn btn-secondary btn-small" href="?action=audit_browser&page=' . max(1, $page - 1) . '&q=' . urlencode($q) . '">Prev</a>
            <a class="btn btn-secondary btn-small" href="?action=audit_browser&page=' . ($page + 1) . '&q=' . urlencode($q) . '">Next</a>
        </div>
    </div>';
    renderFooter();
    exit;
}

// ── Reports hub ─────────────────────────────────────────────────────────────
if ($action === 'reports') {
    if (empty($_SESSION['staff_id']) || !in_array($_SESSION['staff_role'], ['admin', 'billing'], true)) {
        header('Location: ?action=login');
        exit;
    }
    renderHeader('Reports', $_SESSION['staff_role']);
    echo '<div class="page-title"><h2>Reports &amp; Exports</h2>
        <p>Download operational reports as CSV (Excel-compatible).</p></div>';
    echo '<div class="grid grid-3">';
    $reports = [
        ['Daily / period revenue', 'export_report&type=revenue&preset=month&format=csv'],
        ['Patient registrations', 'export_report&type=patients&preset=month&format=csv'],
        ['Outstanding bills', 'export_report&type=outstanding&format=csv'],
        ['Audit log', 'export_report&type=audit&format=csv'],
        ['Workflow analytics', 'analytics'],
        ['Lost patients', 'lost_patients'],
    ];
    foreach ($reports as [$title, $act]) {
        echo '<div class="card"><h3>' . h($title) . '</h3>
            <a class="btn btn-primary" href="?action=' . h($act) . '">Open / Export</a></div>';
    }
    echo '</div>';
    renderFooter();
    exit;
}
