<?php

/**
 * DSMS — SQLite → MySQL One-Time Migration
 * ==========================================
 * Run this ONCE after you have:
 *   1. Created the MySQL database:
 *        CREATE DATABASE dsms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
 *   2. Created a MySQL user with full privileges on it:
 *        CREATE USER 'dsms_user'@'localhost' IDENTIFIED BY 'your_password';
 *        GRANT ALL PRIVILEGES ON dsms.* TO 'dsms_user'@'localhost';
 *        FLUSH PRIVILEGES;
 *   3. Filled in config.php with those credentials.
 *
 * Usage:  php migrate_to_mysql.php
 *
 * The script is safe to re-run — it will skip tables that already have data.
 * DELETE this file from your server once it reports SUCCESS.
 */

$sqliteFile = __DIR__ . '/data/database.sqlite';

if (!file_exists($sqliteFile)) {
    die("ERROR: SQLite database not found at data/database.sqlite\n");
}

// ── Connect to SQLite ─────────────────────────────────────────────────────────

try {
    $sqlite = new PDO('sqlite:' . $sqliteFile);
    $sqlite->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sqlite->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("ERROR connecting to SQLite: " . $e->getMessage() . "\n");
}

// ── Connect to MySQL (via config.php) ─────────────────────────────────────────

$config = require __DIR__ . '/config.php';
$dsn = sprintf(
    'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
    $config['db_host'],
    $config['db_port'],
    $config['db_name']
);

try {
    $mysql = new PDO($dsn, $config['db_user'], $config['db_pass']);
    $mysql->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $mysql->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $mysql->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (Exception $e) {
    die("ERROR connecting to MySQL: " . $e->getMessage() . "\n"
      . "Check your config.php and make sure the database exists.\n");
}

echo "Connected to both databases.\n\n";

// ── Bootstrap MySQL schema ────────────────────────────────────────────────────

require_once __DIR__ . '/src/Database.php';

// Temporarily override getConnection to return our already-open MySQL PDO
// by seeding the static cache via reflection — avoids reconnecting.
$ref = new ReflectionClass('Database');
$prop = $ref->getProperty('pdo');
$prop->setAccessible(true);
$prop->setValue(null, $mysql);

// Run initializeSchema via the private method
$initMethod = $ref->getMethod('initializeSchema');
$initMethod->setAccessible(true);
$initMethod->invoke(null);

echo "MySQL schema initialised (CREATE TABLE IF NOT EXISTS).\n\n";

// ── Helper ────────────────────────────────────────────────────────────────────

function migrate(PDO $src, PDO $dst, string $table, array $columns): void
{
    $dst->exec('SET FOREIGN_KEY_CHECKS = 0');
    $count = (int) $dst->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
    if ($count > 0) {
        echo "  $table: already has $count rows — SKIPPED\n";
        $dst->exec('SET FOREIGN_KEY_CHECKS = 1');
        return;
    }

    $rows = $src->query("SELECT * FROM $table ORDER BY id")->fetchAll();
    if (empty($rows)) {
        echo "  $table: 0 rows — nothing to migrate\n";
        $dst->exec('SET FOREIGN_KEY_CHECKS = 1');
        return;
    }

    $colList = implode(', ', array_map(fn($c) => "`$c`", $columns));
    $placeholders = implode(', ', array_fill(0, count($columns), '?'));
    $stmt = $dst->prepare("INSERT INTO `$table` ($colList) VALUES ($placeholders)");

    $dst->beginTransaction();
    $inserted = 0;
    foreach ($rows as $row) {
        $values = array_map(fn($c) => $row[$c] ?? null, $columns);
        $stmt->execute($values);
        $inserted++;
    }
    $dst->commit();

    // Reset AUTO_INCREMENT to avoid gaps
    $maxId = (int) $src->query("SELECT MAX(id) FROM $table")->fetchColumn();
    $dst->exec("ALTER TABLE `$table` AUTO_INCREMENT = " . ($maxId + 1));

    echo "  $table: migrated $inserted rows\n";
    $dst->exec('SET FOREIGN_KEY_CHECKS = 1');
}

// ── Migrate tables in FK-safe order ──────────────────────────────────────────

echo "Migrating data...\n";

migrate($sqlite, $mysql, 'staff', [
    'id', 'username', 'email', 'password_hash', 'full_name',
    'role', 'is_active', 'last_login', 'created_at', 'updated_at',
]);

migrate($sqlite, $mysql, 'patients', [
    'id', 'patient_id', 'full_name', 'gender', 'date_of_birth',
    'phone', 'email', 'address', 'emergency_contact', 'status',
    'registered_by_staff_id', 'created_at', 'updated_at',
]);

migrate($sqlite, $mysql, 'queue_entries', [
    'id', 'patient_id', 'queued_at', 'status',
    'accepted_at', 'accepted_by_staff_id', 'delayed_at',
]);

migrate($sqlite, $mysql, 'vitals', [
    'id', 'patient_id', 'weight', 'height', 'temperature',
    'blood_pressure', 'pulse_rate', 'recorded_by_staff_id', 'recorded_at',
]);

migrate($sqlite, $mysql, 'payments', [
    'id', 'patient_id', 'type', 'amount', 'receipt_number',
    'recorded_by_staff_id', 'paid_at',
]);

migrate($sqlite, $mysql, 'consultations', [
    'id', 'patient_id', 'doctor_staff_id', 'symptoms',
    'examination', 'diagnosis', 'note', 'status', 'created_at',
]);

migrate($sqlite, $mysql, 'prescriptions', [
    'id', 'patient_id', 'doctor_staff_id', 'medication',
    'dosage', 'frequency', 'instructions', 'created_at',
]);

migrate($sqlite, $mysql, 'dispensations', [
    'id', 'prescription_id', 'pharmacy_staff_id',
    'quantity', 'note', 'dispensed_at',
]);

migrate($sqlite, $mysql, 'pharmacy_bills', [
    'id', 'patient_id', 'pharmacist_staff_id', 'amount',
    'created_at', 'paid_at', 'paid_by_staff_id',
]);

migrate($sqlite, $mysql, 'lab_requests', [
    'id', 'consultation_id', 'test_type', 'status',
    'bill', 'created_at', 'paid_at',
]);

migrate($sqlite, $mysql, 'lab_results', [
    'id', 'lab_request_id', 'result', 'comments', 'uploaded_at',
]);

migrate($sqlite, $mysql, 'medication_history', [
    'id', 'patient_id', 'prescription_id', 'pharmacy_staff_id',
    'quantity', 'note', 'dispensed_at', 'created_at',
]);

migrate($sqlite, $mysql, 'budgets', [
    'id', 'department', 'allocated', 'spent',
    'fiscal_year', 'created_at', 'updated_at',
]);

// ── Verify ────────────────────────────────────────────────────────────────────

echo "\nVerification:\n";
$tables = [
    'staff','patients','queue_entries','vitals','payments','consultations',
    'prescriptions','dispensations','pharmacy_bills','lab_requests',
    'lab_results','medication_history','budgets',
];

$allOk = true;
foreach ($tables as $table) {
    $srcCount = (int) $sqlite->query("SELECT COUNT(*) FROM $table")->fetchColumn();
    $dstCount = (int) $mysql->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
    $ok = $srcCount === $dstCount;
    if (!$ok) $allOk = false;
    printf("  %-22s SQLite: %3d   MySQL: %3d   %s\n",
        $table, $srcCount, $dstCount, $ok ? 'OK' : '*** MISMATCH ***');
}

echo "\n";
if ($allOk) {
    echo "✓ SUCCESS — all row counts match.\n\n";
    echo "Next steps:\n";
    echo "  1. Test that all staff can log in.\n";
    echo "  2. DELETE this file from your server (migrate_to_mysql.php).\n";
    echo "  3. The data/ directory and SQLite files are no longer used — you may archive them.\n";
} else {
    echo "✗ One or more tables have mismatched counts. Review the output above.\n";
}
