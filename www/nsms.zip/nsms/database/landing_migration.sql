/* ═══════════════════════════════════════════════════════════
   LANDING PAGE TABLES MIGRATION
   Run once — safe to re-run (uses IF NOT EXISTS / IGNORE).
   Creates:
     - school_gallery       (gallery images, admin-managed)
     - school_regulations   (rules/policies, admin-managed)
     - school_calendar      (key dates & events, admin-managed)
   Also seeds school_settings with extra public-profile keys.
═══════════════════════════════════════════════════════════ */

-- ─── school_gallery ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `school_gallery` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `url`         TEXT         NOT NULL,
    `caption`     VARCHAR(255) NOT NULL DEFAULT '',
    `date`        DATE                  DEFAULT NULL,
    `sort_order`  SMALLINT     NOT NULL DEFAULT 0,
    `is_visible`  TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_visible_sort` (`is_visible`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── school_regulations ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `school_regulations` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `icon`        VARCHAR(10)  NOT NULL DEFAULT '📌',
    `title`       VARCHAR(120) NOT NULL,
    `text`        TEXT         NOT NULL,
    `sort_order`  SMALLINT     NOT NULL DEFAULT 0,
    `is_visible`  TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (`id`),
    KEY `idx_visible_sort` (`is_visible`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── school_calendar ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `school_calendar` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `icon`        VARCHAR(10)  NOT NULL DEFAULT '📅',
    `type`        ENUM('term','holiday','event','exam') NOT NULL DEFAULT 'event',
    `title`       VARCHAR(160) NOT NULL,
    `date`        DATE         NOT NULL,
    `desc`        TEXT                  DEFAULT NULL,
    `is_visible`  TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_date_visible` (`date`, `is_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── Extra school_settings keys (public profile) ─────────────────────────────
INSERT IGNORE INTO `school_settings` (`setting_key`, `setting_value`, `created_at`, `updated_at`)
VALUES
    ('school_tagline',   'Nursery School', NOW(), NOW()),
    ('established_year', '',               NOW(), NOW()),
    ('principal_name',   '',               NOW(), NOW()),
    ('reg_number',       '',               NOW(), NOW());

-- ─── Optional: seed demo gallery items ───────────────────────────────────────
-- Uncomment to pre-populate the gallery with placeholder images.
/*
INSERT IGNORE INTO `school_gallery` (url, caption, date, sort_order, is_visible) VALUES
    ('https://picsum.photos/seed/nurs11/800/600', 'Our Bright Learning Classroom',  '2025-01-10', 1, 1),
    ('https://picsum.photos/seed/nurs22/800/600', 'Outdoor Play & Discovery Time',  '2025-01-12', 2, 1),
    ('https://picsum.photos/seed/nurs33/800/600', 'Creative Arts & Crafts Session', '2025-02-14', 3, 1),
    ('https://picsum.photos/seed/nurs44/800/600', 'Graduation Ceremony',            '2025-06-20', 4, 1),
    ('https://picsum.photos/seed/nurs55/800/600', 'Storytime Corner',               '2025-02-22', 5, 1),
    ('https://picsum.photos/seed/nurs66/800/600', 'Annual Sports Day',              '2025-05-16', 6, 1),
    ('https://picsum.photos/seed/nurs77/800/600', 'Music & Dance Workshop',         '2025-03-01', 7, 1),
    ('https://picsum.photos/seed/nurs88/800/600', 'Healthy Meals Program',          '2025-04-05', 8, 1);
*/

-- ─── Optional: seed demo regulations ─────────────────────────────────────────
/*
INSERT IGNORE INTO `school_regulations` (icon, title, text, sort_order, is_visible) VALUES
    ('🕖', 'Attendance & Punctuality',    'Children must arrive by 7:30 AM. Any absence must be reported to the office by 8:00 AM on the same day.', 1, 1),
    ('👗', 'School Uniform',              'All learners are required to wear the official school uniform every day. Hair must be neat and tidy.', 2, 1),
    ('🍎', 'Healthy Nutrition',           'Only wholesome, nut-free snacks and meals are permitted. No sweets, chips, or sugary drinks during school hours.', 3, 1),
    ('📵', 'No Electronic Devices',       'Mobile phones, tablets, and electronic toys are strictly prohibited during school hours.', 4, 1),
    ('🤝', 'Respect & Conduct',           'All children, parents, and staff are expected to treat one another with courtesy and respect at all times.', 5, 1),
    ('🚗', 'Pick-Up Safety',              'Children are released only to registered guardians. Any change must be communicated in writing.', 6, 1),
    ('💊', 'Medical & Allergies',         'All medical conditions, allergies, and medications must be disclosed in full during the enrolment process.', 7, 1),
    ('📢', 'Communication Policy',        'Official school communication is issued through the parent portal and written notices.', 8, 1);
*/

-- ─── Optional: seed demo calendar events ─────────────────────────────────────
/*
INSERT IGNORE INTO `school_calendar` (icon, type, title, date, `desc`, is_visible) VALUES
    ('📚', 'term',    'Term 1 Begins',       '2025-01-15', 'First day of the new academic year. Children should arrive by 7:30 AM.',        1),
    ('👨‍👩‍👧', 'event',   'Parent\'s Day',        '2025-02-14', 'Annual parent engagement day. Please confirm attendance by 10 Feb.',           1),
    ('🌴', 'holiday', 'Mid-Term Break',      '2025-03-03', 'School closes for mid-term. Classes resume Monday, 10 March.',                   1),
    ('📚', 'term',    'Term 1 Ends',         '2025-04-04', 'End of Term 1. Report cards will be issued on this day.',                        1),
    ('📚', 'term',    'Term 2 Begins',       '2025-04-28', 'First day of Term 2. Please ensure all Term 2 fees are settled.',                1),
    ('🏆', 'event',   'Sports Day',          '2025-05-16', 'Annual sports day at school grounds. Parents are warmly invited.',               1),
    ('🎓', 'event',   'Graduation Ceremony', '2025-06-20', 'Graduation for Nursery II & Pre-Primary leavers. By invitation.',                1),
    ('☀️', 'holiday', 'Long Holiday',        '2025-06-27', 'School closes. Term 3 commences 1 September 2025.',                              1),
    ('📚', 'term',    'Term 3 Begins',       '2025-09-01', 'First day of Term 3. All uniform must comply with school policy.',               1),
    ('🎶', 'event',   'End-of-Year Concert', '2025-11-28', 'Annual concert and prize-giving. All families warmly welcome.',                  1);
*/
