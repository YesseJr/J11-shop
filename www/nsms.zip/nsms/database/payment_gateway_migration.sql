-- ============================================================
-- NSMS Payment Gateway Migration  (v4.2)
--
-- Safe to run standalone. If you previously ran
-- payment_verification_migration.sql / payment_v2_migration.sql,
-- this will migrate that data into the new structure automatically.
-- If you did NOT run those earlier migrations (no payment_submissions
-- table exists), this script detects that and simply skips the
-- migration step — no error, nothing to migrate.
--
-- Creates a transaction-header + line-item model so one payment can
-- cover multiple fees/instalments in a single record, and widens
-- fee_payments.payment_method to accept the new gateway methods.
-- ============================================================

-- 1. Transaction header table — one row per parent submission,
--    regardless of how many fee items it covers.
CREATE TABLE IF NOT EXISTS payment_transactions (
  id                    INT(11)       NOT NULL AUTO_INCREMENT,
  student_id            INT(11)       NOT NULL,
  parent_id             INT(11)       NOT NULL,
  total_amount          DECIMAL(12,2) NOT NULL,
  payment_method        ENUM('M-Pesa','Tigo Pesa','Airtel Money','HaloPesa','Mixx by Yas','Visa','Mastercard') NOT NULL,
  payment_channel       ENUM('mobile_money','card') NOT NULL,
  network_provider      VARCHAR(30)   DEFAULT NULL,
  phone_number          VARCHAR(20)   DEFAULT NULL,
  card_type             VARCHAR(20)   DEFAULT NULL,
  card_last_four        VARCHAR(4)    DEFAULT NULL,
  card_holder_name      VARCHAR(100)  DEFAULT NULL,
  transaction_reference VARCHAR(50)   NOT NULL UNIQUE,
  payment_date          DATE          NOT NULL,
  payment_proof         VARCHAR(255)  DEFAULT NULL,
  notes                 TEXT          DEFAULT NULL,
  status                ENUM('pending_verification','received','rejected') NOT NULL DEFAULT 'pending_verification',
  verified_by           INT(11)       DEFAULT NULL,
  verified_at           TIMESTAMP     NULL DEFAULT NULL,
  rejection_reason      TEXT          DEFAULT NULL,
  receipt_number        VARCHAR(50)   DEFAULT NULL,
  created_at            TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at            TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_pt_student (student_id),
  KEY idx_pt_parent  (parent_id),
  KEY idx_pt_status  (status),
  KEY idx_pt_created (created_at),
  CONSTRAINT fk_pt_student FOREIGN KEY (student_id) REFERENCES students (id) ON DELETE CASCADE,
  CONSTRAINT fk_pt_parent  FOREIGN KEY (parent_id)  REFERENCES users    (id) ON DELETE CASCADE,
  CONSTRAINT fk_pt_verifier FOREIGN KEY (verified_by) REFERENCES users  (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Line-item table — one row per fee/instalment within a transaction.
CREATE TABLE IF NOT EXISTS payment_items (
  id              INT(11)       NOT NULL AUTO_INCREMENT,
  payment_id      INT(11)       NOT NULL,   -- FK to payment_transactions.id
  student_id      INT(11)       NOT NULL,
  fee_type        VARCHAR(50)   NOT NULL,
  installment_no  TINYINT(4)    DEFAULT NULL,
  amount          DECIMAL(10,2) NOT NULL,
  status          ENUM('pending_verification','received','rejected') NOT NULL DEFAULT 'pending_verification',
  fee_payment_id  INT(11)       DEFAULT NULL, -- linked fee_payments.id after approval
  created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_pi_payment (payment_id),
  KEY idx_pi_student (student_id),
  KEY idx_pi_feetype  (fee_type),
  CONSTRAINT fk_pi_payment FOREIGN KEY (payment_id) REFERENCES payment_transactions (id) ON DELETE CASCADE,
  CONSTRAINT fk_pi_student FOREIGN KEY (student_id) REFERENCES students (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Migrate any existing data from the old single-item
--    payment_submissions table (v1/v2) into the new structure.
--    Each old row becomes its own transaction with one item.
--
-- OPTIONAL STEP: if you never ran the old v1/v2 migrations (or already
-- cleared that table), payment_submissions won't exist and this whole
-- step is a no-op — nothing to migrate, nothing breaks. Wrapped in a
-- stored procedure so it can check information_schema first instead of
-- failing outright with "table doesn't exist".
DELIMITER $$

DROP PROCEDURE IF EXISTS migrate_payment_submissions_if_present $$
CREATE PROCEDURE migrate_payment_submissions_if_present()
BEGIN
  DECLARE old_table_exists INT DEFAULT 0;

  SELECT COUNT(*) INTO old_table_exists
    FROM information_schema.tables
   WHERE table_schema = DATABASE()
     AND table_name = 'payment_submissions';

  IF old_table_exists > 0 THEN

    INSERT INTO payment_transactions
      (student_id, parent_id, total_amount, payment_method, payment_channel,
       transaction_reference, payment_date, payment_proof, notes, status,
       verified_by, verified_at, rejection_reason, created_at, updated_at)
    SELECT
      ps.student_id, ps.parent_id, ps.amount,
      CASE WHEN ps.payment_method IN ('M-Pesa') THEN 'M-Pesa'
           WHEN ps.payment_method = 'Bank Transfer' THEN 'M-Pesa'  -- fallback mapping, see note below
           ELSE 'M-Pesa' END,
      'mobile_money',
      ps.payment_reference,
      ps.payment_date, ps.payment_proof, ps.notes, ps.status,
      ps.verified_by, ps.verified_at, ps.rejection_reason, ps.created_at, ps.updated_at
    FROM payment_submissions ps
    WHERE NOT EXISTS (
      SELECT 1 FROM payment_transactions pt WHERE pt.transaction_reference = ps.payment_reference
    );
    -- NOTE: payment_method values 'Bank Transfer','Cash','Cheque','Other' from the old
    -- enum don't map cleanly onto the new gateway-style enum. They are coerced to
    -- 'M-Pesa'/'mobile_money' purely so the migration doesn't fail on legacy rows.
    -- Review and manually correct any pre-existing rows in payment_transactions if needed.

    INSERT INTO payment_items (payment_id, student_id, fee_type, installment_no, amount, status, fee_payment_id, created_at)
    SELECT pt.id, ps.student_id, ps.fee_type, ps.installment_no, ps.amount, ps.status, ps.fee_payment_id, ps.created_at
    FROM payment_submissions ps
    JOIN payment_transactions pt ON pt.transaction_reference = ps.payment_reference
    WHERE NOT EXISTS (
      SELECT 1 FROM payment_items pi WHERE pi.payment_id = pt.id AND pi.fee_type = ps.fee_type
        AND (pi.installment_no <=> ps.installment_no)
    );

    -- Old table is kept (not dropped) for audit/history purposes.
    -- Rename it so it's clearly deprecated:
    RENAME TABLE payment_submissions TO payment_submissions_deprecated_v2;

  END IF;
END $$

DELIMITER ;

CALL migrate_payment_submissions_if_present();
DROP PROCEDURE IF EXISTS migrate_payment_submissions_if_present;

-- ============================================================
-- v4.1 patch — widen fee_payments.payment_method
--
-- fee_payments.payment_method was created with a 4-value enum
-- ('M-Pesa','Bank Transfer','Cash','Cheque') by the original
-- finance module. The gateway simulation introduces six new
-- payment_method values (Tigo Pesa, Airtel Money, HaloPesa,
-- Mixx by Yas, Visa, Mastercard). Without this ALTER, approving
-- any transaction paid via one of those methods causes the
-- INSERT INTO fee_payments to fail silently (the Database class
-- swallows PDOExceptions), so the approval reports success in
-- the UI while writing nothing to the ledger, fee_installments,
-- or student_fee_accounts.
-- ============================================================
ALTER TABLE fee_payments
  MODIFY COLUMN payment_method
    ENUM('M-Pesa','Bank Transfer','Cash','Cheque',
         'Tigo Pesa','Airtel Money','HaloPesa','Mixx by Yas',
         'Visa','Mastercard')
    NOT NULL;
