-- ================================================================
--  J11 Pulse Migration
--  /nsms/api/pulse-migration.sql
--  Run once. All tables use IF NOT EXISTS — safe to re-run.
-- ================================================================

-- ── Collaboration Groups ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS pulse_groups (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(120) NOT NULL,
    description  TEXT,
    avatar_color VARCHAR(20) DEFAULT '#10B981',
    created_by   INT NOT NULL,
    created_at   DATETIME DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pulse_group_members (
    group_id  INT NOT NULL,
    user_id   INT NOT NULL,
    role      ENUM('owner','member') DEFAULT 'member',
    joined_at DATETIME DEFAULT NOW(),
    PRIMARY KEY (group_id, user_id),
    INDEX idx_pgm_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pulse_group_messages (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    group_id   INT NOT NULL,
    sender_id  INT NOT NULL,
    message    TEXT,
    has_file   TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT NOW(),
    INDEX idx_pgmsg_group (group_id),
    INDEX idx_pgmsg_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pulse_group_files (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    group_message_id INT NOT NULL,
    original_name    VARCHAR(255) NOT NULL,
    stored_name      VARCHAR(255) NOT NULL,
    mime_type        VARCHAR(120),
    file_size        INT DEFAULT 0,
    created_at       DATETIME DEFAULT NOW(),
    INDEX idx_pgf_msg (group_message_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Shared Resources ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pulse_resources (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    group_id       INT DEFAULT NULL,
    shared_by      INT NOT NULL,
    title          VARCHAR(200) NOT NULL,
    description    TEXT,
    original_name  VARCHAR(255),
    stored_name    VARCHAR(255),
    mime_type      VARCHAR(120),
    file_size      INT DEFAULT 0,
    download_count INT DEFAULT 0,
    created_at     DATETIME DEFAULT NOW(),
    INDEX idx_pr_group (group_id),
    INDEX idx_pr_shared_by (shared_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Alerts ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pulse_alerts (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    sender_id      INT NOT NULL,
    title          VARCHAR(200) NOT NULL,
    body           TEXT NOT NULL,
    priority       ENUM('low','medium','high','urgent') DEFAULT 'medium',
    target_type    ENUM('all','role','user') DEFAULT 'role',
    target_role    ENUM('all','teacher','parent','admin') DEFAULT 'all',
    target_user_id INT DEFAULT NULL,
    created_at     DATETIME DEFAULT NOW(),
    INDEX idx_pa_sender (sender_id),
    INDEX idx_pa_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pulse_alert_recipients (
    alert_id INT NOT NULL,
    user_id  INT NOT NULL,
    is_read  TINYINT(1) DEFAULT 0,
    read_at  DATETIME DEFAULT NULL,
    PRIMARY KEY (alert_id, user_id),
    INDEX idx_par_user_unread (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Announcements ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pulse_announcements (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    author_id   INT NOT NULL,
    title       VARCHAR(200) NOT NULL,
    body        TEXT NOT NULL,
    target_role ENUM('all','teacher','parent','admin') DEFAULT 'all',
    pinned      TINYINT(1) DEFAULT 0,
    created_at  DATETIME DEFAULT NOW(),
    expires_at  DATETIME DEFAULT NULL,
    INDEX idx_pan_author (author_id),
    INDEX idx_pan_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Newsletters ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pulse_newsletters (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    author_id   INT NOT NULL,
    subject     VARCHAR(200) NOT NULL,
    content     TEXT NOT NULL,
    target_role ENUM('all','teacher','parent','admin') DEFAULT 'all',
    created_at  DATETIME DEFAULT NOW(),
    INDEX idx_pnl_author (author_id),
    INDEX idx_pnl_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Make sure message tables exist (from older migrations) ────
-- message_files, typing_status, user_presence should already exist
-- but we guard here just in case.

CREATE TABLE IF NOT EXISTS message_files (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    message_id    INT NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name   VARCHAR(255) NOT NULL,
    mime_type     VARCHAR(120),
    file_size     INT DEFAULT 0,
    created_at    DATETIME DEFAULT NOW(),
    INDEX idx_mf_msg (message_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS typing_status (
    user_id    INT NOT NULL,
    contact_id INT NOT NULL,
    updated_at DATETIME DEFAULT NOW(),
    PRIMARY KEY (user_id, contact_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_presence (
    user_id   INT PRIMARY KEY,
    last_seen DATETIME DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
