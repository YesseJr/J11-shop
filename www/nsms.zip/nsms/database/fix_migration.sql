-- ================================================================
-- NSMS Fix Migration
-- Fixes:
--   1. notifications.type ENUM missing 'payment' value
--   2. notifications.reference_key column for deduplication
--   3. typing_status table schema discrepancy (target_id vs contact_id)
--   4. class_teachers compatibility view (parent-pulse-api uses it)
--   5. group_resources table (parent-pulse-api uses it, pulse-migration uses pulse_resources)
-- ================================================================

-- FIX 1: Add 'payment' to notifications.type ENUM so insertNotification()
--         in payment-gateway.php can write to it without silent failure.
ALTER TABLE `notifications`
  MODIFY COLUMN `type`
    ENUM('attendance','homework','fee','announcement','report','message','payment')
    NOT NULL;

-- FIX 2: Add reference_key for deduplication (auth.php generate_reminders uses it)
ALTER TABLE `notifications`
  ADD COLUMN IF NOT EXISTS `reference_key` VARCHAR(120) NULL DEFAULT NULL,
  ADD INDEX IF NOT EXISTS `idx_notif_refkey` (`user_id`, `reference_key`);

-- FIX 3: typing_status — parent-pulse-api.php references column `target_id`
--         but pulse-migration.sql created it with `contact_id`.
--         Add `target_id` as an alias column so both APIs work.
--         (pulse-api.php uses contact_id, parent-pulse-api.php uses target_id)
ALTER TABLE `typing_status`
  ADD COLUMN IF NOT EXISTS `target_id` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `is_typing` TINYINT(1) NOT NULL DEFAULT 0;

-- Sync existing rows: contact_id → target_id
UPDATE `typing_status` SET `target_id` = `contact_id` WHERE `target_id` = 0 AND `contact_id` != 0;

-- FIX 4: class_teachers compatibility — parent-pulse-api.php assumes a
--         class_teachers(class_id, teacher_id) junction table, but the NSMS
--         schema uses classes.teacher_id instead.
--         Create a VIEW so the parent API queries work unchanged.
CREATE OR REPLACE VIEW `class_teachers` AS
  SELECT `id` AS `class_id`, `teacher_id`
  FROM `classes`
  WHERE `teacher_id` IS NOT NULL;

-- FIX 5: group_resources — parent-pulse-api.php inserts into group_resources
--         (uploaded_by, group_id, title, description, stored_name, original_name,
--          mime_type, file_size) but pulse-migration.sql created pulse_resources
--         with different column names (shared_by instead of uploaded_by).
--         Create group_resources as a real table (parent API writes to it).
CREATE TABLE IF NOT EXISTS `group_resources` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `group_id`      INT NOT NULL,
  `uploaded_by`   INT NOT NULL,
  `title`         VARCHAR(200) NOT NULL,
  `description`   TEXT,
  `stored_name`   VARCHAR(255),
  `original_name` VARCHAR(255),
  `mime_type`     VARCHAR(120),
  `file_size`     INT DEFAULT 0,
  `created_at`    DATETIME DEFAULT NOW(),
  INDEX idx_gr_group (group_id),
  INDEX idx_gr_user  (uploaded_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- FIX 6: student_parents — parent-pulse-api.php uses student_parents(student_id, parent_id)
--         but the NSMS schema has parents(user_id, student_id).
--         Create a view so the parent API queries work unchanged.
CREATE OR REPLACE VIEW `student_parents` AS
  SELECT `student_id`, `user_id` AS `parent_id`
  FROM `parents`;
