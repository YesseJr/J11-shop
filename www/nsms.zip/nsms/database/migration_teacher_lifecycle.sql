-- ============================================================
--  NSMS Migration: Teacher First-Login + Student Lifecycle
--  Run once against nsms_db
-- ============================================================

-- 1. Add password_changed flag to users table
ALTER TABLE `users`
  ADD COLUMN `password_changed` tinyint(1) NOT NULL DEFAULT 0
  AFTER `last_login`;

-- Mark existing users (admin + parents) as already changed
-- Teachers start at 0 (must change on first login)
UPDATE `users` SET `password_changed` = 1 WHERE `role` IN ('admin', 'parent');

-- 2. Extend students.status enum to include 'dropped'
ALTER TABLE `students`
  MODIFY COLUMN `status`
    ENUM('active','graduated','transferred','withdrawn','dropped')
    COLLATE utf8mb4_unicode_ci DEFAULT 'active';

-- 3. Add exit fields to students table
ALTER TABLE `students`
  ADD COLUMN `exit_date`          date DEFAULT NULL        AFTER `status`,
  ADD COLUMN `exit_reason`        varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER `exit_date`,
  ADD COLUMN `exit_destination`   varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER `exit_reason`,
  ADD COLUMN `exit_authorized_by` int DEFAULT NULL         AFTER `exit_destination`;

-- 4. Student status log (full audit trail)
CREATE TABLE IF NOT EXISTS `student_status_log` (
  `id`          int NOT NULL AUTO_INCREMENT,
  `student_id`  int NOT NULL,
  `old_status`  varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_status`  varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason`      varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes`       text COLLATE utf8mb4_unicode_ci,
  `changed_by`  int NOT NULL,
  `changed_at`  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_changed_at` (`changed_at`),
  CONSTRAINT `ssl_student_fk` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ssl_user_fk`    FOREIGN KEY (`changed_by`) REFERENCES `users`    (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Done.
-- ============================================================
