-- NSMS: Class minimum admission age (idempotent)
-- Auto-applied at runtime via nsmsEnsureClassMinimumAgeColumn() when needed.

ALTER TABLE classes
  ADD COLUMN IF NOT EXISTS minimum_age INT UNSIGNED NULL DEFAULT NULL
  COMMENT 'Minimum age in full years required for admission';
