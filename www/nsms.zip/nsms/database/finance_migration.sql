-- ================================================
-- NSMS Finance Migration
-- Run this once to add the expenses table
-- Compatible with MySQL 5.7+ / MariaDB 10.2+
-- ================================================

USE nsms_db;

CREATE TABLE IF NOT EXISTS expenses (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    category         VARCHAR(100)                                         NOT NULL,
    description      TEXT                                                 NOT NULL,
    amount           DECIMAL(10,2)                                        NOT NULL,
    payment_method   ENUM('Cash','Bank Transfer','M-Pesa','Cheque')       NOT NULL,
    expense_date     DATE                                                 NOT NULL,
    reference_number VARCHAR(100)                                         DEFAULT NULL,
    recorded_by      INT                                                  NOT NULL,
    created_at       TIMESTAMP                                            DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE RESTRICT,
    INDEX idx_date     (expense_date),
    INDEX idx_category (category),
    INDEX idx_recorder (recorded_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- Optional: seed the fee_structure table with
-- typical nursery school fees for 2025/2026
-- (edit amounts to match your school's actual fees)
-- ================================================

INSERT IGNORE INTO fee_structure (fee_type, amount, currency, academic_year, class_id) VALUES
('School Fees',       250000, 'TSh', '2025/2026', NULL),
('Registration Fee',  100000, 'TSh', '2025/2026', NULL),
('Stationery',         50000, 'TSh', '2025/2026', NULL),
('Uniform',            80000, 'TSh', '2025/2026', NULL),
('Meals',              60000, 'TSh', '2025/2026', NULL),
('Transport',         120000, 'TSh', '2025/2026', NULL),
('Late Payment Fee',   20000, 'TSh', '2025/2026', NULL);

-- ================================================
-- END OF MIGRATION
-- ================================================
