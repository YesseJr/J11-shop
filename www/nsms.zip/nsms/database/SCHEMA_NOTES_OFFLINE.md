# Offline sync schema notes (from live dump 2026-08-19)

## fee_payments
- receipt_number VARCHAR(50) NOT NULL
- recorded_by INT NOT NULL (FK users)
- payment_method ENUM: M-Pesa, Bank Transfer, Cash, Cheque, Other, Tigo Pesa, Airtel Money, HaloPesa, Mixx by Yas, Visa, Mastercard, Control Number
- status ENUM: confirmed, pending, failed
- no `notes` column — use reference_number

## expenses
- category, description NOT NULL
- payment_method ENUM: Cash, Bank Transfer, M-Pesa, Cheque only
- recorded_by INT NOT NULL

## students
- class_id, gender, enrollment_date required for inserts
