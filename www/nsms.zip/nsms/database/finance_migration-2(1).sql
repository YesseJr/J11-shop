-- ================================================
-- NSMS Finance Migration  v2
-- Run this file on a fresh DB, or run only the new
-- sections if upgrading an existing installation.
-- Compatible with MySQL 5.7+ / MariaDB 10.2+
-- ================================================

USE nsms_db;

-- ── expenses table ───────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    category         VARCHAR(100)                                         NOT NULL,
    description      TEXT                                                 NOT NULL,
    amount           DECIMAL(10,2)                                        NOT NULL,
    payment_method   ENUM('Cash','Bank Transfer','M-Pesa','Cheque')       NOT NULL,
    expense_date     DATE                                                 NOT NULL,
    reference_number VARCHAR(100)                                         DEFAULT NULL,
    recorded_by      INT                                                  NOT NULL,
    created_at       TIMESTAMP                                            DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE RESTRICT,
    INDEX idx_date     (expense_date),
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── fee_installments ─────────────────────────────
-- Tracks each installment slot for installable fees
-- (School Fees and Transport) per student per year.
-- 10 rows per student per fee_type per academic year.
-- status: unpaid → partial → paid
CREATE TABLE IF NOT EXISTS fee_installments (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    student_id       INT           NOT NULL,
    academic_year    VARCHAR(10)   NOT NULL,
    fee_type         VARCHAR(50)   NOT NULL,   -- 'School Fees' | 'Transport'
    installment_no   TINYINT       NOT NULL,   -- 1–10
    amount_due       DECIMAL(10,2) NOT NULL,   -- after any discount
    amount_paid      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status           ENUM('unpaid','partial','paid') DEFAULT 'unpaid',
    payment_id       INT           DEFAULT NULL,
    paid_date        DATE          DEFAULT NULL,
    created_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (payment_id) REFERENCES fee_payments(id) ON DELETE SET NULL,
    UNIQUE KEY uq_installment (student_id, academic_year, fee_type, installment_no),
    INDEX idx_student (student_id),
    INDEX idx_year    (academic_year),
    INDEX idx_status  (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── student_discounts ────────────────────────────
-- Per-student discount history.
-- Active discount = row where effective_to IS NULL or > CURDATE().
-- Closing a discount: set effective_to = today before inserting new one.
CREATE TABLE IF NOT EXISTS student_discounts (
    id               INT            AUTO_INCREMENT PRIMARY KEY,
    student_id       INT            NOT NULL,
    discount_percent DECIMAL(5,2)   NOT NULL,   -- 0–100, e.g. 50.00 = 50%
    reason           VARCHAR(255)   DEFAULT NULL,
    effective_from   DATE           NOT NULL,
    effective_to     DATE           DEFAULT NULL,  -- NULL = currently active
    created_by       INT            NOT NULL,
    created_at       TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id)  ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)     ON DELETE RESTRICT,
    INDEX idx_student (student_id),
    INDEX idx_dates   (effective_from, effective_to)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- Fee structure seed data — per-class fees 2025/2026
-- Edit amounts to match your school's actual fees.
-- class_id NULL = school-wide (applies to all classes).
-- 'School Fees' and 'Transport' are installable (÷10).
-- Everything else is paid once upfront.
-- ================================================

DELETE FROM fee_structure WHERE academic_year = '2025/2026';

-- School-wide one-time fees
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year) VALUES
(NULL, 'Registration Fee', 100000, 'TSh', '2025/2026'),
(NULL, 'Stationery',        50000, 'TSh', '2025/2026'),
(NULL, 'Uniform',           80000, 'TSh', '2025/2026');

-- Blue Class — School Fees + Transport (annual; system divides by 10)
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'School Fees', 3000000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Blue Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Transport',   1200000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Blue Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Meals',        700000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Blue Class' LIMIT 1;

-- Green Class
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'School Fees', 2800000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Green Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Transport',   1200000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Green Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Meals',        650000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Green Class' LIMIT 1;

-- Red Class
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'School Fees', 2600000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Red Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Transport',   1100000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Red Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Meals',        600000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Red Class' LIMIT 1;

-- Yellow Class
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'School Fees', 2500000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Yellow Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Transport',   1100000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Yellow Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Meals',        550000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Yellow Class' LIMIT 1;

-- ================================================
-- END OF MIGRATION
-- ================================================
