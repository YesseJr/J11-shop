-- NSMS Payment Module v2 Migration (incremental after v1)
ALTER TABLE payment_submissions
  ADD COLUMN IF NOT EXISTS fee_type VARCHAR(50) DEFAULT NULL AFTER parent_id,
  ADD COLUMN IF NOT EXISTS installment_no TINYINT(4) DEFAULT NULL AFTER fee_type;
ALTER TABLE payment_submissions
  MODIFY COLUMN payment_method ENUM('M-Pesa','Bank Transfer','Cash','Cheque','Other') NOT NULL DEFAULT 'M-Pesa';
