-- ================================================
-- TEACHERS MANAGEMENT - MIGRATION
-- Run this on your nsms_db to add new features
-- ================================================

USE nsms_db;

-- ------------------------------------------------
-- 1. Add photo_url to users table
-- ------------------------------------------------


-- ------------------------------------------------
-- 2. Extend status ENUM to include 'on_leave'
--    (users table currently: active, inactive, suspended)
-- ------------------------------------------------
ALTER TABLE users
    MODIFY COLUMN status ENUM('active', 'inactive', 'suspended', 'on_leave') DEFAULT 'active';

-- ------------------------------------------------
-- 3. SUBJECTS TABLE
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(100) NOT NULL,
    subject_code VARCHAR(20) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_code (subject_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------
-- 4. TEACHER SUBJECTS (junction table)
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS teacher_subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    subject_id INT NOT NULL,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    UNIQUE KEY unique_teacher_subject (teacher_id, subject_id),
    INDEX idx_teacher (teacher_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------
-- 5. TEACHER RATINGS TABLE
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS teacher_ratings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    rated_by INT NOT NULL,
    rating DECIMAL(3,1) NOT NULL,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (rated_by) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_teacher_rater (teacher_id, rated_by),
    INDEX idx_teacher (teacher_id),
    CONSTRAINT chk_rating CHECK (rating >= 1 AND rating <= 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------
-- 6. SAMPLE SUBJECTS (nursery curriculum)
-- ------------------------------------------------
INSERT IGNORE INTO subjects (subject_name, subject_code, description) VALUES
('Mathematics',        'MATH', 'Numbers, counting, basic arithmetic'),
('English Language',   'ENG',  'Reading, writing, phonics'),
('Science',            'SCI',  'Basic nature and environment'),
('Arts & Crafts',      'ART',  'Drawing, painting, creative activities'),
('Physical Education', 'PE',   'Sports, motor skills, outdoor activities'),
('Music & Rhymes',     'MUS',  'Songs, rhythm, musical instruments'),
('Social Studies',     'SS',   'Community, family, social skills'),
('Handwriting',        'HW',   'Pencil grip, letter formation'),
('Health Education',   'HE',   'Hygiene, nutrition, safety'),
('Kiswahili',          'KIS',  'Basic Kiswahili language');

-- ------------------------------------------------
-- 7. Uploads directory marker (create manually)
-- mkdir -p /path/to/nsms/public/uploads/teachers
-- chmod 755 /path/to/nsms/public/uploads/teachers
-- ------------------------------------------------
