-- ================================================
-- NSMS Finance Migration
-- Run this once to add the expenses table
-- Compatible with MySQL 5.7+ / MariaDB 10.2+
-- ================================================

USE nsms_db;

CREATE TABLE IF NOT EXISTS expenses (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    category         VARCHAR(100)                                         NOT NULL,
    description      TEXT                                                 NOT NULL,
    amount           DECIMAL(10,2)                                        NOT NULL,
    payment_method   ENUM('Cash','Bank Transfer','M-Pesa','Cheque')       NOT NULL,
    expense_date     DATE                                                 NOT NULL,
    reference_number VARCHAR(100)                                         DEFAULT NULL,
    recorded_by      INT                                                  NOT NULL,
    created_at       TIMESTAMP                                            DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE RESTRICT,
    INDEX idx_date     (expense_date),
    INDEX idx_category (category),
    INDEX idx_recorder (recorded_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- Optional: seed the fee_structure table with
-- per-class fees for 2025/2026.
-- Edit amounts to match your school's actual fees.
-- class_id NULL = school-wide (applies to all classes).
-- ================================================

-- First clear any existing 2025/2026 fee data to avoid duplicates
DELETE FROM fee_structure WHERE academic_year = '2025/2026';

-- School-wide fees (class_id = NULL — apply to every student regardless of class)
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year) VALUES
(NULL, 'Registration Fee', 100000, 'TSh', '2025/2026'),
(NULL, 'Stationery',        50000, 'TSh', '2025/2026'),
(NULL, 'Uniform',           80000, 'TSh', '2025/2026');

-- Blue Class (id=1) — oldest / most advanced
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'School Fees', 300000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Blue Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Meals',        70000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Blue Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Transport',   120000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Blue Class' LIMIT 1;

-- Green Class (id=2)
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'School Fees', 280000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Green Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Meals',        65000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Green Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Transport',   120000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Green Class' LIMIT 1;

-- Red Class (id=3)
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'School Fees', 260000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Red Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Meals',        60000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Red Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Transport',   110000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Red Class' LIMIT 1;

-- Yellow Class (id=4) — youngest / entry level
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'School Fees', 250000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Yellow Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Meals',        55000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Yellow Class' LIMIT 1;
INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
SELECT c.id, 'Transport',   110000, 'TSh', '2025/2026' FROM classes c WHERE c.class_name='Yellow Class' LIMIT 1;

-- ================================================
-- END OF MIGRATION
-- ================================================
