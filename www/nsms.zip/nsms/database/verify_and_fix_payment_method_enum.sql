-- ============================================================
-- Standalone verification + fix for fee_payments.payment_method
--
-- Run this by itself if you're seeing an approval error like:
--   "Failed to record ledger entry... payment_method 'X' is not
--    yet allowed in the fee_payments table"
--
-- This is idempotent — safe to run any number of times, whether
-- or not the v4.1 patch was already applied.
-- ============================================================

ALTER TABLE fee_payments
  MODIFY COLUMN payment_method
    ENUM('M-Pesa','Bank Transfer','Cash','Cheque',
         'Tigo Pesa','Airtel Money','HaloPesa','Mixx by Yas',
         'Visa','Mastercard')
    NOT NULL;

-- Verify it worked — run this SELECT and check the Type column
-- in the result. It should list all 10 values above.
SHOW COLUMNS FROM fee_payments LIKE 'payment_method';
