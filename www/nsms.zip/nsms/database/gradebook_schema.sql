-- ============================================================
-- NSMS — GRADEBOOK & ASSESSMENT SUBSYSTEM
-- File: gradebook_schema.sql
-- Run this against the nsms_db database.
-- Integrates with: subjects, teacher_subjects, students,
--                  classes, users, term_reports, midterm_reports
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- ============================================================
-- TABLE 1: gradebook_assessments
--   One row per "assessment event" (quiz, test, exam, project…)
--   Scoped to: class + subject + teacher + term
--   SECURITY: teacher_id must match teacher_subjects for subject_id
-- ============================================================
CREATE TABLE IF NOT EXISTS `gradebook_assessments` (
  `id`              INT NOT NULL AUTO_INCREMENT,
  `class_id`        INT NOT NULL,
  `subject_id`      INT NOT NULL,
  `teacher_id`      INT NOT NULL,
  `title`           VARCHAR(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assessment_type` ENUM(
                      'quiz','assignment','test',
                      'exam','project','participation','other'
                    ) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'test',
  `term`            VARCHAR(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year`   VARCHAR(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_score`       DECIMAL(5,2) NOT NULL DEFAULT '100.00',
  `weight`          DECIMAL(5,2) NOT NULL DEFAULT '100.00',
                     -- Percentage weight of this assessment within the subject
                     -- (allows multiple weighted assessments per subject per term)
  `assessment_date` DATE         DEFAULT NULL,
  `is_published`    TINYINT(1)   NOT NULL DEFAULT '0',
                     -- 0 = draft (only teacher sees scores)
                     -- 1 = published (scores visible in reports & to parents)
  `created_at`      TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),
  KEY `idx_ga_class`      (`class_id`),
  KEY `idx_ga_subject`    (`subject_id`),
  KEY `idx_ga_teacher`    (`teacher_id`),
  KEY `idx_ga_term_year`  (`term`, `academic_year`),
  KEY `idx_ga_published`  (`is_published`),

  CONSTRAINT `ga_class_fk`   FOREIGN KEY (`class_id`)   REFERENCES `classes`   (`id`) ON DELETE CASCADE,
  CONSTRAINT `ga_subject_fk` FOREIGN KEY (`subject_id`) REFERENCES `subjects`  (`id`) ON DELETE CASCADE,
  CONSTRAINT `ga_teacher_fk` FOREIGN KEY (`teacher_id`) REFERENCES `users`     (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- TABLE 2: gradebook_grades
--   One row per (assessment × student) — the actual scores
--   NULL score = student not yet graded (appears as "—" in UI)
-- ============================================================
CREATE TABLE IF NOT EXISTS `gradebook_grades` (
  `id`            INT          NOT NULL AUTO_INCREMENT,
  `assessment_id` INT          NOT NULL,
  `student_id`    INT          NOT NULL,
  `score`         DECIMAL(5,2) DEFAULT NULL,
  `remarks`       VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graded_by`     INT          NOT NULL,
  `graded_at`     TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at`    TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_grade_student_assessment` (`assessment_id`, `student_id`),
  KEY `idx_gg_student`    (`student_id`),
  KEY `idx_gg_assessment` (`assessment_id`),

  CONSTRAINT `gg_assessment_fk` FOREIGN KEY (`assessment_id`) REFERENCES `gradebook_assessments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `gg_student_fk`    FOREIGN KEY (`student_id`)    REFERENCES `students`              (`id`) ON DELETE CASCADE,
  CONSTRAINT `gg_grader_fk`     FOREIGN KEY (`graded_by`)     REFERENCES `users`                 (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- TABLE 3: student_subject_performance
--   Aggregated / final subject grade per student per term.
--   Auto-calculated from gradebook_grades but teacher can also
--   write a manual narrative remark here.
--   This table is what feeds term_reports and midterm_reports.
-- ============================================================
CREATE TABLE IF NOT EXISTS `student_subject_performance` (
  `id`                INT          NOT NULL AUTO_INCREMENT,
  `student_id`        INT          NOT NULL,
  `subject_id`        INT          NOT NULL,
  `class_id`          INT          NOT NULL,
  `term`              VARCHAR(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year`     VARCHAR(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `average_score`     DECIMAL(5,2) DEFAULT NULL,
  `grade_letter`      VARCHAR(5)   COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                       -- A / B / C / D / E / F
  `performance_level` ENUM(
                        'Excellent','Very Good','Good',
                        'Average','Below Average','Poor'
                      ) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher_remarks`   TEXT         COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by`        INT          DEFAULT NULL,
  `updated_at`        TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at`        TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ssp` (`student_id`, `subject_id`, `term`, `academic_year`),
  KEY `idx_ssp_student`   (`student_id`),
  KEY `idx_ssp_subject`   (`subject_id`),
  KEY `idx_ssp_class`     (`class_id`),
  KEY `idx_ssp_term_year` (`term`, `academic_year`),

  CONSTRAINT `ssp_student_fk` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ssp_subject_fk` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ssp_class_fk`   FOREIGN KEY (`class_id`)   REFERENCES `classes`  (`id`) ON DELETE CASCADE,
  CONSTRAINT `ssp_updater_fk` FOREIGN KEY (`updated_by`) REFERENCES `users`    (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- TABLE 4: gradebook_report_cards
--   Final assembled report-card record per student per term.
--   Links to student_subject_performance rows (via JSON or
--   individually) and adds holistic narrative fields.
--   This replaces / supersedes the old midterm_reports /
--   term_reports tables for gradebook-driven assessments.
-- ============================================================
CREATE TABLE IF NOT EXISTS `gradebook_report_cards` (
  `id`                      INT       NOT NULL AUTO_INCREMENT,
  `student_id`              INT       NOT NULL,
  `class_id`                INT       NOT NULL,
  `teacher_id`              INT       NOT NULL,
  `term`                    VARCHAR(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year`           VARCHAR(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `overall_average`         DECIMAL(5,2) DEFAULT NULL,
  `overall_grade`           VARCHAR(5)   COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class_rank`              SMALLINT     UNSIGNED DEFAULT NULL,
  `total_students_in_class` SMALLINT     UNSIGNED DEFAULT NULL,
  -- Holistic / narrative assessment fields --
  `conduct`                 ENUM('Excellent','Very Good','Good','Satisfactory','Needs Improvement')
                               COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `punctuality`             ENUM('Excellent','Very Good','Good','Satisfactory','Needs Improvement')
                               COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `neatness`                ENUM('Excellent','Very Good','Good','Satisfactory','Needs Improvement')
                               COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `participation`           ENUM('Excellent','Very Good','Good','Satisfactory','Needs Improvement')
                               COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_skills`           ENUM('Excellent','Very Good','Good','Satisfactory','Needs Improvement')
                               COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher_general_remarks` TEXT  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_finalized`            TINYINT(1)   NOT NULL DEFAULT '0',
                             -- 0 = draft, 1 = finalized (locked & visible to parent)
  `finalized_at`            TIMESTAMP    NULL DEFAULT NULL,
  `created_at`              TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`              TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rc_student_term` (`student_id`, `term`, `academic_year`),
  KEY `idx_rc_class`     (`class_id`),
  KEY `idx_rc_teacher`   (`teacher_id`),
  KEY `idx_rc_term_year` (`term`, `academic_year`),
  KEY `idx_rc_finalized` (`is_finalized`),

  CONSTRAINT `rc_student_fk` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rc_class_fk`   FOREIGN KEY (`class_id`)   REFERENCES `classes`  (`id`) ON DELETE CASCADE,
  CONSTRAINT `rc_teacher_fk` FOREIGN KEY (`teacher_id`) REFERENCES `users`    (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


COMMIT;

-- ============================================================
-- USEFUL VIEWS (optional but recommended)
-- ============================================================

-- View: per-student subject averages for the current term
-- Usage: SELECT * FROM v_subject_averages WHERE student_id = 3 AND term = 'Term 1';
CREATE OR REPLACE VIEW `v_subject_averages` AS
SELECT
    gg.student_id,
    ga.subject_id,
    s.subject_name,
    s.subject_code,
    ga.class_id,
    ga.term,
    ga.academic_year,
    COUNT(gg.id)                       AS assessment_count,
    SUM(gg.score * ga.weight)          AS weighted_sum,
    SUM(ga.weight)                     AS total_weight,
    CASE WHEN SUM(ga.weight) > 0
         THEN ROUND(SUM(gg.score * ga.weight) / SUM(ga.weight), 2)
         ELSE NULL
    END                                AS weighted_average,
    CASE
        WHEN ROUND(SUM(gg.score * ga.weight) / NULLIF(SUM(ga.weight),0), 2) >= 90 THEN 'A'
        WHEN ROUND(SUM(gg.score * ga.weight) / NULLIF(SUM(ga.weight),0), 2) >= 75 THEN 'B'
        WHEN ROUND(SUM(gg.score * ga.weight) / NULLIF(SUM(ga.weight),0), 2) >= 60 THEN 'C'
        WHEN ROUND(SUM(gg.score * ga.weight) / NULLIF(SUM(ga.weight),0), 2) >= 50 THEN 'D'
        WHEN ROUND(SUM(gg.score * ga.weight) / NULLIF(SUM(ga.weight),0), 2) >= 40 THEN 'E'
        ELSE 'F'
    END                                AS grade_letter
FROM `gradebook_grades`  gg
JOIN `gradebook_assessments` ga ON ga.id = gg.assessment_id
JOIN `subjects`              s  ON s.id  = ga.subject_id
WHERE gg.score IS NOT NULL
  AND ga.is_published = 1
GROUP BY
    gg.student_id, ga.subject_id, s.subject_name, s.subject_code,
    ga.class_id, ga.term, ga.academic_year;

-- ============================================================
-- END OF SCHEMA
-- ============================================================
