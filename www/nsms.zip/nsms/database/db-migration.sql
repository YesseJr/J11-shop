-- ═══════════════════════════════════════════════════════════════
-- NSMS Messages System — DB Migration
-- Run this ONCE against your NSMS database.
-- Safe to run multiple times (uses IF NOT EXISTS / IGNORE).
-- ═══════════════════════════════════════════════════════════════

-- 1. Add has_file column to messages table
--    (Skip if already exists — MySQL 5.7/8.0 don't support IF NOT EXISTS on ALTER)
SET @col_exists = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME   = 'messages'
      AND COLUMN_NAME  = 'has_file'
);
SET @sql = IF(@col_exists = 0,
    'ALTER TABLE messages ADD COLUMN has_file TINYINT(1) NOT NULL DEFAULT 0',
    'SELECT ''has_file column already exists'' AS info'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2. Typing status table
--    Stores "user X is currently typing to contact Y"
--    Rows are ephemeral; check updated_at < 5 seconds ago for active typing.
CREATE TABLE IF NOT EXISTS typing_status (
    user_id    INT NOT NULL,
    contact_id INT NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, contact_id),
    KEY idx_ts_contact (contact_id),
    KEY idx_ts_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. User presence table
--    last_seen is updated on every API call.
--    A user is considered "online" if last_seen >= NOW() - INTERVAL 2 MINUTE.
CREATE TABLE IF NOT EXISTS user_presence (
    user_id   INT      NOT NULL,
    last_seen DATETIME NOT NULL,
    PRIMARY KEY (user_id),
    KEY idx_up_seen (last_seen)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Message files table
--    Stores metadata for files attached to messages.
--    Actual files live in /nsms/uploads/messages/<stored_name>.
CREATE TABLE IF NOT EXISTS message_files (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    message_id    INT          NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name   VARCHAR(255) NOT NULL,
    mime_type     VARCHAR(100) NOT NULL DEFAULT 'application/octet-stream',
    file_size     INT          NOT NULL DEFAULT 0,
    created_at    DATETIME     NOT NULL,
    KEY idx_mf_message (message_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Optional: Create uploads directory hint
--    Create /nsms/uploads/messages/ manually (chmod 755) and
--    ensure your web server user can write to it.

-- 6. Cleanup job (optional CRON — cleans stale typing rows)
--    DELETE FROM typing_status WHERE updated_at < DATE_SUB(NOW(), INTERVAL 1 MINUTE);
