-- ============================================================
-- NSMS Payment Verification Module  —  Migration
-- Author: Waython Yesse / J11 Technologies
-- Run once against the `nsms` database.
-- Safe to re-run: uses IF NOT EXISTS / MODIFY COLUMN guards.
-- ============================================================

-- ─────────────────────────────────────────────────────────
-- 1. Extend the existing `notifications` table to support
--    the 'payment' type (ALTER adds value to the ENUM).
-- ─────────────────────────────────────────────────────────
ALTER TABLE `notifications`
  MODIFY COLUMN `type`
    ENUM('attendance','homework','fee','announcement','report','message','payment')
    NOT NULL DEFAULT 'payment';

-- ─────────────────────────────────────────────────────────
-- 2. payment_submissions  —  parent-initiated payment queue
--    Separate from the admin-recorded fee_payments table so
--    submissions can be verified before they touch the ledger.
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `payment_submissions` (
  `id`               INT(11)       NOT NULL AUTO_INCREMENT,
  `student_id`       INT(11)       NOT NULL,
  `parent_id`        INT(11)       NOT NULL,          -- users.id of the parent
  `amount`           DECIMAL(10,2) NOT NULL,
  `payment_reference` VARCHAR(100) NOT NULL,          -- parent-supplied ref / TxID
  `payment_method`   ENUM('M-Pesa','Bank Transfer','Cash','Cheque','Other') NOT NULL DEFAULT 'M-Pesa',
  `payment_date`     DATE          NOT NULL,          -- date parent claims to have paid
  `payment_proof`    VARCHAR(255)  DEFAULT NULL,      -- uploaded file path (relative to publicuploads/)
  `notes`            TEXT          DEFAULT NULL,      -- optional note from parent
  `status`           ENUM('pending_verification','received','rejected') NOT NULL DEFAULT 'pending_verification',
  `verified_by`      INT(11)       DEFAULT NULL,      -- users.id of verifying admin
  `verified_at`      TIMESTAMP     NULL DEFAULT NULL,
  `rejection_reason` TEXT          DEFAULT NULL,
  `fee_payment_id`   INT(11)       DEFAULT NULL,      -- FK to fee_payments after approval
  `created_at`       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_student`   (`student_id`),
  KEY `idx_parent`    (`parent_id`),
  KEY `idx_status`    (`status`),
  KEY `idx_created`   (`created_at`),
  CONSTRAINT `fk_ps_student`  FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)  ON DELETE CASCADE,
  CONSTRAINT `fk_ps_parent`   FOREIGN KEY (`parent_id`)  REFERENCES `users`    (`id`)  ON DELETE CASCADE,
  CONSTRAINT `fk_ps_verified` FOREIGN KEY (`verified_by`) REFERENCES `users`   (`id`)  ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────
-- 3. student_fee_accounts  —  per-student running balance
--    Created/updated automatically on each approved payment.
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `student_fee_accounts` (
  `id`           INT(11)       NOT NULL AUTO_INCREMENT,
  `student_id`   INT(11)       NOT NULL UNIQUE,
  `total_fee`    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `total_paid`   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `balance`      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `last_updated` TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sfa_student` (`student_id`),
  CONSTRAINT `fk_sfa_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────
-- 4. Seed student_fee_accounts from existing fee_payments
--    (runs once; IF NOT EXISTS guard on the table above
--    means re-running this file is harmless).
-- ─────────────────────────────────────────────────────────
INSERT IGNORE INTO `student_fee_accounts` (`student_id`, `total_fee`, `total_paid`, `balance`)
SELECT
    s.id                                         AS student_id,
    COALESCE(fs_totals.total_fee, 0)             AS total_fee,
    COALESCE(fp_totals.total_paid, 0)            AS total_paid,
    COALESCE(fs_totals.total_fee, 0)
      - COALESCE(fp_totals.total_paid, 0)        AS balance
FROM students s
LEFT JOIN (
    SELECT fs.class_id, SUM(fs.amount) AS total_fee
    FROM fee_structure fs
    GROUP BY fs.class_id
) fs_totals ON fs_totals.class_id = s.class_id
LEFT JOIN (
    SELECT fp.student_id, SUM(fp.amount) AS total_paid
    FROM fee_payments fp
    WHERE fp.status = 'confirmed'
    GROUP BY fp.student_id
) fp_totals ON fp_totals.student_id = s.id;

-- ─────────────────────────────────────────────────────────
-- 5. Upload directory placeholder (informational comment)
--    Create the directory:  nsms/publicuploads/payment_proofs/
--    and make sure it is web-accessible on your server.
-- ─────────────────────────────────────────────────────────
-- (no SQL needed — handled by PHP mkdir in the API)
