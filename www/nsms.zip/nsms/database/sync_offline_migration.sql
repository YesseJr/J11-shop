-- NSMS Offline-First / Multi-device Sync (additive, non-destructive)
-- Safe to run multiple times where possible.

-- Device registry
CREATE TABLE IF NOT EXISTS sync_devices (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  device_uuid VARCHAR(36) NOT NULL,
  device_name VARCHAR(120) NULL,
  user_id INT NULL,
  last_seen_at DATETIME NULL,
  last_sync_at DATETIME NULL,
  app_version VARCHAR(32) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_device_uuid (device_uuid),
  KEY idx_sync_devices_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Server-side change log for incremental pull
CREATE TABLE IF NOT EXISTS sync_change_log (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  entity_type VARCHAR(64) NOT NULL,
  record_uuid VARCHAR(36) NOT NULL,
  operation ENUM('CREATE','UPDATE','DELETE') NOT NULL,
  payload_json LONGTEXT NULL,
  device_uuid VARCHAR(36) NULL,
  user_id INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_sync_log_cursor (id),
  KEY idx_sync_log_entity (entity_type, record_uuid),
  KEY idx_sync_log_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Conflict log
CREATE TABLE IF NOT EXISTS sync_conflicts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  entity_type VARCHAR(64) NOT NULL,
  record_uuid VARCHAR(36) NOT NULL,
  local_payload LONGTEXT NULL,
  remote_payload LONGTEXT NULL,
  resolution ENUM('pending','local_wins','remote_wins','merged','manual') NOT NULL DEFAULT 'pending',
  resolved_at DATETIME NULL,
  resolved_by INT NULL,
  notes TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_sync_conflicts_status (resolution),
  KEY idx_sync_conflicts_entity (entity_type, record_uuid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sync session / admin log
CREATE TABLE IF NOT EXISTS sync_sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  device_uuid VARCHAR(36) NOT NULL,
  user_id INT NULL,
  direction ENUM('push','pull','full') NOT NULL DEFAULT 'full',
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  records_uploaded INT UNSIGNED NOT NULL DEFAULT 0,
  records_downloaded INT UNSIGNED NOT NULL DEFAULT 0,
  records_failed INT UNSIGNED NOT NULL DEFAULT 0,
  conflicts INT UNSIGNED NOT NULL DEFAULT 0,
  status ENUM('running','completed','failed','partial') NOT NULL DEFAULT 'running',
  error_details TEXT NULL,
  KEY idx_sync_sessions_device (device_uuid),
  KEY idx_sync_sessions_started (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Processed operation ids for idempotency
CREATE TABLE IF NOT EXISTS sync_processed_ops (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  op_id VARCHAR(64) NOT NULL,
  device_uuid VARCHAR(36) NULL,
  entity_type VARCHAR(64) NULL,
  record_uuid VARCHAR(36) NULL,
  processed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_sync_op_id (op_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
