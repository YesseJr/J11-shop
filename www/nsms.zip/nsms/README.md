# NSMS — Nursery School Management System

Web application for nursery / pre-primary schools with **Admin**, **Teacher**, and **Parent** portals.

## Features

- Public landing page (school info, gallery, calendar, regulations)
- Admin: students, teachers, finance, attendance overview, promotions, settings, messaging
- Teacher: class attendance, gradebook, homework, reports, pulse messaging
- Parent: child attendance, fees, reports, daily diary, pulse messaging
- First-login password activation for teachers and parents

## Requirements

- PHP 7.4+ (8.x recommended) with PDO MySQL
- MySQL 5.7+ / 8.x or MariaDB
- Apache or Nginx (document root → `public/`)

## Quick setup

1. Create database and import schema:
   ```bash
   mysql -u root -p -e "CREATE DATABASE nsms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
   mysql -u root -p nsms < database/nsms.sql
   ```
   If you have a full dump (e.g. from phpMyAdmin), import that instead.

2. Configure database credentials via environment variables (preferred):
   ```bash
   export NSMS_DB_HOST=localhost
   export NSMS_DB_PORT=3306
   export NSMS_DB_NAME=nsms
   export NSMS_DB_USER=root
   export NSMS_DB_PASS=your_password
   ```
   Defaults in `includes/db.php` are for local XAMPP-style development only.

3. Point the web server document root at `public/`.
   API lives at `/nsms/api/` (or adjust paths if your virtual host maps differently).

4. Create the first admin via `public/setup.html` / `api/setup.php` if the database is empty.

5. Upload directories (ensure web-writable):
   - `public/uploads/admin|gallery|teachers|students|logos`
   - `uploads/messages|photos|resources|logos|avatars`

## Security notes

- Session cookies are `HttpOnly`, `SameSite=Lax`, and `Secure` when HTTPS is on.
- Wildcard CORS has been removed. Set `NSMS_CORS_ORIGIN` only if you need a separate frontend origin.
- Never commit production DB passwords or `.env` files.
- Force all users through password change on first login (`password_changed` flag).

## Project layout

```
api/           JSON API endpoints (role-checked)
includes/      db.php, auth.php, helpers.php, mail config
public/        Front-end (index + admin/teacher/parent portals)
database/      Schema and migration SQL files
uploads/       Non-public or shared upload storage
```

## Roles

| Role    | Entry                         | Main areas                          |
|---------|-------------------------------|-------------------------------------|
| Admin   | Sign in on landing page       | Dashboard, students, teachers, finance, settings |
| Teacher | Activate then Sign in         | Attendance, gradebook, reports, pulse |
| Parent  | Activate then Sign in         | Fees, attendance, reports, diary    |

## Known follow-ups (not auto-merged)

- Consolidate overlapping payment tables (`fee_payments` vs `payment_transactions`) after verifying live data.
- Normalize `homework_acknowledgements` / `homework_acknowledgments` naming.
- Add CSRF tokens to sensitive POSTs if you expose APIs cross-origin.
- Move large React pages to a build step when the team is ready.

## License

See LICENSE.


## CSRF protection

Mutating API requests (POST/PUT/DELETE) require header `X-CSRF-Token`.

- Token endpoint: `GET /nsms/api/auth.php?action=csrf`
- Frontend: `public/js/csrf.js` is included on all HTML pages and patches `fetch`
- Disable only in emergency: `NSMS_CSRF=0`

See `docs/LIVE_QA_CHECKLIST.md`, `docs/FINANCE_DESIGN.md`, `docs/BABEL_PILOT.md`.

## Frontend libraries (pinned)

React, ReactDOM, and Babel Standalone are **vendored** under `public/js/vendor/`
(see `VERSIONS.txt`). Pages must not load these from unpkg/CDN in production.

## Uploads

Use `nsmsStoreUpload()` in `includes/helpers.php` for new upload code.
Apache `.htaccess` under upload trees blocks script execution; Nginx needs
explicit rules — see `docs/UPLOADS_HARDENING.md`.

## Frontend build (no Babel in the browser)

```bash
cd nsms
npm install   # devDependency: @babel/core, @babel/preset-react
npm run build # writes public/js/built/**
npm run smoke # offline structure / syntax checks
```

HTML pages load precompiled scripts from `/nsms/public/js/built/`. Source JSX remains under `public/**/*.html` history and `public/includes/js/*-shared.js` for editing — re-run `npm run build` after changes.

## Password reset

- Self-service: Sign in → Forgot password → email with **one-time link** (`public/reset-password.html?token=…`), expires in 1 hour.
- Admin: Teachers / Students → Reset → same link flow.
- Schema: `database/password_reset_tokens.sql` (also auto-created on first use).

## Fee tables

See `docs/FEE_TABLES.md` — do not merge `fee_payments` and `payment_transactions` without a full data reconciliation.
