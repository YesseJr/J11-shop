-- ═══════════════════════════════════════════════════════════════════
-- NSMS Gradebook v2 — Database Migration
-- Run once. ALTER TABLE ADD COLUMN will error if column already
-- exists — that is safe to ignore.
-- ═══════════════════════════════════════════════════════════════════

-- 1. Widen assessment_type to accept new values
ALTER TABLE gradebook_assessments
  MODIFY COLUMN assessment_type VARCHAR(20) NOT NULL DEFAULT 'daily';

-- 2. Add period_label (ignore error if already exists)
ALTER TABLE gradebook_assessments
  ADD COLUMN period_label VARCHAR(60) NULL AFTER assessment_type;

-- 3. Remap old types → new types
UPDATE gradebook_assessments SET assessment_type = 'terminal' WHERE assessment_type IN ('exam');
UPDATE gradebook_assessments SET assessment_type = 'midterm'  WHERE assessment_type IN ('test');
UPDATE gradebook_assessments SET assessment_type = 'weekly'   WHERE assessment_type IN ('project');
UPDATE gradebook_assessments SET assessment_type = 'daily'
  WHERE assessment_type IN ('quiz','assignment','participation','other');

-- 4. Backfill period_label for existing rows
UPDATE gradebook_assessments SET period_label = term
  WHERE period_label IS NULL AND assessment_type = 'terminal';
UPDATE gradebook_assessments SET period_label = 'Midterm 1'
  WHERE period_label IS NULL AND assessment_type = 'midterm';
UPDATE gradebook_assessments
  SET period_label = COALESCE(DATE_FORMAT(assessment_date,'%a %d %b %Y'), 'Day 1')
  WHERE period_label IS NULL AND assessment_type = 'daily';
UPDATE gradebook_assessments SET period_label = 'Week 1'
  WHERE period_label IS NULL;

-- 5. New student_reports table (replaces weekly_reports for the new flow)
CREATE TABLE IF NOT EXISTS student_reports (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    student_id          INT NOT NULL,
    class_id            INT NOT NULL,
    teacher_id          INT NOT NULL,
    report_type         VARCHAR(20)  NOT NULL  COMMENT 'daily | weekly | midterm | terminal',
    period_label        VARCHAR(60)  NOT NULL  COMMENT 'e.g. Mon 21 Apr 2025 / Week 3 / Midterm 1 / Term 1',
    term                VARCHAR(20)  NOT NULL,
    academic_year       VARCHAR(20)  NOT NULL,
    report_date         DATE         NOT NULL,
    subject_data        TEXT         NULL      COMMENT 'JSON {subjectName:{avg_score,grade_letter,rating}}',
    conduct             VARCHAR(30)  NULL,
    punctuality         VARCHAR(30)  NULL,
    neatness            VARCHAR(30)  NULL,
    class_participation VARCHAR(30)  NULL,
    social_skills       VARCHAR(30)  NULL,
    teacher_comments    TEXT         NULL,
    recommendations     TEXT         NULL,
    promotion_status    VARCHAR(20)  NULL      COMMENT 'Terminal only: Promoted | Repeat | Under Review',
    is_draft            TINYINT(1)   NOT NULL DEFAULT 1,
    is_published        TINYINT(1)   NOT NULL DEFAULT 0,
    published_at        DATETIME     NULL,
    created_at          DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_student_report (student_id, report_type, period_label, term, academic_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
