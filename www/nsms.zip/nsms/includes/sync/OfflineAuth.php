<?php
/**
 * Secure offline authentication cache (SQLite).
 * - Never stores plaintext passwords
 * - Only caches after a successful online login
 * - Accounts that still require activation (password_changed=0) cannot log in offline
 */
class OfflineAuth {
    private static function store() {
        require_once __DIR__ . '/SyncConfig.php';
        require_once __DIR__ . '/SqliteStore.php';
        require_once __DIR__ . '/DeviceIdentity.php';
        $store = new SqliteStore();
        $pdo = $store->connect();
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS offline_users (
                user_id INTEGER PRIMARY KEY,
                uuid TEXT,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                full_name TEXT,
                role TEXT NOT NULL,
                phone TEXT,
                status TEXT DEFAULT 'active',
                password_changed INTEGER NOT NULL DEFAULT 1,
                photo_url TEXT,
                cached_at TEXT NOT NULL,
                last_login_at TEXT
            )"
        );
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_offline_users_email ON offline_users(email)");
        return $pdo;
    }

    /**
     * Cache a verified user after online login.
     * @param array $user Row from MySQL users (must include password_hash)
     */
    public static function cacheVerifiedUser(array $user) {
        try {
            if (empty($user['id']) || empty($user['email'])) return;
            $hash = '';
            if (!empty($user['password_hash'])) $hash = (string)$user['password_hash'];
            elseif (!empty($user['password'])) $hash = (string)$user['password'];
            if ($hash === '' || strlen($hash) < 20) return; // refuse non-hash values

            $changed = 1;
            if (isset($user['password_changed']) && $user['password_changed'] !== null && $user['password_changed'] !== '') {
                $changed = (int)$user['password_changed'];
            }
            // Do not cache accounts that still need first-time activation
            if ($changed === 0) return;

            $status = isset($user['status']) ? strtolower(trim((string)$user['status'])) : 'active';
            if ($status !== '' && $status !== 'active') return;

            $pdo = self::store();
            $st = $pdo->prepare(
                "INSERT INTO offline_users
                    (user_id, uuid, email, password_hash, full_name, role, phone, status, password_changed, photo_url, cached_at, last_login_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                 ON CONFLICT(user_id) DO UPDATE SET
                    email=excluded.email,
                    password_hash=excluded.password_hash,
                    full_name=excluded.full_name,
                    role=excluded.role,
                    phone=excluded.phone,
                    status=excluded.status,
                    password_changed=excluded.password_changed,
                    photo_url=excluded.photo_url,
                    cached_at=excluded.cached_at,
                    last_login_at=excluded.last_login_at"
            );
            $email = strtolower(trim((string)$user['email']));
            $st->execute(array(
                (int)$user['id'],
                isset($user['uuid']) ? $user['uuid'] : null,
                $email,
                $hash,
                isset($user['full_name']) ? $user['full_name'] : null,
                isset($user['role']) ? $user['role'] : 'parent',
                isset($user['phone']) ? $user['phone'] : null,
                $status ?: 'active',
                $changed,
                isset($user['photo_url']) ? $user['photo_url'] : null,
                date('c'),
                date('c'),
            ));
        } catch (Exception $e) {
            error_log('OfflineAuth::cacheVerifiedUser: ' . $e->getMessage());
        }
    }

    /**
     * Attempt offline login. Returns user array or null.
     * Sets $error by reference for caller messaging.
     */
    public static function attemptLogin($email, $password, &$error = null) {
        $error = null;
        try {
            $email = strtolower(trim((string)$email));
            if ($email === '' || $password === '') {
                $error = 'Email and password are required';
                return null;
            }
            $pdo = self::store();
            $st = $pdo->prepare('SELECT * FROM offline_users WHERE email = ? LIMIT 1');
            $st->execute(array($email));
            $row = $st->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                $n = 0;
                try { $n = (int)$pdo->query('SELECT COUNT(*) FROM offline_users')->fetchColumn(); } catch (Exception $e) {}
                if ($n < 1) {
                    $error = 'Offline login is not prepared yet. Start MySQL, sign in once online, or open Admin → Synchronization and click “Prepare offline logins”.';
                } else {
                    $error = 'Invalid email or password (offline), or this account was never prepared for offline access.';
                }
                return null;
            }
            if ((int)$row['password_changed'] === 0) {
                $error = 'This account must be activated online before offline login is available.';
                return null;
            }
            $status = strtolower(trim((string)$row['status']));
            if ($status !== '' && $status !== 'active') {
                $error = 'This account is not active.';
                return null;
            }
            if (!function_exists('verifyPassword')) {
                // fallback
                if (!password_verify($password, $row['password_hash'])) {
                    $error = 'Invalid email or password';
                    return null;
                }
            } else {
                if (!verifyPassword($password, $row['password_hash'])) {
                    $error = 'Invalid email or password';
                    return null;
                }
            }
            $pdo->prepare('UPDATE offline_users SET last_login_at = ? WHERE user_id = ?')
                ->execute(array(date('c'), (int)$row['user_id']));

            return array(
                'id' => (int)$row['user_id'],
                'email' => $row['email'],
                'full_name' => $row['full_name'],
                'role' => $row['role'],
                'phone' => $row['phone'],
                'status' => $row['status'],
                'password_changed' => (int)$row['password_changed'],
                'photo_url' => $row['photo_url'],
                'uuid' => $row['uuid'],
                'offline' => true,
            );
        } catch (Exception $e) {
            error_log('OfflineAuth::attemptLogin: ' . $e->getMessage());
            $error = 'Offline authentication unavailable';
            return null;
        }
    }

    public static function revoke($userId) {
        try {
            $pdo = self::store();
            $pdo->prepare('DELETE FROM offline_users WHERE user_id = ?')->execute(array((int)$userId));
        } catch (Exception $e) {}
    }

    public static function countCached() {
        try {
            $pdo = self::store();
            return (int)$pdo->query('SELECT COUNT(*) FROM offline_users')->fetchColumn();
        } catch (Exception $e) {
            return 0;
        }
    }

    /**
     * Admin/online: copy activated users from MySQL into SQLite offline cache.
     * Only password hashes (never plaintext). Skips password_changed=0.
     * @param Database $db
     * @return array{ok:bool,cached:int,skipped:int,error?:string}
     */
    public static function warmFromMysql($db) {
        try {
            if (!class_exists('PDO') || !in_array('sqlite', PDO::getAvailableDrivers(), true)) {
                return array('ok' => false, 'cached' => 0, 'skipped' => 0, 'error' => 'PHP PDO SQLite extension is not enabled (enable extension=pdo_sqlite)');
            }
            // Detect optional columns safely
            $hasChanged = false;
            $hasStatus = false;
            try {
                $cols = $db->query("SHOW COLUMNS FROM users");
                if (is_array($cols)) {
                    foreach ($cols as $c) {
                        $f = isset($c['Field']) ? $c['Field'] : (isset($c['field']) ? $c['field'] : '');
                        if ($f === 'password_changed') $hasChanged = true;
                        if ($f === 'status') $hasStatus = true;
                    }
                }
            } catch (Exception $e) {}

            $sql = "SELECT id, email, password_hash, full_name, role, phone";
            if ($hasStatus) $sql .= ", status";
            if ($hasChanged) $sql .= ", password_changed";
            $sql .= " FROM users";
            if ($hasStatus) {
                $sql .= " WHERE (status = 'active' OR status IS NULL OR status = '')";
            }

            $rows = $db->query($sql);
            if ($rows === false) {
                return array('ok' => false, 'cached' => 0, 'skipped' => 0, 'error' => 'Could not read users table — check PHP error log');
            }
            if (!is_array($rows)) $rows = array();

            $cached = 0;
            $skipped = 0;
            $skippedReasons = array('not_activated' => 0, 'bad_hash' => 0, 'no_email' => 0);
            $samples = array();

            foreach ($rows as $row) {
                if (empty($row['email'])) { $skipped++; $skippedReasons['no_email']++; continue; }

                $changed = 1;
                if ($hasChanged && isset($row['password_changed']) && $row['password_changed'] !== null && $row['password_changed'] !== '') {
                    $changed = (int)$row['password_changed'];
                }
                // Admins are always eligible; others need activation completed
                $role = isset($row['role']) ? $row['role'] : '';
                if ($changed === 0 && $role !== 'admin') {
                    $skipped++;
                    $skippedReasons['not_activated']++;
                    continue;
                }

                $hash = !empty($row['password_hash']) ? (string)$row['password_hash'] : '';
                if ($hash === '' || strlen($hash) < 20) {
                    $skipped++;
                    $skippedReasons['bad_hash']++;
                    continue;
                }

                $row['password_hash'] = $hash;
                $row['password_changed'] = ($role === 'admin') ? max(1, $changed) : $changed;
                if ($role === 'admin') {
                    $row['password_changed'] = 1; // allow offline for admin
                }
                self::cacheVerifiedUser($row);
                $cached++;
                if (count($samples) < 5) {
                    $samples[] = $row['email'];
                }
            }

            // Verify write
            $verify = self::countCached();
            return array(
                'ok' => true,
                'cached' => $cached,
                'skipped' => $skipped,
                'skipped_detail' => $skippedReasons,
                'sqlite_count' => $verify,
                'sample_emails' => $samples,
                'sqlite' => self::sqliteReady(),
            );
        } catch (Exception $e) {
            error_log('OfflineAuth::warmFromMysql: ' . $e->getMessage());
            return array('ok' => false, 'cached' => 0, 'skipped' => 0, 'error' => $e->getMessage());
        }
    }

    public static function sqliteReady() {
        try {
            if (!class_exists('PDO') || !in_array('sqlite', PDO::getAvailableDrivers(), true)) {
                return array('ok' => false, 'detail' => 'pdo_sqlite missing');
            }
            $pdo = self::store();
            $path = SyncConfig::sqlitePath();
            return array(
                'ok' => true,
                'detail' => 'ready',
                'path' => $path,
                'writable' => is_writable(dirname($path)) || is_writable($path),
                'cached_users' => (int)$pdo->query('SELECT COUNT(*) FROM offline_users')->fetchColumn(),
            );
        } catch (Exception $e) {
            return array('ok' => false, 'detail' => $e->getMessage());
        }
    }

    /** Establish PHP session from offline user row */
    public static function establishSession(array $user) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['role'] = strtolower(trim((string)$user['role']));
        $_SESSION['email'] = $user['email'];
        $_SESSION['full_name'] = isset($user['full_name']) ? $user['full_name'] : '';
        $_SESSION['offline_mode'] = true;
        $_SESSION['login_at'] = date('c');
        if (function_exists('ensureCsrfToken')) {
            ensureCsrfToken();
        }
    }
}
