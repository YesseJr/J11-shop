<?php
/**
 * Read/write helpers for offline SQLite data used when MySQL is down.
 */
class OfflineData {
    private static function pdo() {
        require_once __DIR__ . '/SyncConfig.php';
        require_once __DIR__ . '/SqliteStore.php';
        $store = new SqliteStore();
        return $store->connect();
    }

    /** Snapshot active students + classes from MySQL into SQLite */
    public static function warmRosterFromMysql($db) {
        $pdo = self::pdo();
        // Ensure class colour columns exist locally
        foreach (array('class_color TEXT', 'sort_order INTEGER', 'minimum_age INTEGER', 'capacity INTEGER', 'teacher_id INTEGER') as $def) {
            try { $pdo->exec('ALTER TABLE classes ADD COLUMN ' . $def); } catch (Exception $e) {}
        }
        $classes = $db->query("SELECT id, class_name, capacity, teacher_id, class_color, sort_order, minimum_age FROM classes");
        if ($classes === false) {
            $classes = $db->query("SELECT id, class_name, capacity, teacher_id FROM classes") ?: array();
        }
        if (!is_array($classes)) $classes = array();
        $palette = array('#2563EB','#10B981','#8B5CF6','#F59E0B','#EF4444','#06B6D4','#EC4899','#84CC16','#F97316','#6366F1');
        $nC = 0;
        foreach ($classes as $i => $c) {
            $uuid = null;
            try {
                if (class_exists('SyncHooks')) {
                    $uuid = SyncHooks::ensureRecordUuid($db, 'classes', (int)$c['id']);
                }
            } catch (Exception $e) {}
            if (!$uuid) $uuid = 'class-' . (int)$c['id'];
            $color = isset($c['class_color']) && $c['class_color'] ? $c['class_color'] : $palette[$i % count($palette)];
            $st = $pdo->prepare(
                "INSERT INTO classes (id, uuid, class_name, capacity, teacher_id, class_color, sort_order, minimum_age, updated_at, sync_version)
                 VALUES (?,?,?,?,?,?,?,?,?,1)
                 ON CONFLICT(id) DO UPDATE SET
                   class_name=excluded.class_name,
                   capacity=excluded.capacity,
                   teacher_id=excluded.teacher_id,
                   class_color=excluded.class_color,
                   sort_order=excluded.sort_order,
                   minimum_age=excluded.minimum_age,
                   updated_at=excluded.updated_at"
            );
            try {
                $st->execute(array(
                    (int)$c['id'], $uuid, $c['class_name'],
                    isset($c['capacity']) ? $c['capacity'] : null,
                    isset($c['teacher_id']) ? $c['teacher_id'] : null,
                    $color,
                    isset($c['sort_order']) ? $c['sort_order'] : null,
                    isset($c['minimum_age']) ? $c['minimum_age'] : null,
                    date('c'),
                ));
            } catch (Exception $e) {
                // older schema without extra cols
                $st2 = $pdo->prepare(
                    "INSERT INTO classes (id, uuid, class_name, capacity, teacher_id, updated_at, sync_version)
                     VALUES (?,?,?,?,?,?,1)
                     ON CONFLICT(id) DO UPDATE SET class_name=excluded.class_name, capacity=excluded.capacity, teacher_id=excluded.teacher_id, updated_at=excluded.updated_at"
                );
                $st2->execute(array((int)$c['id'], $uuid, $c['class_name'], isset($c['capacity']) ? $c['capacity'] : null, isset($c['teacher_id']) ? $c['teacher_id'] : null, date('c')));
                try {
                    $pdo->prepare("UPDATE classes SET class_color = ? WHERE id = ?")->execute(array($color, (int)$c['id']));
                } catch (Exception $e2) {}
            }
            $nC++;
        }
        // Prune classes removed from MySQL (or never present) — keep local pending creates (id < 0)
        try {
            $alive = array();
            foreach ($classes as $c) {
                $alive[] = (int)$c['id'];
            }
            if ($alive) {
                $ph = implode(',', array_fill(0, count($alive), '?'));
                $pdo->prepare("DELETE FROM classes WHERE id > 0 AND id NOT IN ($ph)")->execute($alive);
            } else {
                $pdo->exec("DELETE FROM classes WHERE id > 0");
            }
            // Clear soft-deleted ghosts
            try { $pdo->exec("DELETE FROM classes WHERE deleted_at IS NOT NULL AND deleted_at != ''"); } catch (Exception $e) {}
        } catch (Exception $e) {
            error_log('prune classes: ' . $e->getMessage());
        }

        $students = $db->query(
            "SELECT s.id, s.student_name, s.class_id, s.gender, s.date_of_birth, s.status,
                    s.address, s.enrollment_date, s.photo_url,
                    u.full_name AS parent_name, u.phone AS parent_phone, u.email AS parent_email,
                    p.relationship AS parent_relationship
               FROM students s
          LEFT JOIN parents p ON p.student_id = s.id
          LEFT JOIN users u ON u.id = p.user_id"
        );
        if ($students === false) {
            // Alternate: parent linked via students.parent_id
            $students = $db->query(
                "SELECT s.id, s.student_name, s.class_id, s.gender, s.date_of_birth, s.status,
                        s.address, s.enrollment_date, s.photo_url,
                        u.full_name AS parent_name, u.phone AS parent_phone, u.email AS parent_email,
                        NULL AS parent_relationship
                   FROM students s
              LEFT JOIN users u ON u.id = s.parent_id"
            );
        }
        if ($students === false) {
            $students = $db->query(
                "SELECT id, student_name, class_id, gender, date_of_birth, status, address, enrollment_date, photo_url FROM students"
            ) ?: array();
        }
        // Secondary fill: any row still missing parent_name
        if (is_array($students)) {
            foreach ($students as &$srow) {
                if (!empty($srow['parent_name'])) continue;
                $sid = (int)$srow['id'];
                $p = $db->queryOne(
                    "SELECT u.full_name, u.phone, u.email, p.relationship
                       FROM parents p JOIN users u ON u.id = p.user_id
                      WHERE p.student_id = ? LIMIT 1",
                    array($sid)
                );
                if (!$p) {
                    $p = $db->queryOne(
                        "SELECT full_name, phone, email FROM users WHERE id = (SELECT parent_id FROM students WHERE id = ? LIMIT 1) LIMIT 1",
                        array($sid)
                    );
                }
                if ($p) {
                    $srow['parent_name'] = isset($p['full_name']) ? $p['full_name'] : (isset($p['parent_name']) ? $p['parent_name'] : null);
                    $srow['parent_phone'] = isset($p['phone']) ? $p['phone'] : null;
                    $srow['parent_email'] = isset($p['email']) ? $p['email'] : null;
                    if (isset($p['relationship'])) $srow['parent_relationship'] = $p['relationship'];
                }
            }
            unset($srow);
        }
        $nS = 0;
        foreach ($students as $s) {
            $uuid = null;
            try {
                if (class_exists('SyncHooks')) {
                    $uuid = SyncHooks::ensureRecordUuid($db, 'students', (int)$s['id']);
                }
            } catch (Exception $e) {}
            if (!$uuid) $uuid = 'student-' . (int)$s['id'];
            try {
                $pdo->exec("ALTER TABLE students ADD COLUMN address TEXT");
            } catch (Exception $e) {}
            foreach (array('enrollment_date','photo_url','parent_name','parent_phone','parent_email','parent_relationship','sync_status') as $c) {
                try { $pdo->exec("ALTER TABLE students ADD COLUMN $c TEXT"); } catch (Exception $e) {}
            }
            $st = $pdo->prepare(
                "INSERT INTO students (id, uuid, student_name, class_id, gender, date_of_birth, status,
                    address, enrollment_date, photo_url, parent_name, parent_phone, parent_email, parent_relationship,
                    updated_at, sync_version, sync_status)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,'synced')
                 ON CONFLICT(id) DO UPDATE SET
                   student_name=excluded.student_name,
                   class_id=excluded.class_id,
                   gender=excluded.gender,
                   date_of_birth=excluded.date_of_birth,
                   status=excluded.status,
                   address=excluded.address,
                   enrollment_date=excluded.enrollment_date,
                   photo_url=excluded.photo_url,
                   parent_name=excluded.parent_name,
                   parent_phone=excluded.parent_phone,
                   parent_email=excluded.parent_email,
                   parent_relationship=excluded.parent_relationship,
                   updated_at=excluded.updated_at"
            );
            $st->execute(array(
                (int)$s['id'],
                $uuid,
                $s['student_name'],
                $s['class_id'],
                isset($s['gender']) ? $s['gender'] : null,
                isset($s['date_of_birth']) ? $s['date_of_birth'] : null,
                isset($s['status']) && $s['status'] ? $s['status'] : 'active',
                isset($s['address']) ? $s['address'] : null,
                isset($s['enrollment_date']) ? $s['enrollment_date'] : null,
                isset($s['photo_url']) ? $s['photo_url'] : null,
                isset($s['parent_name']) ? $s['parent_name'] : null,
                isset($s['parent_phone']) ? $s['parent_phone'] : null,
                isset($s['parent_email']) ? $s['parent_email'] : null,
                isset($s['parent_relationship']) ? $s['parent_relationship'] : null,
                date('c'),
            ));
            $nS++;
        }
        $deduped = 0;
        try { $deduped = self::dedupeStudents(); } catch (Exception $e) {}
        return array('classes' => $nC, 'students' => $nS, 'deduped' => $deduped);
    }


    /**
     * Remove offline shadow rows that duplicate a synced MySQL student
     * (same name + class, one local negative id + one positive id).
     */
    public static function dedupeStudents() {
        $pdo = self::pdo();
        // Ensure columns
        foreach (array('parent_name TEXT', 'parent_phone TEXT', 'sync_status TEXT') as $def) {
            try { $pdo->exec('ALTER TABLE students ADD COLUMN ' . $def); } catch (Exception $e) {}
        }
        $rows = $pdo->query(
            "SELECT id, uuid, student_name, class_id, parent_name, parent_phone, sync_status, status
               FROM students
              WHERE deleted_at IS NULL OR deleted_at = '' OR deleted_at = 0"
        )->fetchAll(PDO::FETCH_ASSOC);
        $groups = array();
        foreach ($rows as $r) {
            $key = strtolower(trim($r['student_name'])) . '|' . (int)$r['class_id'];
            if (!isset($groups[$key])) $groups[$key] = array();
            $groups[$key][] = $r;
        }
        $removed = 0;
        foreach ($groups as $key => $list) {
            if (count($list) < 2) continue;
            // Prefer positive id, then has parent, then synced
            usort($list, function ($a, $b) {
                $ap = (int)$a['id'] > 0 ? 1 : 0;
                $bp = (int)$b['id'] > 0 ? 1 : 0;
                if ($ap !== $bp) return $bp - $ap;
                $apa = !empty($a['parent_name']) ? 1 : 0;
                $bpb = !empty($b['parent_name']) ? 1 : 0;
                if ($apa !== $bpb) return $bpb - $apa;
                $as = (isset($a['sync_status']) && $a['sync_status'] === 'synced') ? 1 : 0;
                $bs = (isset($b['sync_status']) && $b['sync_status'] === 'synced') ? 1 : 0;
                return $bs - $as;
            });
            $keep = $list[0];
            // Merge parent info onto keeper if missing
            for ($i = 1; $i < count($list); $i++) {
                $drop = $list[$i];
                if (empty($keep['parent_name']) && !empty($drop['parent_name'])) {
                    try {
                        $pdo->prepare(
                            "UPDATE students SET parent_name=?, parent_phone=?, parent_email=COALESCE(parent_email, ?), parent_relationship=COALESCE(parent_relationship, ?) WHERE id=?"
                        )->execute(array(
                            $drop['parent_name'],
                            isset($drop['parent_phone']) ? $drop['parent_phone'] : null,
                            isset($drop['parent_email']) ? $drop['parent_email'] : null,
                            isset($drop['parent_relationship']) ? $drop['parent_relationship'] : null,
                            (int)$keep['id'],
                        ));
                    } catch (Exception $e) {}
                }
                // Soft-delete or hard-delete shadow row
                try {
                    $pdo->prepare("UPDATE students SET deleted_at = ?, sync_status = 'duplicate' WHERE id = ?")
                        ->execute(array(date('c'), (int)$drop['id']));
                } catch (Exception $e) {
                    try {
                        $pdo->prepare("DELETE FROM students WHERE id = ?")->execute(array((int)$drop['id']));
                    } catch (Exception $e2) {}
                }
                // Cancel pending queue ops for dropped uuid
                if (!empty($drop['uuid'])) {
                    try {
                        $pdo->prepare(
                            "UPDATE sync_queue SET status = 'synced', error_message = 'deduped' WHERE record_uuid = ? AND status IN ('pending','failed')"
                        )->execute(array($drop['uuid']));
                    } catch (Exception $e) {}
                }
                $removed++;
            }
        }
        return $removed;
    }


    /**
     * Offline-only students (negative id or sync_status=pending) that have no
     * pending queue row must be re-enqueued so they can appear in MySQL.
     */
    public static function requeueOrphanStudents() {
        $pdo = self::pdo();
        require_once __DIR__ . '/SqliteStore.php';
        $store = new SqliteStore();
        $store->connect();
        // Only true offline-created rows (negative local ids). Never re-push positive MySQL ids.
        $rows = $pdo->query(
            "SELECT * FROM students
              WHERE (deleted_at IS NULL OR deleted_at = '')
                AND id < 0"
        )->fetchAll(PDO::FETCH_ASSOC);
        $queued = 0;
        foreach ($rows as $r) {
            $uuid = isset($r['uuid']) && $r['uuid'] !== '' ? $r['uuid'] : null;
            if (!$uuid) {
                // generate and persist
                require_once __DIR__ . '/DeviceIdentity.php';
                $uuid = DeviceIdentity::generateUuid();
                try {
                    $pdo->prepare('UPDATE students SET uuid = ? WHERE id = ?')->execute(array($uuid, (int)$r['id']));
                } catch (Exception $e) {}
            }
            // Already pending in queue?
            $st = $pdo->prepare(
                "SELECT id FROM sync_queue WHERE record_uuid = ? AND status IN ('pending','failed') LIMIT 1"
            );
            $st->execute(array($uuid));
            if ($st->fetch()) {
                continue;
            }
            $payload = array(
                'uuid' => $uuid,
                'student_name' => $r['student_name'],
                'class_id' => isset($r['class_id']) ? (int)$r['class_id'] : null,
                'gender' => isset($r['gender']) ? $r['gender'] : 'Male',
                'date_of_birth' => isset($r['date_of_birth']) ? $r['date_of_birth'] : null,
                'enrollment_date' => isset($r['enrollment_date']) ? $r['enrollment_date'] : date('Y-m-d'),
                'address' => isset($r['address']) ? $r['address'] : null,
                'status' => isset($r['status']) ? $r['status'] : 'active',
                'parent_name' => isset($r['parent_name']) ? $r['parent_name'] : null,
                'parent_phone' => isset($r['parent_phone']) ? $r['parent_phone'] : null,
                'parent_email' => isset($r['parent_email']) ? $r['parent_email'] : null,
                'parent_relationship' => isset($r['parent_relationship']) ? $r['parent_relationship'] : null,
                'local_id' => (int)$r['id'],
            );
            $op = ((int)$r['id'] > 0) ? 'UPDATE' : 'CREATE';
            // If positive id exists only offline with pending, still CREATE on server if no MySQL twin —
            // local negative ids always CREATE
            if ((int)$r['id'] < 0) $op = 'CREATE';
            $store->enqueue('students', $uuid, $op, $payload);
            try {
                $pdo->prepare("UPDATE students SET sync_status = 'pending' WHERE id = ?")->execute(array((int)$r['id']));
            } catch (Exception $e) {}
            $queued++;
        }
        return $queued;
    }

    public static function listStudents($status = 'active', $classId = null) {
        $pdo = self::pdo();
        try { self::dedupeStudents(); } catch (Exception $e) {}
        $sql = "SELECT s.id, s.uuid, s.student_name, s.class_id, s.gender, s.date_of_birth, s.status,
                       s.address, s.enrollment_date, s.photo_url,
                       s.parent_name, s.parent_phone, s.parent_email, s.parent_relationship,
                       c.class_name, c.class_color,
                       s.sync_status
                  FROM students s
             LEFT JOIN classes c ON c.id = s.class_id
                 WHERE (s.deleted_at IS NULL OR s.deleted_at = '')";
        $params = array();
        if ($status && $status !== 'all') {
            if ($status === 'former') {
                $sql .= " AND s.status IN ('transferred','withdrawn','graduated','suspended')";
            } else {
                $sql .= " AND (s.status = ? OR (s.status IS NULL AND ? = 'active'))";
                $params[] = $status;
                $params[] = $status;
            }
        }
        if ($classId) {
            $sql .= " AND CAST(s.class_id AS INTEGER) = ?";
            $params[] = (int)$classId;
        }
        $sql .= " AND (s.sync_status IS NULL OR s.sync_status = '' OR s.sync_status = 'synced' OR s.sync_status = 'pending')";
        $sql .= " AND (s.id IS NULL OR s.id > 0)";
        $sql .= " ORDER BY s.student_name ASC";
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $palette = array('#2563EB','#10B981','#8B5CF6','#F59E0B','#EF4444','#06B6D4','#EC4899','#84CC16','#F97316','#6366F1');
        // Map class colours if join missed them
        $colorByClass = array();
        try {
            foreach ($pdo->query("SELECT id, class_color, class_name FROM classes") as $c) {
                $colorByClass[(int)$c['id']] = $c['class_color'] ?: null;
            }
        } catch (Exception $e) {}
        foreach ($rows as $i => &$r) {
            $cid = isset($r['class_id']) ? (int)$r['class_id'] : 0;
            if (empty($r['class_color'])) {
                if ($cid && !empty($colorByClass[$cid])) {
                    $r['class_color'] = $colorByClass[$cid];
                } else {
                    $r['class_color'] = $palette[$cid > 0 ? ($cid % count($palette)) : ($i % count($palette))];
                }
            }
            // Normalize empty parent strings to null for UI dashes
            foreach (array('parent_name','parent_phone','parent_email') as $k) {
                if (isset($r[$k]) && trim((string)$r[$k]) === '') $r[$k] = null;
            }
        }
        unset($r);
        return $rows;
    }

    public static function statusCounts() {
        $pdo = self::pdo();
        $rows = $pdo->query("SELECT status, COUNT(*) AS c FROM students WHERE deleted_at IS NULL OR deleted_at = '' GROUP BY status")->fetchAll(PDO::FETCH_ASSOC);
        $out = array('active' => 0, 'transferred' => 0, 'withdrawn' => 0, 'graduated' => 0, 'suspended' => 0, 'former' => 0, 'all' => 0);
        foreach ($rows as $r) {
            $st = $r['status'] ?: 'active';
            $n = (int)$r['c'];
            if (isset($out[$st])) $out[$st] += $n;
            $out['all'] += $n;
            if (in_array($st, array('transferred','withdrawn','graduated','suspended'), true)) {
                $out['former'] += $n;
            }
        }
        return $out;
    }

    public static function dashboardSummary() {
        $pdo = self::pdo();
        $students = 0;
        $classes = 0;
        $teachers = 0;
        $avgAtt = 0;
        try {
            $students = (int)$pdo->query(
                "SELECT COUNT(*) FROM students WHERE (deleted_at IS NULL OR deleted_at='') AND (status='active' OR status IS NULL OR status='')"
            )->fetchColumn();
        } catch (Exception $e) {}
        try {
            $classes = (int)$pdo->query(
                "SELECT COUNT(*) FROM classes WHERE deleted_at IS NULL OR deleted_at=''"
            )->fetchColumn();
        } catch (Exception $e) {}
        try {
            $teachers = (int)$pdo->query("SELECT COUNT(*) FROM teachers_cache")->fetchColumn();
        } catch (Exception $e) {
            try {
                // fallback: count distinct teacher_id on classes
                $teachers = (int)$pdo->query(
                    "SELECT COUNT(DISTINCT teacher_id) FROM classes WHERE teacher_id IS NOT NULL AND teacher_id != 0"
                )->fetchColumn();
            } catch (Exception $e2) {}
        }
        try {
            $row = $pdo->query(
                "SELECT
                    SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present,
                    COUNT(*) AS total
                   FROM attendance
                  WHERE attendance_date >= date('now', '-30 days')"
            )->fetch(PDO::FETCH_ASSOC);
            if ($row && (int)$row['total'] > 0) {
                $avgAtt = round(((int)$row['present'] / (int)$row['total']) * 100, 1);
            }
        } catch (Exception $e) {}

        return array(
            'total_students' => $students,
            'students_this_month' => 0,
            'period_days' => 30,
            'total_teachers' => $teachers,
            'total_classes' => $classes,
            'avg_attendance' => $avgAtt,
            'fee_collection_rate' => null,
            'collected_amount' => null,
            'expected_revenue' => null,
            'enrollment_growth' => 0,
            'offline_mode' => true,
            'message' => 'Offline mode — showing cached school data from SQLite.',
        );
    }

    public static function financeOverviewOffline() {
        return array(
            'total_revenue' => 0,
            'pending_amount' => 0,
            'collected_amount' => 0,
            'expected_amount' => 0,
            'fee_collection_rate' => 0,
            'offline_mode' => true,
            'message' => 'Finance figures require MySQL. Offline cache does not store payment ledgers.',
        );
    }

    public static function enrollmentTrendsOffline() {
        // Empty series — UI already handles empty trends
        return array();
    }

    public static function recentActivityOffline() {
        return array(
            array(
                'type' => 'system',
                'title' => 'Working offline',
                'description' => 'Dashboard is using the local SQLite cache. Start MySQL to refresh live analytics and finance.',
                'created_at' => date('c'),
            ),
        );
    }

    /** Queue attendance marks offline */
    public static function queueAttendance($classId, $date, $records, $userId) {
        require_once __DIR__ . '/SqliteStore.php';
        require_once __DIR__ . '/DeviceIdentity.php';
        $store = new SqliteStore();
        $pdo = $store->connect();
        $queued = 0;
        foreach ($records as $rec) {
            $sid = isset($rec['student_id']) ? (int)$rec['student_id'] : 0;
            if ($sid < 1) continue;
            $status = isset($rec['status']) ? $rec['status'] : 'present';
            $payload = array(
                'student_id' => $sid,
                'class_id' => (int)$classId,
                'attendance_date' => $date,
                'status' => $status,
                'late_minutes' => isset($rec['late_minutes']) ? $rec['late_minutes'] : null,
                'recorded_by' => $userId,
            );
            $uuid = 'att-' . $sid . '-' . $date;
            // local mirror
            $st = $pdo->prepare(
                "INSERT INTO attendance (uuid, student_id, class_id, attendance_date, status, recorded_by, updated_at, sync_version)
                 VALUES (?,?,?,?,?,?,?,1)
                 ON CONFLICT(uuid) DO UPDATE SET status=excluded.status, updated_at=excluded.updated_at"
            );
            try {
                $st->execute(array($uuid, $sid, (int)$classId, $date, $status, $userId, date('c')));
            } catch (Exception $e) {
                // if no unique on uuid, try insert only
                try {
                    $pdo->prepare(
                        "INSERT INTO attendance (uuid, student_id, class_id, attendance_date, status, recorded_by, updated_at, sync_version)
                         VALUES (?,?,?,?,?,?,?,1)"
                    )->execute(array($uuid, $sid, (int)$classId, $date, $status, $userId, date('c')));
                } catch (Exception $e2) {}
            }
            $store->enqueue('attendance', $uuid, 'UPDATE', $payload);
            $queued++;
        }
        return $queued;
    }

    public static function warmTeachersFromMysql($db) {
        $pdo = self::pdo();
        $pdo->exec("CREATE TABLE IF NOT EXISTS teachers_cache (
            id INTEGER PRIMARY KEY,
            user_id INTEGER,
            full_name TEXT,
            email TEXT,
            phone TEXT,
            status TEXT,
            photo_url TEXT,
            class_id INTEGER,
            class_name TEXT,
            class_color TEXT,
            subjects TEXT,
            subject_ids TEXT,
            uuid TEXT,
            sync_status TEXT DEFAULT 'synced',
            updated_at TEXT
        )");
        foreach (array(
            'photo_url TEXT', 'class_id INTEGER', 'class_name TEXT', 'class_color TEXT',
            'subjects TEXT', 'subject_ids TEXT', 'uuid TEXT', "sync_status TEXT DEFAULT 'synced'"
        ) as $def) {
            try { $pdo->exec('ALTER TABLE teachers_cache ADD COLUMN ' . $def); } catch (Exception $e) {}
        }
        $sql = "SELECT u.id, u.email, u.full_name, u.phone, u.status, u.photo_url,
                       c.id AS class_id, c.class_name, c.class_color,
                       GROUP_CONCAT(DISTINCT s.subject_name ORDER BY s.subject_name SEPARATOR ', ') AS subjects,
                       GROUP_CONCAT(DISTINCT ts.subject_id ORDER BY ts.subject_id SEPARATOR ',') AS subject_ids
                  FROM users u
             LEFT JOIN classes c ON c.teacher_id = u.id
             LEFT JOIN teacher_subjects ts ON ts.teacher_id = u.id
             LEFT JOIN subjects s ON s.id = ts.subject_id
                 WHERE u.role = 'teacher'
              GROUP BY u.id, u.email, u.full_name, u.phone, u.status, u.photo_url, c.id, c.class_name, c.class_color";
        $teachers = $db->query($sql);
        if ($teachers === false) {
            $teachers = $db->query(
                "SELECT id, email, full_name, phone, status, photo_url FROM users WHERE role = 'teacher'"
            ) ?: array();
        }
        $n = 0;
        foreach ($teachers as $r) {
            $uuid = null;
            try {
                if (class_exists('SyncHooks')) {
                    $uuid = SyncHooks::ensureRecordUuid($db, 'users', (int)$r['id']);
                }
            } catch (Exception $e) {}
            if (!$uuid) $uuid = 'user-' . (int)$r['id'];
            $st = $pdo->prepare(
                "INSERT INTO teachers_cache (id, user_id, full_name, email, phone, status, photo_url, class_id, class_name, class_color, subjects, subject_ids, uuid, sync_status, updated_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, 'synced', ?)
                 ON CONFLICT(id) DO UPDATE SET
                   full_name=excluded.full_name,
                   email=excluded.email,
                   phone=excluded.phone,
                   status=excluded.status,
                   photo_url=excluded.photo_url,
                   class_id=excluded.class_id,
                   class_name=excluded.class_name,
                   class_color=excluded.class_color,
                   subjects=excluded.subjects,
                   subject_ids=excluded.subject_ids,
                   uuid=excluded.uuid,
                   sync_status='synced',
                   updated_at=excluded.updated_at"
            );
            $st->execute(array(
                (int)$r['id'],
                (int)$r['id'],
                isset($r['full_name']) ? $r['full_name'] : null,
                isset($r['email']) ? $r['email'] : null,
                isset($r['phone']) ? $r['phone'] : null,
                isset($r['status']) ? $r['status'] : 'active',
                isset($r['photo_url']) ? $r['photo_url'] : null,
                isset($r['class_id']) ? $r['class_id'] : null,
                isset($r['class_name']) ? $r['class_name'] : null,
                isset($r['class_color']) ? $r['class_color'] : null,
                isset($r['subjects']) ? $r['subjects'] : null,
                isset($r['subject_ids']) ? $r['subject_ids'] : null,
                $uuid,
                date('c'),
            ));
            $n++;
        }
        // Drop offline shadows that duplicate email of synced teachers
        try {
            $pdo->exec(
                "UPDATE teachers_cache SET status = 'inactive', sync_status = 'duplicate'
                  WHERE id < 0 AND lower(email) IN (SELECT lower(email) FROM teachers_cache WHERE id > 0)"
            );
        } catch (Exception $e) {}
        return $n;
    }

    public static function requeueOrphanTeachers() {
        $pdo = self::pdo();
        require_once __DIR__ . '/SqliteStore.php';
        $store = new SqliteStore();
        $store->connect();
        $rows = $pdo->query(
            "SELECT * FROM teachers_cache
              WHERE id < 0 AND IFNULL(status,'active') NOT IN ('inactive','duplicate')"
        )->fetchAll(PDO::FETCH_ASSOC);
        $n = 0;
        foreach ($rows as $r) {
            $uuid = !empty($r['uuid']) ? $r['uuid'] : null;
            if (!$uuid) {
                require_once __DIR__ . '/DeviceIdentity.php';
                $uuid = DeviceIdentity::generateUuid();
                $pdo->prepare('UPDATE teachers_cache SET uuid = ? WHERE id = ?')->execute(array($uuid, (int)$r['id']));
            }
            $st = $pdo->prepare("SELECT id FROM sync_queue WHERE record_uuid = ? AND status IN ('pending','failed') LIMIT 1");
            $st->execute(array($uuid));
            if ($st->fetch()) continue;
            $payload = array(
                'uuid' => $uuid,
                'full_name' => $r['full_name'],
                'email' => $r['email'],
                'phone' => isset($r['phone']) ? $r['phone'] : null,
                'role' => 'teacher',
                'status' => 'active',
                'local_id' => (int)$r['id'],
            );
            $store->enqueue('users', $uuid, 'CREATE', $payload);
            $n++;
        }
        return $n;
    }

    public static function listTeachers() {
        $pdo = self::pdo();
        try {
            foreach (array(
                'photo_url TEXT', 'class_id INTEGER', 'class_name TEXT', 'class_color TEXT',
                'subjects TEXT', 'subject_ids TEXT', 'uuid TEXT', 'sync_status TEXT'
            ) as $def) {
                try { $pdo->exec('ALTER TABLE teachers_cache ADD COLUMN ' . $def); } catch (Exception $e) {}
            }
            $rows = $pdo->query(
                "SELECT id, user_id, full_name, email, phone, status, photo_url,
                        class_id, class_name, class_color, subjects, subject_ids,
                        uuid, sync_status
                   FROM teachers_cache
                  WHERE IFNULL(status,'active') NOT IN ('inactive','duplicate')
                    AND IFNULL(sync_status,'') != 'duplicate'
               ORDER BY full_name ASC"
            )->fetchAll(PDO::FETCH_ASSOC);
            // Dedupe by email: prefer positive id
            $byEmail = array();
            foreach ($rows as $r) {
                $key = strtolower(trim(isset($r['email']) ? $r['email'] : ('id-'.$r['id'])));
                if (!isset($byEmail[$key])) {
                    $byEmail[$key] = $r;
                    continue;
                }
                $prev = $byEmail[$key];
                $prefer = ((int)$r['id'] > 0 && (int)$prev['id'] < 0) ? $r : $prev;
                if ((int)$r['id'] > 0 && (int)$prev['id'] > 0) {
                    $prefer = !empty($r['class_name']) ? $r : $prev;
                }
                $byEmail[$key] = $prefer;
            }
            return array_values($byEmail);
        } catch (Exception $e) {
            return array();
        }
    }


    public static function warmSettingsFromMysql($db) {
        $pdo = self::pdo();
        $pdo->exec("CREATE TABLE IF NOT EXISTS settings_cache (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT
        )");
        $n = 0;
        // Primary source: school_settings (key/value rows)
        try {
            $rows = $db->query("SELECT setting_key, setting_value FROM school_settings") ?: array();
            $st = $pdo->prepare(
                "INSERT INTO settings_cache (key, value, updated_at) VALUES (?,?,?)
                 ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at"
            );
            foreach ($rows as $r) {
                $k = isset($r['setting_key']) ? $r['setting_key'] : null;
                if (!$k) continue;
                $val = isset($r['setting_value']) ? $r['setting_value'] : '';
                if (is_string($val) && function_exists('decodeText')) {
                    $val = decodeText($val);
                }
                $st->execute(array($k, is_scalar($val) ? (string)$val : json_encode($val), date('c')));
                $n++;
            }
        } catch (Exception $e) {
            error_log('warmSettings school_settings: ' . $e->getMessage());
        }
        // Alias logo keys
        try {
            $st = $pdo->prepare("SELECT value FROM settings_cache WHERE key = ? LIMIT 1");
            $st->execute(array('school_logo'));
            $logo = $st->fetchColumn();
            if ($logo) {
                $pdo->prepare(
                    "INSERT INTO settings_cache (key, value, updated_at) VALUES ('logo_url',?,?)
                     ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at"
                )->execute(array($logo, date('c')));
            }
        } catch (Exception $e) {}
        return $n;
    }

    public static function getSetting($key, $default = null) {
        try {
            $pdo = self::pdo();
            $st = $pdo->prepare("SELECT value FROM settings_cache WHERE key = ? LIMIT 1");
            $st->execute(array($key));
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return $row ? $row['value'] : $default;
        } catch (Exception $e) {
            return $default;
        }
    }

    public static function listAttendanceForDate($classId, $date) {
        $pdo = self::pdo();
        $st = $pdo->prepare(
            "SELECT a.student_id, a.status, a.attendance_date, s.student_name
               FROM attendance a
          LEFT JOIN students s ON s.id = a.student_id
              WHERE a.class_id = ? AND a.attendance_date = ?"
        );
        $st->execute(array((int)$classId, $date));
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Teacher offline dashboard KPIs from SQLite */
    public static function teacherDashboard($teacherUserId, $preferClassId = 0) {
        $pdo = self::pdo();
        $today = date('Y-m-d');
        $dayOfWeek = (int)date('N');
        $dayInfo = array('type' => 'school_day', 'name' => null);
        if ($dayOfWeek >= 6) {
            $dayInfo = array(
                'type' => 'weekend',
                'name' => $dayOfWeek === 6 ? 'Saturday' : 'Sunday',
            );
        }

        $classId = (int)$preferClassId;
        $className = null;
        $classColor = '#94A3B8';

        // Resolve class row
        try {
            if ($classId > 0) {
                $st = $pdo->prepare("SELECT id, class_name, class_color, teacher_id FROM classes WHERE id = ? LIMIT 1");
                $st->execute(array($classId));
                $c = $st->fetch(PDO::FETCH_ASSOC);
            } else {
                $c = null;
            }
            if (!$c) {
                $st = $pdo->prepare("SELECT id, class_name, class_color, teacher_id FROM classes WHERE CAST(teacher_id AS INTEGER) = ? LIMIT 1");
                $st->execute(array((int)$teacherUserId));
                $c = $st->fetch(PDO::FETCH_ASSOC);
            }
            if ($c) {
                $classId = (int)$c['id'];
                $className = $c['class_name'];
                $classColor = !empty($c['class_color']) ? $c['class_color'] : '#94A3B8';
            }
        } catch (Exception $e) {
            error_log('teacherDashboard class: ' . $e->getMessage());
        }

        // Student count — simplest possible query
        $totalStudents = 0;
        if ($classId > 0) {
            try {
                $st = $pdo->prepare("SELECT COUNT(*) FROM students WHERE CAST(class_id AS INTEGER) = ? AND (status IS NULL OR status = '' OR lower(status) = 'active') AND (id > 0 OR id IS NULL)");
                $st->execute(array($classId));
                $totalStudents = (int)$st->fetchColumn();
            } catch (Exception $e) {
                try {
                    $st = $pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = ?");
                    $st->execute(array($classId));
                    $totalStudents = (int)$st->fetchColumn();
                } catch (Exception $e2) {
                    error_log('teacherDashboard count: ' . $e2->getMessage());
                }
            }
        }

        $presentToday = 0;
        $absentToday = 0;
        $lateToday = 0;
        if ($classId > 0) {
            try {
                $st = $pdo->prepare(
                    "SELECT lower(IFNULL(status,'present')) AS st, COUNT(*) AS c
                       FROM attendance
                      WHERE CAST(class_id AS INTEGER) = ?
                        AND substr(IFNULL(attendance_date,''),1,10) = ?
                      GROUP BY st"
                );
                $st->execute(array($classId, $today));
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    if ($r['st'] === 'present') $presentToday = (int)$r['c'];
                    elseif ($r['st'] === 'absent') $absentToday = (int)$r['c'];
                    elseif ($r['st'] === 'late') $lateToday = (int)$r['c'];
                }
            } catch (Exception $e) {
                // fallback without class_id column
                try {
                    $st = $pdo->prepare(
                        "SELECT lower(IFNULL(a.status,'present')) AS st, COUNT(*) AS c
                           FROM attendance a
                           JOIN students s ON s.id = a.student_id
                          WHERE CAST(s.class_id AS INTEGER) = ?
                            AND substr(IFNULL(a.attendance_date,''),1,10) = ?
                          GROUP BY st"
                    );
                    $st->execute(array($classId, $today));
                    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                        if ($r['st'] === 'present') $presentToday = (int)$r['c'];
                        elseif ($r['st'] === 'absent') $absentToday = (int)$r['c'];
                        elseif ($r['st'] === 'late') $lateToday = (int)$r['c'];
                    }
                } catch (Exception $e2) {}
            }
        }

        $attendanceRate = 0.0;
        $marked = $presentToday + $absentToday + $lateToday;
        if ($marked > 0) {
            $attendanceRate = round(($presentToday / $marked) * 100, 1);
        } elseif ($totalStudents > 0 && $presentToday > 0) {
            $attendanceRate = round(($presentToday / $totalStudents) * 100, 1);
        }

        $schedule = array();
        $pendingHomework = 0;
        try {
            $st = $pdo->prepare(
                "SELECT id, title, subject, due_date, class_id
                   FROM homework
                  WHERE CAST(class_id AS INTEGER) = ? AND date(due_date) >= date(?)
                  ORDER BY due_date ASC LIMIT 5"
            );
            $st->execute(array($classId, $today));
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) ?: array() as $hw) {
                $due = isset($hw['due_date']) ? substr($hw['due_date'], 0, 10) : '';
                $status = 'upcoming';
                if ($due === $today) $status = 'due_today';
                elseif ($due !== '' && $due < $today) $status = 'overdue';
                $schedule[] = array(
                    'id' => (int)$hw['id'],
                    'title' => isset($hw['title']) ? $hw['title'] : (isset($hw['subject']) ? $hw['subject'] : 'Homework'),
                    'subject' => isset($hw['subject']) ? $hw['subject'] : '',
                    'due_date' => $due,
                    'hw_status' => $status,
                );
                $pendingHomework++;
            }
        } catch (Exception $e) {}

        return array(
            'day_info' => $dayInfo,
            'class_id' => $classId ?: null,
            'class_name' => $className,
            'class_color' => $classColor,
            'total_students' => $totalStudents,
            'present_today' => $presentToday,
            'absent_today' => $absentToday,
            'late_today' => $lateToday,
            'attendance_rate' => $attendanceRate,
            'pending_homework' => $pendingHomework,
            'unread_messages' => 0,
            'schedule' => $schedule,
            'announcements' => array(),
            'upcoming_homework' => $schedule,
            'performance' => array(
                'attendance_rate' => $attendanceRate,
                'homework_completion' => 0.0,
                'overall_progress' => $attendanceRate,
            ),
            'offline_mode' => true,
            'debug_teacher_id' => (int)$teacherUserId,
            'debug_prefer_class' => (int)$preferClassId,
        );
    }

    /** Teacher my-class student list from SQLite */
    public static function teacherMyClass($teacherUserId, $classId = 0) {
        $pdo = self::pdo();
        if (!$classId) {
            try {
                $st = $pdo->prepare(
                    "SELECT id FROM classes WHERE teacher_id = ? AND (deleted_at IS NULL OR deleted_at='') ORDER BY id LIMIT 1"
                );
                $st->execute(array((int)$teacherUserId));
                $classId = (int)$st->fetchColumn();
            } catch (Exception $e) {}
        }
        $class = null;
        if ($classId) {
            try {
                $st = $pdo->prepare("SELECT id, class_name, class_color, capacity FROM classes WHERE id = ? LIMIT 1");
                $st->execute(array($classId));
                $class = $st->fetch(PDO::FETCH_ASSOC) ?: null;
            } catch (Exception $e) {}
        }
        $students = self::listStudents('active', $classId ?: null);
        return array(
            'class' => $class,
            'class_id' => $classId ?: null,
            'students' => $students,
            'count' => count($students),
            'offline_mode' => true,
        );
    }

}
