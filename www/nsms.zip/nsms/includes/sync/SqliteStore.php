<?php
/**
 * Local SQLite store for offline operation.
 * Schema mirrors priority MySQL tables + sync_queue.
 */
require_once __DIR__ . '/SyncConfig.php';

class SqliteStore {
    private $pdo = null;
    private $path;

    public function __construct($path = null) {
        $this->path = $path ?: SyncConfig::sqlitePath();
    }

    public function connect() {
        if ($this->pdo) return $this->pdo;
        $dir = dirname($this->path);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        $this->pdo = new PDO('sqlite:' . $this->path, null, null, array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ));
        $this->pdo->exec('PRAGMA foreign_keys = ON');
        $this->pdo->exec('PRAGMA journal_mode = WAL');
        $this->ensureSchema();
        return $this->pdo;
    }

    public function ensureSchema() {
        $pdo = $this->pdo;
        $pdo->exec("CREATE TABLE IF NOT EXISTS sync_meta (
            key TEXT PRIMARY KEY,
            value TEXT
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sync_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            op_id TEXT NOT NULL UNIQUE,
            entity_type TEXT NOT NULL,
            record_uuid TEXT NOT NULL,
            operation TEXT NOT NULL,
            payload TEXT,
            created_at TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            last_attempt_at TEXT,
            status TEXT NOT NULL DEFAULT 'pending',
            error_message TEXT
        )");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sync_queue_status ON sync_queue(status)");

        // Priority entity tables (minimal offline-capable columns + uuid)
        $pdo->exec("CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY,
            uuid TEXT UNIQUE,
            class_name TEXT,
            capacity INTEGER,
            minimum_age INTEGER,
            sort_order INTEGER,
            teacher_id INTEGER,
            updated_at TEXT,
            deleted_at TEXT,
            sync_version INTEGER DEFAULT 1
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY,
            uuid TEXT UNIQUE,
            student_name TEXT,
            class_id INTEGER,
            parent_id INTEGER,
            gender TEXT,
            date_of_birth TEXT,
            address TEXT,
            enrollment_date TEXT,
            photo_url TEXT,
            parent_name TEXT,
            parent_phone TEXT,
            parent_email TEXT,
            parent_relationship TEXT,
            status TEXT DEFAULT 'active',
            sync_status TEXT DEFAULT 'synced',
            updated_at TEXT,
            deleted_at TEXT,
            sync_version INTEGER DEFAULT 1
        )");
        foreach (array(
            'address TEXT', 'enrollment_date TEXT', 'photo_url TEXT',
            'parent_name TEXT', 'parent_phone TEXT', 'parent_email TEXT',
            'parent_relationship TEXT', 'sync_status TEXT'
        ) as $colDef) {
            $col = explode(' ', $colDef)[0];
            try { $pdo->exec("ALTER TABLE students ADD COLUMN $colDef"); } catch (Exception $e) {}
        }
        $pdo->exec("CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY,
            uuid TEXT UNIQUE,
            student_id INTEGER,
            class_id INTEGER,
            attendance_date TEXT,
            status TEXT,
            recorded_by INTEGER,
            updated_at TEXT,
            deleted_at TEXT,
            sync_version INTEGER DEFAULT 1
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            uuid TEXT UNIQUE,
            full_name TEXT,
            email TEXT,
            role TEXT,
            phone TEXT,
            updated_at TEXT,
            deleted_at TEXT,
            sync_version INTEGER DEFAULT 1
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS homework (
            id INTEGER PRIMARY KEY,
            uuid TEXT UNIQUE,
            class_id INTEGER,
            subject TEXT,
            description TEXT,
            due_date TEXT,
            posted_by INTEGER,
            updated_at TEXT,
            deleted_at TEXT,
            sync_version INTEGER DEFAULT 1
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS school_settings (
            id INTEGER PRIMARY KEY,
            uuid TEXT UNIQUE,
            setting_key TEXT UNIQUE,
            setting_value TEXT,
            updated_at TEXT,
            deleted_at TEXT,
            sync_version INTEGER DEFAULT 1
        )");

        // Cursor for last successful pull from remote
        $st = $pdo->prepare("INSERT OR IGNORE INTO sync_meta (key, value) VALUES ('pull_cursor', '0')");
        $st->execute();
        $st = $pdo->prepare("INSERT OR IGNORE INTO sync_meta (key, value) VALUES ('last_sync_at', '')");
        $st->execute();
    }

    public function getMeta($key, $default = null) {
        $pdo = $this->connect();
        $st = $pdo->prepare('SELECT value FROM sync_meta WHERE key = ?');
        $st->execute(array($key));
        $row = $st->fetch();
        return $row ? $row['value'] : $default;
    }

    public function setMeta($key, $value) {
        $pdo = $this->connect();
        $st = $pdo->prepare('INSERT INTO sync_meta (key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value');
        $st->execute(array($key, $value));
    }

    public function enqueue($entityType, $recordUuid, $operation, $payload, $opId = null) {
        $pdo = $this->connect();
        $opId = $opId ?: DeviceIdentity::generateUuid();
        $st = $pdo->prepare(
            'INSERT INTO sync_queue (op_id, entity_type, record_uuid, operation, payload, created_at, status)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $st->execute(array(
            $opId,
            $entityType,
            $recordUuid,
            $operation,
            is_string($payload) ? $payload : json_encode($payload),
            date('c'),
            'pending',
        ));
        return $opId;
    }

    public function pendingQueue($limit = 100) {
        $pdo = $this->connect();
        $st = $pdo->prepare(
            "SELECT * FROM sync_queue WHERE status IN ('pending','failed')
             ORDER BY id ASC LIMIT ?"
        );
        $st->bindValue(1, (int)$limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }

    public function markQueue($id, $status, $error = null) {
        $pdo = $this->connect();
        $st = $pdo->prepare(
            'UPDATE sync_queue SET status = ?, error_message = ?, attempts = attempts + 1, last_attempt_at = ? WHERE id = ?'
        );
        $st->execute(array($status, $error, date('c'), $id));
    }

    public function pendingCount() {
        $pdo = $this->connect();
        return (int)$pdo->query("SELECT COUNT(*) FROM sync_queue WHERE status IN ('pending','failed')")->fetchColumn();
    }
}
