<?php
/**
 * NSMS Offline-First Sync Configuration
 * Additive layer — does not change default MySQL behaviour unless offline mode is active.
 */
class SyncConfig {
    /** Entities supported for offline + sync (priority modules) */
    public static function entities() {
        return array(
            'students',
            'classes',
            'users', 'subjects',
            'attendance',
            'homework',
            'fee_payments',
            'expenses',
            'fee_structure',
            'notifications',
            'school_settings',
        );
    }

    public static function batchSize() {
        $n = getenv('NSMS_SYNC_BATCH_SIZE');
        $n = $n !== false ? (int)$n : 100;
        return max(10, min(500, $n));
    }

    public static function sqlitePath() {
        $p = getenv('NSMS_SQLITE_PATH');
        if ($p) return $p;
        return dirname(dirname(__DIR__)) . '/data/nsms_local.sqlite';
    }

    public static function remoteBaseUrl() {
        $u = getenv('NSMS_REMOTE_SYNC_URL');
        if ($u) return rtrim($u, '/');
        // Same origin relative — used by browser health check
        return '';
    }

    public static function offlineModeEnabled() {
        $v = getenv('NSMS_OFFLINE_MODE');
        return $v === '1' || $v === 'true' || $v === 'yes';
    }

    /** Conflict strategy: last_write_wins | detect_only */
    public static function conflictStrategy() {
        $s = getenv('NSMS_SYNC_CONFLICT_STRATEGY');
        return $s ? $s : 'last_write_wins';
    }
}
