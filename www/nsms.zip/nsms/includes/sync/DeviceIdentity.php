<?php
/**
 * Stable device identity for this NSMS installation.
 */
class DeviceIdentity {
    public static function getUuid() {
        $file = dirname(dirname(__DIR__)) . '/data/device_uuid.txt';
        $dir = dirname($file);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        if (is_file($file)) {
            $id = trim(file_get_contents($file));
            if (preg_match('/^[0-9a-fA-F-]{36}$/', $id)) return $id;
        }
        $id = self::generateUuid();
        @file_put_contents($file, $id);
        return $id;
    }

    public static function generateUuid() {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
