<?php
/**
 * Non-invasive hooks: after a successful MySQL write, publish a sync change-log
 * entry and optionally mirror into local SQLite. Never throws to callers.
 */
class SyncHooks {
    private static $booted = false;

    private static function boot() {
        if (self::$booted) return;
        self::$booted = true;
        require_once __DIR__ . '/SyncConfig.php';
        require_once __DIR__ . '/DeviceIdentity.php';
        require_once __DIR__ . '/SyncMysql.php';
        require_once __DIR__ . '/SqliteStore.php';
    }

    /**
     * @param Database $db
     * @param string   $entity   Table/entity name (students, attendance, …)
     * @param int      $localId  MySQL primary key
     * @param string   $operation CREATE|UPDATE|DELETE
     * @param array    $payload  Field snapshot for other devices
     */
    public static function afterWrite($db, $entity, $localId, $operation, $payload = array()) {
        try {
            self::boot();
            $entity = strtolower(trim($entity));
            if (!in_array($entity, SyncConfig::entities(), true)) {
                return;
            }
            $operation = strtoupper($operation);
            if (!in_array($operation, array('CREATE', 'UPDATE', 'DELETE'), true)) {
                return;
            }
            $localId = (int)$localId;
            if ($localId < 1 && empty($payload['uuid'])) {
                return;
            }

            $syncDb = new SyncMysql($db);
            $uuid = !empty($payload['uuid'])
                ? $payload['uuid']
                : self::ensureRecordUuid($db, $entity, $localId);

            if (!$uuid) return;

            $payload['uuid'] = $uuid;
            if ($localId > 0) $payload['id'] = $localId;

            $device = DeviceIdentity::getUuid();
            $userId = null;
            if (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['user_id'])) {
                $userId = (int)$_SESSION['user_id'];
            }

            $syncDb->appendChangeLog($entity, $uuid, $operation, $payload, $device, $userId);

            // Best-effort local SQLite mirror (for offline-capable installs)
            try {
                self::mirrorLocal($entity, $uuid, $operation, $payload);
            } catch (Exception $e) {
                error_log('SyncHooks mirrorLocal: ' . $e->getMessage());
            }
        } catch (Exception $e) {
            error_log('SyncHooks::afterWrite: ' . $e->getMessage());
        }
    }

    public static function ensureRecordUuid($db, $entity, $localId) {
        self::boot();
        $entity = preg_replace('/[^a-z0-9_]/', '', strtolower($entity));
        $localId = (int)$localId;
        if ($localId < 1) return null;

        try {
            $cols = $db->query("SHOW COLUMNS FROM `$entity` LIKE 'uuid'");
            if (empty($cols)) {
                $db->execute("ALTER TABLE `$entity` ADD COLUMN uuid VARCHAR(36) NULL");
                try {
                    $db->execute("CREATE UNIQUE INDEX uq_{$entity}_uuid ON `$entity` (uuid)");
                } catch (Exception $e) {}
            }
        } catch (Exception $e) {
            return null;
        }

        $row = $db->queryOne("SELECT uuid FROM `$entity` WHERE id = ?", array($localId));
        if ($row && !empty($row['uuid'])) {
            return $row['uuid'];
        }
        $uuid = DeviceIdentity::generateUuid();
        try {
            $db->execute("UPDATE `$entity` SET uuid = ? WHERE id = ? AND (uuid IS NULL OR uuid = '')", array($uuid, $localId));
        } catch (Exception $e) {
            return null;
        }
        return $uuid;
    }

    private static function mirrorLocal($entity, $uuid, $operation, $payload) {
        $store = new SqliteStore();
        $pdo = $store->connect();
        if ($operation === 'DELETE') {
            try {
                $st = $pdo->prepare("UPDATE `$entity` SET deleted_at = ? WHERE uuid = ?");
                $st->execute(array(date('c'), $uuid));
            } catch (Exception $e) {}
            $store->enqueue($entity, $uuid, 'DELETE', $payload);
            return;
        }
        // Upsert minimal rows for known entities
        if ($entity === 'students') {
            $st = $pdo->prepare('SELECT id FROM students WHERE uuid = ?');
            $st->execute(array($uuid));
            $ex = $st->fetch();
            if ($ex) {
                $st = $pdo->prepare('UPDATE students SET student_name=?, class_id=?, parent_id=?, gender=?, date_of_birth=?, status=?, updated_at=?, deleted_at=NULL WHERE uuid=?');
                $st->execute(array(
                    $payload['student_name'] ?? null,
                    $payload['class_id'] ?? null,
                    $payload['parent_id'] ?? null,
                    $payload['gender'] ?? null,
                    $payload['date_of_birth'] ?? null,
                    $payload['status'] ?? 'active',
                    date('c'),
                    $uuid,
                ));
            } else {
                $st = $pdo->prepare('INSERT INTO students (id, uuid, student_name, class_id, parent_id, gender, date_of_birth, status, updated_at, sync_version) VALUES (?,?,?,?,?,?,?,?,?,1)');
                $st->execute(array(
                    $payload['id'] ?? null,
                    $uuid,
                    $payload['student_name'] ?? null,
                    $payload['class_id'] ?? null,
                    $payload['parent_id'] ?? null,
                    $payload['gender'] ?? null,
                    $payload['date_of_birth'] ?? null,
                    $payload['status'] ?? 'active',
                    date('c'),
                ));
            }
        } elseif ($entity === 'classes') {
            $st = $pdo->prepare('SELECT id FROM classes WHERE uuid = ?');
            $st->execute(array($uuid));
            if ($st->fetch()) {
                $st = $pdo->prepare('UPDATE classes SET class_name=?, capacity=?, teacher_id=?, updated_at=?, deleted_at=NULL WHERE uuid=?');
                $st->execute(array(
                    $payload['class_name'] ?? null,
                    $payload['capacity'] ?? null,
                    $payload['teacher_id'] ?? null,
                    date('c'),
                    $uuid,
                ));
            } else {
                $st = $pdo->prepare('INSERT INTO classes (id, uuid, class_name, capacity, teacher_id, updated_at, sync_version) VALUES (?,?,?,?,?,?,1)');
                $st->execute(array(
                    $payload['id'] ?? null,
                    $uuid,
                    $payload['class_name'] ?? null,
                    $payload['capacity'] ?? null,
                    $payload['teacher_id'] ?? null,
                    date('c'),
                ));
            }
        } elseif ($entity === 'attendance') {
            $st = $pdo->prepare('SELECT id FROM attendance WHERE uuid = ?');
            $st->execute(array($uuid));
            if ($st->fetch()) {
                $st = $pdo->prepare('UPDATE attendance SET student_id=?, class_id=?, attendance_date=?, status=?, recorded_by=?, updated_at=?, deleted_at=NULL WHERE uuid=?');
                $st->execute(array(
                    $payload['student_id'] ?? null,
                    $payload['class_id'] ?? null,
                    $payload['attendance_date'] ?? null,
                    $payload['status'] ?? null,
                    $payload['recorded_by'] ?? null,
                    date('c'),
                    $uuid,
                ));
            } else {
                $st = $pdo->prepare('INSERT INTO attendance (id, uuid, student_id, class_id, attendance_date, status, recorded_by, updated_at, sync_version) VALUES (?,?,?,?,?,?,?,?,1)');
                $st->execute(array(
                    $payload['id'] ?? null,
                    $uuid,
                    $payload['student_id'] ?? null,
                    $payload['class_id'] ?? null,
                    $payload['attendance_date'] ?? null,
                    $payload['status'] ?? null,
                    $payload['recorded_by'] ?? null,
                    date('c'),
                ));
            }
        } elseif ($entity === 'fee_payments') {
            // Mirrors into fee_payments_local (the offline finance cache), matching
            // the schema OfflineAdmin::recordCashPayment() writes to. Table may not
            // exist yet on a fresh install that has never gone offline — create it
            // defensively rather than fail the whole hook.
            $pdo->exec("CREATE TABLE IF NOT EXISTS fee_payments_local (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uuid TEXT UNIQUE NOT NULL,
                student_id INTEGER,
                student_name TEXT,
                class_id INTEGER,
                amount REAL NOT NULL,
                payment_method TEXT DEFAULT 'Cash',
                payment_date TEXT,
                receipt_number TEXT,
                recorded_by INTEGER,
                notes TEXT,
                status TEXT DEFAULT 'confirmed',
                sync_status TEXT DEFAULT 'pending',
                created_at TEXT,
                updated_at TEXT
            )");
            $st = $pdo->prepare('SELECT id FROM fee_payments_local WHERE uuid = ?');
            $st->execute(array($uuid));
            if ($st->fetch()) {
                $st = $pdo->prepare('UPDATE fee_payments_local SET student_id=?, student_name=?, class_id=?, amount=?, payment_method=?, payment_date=?, receipt_number=?, recorded_by=?, status=?, sync_status=?, updated_at=? WHERE uuid=?');
                $st->execute(array(
                    $payload['student_id'] ?? null,
                    $payload['student_name'] ?? null,
                    $payload['class_id'] ?? null,
                    $payload['amount'] ?? 0,
                    $payload['payment_method'] ?? 'Cash',
                    $payload['payment_date'] ?? null,
                    $payload['receipt_number'] ?? null,
                    $payload['recorded_by'] ?? null,
                    $payload['status'] ?? 'confirmed',
                    'synced',
                    date('c'),
                    $uuid,
                ));
            } else {
                $st = $pdo->prepare('INSERT INTO fee_payments_local (uuid, student_id, student_name, class_id, amount, payment_method, payment_date, receipt_number, recorded_by, status, sync_status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
                $st->execute(array(
                    $uuid,
                    $payload['student_id'] ?? null,
                    $payload['student_name'] ?? null,
                    $payload['class_id'] ?? null,
                    $payload['amount'] ?? 0,
                    $payload['payment_method'] ?? 'Cash',
                    $payload['payment_date'] ?? null,
                    $payload['receipt_number'] ?? null,
                    $payload['recorded_by'] ?? null,
                    $payload['status'] ?? 'confirmed',
                    // Originated on MySQL already — nothing to push, so mark synced
                    // immediately rather than 'pending' (which would make the local
                    // engine try to re-upload a record MySQL already has).
                    'synced',
                    date('c'),
                    date('c'),
                ));
            }
        }
        // Note: enqueue is only for pure-offline originators; MySQL-originated
        // changes ride the change_log for other devices via pull.
    }
}
