<?php
/**
 * MySQL-side sync helpers (change log, devices, idempotency).
 * Additive — never replaces primary CRUD.
 */
class SyncMysql {
    private $db;

    public function __construct($db) {
        $this->db = $db;
        $this->ensureTables();
    }

    public function ensureTables() {
        static $done = false;
        if ($done) return;
        $done = true;
        $sqlFile = dirname(dirname(__DIR__)) . '/database/sync_offline_migration.sql';
        if (!is_file($sqlFile)) return;
        try {
            $sql = file_get_contents($sqlFile);
            // Split on semicolons carefully for multi-statement
            foreach (preg_split('/;\s*\n/', $sql) as $stmt) {
                $stmt = trim($stmt);
                if ($stmt === '' || strpos($stmt, '--') === 0 && strlen($stmt) < 5) continue;
                // skip pure comment blocks
                if (preg_match('/^--/', $stmt) && strpos($stmt, 'CREATE') === false) continue;
                try {
                    $this->db->execute($stmt);
                } catch (Exception $e) {
                    // table may already exist
                }
            }
        } catch (Exception $e) {
            error_log('SyncMysql ensureTables: ' . $e->getMessage());
        }
    }

    public function registerDevice($deviceUuid, $userId = null, $deviceName = null) {
        $row = $this->db->queryOne('SELECT id FROM sync_devices WHERE device_uuid = ?', array($deviceUuid));
        if ($row) {
            $this->db->execute(
                'UPDATE sync_devices SET last_seen_at = NOW(), user_id = COALESCE(?, user_id), device_name = COALESCE(?, device_name) WHERE device_uuid = ?',
                array($userId, $deviceName, $deviceUuid)
            );
            return (int)$row['id'];
        }
        return (int)$this->db->execute(
            'INSERT INTO sync_devices (device_uuid, device_name, user_id, last_seen_at, created_at) VALUES (?,?,?,NOW(),NOW())',
            array($deviceUuid, $deviceName, $userId)
        );
    }

    public function isOpProcessed($opId) {
        $row = $this->db->queryOne('SELECT id FROM sync_processed_ops WHERE op_id = ?', array($opId));
        return !empty($row);
    }

    public function markOpProcessed($opId, $deviceUuid, $entityType, $recordUuid) {
        try {
            $this->db->execute(
                'INSERT INTO sync_processed_ops (op_id, device_uuid, entity_type, record_uuid, processed_at) VALUES (?,?,?,?,NOW())',
                array($opId, $deviceUuid, $entityType, $recordUuid)
            );
        } catch (Exception $e) {
            // unique race — already processed
        }
    }

    public function appendChangeLog($entityType, $recordUuid, $operation, $payload, $deviceUuid = null, $userId = null) {
        return $this->db->execute(
            'INSERT INTO sync_change_log (entity_type, record_uuid, operation, payload_json, device_uuid, user_id, created_at)
             VALUES (?,?,?,?,?,?,NOW())',
            array(
                $entityType,
                $recordUuid,
                $operation,
                is_string($payload) ? $payload : json_encode($payload),
                $deviceUuid,
                $userId,
            )
        );
    }

    public function pullChanges($afterId, $limit = 100) {
        $afterId = (int)$afterId;
        $limit = (int)$limit;
        return $this->db->query(
            'SELECT * FROM sync_change_log WHERE id > ? ORDER BY id ASC LIMIT ' . $limit,
            array($afterId)
        ) ?: array();
    }

    public function startSession($deviceUuid, $userId, $direction = 'full') {
        return (int)$this->db->execute(
            'INSERT INTO sync_sessions (device_uuid, user_id, direction, started_at, status) VALUES (?,?,?,NOW(),\'running\')',
            array($deviceUuid, $userId, $direction)
        );
    }

    public function finishSession($sessionId, $up, $down, $failed, $conflicts, $status = 'completed', $error = null) {
        $this->db->execute(
            'UPDATE sync_sessions SET completed_at = NOW(), records_uploaded = ?, records_downloaded = ?,
             records_failed = ?, conflicts = ?, status = ?, error_details = ? WHERE id = ?',
            array($up, $down, $failed, $conflicts, $status, $error, $sessionId)
        );
        $this->db->execute(
            'UPDATE sync_devices SET last_sync_at = NOW() WHERE device_uuid = (SELECT device_uuid FROM sync_sessions WHERE id = ?)',
            array($sessionId)
        );
    }

    public function stats() {
        $pendingConflicts = $this->db->queryOne(
            "SELECT COUNT(*) AS c FROM sync_conflicts WHERE resolution = 'pending'"
        );
        $devices = $this->db->queryOne('SELECT COUNT(*) AS c FROM sync_devices');
        $last = $this->db->queryOne(
            "SELECT * FROM sync_sessions WHERE status IN ('completed','partial') ORDER BY id DESC LIMIT 1"
        );
        $failed = $this->db->queryOne(
            "SELECT COALESCE(SUM(records_failed),0) AS c FROM sync_sessions WHERE started_at > DATE_SUB(NOW(), INTERVAL 7 DAY)"
        );
        return array(
            'devices' => (int)($devices['c'] ?? 0),
            'pending_conflicts' => (int)($pendingConflicts['c'] ?? 0),
            'failed_7d' => (int)($failed['c'] ?? 0),
            'last_session' => $last ?: null,
        );
    }

    /**
     * Apply one pushed operation idempotently (create/update/delete by UUID).
     * Uses entity-specific handlers for priority tables.
     */
    public function applyPushOp($op) {
        $opId = isset($op['op_id']) ? $op['op_id'] : null;
        $entity = isset($op['entity_type']) ? $op['entity_type'] : '';
        $uuid = isset($op['record_uuid']) ? $op['record_uuid'] : '';
        $operation = isset($op['operation']) ? strtoupper($op['operation']) : '';
        $payload = isset($op['payload']) ? $op['payload'] : array();
        if (is_string($payload)) {
            $decoded = json_decode($payload, true);
            if (is_array($decoded)) $payload = $decoded;
        }
        $deviceUuid = isset($op['device_uuid']) ? $op['device_uuid'] : null;

        if (!$opId || !$entity || !$uuid || !in_array($operation, array('CREATE','UPDATE','DELETE'), true)) {
            return array('ok' => false, 'error' => 'Invalid operation');
        }
        if ($this->isOpProcessed($opId)) {
            return array('ok' => true, 'duplicate' => true, 'message' => 'Already processed');
        }

        $entities = SyncConfig::entities();
        if (!in_array($entity, $entities, true)) {
            return array('ok' => false, 'error' => 'Unsupported entity: ' . $entity);
        }

        try {
            if ($operation === 'DELETE') {
                $this->softDeleteByUuid($entity, $uuid);
            } else {
                $this->upsertByUuid($entity, $uuid, is_array($payload) ? $payload : array());
            }
            $this->appendChangeLog($entity, $uuid, $operation, $payload, $deviceUuid, null);
            $this->markOpProcessed($opId, $deviceUuid, $entity, $uuid);
            if ($entity === 'students' && is_array($payload)) {
                $this->remapLocalStudentAfterPush($uuid, $payload);
            }
            return array('ok' => true, 'entity' => $entity, 'uuid' => $uuid, 'operation' => $operation);
        } catch (Exception $e) {
            error_log('applyPushOp ' . $entity . ' ' . $uuid . ': ' . $e->getMessage());
            return array('ok' => false, 'error' => $e->getMessage(), 'entity' => $entity, 'uuid' => $uuid);
        }
    }

    private function tableHasUuid($table) {
        try {
            $cols = $this->db->query("SHOW COLUMNS FROM `$table` LIKE 'uuid'");
            return !empty($cols);
        } catch (Exception $e) {
            return false;
        }
    }

    private function ensureUuidColumn($table) {
        if ($this->tableHasUuid($table)) return;
        try {
            $this->db->execute("ALTER TABLE `$table` ADD COLUMN uuid VARCHAR(36) NULL UNIQUE");
        } catch (Exception $e) {}
        try {
            $this->db->execute("ALTER TABLE `$table` ADD COLUMN deleted_at DATETIME NULL");
        } catch (Exception $e) {}
        try {
            $this->db->execute("ALTER TABLE `$table` ADD COLUMN sync_version INT UNSIGNED NOT NULL DEFAULT 1");
        } catch (Exception $e) {}
    }

    private function softDeleteByUuid($entity, $uuid) {
        $this->ensureUuidColumn($entity);
        // classes / subjects may not have deleted_at — hard delete is correct for school config
        if (in_array($entity, array('classes', 'subjects'), true)) {
            $this->db->execute("DELETE FROM `$entity` WHERE uuid = ?", array($uuid));
            // Also try by id if uuid not stored yet
            if (preg_match('/^(class|subject)-(\d+)$/', $uuid, $m)) {
                $this->db->execute("DELETE FROM `$entity` WHERE id = ?", array((int)$m[2]));
            }
            return;
        }
        try {
            $this->db->execute(
                "UPDATE `$entity` SET deleted_at = NOW() WHERE uuid = ?",
                array($uuid)
            );
        } catch (Exception $e) {
            $this->db->execute("DELETE FROM `$entity` WHERE uuid = ?", array($uuid));
        }
    }

    private function ensureExpensesTable() {
        try {
            $this->db->execute("CREATE TABLE IF NOT EXISTS expenses (
                id INT AUTO_INCREMENT PRIMARY KEY,
                uuid VARCHAR(64) NULL,
                category VARCHAR(100) NULL,
                description TEXT NULL,
                amount DECIMAL(12,2) NOT NULL DEFAULT 0,
                payment_method VARCHAR(50) NULL,
                expense_date DATE NULL,
                notes TEXT NULL,
                created_at DATETIME NULL,
                INDEX (uuid)
            )");
        } catch (Exception $e) {}
    }

    private function upsertByUuid($entity, $uuid, $payload) {
        if ($entity === 'fee_structure') {
            $ft = isset($payload['fee_type']) ? $payload['fee_type'] : '';
            $yr = isset($payload['academic_year']) ? $payload['academic_year'] : '';
            $cid = array_key_exists('class_id', $payload) && $payload['class_id'] !== '' && $payload['class_id'] !== null
                ? (int)$payload['class_id'] : null;
            $amt = isset($payload['amount']) ? (float)$payload['amount'] : 0;
            $cur = isset($payload['currency']) ? $payload['currency'] : 'TZS';
            if ($ft === '' || $yr === '') {
                throw new Exception('fee_structure requires fee_type and academic_year');
            }
            if ($cid === null) {
                $this->db->execute(
                    "DELETE FROM fee_structure WHERE class_id IS NULL AND academic_year = ? AND fee_type = ?",
                    array($yr, $ft)
                );
            } else {
                $this->db->execute(
                    "DELETE FROM fee_structure WHERE class_id = ? AND academic_year = ? AND fee_type = ?",
                    array($cid, $yr, $ft)
                );
            }
            $this->db->execute(
                "INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year) VALUES (?,?,?,?,?)",
                array($cid, $ft, $amt, $cur, $yr)
            );
            return;
        }
        if ($entity === 'school_settings') {
            $key = isset($payload['setting_key']) ? $payload['setting_key'] : '';
            $val = isset($payload['setting_value']) ? $payload['setting_value'] : '';
            if ($key === '') throw new Exception('school_settings requires setting_key');
            $ex = $this->db->queryOne("SELECT id FROM school_settings WHERE setting_key = ? LIMIT 1", array($key));
            if ($ex) {
                $this->db->execute("UPDATE school_settings SET setting_value = ? WHERE setting_key = ?", array($val, $key));
            } else {
                $this->db->execute("INSERT INTO school_settings (setting_key, setting_value) VALUES (?, ?)", array($key, $val));
            }
            return;
        }
        if ($entity === 'expenses') {
            /* use live expenses table — do not CREATE alternate schema */
        }

        $this->ensureUuidColumn($entity);
        $existing = $this->db->queryOne("SELECT * FROM `$entity` WHERE uuid = ? LIMIT 1", array($uuid));

        // Offline updates of warmed rows: fall back to numeric id when uuid not yet on MySQL
        if (!$existing && $entity === 'students' && !empty($payload['id']) && (int)$payload['id'] > 0) {
            $existing = $this->db->queryOne("SELECT * FROM students WHERE id = ? LIMIT 1", array((int)$payload['id']));
            if ($existing) {
                try {
                    $this->db->execute("UPDATE students SET uuid = ? WHERE id = ?", array($uuid, (int)$payload['id']));
                    $existing['uuid'] = $uuid;
                } catch (Exception $e) {}
            }
        }
        // Prevent duplicate teachers/users: match by email
        if (!$existing && $entity === 'users') {
            $em = isset($payload['email']) ? strtolower(trim($payload['email'])) : '';
            if ($em !== '') {
                $existing = $this->db->queryOne("SELECT * FROM users WHERE LOWER(email) = ? LIMIT 1", array($em));
                if ($existing) {
                    try {
                        $this->db->execute("UPDATE users SET uuid = ? WHERE id = ?", array($uuid, (int)$existing['id']));
                        $existing['uuid'] = $uuid;
                    } catch (Exception $e) {}
                }
            }
            if (!$existing && !empty($payload['id']) && (int)$payload['id'] > 0) {
                $existing = $this->db->queryOne("SELECT * FROM users WHERE id = ? LIMIT 1", array((int)$payload['id']));
                if ($existing) {
                    try {
                        $this->db->execute("UPDATE users SET uuid = ? WHERE id = ?", array($uuid, (int)$payload['id']));
                        $existing['uuid'] = $uuid;
                    } catch (Exception $e) {}
                }
            }
        }
        // Prevent duplicate students: match by name + class when uuid missing on MySQL
        if (!$existing && $entity === 'students') {
            $nm = isset($payload['student_name']) ? trim($payload['student_name']) : '';
            $cid = isset($payload['class_id']) ? (int)$payload['class_id'] : 0;
            if ($nm !== '') {
                if ($cid > 0) {
                    $existing = $this->db->queryOne(
                        "SELECT * FROM students WHERE LOWER(TRIM(student_name)) = LOWER(?) AND class_id = ? ORDER BY id ASC LIMIT 1",
                        array($nm, $cid)
                    );
                }
                if (!$existing) {
                    $existing = $this->db->queryOne(
                        "SELECT * FROM students WHERE LOWER(TRIM(student_name)) = LOWER(?) ORDER BY id ASC LIMIT 1",
                        array($nm)
                    );
                }
                if ($existing) {
                    try {
                        $this->db->execute("UPDATE students SET uuid = ? WHERE id = ?", array($uuid, (int)$existing['id']));
                        $existing['uuid'] = $uuid;
                    } catch (Exception $e) {}
                }
            }
        }
        if ($entity === 'classes') {
            if (empty($payload['class_color']) || !is_string($payload['class_color'])) {
                $payload['class_color'] = '#2563EB';
            }
            if (empty($payload['class_name'])) {
                $payload['class_name'] = 'New Class';
            }
            if (!isset($payload['capacity']) || $payload['capacity'] === '' || $payload['capacity'] === null) {
                $payload['capacity'] = 40;
            }
        }

        if (!$existing && $entity === 'classes' && !empty($payload['id']) && (int)$payload['id'] > 0) {
            $existing = $this->db->queryOne("SELECT * FROM classes WHERE id = ? LIMIT 1", array((int)$payload['id']));
            if ($existing) {
                try {
                    $this->db->execute("UPDATE classes SET uuid = ? WHERE id = ?", array($uuid, (int)$payload['id']));
                    $existing['uuid'] = $uuid;
                } catch (Exception $e) {}
            }
        }

        // Only map known safe columns per entity
        $map = $this->payloadMap($entity, $payload);
        // Drop columns that do not exist on the live MySQL table
        if ($entity === 'fee_payments' || $entity === 'expenses') {
            $cols = $this->tableColumns($entity);
            if ($cols) {
                foreach (array_keys($map) as $col) {
                    if (!isset($cols[strtolower($col)])) unset($map[$col]);
                }
            }
        }
        // Ignore negative offline-only foreign keys
        if (isset($map['class_id']) && (int)$map['class_id'] < 0) {
            unset($map['class_id']);
        }
        if (isset($map['student_id']) && (int)$map['student_id'] < 0) {
            unset($map['student_id']);
        }
        if ($entity === 'users' && empty($map['password_hash'])) {
            $map['password_hash'] = password_hash('teacher123', PASSWORD_DEFAULT);
            $map['password_changed'] = 0;
        }
        if ($entity === 'users' && empty($map['role'])) {
            $map['role'] = 'teacher';
        }
        if ($existing) {
            // conflict: compare sync_version if present
            $remoteVer = isset($payload['sync_version']) ? (int)$payload['sync_version'] : 0;
            $localVer = isset($existing['sync_version']) ? (int)$existing['sync_version'] : 0;
            if ($remoteVer && $localVer && $remoteVer < $localVer && SyncConfig::conflictStrategy() === 'detect_only') {
                $this->db->execute(
                    'INSERT INTO sync_conflicts (entity_type, record_uuid, local_payload, remote_payload, resolution, created_at)
                     VALUES (?,?,?,?,\'pending\',NOW())',
                    array($entity, $uuid, json_encode($existing), json_encode($payload))
                );
                return;
            }
            $sets = array();
            $params = array();
            foreach ($map as $col => $val) {
                $sets[] = "`$col` = ?";
                $params[] = $val;
            }
            $sets[] = 'sync_version = COALESCE(sync_version,0) + 1';
            $params[] = $uuid;
            if ($sets) {
                $this->db->execute(
                    "UPDATE `$entity` SET " . implode(',', $sets) . " WHERE uuid = ?",
                    $params
                );
            }
        } else {
            if ($entity === 'students') {
                $this->insertStudentRow($uuid, $map, $payload);
            } elseif ($entity === 'fee_payments') {
                $this->insertFeePaymentRow($uuid, $map, $payload);
            } elseif ($entity === 'expenses') {
                $this->insertExpenseRow($uuid, $map, $payload);
            } else {
                $cols = array('uuid');
                $qs = array('?');
                $params = array($uuid);
                foreach ($map as $col => $val) {
                    $cols[] = "`$col`";
                    $qs[] = '?';
                    $params[] = $val;
                }
                $ok = $this->db->execute(
                    "INSERT INTO `$entity` (" . implode(',', $cols) . ") VALUES (" . implode(',', $qs) . ")",
                    $params
                );
                if ($ok === false) {
                    $detail = !empty($this->db->lastError) ? $this->db->lastError : 'check server error log';
                    throw new Exception('Failed to insert ' . $entity . ' (uuid=' . $uuid . '): ' . $detail);
                }
            }
        }
    }

    /**
     * Insert student with NOT NULL defaults matching NSMS schema:
     * class_id, gender (Male|Female), enrollment_date required.
     */
    private function tableColumns($table) {
        static $cache = array();
        if (isset($cache[$table])) return $cache[$table];
        $cols = array();
        try {
            $rows = $this->db->query("SHOW COLUMNS FROM `$table`");
            if (is_array($rows)) {
                foreach ($rows as $r) {
                    $cols[strtolower($r['Field'])] = $r;
                }
            }
        } catch (Exception $e) {}
        $cache[$table] = $cols;
        return $cols;
    }

    private function insertStudentRow($uuid, $map, $payload) {
        $name = isset($map['student_name']) ? trim($map['student_name']) : (isset($payload['student_name']) ? trim($payload['student_name']) : '');
        if ($name === '') {
            throw new Exception('Student sync requires student_name');
        }

        // Idempotent: already inserted with this uuid
        $this->ensureUuidColumn('students');
        $already = $this->db->queryOne("SELECT id FROM students WHERE uuid = ? LIMIT 1", array($uuid));
        if ($already) {
            return;
        }

        $classId = isset($map['class_id']) ? (int)$map['class_id'] : (isset($payload['class_id']) ? (int)$payload['class_id'] : 0);
        if ($classId < 1) {
            $row = $this->db->queryOne("SELECT id FROM classes ORDER BY id ASC LIMIT 1");
            if ($row) $classId = (int)$row['id'];
        }
        if ($classId > 0) {
            $cls = $this->db->queryOne("SELECT id FROM classes WHERE id = ? LIMIT 1", array($classId));
            if (!$cls) {
                $row = $this->db->queryOne("SELECT id FROM classes ORDER BY id ASC LIMIT 1");
                $classId = $row ? (int)$row['id'] : 0;
            }
        }
        if ($classId < 1) {
            throw new Exception('Student sync requires a valid class_id (create at least one class online first)');
        }

        $gender = isset($map['gender']) ? trim($map['gender']) : (isset($payload['gender']) ? trim($payload['gender']) : '');
        $gLower = strtolower($gender);
        if ($gLower === 'male' || $gLower === 'm') $gender = 'Male';
        elseif ($gLower === 'female' || $gLower === 'f') $gender = 'Female';
        elseif ($gender !== 'Male' && $gender !== 'Female') $gender = 'Male';

        $enroll = isset($map['enrollment_date']) ? $map['enrollment_date'] : (isset($payload['enrollment_date']) ? $payload['enrollment_date'] : null);
        if (!$enroll || $enroll === '') $enroll = date('Y-m-d');
        if (strlen($enroll) > 10) $enroll = substr($enroll, 0, 10);

        $dob = isset($map['date_of_birth']) ? $map['date_of_birth'] : (isset($payload['date_of_birth']) ? $payload['date_of_birth'] : null);
        if ($dob && strlen($dob) > 10) $dob = substr($dob, 0, 10);
        if ($dob === '') $dob = null;

        $status = isset($map['status']) ? $map['status'] : (isset($payload['status']) ? $payload['status'] : 'active');
        $allowedStatus = array('active','graduated','transferred','withdrawn','suspended');
        if (!in_array($status, $allowedStatus, true)) $status = 'active';

        $address = isset($map['address']) ? $map['address'] : null;
        $photo = isset($map['photo_url']) ? $map['photo_url'] : null;

        $colsMeta = $this->tableColumns('students');
        $candidate = array(
            'uuid' => $uuid,
            'student_name' => $name,
            'class_id' => $classId,
            'date_of_birth' => $dob,
            'gender' => $gender,
            'address' => $address,
            'enrollment_date' => $enroll,
            'photo_url' => $photo,
            'status' => $status,
        );

        // Prefer matching online createStudent shape exactly
        $cols = array();
        $params = array();
        foreach ($candidate as $col => $val) {
            if (!isset($colsMeta[strtolower($col)])) continue;
            $cols[] = '`' . $col . '`';
            $params[] = $val;
        }
        if (!in_array('`student_name`', $cols, true)) {
            throw new Exception('students.student_name column missing on MySQL');
        }

        $placeholders = implode(',', array_fill(0, count($cols), '?'));
        $sql = 'INSERT INTO students (' . implode(',', $cols);
        $hasCreated = isset($colsMeta['created_at']);
        if ($hasCreated) {
            $sql .= ', `created_at`) VALUES (' . $placeholders . ', NOW())';
        } else {
            $sql .= ') VALUES (' . $placeholders . ')';
        }

        $this->db->lastError = null;
        $ok = $this->db->execute($sql, $params);
        if ($ok === false) {
            $detail = !empty($this->db->lastError) ? $this->db->lastError : 'unknown SQL error';
            // Common ENUM gender values Male/Female vs M/F
            if (stripos($detail, 'gender') !== false || stripos($detail, 'truncated') !== false) {
                $candidate['gender'] = 'M';
                // rebuild once with M
                $cols = array();
                $params = array();
                foreach ($candidate as $col => $val) {
                    if (!isset($colsMeta[strtolower($col)])) continue;
                    $cols[] = '`' . $col . '`';
                    $params[] = $val;
                }
                $placeholders = implode(',', array_fill(0, count($cols), '?'));
                $sql = 'INSERT INTO students (' . implode(',', $cols);
                if ($hasCreated) {
                    $sql .= ', `created_at`) VALUES (' . $placeholders . ', NOW())';
                } else {
                    $sql .= ') VALUES (' . $placeholders . ')';
                }
                $this->db->lastError = null;
                $ok = $this->db->execute($sql, $params);
            }
        }
        if ($ok === false) {
            $detail = !empty($this->db->lastError) ? $this->db->lastError : 'unknown SQL error';
            throw new Exception(
                'Failed to insert students (uuid=' . $uuid . '): class_id=' . $classId .
                ', gender=' . $gender . ', enrollment_date=' . $enroll . ' — ' . $detail
            );
        }

        $newId = (int)$ok;
        if ($newId > 0 && !isset($colsMeta['uuid'])) {
            try {
                $this->ensureUuidColumn('students');
                $this->db->execute("UPDATE students SET uuid = ? WHERE id = ?", array($uuid, $newId));
            } catch (Exception $e) {}
        }
    }


    private function remapLocalStudentAfterPush($uuid, $payload) {
        try {
            require_once __DIR__ . '/SqliteStore.php';
            $store = new SqliteStore();
            $pdo = $store->connect();
            $row = $this->db->queryOne("SELECT id FROM students WHERE uuid = ? LIMIT 1", array($uuid));
            if (!$row) return;
            $mysqlId = (int)$row['id'];
            // Remove local negative shadow with same uuid
            $pdo->prepare("DELETE FROM students WHERE uuid = ? AND id < 0")->execute(array($uuid));
            // Upsert positive row from MySQL shape
            $full = $this->db->queryOne(
                "SELECT s.*, u.full_name AS parent_name, u.phone AS parent_phone, u.email AS parent_email, p.relationship AS parent_relationship
                   FROM students s
              LEFT JOIN parents p ON p.student_id = s.id
              LEFT JOIN users u ON u.id = p.user_id
                  WHERE s.id = ? LIMIT 1",
                array($mysqlId)
            );
            if (!$full) {
                $full = $this->db->queryOne("SELECT * FROM students WHERE id = ? LIMIT 1", array($mysqlId));
            }
            if (!$full) return;
            foreach (array('parent_name','parent_phone','parent_email','parent_relationship','address','enrollment_date','photo_url','sync_status') as $c) {
                try { $pdo->exec("ALTER TABLE students ADD COLUMN $c TEXT"); } catch (Exception $e) {}
            }
            $st = $pdo->prepare(
                "INSERT INTO students (id, uuid, student_name, class_id, gender, date_of_birth, status, address, enrollment_date, photo_url,
                  parent_name, parent_phone, parent_email, parent_relationship, updated_at, sync_version, sync_status, deleted_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,'synced', NULL)
                 ON CONFLICT(id) DO UPDATE SET
                   uuid=excluded.uuid,
                   student_name=excluded.student_name,
                   class_id=excluded.class_id,
                   gender=excluded.gender,
                   date_of_birth=excluded.date_of_birth,
                   status=excluded.status,
                   address=excluded.address,
                   enrollment_date=excluded.enrollment_date,
                   parent_name=excluded.parent_name,
                   parent_phone=excluded.parent_phone,
                   parent_email=excluded.parent_email,
                   parent_relationship=excluded.parent_relationship,
                   sync_status='synced',
                   deleted_at=NULL,
                   updated_at=excluded.updated_at"
            );
            $st->execute(array(
                $mysqlId,
                $uuid,
                $full['student_name'],
                $full['class_id'],
                isset($full['gender']) ? $full['gender'] : null,
                isset($full['date_of_birth']) ? $full['date_of_birth'] : null,
                isset($full['status']) ? $full['status'] : 'active',
                isset($full['address']) ? $full['address'] : null,
                isset($full['enrollment_date']) ? $full['enrollment_date'] : null,
                isset($full['photo_url']) ? $full['photo_url'] : null,
                isset($full['parent_name']) ? $full['parent_name'] : (isset($payload['parent_name']) ? $payload['parent_name'] : null),
                isset($full['parent_phone']) ? $full['parent_phone'] : (isset($payload['parent_phone']) ? $payload['parent_phone'] : null),
                isset($full['parent_email']) ? $full['parent_email'] : (isset($payload['parent_email']) ? $payload['parent_email'] : null),
                isset($full['parent_relationship']) ? $full['parent_relationship'] : (isset($payload['parent_relationship']) ? $payload['parent_relationship'] : null),
                date('c'),
            ));
        } catch (Exception $e) {
            error_log('remapLocalStudentAfterPush: ' . $e->getMessage());
        }
    }



    private function insertExpenseRow($uuid, $map, $payload) {
        // Schema: category, description NOT NULL, amount, payment_method ENUM(Cash,Bank Transfer,M-Pesa,Cheque),
        // expense_date, reference_number NULL, recorded_by NOT NULL
        $category = isset($map['category']) ? trim($map['category']) : (isset($payload['category']) ? trim($payload['category']) : 'General');
        if ($category === '') $category = 'General';
        $description = isset($map['description']) ? trim($map['description']) : (isset($payload['description']) ? trim($payload['description']) : '');
        if ($description === '') $description = $category;
        $amount = isset($map['amount']) ? (float)$map['amount'] : (isset($payload['amount']) ? (float)$payload['amount'] : 0);
        if ($amount <= 0) throw new Exception('expenses sync requires amount > 0');
        $method = isset($map['payment_method']) ? $map['payment_method'] : (isset($payload['payment_method']) ? $payload['payment_method'] : 'Cash');
        $allowed = array('Cash','Bank Transfer','M-Pesa','Cheque');
        if (!in_array($method, $allowed, true)) $method = 'Cash';
        $date = isset($map['expense_date']) ? $map['expense_date'] : (isset($payload['expense_date']) ? $payload['expense_date'] : date('Y-m-d'));
        if (strlen($date) > 10) $date = substr($date, 0, 10);
        $ref = isset($payload['notes']) ? substr((string)$payload['notes'], 0, 100) : null;
        $recordedBy = 0;
        if (!empty($payload['recorded_by'])) $recordedBy = (int)$payload['recorded_by'];
        elseif (!empty($_SESSION['user_id'])) $recordedBy = (int)$_SESSION['user_id'];
        if ($recordedBy < 1) {
            $admin = $this->db->queryOne("SELECT id FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1");
            $recordedBy = $admin ? (int)$admin['id'] : 1;
        }
        $this->db->lastError = null;
        $ok = $this->db->execute(
            "INSERT INTO expenses (category, description, amount, payment_method, expense_date, reference_number, recorded_by, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, NOW())",
            array($category, $description, $amount, $method, $date, $ref, $recordedBy)
        );
        if ($ok === false) {
            $detail = !empty($this->db->lastError) ? $this->db->lastError : 'unknown';
            throw new Exception('Failed to insert expenses: ' . $detail);
        }
    }

    private function insertFeePaymentRow($uuid, $map, $payload) {
        // Matches live schema (nsms.sql):
        // student_id, amount, payment_method ENUM, payment_date, receipt_number NOT NULL,
        // reference_number NULL, status ENUM, recorded_by NOT NULL, created_at, uuid
        $studentId = isset($map['student_id']) ? (int)$map['student_id'] : (isset($payload['student_id']) ? (int)$payload['student_id'] : 0);
        if ($studentId < 1) throw new Exception('fee_payments sync requires student_id');
        $amount = isset($map['amount']) ? (float)$map['amount'] : (isset($payload['amount']) ? (float)$payload['amount'] : 0);
        if ($amount <= 0) throw new Exception('fee_payments sync requires amount > 0');

        $method = isset($map['payment_method']) ? trim($map['payment_method']) : (isset($payload['payment_method']) ? trim($payload['payment_method']) : 'Cash');
        $allowedMethods = array('M-Pesa','Bank Transfer','Cash','Cheque','Other','Tigo Pesa','Airtel Money','HaloPesa','Mixx by Yas','Visa','Mastercard','Control Number');
        if (!in_array($method, $allowedMethods, true)) {
            // Map common offline aliases
            $ml = strtolower($method);
            if (strpos($ml, 'cash') !== false) $method = 'Cash';
            elseif (strpos($ml, 'bank') !== false) $method = 'Bank Transfer';
            elseif (strpos($ml, 'cheque') !== false || strpos($ml, 'check') !== false) $method = 'Cheque';
            elseif (strpos($ml, 'control') !== false) $method = 'Control Number';
            elseif (strpos($ml, 'm-pesa') !== false || strpos($ml, 'mpesa') !== false) $method = 'M-Pesa';
            else $method = 'Cash';
        }

        $date = isset($map['payment_date']) ? $map['payment_date'] : (isset($payload['payment_date']) ? $payload['payment_date'] : date('Y-m-d'));
        if (strlen($date) > 10) $date = substr($date, 0, 10);

        $status = isset($map['status']) ? $map['status'] : 'confirmed';
        if (!in_array($status, array('confirmed','pending','failed'), true)) $status = 'confirmed';

        $receipt = '';
        if (!empty($map['receipt_number'])) $receipt = trim((string)$map['receipt_number']);
        elseif (!empty($payload['receipt_number'])) $receipt = trim((string)$payload['receipt_number']);
        if ($receipt === '') {
            $receipt = 'OFF-' . strtoupper(substr(str_replace('-', '', $uuid), 0, 10));
        }
        if (strlen($receipt) > 50) $receipt = substr($receipt, 0, 50);

        $ref = null;
        if (!empty($map['reference_number'])) $ref = substr((string)$map['reference_number'], 0, 100);
        elseif (!empty($payload['reference_number'])) $ref = substr((string)$payload['reference_number'], 0, 100);
        elseif (!empty($payload['notes'])) $ref = substr((string)$payload['notes'], 0, 100);

        // recorded_by is NOT NULL in schema
        $recordedBy = 0;
        if (!empty($payload['recorded_by'])) $recordedBy = (int)$payload['recorded_by'];
        elseif (function_exists('getCurrentUserId')) {
            try { $recordedBy = (int)getCurrentUserId(); } catch (Exception $e) {}
        }
        if ($recordedBy < 1 && !empty($_SESSION['user_id'])) $recordedBy = (int)$_SESSION['user_id'];
        if ($recordedBy < 1) {
            // Fallback: first admin user
            $admin = $this->db->queryOne("SELECT id FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1");
            $recordedBy = $admin ? (int)$admin['id'] : 1;
        }

        $this->ensureUuidColumn('fee_payments');
        $already = $this->db->queryOne("SELECT id FROM fee_payments WHERE uuid = ? LIMIT 1", array($uuid));
        if ($already) return;
        $byRec = $this->db->queryOne("SELECT id FROM fee_payments WHERE receipt_number = ? LIMIT 1", array($receipt));
        if ($byRec) {
            try {
                $this->db->execute("UPDATE fee_payments SET uuid = ? WHERE id = ?", array($uuid, (int)$byRec['id']));
            } catch (Exception $e) {}
            return;
        }

        $this->db->lastError = null;
        $ok = $this->db->execute(
            "INSERT INTO fee_payments
                (student_id, amount, payment_method, payment_date, receipt_number, reference_number, status, recorded_by, created_at, uuid, sync_version)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 1)",
            array($studentId, $amount, $method, $date, $receipt, $ref, $status, $recordedBy, $uuid)
        );
        if ($ok === false) {
            // Without uuid column if not present
            $this->db->lastError = null;
            $ok = $this->db->execute(
                "INSERT INTO fee_payments
                    (student_id, amount, payment_method, payment_date, receipt_number, reference_number, status, recorded_by, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())",
                array($studentId, $amount, $method, $date, $receipt, $ref, $status, $recordedBy)
            );
            if ($ok !== false) {
                $newId = (int)$ok;
                if ($newId > 0) {
                    try {
                        $this->db->execute("UPDATE fee_payments SET uuid = ? WHERE id = ?", array($uuid, $newId));
                    } catch (Exception $e) {}
                }
            }
        }
        if ($ok === false) {
            $detail = !empty($this->db->lastError) ? $this->db->lastError : 'unknown';
            throw new Exception('Failed to insert fee_payments (uuid=' . $uuid . '): ' . $detail);
        }
    }

    private function payloadMap($entity, $payload) {
        $allowed = array(
            'students' => array('student_name','class_id','gender','date_of_birth','status','enrollment_date','address','photo_url'),
            'classes' => array('class_name','capacity','minimum_age','sort_order','class_color','teacher_id','minimum_age','sort_order','teacher_id'),
            'subjects' => array('subject_name','subject_code'),
            'users' => array('full_name','email','role','phone'),
            'attendance' => array('student_id','class_id','attendance_date','status','recorded_by'),
            'homework' => array('class_id','subject','description','due_date','posted_by'),
            'school_settings' => array('setting_key','setting_value'),
            'subjects' => array('subject_name','subject_code'),
            'users' => array('full_name','email','phone','role','status','password_hash','password_changed'),
            'fee_payments' => array('student_id','amount','payment_method','payment_date','status','receipt_number','reference_number'),
            'expenses' => array('category','description','amount','payment_method','expense_date','notes'),
            'fee_structure' => array('fee_type','amount','class_id','academic_year','currency'),
            'school_settings' => array('setting_key','setting_value'),
            'notifications' => array('user_id','type','title','message','is_read'),
        );
        $cols = isset($allowed[$entity]) ? $allowed[$entity] : array();
        $out = array();
        foreach ($cols as $c) {
            if (array_key_exists($c, $payload)) {
                $out[$c] = $payload[$c];
            }
        }
        return $out;
    }
}
