<?php
/**
 * Client-side sync orchestrator: local SQLite queue ↔ remote API.
 * Safe to call repeatedly; uses op_id idempotency on server.
 */
class SyncEngine {
    private $sqlite;
    private $remoteUrl;
    private $authToken;

    public function __construct($remoteUrl = null, $authToken = null) {
        require_once __DIR__ . '/SyncConfig.php';
        require_once __DIR__ . '/DeviceIdentity.php';
        require_once __DIR__ . '/SqliteStore.php';
        $this->sqlite = new SqliteStore();
        $this->remoteUrl = $remoteUrl !== null ? $remoteUrl : SyncConfig::remoteBaseUrl();
        $this->authToken = $authToken;
    }

    public function isRemoteReachable($timeout = 3) {
        $url = $this->healthUrl();
        if (!$url) return false;
        $ctx = stream_context_create(array(
            'http' => array(
                'method' => 'GET',
                'timeout' => $timeout,
                'ignore_errors' => true,
                'header' => "Accept: application/json\r\n",
            ),
        ));
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false) return false;
        $j = json_decode($body, true);
        return is_array($j) && !empty($j['success']);
    }

    private function healthUrl() {
        if ($this->remoteUrl) {
            return rtrim($this->remoteUrl, '/') . '/api/sync.php?action=health';
        }
        // Same-server default
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
        $base = dirname(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/nsms/api')));
        // Prefer absolute path style used by NSMS
        return $scheme . '://' . $host . '/nsms/api/sync.php?action=health';
    }

    /**
     * @param bool|null $knownDbConnected If the caller already knows whether MySQL
     *   is reachable (e.g. api/sync.php already did $db->connect() before calling
     *   this), pass that result directly instead of re-checking via HTTP self-call.
     *   The self-call (isRemoteReachable()) makes this process fetch its own health
     *   endpoint over HTTP, which depends on allow_url_fopen being enabled, the
     *   hardcoded '/nsms/' path prefix matching the real deployment path, and enough
     *   server concurrency to serve a request from within a request. Any one of
     *   those failing makes this permanently report "offline" even when MySQL is
     *   perfectly reachable — which silently disables automatic sync client-side,
     *   since autoSyncIfNeeded() in nsms-sync-status.js only fires when online=true.
     *   Passing the already-known DB state avoids all of that. isRemoteReachable()
     *   is kept for callers that genuinely have no other way to know (e.g. checking
     *   reachability of a *different* remote server via NSMS_REMOTE_SYNC_URL).
     */
    public function status($knownDbConnected = null) {
        $this->sqlite->connect();
        $online = ($knownDbConnected !== null) ? (bool)$knownDbConnected : $this->isRemoteReachable();
        $pending = $this->sqlite->pendingCount();
        $last = $this->sqlite->getMeta('last_sync_at', '');
        $failed = $this->sqlite->connect()->query(
            "SELECT COUNT(*) FROM sync_queue WHERE status = 'failed'"
        )->fetchColumn();
        return array(
            'online' => $online,
            'pending' => (int)$pending,
            'failed' => (int)$failed,
            'last_sync_at' => $last,
            'device_uuid' => DeviceIdentity::getUuid(),
            'pull_cursor' => $this->sqlite->getMeta('pull_cursor', '0'),
            'state' => !$online ? 'offline' : ($pending > 0 ? 'pending' : 'synced'),
        );
    }

    public function runFullSync() {
        if (!$this->isRemoteReachable()) {
            return array('success' => false, 'error' => 'Remote unreachable', 'state' => 'offline');
        }
        $push = $this->pushPending();
        $pull = $this->pullRemote();
        $this->sqlite->setMeta('last_sync_at', date('c'));
        return array(
            'success' => true,
            'push' => $push,
            'pull' => $pull,
            'status' => $this->status(),
        );
    }

    public function pushPending($syncMysql = null) {
        try {
            $this->sqlite->connect()->exec("UPDATE sync_queue SET status = 'pending', error_message = NULL WHERE status = 'failed'");
        } catch (Exception $e) {}
        $batch = $this->sqlite->pendingQueue(SyncConfig::batchSize());
        $uploaded = 0;
        $failed = 0;
        $device = DeviceIdentity::getUuid();
        $results = array();
        foreach ($batch as $row) {
            $op = array(
                'op_id' => $row['op_id'],
                'entity_type' => $row['entity_type'],
                'record_uuid' => $row['record_uuid'],
                'operation' => $row['operation'],
                'payload' => is_string($row['payload']) ? json_decode($row['payload'], true) : $row['payload'],
                'device_uuid' => $device,
            );
            $ok = false;
            $err = 'Push failed';
            if ($syncMysql && method_exists($syncMysql, 'applyPushOp')) {
                $r = $syncMysql->applyPushOp($op);
                $ok = !empty($r['ok']);
                $err = isset($r['error']) ? $r['error'] : $err;
                $results[] = $r;
            } else {
                $res = $this->postJson('push', array('operations' => array($op)));
                if ($res && !empty($res['success'])) {
                    $ok = true;
                } else {
                    $err = $res && isset($res['error']) ? $res['error'] : $err;
                }
            }
            if ($ok) {
                $this->sqlite->markQueue($row['id'], 'synced', null);
                $uploaded++;
            } else {
                $this->sqlite->markQueue($row['id'], 'failed', $err);
                $failed++;
            }
        }
        return array('uploaded' => $uploaded, 'failed' => $failed, 'results' => $results);
    }

    public function pullRemote() {
        $cursor = (int)$this->sqlite->getMeta('pull_cursor', '0');
        $downloaded = 0;
        $device = DeviceIdentity::getUuid();
        $res = $this->postJson('pull', array(
            'cursor' => $cursor,
            'limit' => SyncConfig::batchSize(),
            'device_uuid' => $device,
        ));
        if (!$res || empty($res['success'])) {
            return array('downloaded' => 0, 'error' => $res['error'] ?? 'Pull failed');
        }
        $changes = isset($res['data']['changes']) ? $res['data']['changes'] : array();
        $maxId = $cursor;
        $pdo = $this->sqlite->connect();
        foreach ($changes as $ch) {
            $this->applyRemoteChange($pdo, $ch);
            $downloaded++;
            if ((int)$ch['id'] > $maxId) $maxId = (int)$ch['id'];
        }
        $this->sqlite->setMeta('pull_cursor', (string)$maxId);
        return array('downloaded' => $downloaded, 'cursor' => $maxId);
    }

    private function applyRemoteChange($pdo, $ch) {
        $entity = $ch['entity_type'];
        $uuid = $ch['record_uuid'];
        $op = strtoupper($ch['operation']);
        $payload = json_decode($ch['payload_json'], true);
        if (!is_array($payload)) $payload = array();
        if (!in_array($entity, SyncConfig::entities(), true)) return;

        if ($op === 'DELETE') {
            $st = $pdo->prepare("UPDATE `$entity` SET deleted_at = ? WHERE uuid = ?");
            $st->execute(array(date('c'), $uuid));
            return;
        }
        // upsert local
        $st = $pdo->prepare("SELECT id FROM `$entity` WHERE uuid = ?");
        $st->execute(array($uuid));
        $exists = $st->fetch();
        if ($entity === 'students') {
            if ($exists) {
                $st = $pdo->prepare('UPDATE students SET student_name=?, class_id=?, parent_id=?, gender=?, date_of_birth=?, status=?, updated_at=?, deleted_at=NULL, sync_version=COALESCE(sync_version,0)+1 WHERE uuid=?');
                $st->execute(array(
                    $payload['student_name'] ?? null,
                    $payload['class_id'] ?? null,
                    $payload['parent_id'] ?? null,
                    $payload['gender'] ?? null,
                    $payload['date_of_birth'] ?? null,
                    $payload['status'] ?? 'active',
                    date('c'),
                    $uuid,
                ));
            } else {
                $st = $pdo->prepare('INSERT INTO students (uuid, student_name, class_id, parent_id, gender, date_of_birth, status, updated_at, sync_version) VALUES (?,?,?,?,?,?,?,?,1)');
                $st->execute(array(
                    $uuid,
                    $payload['student_name'] ?? null,
                    $payload['class_id'] ?? null,
                    $payload['parent_id'] ?? null,
                    $payload['gender'] ?? null,
                    $payload['date_of_birth'] ?? null,
                    $payload['status'] ?? 'active',
                    date('c'),
                ));
            }
        } elseif ($entity === 'classes') {
            if ($exists) {
                $st = $pdo->prepare('UPDATE classes SET class_name=?, capacity=?, minimum_age=?, sort_order=?, teacher_id=?, updated_at=?, deleted_at=NULL WHERE uuid=?');
                $st->execute(array(
                    $payload['class_name'] ?? null,
                    $payload['capacity'] ?? null,
                    $payload['minimum_age'] ?? null,
                    $payload['sort_order'] ?? null,
                    $payload['teacher_id'] ?? null,
                    date('c'),
                    $uuid,
                ));
            } else {
                $st = $pdo->prepare('INSERT INTO classes (uuid, class_name, capacity, minimum_age, sort_order, teacher_id, updated_at, sync_version) VALUES (?,?,?,?,?,?,?,1)');
                $st->execute(array(
                    $uuid,
                    $payload['class_name'] ?? null,
                    $payload['capacity'] ?? null,
                    $payload['minimum_age'] ?? null,
                    $payload['sort_order'] ?? null,
                    $payload['teacher_id'] ?? null,
                    date('c'),
                ));
            }
        }
        // other entities can be extended similarly
    }

    private function postJson($action, $body) {
        $url = $this->endpoint($action);
        $headers = "Content-Type: application/json\r\nAccept: application/json\r\n";
        if ($this->authToken) {
            $headers .= 'Authorization: Bearer ' . $this->authToken . "\r\n";
        }
        // Cookie session for same-origin
        if (!empty($_COOKIE)) {
            $parts = array();
            foreach ($_COOKIE as $k => $v) {
                $parts[] = $k . '=' . $v;
            }
            $headers .= 'Cookie: ' . implode('; ', $parts) . "\r\n";
        }
        $ctx = stream_context_create(array(
            'http' => array(
                'method' => 'POST',
                'header' => $headers,
                'content' => json_encode($body),
                'timeout' => 30,
                'ignore_errors' => true,
            ),
        ));
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw === false) return null;
        return json_decode($raw, true);
    }

    private function endpoint($action) {
        if ($this->remoteUrl) {
            return rtrim($this->remoteUrl, '/') . '/api/sync.php?action=' . urlencode($action);
        }
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
        return $scheme . '://' . $host . '/nsms/api/sync.php?action=' . urlencode($action);
    }
}
