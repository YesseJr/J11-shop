<?php
/**
 * Offline-first admin operations against local SQLite.
 * Online path remains MySQL; these methods are used when MySQL is unreachable.
 */
class OfflineAdmin {
    private static function pdo() {
        require_once __DIR__ . '/SyncConfig.php';
        require_once __DIR__ . '/SqliteStore.php';
        require_once __DIR__ . '/DeviceIdentity.php';
        $store = new SqliteStore();
        $pdo = $store->connect();
        self::ensureExtraSchema($pdo);
        return $pdo;
    }

    private static function store() {
        require_once __DIR__ . '/SqliteStore.php';
        require_once __DIR__ . '/DeviceIdentity.php';
        return new SqliteStore();
    }

    private static function ensureExtraSchema($pdo) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS fee_payments_local (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT UNIQUE NOT NULL,
            student_id INTEGER,
            student_name TEXT,
            class_id INTEGER,
            amount REAL NOT NULL,
            payment_method TEXT DEFAULT 'Cash',
            payment_date TEXT,
            recorded_by INTEGER,
            notes TEXT,
            status TEXT DEFAULT 'confirmed',
            sync_status TEXT DEFAULT 'pending',
            created_at TEXT,
            updated_at TEXT
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS activity_log_local (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT UNIQUE,
            type TEXT,
            title TEXT,
            description TEXT,
            user_id INTEGER,
            created_at TEXT
        )");
        foreach (array(
            "ALTER TABLE students ADD COLUMN enrollment_date TEXT",
            "ALTER TABLE students ADD COLUMN address TEXT",
            "ALTER TABLE students ADD COLUMN photo_url TEXT",
            "ALTER TABLE students ADD COLUMN parent_name TEXT",
            "ALTER TABLE students ADD COLUMN parent_phone TEXT",
            "ALTER TABLE students ADD COLUMN parent_email TEXT",
            "ALTER TABLE students ADD COLUMN parent_relationship TEXT",
            "ALTER TABLE students ADD COLUMN sync_status TEXT DEFAULT 'synced'",
            "ALTER TABLE teachers_cache ADD COLUMN uuid TEXT",
            "ALTER TABLE teachers_cache ADD COLUMN sync_status TEXT",
        ) as $sql) {
            try { $pdo->exec($sql); } catch (Exception $e) {}
        }
    }

    public static function logActivity($type, $title, $description = '', $userId = null) {
        try {
            $pdo = self::pdo();
            $uuid = DeviceIdentity::generateUuid();
            $st = $pdo->prepare(
                "INSERT INTO activity_log_local (uuid, type, title, description, user_id, created_at) VALUES (?,?,?,?,?,?)"
            );
            $st->execute(array($uuid, $type, $title, $description, $userId, date('c')));
        } catch (Exception $e) {
            error_log('OfflineAdmin::logActivity ' . $e->getMessage());
        }
    }

    public static function recentActivity($limit = 20) {
        $pdo = self::pdo();
        $st = $pdo->prepare("SELECT * FROM activity_log_local ORDER BY id DESC LIMIT ?");
        $st->bindValue(1, (int)$limit, PDO::PARAM_INT);
        $st->execute();
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $out = array();
        foreach ($rows as $r) {
            $out[] = array(
                'type' => $r['type'],
                'title' => $r['title'],
                'description' => $r['description'],
                'created_at' => $r['created_at'],
            );
        }
        if (!$out) {
            $out[] = array(
                'type' => 'system',
                'title' => 'Working offline',
                'description' => 'Local SQLite cache is active. Changes will sync when MySQL is back.',
                'created_at' => date('c'),
            );
        }
        return $out;
    }

    public static function enrollmentTrends($periodDays = 30) {
        $pdo = self::pdo();
        $periodDays = (int)$periodDays;
        if (!in_array($periodDays, array(7, 30, 90, 180), true)) {
            $periodDays = 30;
        }
        $periodStart = date('Y-m-d', strtotime("-{$periodDays} days"));
        $out = array();

        try {
            if ($periodDays <= 30) {
                $st = $pdo->prepare(
                    "SELECT date(COALESCE(enrollment_date, substr(updated_at,1,10))) AS day,
                            COUNT(*) AS count
                       FROM students
                      WHERE id > 0
                        AND (deleted_at IS NULL OR deleted_at = '')
                        AND IFNULL(status, 'active') = 'active'
                        AND IFNULL(sync_status, '') != 'duplicate'
                        AND date(COALESCE(enrollment_date, substr(updated_at,1,10))) >= date(?)
                   GROUP BY day
                   ORDER BY day ASC"
                );
                $st->execute(array($periodStart));
                $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: array();
                foreach ($rows as $r) {
                    $ts = strtotime($r['day']);
                    $out[] = array(
                        'month' => $r['day'],
                        'month_name' => date('d M', $ts),
                        'count' => (int)$r['count'],
                    );
                }
            } else {
                $st = $pdo->prepare(
                    "SELECT substr(COALESCE(enrollment_date, updated_at), 1, 7) AS month,
                            COUNT(*) AS count
                       FROM students
                      WHERE id > 0
                        AND (deleted_at IS NULL OR deleted_at = '')
                        AND IFNULL(status, 'active') = 'active'
                        AND IFNULL(sync_status, '') != 'duplicate'
                        AND date(COALESCE(enrollment_date, substr(updated_at,1,10))) >= date(?)
                   GROUP BY month
                   ORDER BY month ASC"
                );
                $st->execute(array($periodStart));
                $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: array();
                foreach ($rows as $r) {
                    $ts = strtotime($r['month'] . '-01');
                    $out[] = array(
                        'month' => $r['month'],
                        'month_name' => date('M', $ts),
                        'count' => (int)$r['count'],
                    );
                }
            }
        } catch (Exception $e) {
            error_log('offline enrollmentTrends: ' . $e->getMessage());
        }
        return $out;
    }

    /**
 matching online getOverviewStats shape.
     */
    public static function analyticsOverview($periodDays = 30) {
        $pdo = self::pdo();
        $periodDays = max(1, (int)$periodDays);
        $periodStart = date('Y-m-d', strtotime("-{$periodDays} days"));

        $totalStudents = 0;
        $studentsThisPeriod = 0;
        $totalTeachers = 0;
        $avgAttendance = 0.0;
        $enrollmentGrowth = 0.0;

        try {
            $totalStudents = (int)$pdo->query(
                "SELECT COUNT(*) FROM students
                  WHERE id > 0
                    AND (deleted_at IS NULL OR deleted_at = '')
                    AND IFNULL(status, 'active') = 'active'
                    AND IFNULL(sync_status, '') != 'duplicate'"
            )->fetchColumn();
        } catch (Exception $e) {}

        try {
            $st = $pdo->prepare(
                "SELECT COUNT(*) FROM students
                  WHERE id > 0
                    AND (deleted_at IS NULL OR deleted_at = '')
                    AND IFNULL(status, 'active') = 'active'
                    AND IFNULL(sync_status, '') != 'duplicate'
                    AND date(COALESCE(enrollment_date, updated_at)) >= date(?)"
            );
            $st->execute(array($periodStart));
            $studentsThisPeriod = (int)$st->fetchColumn();
        } catch (Exception $e) {}

        try {
            $totalTeachers = (int)$pdo->query("SELECT COUNT(*) FROM teachers_cache")->fetchColumn();
            if ($totalTeachers <= 0) {
                $totalTeachers = (int)$pdo->query(
                    "SELECT COUNT(DISTINCT teacher_id) FROM classes WHERE teacher_id IS NOT NULL AND teacher_id != 0"
                )->fetchColumn();
            }
        } catch (Exception $e) {}

        try {
            $st = $pdo->prepare(
                "SELECT SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present,
                        COUNT(*) AS total
                   FROM attendance
                  WHERE attendance_date >= date(?)"
            );
            $st->execute(array($periodStart));
            $row = $st->fetch(PDO::FETCH_ASSOC);
            if ($row && (int)$row['total'] > 0) {
                $avgAttendance = round(((int)$row['present'] / (int)$row['total']) * 100, 1);
            }
        } catch (Exception $e) {}

        // enrollment growth vs prior equal window
        try {
            $priorEnd = $periodStart;
            $priorStart = date('Y-m-d', strtotime("-" . ($periodDays * 2) . " days"));
            $st = $pdo->prepare(
                "SELECT COUNT(*) FROM students
                  WHERE id > 0
                    AND (deleted_at IS NULL OR deleted_at = '')
                    AND IFNULL(status, 'active') = 'active'
                    AND IFNULL(sync_status, '') != 'duplicate'
                    AND date(COALESCE(enrollment_date, updated_at)) >= date(?)
                    AND date(COALESCE(enrollment_date, updated_at)) < date(?)"
            );
            $st->execute(array($priorStart, $priorEnd));
            $priorCount = (int)$st->fetchColumn();
            if ($priorCount > 0) {
                $raw = round((($studentsThisPeriod - $priorCount) / $priorCount) * 100, 1);
                $enrollmentGrowth = max(-100, min(100, $raw));
            } else {
                $enrollmentGrowth = $studentsThisPeriod > 0 ? 100.0 : 0.0;
            }
        } catch (Exception $e) {}

        // Fee collection from FEE STRUCTURE × active students (same as online getFeeCollectionOverview)
        $collected = 0.0;
        $expected = 0.0;
        try {
            self::ensureFinanceTables($pdo);
            try {
                $pdo->exec(
                    "DELETE FROM fee_payments_local
                      WHERE sync_status = 'pending'
                        AND EXISTS (
                          SELECT 1 FROM fee_payments_local s
                           WHERE s.sync_status = 'synced'
                             AND s.student_id = fee_payments_local.student_id
                             AND ABS(s.amount - fee_payments_local.amount) < 0.01
                             AND substr(s.payment_date,1,10) = substr(fee_payments_local.payment_date,1,10)
                             AND IFNULL(s.payment_method,'') = IFNULL(fee_payments_local.payment_method,'')
                        )"
                );
            } catch (Exception $e) {}

            $collected = (float)$pdo->query(
                "SELECT COALESCE(SUM(p.amount),0)
                   FROM fee_payments_local p
                   JOIN students s ON s.id = p.student_id
                  WHERE IFNULL(p.status,'confirmed') = 'confirmed'
                    AND s.id > 0
                    AND IFNULL(s.status,'active') = 'active'
                    AND (s.deleted_at IS NULL OR s.deleted_at = '')
                    AND IFNULL(s.sync_status,'') != 'duplicate'"
            )->fetchColumn();
        } catch (Exception $e) {}

        try {
            $schoolWideOneTime = 0.0;
            $perClassOneTime = array();
            $classSchoolFees = array();
            $feeRows = $pdo->query("SELECT fee_type, amount, class_id FROM fee_structure_cache")->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($feeRows as $f) {
                $ft = isset($f['fee_type']) ? $f['fee_type'] : '';
                $amt = isset($f['amount']) ? (float)$f['amount'] : 0.0;
                $cid = isset($f['class_id']) && $f['class_id'] !== '' && $f['class_id'] !== null ? (int)$f['class_id'] : null;
                if ($ft === 'Transport') {
                    continue;
                }
                if ($ft === 'School Fees') {
                    if ($cid !== null) $classSchoolFees[$cid] = $amt;
                    continue;
                }
                if ($cid === null) {
                    $schoolWideOneTime += $amt;
                } else {
                    if (!isset($perClassOneTime[$cid])) $perClassOneTime[$cid] = 0.0;
                    $perClassOneTime[$cid] += $amt;
                }
            }

            $classCounts = array();
            $students = $pdo->query(
                "SELECT id, class_id FROM students
                  WHERE id > 0 AND IFNULL(status,'active') = 'active'
                    AND (deleted_at IS NULL OR deleted_at = '')
                    AND IFNULL(sync_status,'') != 'duplicate'"
            )->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($students as $s) {
                $cid = isset($s['class_id']) ? (int)$s['class_id'] : 0;
                if (!isset($classCounts[$cid])) $classCounts[$cid] = 0;
                $classCounts[$cid]++;
            }

            $oneTimeDue = 0.0;
            $schoolFeesDue = 0.0;
            foreach ($classCounts as $cid => $n) {
                $extra = isset($perClassOneTime[$cid]) ? $perClassOneTime[$cid] : 0.0;
                $oneTimeDue    += $n * ($schoolWideOneTime + $extra);
                $schoolFeesDue += $n * (isset($classSchoolFees[$cid]) ? $classSchoolFees[$cid] : 0.0);
            }
            $expected = $oneTimeDue + $schoolFeesDue;
        } catch (Exception $e) {}

        $rate = 0;
        if ($expected > 0) {
            $rate = (int)min(100, round(($collected / $expected) * 100));
        } elseif ($collected > 0) {
            $rate = 100;
        }


        return array(
            'total_students' => $totalStudents,
            'students_this_month' => $studentsThisPeriod,
            'period_days' => $periodDays,
            'total_teachers' => $totalTeachers,
            'avg_attendance' => $avgAttendance,
            'fee_collection_rate' => $rate,
            'collected_amount' => $collected,
            'expected_revenue' => $expected,
            'enrollment_growth' => $enrollmentGrowth,
            'offline_mode' => true,
            'message' => 'Offline analytics from local SQLite cache',
        );
    }

    public static function classDistribution() {
        $pdo = self::pdo();
        $rows = array();
        try {
            $rows = $pdo->query(
                "SELECT c.id,
                        c.class_name,
                        COALESCE(c.class_color, '#2563EB') AS class_color,
                        COALESCE(c.capacity, 40) AS capacity,
                        COUNT(s.id) AS student_count
                   FROM classes c
              LEFT JOIN students s
                     ON s.class_id = c.id
                    AND s.id > 0
                    AND (s.deleted_at IS NULL OR s.deleted_at = '')
                    AND IFNULL(s.status, 'active') = 'active'
                    AND IFNULL(s.sync_status, '') != 'duplicate'
                  WHERE c.id > 0
                    AND (c.deleted_at IS NULL OR c.deleted_at = '')
               GROUP BY c.id, c.class_name, c.class_color, c.capacity
               ORDER BY COALESCE(c.sort_order, c.id), c.class_name"
            )->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($rows as &$r) {
                $r['student_count'] = (int)$r['student_count'];
                $r['capacity'] = (int)(isset($r['capacity']) ? $r['capacity'] : 40);
                $r['count'] = $r['student_count']; // alias
                $r['name'] = $r['class_name'];
            }
            unset($r);
        } catch (Exception $e) {
            error_log('offline classDistribution: ' . $e->getMessage());
        }
        return $rows;
    }



    public static function createStudent($data, $userId = null) {
        $pdo = self::pdo();
        $uuid = DeviceIdentity::generateUuid();
        $name = isset($data['student_name']) ? trim($data['student_name']) : '';
        if ($name === '') throw new Exception('Student name is required');
        $classId = isset($data['class_id']) ? (int)$data['class_id'] : null;
        $gender = isset($data['gender']) ? trim($data['gender']) : 'Male';
        $gLower = strtolower($gender);
        if ($gLower === 'male' || $gLower === 'm') $gender = 'Male';
        elseif ($gLower === 'female' || $gLower === 'f') $gender = 'Female';
        else $gender = 'Male';
        $dob = isset($data['date_of_birth']) ? $data['date_of_birth'] : null;
        $enroll = isset($data['enrollment_date']) && $data['enrollment_date'] !== ''
            ? $data['enrollment_date'] : date('Y-m-d');
        if (!$classId || (int)$classId < 1) {
            // Prefer first local class so sync has a usable class_id
            try {
                $cid = (int)$pdo->query("SELECT id FROM classes WHERE id > 0 ORDER BY id ASC LIMIT 1")->fetchColumn();
                if ($cid > 0) $classId = $cid;
            } catch (Exception $e) {}
        }
        $localId = (int)$pdo->query("SELECT COALESCE(MIN(id),0) FROM students")->fetchColumn();
        $localId = ($localId >= 0) ? -1 : ($localId - 1);
        $pdo->prepare(
            "INSERT INTO students (id, uuid, student_name, class_id, gender, date_of_birth, status, enrollment_date, address,
              parent_name, parent_phone, parent_email, parent_relationship, updated_at, sync_version, sync_status)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'pending')"
        )->execute(array(
            $localId, $uuid, $name, $classId, $gender, $dob, 'active', $enroll, $address,
            $parentName, $parentPhone, $parentEmail, $parentRel, date('c'), 1
        ));
        $payload = array(
            'uuid' => $uuid,
            'student_name' => $name,
            'class_id' => $classId,
            'gender' => $gender,
            'date_of_birth' => $dob,
            'status' => 'active',
            'enrollment_date' => $enroll,
            'address' => $address,
            'parent_name' => $parentName,
            'parent_phone' => $parentPhone,
            'parent_email' => $parentEmail,
            'parent_relationship' => $parentRel,
            'local_id' => $localId,
        );
        self::store()->enqueue('students', $uuid, 'CREATE', $payload);
        self::logActivity('student', 'Student registered (offline)', $name, $userId);
        // Resolve class_name for immediate UI
        $className = null;
        try {
            $cst = $pdo->prepare('SELECT class_name FROM classes WHERE id = ?');
            $cst->execute(array($classId));
            $cr = $cst->fetch(PDO::FETCH_ASSOC);
            if ($cr) $className = $cr['class_name'];
        } catch (Exception $e) {}
        return array(
            'id' => $localId,
            'uuid' => $uuid,
            'student_name' => $name,
            'class_id' => $classId,
            'class_name' => $className,
            'gender' => $gender,
            'date_of_birth' => $dob,
            'enrollment_date' => $enroll,
            'address' => $address,
            'parent_name' => $parentName,
            'parent_phone' => $parentPhone,
            'parent_email' => $parentEmail,
            'parent_relationship' => $parentRel,
            'status' => 'active',
            'offline_mode' => true,
            'sync_status' => 'pending',
        );
    }

    public static function updateStudent($id, $data, $userId = null) {
        $pdo = self::pdo();
        $st = $pdo->prepare("SELECT * FROM students WHERE id = ? LIMIT 1");
        $st->execute(array((int)$id));
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new Exception('Student not found in offline cache');
        $uuid = !empty($row['uuid']) ? $row['uuid'] : DeviceIdentity::generateUuid();
        $name = array_key_exists('student_name', $data) ? trim($data['student_name']) : $row['student_name'];
        $classId = array_key_exists('class_id', $data) ? (int)$data['class_id'] : $row['class_id'];
        $gender = array_key_exists('gender', $data) ? $data['gender'] : $row['gender'];
        $status = array_key_exists('status', $data) ? $data['status'] : $row['status'];
        $address = array_key_exists('address', $data) ? $data['address'] : (isset($row['address']) ? $row['address'] : null);
        $dob = array_key_exists('date_of_birth', $data) ? $data['date_of_birth'] : (isset($row['date_of_birth']) ? $row['date_of_birth'] : null);
        $enroll = array_key_exists('enrollment_date', $data) ? $data['enrollment_date'] : (isset($row['enrollment_date']) ? $row['enrollment_date'] : null);
        $parentName = array_key_exists('parent_name', $data) ? $data['parent_name'] : (isset($row['parent_name']) ? $row['parent_name'] : null);
        $parentPhone = array_key_exists('parent_phone', $data) ? $data['parent_phone'] : (isset($row['parent_phone']) ? $row['parent_phone'] : null);
        $parentEmail = array_key_exists('parent_email', $data) ? $data['parent_email'] : (isset($row['parent_email']) ? $row['parent_email'] : null);
        $parentRel = array_key_exists('parent_relationship', $data) ? $data['parent_relationship'] : (isset($row['parent_relationship']) ? $row['parent_relationship'] : null);
        $pdo->prepare(
            "UPDATE students SET uuid=?, student_name=?, class_id=?, gender=?, status=?, date_of_birth=?, enrollment_date=?, address=?,
              parent_name=?, parent_phone=?, parent_email=?, parent_relationship=?, updated_at=?, sync_status='pending' WHERE id=?"
        )->execute(array($uuid, $name, $classId, $gender, $status, $dob, $enroll, $address, $parentName, $parentPhone, $parentEmail, $parentRel, date('c'), (int)$id));
        $payload = array(
            'uuid' => $uuid, 'id' => (int)$id, 'student_name' => $name, 'class_id' => $classId,
            'gender' => $gender, 'status' => $status, 'date_of_birth' => $dob, 'enrollment_date' => $enroll,
            'address' => $address, 'parent_name' => $parentName, 'parent_phone' => $parentPhone,
            'parent_email' => $parentEmail, 'parent_relationship' => $parentRel,
        );
        self::store()->enqueue('students', $uuid, 'UPDATE', $payload);
        self::logActivity('student', 'Student updated (offline)', $name, $userId);
        return array('id' => (int)$id, 'uuid' => $uuid, 'offline_mode' => true, 'sync_status' => 'pending');
    }

    public static function createTeacher($data, $userId = null) {
        $pdo = self::pdo();
        $pdo->exec("CREATE TABLE IF NOT EXISTS teachers_cache (
            id INTEGER PRIMARY KEY, user_id INTEGER, full_name TEXT, email TEXT, phone TEXT,
            status TEXT, photo_url TEXT, class_id INTEGER, class_name TEXT, class_color TEXT,
            subjects TEXT, subject_ids TEXT, uuid TEXT, sync_status TEXT, updated_at TEXT
        )");
        self::ensureExtraSchema($pdo);
        foreach (array('photo_url TEXT','class_id INTEGER','class_name TEXT','class_color TEXT','subjects TEXT','subject_ids TEXT') as $def) {
            try { $pdo->exec('ALTER TABLE teachers_cache ADD COLUMN ' . $def); } catch (Exception $e) {}
        }
        $uuid = DeviceIdentity::generateUuid();
        $name = isset($data['full_name']) ? trim($data['full_name']) : (isset($data['name']) ? trim($data['name']) : '');
        $email = isset($data['email']) ? strtolower(trim($data['email'])) : '';
        if ($name === '' || $email === '') throw new Exception('Teacher name and email are required');
        // Unique email offline
        $dup = $pdo->prepare("SELECT id FROM teachers_cache WHERE lower(email) = ? AND IFNULL(status,'active') != 'inactive' LIMIT 1");
        $dup->execute(array($email));
        if ($dup->fetch()) throw new Exception('A teacher with this email already exists offline');
        $phone = isset($data['phone']) ? trim($data['phone']) : null;
        $classId = isset($data['class_id']) ? (int)$data['class_id'] : (isset($data['classIds']) ? (int)$data['classIds'] : 0);
        if (!$classId && !empty($data['class_ids'])) {
            $parts = is_array($data['class_ids']) ? $data['class_ids'] : explode(',', $data['class_ids']);
            $classId = (int)$parts[0];
        }
        $className = null; $classColor = null;
        if ($classId > 0) {
            try {
                $cst = $pdo->prepare('SELECT class_name, class_color FROM classes WHERE id = ?');
                $cst->execute(array($classId));
                $cr = $cst->fetch(PDO::FETCH_ASSOC);
                if ($cr) { $className = $cr['class_name']; $classColor = isset($cr['class_color']) ? $cr['class_color'] : null; }
            } catch (Exception $e) {}
        }
        $localId = (int)$pdo->query("SELECT COALESCE(MIN(id),0) FROM teachers_cache")->fetchColumn();
        $localId = ($localId >= 0) ? -1 : ($localId - 1);
        $pdo->prepare(
            "INSERT INTO teachers_cache (id, user_id, full_name, email, phone, status, class_id, class_name, class_color, uuid, sync_status, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
        )->execute(array($localId, $localId, $name, $email, $phone, 'active', $classId ?: null, $className, $classColor, $uuid, 'pending', date('c')));
        $payload = array(
            'uuid' => $uuid, 'full_name' => $name, 'email' => $email, 'phone' => $phone,
            'role' => 'teacher', 'status' => 'active', 'local_id' => $localId,
            'class_id' => $classId ?: null,
        );
        self::store()->enqueue('users', $uuid, 'CREATE', $payload);
        self::logActivity('teacher', 'Teacher registered (offline)', $name . ' <' . $email . '>', $userId);
        return array(
            'id' => $localId, 'uuid' => $uuid, 'full_name' => $name, 'email' => $email, 'phone' => $phone,
            'class_id' => $classId ?: null, 'class_name' => $className, 'class_color' => $classColor,
            'status' => 'active', 'offline_mode' => true, 'sync_status' => 'pending',
        );
    }

    public static function updateTeacher($id, $data, $userId = null) {
        $pdo = self::pdo();
        foreach (array('class_id INTEGER','class_name TEXT','class_color TEXT','photo_url TEXT') as $def) {
            try { $pdo->exec('ALTER TABLE teachers_cache ADD COLUMN ' . $def); } catch (Exception $e) {}
        }
        $st = $pdo->prepare("SELECT * FROM teachers_cache WHERE id = ? LIMIT 1");
        $st->execute(array((int)$id));
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new Exception('Teacher not found in offline cache');
        $uuid = !empty($row['uuid']) ? $row['uuid'] : DeviceIdentity::generateUuid();
        $name = array_key_exists('full_name', $data) ? trim($data['full_name']) : $row['full_name'];
        $email = array_key_exists('email', $data) ? strtolower(trim($data['email'])) : $row['email'];
        $phone = array_key_exists('phone', $data) ? $data['phone'] : $row['phone'];
        $classId = array_key_exists('class_id', $data) ? (int)$data['class_id'] : (isset($row['class_id']) ? (int)$row['class_id'] : 0);
        $className = isset($row['class_name']) ? $row['class_name'] : null;
        $classColor = isset($row['class_color']) ? $row['class_color'] : null;
        if ($classId > 0) {
            try {
                $cst = $pdo->prepare('SELECT class_name, class_color FROM classes WHERE id = ?');
                $cst->execute(array($classId));
                $cr = $cst->fetch(PDO::FETCH_ASSOC);
                if ($cr) { $className = $cr['class_name']; $classColor = isset($cr['class_color']) ? $cr['class_color'] : null; }
            } catch (Exception $e) {}
        }
        $pdo->prepare(
            "UPDATE teachers_cache SET uuid=?, full_name=?, email=?, phone=?, class_id=?, class_name=?, class_color=?, sync_status='pending', updated_at=? WHERE id=?"
        )->execute(array($uuid, $name, $email, $phone, $classId ?: null, $className, $classColor, date('c'), (int)$id));
        $payload = array(
            'uuid' => $uuid, 'id' => (int)$id, 'full_name' => $name, 'email' => $email, 'phone' => $phone,
            'role' => 'teacher', 'status' => isset($row['status']) ? $row['status'] : 'active',
            'class_id' => $classId ?: null,
        );
        self::store()->enqueue('users', $uuid, ((int)$id > 0 ? 'UPDATE' : 'CREATE'), $payload);
        self::logActivity('teacher', 'Teacher updated (offline)', $name, $userId);
        return array(
            'id' => (int)$id, 'uuid' => $uuid, 'full_name' => $name, 'email' => $email, 'phone' => $phone,
            'class_id' => $classId ?: null, 'class_name' => $className, 'class_color' => $classColor,
            'offline_mode' => true, 'sync_status' => 'pending',
        );
    }


    public static function ensureFinanceTables($pdo) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS fee_payments_local (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT UNIQUE,
            student_id INTEGER,
            student_name TEXT,
            class_id INTEGER,
            amount REAL,
            payment_method TEXT,
            payment_date TEXT,
            recorded_by INTEGER,
            notes TEXT,
            status TEXT DEFAULT 'confirmed',
            receipt_number TEXT,
            sync_status TEXT DEFAULT 'pending',
            created_at TEXT,
            updated_at TEXT
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS expenses_local (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT UNIQUE,
            category TEXT,
            description TEXT,
            amount REAL,
            payment_method TEXT,
            expense_date TEXT,
            recorded_by INTEGER,
            notes TEXT,
            sync_status TEXT DEFAULT 'pending',
            created_at TEXT,
            updated_at TEXT
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS fee_installments_local (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT UNIQUE,
            student_id INTEGER,
            academic_year TEXT,
            fee_type TEXT,
            installment_no INTEGER,
            amount_due REAL,
            amount_paid REAL DEFAULT 0,
            status TEXT DEFAULT 'unpaid',
            sync_status TEXT DEFAULT 'synced',
            updated_at TEXT
        )");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_fi_local_student ON fee_installments_local(student_id)");

        $pdo->exec("CREATE TABLE IF NOT EXISTS fee_structure_cache (
            id INTEGER PRIMARY KEY,
            fee_type TEXT,
            amount REAL,
            class_id INTEGER,
            class_name TEXT,
            is_installment INTEGER DEFAULT 0,
            updated_at TEXT
        )");
    }

    public static function recordCashPayment($data, $userId = null) {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        $studentId = isset($data['student_id']) ? (int)$data['student_id'] : 0;
        if ($studentId < 1) throw new Exception('Student is required');
        $amount = isset($data['amount']) ? (float)$data['amount'] : 0;
        if ($amount <= 0) throw new Exception('Amount must be greater than zero');
        $method = isset($data['payment_method']) ? trim($data['payment_method']) : 'Cash';
        if ($method === '') $method = 'Cash';
        // Offline: only cash-like methods
        $allowed = array('Cash', 'cash', 'CASH', 'Bank Deposit', 'Bank', 'Cheque', 'Control Number');
        // Allow any string but default Cash for pure offline till
        if (stripos($method, 'm-pesa') !== false || stripos($method, 'mobile') !== false) {
            // still allow recording offline; will sync later
        }
        $date = isset($data['payment_date']) ? $data['payment_date'] : date('Y-m-d');
        if (strlen($date) > 10) $date = substr($date, 0, 10);
        $notes = isset($data['notes']) ? $data['notes'] : 'Offline payment';
        $studentName = isset($data['student_name']) ? $data['student_name'] : null;
        $classId = isset($data['class_id']) ? (int)$data['class_id'] : null;
        if (!$studentName || !$classId) {
            try {
                $st = $pdo->prepare('SELECT student_name, class_id FROM students WHERE id = ? LIMIT 1');
                $st->execute(array($studentId));
                $s = $st->fetch(PDO::FETCH_ASSOC);
                if ($s) {
                    if (!$studentName) $studentName = $s['student_name'];
                    if (!$classId) $classId = isset($s['class_id']) ? (int)$s['class_id'] : null;
                }
            } catch (Exception $e) {}
        }
        $uuid = DeviceIdentity::generateUuid();
        $receipt = 'OFF-' . strtoupper(substr(str_replace('-', '', $uuid), 0, 8));
        $pdo->prepare(
            "INSERT INTO fee_payments_local (uuid, student_id, student_name, class_id, amount, payment_method, payment_date, recorded_by, notes, status, receipt_number, sync_status, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?, 'pending', ?, ?)"
        )->execute(array(
            $uuid, $studentId, $studentName, $classId, $amount, $method, $date, $userId, $notes, 'confirmed', $receipt, date('c'), date('c')
        ));
        self::store()->enqueue('fee_payments', $uuid, 'CREATE', array(
            'uuid' => $uuid,
            'student_id' => $studentId,
            'amount' => $amount,
            'payment_method' => $method,
            'payment_date' => $date,
            'notes' => $notes,
            'status' => 'confirmed',
            'receipt_number' => $receipt,
        ));
        self::logActivity('payment', 'Payment received (offline)', ($studentName ?: ('Student #'.$studentId)) . ' — ' . $amount, $userId);
        return array(
            'uuid' => $uuid,
            'student_id' => $studentId,
            'student_name' => $studentName,
            'amount' => $amount,
            'payment_method' => $method,
            'payment_date' => $date,
            'receipt_number' => $receipt,
            'offline_mode' => true,
            'sync_status' => 'pending',
        );
    }

    public static function listPayments($limit = 100) {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        $limit = max(1, min(500, (int)$limit));
        $st = $pdo->prepare("SELECT * FROM fee_payments_local ORDER BY id DESC LIMIT ?");
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function recordExpense($data, $userId = null) {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        $amount = isset($data['amount']) ? (float)$data['amount'] : 0;
        if ($amount <= 0) throw new Exception('Expense amount must be greater than zero');
        $category = isset($data['category']) ? trim($data['category']) : 'General';
        if ($category === '') $category = 'General';
        $description = isset($data['description']) ? trim($data['description']) : (isset($data['title']) ? trim($data['title']) : '');
        $method = isset($data['payment_method']) ? $data['payment_method'] : 'Cash';
        $date = isset($data['expense_date']) ? $data['expense_date'] : (isset($data['date']) ? $data['date'] : date('Y-m-d'));
        if (strlen($date) > 10) $date = substr($date, 0, 10);
        $notes = isset($data['notes']) ? $data['notes'] : null;
        $uuid = DeviceIdentity::generateUuid();
        $pdo->prepare(
            "INSERT INTO expenses_local (uuid, category, description, amount, payment_method, expense_date, recorded_by, notes, sync_status, created_at, updated_at)
             VALUES (?,?,?,?,?,?,?,?, 'pending', ?, ?)"
        )->execute(array($uuid, $category, $description, $amount, $method, $date, $userId, $notes, date('c'), date('c')));
        self::store()->enqueue('expenses', $uuid, 'CREATE', array(
            'uuid' => $uuid,
            'category' => $category,
            'description' => $description,
            'amount' => $amount,
            'payment_method' => $method,
            'expense_date' => $date,
            'notes' => $notes,
        ));
        self::logActivity('expense', 'Expense recorded (offline)', $category . ' — ' . $amount, $userId);
        return array(
            'uuid' => $uuid,
            'category' => $category,
            'description' => $description,
            'amount' => $amount,
            'expense_date' => $date,
            'offline_mode' => true,
            'sync_status' => 'pending',
        );
    }

    public static function listExpenses($limit = 100) {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        $limit = max(1, min(500, (int)$limit));
        $st = $pdo->prepare("SELECT * FROM expenses_local ORDER BY id DESC LIMIT ?");
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function financeOverview($month = null) {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        try { $pdo->exec("ALTER TABLE fee_payments_local ADD COLUMN receipt_number TEXT"); } catch (Exception $e) {}
        // Remove only pending offline rows that already exist as synced (post-sync twins)
        try {
            $pdo->exec(
                "DELETE FROM fee_payments_local
                  WHERE sync_status = 'pending'
                    AND EXISTS (
                      SELECT 1 FROM fee_payments_local s
                       WHERE s.sync_status = 'synced'
                         AND s.student_id = fee_payments_local.student_id
                         AND ABS(s.amount - fee_payments_local.amount) < 0.01
                         AND substr(s.payment_date,1,10) = substr(fee_payments_local.payment_date,1,10)
                         AND IFNULL(s.payment_method,'') = IFNULL(fee_payments_local.payment_method,'')
                    )"
            );
        } catch (Exception $e) {}
        if ($month === null || $month === '') {
            $month = isset($_GET['month']) ? trim($_GET['month']) : date('Y-m');
        }
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) $month = date('Y-m');
        $year = substr($month, 0, 4);

        $totalRevenue = 0.0;
        $yearRevenue = 0.0;
        try {
            $st = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM fee_payments_local WHERE substr(payment_date,1,7) = ? AND IFNULL(status,'confirmed') = 'confirmed'");
            $st->execute(array($month));
            $totalRevenue = (float)$st->fetchColumn();
        } catch (Exception $e) {}
        try {
            $st = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM fee_payments_local WHERE substr(payment_date,1,4) = ? AND IFNULL(status,'confirmed') = 'confirmed'");
            $st->execute(array($year));
            $yearRevenue = (float)$st->fetchColumn();
        } catch (Exception $e) {}

        $scholarshipRevMonth = 0.0;
        $scholarshipCount = 0;
        $scholarshipRevYear = 0.0;
        try {
            $st = $pdo->prepare(
                "SELECT COALESCE(SUM(amount),0), COUNT(DISTINCT student_id)
                   FROM fee_payments_local
                  WHERE substr(payment_date,1,7) = ?
                    AND payment_method LIKE 'Scholarship%'
                    AND IFNULL(status,'confirmed') = 'confirmed'"
            );
            $st->execute(array($month));
            $row = $st->fetch(PDO::FETCH_NUM);
            if ($row) {
                $scholarshipRevMonth = (float)$row[0];
                $scholarshipCount = (int)$row[1];
            }
            $st = $pdo->prepare(
                "SELECT COALESCE(SUM(amount),0) FROM fee_payments_local
                  WHERE substr(payment_date,1,4) = ? AND payment_method LIKE 'Scholarship%'
                    AND IFNULL(status,'confirmed') = 'confirmed'"
            );
            $st->execute(array($year));
            $scholarshipRevYear = (float)$st->fetchColumn();
        } catch (Exception $e) {}

        $totalExpenses = 0.0;
        $breakdown = array();
        try {
            $st = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM expenses_local WHERE substr(expense_date,1,7) = ?");
            $st->execute(array($month));
            $totalExpenses = (float)$st->fetchColumn();
            $st = $pdo->prepare(
                "SELECT category, COALESCE(SUM(amount),0) AS amount
                   FROM expenses_local
                  WHERE substr(expense_date,1,7) = ?
               GROUP BY category ORDER BY amount DESC"
            );
            $st->execute(array($month));
            $breakdown = $st->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($breakdown as &$row) {
                $row['amount'] = (float)$row['amount'];
                $row['percentage'] = $totalExpenses > 0 ? round(($row['amount'] / $totalExpenses) * 100) : 0;
            }
            unset($row);
        } catch (Exception $e) {}

        $methods = array();
        try {
            $st = $pdo->prepare(
                "SELECT payment_method, COUNT(*) AS cnt, COALESCE(SUM(amount),0) AS total
                   FROM fee_payments_local
                  WHERE substr(payment_date,1,7) = ?
                    AND IFNULL(status,'confirmed') = 'confirmed'
               GROUP BY payment_method ORDER BY total DESC"
            );
            $st->execute(array($month));
            $methods = $st->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($methods as &$r) {
                $r['total'] = (float)$r['total'];
                $r['count'] = (int)$r['cnt'];
            }
            unset($r);
        } catch (Exception $e) {}

        $trend = array();
        try {
            $monthNames = array('01'=>'Jan','02'=>'Feb','03'=>'Mar','04'=>'Apr','05'=>'May','06'=>'Jun','07'=>'Jul','08'=>'Aug','09'=>'Sep','10'=>'Oct','11'=>'Nov','12'=>'Dec');
            $sums = array();
            $rows = $pdo->query(
                "SELECT substr(payment_date,1,7) AS month, COALESCE(SUM(amount),0) AS revenue
                   FROM fee_payments_local
                  WHERE IFNULL(status,'confirmed') = 'confirmed'
               GROUP BY substr(payment_date,1,7)"
            )->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($rows as $r) {
                $sums[$r['month']] = (float)$r['revenue'];
            }
            // Always pad last 6 calendar months so the chart has a stable shape online/offline
            for ($i = 5; $i >= 0; $i--) {
                $ts = strtotime(date('Y-m-01') . " -$i months");
                $ym = date('Y-m', $ts);
                $parts = explode('-', $ym);
                $label = $monthNames[$parts[1]] . ' ' . $parts[0];
                $trend[] = array(
                    'month' => $ym,
                    'label' => $label,
                    'revenue' => isset($sums[$ym]) ? (float)$sums[$ym] : 0.0,
                );
            }
        } catch (Exception $e) {}


        // Approximate outstanding balances offline from fee_structure_cache + local payments
        $pendingCount = 0;
        $pendingAmount = 0.0;
        try {
            $schoolWideOneTime = 0.0;
            $classSchoolFees = array();
            $feeRows = $pdo->query("SELECT fee_type, amount, class_id FROM fee_structure_cache")->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($feeRows as $f) {
                $ft = isset($f['fee_type']) ? $f['fee_type'] : '';
                $amt = isset($f['amount']) ? (float)$f['amount'] : 0;
                $cid = isset($f['class_id']) && $f['class_id'] !== '' && $f['class_id'] !== null ? (int)$f['class_id'] : null;
                if ($cid === null) {
                    if ($ft !== 'School Fees' && $ft !== 'Transport') $schoolWideOneTime += $amt;
                } else {
                    if ($ft === 'School Fees') $classSchoolFees[$cid] = $amt;
                }
            }
            $paidByStudent = array();
            foreach ($pdo->query(
                "SELECT student_id, COALESCE(SUM(amount),0) AS paid
                   FROM fee_payments_local
                  WHERE IFNULL(status,'confirmed') = 'confirmed'
               GROUP BY student_id"
            )->fetchAll(PDO::FETCH_ASSOC) as $pr) {
                $paidByStudent[(int)$pr['student_id']] = (float)$pr['paid'];
            }
            $students = $pdo->query(
                "SELECT id, class_id FROM students
                  WHERE id > 0
                    AND IFNULL(status,'active') = 'active'
                    AND (deleted_at IS NULL OR deleted_at = '')
                    AND IFNULL(sync_status,'') != 'duplicate'"
            )->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($students as $s) {
                $sid = (int)$s['id'];
                $cid = isset($s['class_id']) ? (int)$s['class_id'] : 0;
                $due = $schoolWideOneTime + (isset($classSchoolFees[$cid]) ? (float)$classSchoolFees[$cid] : 0);
                if ($due <= 0) continue;
                $paid = isset($paidByStudent[$sid]) ? $paidByStudent[$sid] : 0.0;
                $bal = max(0.0, $due - $paid);
                if ($bal > 0.009) {
                    $pendingCount++;
                    $pendingAmount += $bal;
                }
            }
        } catch (Exception $e) {
            $pendingCount = 0;
            $pendingAmount = 0.0;
        }

        return array(
            'month' => $month,
            'total_revenue' => $totalRevenue,
            'total_year_revenue' => $yearRevenue,
            'total_expenses' => $totalExpenses,
            'net_profit' => $totalRevenue - $totalExpenses,
            'pending_count' => $pendingCount,
            'pending_amount' => $pendingAmount,
            'scholarship_revenue' => $scholarshipRevMonth,
            'scholarship_year_revenue' => $scholarshipRevYear,
            'scholarship_count' => $scholarshipCount,
            'expense_breakdown' => $breakdown,
            'method_breakdown' => $methods,
            'revenue_trend' => $trend,
            'offline_mode' => true,
            'message' => 'Offline overview from local payments and expenses',
        );
    }

    public static function feeByClass() {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        try {
            $rows = $pdo->query(
                "SELECT class_id, SUM(amount) AS collected, COUNT(*) AS payments
                   FROM fee_payments_local
               GROUP BY class_id"
            )->fetchAll(PDO::FETCH_ASSOC);
            return $rows ?: array();
        } catch (Exception $e) {
            return array();
        }
    }


    public static function studentPaymentStatus($studentId) {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        $studentId = (int)$studentId;
        $student = null;
        try {
            $st = $pdo->prepare(
                "SELECT s.id, s.student_name, s.class_id, c.class_name, c.class_color
                   FROM students s
              LEFT JOIN classes c ON c.id = s.class_id
                  WHERE s.id = ? LIMIT 1"
            );
            $st->execute(array($studentId));
            $student = $st->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {}
        if (!$student) {
            throw new Exception('Student not found in offline cache');
        }
        $classId = isset($student['class_id']) ? (int)$student['class_id'] : 0;
        $yr = date('Y');

        // Fee totals from cache: school-wide + class School Fees
        $oneTimeMap = array();
        $oneTimeTotal = 0.0;
        $sfTotal = 0.0;
        try {
            $rows = $pdo->query("SELECT fee_type, amount, class_id FROM fee_structure_cache")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $f) {
                $cid = isset($f['class_id']) && $f['class_id'] !== '' && $f['class_id'] !== null ? (int)$f['class_id'] : null;
                $ft = isset($f['fee_type']) ? $f['fee_type'] : '';
                $amt = isset($f['amount']) ? (float)$f['amount'] : 0;
                if ($amt <= 0 || $ft === '') continue;
                if ($cid === null) {
                    if ($ft === 'School Fees' || $ft === 'Transport') continue;
                    $oneTimeMap[$ft] = $amt;
                    $oneTimeTotal += $amt;
                } elseif ($cid === $classId && $ft === 'School Fees') {
                    $sfTotal += $amt;
                }
            }
        } catch (Exception $e) {}

        $totalPaid = 0.0;
        try {
            $st = $pdo->prepare(
                "SELECT COALESCE(SUM(amount),0) FROM fee_payments_local WHERE student_id = ?"
            );
            $st->execute(array($studentId));
            $totalPaid = (float)$st->fetchColumn();
        } catch (Exception $e) {}

        $grandTotal = $oneTimeTotal + $sfTotal;
        $balance = ($grandTotal > 0) ? max(0, $grandTotal - $totalPaid) : 0;

        return array(
            'student_id' => $studentId,
            'student_name' => $student['student_name'],
            'class_id' => $classId,
            'class_name' => isset($student['class_name']) ? $student['class_name'] : null,
            'class_color' => isset($student['class_color']) ? $student['class_color'] : null,
            'academic_year' => $yr,
            'discount_pct' => 0,
            'one_time_fees' => $oneTimeMap,
            'one_time_total' => $oneTimeTotal,
            'one_time_paid' => min($totalPaid, $oneTimeTotal),
            'one_time_owed' => max(0, $oneTimeTotal - min($totalPaid, $oneTimeTotal)),
            'installments' => array(),
            'install_total' => $sfTotal,
            'install_paid' => max(0, min($totalPaid - min($totalPaid, $oneTimeTotal), $sfTotal)),
            'transport_total' => 0,
            'transport_paid' => 0,
            'transport_assigned' => false,
            'transport_complete' => false,
            'mandatory_complete' => ($grandTotal > 0 && $balance <= 0),
            'scholarship_total' => 0,
            'total_paid' => $totalPaid,
            'grand_total' => $grandTotal,
            'balance_owed' => $balance,
            'fully_paid' => ($grandTotal > 0 && $balance <= 0),
            'no_fees_configured' => ($grandTotal == 0),
            'offline_mode' => true,
            'message' => $grandTotal == 0
                ? 'Fee structure not cached offline yet. You can still record a cash payment; run Prepare offline logins while online to load fee amounts.'
                : null,
        );
    }

    public static function studentsForPayment($q = '') {
        require_once __DIR__ . '/OfflineData.php';
        $rows = OfflineData::listStudents('active', null);
        $q = strtolower(trim($q));
        if ($q !== '') {
            $rows = array_values(array_filter($rows, function ($r) use ($q) {
                $blob = strtolower(
                    (isset($r['student_name']) ? $r['student_name'] : '') . ' ' .
                    (isset($r['parent_name']) ? $r['parent_name'] : '') . ' ' .
                    (isset($r['parent_phone']) ? $r['parent_phone'] : '')
                );
                return strpos($blob, $q) !== false;
            }));
        }
        // Shape expected by payment picker
        $out = array();
        foreach ($rows as $r) {
            $out[] = array(
                'id' => $r['id'],
                'student_name' => $r['student_name'],
                'class_id' => isset($r['class_id']) ? $r['class_id'] : null,
                'class_name' => isset($r['class_name']) ? $r['class_name'] : null,
                'parent_name' => isset($r['parent_name']) ? $r['parent_name'] : null,
            );
        }
        return $out;
    }


    public static function ensureSubjectsTable($pdo) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY,
            uuid TEXT UNIQUE,
            subject_name TEXT,
            subject_code TEXT,
            sync_status TEXT DEFAULT 'synced',
            updated_at TEXT,
            deleted_at TEXT,
            sync_version INTEGER DEFAULT 1
        )");
        try { $pdo->exec("ALTER TABLE classes ADD COLUMN minimum_age INTEGER"); } catch (Exception $e) {}
        try { $pdo->exec("ALTER TABLE classes ADD COLUMN sort_order INTEGER"); } catch (Exception $e) {}
        try { $pdo->exec("ALTER TABLE classes ADD COLUMN class_color TEXT"); } catch (Exception $e) {}
        try { $pdo->exec("ALTER TABLE classes ADD COLUMN sync_status TEXT"); } catch (Exception $e) {}
        try { $pdo->exec("ALTER TABLE classes ADD COLUMN deleted_at TEXT"); } catch (Exception $e) {}
        try { $pdo->exec("ALTER TABLE classes ADD COLUMN uuid TEXT"); } catch (Exception $e) {}
    }

    public static function listClasses() {
        $pdo = self::pdo();
        self::ensureSubjectsTable($pdo);
        try {
            return $pdo->query(
                "SELECT id, class_name, capacity, minimum_age, sort_order, class_color, teacher_id, uuid, sync_status
                   FROM classes
                  WHERE deleted_at IS NULL OR deleted_at = ''
                  ORDER BY COALESCE(sort_order, 9999), class_name"
            )->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return array();
        }
    }

    public static function createClass($data, $userId = null) {
        $pdo = self::pdo();
        self::ensureSubjectsTable($pdo);
        $name = isset($data['class_name']) ? trim($data['class_name']) : '';
        if ($name === '') throw new Exception('Class name is required');
        $st = $pdo->prepare("SELECT id FROM classes WHERE class_name = ? AND (deleted_at IS NULL OR deleted_at='') LIMIT 1");
        $st->execute(array($name));
        if ($st->fetch()) throw new Exception('A class with this name already exists');
        $uuid = DeviceIdentity::generateUuid();
        $capacity = isset($data['capacity']) && $data['capacity'] !== '' ? (int)$data['capacity'] : null;
        $sortOrder = isset($data['sort_order']) && $data['sort_order'] !== '' ? (int)$data['sort_order'] : null;
        $minAge = isset($data['minimum_age']) && $data['minimum_age'] !== '' && $data['minimum_age'] !== null ? (int)$data['minimum_age'] : null;
        if ($sortOrder === null) {
            $mx = (int)$pdo->query("SELECT COALESCE(MAX(sort_order),0) FROM classes")->fetchColumn();
            $sortOrder = $mx + 1;
        }
        $localId = (int)$pdo->query("SELECT COALESCE(MIN(id),0) FROM classes")->fetchColumn();
        $localId = ($localId >= 0) ? -1 : ($localId - 1);
        $classColor = '#2563EB';
        if (!empty($data['class_color'])) {
            $classColor = trim($data['class_color']);
        } elseif (!empty($data['color'])) {
            $classColor = trim($data['color']);
        }
        if ($classColor === '' || $classColor[0] !== '#') {
            $classColor = '#2563EB';
        }
        try { $pdo->exec("ALTER TABLE classes ADD COLUMN class_color TEXT"); } catch (Exception $e) {}
        $pdo->prepare(
            "INSERT INTO classes (id, uuid, class_name, capacity, minimum_age, sort_order, class_color, updated_at, sync_version, sync_status)
             VALUES (?,?,?,?,?,?,?,?,?, 'pending')"
        )->execute(array($localId, $uuid, $name, $capacity, $minAge, $sortOrder, $classColor, date('c'), 1));
        $payload = array(
            'uuid' => $uuid,
            'class_name' => $name,
            'capacity' => $capacity,
            'minimum_age' => $minAge,
            'sort_order' => $sortOrder,
            'class_color' => $classColor,
            'local_id' => $localId,
        );
        self::store()->enqueue('classes', $uuid, 'CREATE', $payload);
        self::logActivity('class', 'Class created (offline)', $name, $userId);
        return array(
            'id' => $localId,
            'class_name' => $name,
            'capacity' => $capacity,
            'sort_order' => $sortOrder,
            'minimum_age' => $minAge,
            'uuid' => $uuid,
            'offline_mode' => true,
            'sync_status' => 'pending',
        );
    }

    public static function updateClass($id, $data, $userId = null) {
        $pdo = self::pdo();
        self::ensureSubjectsTable($pdo);
        $st = $pdo->prepare("SELECT * FROM classes WHERE id = ? LIMIT 1");
        $st->execute(array((int)$id));
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new Exception('Class not found in offline cache');
        $uuid = !empty($row['uuid']) ? $row['uuid'] : DeviceIdentity::generateUuid();
        $name = array_key_exists('class_name', $data) ? trim($data['class_name']) : $row['class_name'];
        if ($name === '') throw new Exception('Class name is required');
        $capacity = array_key_exists('capacity', $data) ? ($data['capacity'] === '' || $data['capacity'] === null ? null : (int)$data['capacity']) : $row['capacity'];
        $sortOrder = array_key_exists('sort_order', $data) ? ($data['sort_order'] === '' || $data['sort_order'] === null ? null : (int)$data['sort_order']) : (isset($row['sort_order']) ? $row['sort_order'] : null);
        $minAge = array_key_exists('minimum_age', $data) ? ($data['minimum_age'] === '' || $data['minimum_age'] === null ? null : (int)$data['minimum_age']) : (isset($row['minimum_age']) ? $row['minimum_age'] : null);
        $classColor = array_key_exists('class_color', $data) ? trim($data['class_color']) : (isset($row['class_color']) ? $row['class_color'] : '#2563EB');
        if ($classColor === '' || (isset($classColor[0]) && $classColor[0] !== '#')) {
            $classColor = '#2563EB';
        }
        try { $pdo->exec("ALTER TABLE classes ADD COLUMN class_color TEXT"); } catch (Exception $e) {}
        $pdo->prepare(
            "UPDATE classes SET uuid=?, class_name=?, capacity=?, minimum_age=?, sort_order=?, class_color=?, updated_at=?, sync_status='pending' WHERE id=?"
        )->execute(array($uuid, $name, $capacity, $minAge, $sortOrder, $classColor, date('c'), (int)$id));
        $payload = array(
            'uuid' => $uuid,
            'id' => (int)$id,
            'class_name' => $name,
            'capacity' => $capacity,
            'minimum_age' => $minAge,
            'sort_order' => $sortOrder,
            'class_color' => $classColor,
        );
        self::store()->enqueue('classes', $uuid, 'UPDATE', $payload);
        self::logActivity('class', 'Class updated (offline)', $name, $userId);
        return array('id' => (int)$id, 'class_name' => $name, 'uuid' => $uuid, 'offline_mode' => true, 'sync_status' => 'pending');
    }

    public static function listSubjects() {
        $pdo = self::pdo();
        self::ensureSubjectsTable($pdo);
        try {
            return $pdo->query(
                "SELECT id, subject_name, subject_code, uuid, sync_status
                   FROM subjects
                  WHERE deleted_at IS NULL OR deleted_at = ''
                  ORDER BY subject_name"
            )->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return array();
        }
    }

    public static function createSubject($data, $userId = null) {
        $pdo = self::pdo();
        self::ensureSubjectsTable($pdo);
        $name = isset($data['subject_name']) ? trim($data['subject_name']) : '';
        if ($name === '') throw new Exception('Subject name is required');
        $st = $pdo->prepare("SELECT id FROM subjects WHERE subject_name = ? AND (deleted_at IS NULL OR deleted_at='') LIMIT 1");
        $st->execute(array($name));
        if ($st->fetch()) throw new Exception('A subject with this name already exists');
        $uuid = DeviceIdentity::generateUuid();
        $base = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $name), 0, 3));
        if (strlen($base) < 2) $base = strtoupper(substr(md5($name), 0, 3));
        $code = $base;
        $suffix = 1;
        while (true) {
            $c = $pdo->prepare("SELECT id FROM subjects WHERE subject_code = ? LIMIT 1");
            $c->execute(array($code));
            if (!$c->fetch()) break;
            $code = $base . $suffix++;
        }
        $localId = (int)$pdo->query("SELECT COALESCE(MIN(id),0) FROM subjects")->fetchColumn();
        $localId = ($localId >= 0) ? -1 : ($localId - 1);
        $pdo->prepare(
            "INSERT INTO subjects (id, uuid, subject_name, subject_code, sync_status, updated_at, sync_version)
             VALUES (?,?,?,?, 'pending', ?, 1)"
        )->execute(array($localId, $uuid, $name, $code, date('c')));
        $payload = array(
            'uuid' => $uuid,
            'subject_name' => $name,
            'subject_code' => $code,
            'local_id' => $localId,
        );
        self::store()->enqueue('subjects', $uuid, 'CREATE', $payload);
        self::logActivity('subject', 'Subject added (offline)', $name, $userId);
        return array('id' => $localId, 'subject_name' => $name, 'subject_code' => $code, 'uuid' => $uuid, 'offline_mode' => true, 'sync_status' => 'pending');
    }

    public static function updateSubject($id, $data, $userId = null) {
        $pdo = self::pdo();
        self::ensureSubjectsTable($pdo);
        $st = $pdo->prepare("SELECT * FROM subjects WHERE id = ? LIMIT 1");
        $st->execute(array((int)$id));
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new Exception('Subject not found in offline cache');
        $uuid = !empty($row['uuid']) ? $row['uuid'] : DeviceIdentity::generateUuid();
        $name = array_key_exists('subject_name', $data) ? trim($data['subject_name']) : $row['subject_name'];
        if ($name === '') throw new Exception('Subject name is required');
        $pdo->prepare(
            "UPDATE subjects SET uuid=?, subject_name=?, sync_status='pending', updated_at=? WHERE id=?"
        )->execute(array($uuid, $name, date('c'), (int)$id));
        self::store()->enqueue('subjects', $uuid, 'UPDATE', array(
            'uuid' => $uuid,
            'id' => (int)$id,
            'subject_name' => $name,
            'subject_code' => isset($row['subject_code']) ? $row['subject_code'] : null,
        ));
        self::logActivity('subject', 'Subject updated (offline)', $name, $userId);
        return array('id' => (int)$id, 'subject_name' => $name, 'uuid' => $uuid, 'offline_mode' => true);
    }

    public static function warmSubjectsFromMysql($db) {
        $pdo = self::pdo();
        self::ensureSubjectsTable($pdo);
        $n = 0;
        try {
            $rows = $db->query("SELECT id, subject_name, subject_code FROM subjects") ?: array();
            if (!is_array($rows)) $rows = array();
            foreach ($rows as $r) {
                $uuid = 'subject-' . (int)$r['id'];
                $pdo->prepare(
                    "INSERT INTO subjects (id, uuid, subject_name, subject_code, sync_status, updated_at, sync_version)
                     VALUES (?,?,?,?, 'synced', ?, 1)
                     ON CONFLICT(id) DO UPDATE SET subject_name=excluded.subject_name, subject_code=excluded.subject_code, updated_at=excluded.updated_at"
                )->execute(array(
                    (int)$r['id'], $uuid, $r['subject_name'],
                    isset($r['subject_code']) ? $r['subject_code'] : null, date('c'),
                ));
                $n++;
            }
        } catch (Exception $e) {
            error_log('warmSubjectsFromMysql: ' . $e->getMessage());
        }
        return $n;
    }

    public static function warmFinanceFromMysql($db) {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        // Ensure receipt column
        try { $pdo->exec("ALTER TABLE fee_payments_local ADD COLUMN receipt_number TEXT"); } catch (Exception $e) {}

        $nPay = 0;
        $nFee = 0;
        $nExp = 0;
        try {
            $rows = $db->query(
                "SELECT fp.id, fp.student_id, fp.amount, fp.payment_method, fp.payment_date, fp.status,
                        fp.receipt_number, fp.reference_number, fp.uuid AS mysql_uuid,
                        s.student_name, s.class_id
                   FROM fee_payments fp
              LEFT JOIN students s ON s.id = fp.student_id
               ORDER BY fp.id DESC LIMIT 500"
            ) ?: array();

            // Index existing local rows
            $byUuid = array();
            $byReceipt = array();
            $byFingerprint = array();
            try {
                foreach ($pdo->query("SELECT id, uuid, receipt_number, student_id, amount, payment_date, payment_method, sync_status FROM fee_payments_local")->fetchAll(PDO::FETCH_ASSOC) as $loc) {
                    if (!empty($loc['uuid'])) $byUuid[$loc['uuid']] = $loc;
                    if (!empty($loc['receipt_number'])) $byReceipt[$loc['receipt_number']] = $loc;
                    $fpKey = strtolower(trim(
                        (int)$loc['student_id'] . '|' . number_format((float)$loc['amount'], 2, '.', '') . '|' .
                        substr((string)$loc['payment_date'], 0, 10) . '|' . (string)$loc['payment_method']
                    ));
                    $byFingerprint[$fpKey] = $loc;
                }
            } catch (Exception $e) {}

            foreach ($rows as $r) {
                $mysqlId = (int)$r['id'];
                $uuid = !empty($r['mysql_uuid']) ? $r['mysql_uuid'] : ('pay-' . $mysqlId);
                $receipt = isset($r['receipt_number']) ? $r['receipt_number'] : null;
                $fpKey = strtolower(trim(
                    (int)$r['student_id'] . '|' . number_format((float)$r['amount'], 2, '.', '') . '|' .
                    substr((string)$r['payment_date'], 0, 10) . '|' . (string)$r['payment_method']
                ));

                // Match only by uuid or receipt_number — never by amount fingerprint
                // (two legitimate Control Number payments can share amount+date+method)
                $existingId = null;
                if (isset($byUuid[$uuid])) $existingId = (int)$byUuid[$uuid]['id'];
                elseif ($receipt && isset($byReceipt[$receipt])) $existingId = (int)$byReceipt[$receipt]['id'];

                if ($existingId) {
                    $pdo->prepare(
                        "UPDATE fee_payments_local SET uuid=?, student_id=?, student_name=?, class_id=?, amount=?,
                            payment_method=?, payment_date=?, receipt_number=?, status=?, sync_status='synced', updated_at=?
                          WHERE id=?"
                    )->execute(array(
                        $uuid,
                        (int)$r['student_id'],
                        isset($r['student_name']) ? $r['student_name'] : null,
                        isset($r['class_id']) ? $r['class_id'] : null,
                        $r['amount'],
                        $r['payment_method'],
                        $r['payment_date'],
                        $receipt,
                        isset($r['status']) ? $r['status'] : 'confirmed',
                        date('c'),
                        $existingId,
                    ));
                } else {
                    try {
                        $pdo->prepare(
                            "INSERT INTO fee_payments_local (uuid, student_id, student_name, class_id, amount, payment_method, payment_date, receipt_number, status, sync_status, created_at, updated_at)
                             VALUES (?,?,?,?,?,?,?,?,?, 'synced', ?, ?)"
                        )->execute(array(
                            $uuid,
                            (int)$r['student_id'],
                            isset($r['student_name']) ? $r['student_name'] : null,
                            isset($r['class_id']) ? $r['class_id'] : null,
                            $r['amount'],
                            $r['payment_method'],
                            $r['payment_date'],
                            $receipt,
                            isset($r['status']) ? $r['status'] : 'confirmed',
                            date('c'), date('c'),
                        ));
                    } catch (Exception $e) {
                        // unique uuid conflict — update
                        $pdo->prepare(
                            "UPDATE fee_payments_local SET amount=?, status=?, receipt_number=?, sync_status='synced' WHERE uuid=?"
                        )->execute(array($r['amount'], isset($r['status']) ? $r['status'] : 'confirmed', $receipt, $uuid));
                    }
                }
                $nPay++;
            }


            // Drop MySQL pay-{id} re-imports that duplicate an offline-origin uuid payment (same cash fingerprint)
            try {
                $pdo->exec(
                    "DELETE FROM fee_payments_local
                      WHERE uuid LIKE 'pay-%'
                        AND EXISTS (
                          SELECT 1 FROM fee_payments_local o
                           WHERE o.uuid NOT LIKE 'pay-%'
                             AND o.student_id = fee_payments_local.student_id
                             AND ABS(o.amount - fee_payments_local.amount) < 0.01
                             AND substr(o.payment_date,1,10) = substr(fee_payments_local.payment_date,1,10)
                             AND IFNULL(o.payment_method,'') = IFNULL(fee_payments_local.payment_method,'')
                        )"
                );
            } catch (Exception $e) {}

            // Drop pure offline pending rows that match a synced fingerprint (post-sync duplicates)
            try {
                $pdo->exec(
                    "DELETE FROM fee_payments_local
                      WHERE sync_status = 'pending'
                        AND EXISTS (
                          SELECT 1 FROM fee_payments_local s
                           WHERE s.sync_status = 'synced'
                             AND s.student_id = fee_payments_local.student_id
                             AND ABS(s.amount - fee_payments_local.amount) < 0.01
                             AND substr(s.payment_date,1,10) = substr(fee_payments_local.payment_date,1,10)
                             AND s.payment_method = fee_payments_local.payment_method
                             AND s.id != fee_payments_local.id
                        )"
                );
            } catch (Exception $e) {}
        } catch (Exception $e) {
            error_log('warmFinance payments: ' . $e->getMessage());
        }

        try {
            $pdo->exec("DELETE FROM fee_structure_cache");
            $fees = $db->query("SELECT id, fee_type, amount, class_id, academic_year FROM fee_structure");
            if ($fees === false) $fees = array();
            foreach ($fees as $f) {
                $pdo->prepare(
                    "INSERT INTO fee_structure_cache (id, fee_type, amount, class_id, class_name, updated_at)
                     VALUES (?,?,?,?,NULL,?)"
                )->execute(array((int)$f['id'], $f['fee_type'], $f['amount'], isset($f['class_id']) ? $f['class_id'] : null, date('c')));
                $nFee++;
            }
        } catch (Exception $e) {
            error_log('warmFinance structure: ' . $e->getMessage());
        }

        try {
            $exps = $db->query(
                "SELECT id, category, description, amount, payment_method, expense_date, reference_number
                   FROM expenses ORDER BY id DESC LIMIT 300"
            );
            if ($exps === false) $exps = array();
            foreach ($exps as $e) {
                $uuid = 'exp-' . (int)$e['id'];
                try {
                    $pdo->prepare(
                        "INSERT INTO expenses_local (uuid, category, description, amount, payment_method, expense_date, notes, sync_status, created_at, updated_at)
                         VALUES (?,?,?,?,?,?,?, 'synced', ?, ?)
                         ON CONFLICT(uuid) DO UPDATE SET amount=excluded.amount, category=excluded.category"
                    )->execute(array(
                        $uuid, $e['category'], isset($e['description']) ? $e['description'] : '',
                        $e['amount'], isset($e['payment_method']) ? $e['payment_method'] : 'Cash',
                        $e['expense_date'], isset($e['reference_number']) ? $e['reference_number'] : null,
                        date('c'), date('c'),
                    ));
                    $nExp++;
                } catch (Exception $ex) {}
            }
        } catch (Exception $e) {
            error_log('warmFinance expenses: ' . $e->getMessage());
        }
        
        $nInst = 0;
        try {
            $pdo->exec("DELETE FROM fee_installments_local");
            $insts = $db->query(
                "SELECT fi.id, fi.student_id, fi.academic_year, fi.fee_type, fi.installment_no,
                        fi.amount_due, fi.amount_paid, fi.status
                   FROM fee_installments fi
                   JOIN students s ON s.id = fi.student_id AND s.status = 'active'
                  ORDER BY fi.id ASC LIMIT 5000"
            );
            if ($insts === false) $insts = array();
            foreach ($insts as $fi) {
                $uuid = 'fi-' . (int)$fi['id'];
                try {
                    $pdo->prepare(
                        "INSERT INTO fee_installments_local
                            (uuid, student_id, academic_year, fee_type, installment_no, amount_due, amount_paid, status, sync_status, updated_at)
                         VALUES (?,?,?,?,?,?,?,?, 'synced', ?)"
                    )->execute(array(
                        $uuid,
                        (int)$fi['student_id'],
                        $fi['academic_year'],
                        $fi['fee_type'],
                        (int)$fi['installment_no'],
                        $fi['amount_due'],
                        $fi['amount_paid'],
                        isset($fi['status']) ? $fi['status'] : 'unpaid',
                        date('c'),
                    ));
                    $nInst++;
                } catch (Exception $ex) {}
            }
        } catch (Exception $e) {
            error_log('warmFinance installments: ' . $e->getMessage());
        }
        return array('payments' => $nPay, 'fee_structure_rows' => $nFee, 'expenses' => $nExp, 'installments' => $nInst);

    }

    public static function deleteClass($id, $userId = null) {
        $pdo = self::pdo();
        self::ensureSubjectsTable($pdo);
        $st = $pdo->prepare("SELECT * FROM classes WHERE id = ? LIMIT 1");
        $st->execute(array((int)$id));
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new Exception('Class not found');
        $uuid = !empty($row['uuid']) ? $row['uuid'] : ('class-' . (int)$id);
        $syncStatus = isset($row['sync_status']) ? $row['sync_status'] : '';
        $neverSynced = ((int)$id < 0) || $syncStatus === 'pending';

        // Always remove from local list immediately
        try {
            $pdo->prepare("UPDATE classes SET deleted_at=?, sync_status='pending', updated_at=? WHERE id=?")
                ->execute(array(date('c'), date('c'), (int)$id));
        } catch (Exception $e) {}
        // Hard-delete local row so it cannot reappear after refresh
        $pdo->prepare("DELETE FROM classes WHERE id=?")->execute(array((int)$id));

        // Drop pending CREATE for this uuid so sync does not re-insert then delete messily
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS sync_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_type TEXT,
                record_uuid TEXT,
                operation TEXT,
                payload TEXT,
                op_id TEXT,
                created_at TEXT,
                attempts INTEGER DEFAULT 0
            )");
            $pdo->prepare(
                "DELETE FROM sync_queue WHERE record_uuid = ? AND UPPER(operation) = 'CREATE'"
            )->execute(array($uuid));
        } catch (Exception $e) {}

        if ($neverSynced) {
            // Never reached MySQL — nothing to push
            self::logActivity('class', 'Class removed offline (never synced)', isset($row['class_name']) ? $row['class_name'] : ('#'.$id), $userId);
            return array('id' => (int)$id, 'uuid' => $uuid, 'offline_mode' => true, 'sync_status' => 'local_only_removed');
        }

        self::store()->enqueue('classes', $uuid, 'DELETE', array('uuid' => $uuid, 'id' => (int)$id));
        self::logActivity('class', 'Class deleted (offline)', isset($row['class_name']) ? $row['class_name'] : ('#'.$id), $userId);
        return array('id' => (int)$id, 'uuid' => $uuid, 'offline_mode' => true, 'sync_status' => 'pending');
    }

    public static function deleteSubject($id, $userId = null) {
        $pdo = self::pdo();
        self::ensureSubjectsTable($pdo);
        $st = $pdo->prepare("SELECT * FROM subjects WHERE id = ? LIMIT 1");
        $st->execute(array((int)$id));
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new Exception('Subject not found');
        $uuid = !empty($row['uuid']) ? $row['uuid'] : ('subject-' . (int)$id);
        $syncStatus = isset($row['sync_status']) ? $row['sync_status'] : '';
        $neverSynced = ((int)$id < 0) || $syncStatus === 'pending';
        try {
            $pdo->prepare("UPDATE subjects SET deleted_at=?, sync_status='pending', updated_at=? WHERE id=?")
                ->execute(array(date('c'), date('c'), (int)$id));
        } catch (Exception $e) {}
        $pdo->prepare("DELETE FROM subjects WHERE id=?")->execute(array((int)$id));
        try {
            $pdo->prepare("DELETE FROM sync_queue WHERE record_uuid = ? AND UPPER(operation) = 'CREATE'")->execute(array($uuid));
        } catch (Exception $e) {}
        if ($neverSynced) {
            self::logActivity('subject', 'Subject removed offline (never synced)', isset($row['subject_name']) ? $row['subject_name'] : ('#'.$id), $userId);
            return array('id' => (int)$id, 'uuid' => $uuid, 'offline_mode' => true, 'sync_status' => 'local_only_removed');
        }
        self::store()->enqueue('subjects', $uuid, 'DELETE', array('uuid' => $uuid, 'id' => (int)$id));
        self::logActivity('subject', 'Subject deleted (offline)', isset($row['subject_name']) ? $row['subject_name'] : ('#'.$id), $userId);
        return array('id' => (int)$id, 'uuid' => $uuid, 'offline_mode' => true, 'sync_status' => 'pending');
    }

    public static function getSchoolSettings() {
        $pdo = self::pdo();
        // Match online getSettings() defaults + cached values
        $out = array(
            'school_name'         => 'Nursery School',
            'school_address'      => '',
            'school_phone'        => '',
            'school_email'        => '',
            'email_notifications' => 'true',
            'sms_notifications'   => 'true',
            'school_logo'         => '',
            'school_mission'      => '',
            'school_vision'       => '',
            'established_year'    => '',
            'school_tagline'      => '',
            'principal_name'      => '',
            'academic_year'       => '',
            'offline_mode'        => true,
            'read_only'           => true,
        );
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS settings_cache (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TEXT
            )");
            $rows = $pdo->query("SELECT key, value FROM settings_cache")->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($rows as $r) {
                if (!isset($r['key']) || $r['key'] === '') continue;
                $out[$r['key']] = $r['value'];
            }
        } catch (Exception $e) {}
        if (empty($out['school_logo']) && !empty($out['logo_url'])) {
            $out['school_logo'] = $out['logo_url'];
        }
        if (!isset($out['school_name']) || $out['school_name'] === '') {
            $out['school_name'] = 'Nursery School';
        }
        $out['offline_mode'] = true;
        $out['read_only'] = true;
        return $out;
    }

    public static function updateSchoolSettings($data, $userId = null) {
        $pdo = self::pdo();
        $pdo->exec("CREATE TABLE IF NOT EXISTS settings_cache (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT
        )");
        if (!is_array($data)) throw new Exception('Invalid settings payload');
        // Accept either {settings:{k:v}} or flat map
        if (isset($data['settings']) && is_array($data['settings'])) {
            $map = $data['settings'];
        } else {
            $map = $data;
        }
        $allowed = array(
            'school_name','school_phone','school_email','school_address','academic_year',
            'school_motto','currency','timezone','years_of_excellence','tagline','about'
        );
        $saved = array();
        foreach ($map as $k => $v) {
            $k = (string)$k;
            if ($k === 'uuid' || $k === 'id' || $k === 'offline_mode') continue;
            // allow known keys or any non-empty string key from admin form
            if (!in_array($k, $allowed, true) && !preg_match('/^[a-z0-9_]{2,64}$/i', $k)) continue;
            $val = is_scalar($v) ? (string)$v : json_encode($v);
            $pdo->prepare(
                "INSERT INTO settings_cache (key, value, updated_at) VALUES (?,?,?)
                 ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at"
            )->execute(array($k, $val, date('c')));
            $uuid = 'setting-' . $k;
            self::store()->enqueue('school_settings', $uuid, 'UPDATE', array(
                'uuid' => $uuid,
                'setting_key' => $k,
                'setting_value' => $val,
            ));
            $saved[$k] = $val;
        }
        self::logActivity('settings', 'Settings updated (offline)', implode(', ', array_keys($saved)), $userId);
        return array('settings' => $saved, 'offline_mode' => true, 'sync_status' => 'pending');
    }

    public static function feeStructureAll() {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        $classes = self::listClasses();
        $feeMap = array('school_wide' => array(), 'per_class' => array());
        $yr = date('Y') . '/' . (date('Y') + 1);
        try {
            $st = $pdo->prepare("SELECT value FROM settings_cache WHERE key = 'academic_year' LIMIT 1");
            $st->execute();
            $v = $st->fetchColumn();
            if ($v) $yr = $v;
        } catch (Exception $e) {}
        try {
            $rows = $pdo->query("SELECT id, fee_type, amount, class_id, class_name FROM fee_structure_cache")->fetchAll(PDO::FETCH_ASSOC) ?: array();
            foreach ($rows as $r) {
                $ft = $r['fee_type'];
                $amt = (float)$r['amount'];
                $cid = $r['class_id'] === null || $r['class_id'] === '' ? null : (int)$r['class_id'];
                $entry = array(
                    'id' => isset($r['id']) ? (int)$r['id'] : null,
                    'fee_type' => $ft,
                    'amount' => $amt,
                    'class_id' => $cid,
                    'class_name' => isset($r['class_name']) ? $r['class_name'] : null,
                    'academic_year' => $yr,
                );
                if ($cid === null) {
                    $feeMap['school_wide'][$ft] = $entry;
                } else {
                    if (!isset($feeMap['per_class'][$cid])) $feeMap['per_class'][$cid] = array();
                    $feeMap['per_class'][$cid][$ft] = $entry;
                }
            }
        } catch (Exception $e) {}
        return array(
            'academic_year' => $yr,
            'classes' => $classes,
            'fee_map' => $feeMap,
            'fee_types' => array_values(array_unique(array_merge(
                array_keys($feeMap['school_wide']),
                array('School Fees', 'Registration Fee', 'Stationery', 'Uniform', 'Meals', 'Transport')
            ))),
            'installable' => array('School Fees', 'Transport'),
            'school_wide_fee_types' => array('Registration Fee', 'Stationery', 'Uniform', 'Meals', 'Transport'),
            'class_fee_types' => array('School Fees'),
            'offline_mode' => true,
        );
    }

    public static function saveFeeStructure($data, $userId = null) {
        $pdo = self::pdo();
        self::ensureFinanceTables($pdo);
        if (!isset($data['fees']) || !is_array($data['fees'])) {
            throw new Exception('fees array required');
        }
        $yr = !empty($data['academic_year']) ? $data['academic_year'] : null;
        if (!$yr) {
            try {
                $st = $pdo->prepare("SELECT value FROM settings_cache WHERE key = 'academic_year' LIMIT 1");
                $st->execute();
                $yr = $st->fetchColumn() ?: (date('Y') . '/' . (date('Y') + 1));
            } catch (Exception $e) {
                $yr = date('Y') . '/' . (date('Y') + 1);
            }
        }
        $classId = (isset($data['class_id']) && $data['class_id'] !== '' && $data['class_id'] !== null)
            ? (int)$data['class_id'] : null;

        // Remove existing rows for this scope from cache
        if ($classId !== null) {
            $pdo->prepare("DELETE FROM fee_structure_cache WHERE class_id = ?")->execute(array($classId));
        } else {
            $pdo->prepare("DELETE FROM fee_structure_cache WHERE class_id IS NULL OR class_id = ''")->execute();
        }

        $className = null;
        if ($classId !== null) {
            try {
                $st = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
                $st->execute(array($classId));
                $className = $st->fetchColumn() ?: null;
            } catch (Exception $e) {}
        }

        $n = 0;
        foreach ($data['fees'] as $fee) {
            $ft = isset($fee['fee_type']) ? trim($fee['fee_type']) : '';
            if ($ft === '') continue;
            $amt = isset($fee['amount']) ? (float)$fee['amount'] : 0;
            $localId = -1 * (time() + $n);
            $pdo->prepare(
                "INSERT INTO fee_structure_cache (id, fee_type, amount, class_id, class_name, updated_at)
                 VALUES (?,?,?,?,?,?)"
            )->execute(array($localId, $ft, $amt, $classId, $className, date('c')));
            $uuid = 'fee-struct-' . md5($yr . '|' . ($classId === null ? 'sw' : $classId) . '|' . $ft);
            self::store()->enqueue('fee_structure', $uuid, 'UPDATE', array(
                'uuid' => $uuid,
                'fee_type' => $ft,
                'amount' => $amt,
                'class_id' => $classId,
                'academic_year' => $yr,
                'currency' => 'TZS',
            ));
            $n++;
        }
        self::logActivity('fee_structure', 'Fee structure saved (offline)', ($classId ? 'class '.$classId : 'school-wide') . ' ×' . $n, $userId);
        return array('saved' => $n, 'academic_year' => $yr, 'class_id' => $classId, 'offline_mode' => true, 'sync_status' => 'pending');
    }


    public static function ensureContentCaches($pdo) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS gallery_cache (
            id INTEGER PRIMARY KEY,
            url TEXT,
            caption TEXT,
            date TEXT,
            sort_order INTEGER,
            is_visible INTEGER DEFAULT 1
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS calendar_cache (
            id INTEGER PRIMARY KEY,
            icon TEXT,
            type TEXT,
            title TEXT,
            date TEXT,
            description TEXT,
            is_visible INTEGER DEFAULT 1
        )");
    }

    public static function warmGalleryFromMysql($db) {
        $pdo = self::pdo();
        self::ensureContentCaches($pdo);
        $n = 0;
        try {
            $pdo->exec("DELETE FROM gallery_cache");
            $rows = $db->query(
                "SELECT id, url, caption, date, sort_order, is_visible FROM school_gallery ORDER BY sort_order ASC, id DESC LIMIT 100"
            ) ?: array();
            foreach ($rows as $r) {
                $pdo->prepare(
                    "INSERT INTO gallery_cache (id, url, caption, date, sort_order, is_visible) VALUES (?,?,?,?,?,?)"
                )->execute(array(
                    (int)$r['id'],
                    isset($r['url']) ? $r['url'] : '',
                    isset($r['caption']) ? $r['caption'] : '',
                    isset($r['date']) ? substr($r['date'], 0, 10) : '',
                    isset($r['sort_order']) ? (int)$r['sort_order'] : 0,
                    isset($r['is_visible']) ? (int)$r['is_visible'] : 1,
                ));
                $n++;
            }
        } catch (Exception $e) {
            error_log('warmGallery: ' . $e->getMessage());
        }
        return $n;
    }

    public static function warmCalendarFromMysql($db) {
        $pdo = self::pdo();
        self::ensureContentCaches($pdo);
        $n = 0;
        try {
            $pdo->exec("DELETE FROM calendar_cache");
            $rows = $db->query(
                "SELECT id, icon, type, title, date, `desc` AS description, is_visible FROM school_calendar ORDER BY date ASC LIMIT 200"
            );
            if ($rows === false) {
                $rows = $db->query(
                    "SELECT id, icon, type, title, date, description, is_visible FROM school_calendar ORDER BY date ASC LIMIT 200"
                ) ?: array();
            }
            if (!is_array($rows)) $rows = array();
            foreach ($rows as $r) {
                $desc = isset($r['description']) ? $r['description'] : (isset($r['desc']) ? $r['desc'] : '');
                $pdo->prepare(
                    "INSERT INTO calendar_cache (id, icon, type, title, date, description, is_visible) VALUES (?,?,?,?,?,?,?)"
                )->execute(array(
                    (int)$r['id'],
                    isset($r['icon']) ? $r['icon'] : '',
                    isset($r['type']) ? $r['type'] : '',
                    isset($r['title']) ? $r['title'] : '',
                    isset($r['date']) ? substr($r['date'], 0, 10) : '',
                    $desc,
                    isset($r['is_visible']) ? (int)$r['is_visible'] : 1,
                ));
                $n++;
            }
        } catch (Exception $e) {
            error_log('warmCalendar: ' . $e->getMessage());
        }
        return $n;
    }

    public static function listGallery() {
        $pdo = self::pdo();
        self::ensureContentCaches($pdo);
        try {
            $rows = $pdo->query(
                "SELECT id, url, caption, date, sort_order, is_visible FROM gallery_cache ORDER BY sort_order ASC, id DESC"
            )->fetchAll(PDO::FETCH_ASSOC) ?: array();
            return $rows;
        } catch (Exception $e) {
            return array();
        }
    }

    public static function listCalendar() {
        $pdo = self::pdo();
        self::ensureContentCaches($pdo);
        try {
            $rows = $pdo->query(
                "SELECT id, icon, type, title, date, description AS `desc`, is_visible FROM calendar_cache ORDER BY date ASC"
            )->fetchAll(PDO::FETCH_ASSOC) ?: array();
            // Also provide description alias
            foreach ($rows as &$r) {
                if (!isset($r['desc']) && isset($r['description'])) $r['desc'] = $r['description'];
            }
            unset($r);
            return $rows;
        } catch (Exception $e) {
            return array();
        }
    }

}
