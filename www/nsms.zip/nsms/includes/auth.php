<?php
require_once __DIR__ . '/config.php';
/**
 * Authentication Helper Functions
 * Session management and security
 */

// Harden session cookies before starting the session
if (session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);

    // PHP 7.3+ supports array form; fall back for older runtimes
    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params(array(
            'lifetime' => 0,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ));
    } else {
        session_set_cookie_params(0, '/; samesite=Lax', '', $secure, true);
    }

    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_strict_mode', '1');
    session_start();
}

/**
 * Ensure a CSRF token exists for this session.
 * @return string
 */
function ensureCsrfToken() {
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        try {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        } catch (Exception $e) {
            $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
        }
    }
    return $_SESSION['csrf_token'];
}

/**
 * Read CSRF token from request headers or body fields (multipart / form).
 * @return string|null
 */
function readCsrfTokenFromRequest() {
    $headers = array();
    if (function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) {
            $headers[strtolower($k)] = $v;
        }
    } else {
        foreach ($_SERVER as $k => $v) {
            if (strpos($k, 'HTTP_') === 0) {
                $name = strtolower(str_replace('_', '-', substr($k, 5)));
                $headers[$name] = $v;
            }
        }
    }
    // Also check common CGI header variants
    foreach (array('HTTP_X_CSRF_TOKEN', 'HTTP_X_XSRF_TOKEN') as $sk) {
        if (!empty($_SERVER[$sk])) {
            return trim($_SERVER[$sk]);
        }
    }
    foreach (array('x-csrf-token', 'x-xsrf-token') as $h) {
        if (!empty($headers[$h])) {
            return trim($headers[$h]);
        }
    }
    if (!empty($_POST['_csrf'])) {
        return trim($_POST['_csrf']);
    }
    if (!empty($_POST['csrf_token'])) {
        return trim($_POST['csrf_token']);
    }
    // JSON body (application/json POSTs)
    $ct = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : (isset($_SERVER['HTTP_CONTENT_TYPE']) ? $_SERVER['HTTP_CONTENT_TYPE'] : '');
    if (stripos($ct, 'application/json') !== false) {
        static $jsonBody = null;
        if ($jsonBody === null) {
            $raw = file_get_contents('php://input');
            $jsonBody = json_decode($raw, true);
            if (!is_array($jsonBody)) $jsonBody = array();
            // Re-populate a global so APIs can still read body once
            $GLOBALS['NSMS_JSON_BODY'] = $jsonBody;
        }
        if (!empty($jsonBody['_csrf'])) return trim($jsonBody['_csrf']);
        if (!empty($jsonBody['csrf_token'])) return trim($jsonBody['csrf_token']);
    }
    return null;
}

/**
 * Validate CSRF for mutating HTTP methods.
 * Set NSMS_CSRF=0 to disable (emergency only).
 */
function enforceCsrf() {
    $flag = getenv('NSMS_CSRF');
    if ($flag === '0' || strtolower((string)$flag) === 'false') {
        return;
    }
    $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';
    if (in_array($method, array('GET', 'HEAD', 'OPTIONS'), true)) {
        return;
    }

    // Login/logout must work even if the SPA has not yet obtained a CSRF token
    // (first visit, cleared cookies, or blocked GET ?action=csrf). Credentials
    // are the protection for these endpoints.
    $action = isset($_GET['action']) ? (string) $_GET['action'] : '';
    if (in_array($action, array('login', 'logout', 'forgot_password', 'complete_password_reset'), true)) {
        $script = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', (string) $_SERVER['SCRIPT_NAME']) : '';
        $uri    = isset($_SERVER['REQUEST_URI']) ? str_replace('\\', '/', (string) $_SERVER['REQUEST_URI']) : '';
        $self   = isset($_SERVER['PHP_SELF']) ? str_replace('\\', '/', (string) $_SERVER['PHP_SELF']) : '';
        $isAuth = (substr($script, -8) === 'auth.php')
            || (substr($self, -8) === 'auth.php')
            || (strpos($uri, 'auth.php') !== false);
        if ($isAuth) {
            return;
        }
    }

    ensureCsrfToken();
    $sent = readCsrfTokenFromRequest();
    $expected = isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : '';
    if (!$sent || !$expected || !hash_equals($expected, $sent)) {
        http_response_code(403);
        if (ob_get_level()) {
            ob_clean();
        }
        header('Content-Type: application/json');
        echo json_encode(array(
            'success' => false,
            'error'   => 'Invalid or missing CSRF token',
            'code'    => 'csrf_failed',
        ));
        exit;
    }
}


/**
 * Check if user is logged in
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

/**
 * Require authentication
 */
function requireAuth() {
    if (!isLoggedIn()) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(array('success' => false, 'error' => 'Unauthorized - Please login'));
        exit;
    }
}

/**
 * Require specific role
 * @param string|array $roles
 */
function requireRole($roles) {
    requireAuth();

    if (!is_array($roles)) {
        $roles = array($roles);
    }

    if (!in_array($_SESSION['role'], $roles)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(array('success' => false, 'error' => 'Forbidden - Insufficient permissions'));
        exit;
    }
}

/**
 * Get current user ID
 * @return int|null
 */
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
}

/**
 * Get current user role
 * @return string|null
 */
function getCurrentUserRole() {
    return isset($_SESSION['role']) ? $_SESSION['role'] : null;
}

/**
 * Get current user data
 * @return array|null
 */
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }

    return array(
        'id'        => $_SESSION['user_id'],
        'email'     => $_SESSION['email'],
        'role'      => $_SESSION['role'],
        'full_name' => $_SESSION['full_name']
    );
}

/**
 * Set session data after login
 * @param array $user
 */
function setUserSession($user) {
    // Rotate session ID on login to prevent fixation
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }
    $_SESSION['user_id']   = $user['id'];
    $_SESSION['email']     = $user['email'];
    $_SESSION['role']      = strtolower(trim((string)$user['role']));
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['phone']     = isset($user['phone']) ? $user['phone'] : null;
}

/**
 * Clear session data (logout)
 */
function clearUserSession() {
    $_SESSION = array();
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], !empty($p['secure']), !empty($p['httponly'])
        );
    }
    session_destroy();
}

/**
 * Hash password
 * @param string $password
 * @return string
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password
 * @param string $password
 * @param string $hash
 * @return bool
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate random token
 * @param int $length
 * @return string
 */
function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

/**
 * Sanitize input for display
 * Guarded — helpers.php may already define sanitize() in the include chain.
 * @param string $data
 * @return string
 */
if (!function_exists('sanitize')) {
    function sanitize($data) {
        // Plain-text sanitize for storage / JSON APIs.
        // Do NOT htmlspecialchars here — React and JSON consumers escape on display;
        // HTML emails should call htmlspecialchars at render time.
        if (is_array($data)) {
            return array_map('sanitize', $data);
        }
        $data = trim((string)$data);
        $data = strip_tags($data);
        // Decode any legacy double-encoded entities so "&amp;" becomes "&"
        $data = html_entity_decode($data, ENT_QUOTES, 'UTF-8');
        return $data;
    }
}

/**
 * Validate email
 * @param string $email
 * @return bool
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Send JSON response
 * @param mixed $data
 * @param int $status
 */
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function errorResponse($msg, $code = 400) {
    http_response_code($code);
    if (ob_get_level()) {
        ob_clean();
    }
    header('Content-Type: application/json');
    echo json_encode(array('success' => false, 'error' => $msg, 'message' => $msg));
    exit;
}

function successResponse($data = null, $msg = null) {
    $out = array('success' => true);
    if ($data !== null) $out['data'] = $data;
    if ($msg  !== null) $out['message'] = $msg;
    if (ob_get_level()) {
        ob_clean();
    }
    header('Content-Type: application/json');
    echo json_encode($out);
    exit;
}

/**
 * Apply standard API response headers.
 * Restrict CORS to same-origin by default. Set NSMS_CORS_ORIGIN env
 * (e.g. https://school.example.com) only if a separate frontend origin is required.
 */
function applyApiHeaders() {
    header('Content-Type: application/json');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');

    // Always mint a session CSRF token so the SPA can fetch it
    if (function_exists('ensureCsrfToken')) {
        ensureCsrfToken();
    }

    $cors = getenv('NSMS_CORS_ORIGIN');
    if ($cors) {
        header('Access-Control-Allow-Origin: ' . $cors);
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, PATCH, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token, X-XSRF-Token');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        if (ob_get_level()) {
            ob_end_clean();
        }
        http_response_code(204);
        exit;
    }

    // Enforce CSRF on state-changing requests (disable with NSMS_CSRF=0)
    if (function_exists('enforceCsrf')) {
        enforceCsrf();
    }
}
