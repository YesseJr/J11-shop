<?php
/**
 * Helper Utility Functions
 * General purpose helpers for the application
 */

/**
 * Sanitize user input to prevent XSS and injection attacks.
 * Called extensively throughout pulse-api.php for all user-supplied strings
 * (titles, bodies, names, descriptions, subjects, etc.)
 *
 * Guard prevents a fatal "Cannot redeclare" error if sanitize() is
 * already defined earlier in the include chain (e.g. auth.php).
 *
 * @param  string|array $input
 * @return string|array
 */
if (!function_exists('sanitize')) {
    function sanitize($input) {
        if (is_array($input)) {
            return array_map('sanitize', $input);
        }
        $input = trim((string)$input);
        $input = stripslashes($input);
        $input = strip_tags($input);
        $input = html_entity_decode($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
}


/**
 * Decode legacy HTML entities in text loaded from the DB for JSON/React UIs.
 * Safe to call on already-plain strings.
 */
function decodeText($value) {
    if ($value === null || $value === '') {
        return $value;
    }
    if (is_array($value)) {
        return array_map('decodeText', $value);
    }
    return html_entity_decode((string)$value, ENT_QUOTES, 'UTF-8');
}

/**
 * Format Tanzanian Shilling amount
 * @param float $amount
 * @param bool $includeSymbol
 * @return string
 */
function formatTSh($amount, $includeSymbol = true) {
    $formatted = number_format($amount, 2);
    return $includeSymbol ? 'TSh ' . $formatted : $formatted;
}

/**
 * Format date for display
 * @param string $date
 * @param string $format
 * @return string
 */
function formatDate($date, $format = 'Y-m-d') {
    if (empty($date)) return '';
    $timestamp = strtotime($date);
    return date($format, $timestamp);
}

/**
 * Calculate age from date of birth
 * @param string $dob
 * @return int
 */
function calculateAge($dob) {
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    return $today->diff($birthDate)->y;
}

/**
 * Get current academic year
 * @return string
 */
function getCurrentAcademicYear() {
    $currentMonth = (int)date('n');
    $currentYear = (int)date('Y');
    
    // Academic year runs from September to August
    if ($currentMonth >= 9) {
        return $currentYear . '/' . ($currentYear + 1);
    } else {
        return ($currentYear - 1) . '/' . $currentYear;
    }
}

/**
 * Get current term (1 or 2). Tanzania nursery/primary schools run two
 * terms a year — there is no Term 3.
 *
 * Prefers the school's own configured term dates (school_settings:
 * acad_term1_start/end, acad_term2_start/end — set on the admin Settings
 * page) when a $db connection is passed in, since those are the real,
 * admin-confirmed dates for this specific school rather than a guess.
 * Falls back to a plain month-based split (aligned with the Sep–Aug
 * academic year already used throughout NSMS) if no $db is given or no
 * schedule has been configured yet.
 *
 * @param object|null $db Optional Database instance for the accurate path
 * @return int
 */
function getCurrentTerm($db = null) {
    if ($db) {
        try {
            $rows = $db->query(
                "SELECT setting_key, setting_value FROM school_settings
                  WHERE setting_key IN ('acad_term1_start','acad_term1_end','acad_term2_start','acad_term2_end')"
            ) ?: [];
            $s = [];
            foreach ($rows as $r) { $s[$r['setting_key']] = $r['setting_value']; }

            if (!empty($s['acad_term1_start']) && !empty($s['acad_term1_end'])
                && !empty($s['acad_term2_start']) && !empty($s['acad_term2_end'])) {
                $today = date('Y-m-d');
                if ($today >= $s['acad_term1_start'] && $today <= $s['acad_term1_end']) return 1;
                if ($today >= $s['acad_term2_start'] && $today <= $s['acad_term2_end']) return 2;
                // Outside both configured ranges (e.g. a holiday) — fall through to the heuristic below.
            }
        } catch (Exception $e) { /* schedule not set up yet — fall through */ }
    }

    // Fallback: split the Sep–Aug academic year into two halves.
    $currentMonth = (int)date('n');
    return in_array($currentMonth, [9, 10, 11, 12, 1, 2], true) ? 1 : 2;
}

/**
 * Get week number of the month
 * @param string $date
 * @return int
 */
function getWeekOfMonth($date = null) {
    if ($date === null) {
        $date = date('Y-m-d');
    }
    $timestamp = strtotime($date);
    $firstOfMonth = strtotime(date('Y-m-01', $timestamp));
    $dayOfMonth = date('j', $timestamp);
    $weekOfYear = date('W', $timestamp);
    $weekOfFirstDay = date('W', $firstOfMonth);
    
    return $weekOfYear - $weekOfFirstDay + 1;
}

/**
 * Generate receipt number
 * @return string
 */
function generateReceiptNumber() {
    $prefix = 'REC';
    $timestamp = date('ymd');
    $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
    return $prefix . '-' . $timestamp . '-' . $random;
}

/**
 * Upload file
 * @param array $file $_FILES array
 * @param string $directory
 * @param array $allowedTypes
 * @return string|false Returns file path on success, false on failure
 */
/**
 * Safe upload helper — validates size, extension, and real MIME (finfo).
 * Never trusts the browser-supplied Content-Type alone.
 *
 * @param array  $file          One entry from $_FILES
 * @param string $directory     Absolute or relative target directory (trailing slash optional)
 * @param array  $allowedExts   Lowercase extensions without dots, e.g. array('jpg','png','pdf')
 * @param int    $maxBytes      Default 5 MB
 * @param array  $allowedMimes  Optional explicit MIME whitelist; if empty, derived from extension map
 * @return array{ok:bool,path?:string,filename?:string,mime?:string,error?:string}
 */

/**
 * Resize/compress raster images for faster mobile delivery.
 * Max edge 1280px; JPEG/WebP quality ~82. No-op if GD missing or not an image.
 * Overwrites $filepath in place when successful.
 */
function nsmsOptimizeImageFile($filepath, $maxEdge = 1280, $jpegQuality = 82) {
    if (!is_string($filepath) || $filepath === '' || !is_file($filepath)) {
        return false;
    }
    if (!function_exists('getimagesize') || !function_exists('imagecreatetruecolor')) {
        return false;
    }
    $info = @getimagesize($filepath);
    if ($info === false || empty($info[0]) || empty($info[1])) {
        return false;
    }
    $w = (int) $info[0];
    $h = (int) $info[1];
    $type = isset($info[2]) ? (int) $info[2] : 0;
    if ($w < 1 || $h < 1) {
        return false;
    }

    $src = null;
    if ($type === IMAGETYPE_JPEG && function_exists('imagecreatefromjpeg')) {
        $src = @imagecreatefromjpeg($filepath);
    } elseif ($type === IMAGETYPE_PNG && function_exists('imagecreatefrompng')) {
        $src = @imagecreatefrompng($filepath);
    } elseif ($type === IMAGETYPE_WEBP && function_exists('imagecreatefromwebp')) {
        $src = @imagecreatefromwebp($filepath);
    } elseif ($type === IMAGETYPE_GIF && function_exists('imagecreatefromgif')) {
        $src = @imagecreatefromgif($filepath);
    }
    if (!$src) {
        return false;
    }

    $scale = 1.0;
    $maxEdge = max(320, (int) $maxEdge);
    if ($w > $maxEdge || $h > $maxEdge) {
        $scale = min($maxEdge / $w, $maxEdge / $h);
    }
    // Always recompress large files even if dimensions OK
    $needWrite = ($scale < 0.999) || (filesize($filepath) > 350000);
    if (!$needWrite) {
        imagedestroy($src);
        return true;
    }

    $nw = max(1, (int) round($w * $scale));
    $nh = max(1, (int) round($h * $scale));
    $dst = imagecreatetruecolor($nw, $nh);
    if (!$dst) {
        imagedestroy($src);
        return false;
    }

    if ($type === IMAGETYPE_PNG || $type === IMAGETYPE_WEBP || $type === IMAGETYPE_GIF) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
        imagefilledrectangle($dst, 0, 0, $nw, $nh, $transparent);
    }

    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    $ok = false;
    if ($type === IMAGETYPE_JPEG) {
        $ok = imagejpeg($dst, $filepath, max(60, min(92, (int) $jpegQuality)));
    } elseif ($type === IMAGETYPE_PNG) {
        // PNG compression 0-9
        $ok = imagepng($dst, $filepath, 6);
    } elseif ($type === IMAGETYPE_WEBP && function_exists('imagewebp')) {
        $ok = imagewebp($dst, $filepath, max(60, min(92, (int) $jpegQuality)));
    } elseif ($type === IMAGETYPE_GIF) {
        $ok = imagegif($dst, $filepath);
    }
    imagedestroy($src);
    imagedestroy($dst);
    if ($ok) {
        @chmod($filepath, 0644);
    }
    return $ok;
}

function nsmsStoreUpload($file, $directory, $allowedExts = array('jpg', 'jpeg', 'png', 'pdf'), $maxBytes = 5242880, $allowedMimes = array()) {
    if (!is_array($file) || !isset($file['error']) || is_array($file['error'])) {
        return array('ok' => false, 'error' => 'Invalid upload payload');
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $map = array(
            UPLOAD_ERR_INI_SIZE   => 'File exceeds server limit',
            UPLOAD_ERR_FORM_SIZE  => 'File exceeds form limit',
            UPLOAD_ERR_PARTIAL    => 'File only partially uploaded',
            UPLOAD_ERR_NO_FILE    => 'No file uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Server temp folder missing',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION  => 'Upload blocked by server extension',
        );
        $code = (int) $file['error'];
        return array('ok' => false, 'error' => isset($map[$code]) ? $map[$code] : 'Upload failed');
    }
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return array('ok' => false, 'error' => 'Not a valid uploaded file');
    }
    if (!isset($file['size']) || (int) $file['size'] <= 0) {
        return array('ok' => false, 'error' => 'Empty file');
    }
    if ((int) $file['size'] > (int) $maxBytes) {
        return array('ok' => false, 'error' => 'File too large (max ' . round($maxBytes / 1048576, 1) . ' MB)');
    }

    $orig = isset($file['name']) ? (string) $file['name'] : '';
    $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    // Block double extensions / path tricks
    if ($ext === '' || strpos($orig, '..') !== false || preg_match('/\.(php|phtml|phar|cgi|pl|asp|aspx|js|html|htm|shtml|exe|sh|bat)$/i', $orig)) {
        return array('ok' => false, 'error' => 'File type not allowed');
    }
    $allowedExts = array_map('strtolower', $allowedExts);
    if (!in_array($ext, $allowedExts, true)) {
        return array('ok' => false, 'error' => 'File extension not allowed');
    }

    $mimeMap = array(
        'jpg'  => array('image/jpeg'),
        'jpeg' => array('image/jpeg'),
        'png'  => array('image/png'),
        'gif'  => array('image/gif'),
        'webp' => array('image/webp'),
        'pdf'  => array('application/pdf'),
        'txt'  => array('text/plain'),
        'doc'  => array('application/msword'),
        'docx' => array('application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
        'xls'  => array('application/vnd.ms-excel'),
        'xlsx' => array('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
    );

    $mime = '';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = (string) finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
        }
    }
    if ($mime === '' && !empty($file['type'])) {
        $mime = (string) $file['type']; // last resort
    }

    if (empty($allowedMimes)) {
        $allowedMimes = isset($mimeMap[$ext]) ? $mimeMap[$ext] : array();
    }
    if (!empty($allowedMimes) && $mime !== '' && !in_array($mime, $allowedMimes, true)) {
        return array('ok' => false, 'error' => 'File content type not allowed');
    }

    $directory = rtrim(str_replace('\\', '/', $directory), '/') . '/';
    if (!is_dir($directory)) {
        if (!@mkdir($directory, 0755, true) && !is_dir($directory)) {
            return array('ok' => false, 'error' => 'Could not create upload directory');
        }
    }
    if (!is_writable($directory)) {
        return array('ok' => false, 'error' => 'Upload directory is not writable');
    }

    try {
        $filename = bin2hex(random_bytes(16)) . '.' . $ext;
    } catch (Exception $e) {
        $filename = uniqid('up_', true) . '.' . $ext;
    }
    $filepath = $directory . $filename;
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        return array('ok' => false, 'error' => 'Failed to save uploaded file');
    }
    @chmod($filepath, 0644);

    // Compress/resize photos & payment proofs for mobile-friendly delivery
    $imageExts = array('jpg', 'jpeg', 'png', 'webp', 'gif');
    if (in_array($ext, $imageExts, true)) {
        @nsmsOptimizeImageFile($filepath, 1280, 82);
    }

    $finalSize = is_file($filepath) ? (int) filesize($filepath) : (int) $file['size'];

    return array(
        'ok'       => true,
        'path'     => $filepath,
        'filename' => $filename,
        'mime'     => $mime,
        'size'     => $finalSize,
    );
}

/**
 * Legacy wrapper — returns filepath string or false.
 * Prefer nsmsStoreUpload() for new code (structured errors).
 */
function uploadFile($file, $directory = 'uploads/', $allowedTypes = array('jpg', 'jpeg', 'png', 'pdf')) {
    $res = nsmsStoreUpload($file, $directory, $allowedTypes);
    return !empty($res['ok']) ? $res['path'] : false;
}

/**
 * Delete file
 * @param string $filepath
 * @return bool
 */
function deleteFile($filepath) {
    if (file_exists($filepath)) {
        return unlink($filepath);
    }
    return false;
}

/**
 * Calculate attendance percentage
 * @param int $present
 * @param int $total
 * @return float
 */
function calculateAttendancePercentage($present, $total) {
    if ($total == 0) return 0;
    return round(($present / $total) * 100, 1);
}

/**
 * Get student's full name with parent info
 * @param object $db
 * @param int $studentId
 * @return array
 */
function getStudentWithParent($db, $studentId) {
    $sql = "SELECT s.*, c.class_name, c.class_color,
                   u.full_name as parent_name, u.email as parent_email, u.phone as parent_phone
            FROM students s
            JOIN classes c ON s.class_id = c.id
            LEFT JOIN parents p ON s.id = p.student_id
            LEFT JOIN users u ON p.user_id = u.id
            WHERE s.id = :student_id
            LIMIT 1";
    
    return $db->queryOne($sql, array(':student_id' => $studentId));
}

/**
 * Send SMS notification (placeholder - integrate with SMS API)
 * @param string $phone
 * @param string $message
 * @return bool
 */
function sendSMS($phone, $message) {
    // TODO: Integrate with Africa's Talking or Bongo Live SMS API
    // For now, just log the SMS
    error_log("SMS to {$phone}: {$message}");
    return true;
}

/**
 * Send email notification (placeholder)
 * @param string $email
 * @param string $subject
 * @param string $message
 * @return bool
 */
/**
 * Send a transactional email via Brevo's HTTP API.
 * @param string $email   Recipient email address
 * @param string $subject Email subject
 * @param string $message HTML body (plain text also accepted — Brevo will render it as-is)
 * @return bool true if Brevo accepted the email, false otherwise
 */

/**
 * Simple file-based rate limiter (shared hosting friendly).
 * Returns true if allowed; false if over limit.
 *
 * @param string $bucket e.g. login:ip or forgot:email
 * @param int $maxAttempts
 * @param int $windowSeconds
 */
function nsmsRateLimit($bucket, $maxAttempts = 10, $windowSeconds = 900) {
    $bucket = preg_replace('/[^a-zA-Z0-9:_@.-]/', '_', (string)$bucket);
    $dir = dirname(__DIR__) . '/uploads/.rate_limit';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $file = $dir . '/' . hash('sha256', $bucket) . '.json';
    $now = time();
    $data = array('hits' => array());
    if (is_file($file)) {
        $raw = @file_get_contents($file);
        $decoded = $raw ? json_decode($raw, true) : null;
        if (is_array($decoded) && isset($decoded['hits']) && is_array($decoded['hits'])) {
            $data = $decoded;
        }
    }
    $hits = array();
    foreach ($data['hits'] as $ts) {
        if ((int)$ts > $now - $windowSeconds) {
            $hits[] = (int)$ts;
        }
    }
    if (count($hits) >= (int)$maxAttempts) {
        @file_put_contents($file, json_encode(array('hits' => $hits)), LOCK_EX);
        return false;
    }
    $hits[] = $now;
    @file_put_contents($file, json_encode(array('hits' => $hits)), LOCK_EX);
    return true;
}

function nsmsClientIp() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($parts[0]);
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
}

function sendEmail($email, $subject, $message) {
    $configPath = __DIR__ . '/mail_config.php';
    if (!file_exists($configPath)) {
        error_log("sendEmail: mail_config.php not found — copy mail_config.example.php and fill in your Brevo details. Email to {$email} not sent.");
        return false;
    }
    require_once $configPath;

    if (!defined('BREVO_API_KEY') || strpos(BREVO_API_KEY, 'xkeysib-xxxx') === 0) {
        error_log("sendEmail: Brevo API key not configured yet (still a placeholder). Email to {$email} not sent.");
        return false;
    }
    if (!function_exists('curl_init')) {
        error_log('sendEmail: PHP curl extension is not enabled — cannot reach Brevo.');
        return false;
    }

    $payload = [
        'sender'      => ['name' => MAIL_SENDER_NAME, 'email' => MAIL_SENDER_EMAIL],
        'to'          => [['email' => $email]],
        'subject'     => $subject,
        'htmlContent' => $message,
    ];

    $ch = curl_init('https://api.brevo.com/v3/smtp/email');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'accept: application/json',
            'api-key: ' . BREVO_API_KEY,
            'content-type: application/json',
        ],
        CURLOPT_TIMEOUT        => 10,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        error_log("sendEmail: cURL error sending to {$email}: {$curlErr}");
        return false;
    }
    // Brevo returns 201 Created with a messageId on success
    if ($httpCode >= 200 && $httpCode < 300) {
        return true;
    }

    error_log("sendEmail: Brevo rejected email to {$email} (HTTP {$httpCode}): {$response}");
    return false;
}

/**
 * Log activity
 * @param object $db
 * @param int $userId
 * @param string $action
 * @param string $details
 */
function logActivity($db, $userId, $action, $details = '') {
    error_log("User {$userId}: {$action} - {$details}");
    if (!$db || !is_object($db)) {
        return;
    }
    try {
        static $ready = null;
        if ($ready === null) {
            try {
                $db->execute(
                    "CREATE TABLE IF NOT EXISTS activity_logs (
                        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                        user_id INT NULL,
                        action VARCHAR(64) NOT NULL,
                        details VARCHAR(500) DEFAULT NULL,
                        ip VARCHAR(45) DEFAULT NULL,
                        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (id),
                        KEY idx_action_created (action, created_at),
                        KEY idx_user_created (user_id, created_at)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
                );
                $ready = true;
            } catch (Exception $e) {
                $ready = false;
            }
        }
        if (!$ready) return;
        $ip = isset($_SERVER['REMOTE_ADDR']) ? substr((string)$_SERVER['REMOTE_ADDR'], 0, 45) : null;
        $db->execute(
            "INSERT INTO activity_logs (user_id, action, details, ip) VALUES (:u, :a, :d, :ip)",
            array(
                ':u' => $userId ? (int)$userId : null,
                ':a' => substr((string)$action, 0, 64),
                ':d' => substr((string)$details, 0, 500),
                ':ip' => $ip,
            )
        );
    } catch (Exception $e) {
        // never break the request because of logging
    }
}
/**
 * Generate a readable temporary password (no ambiguous characters).
 * @param int $length
 * @return string
 */
function nsmsGenerateTempPassword($length = 10) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
    $max   = strlen($chars) - 1;
    $out   = '';
    for ($i = 0; $i < $length; $i++) {
        try {
            $out .= $chars[random_int(0, $max)];
        } catch (Exception $e) {
            $out .= $chars[mt_rand(0, $max)];
        }
    }
    return $out;
}

/**
 * Ensure password_reset_tokens table exists (self-heal).
 */
function nsmsEnsureResetTokensTable($db) {
    static $done = false;
    if ($done) return;
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS password_reset_tokens (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id INT NOT NULL,
                token_hash CHAR(64) NOT NULL,
                expires_at DATETIME NOT NULL,
                used_at DATETIME DEFAULT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_token_hash (token_hash),
                KEY idx_user (user_id),
                KEY idx_expires (expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Exception $e) {
        error_log('nsmsEnsureResetTokensTable: ' . $e->getMessage());
    }
    $done = true;
}

/**
 * Public site base for email links (no trailing slash).
 */
function nsmsPublicBaseUrl() {
    if (defined('NSMS_SITE_URL') && NSMS_SITE_URL) {
        return rtrim(NSMS_SITE_URL, '/');
    }
    if (defined('SITE_URL') && SITE_URL) {
        return rtrim(SITE_URL, '/');
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
    $scheme = $https ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    return $scheme . '://' . $host . '/nsms';
}

/**
 * Create a one-time reset token (raw token returned once; only hash stored).
 * @return array{ok:bool,token?:string,expires_at?:string,error?:string}
 */
function nsmsCreateResetToken($db, $userId, $ttlMinutes = 60) {
    nsmsEnsureResetTokensTable($db);
    $userId = (int) $userId;
    if ($userId < 1) {
        return array('ok' => false, 'error' => 'Invalid user');
    }
    try {
        $raw = bin2hex(random_bytes(32));
    } catch (Exception $e) {
        $raw = bin2hex(openssl_random_pseudo_bytes(32));
    }
    $hash = hash('sha256', $raw);
    $expires = date('Y-m-d H:i:s', time() + max(5, (int)$ttlMinutes) * 60);

    // Invalidate prior unused tokens for this user
    try {
        $db->execute(
            "UPDATE password_reset_tokens SET used_at = NOW()
             WHERE user_id = :uid AND used_at IS NULL",
            array(':uid' => $userId)
        );
    } catch (Exception $e) { /* ignore */ }

    $ok = $db->execute(
        "INSERT INTO password_reset_tokens (user_id, token_hash, expires_at)
         VALUES (:uid, :th, :exp)",
        array(':uid' => $userId, ':th' => $hash, ':exp' => $expires)
    );
    if ($ok === false) {
        return array('ok' => false, 'error' => 'Could not create reset token');
    }
    return array('ok' => true, 'token' => $raw, 'expires_at' => $expires);
}

/**
 * Consume a valid reset token and set a new password (marks activated).
 * @return array{ok:bool,error?:string,user?:array}
 */
function nsmsConsumeResetToken($db, $rawToken, $newPassword) {
    nsmsEnsureResetTokensTable($db);
    $rawToken = trim((string) $rawToken);
    if (strlen($rawToken) < 32) {
        return array('ok' => false, 'error' => 'Invalid or expired reset link');
    }
    if (strlen($newPassword) < 8) {
        return array('ok' => false, 'error' => 'Password must be at least 8 characters');
    }

    $hash = hash('sha256', $rawToken);
    $row = $db->queryOne(
        "SELECT t.id AS token_id, t.user_id, t.expires_at, t.used_at,
                u.id, u.email, u.full_name, u.role, u.status
         FROM password_reset_tokens t
         JOIN users u ON u.id = t.user_id
         WHERE t.token_hash = :th
         LIMIT 1",
        array(':th' => $hash)
    );
    if (!$row) {
        return array('ok' => false, 'error' => 'Invalid or expired reset link');
    }
    if (!empty($row['used_at'])) {
        return array('ok' => false, 'error' => 'This reset link was already used');
    }
    if (strtotime($row['expires_at']) < time()) {
        return array('ok' => false, 'error' => 'This reset link has expired');
    }
    if (!in_array($row['role'], array('teacher', 'parent'), true)) {
        return array('ok' => false, 'error' => 'Account cannot use this reset flow');
    }
    if (isset($row['status']) && strtolower((string)$row['status']) !== 'active') {
        return array('ok' => false, 'error' => 'Account is not active');
    }

    $pwHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $db->execute(
        "UPDATE users SET password_hash = :h, password_changed = 1 WHERE id = :id",
        array(':h' => $pwHash, ':id' => (int)$row['user_id'])
    );
    $db->execute(
        "UPDATE password_reset_tokens SET used_at = NOW() WHERE id = :id",
        array(':id' => (int)$row['token_id'])
    );
    // burn other tokens
    try {
        $db->execute(
            "UPDATE password_reset_tokens SET used_at = NOW()
             WHERE user_id = :uid AND used_at IS NULL",
            array(':uid' => (int)$row['user_id'])
        );
    } catch (Exception $e) { /* ignore */ }

    if (function_exists('logActivity')) {
        logActivity($db, (int)$row['user_id'], 'PASSWORD_RESET_COMPLETE', 'Password set via reset link');
    }

    return array(
        'ok' => true,
        'user' => array(
            'id' => (int)$row['user_id'],
            'email' => $row['email'],
            'full_name' => $row['full_name'],
            'role' => $row['role'],
        ),
    );
}

/**
 * Issue a reset link for a parent/teacher (forgot password or admin).
 * Does not change the current password until the link is used.
 *
 * @return array{ok:bool,reset_url?:string,email_sent?:bool,user?:array,error?:string,token?:string}
 */
function nsmsIssuePasswordResetLink($db, $userId, $ttlMinutes = 60) {
    $userId = (int) $userId;
    $user = $db->queryOne(
        "SELECT id, email, full_name, role, phone, status FROM users WHERE id = :id LIMIT 1",
        array(':id' => $userId)
    );
    if (!$user) {
        return array('ok' => false, 'error' => 'User not found');
    }
    if (!in_array($user['role'], array('teacher', 'parent'), true)) {
        return array('ok' => false, 'error' => 'Only teacher or parent accounts can use reset links');
    }
    if (isset($user['status']) && strtolower((string)$user['status']) !== 'active') {
        return array('ok' => false, 'error' => 'Account is not active');
    }
    if (empty($user['email']) || strpos($user['email'], '@nsms.local') !== false) {
        return array('ok' => false, 'error' => 'Account has no valid email address');
    }

    $tok = nsmsCreateResetToken($db, $userId, $ttlMinutes);
    if (empty($tok['ok'])) {
        return $tok;
    }

    $base = nsmsPublicBaseUrl();
    $resetUrl = $base . '/public/reset-password.html?token=' . urlencode($tok['token']);

    $emailSent = nsmsEmailResetLink($user, $resetUrl, $tok['expires_at']);

    if (function_exists('logActivity')) {
        logActivity($db, $userId, 'PASSWORD_RESET_LINK', 'Reset link issued');
    }

    return array(
        'ok'         => true,
        'reset_url'  => $resetUrl,
        'email_sent' => $emailSent,
        'user'       => $user,
        // token only for admin offline fallback — never log in production if avoidable
        'token'      => $tok['token'],
        'expires_at' => $tok['expires_at'],
    );
}

/**
 * Legacy: force new temp password + activation (admin emergency / offline).
 * Prefer nsmsIssuePasswordResetLink when email works.
 */
function nsmsResetActivation($db, $userId) {
    $userId = (int) $userId;
    if ($userId < 1) {
        return array('ok' => false, 'error' => 'Invalid user');
    }

    $user = $db->queryOne(
        "SELECT id, email, full_name, role, phone, status FROM users WHERE id = :id LIMIT 1",
        array(':id' => $userId)
    );
    if (!$user) {
        return array('ok' => false, 'error' => 'User not found');
    }
    if (!in_array($user['role'], array('teacher', 'parent'), true)) {
        return array('ok' => false, 'error' => 'Only teacher or parent accounts can be reset this way');
    }
    if (isset($user['status']) && strtolower((string) $user['status']) !== 'active') {
        return array('ok' => false, 'error' => 'Account is not active');
    }
    if (empty($user['email']) || strpos($user['email'], '@nsms.local') !== false) {
        return array('ok' => false, 'error' => 'Account has no valid email address');
    }

    // Prefer secure link; fall back to temp password if token table fails
    $link = nsmsIssuePasswordResetLink($db, $userId, 60);
    if (!empty($link['ok'])) {
        return array(
            'ok'            => true,
            'mode'          => 'link',
            'reset_url'     => $link['reset_url'],
            'email_sent'    => $link['email_sent'],
            'user'          => $user,
            'temp_password' => null,
            'token'         => isset($link['token']) ? $link['token'] : null,
        );
    }

    $temp = nsmsGenerateTempPassword(10);
    $hash = password_hash($temp, PASSWORD_DEFAULT);
    $ok = $db->execute(
        "UPDATE users
         SET password_hash = :h, password_changed = 0, last_login = NULL
         WHERE id = :id AND role IN ('teacher','parent')",
        array(':h' => $hash, ':id' => $userId)
    );
    if ($ok === false) {
        return array('ok' => false, 'error' => 'Failed to update password');
    }
    $emailSent = nsmsEmailResetCredentials($user, $temp);
    return array(
        'ok'            => true,
        'mode'          => 'temp_password',
        'temp_password' => $temp,
        'user'          => $user,
        'email_sent'    => $emailSent,
    );
}

function nsmsEmailResetLink($user, $resetUrl, $expiresAt) {
    if (!function_exists('sendEmail')) {
        return false;
    }
    $email = isset($user['email']) ? $user['email'] : '';
    $name  = isset($user['full_name']) ? $user['full_name'] : 'User';
    $role  = isset($user['role']) ? $user['role'] : 'user';
    if ($email === '') return false;

    $roleLabel = ($role === 'teacher') ? 'teacher' : 'parent';
    $subject = 'Reset your NSMS password';
    $body =
        '<p>Dear ' . htmlspecialchars($name) . ',</p>' .
        '<p>We received a request to reset your ' . htmlspecialchars($roleLabel) . ' account password.</p>' .
        '<p><a href="' . htmlspecialchars($resetUrl) . '" style="display:inline-block;padding:12px 20px;' .
        'background:#1B3D2F;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;">Choose a new password</a></p>' .
        '<p style="color:#555;font-size:13px;">This link expires at <strong>' . htmlspecialchars($expiresAt) . '</strong> ' .
        'and can be used only once. If you did not request a reset, you can ignore this email — your password stays the same.</p>' .
        '<p style="color:#888;font-size:12px;">If the button does not work, copy this URL:<br>' .
        '<span style="word-break:break-all;">' . htmlspecialchars($resetUrl) . '</span></p>';

    return (bool) sendEmail($email, $subject, $body);
}

function nsmsEmailResetCredentials($user, $tempPassword) {
    if (!function_exists('sendEmail')) {
        return false;
    }
    $email = isset($user['email']) ? $user['email'] : '';
    $name  = isset($user['full_name']) ? $user['full_name'] : 'User';
    $role  = isset($user['role']) ? $user['role'] : 'user';
    if ($email === '') {
        return false;
    }

    $loginUrl = nsmsPublicBaseUrl() . '/public/index.html';
    $roleLabel = ($role === 'teacher') ? 'teacher' : 'parent';
    $subject   = 'Your NSMS account password was reset';
    $body      =
        '<p>Dear ' . htmlspecialchars($name) . ',</p>' .
        '<p>Your ' . htmlspecialchars($roleLabel) . ' account password has been reset. ' .
        'Please sign in with the temporary password below, then choose a new personal password.</p>' .
        '<p><strong>Email:</strong> ' . htmlspecialchars($email) . '<br>' .
        '<strong>Temporary password:</strong> <code style="font-size:16px;letter-spacing:1px;">' .
        htmlspecialchars($tempPassword) . '</code></p>' .
        '<p><a href="' . htmlspecialchars($loginUrl) . '" style="display:inline-block;padding:10px 18px;' .
        'background:#1B3D2F;color:#fff;text-decoration:none;border-radius:6px;">Sign in</a></p>';

    return (bool) sendEmail($email, $subject, $body);
}


/* =====================================================================
   REGISTRATION VALIDATION HELPERS (students, teachers, classes)
   ===================================================================== */

/**
 * Ensure classes.minimum_age column exists (idempotent).
 */
function nsmsEnsureClassMinimumAgeColumn($db) {
    static $done = false;
    if ($done) {
        return true;
    }
    try {
        $cols = $db->query("SHOW COLUMNS FROM classes LIKE 'minimum_age'");
        if (empty($cols)) {
            $db->execute(
                "ALTER TABLE classes
                 ADD COLUMN minimum_age INT UNSIGNED NULL DEFAULT NULL
                 COMMENT 'Minimum age in full years required for admission'"
            );
        }
        $done = true;
        return true;
    } catch (Exception $e) {
        error_log('nsmsEnsureClassMinimumAgeColumn: ' . $e->getMessage());
        return false;
    }
}

/**
 * Person name: letters (incl. accented), spaces, hyphen, apostrophe, period.
 * Rejects digits, emojis, and most symbols.
 */
function nsmsValidatePersonName($name, $label = 'Name') {
    $name = trim((string) $name);
    if ($name === '') {
        return array('ok' => false, 'error' => $label . ' is required', 'value' => '');
    }
    if (mb_strlen($name) < 2) {
        return array('ok' => false, 'error' => $label . ' is too short', 'value' => $name);
    }
    if (mb_strlen($name) > 120) {
        return array('ok' => false, 'error' => $label . ' is too long', 'value' => $name);
    }
    // Unicode letters, marks, spaces, hyphen, apostrophe, period
    if (!preg_match("/^[\\p{L}\\p{M}][\\p{L}\\p{M}\\s'.\\-]*$/u", $name)) {
        return array('ok' => false, 'error' => $label . ' may only contain letters and common name characters', 'value' => $name);
    }
    // Collapse internal whitespace
    $name = preg_replace('/\\s+/u', ' ', $name);
    return array('ok' => true, 'error' => null, 'value' => $name);
}

/**
 * Normalise and validate phone (TZ-friendly international + local).
 * Accepts: +255712345678, 0712345678, 255712345678
 * Stores digits with optional leading + for international.
 */
function nsmsValidatePhone($phone, $required = false, $label = 'Phone number') {
    $raw = trim((string) $phone);
    if ($raw === '') {
        if ($required) {
            return array('ok' => false, 'error' => $label . ' is required', 'value' => '');
        }
        return array('ok' => true, 'error' => null, 'value' => '');
    }

    // Reject letters and invalid symbols early
    if (preg_match('/[A-Za-z]/', $raw) || preg_match('/[@#$%*={}\\[\\]<>\\\\]/', $raw)) {
        return array('ok' => false, 'error' => $label . ' must contain a valid phone number', 'value' => $raw);
    }

    // Compact to digits + optional leading + (reject letters/symbols)
    $compact = preg_replace('/[\\s\\-().]/', '', $raw);
    if ($compact === null) { $compact = $raw; }
    if (!preg_match('/^\\+?[0-9]+$/', $compact)) {
        return array('ok' => false, 'error' => $label . ' may only contain digits and an optional + at the start', 'value' => $raw);
    }
    $raw = $compact;
    if (substr_count($raw, '+') > 1 || (strpos($raw, '+') > 0)) {
        return array('ok' => false, 'error' => $label . ' may only have + at the beginning', 'value' => $raw);
    }

    $hasPlus = strpos($raw, '+') === 0;
    $digits = preg_replace('/\\D+/', '', $raw);
    if ($digits === '' || strlen($digits) < 9) {
        return array('ok' => false, 'error' => $label . ' is too short', 'value' => $raw);
    }
    if (strlen($digits) > 15) {
        return array('ok' => false, 'error' => $label . ' is too long', 'value' => $raw);
    }

    // Normalise Tanzania local 0XXXXXXXXX → +255XXXXXXXXX when 10 digits starting with 0
    if (!$hasPlus && strlen($digits) === 10 && $digits[0] === '0') {
        $normalized = '+255' . substr($digits, 1);
    } elseif ($hasPlus) {
        $normalized = '+' . $digits;
    } elseif (strlen($digits) === 12 && strpos($digits, '255') === 0) {
        $normalized = '+' . $digits;
    } else {
        // Keep leading 0 local forms as-is if not clearly international
        $normalized = $hasPlus ? ('+' . $digits) : $digits;
    }

    return array('ok' => true, 'error' => null, 'value' => $normalized);
}


/**
 * Find a user by email (case-insensitive). One email = one user.
 * @return array|null row with id, email, role, full_name, status
 */
function nsmsFindUserByEmail($db, $email) {
    $email = strtolower(trim((string) $email));
    if ($email === '') {
        return null;
    }
    try {
        return $db->queryOne(
            "SELECT id, email, role, full_name, status, phone
               FROM users
              WHERE LOWER(TRIM(email)) = :e
              LIMIT 1",
            array(':e' => $email)
        );
    } catch (Exception $e) {
        error_log('nsmsFindUserByEmail: ' . $e->getMessage());
        return null;
    }
}

/**
 * Ensure email is free, or belongs only to $excludeUserId (for updates).
 * @return array{ok:bool,error:?string,user:?array}
 */
function nsmsAssertEmailAvailable($db, $email, $excludeUserId = null) {
    $email = strtolower(trim((string) $email));
    if ($email === '') {
        return array('ok' => true, 'error' => null, 'user' => null);
    }
    $row = nsmsFindUserByEmail($db, $email);
    if (!$row) {
        return array('ok' => true, 'error' => null, 'user' => null);
    }
    $rid = (int) $row['id'];
    if ($excludeUserId !== null && $rid === (int) $excludeUserId) {
        return array('ok' => true, 'error' => null, 'user' => $row);
    }
    return array(
        'ok' => false,
        'error' => 'This email is already registered to another user. Each email can only belong to one account.',
        'user' => $row,
    );
}

function nsmsValidateEmail($email, $required = false, $label = 'Email') {
    $email = trim((string) $email);
    if ($email === '') {
        if ($required) {
            return array('ok' => false, 'error' => $label . ' is required', 'value' => '');
        }
        return array('ok' => true, 'error' => null, 'value' => '');
    }
    $email = strtolower($email);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return array('ok' => false, 'error' => 'Please enter a valid email address', 'value' => $email);
    }
    if (strlen($email) > 190) {
        return array('ok' => false, 'error' => $label . ' is too long', 'value' => $email);
    }
    return array('ok' => true, 'error' => null, 'value' => $email);
}

function nsmsValidateGender($gender) {
    $g = trim((string) $gender);
    $allowed = array('Male', 'Female', 'Other');
    // case-insensitive match to canonical
    foreach ($allowed as $a) {
        if (strcasecmp($g, $a) === 0) {
            return array('ok' => true, 'error' => null, 'value' => $a);
        }
    }
    return array('ok' => false, 'error' => 'Please select a valid gender', 'value' => $g);
}

/**
 * Validate ISO date (Y-m-d). Rejects future DOB when $allowFuture is false.
 */
function nsmsValidateDate($date, $label = 'Date', $allowFuture = true, $minYear = 1900) {
    $date = trim((string) $date);
    if ($date === '') {
        return array('ok' => false, 'error' => $label . ' is required', 'value' => '');
    }
    $dt = DateTime::createFromFormat('Y-m-d', $date);
    $errors = DateTime::getLastErrors();
    if (!$dt || ($errors && (($errors['warning_count'] ?? 0) > 0 || ($errors['error_count'] ?? 0) > 0))) {
        return array('ok' => false, 'error' => $label . ' must be a valid date', 'value' => $date);
    }
    if ((int) $dt->format('Y') < $minYear) {
        return array('ok' => false, 'error' => $label . ' year is not valid', 'value' => $date);
    }
    if (!$allowFuture) {
        $today = new DateTime('today');
        if ($dt > $today) {
            return array('ok' => false, 'error' => $label . ' cannot be in the future', 'value' => $date);
        }
    }
    return array('ok' => true, 'error' => null, 'value' => $dt->format('Y-m-d'));
}

/**
 * Age in full years and remaining months as of $asOf (Y-m-d or null = today).
 * @return array{years:int,months:int,total_months:int}|null
 */
function nsmsCalcAgeParts($dob, $asOf = null) {
    try {
        $birth = new DateTime($dob);
        $ref = $asOf ? new DateTime($asOf) : new DateTime('today');
        if ($birth > $ref) {
            return null;
        }
        $diff = $birth->diff($ref);
        return array(
            'years' => (int) $diff->y,
            'months' => (int) $diff->m,
            'days' => (int) $diff->d,
            'total_months' => ((int) $diff->y) * 12 + (int) $diff->m,
        );
    } catch (Exception $e) {
        return null;
    }
}

/**
 * Whether DOB meets minimum full years for a class as of a date.
 */
function nsmsMeetsMinimumAge($dob, $minimumAgeYears, $asOf = null) {
    $min = (int) $minimumAgeYears;
    if ($min <= 0) {
        return array('ok' => true, 'age' => nsmsCalcAgeParts($dob, $asOf), 'message' => null);
    }
    $age = nsmsCalcAgeParts($dob, $asOf);
    if ($age === null) {
        return array('ok' => false, 'age' => null, 'message' => 'Could not calculate age from date of birth');
    }
    if ($age['years'] < $min) {
        $label = $age['years'] . ' year' . ($age['years'] === 1 ? '' : 's');
        if ($age['months'] > 0) {
            $label .= ', ' . $age['months'] . ' month' . ($age['months'] === 1 ? '' : 's');
        }
        return array(
            'ok' => false,
            'age' => $age,
            'message' => 'This student does not meet the minimum age requirement. The minimum required age is '
                . $min . ' years. Current age: ' . $label . '.',
        );
    }
    return array('ok' => true, 'age' => $age, 'message' => null);
}

/**
 * Validate minimum_age value for a class (null/empty = no requirement).
 */
function nsmsValidateMinimumAge($value) {
    if ($value === null || $value === '') {
        return array('ok' => true, 'error' => null, 'value' => null);
    }
    if (!is_numeric($value) || (string)(int)$value !== (string)(int)(float)$value && (int)$value != $value) {
        // allow numeric strings
    }
    if (!is_numeric($value)) {
        return array('ok' => false, 'error' => 'Minimum age must be a number', 'value' => null);
    }
    $n = (int) $value;
    if ($n < 0 || $n > 25) {
        return array('ok' => false, 'error' => 'Minimum age must be between 0 and 25 years', 'value' => $n);
    }
    return array('ok' => true, 'error' => null, 'value' => $n);
}
