<?php
/**
 * Database Connection Class
 * Uses PDO for secure database operations
 * Compatible with PHP 7.2+
 *
 * Credentials are read from environment variables when set, otherwise
 * fall back to local defaults (for XAMPP/WAMP development only).
 * Never commit production passwords.
 *
 *   NSMS_DB_HOST, NSMS_DB_PORT, NSMS_DB_NAME, NSMS_DB_USER, NSMS_DB_PASS
 */

class Database {
    public $lastError = null;
    private $host;
    private $port;
    private $db_name;
    private $username;
    private $password;
    private $conn = null;

    public function __construct() {
        $this->host     = getenv('NSMS_DB_HOST') ?: 'localhost';
        $this->port     = getenv('NSMS_DB_PORT') ?: '3307';
        $this->db_name  = getenv('NSMS_DB_NAME') ?: 'nsms';
        $this->username = getenv('NSMS_DB_USER') ?: 'root';
        $this->password = getenv('NSMS_DB_PASS') !== false ? getenv('NSMS_DB_PASS') : '';
    }

    /**
     * Get database connection
     * @return PDO|null
     */
    /** @var bool|null process-local cache of last connect outcome */
    private static $fastFailCache = null;
    private static $fastFailAt = 0;

    /**
     * Path for short-lived MySQL down cache (avoids multi-second hangs per request).
     */
    private static function statusCachePath() {
        $dir = dirname(__DIR__) . '/data';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return $dir . '/mysql_status_cache.json';
    }

    private static function readDownCache() {
        $path = self::statusCachePath();
        if (!is_file($path)) return null;
        $raw = @file_get_contents($path);
        if ($raw === false) return null;
        $j = json_decode($raw, true);
        if (!is_array($j) || empty($j['down'])) return null;
        $age = time() - (int)(isset($j['ts']) ? $j['ts'] : 0);
        // Remember "down" briefly — short TTL so recovery after restart is fast
        if ($age >= 0 && $age <= 8) {
            return true;
        }
        return null;
    }

    private static function writeDownCache($down) {
        $path = self::statusCachePath();
        @file_put_contents($path, json_encode(array(
            'down' => (bool)$down,
            'ts' => time(),
        )));
    }

    public function connect($force = false) {
        if ($this->conn !== null) {
            return $this->conn;
        }

        // Process-local + file cache: if MySQL was just unreachable, fail in milliseconds
        // $force=true always retries (login / critical session paths)
        if (!$force) {
            if (self::$fastFailCache === false && (time() - self::$fastFailAt) <= 8) {
                return null;
            }
            if (self::readDownCache() === true) {
                self::$fastFailCache = false;
                self::$fastFailAt = time();
                return null;
            }
        }

        $prevTimeout = ini_get('default_socket_timeout');
        try {
            // Hard cap TCP wait — critical for offline UX
            @ini_set('default_socket_timeout', '3');
            $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->db_name};charset=utf8mb4";
            $options = array(
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            );
            // ATTR_TIMEOUT is honored by some drivers (seconds)
            if (defined('PDO::ATTR_TIMEOUT')) {
                $options[PDO::ATTR_TIMEOUT] = 3;
            }

            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
            self::$fastFailCache = true;
            self::$fastFailAt = time();
            self::writeDownCache(false);
            return $this->conn;

        } catch (PDOException $e) {
            error_log('Database Connection Error: ' . $e->getMessage());
            self::$fastFailCache = false;
            self::$fastFailAt = time();
            self::writeDownCache(true);
            return null;
        } finally {
            if ($prevTimeout !== false && $prevTimeout !== null) {
                @ini_set('default_socket_timeout', (string)$prevTimeout);
            }
        }
    }

    /** Clear down-cache after successful recovery (optional). */
    public static function clearDownCache() {
        self::$fastFailCache = null;
        self::$fastFailAt = 0;
        $path = self::statusCachePath();
        if (is_file($path)) @unlink($path);
    }

    /**
     * Execute SELECT query
     * @param string $sql
     * @param array  $params
     * @return array|false
     */
    public function query($sql, $params = array()) {
        try {
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log('Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Execute INSERT/UPDATE/DELETE query
     * @param string $sql
     * @param array  $params
     * @return bool|int Returns lastInsertId for INSERT, affected rows for UPDATE/DELETE
     */
    public function execute($sql, $params = array()) {
        try {
            $stmt   = $this->conn->prepare($sql);
            $result = $stmt->execute($params);

            if (stripos(trim($sql), 'INSERT') === 0) {
                return $this->conn->lastInsertId();
            }

            return $stmt->rowCount();

        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            error_log('Execute Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get single row
     * @param string $sql
     * @param array  $params
     * @return array|false
     */
    public function queryOne($sql, $params = array()) {
        try {
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log('QueryOne Error: ' . $e->getMessage());
            return false;
        }
    }

    public function beginTransaction() {
        return $this->conn->beginTransaction();
    }

    public function commit() {
        return $this->conn->commit();
    }

    public function rollback() {
        return $this->conn->rollBack();
    }
}
