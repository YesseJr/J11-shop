<?php
/**
 * Copy to mail_config.php and fill in real values (do not commit secrets).
 *
 * Production (preferred): set environment variables —
 *   NSMS_SITE_URL=https://your-domain.com/nsms
 *   NSMS_BREVO_API_KEY=xkeysib-...
 *   NSMS_MAIL_SENDER_EMAIL=noreply@your-domain.com
 *   NSMS_MAIL_SENDER_NAME=Your School Name
 */

if (!defined('SITE_URL')) {
    define('SITE_URL', 'https://your-domain.com/nsms');
}
if (!defined('BREVO_API_KEY')) {
    define('BREVO_API_KEY', 'xkeysib-xxxx');
}
if (!defined('MAIL_SENDER_EMAIL')) {
    define('MAIL_SENDER_EMAIL', 'noreply@your-domain.com');
}
if (!defined('MAIL_SENDER_NAME')) {
    define('MAIL_SENDER_NAME', 'Your School Name');
}
