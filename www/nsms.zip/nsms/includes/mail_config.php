<?php
/**
 * Local mail / site settings (Laragon / production).
 * Safe to re-include: constants only defined if missing.
 */

if (!defined('SITE_URL')) {
    define('SITE_URL', 'http://localhost/nsms');
}
if (!defined('BREVO_API_KEY')) {
    define('BREVO_API_KEY', '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');
}
if (!defined('MAIL_SENDER_EMAIL')) {
    define('MAIL_SENDER_EMAIL', 'waythonny@gmail.com');
}
if (!defined('MAIL_SENDER_NAME')) {
    define('MAIL_SENDER_NAME', 'J11 Nursery School');
}
