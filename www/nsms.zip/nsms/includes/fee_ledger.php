<?php
/**
 * Unified fee ledger reads across fee_payments + payment_transactions.
 * Does NOT migrate or delete data — safe for production dual-path installs.
 */

/**
 * Confirmed amount attributed to a student from legacy fee_payments.
 */
function nsmsLedgerPaidFromFeePayments($db, $studentId) {
    $studentId = (int) $studentId;
    try {
        $row = $db->queryOne(
            "SELECT COALESCE(SUM(amount), 0) AS total
             FROM fee_payments
             WHERE student_id = :sid
               AND (status = 'confirmed' OR status = 'paid' OR status IS NULL OR status = '')",
            array(':sid' => $studentId)
        );
        return $row ? (float) $row['total'] : 0.0;
    } catch (Exception $e) {
        return 0.0;
    }
}

/**
 * Verified / approved amount from payment_transactions (parent gateway path).
 */
function nsmsLedgerPaidFromTransactions($db, $studentId) {
    $studentId = (int) $studentId;
    try {
        $row = $db->queryOne(
            "SELECT COALESCE(SUM(amount), 0) AS total
             FROM payment_transactions
             WHERE student_id = :sid
               AND status IN ('verified','approved','confirmed','paid')",
            array(':sid' => $studentId)
        );
        return $row ? (float) $row['total'] : 0.0;
    } catch (Exception $e) {
        return 0.0;
    }
}

/**
 * Combined paid total. By default uses the MAX of the two sources to avoid
 * double-counting when the same payment was recorded in both tables.
 * Set $mode to 'sum' only after confirming no overlap.
 *
 * @return array{fee_payments:float,payment_transactions:float,combined:float,mode:string}
 */
function nsmsLedgerStudentPaid($db, $studentId, $mode = 'max') {
    $a = nsmsLedgerPaidFromFeePayments($db, $studentId);
    $b = nsmsLedgerPaidFromTransactions($db, $studentId);
    $combined = ($mode === 'sum') ? ($a + $b) : max($a, $b);
    return array(
        'fee_payments' => $a,
        'payment_transactions' => $b,
        'combined' => $combined,
        'mode' => $mode,
    );
}

/**
 * Admin reconciliation snapshot (read-only).
 */
function nsmsLedgerReconcileSummary($db, $limit = 50) {
    $limit = max(1, min(200, (int) $limit));
    $students = array();
    try {
        $students = $db->query(
            "SELECT id, student_name, class_id, status FROM students WHERE status = 'active' ORDER BY student_name ASC LIMIT {$limit}"
        ) ?: array();
    } catch (Exception $e) {
        $students = array();
    }

    $rows = array();
    $mismatch = 0;
    foreach ($students as $s) {
        $paid = nsmsLedgerStudentPaid($db, (int) $s['id'], 'max');
        $diff = abs($paid['fee_payments'] - $paid['payment_transactions']);
        if ($diff > 0.009) {
            $mismatch++;
        }
        $rows[] = array(
            'student_id' => (int) $s['id'],
            'student_name' => $s['student_name'],
            'class_id' => isset($s['class_id']) ? (int) $s['class_id'] : null,
            'paid_fee_payments' => $paid['fee_payments'],
            'paid_payment_transactions' => $paid['payment_transactions'],
            'paid_combined_max' => $paid['combined'],
            'sources_differ' => $diff > 0.009,
            'difference' => $diff,
        );
    }

    return array(
        'students_checked' => count($rows),
        'mismatch_count' => $mismatch,
        'note' => 'Read-only. combined uses MAX(fee_payments, payment_transactions) to avoid double-counting until a formal migration.',
        'rows' => $rows,
    );
}

/**
 * Promote verified gateway transactions into fee_payments when missing.
 * Safe: only inserts when no matching fee_payments row exists for the same
 * student + amount + date + reference (or payment_items.fee_payment_id empty).
 * Never deletes.
 *
 * @return array{scanned:int,promoted:int,skipped:int,errors:array}
 */
function nsmsLedgerPromoteTransactions($db, $limit = 100) {
    $limit = max(1, min(500, (int) $limit));
    $result = array('scanned' => 0, 'promoted' => 0, 'skipped' => 0, 'errors' => array());

    try {
        $txns = $db->query(
            "SELECT pt.id, pt.student_id, pt.amount, pt.total_amount, pt.payment_method,
                    pt.payment_date, pt.transaction_reference, pt.receipt_number, pt.status
             FROM payment_transactions pt
             WHERE pt.status IN ('received','verified','approved','confirmed','paid')
             ORDER BY pt.id DESC
             LIMIT {$limit}"
        ) ?: array();
    } catch (Exception $e) {
        $result['errors'][] = $e->getMessage();
        return $result;
    }

    foreach ($txns as $txn) {
        $result['scanned']++;
        $txnId = (int) $txn['id'];
        $studentId = (int) $txn['student_id'];
        $amount = isset($txn['total_amount']) ? (float) $txn['total_amount'] : (float) $txn['amount'];
        $date = !empty($txn['payment_date']) ? $txn['payment_date'] : date('Y-m-d');
        $method = !empty($txn['payment_method']) ? $txn['payment_method'] : 'other';
        $ref = !empty($txn['transaction_reference']) ? $txn['transaction_reference'] : ('PT-' . $txnId);
        $receipt = !empty($txn['receipt_number']) ? $txn['receipt_number'] : ('SYNC-' . $txnId);

        // Skip if fee_payments already has this receipt or reference
        try {
            $exists = $db->queryOne(
                "SELECT id FROM fee_payments
                 WHERE student_id = :sid
                   AND (
                     receipt_number = :rec
                     OR (reference_number = :ref AND reference_number <> '' AND reference_number IS NOT NULL)
                   )
                 LIMIT 1",
                array(':sid' => $studentId, ':rec' => $receipt, ':ref' => $ref)
            );
        } catch (Exception $e) {
            $result['errors'][] = "txn {$txnId}: " . $e->getMessage();
            continue;
        }
        if ($exists) {
            $result['skipped']++;
            continue;
        }

        // Prefer item-level amounts when present
        $items = array();
        try {
            $items = $db->query(
                "SELECT id, student_id, amount, fee_type, fee_payment_id
                 FROM payment_items WHERE payment_id = :pid",
                array(':pid' => $txnId)
            ) ?: array();
        } catch (Exception $e) {
            $items = array();
        }

        if (!$items) {
            $items = array(array(
                'id' => 0,
                'student_id' => $studentId,
                'amount' => $amount,
                'fee_type' => null,
                'fee_payment_id' => null,
            ));
        }

        foreach ($items as $idx => $item) {
            if (!empty($item['fee_payment_id'])) {
                $result['skipped']++;
                continue;
            }
            $itemAmount = (float) $item['amount'];
            $itemReceipt = $receipt;
            if (count($items) > 1) {
                $itemReceipt = $receipt . '-I' . ($idx + 1);
            }
            $sid = !empty($item['student_id']) ? (int) $item['student_id'] : $studentId;

            $dup = $db->queryOne(
                "SELECT id FROM fee_payments WHERE receipt_number = :r LIMIT 1",
                array(':r' => $itemReceipt)
            );
            if ($dup) {
                $result['skipped']++;
                continue;
            }

            $fpId = $db->execute(
                "INSERT INTO fee_payments
                   (student_id, amount, payment_method, payment_date, receipt_number, reference_number, status, recorded_by, created_at)
                 VALUES (:sid, :amt, :mth, :dt, :rec, :ref, 'confirmed', NULL, NOW())",
                array(
                    ':sid' => $sid,
                    ':amt' => $itemAmount,
                    ':mth' => $method,
                    ':dt' => $date,
                    ':rec' => $itemReceipt,
                    ':ref' => $ref,
                )
            );
            if ($fpId === false || !$fpId) {
                $result['errors'][] = "txn {$txnId} item {$idx}: insert failed";
                continue;
            }
            if (!empty($item['id'])) {
                try {
                    $db->execute(
                        "UPDATE payment_items SET fee_payment_id = :fp WHERE id = :id AND (fee_payment_id IS NULL OR fee_payment_id = 0)",
                        array(':fp' => $fpId, ':id' => (int) $item['id'])
                    );
                } catch (Exception $e) { /* ignore */ }
            }
            $result['promoted']++;
        }
    }

    return $result;
}
