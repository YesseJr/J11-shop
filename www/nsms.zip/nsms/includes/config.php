<?php
/**
 * NSMS runtime configuration.
 * Prefer environment variables in production. mail_config.php may still define
 * Brevo / SITE_URL for local installs.
 */

if (!defined('NSMS_CONFIG_LOADED')) {
    define('NSMS_CONFIG_LOADED', true);

    // Load local mail/site overrides first so they win over auto-detect
    $mailCfg = __DIR__ . '/mail_config.php';
    if (is_file($mailCfg)) {
        require_once $mailCfg;
    }

    // Public base URL used in emails (no trailing slash)
    $siteUrl = getenv('NSMS_SITE_URL');
    if ($siteUrl === false || $siteUrl === '') {
        $siteUrl = getenv('SITE_URL');
    }
    if (($siteUrl === false || $siteUrl === '') && defined('SITE_URL')) {
        $siteUrl = SITE_URL;
    }
    if ($siteUrl === false || $siteUrl === '') {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443);
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        if ($host !== '') {
            $siteUrl = ($https ? 'https' : 'http') . '://' . $host . '/nsms';
        } else {
            $siteUrl = 'http://localhost/nsms';
        }
    }
    if (!defined('NSMS_SITE_URL')) {
        define('NSMS_SITE_URL', rtrim((string) $siteUrl, '/'));
    }
    if (!defined('SITE_URL')) {
        define('SITE_URL', NSMS_SITE_URL);
    }

    if (!defined('NSMS_CORS_ORIGIN')) {
        $cors = getenv('NSMS_CORS_ORIGIN');
        define('NSMS_CORS_ORIGIN', $cors !== false ? $cors : '');
    }
}

// Env overrides for mail (only if not already defined by mail_config.php)
if (getenv('NSMS_BREVO_API_KEY') && !defined('BREVO_API_KEY')) {
    define('BREVO_API_KEY', getenv('NSMS_BREVO_API_KEY'));
}
if (getenv('NSMS_MAIL_SENDER_EMAIL') && !defined('MAIL_SENDER_EMAIL')) {
    define('MAIL_SENDER_EMAIL', getenv('NSMS_MAIL_SENDER_EMAIL'));
}
if (getenv('NSMS_MAIL_SENDER_NAME') && !defined('MAIL_SENDER_NAME')) {
    define('MAIL_SENDER_NAME', getenv('NSMS_MAIL_SENDER_NAME'));
}

if (!defined('BREVO_API_KEY')) {
    define('BREVO_API_KEY', '');
}
if (!defined('MAIL_SENDER_EMAIL')) {
    define('MAIL_SENDER_EMAIL', '');
}
if (!defined('MAIL_SENDER_NAME')) {
    define('MAIL_SENDER_NAME', 'NSMS');
}
