/**
 * Compile JSX (shared modules + inline page scripts) to plain JS.
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const require = createRequire('/tmp/package.json');
const babel = require('/tmp/node_modules/@babel/core');
const presetReact = require('/tmp/node_modules/@babel/preset-react');

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const outDir = path.join(root, 'public/js/built');
const preset = [[presetReact, { runtime: 'classic' }]];

fs.mkdirSync(outDir, { recursive: true });

function compile(code, filename) {
  const r = babel.transformSync(code, {
    filename,
    presets: preset,
    babelrc: false,
    configFile: false,
  });
  return r.code;
}

function write(rel, code) {
  const dest = path.join(outDir, rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, code, 'utf8');
  console.log('built', rel, `(${code.length} bytes)`);
}

const sharedDir = path.join(root, 'public/includes/js');
for (const name of ['nsms-shared.js', 'teacher-shared.js', 'parent-shared.js']) {
  const src = path.join(sharedDir, name);
  if (!fs.existsSync(src)) continue;
  write(name, compile(fs.readFileSync(src, 'utf8'), name));
}

const publicDir = path.join(root, 'public');
let pages = 0;
let skipped = 0;

function walk(dir) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) {
      if (['js', 'css', 'uploads', 'includes'].includes(ent.name) && path.basename(dir) === 'public') {
        if (ent.name === 'includes') {
          // still walk html under public only; includes has no html pages of interest at top
        }
      }
      if (ent.name === 'js' || ent.name === 'css' || ent.name === 'uploads') continue;
      walk(p);
    } else if (ent.name.endsWith('.html')) processHtml(p);
  }
}

function processHtml(htmlPath) {
  let html = fs.readFileSync(htmlPath, 'utf8');
  const relHtml = path.relative(publicDir, htmlPath).replace(/\\/g, '/');

  html = html.replace(
    /<script([^>]*?)src=["']([^"']*includes\/js\/(nsms-shared|teacher-shared|parent-shared)\.js)["']([^>]*)>\s*<\/script>/gi,
    (m, pre, src, which) => `<script src="/nsms/public/js/built/${which}.js"></script>`
  );

  const re = /<script([^>]*)>([\s\S]*?)<\/script>/gi;
  let match;
  const replacements = [];
  while ((match = re.exec(html))) {
    const attrs = match[1] || '';
    const body = match[2] || '';
    if (!/type\s*=\s*["']text\/babel["']/i.test(attrs)) continue;
    if (/\bsrc\s*=/.test(attrs)) continue;
    if (!body.trim()) continue;
    replacements.push({ full: match[0], body });
  }

  if (replacements.length === 0) {
    if (html.includes('/nsms/public/js/built/')) {
      html = html.replace(/<script[^>]*babel\.min\.js[^>]*><\/script>\s*/gi, '');
      fs.writeFileSync(htmlPath, html, 'utf8');
      pages++;
    } else skipped++;
    return;
  }

  const pageSlug = relHtml.replace(/\.html$/i, '').replace(/\//g, '__');
  let newHtml = html;
  let i = 0;
  for (const block of replacements) {
    i++;
    const outName = `${pageSlug}${replacements.length > 1 ? '_' + i : ''}.js`;
    try {
      const js = compile(block.body, outName);
      write(`pages/${outName}`, js);
      newHtml = newHtml.replace(block.full, `<script src="/nsms/public/js/built/pages/${outName}"></script>`);
    } catch (err) {
      console.error('FAIL', relHtml, err.message.split('\n')[0]);
      skipped++;
      return;
    }
  }

  if (!/type\s*=\s*["']text\/babel["']/i.test(newHtml)) {
    newHtml = newHtml.replace(/<script[^>]*babel\.min\.js[^>]*><\/script>\s*/gi, '');
  }

  fs.writeFileSync(htmlPath, newHtml, 'utf8');
  pages++;
  console.log('page', relHtml);
}

walk(publicDir);
console.log(`\nDone. pages updated=${pages} skipped=${skipped}`);
