/**
 * Offline smoke checks — structure + auth helpers (no live server required).
 * Run: npm run smoke
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawnSync } from 'child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
let failed = 0;

function ok(name, cond, detail = '') {
  if (cond) console.log('OK  ', name);
  else {
    console.log('FAIL', name, detail);
    failed++;
  }
}

// 1) Critical files
const must = [
  'public/index.html',
  'public/reset-password.html',
  'public/js/icons.js',
  'public/js/csrf.js',
  'public/js/vendor/react.production.min.js',
  'api/auth.php',
  'includes/helpers.php',
  'includes/auth.php',
  'includes/config.php',
  'includes/fee_ledger.php',
  'public/spa.html',
  'docs/PRODUCTION_CONFIG.md',
  '.github/workflows/ci.yml',
  'api/health.php',
];
for (const f of must) {
  ok(`exists ${f}`, fs.existsSync(path.join(root, f)));
}

// 2) No backup shared noise
const jsDir = path.join(root, 'public/includes/js');
const backups = fs.existsSync(jsDir)
  ? fs.readdirSync(jsDir).filter((n) => /shared0/.test(n))
  : [];
ok('no *shared0* backups', backups.length === 0, backups.join(','));

// 3) index has forgot + login endpoints
const index = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
const indexBuilt = path.join(root, 'public/js/built/pages/index.js');
const indexJs = fs.existsSync(indexBuilt) ? fs.readFileSync(indexBuilt, 'utf8') : '';
const indexAll = index + indexJs;
ok('forgot_password action referenced', indexAll.includes('forgot_password'));
ok('ForgotPasswordModal or forgot UI', indexAll.includes('ForgotPasswordModal') || indexAll.includes('Forgot password'));
ok('login action referenced', indexAll.includes('action=login') || indexAll.includes('action=login'));

// 4) reset page
const reset = fs.readFileSync(path.join(root, 'public/reset-password.html'), 'utf8');
ok('complete_password_reset', reset.includes('complete_password_reset'));

// 5) Auth API cases
const auth = fs.readFileSync(path.join(root, 'api/auth.php'), 'utf8');
ok('auth login case', /case\s+'login'/.test(auth));
ok('auth forgot_password case', /case\s+'forgot_password'/.test(auth));
ok('auth complete_password_reset case', /case\s+'complete_password_reset'/.test(auth));

// 6) Helpers token functions
const help = fs.readFileSync(path.join(root, 'includes/helpers.php'), 'utf8');
ok('nsmsCreateResetToken', help.includes('function nsmsCreateResetToken'));
ok('nsmsConsumeResetToken', help.includes('function nsmsConsumeResetToken'));
ok('nsmsIssuePasswordResetLink', help.includes('function nsmsIssuePasswordResetLink'));

// 7) PHP syntax
for (const f of ['api/auth.php', 'includes/helpers.php', 'includes/auth.php', 'api/teachers.php', 'api/students.php']) {
  const r = spawnSync('php', ['-l', path.join(root, f)], { encoding: 'utf8' });
  ok(`php -l ${f}`, r.status === 0, r.stdout || r.stderr);
}

// 8) Main nav HTML roots exist
const portals = [
  'public/admin/dashboard.html',
  'public/admin/teachers.html',
  'public/admin/students.html',
  'public/admin/settings.html',
  'public/teacher/dashboard.html',
  'public/teacher/attendance.html',
  'public/parent/dashboard.html',
];
for (const f of portals) {
  const p = path.join(root, f);
  if (!fs.existsSync(p)) {
    ok(`portal ${f}`, false, 'missing');
    continue;
  }
  const h = fs.readFileSync(p, 'utf8');
  ok(`portal ${f} has #root`, /id=["']root["']/.test(h));
  ok(`portal ${f} loads React`, /react\.production\.min\.js/.test(h));
}

// 9) Built artifacts (if build was run)
const builtShared = path.join(root, 'public/js/built/nsms-shared.js');
ok('optional: built nsms-shared.js', true); // informational
if (fs.existsSync(builtShared)) {
  console.log('INFO built frontend present');
}

console.log(failed === 0 ? '\nALL SMOKE CHECKS PASSED' : `\n${failed} CHECK(S) FAILED`);
process.exit(failed === 0 ? 0 : 1);
