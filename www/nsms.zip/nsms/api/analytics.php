<?php
/**
 * Admin Analytics API
 * Provides statistics for admin dashboard
 */

header('Content-Type: application/json');

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once __DIR__ . '/../includes/sync/OfflineData.php';
require_once __DIR__ . '/../includes/sync/OfflineAdmin.php';

applyApiHeaders();

requireRole('admin');

$db = new Database();
$conn = $db->connect();

$action = isset($_GET['action']) ? $_GET['action'] : 'overview';

if (!$conn) {
    // Serve SQLite-backed analytics so admin UI stays useful offline
    if (!class_exists('OfflineAdmin')) {
        errorResponse('Database connection failed', 500);
    }
    $period = isset($_GET['period']) ? (int)$_GET['period'] : 30;
    if ($period < 1) $period = 30;
    switch ($action) {
        case 'overview':
            successResponse(OfflineAdmin::analyticsOverview($period), 'Offline overview');
            break;
        case 'enrollment_trends':
            successResponse(OfflineAdmin::enrollmentTrends($period), 'Offline trends');
            break;
        case 'recent_activity':
            successResponse(OfflineAdmin::recentActivity(), 'Offline activity');
            break;
        case 'class_distribution':
            successResponse(OfflineAdmin::classDistribution(), 'Offline class distribution');
            break;
        case 'fee_by_class':
            successResponse(OfflineAdmin::feeByClass(), 'Offline fee by class');
            break;
        default:
            errorResponse('Database connection failed', 500);
    }
    exit;
}

switch ($action) {
    case 'overview':
        getOverviewStats($db);
        break;

    case 'enrollment_trends':
        getEnrollmentTrends($db);
        break;

    case 'class_distribution':
        getClassDistribution($db);
        break;

    case 'recent_activity':
        getRecentActivity($db);
        break;

    case 'fee_by_class':
        getFeeByClass($db);
        break;

    default:
        errorResponse('Invalid action');
}

/* ═══════════════════════════════════════════════════════════
   HELPERS — academic year & one-time fee map
   (Identical logic to finance.php — keep in sync)
═══════════════════════════════════════════════════════════ */

/**
 * Resolve current academic year from fee_structure, then school_settings,
 * then fallback to curYear/curYear+1.
 */
function analyticsGetAcademicYear($db) {
    $row = $db->queryOne(
        "SELECT academic_year, COUNT(*) AS cnt
           FROM fee_structure
          GROUP BY academic_year
          ORDER BY cnt DESC, academic_year DESC
          LIMIT 1"
    );
    if ($row && !empty($row['academic_year'])) return $row['academic_year'];

    $setting = $db->queryOne(
        "SELECT setting_value FROM school_settings
          WHERE setting_key = 'academic_year'"
    );
    if ($setting && !empty($setting['setting_value'])) return $setting['setting_value'];

    $y = (int)date('Y');
    return $y . '/' . ($y + 1);
}

/**
 * Extract both calendar years covered by an academic year string.
 * "2025/2026" → [2025, 2026]   "2025" → [2025, 2026]
 */
function analyticsAcademicYearRange($academicYear) {
    $parts = explode('/', $academicYear);
    $y1 = (int)$parts[0];
    $y2 = count($parts) > 1 ? (int)$parts[1] : $y1 + 1;
    return [$y1, $y2];
}

/**
 * Build a map of one-time fees (everything except School Fees & Transport)
 * keyed by class_id, plus a school_wide total.
 * Returns: ['school_wide' => float, 'per_class' => [class_id => float]]
 */
function analyticsOneTimeFeeMap($db, $yr) {
    $rows = $db->query(
        "SELECT fee_type, class_id, MAX(amount) AS amount
           FROM fee_structure
          WHERE academic_year = :yr
            AND fee_type NOT IN ('School Fees', 'Transport')
          GROUP BY fee_type, class_id",
        [':yr' => $yr]
    ) ?: [];

    $schoolWide = 0.0;
    $perClass   = [];

    foreach ($rows as $r) {
        $amt = (float)$r['amount'];
        if ($r['class_id'] === null) {
            $schoolWide += $amt;
        } else {
            $cid = (int)$r['class_id'];
            $perClass[$cid] = ($perClass[$cid] ?? 0) + $amt;
        }
    }

    return ['school_wide' => $schoolWide, 'per_class' => $perClass];
}

/**
 * Compute the correct school-wide fee collection rate.
 *
 * Denominator  = SUM(fee_installments.amount_due for active students)
 *              + SUM(one-time fees × active student count per class)
 * Numerator    = SUM(confirmed fee_payments for active students in academic year)
 * Rate         = MIN(100, FLOOR(numerator / denominator × 100))
 *
 * Wrapped in try/catch so analytics still loads before finance tables exist.
 */
function getFeeCollectionOverview($db) {
    $yr = analyticsGetAcademicYear($db);
    [$yearNum1, $yearNum2] = analyticsAcademicYearRange($yr);

    $defaults = ['fee_collection_rate' => 0, 'collected_amount' => 0, 'total_expected' => 0];

    try {
        // Collected: all confirmed payments for active students (academic year window)
        $cashRow = $db->queryOne(
            "SELECT COALESCE(SUM(fp.amount), 0) AS total_paid
               FROM fee_payments fp
               JOIN students s ON s.id = fp.student_id AND s.status = 'active'
              WHERE fp.status = 'confirmed'
                AND YEAR(fp.payment_date) BETWEEN :yr1 AND :yr2",
            [':yr1' => $yearNum1, ':yr2' => $yearNum2]
        );
        $totalPaid = (float)($cashRow['total_paid'] ?? 0);

        // Expected from FEE STRUCTURE for every active student (not only those with installment rows)
        // one-time (exclude School Fees + Transport) × headcount + School Fees per class × headcount
        $otMap      = analyticsOneTimeFeeMap($db, $yr);
        $schoolWide = (float)($otMap['school_wide'] ?? 0);
        $perClass   = $otMap['per_class'] ?? [];

        $sfRows = $db->query(
            "SELECT class_id, amount FROM fee_structure
              WHERE academic_year = :yr AND fee_type = 'School Fees'",
            [':yr' => $yr]
        ) ?: [];
        $classSchoolFees = [];
        foreach ($sfRows as $r) {
            if ($r['class_id'] !== null) {
                $classSchoolFees[(int)$r['class_id']] = (float)$r['amount'];
            }
        }

        $classCounts = $db->query(
            "SELECT class_id, COUNT(*) AS cnt
               FROM students WHERE status = 'active'
              GROUP BY class_id"
        ) ?: [];

        $oneTimeDue = 0.0;
        $schoolFeesDue = 0.0;
        foreach ($classCounts as $cc) {
            $cid = (int)$cc['class_id'];
            $n   = (int)$cc['cnt'];
            $extra = (float)($perClass[$cid] ?? 0);
            $oneTimeDue    += $n * ($schoolWide + $extra);
            $schoolFeesDue += $n * (float)($classSchoolFees[$cid] ?? 0);
        }

        $grandTotalDue = $oneTimeDue + $schoolFeesDue;

        $rate = 0;
        if ($grandTotalDue > 0) {
            $rate = (int)min(100, round(($totalPaid / $grandTotalDue) * 100));
        }

        return [
            'fee_collection_rate' => $rate,
            'collected_amount'    => $totalPaid,
            'total_expected'      => $grandTotalDue,
        ];
    } catch (Throwable $e) {
        return $defaults; // finance tables not yet migrated
    }
}

/* ═══════════════════════════════════════════════════════════
   ACTION: overview
═══════════════════════════════════════════════════════════ */
function getOverviewStats($db) {
    $stats = [];

    $period      = isset($_GET['period']) ? (int)$_GET['period'] : 30;
    $period      = in_array($period, [7, 30, 90, 180]) ? $period : 30;
    $periodStart = date('Y-m-d', strtotime("-{$period} days"));

    // Total Students (all active)
    $result = $db->queryOne("SELECT COUNT(*) as count FROM students WHERE status = 'active'");
    $stats['total_students'] = $result ? (int)$result['count'] : 0;

    // Students enrolled in this period
    $result = $db->queryOne(
        "SELECT COUNT(*) as count FROM students WHERE status = 'active' AND enrollment_date >= ?",
        [$periodStart]
    );
    $stats['students_this_month'] = $result ? (int)$result['count'] : 0;
    $stats['period_days']         = $period;

    // Total Teachers (active)
    $result = $db->queryOne("SELECT COUNT(*) as count FROM users WHERE role = 'teacher' AND status = 'active'");
    $stats['total_teachers'] = $result ? (int)$result['count'] : 0;

    // Average Attendance (last period)
    $result = $db->queryOne(
        "SELECT COUNT(CASE WHEN status = 'present' THEN 1 END) as present,
                COUNT(*) as total
           FROM attendance WHERE attendance_date >= ?",
        [$periodStart]
    );
    if ($result && $result['total'] > 0) {
        $stats['avg_attendance'] = round(($result['present'] / $result['total']) * 100, 1);
    } else {
        $stats['avg_attendance'] = 0;
    }

    // ── Fee Collection Rate — correct denominator from fee structure ──
    $feeData = getFeeCollectionOverview($db);
    $stats['fee_collection_rate'] = $feeData['fee_collection_rate'];
    $stats['collected_amount']    = $feeData['collected_amount'];
    $stats['expected_revenue']    = $feeData['total_expected'];

    // Enrollment growth: current period vs prior equal-length period
    $priorPeriodEnd   = date('Y-m-d', strtotime("-{$period} days"));
    $priorPeriodStart = date('Y-m-d', strtotime("-" . ($period * 2) . " days"));
    $prior = $db->queryOne(
        "SELECT COUNT(*) as count FROM students
          WHERE status = 'active'
            AND enrollment_date >= ? AND enrollment_date < ?",
        [$priorPeriodStart, $priorPeriodEnd]
    );
    $priorCount   = $prior ? (int)$prior['count'] : 0;
    $currentCount = $stats['students_this_month'];
    if ($priorCount > 0) {
        $raw = round((($currentCount - $priorCount) / $priorCount) * 100, 1);
        $stats['enrollment_growth'] = max(-100, min(100, $raw));
    } else {
        $stats['enrollment_growth'] = $currentCount > 0 ? 100 : 0;
    }

    successResponse($stats);
}

/* ═══════════════════════════════════════════════════════════
   ACTION: fee_by_class
   Correct denominator: fee_installments + one-time fees per student.
   Rate capped at 100, 0 when no fees configured for that class.
═══════════════════════════════════════════════════════════ */
function getFeeByClass($db) {
    $yr = analyticsGetAcademicYear($db);
    [$yearNum1, $yearNum2] = analyticsAcademicYearRange($yr);

    // Fallback safe result if finance tables don't exist yet
    $fallback = function() use ($db) {
        $classes = $db->query("SELECT class_name, class_color FROM classes ORDER BY class_name ASC") ?: [];
        $result  = [];
        foreach ($classes as $cls) {
            $result[] = [
                'name'      => $cls['class_name'],
                'color'     => $cls['class_color'],
                'collected' => 0,
                'amount'    => 'No fee data',
            ];
        }
        successResponse($result);
    };

    try {
        $otMap      = analyticsOneTimeFeeMap($db, $yr);
        $schoolWide = $otMap['school_wide'];
        $perClass   = $otMap['per_class'];
        $classSchoolFees = [];
        $sfRows = $db->query(
            "SELECT class_id, amount FROM fee_structure
              WHERE academic_year = :yr AND fee_type = 'School Fees'",
            [':yr' => $yr]
        ) ?: [];
        foreach ($sfRows as $r) {
            if ($r['class_id'] !== null) {
                $classSchoolFees[(int)$r['class_id']] = (float)$r['amount'];
            }
        }


        // Installment totals per student
        $instRows = $db->query(
            "SELECT fi.student_id,
                    COALESCE(SUM(fi.amount_due),  0) AS inst_due,
                    COALESCE(SUM(fi.amount_paid), 0) AS inst_paid
               FROM fee_installments fi
               JOIN students s ON s.id = fi.student_id AND s.status = 'active'
              WHERE fi.academic_year = :yr
              GROUP BY fi.student_id",
            [':yr' => $yr]
        ) ?: [];

        $instDueMap = [];
        foreach ($instRows as $r) {
            $instDueMap[(int)$r['student_id']] = (float)$r['inst_due'];
        }

        // Confirmed cash per student across both academic years
        $cashRows = $db->query(
            "SELECT fp.student_id,
                    COALESCE(SUM(fp.amount), 0) AS total_paid
               FROM fee_payments fp
               JOIN students s ON s.id = fp.student_id AND s.status = 'active'
              WHERE fp.status = 'confirmed'
                AND YEAR(fp.payment_date) BETWEEN :yr1 AND :yr2
              GROUP BY fp.student_id",
            [':yr1' => $yearNum1, ':yr2' => $yearNum2]
        ) ?: [];

        $cashMap = [];
        foreach ($cashRows as $r) {
            $cashMap[(int)$r['student_id']] = (float)$r['total_paid'];
        }

        // Active students
        $students = $db->query(
            "SELECT s.id, s.class_id FROM students s WHERE s.status = 'active'"
        ) ?: [];

        // All classes for display
        $classes = $db->query(
            "SELECT id, class_name, class_color FROM classes ORDER BY class_name ASC"
        ) ?: [];

        $classData = [];
        foreach ($classes as $cls) {
            $classData[(int)$cls['id']] = [
                'name'          => $cls['class_name'],
                'color'         => $cls['class_color'],
                'total_due'     => 0.0,
                'total_paid'    => 0.0,
                'student_count' => 0,
            ];
        }

        foreach ($students as $s) {
            $sid  = (int)$s['id'];
            $cid  = (int)$s['class_id'];
            if (!isset($classData[$cid])) continue;

            $classExtra = $perClass[$cid] ?? 0;
            $oneTime    = $schoolWide + $classExtra;
            // Configured school fees for this class (not installment rows only)
            $sfDue      = isset($classSchoolFees[$cid]) ? (float)$classSchoolFees[$cid] : 0.0;
            if ($sfDue <= 0 && isset($instDueMap[$sid])) {
                $sfDue = (float)$instDueMap[$sid]; // fallback if structure missing
            }
            $cash       = $cashMap[$sid]    ?? 0;

            $classData[$cid]['total_due']     += $oneTime + $sfDue;
            $classData[$cid]['total_paid']    += $cash;
            $classData[$cid]['student_count'] += 1;
        }

        $fmt = function($v) {
            if ($v >= 1_000_000) return 'TSh ' . number_format($v / 1_000_000, 1) . 'M';
            if ($v >= 1_000)     return 'TSh ' . number_format($v / 1_000, 0) . 'K';
            return 'TSh ' . number_format($v);
        };

        $result = [];
        foreach ($classData as $cid => $cd) {
            if ($cd['student_count'] === 0) continue;

            $due  = $cd['total_due'];
            $paid = $cd['total_paid'];
            $rate = ($due > 0) ? (int)min(100, round(($paid / $due) * 100)) : 0;

            $result[] = [
                'name'          => $cd['name'],
                'color'         => $cd['color'],
                'collected'     => $rate,
                'amount'        => $fmt($paid) . ' / ' . $fmt($due),
                'total_paid'    => $paid,
                'total_due'     => $due,
                'student_count' => $cd['student_count'],
            ];
        }

        successResponse($result);
    } catch (Throwable $e) {
        $fallback();
    }
}

/* ═══════════════════════════════════════════════════════════
   ACTION: enrollment_trends
═══════════════════════════════════════════════════════════ */
function getEnrollmentTrends($db) {
    $period      = isset($_GET['period']) ? (int)$_GET['period'] : 180;
    $period      = in_array($period, [7, 30, 90, 180]) ? $period : 180;
    $periodStart = date('Y-m-d', strtotime("-{$period} days"));

    if ($period <= 30) {
        $sql = "SELECT DATE_FORMAT(enrollment_date, '%Y-%m-%d') as month,
                       DATE_FORMAT(enrollment_date, '%d %b') as month_name,
                       COUNT(*) as count
                  FROM students WHERE enrollment_date >= ?
                 GROUP BY DATE_FORMAT(enrollment_date, '%Y-%m-%d'), month_name
                 ORDER BY month ASC";
    } else {
        $sql = "SELECT DATE_FORMAT(enrollment_date, '%Y-%m') as month,
                       DATE_FORMAT(enrollment_date, '%b') as month_name,
                       COUNT(*) as count
                  FROM students WHERE enrollment_date >= ?
                 GROUP BY month, month_name
                 ORDER BY month ASC";
    }

    $trends = $db->query($sql, [$periodStart]);
    successResponse($trends ?: []);
}

/* ═══════════════════════════════════════════════════════════
   ACTION: class_distribution
═══════════════════════════════════════════════════════════ */
function getClassDistribution($db) {
    if (function_exists('nsmsEnsureClassMinimumAgeColumn')) {
        nsmsEnsureClassMinimumAgeColumn($db);
    }
    $sql = "SELECT c.id, c.class_name, c.class_color,
                   COUNT(s.id) as student_count, c.capacity, c.minimum_age
              FROM classes c
              LEFT JOIN students s ON c.id = s.class_id AND s.status = 'active'
             GROUP BY c.id, c.class_name, c.class_color, c.capacity, c.minimum_age
             ORDER BY c.class_name";
    try {
        successResponse($db->query($sql) ?: []);
    } catch (Exception $e) {
        // Legacy DB without minimum_age
        $sql2 = "SELECT c.id, c.class_name, c.class_color,
                        COUNT(s.id) as student_count, c.capacity
                   FROM classes c
                   LEFT JOIN students s ON c.id = s.class_id AND s.status = 'active'
                  GROUP BY c.id, c.class_name, c.class_color, c.capacity
                  ORDER BY c.class_name";
        successResponse($db->query($sql2) ?: []);
    }
}

/* ═══════════════════════════════════════════════════════════
   ACTION: recent_activity
═══════════════════════════════════════════════════════════ */
function getRecentActivity($db) {
    $activities = [];

    $enrollments = $db->query(
        "SELECT s.student_name, COALESCE(s.created_at, s.enrollment_date) as activity_time, c.class_name
           FROM students s JOIN classes c ON s.class_id = c.id
          WHERE s.status = 'active'
          ORDER BY COALESCE(s.created_at, s.enrollment_date) DESC LIMIT 3"
    );
    if ($enrollments) {
        foreach ($enrollments as $e) {
            $activities[] = [
                'type'        => 'enrollment',
                'title'       => 'New student enrolled',
                'description' => $e['student_name'] . ' - ' . $e['class_name'],
                'timestamp'   => $e['activity_time'],
                'icon'        => '👤',
            ];
        }
    }

    $payments = $db->query(
        "SELECT s.student_name, fp.amount, COALESCE(fp.created_at, fp.payment_date) as activity_time
           FROM fee_payments fp JOIN students s ON fp.student_id = s.id
          WHERE fp.status = 'confirmed'
          ORDER BY COALESCE(fp.created_at, fp.payment_date) DESC LIMIT 3"
    );
    if ($payments) {
        foreach ($payments as $p) {
            $activities[] = [
                'type'        => 'payment',
                'title'       => 'Fee payment received',
                'description' => $p['student_name'] . ' - TSh ' . number_format($p['amount']),
                'timestamp'   => $p['activity_time'],
                'icon'        => '💰',
            ];
        }
    }

    usort($activities, function($a, $b) {
        return strtotime($b['timestamp']) - strtotime($a['timestamp']);
    });

    successResponse(array_slice($activities, 0, 5));
}