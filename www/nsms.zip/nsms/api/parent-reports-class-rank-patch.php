<?php
/**
 * ═══════════════════════════════════════════════════════════════════
 *  PATCH — Add this to your existing  /nsms/api/parent-reports.php
 * ═══════════════════════════════════════════════════════════════════
 *
 *  STEP 1 — Add 'class_rank' to the switch in parent-reports.php:
 *
 *      case 'class_rank': getClassRank($db); break;
 *
 *  STEP 2 — Paste the function below anywhere in that file.
 *
 *  What it does:
 *    Ranks every active student in the class by their total
 *    subject-performance score for the given term/year, then
 *    returns the querying student's position and total headcount.
 *
 *  Called by parent-reports-6.html:
 *    GET /nsms/api/parent-reports.php
 *        ?action=class_rank
 *        &student_id=X
 *        &class_id=Y
 *        &term=Z
 *        &academic_year=W
 * ═══════════════════════════════════════════════════════════════════
 */


function getClassRank($db) {

    /* ── inputs ── */
    $studentId   = isset($_GET['student_id'])    ? (int)  trim($_GET['student_id'])    : 0;
    $classId     = isset($_GET['class_id'])      ? (int)  trim($_GET['class_id'])      : 0;
    $term        = isset($_GET['term'])          ? trim($_GET['term'])                 : '';
    $academicYear= isset($_GET['academic_year']) ? trim($_GET['academic_year'])        : '';

    if (!$studentId || !$classId || !$term || !$academicYear) {
        ob_end_clean();
        errorResponse('student_id, class_id, term, academic_year are required.');
        return;
    }

    /*
     * ── Auth guard ──────────────────────────────────────────────────
     * Only allow a parent to query rank for their own linked child.
     */
    list($userId, $role) = sessionInfo();   // uses the same helper already in parent-reports.php
    if ($role === 'parent') {
        $linked = $db->queryOne(
            "SELECT 1 FROM parents WHERE user_id = :uid AND student_id = :sid LIMIT 1",
            [':uid' => $userId, ':sid' => $studentId]
        );
        if (!$linked) {
            ob_end_clean();
            errorResponse('Access denied.', 403);
            return;
        }
    }

    /*
     * ── Rank query ──────────────────────────────────────────────────
     * Sum each student's average_score across all subjects for this
     * term/year/class, then rank descending.
     *
     * We use a sub-select for portability (MySQL 5.6+ / MariaDB 10.1+)
     * rather than window functions, so it works on shared hosting.
     */
    $rankedRows = $db->query(
        "SELECT student_id,
                SUM(average_score) AS total_score
         FROM   student_subject_performance
         WHERE  class_id      = :cid
           AND  term          = :term
           AND  academic_year = :yr
           AND  average_score IS NOT NULL
         GROUP  BY student_id
         ORDER  BY total_score DESC",
        [':cid' => $classId, ':term' => $term, ':yr' => $academicYear]
    ) ?: [];

    $totalStudents = count($rankedRows);

    if ($totalStudents === 0) {
        ob_end_clean();
        successResponse([
            'position'       => null,
            'total_students' => 0,
            'total_score'    => null,
            'message'        => 'No performance data available yet for this term.',
        ]);
        return;
    }

    /* Walk the ranked list to find this student's position.
       Ties share the same position (dense rank). */
    $position    = null;
    $totalScore  = null;
    $lastScore   = null;
    $currentRank = 0;

    foreach ($rankedRows as $row) {
        $score = (float) $row['total_score'];
        if ($score !== $lastScore) {
            $currentRank++;
            $lastScore = $score;
        }
        if ((int)$row['student_id'] === $studentId) {
            $position   = $currentRank;
            $totalScore = $score;
            break;
        }
    }

    ob_end_clean();
    successResponse([
        'position'       => $position,
        'total_students' => $totalStudents,
        'total_score'    => $totalScore,
    ]);
}
