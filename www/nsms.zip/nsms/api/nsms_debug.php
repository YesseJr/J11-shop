<?php
/**
 * NSMS Report Debug — run once, delete after.
 * Place at /nsms/api/nsms_debug.php and open in browser while logged in.
 */
require_once '../includes/db.php';
require_once '../includes/auth.php';

$db   = new Database();
$db->connect();

$out = [];

/* 1. Which tables exist? */
$tables = $db->query("SHOW TABLES") ?: [];
$tableNames = [];
foreach ($tables as $t) { $tableNames[] = array_values($t)[0]; }
$out['tables_relevant'] = array_values(array_filter($tableNames, function($n){
    return strpos($n,'report') !== false || strpos($n,'student') !== false || strpos($n,'parent') !== false;
}));

/* 2. student_reports — does it exist? How many rows? Published? */
if (in_array('student_reports', $tableNames)) {
    $cnt = $db->queryOne("SELECT COUNT(*) AS n FROM student_reports");
    $pub = $db->queryOne("SELECT COUNT(*) AS n FROM student_reports WHERE is_published=1");
    $out['student_reports_total']     = $cnt ? (int)$cnt['n'] : 0;
    $out['student_reports_published'] = $pub ? (int)$pub['n'] : 0;
    $out['student_reports_sample']    = $db->query(
        "SELECT id,student_id,report_type,period_label,term,is_draft,is_published,published_at,
                teacher_id, LEFT(subject_data,80) AS subject_data_preview
         FROM student_reports ORDER BY id DESC LIMIT 5"
    ) ?: [];
} else {
    $out['student_reports'] = 'TABLE DOES NOT EXIST — run migration.sql';
}

/* 3. weekly_reports — old table still has data? */
if (in_array('weekly_reports', $tableNames)) {
    $cnt = $db->queryOne("SELECT COUNT(*) AS n FROM weekly_reports");
    $out['weekly_reports_total'] = $cnt ? (int)$cnt['n'] : 0;
    $out['weekly_reports_sample'] = $db->query(
        "SELECT id,student_id,LEFT(COALESCE(status,''),20) AS status,created_at FROM weekly_reports ORDER BY id DESC LIMIT 3"
    ) ?: [];
}

/* 4. parents table — how is it structured? */
if (in_array('parents', $tableNames)) {
    $cols = $db->query("SHOW COLUMNS FROM parents") ?: [];
    $out['parents_columns'] = array_column($cols, 'Field');
    $out['parents_sample']  = $db->query("SELECT * FROM parents LIMIT 5") ?: [];
}

/* 5. Current session */
$out['session'] = [
    'user_id'   => isset($_SESSION['user_id'])   ? $_SESSION['user_id']   : null,
    'parent_id' => isset($_SESSION['parent_id']) ? $_SESSION['parent_id'] : null,
    'role'      => isset($_SESSION['role'])      ? $_SESSION['role']      : null,
];

/* 6. If session has user_id, what students are linked? */
$uid = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
if ($uid) {
    $out['linked_students_via_user_id'] = $db->query(
        "SELECT p.*, s.student_name FROM parents p
         JOIN students s ON s.id=p.student_id
         WHERE p.user_id=:uid", [':uid'=>$uid]
    ) ?: [];
}

/* 7. If linked students exist, do they have reports? */
if (!empty($out['linked_students_via_user_id'])) {
    foreach ($out['linked_students_via_user_id'] as $s) {
        $sid = (int)$s['student_id'];
        $rpts = $db->query(
            "SELECT id,report_type,is_published,is_draft FROM student_reports WHERE student_id=:sid",
            [':sid'=>$sid]
        ) ?: [];
        $out['reports_for_student_'.$sid.'_'.$s['student_name']] = $rpts ?: 'NONE';
    }
}

header('Content-Type: application/json');
echo json_encode($out, JSON_PRETTY_PRINT);
