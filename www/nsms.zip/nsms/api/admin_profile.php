<?php
/* ═══════════════════════════════════════════════════════════════
   nsms/api/admin_profile.php
   Actions:
     GET  ?action=get              → returns admin profile data
     POST action=update_profile    → update name, email, phone (+ optional password)
     POST action=upload_photo      → multipart upload of profile photo
═══════════════════════════════════════════════════════════════ */

ob_start();
header('Content-Type: application/json'); // set EARLY so even fatal errors carry the right type

/* ── Global safety net: any uncaught exception → clean JSON ── */
set_exception_handler(function($e) {
    ob_clean();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Exception: ' . $e->getMessage()]);
    exit;
});

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
$db = new Database();
$db->connect();

/* auth.php required only if it exists — requireRole is not enforced */
if (file_exists(__DIR__ . '/../includes/auth.php')) {
    require_once __DIR__ . '/../includes/auth.php';
}
if (function_exists('applyApiHeaders')) { applyApiHeaders(); }
requireRole('admin');   // uncomment to enforce auth

/*function successResponse($data = null) {
    $out = ['success' => true];
    if ($data !== null) $out['data'] = $data;
    ob_clean();
    echo json_encode($out);
    exit;
}*/

/*function errorResponse($msg, $code = 400) {
    http_response_code($code);
    ob_clean();
    echo json_encode(['success' => false, 'error' => $msg]);
    exit;
}*/

/* ── Get current session admin ID ── */
if (session_status() === PHP_SESSION_NONE) session_start();
$adminId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 1; // fallback to 1 for dev

/* ════════════════════
   GET profile
════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    if ($action !== 'get') errorResponse('Unknown action');

    try {
        $row = $db->queryOne(
            "SELECT id, full_name, email, phone, role, photo_url, created_at
             FROM users WHERE id = :id LIMIT 1",
            [':id' => $adminId]
        );
    } catch (Exception $e) {
        errorResponse('Database error: ' . $e->getMessage(), 500);
    }

    if (!$row) errorResponse('Profile not found', 404);

    unset($row['password']);
    successResponse($row);
}

/* ════════════════════
   POST actions
════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /* ── Photo upload ── */
    if (isset($_FILES['photo'])) {
        $uploadDir = __DIR__ . '/../public/uploads/admin/';
        $stored = nsmsStoreUpload(
            $_FILES['photo'],
            $uploadDir,
            array('jpg', 'jpeg', 'png', 'gif', 'webp'),
            3 * 1024 * 1024,
            array('image/jpeg', 'image/png', 'image/gif', 'image/webp')
        );
        if (empty($stored['ok'])) {
            errorResponse(isset($stored['error']) ? $stored['error'] : 'Upload failed');
        }
        $fileName = $stored['filename'];
        $photoUrl = '/nsms/public/uploads/admin/' . $fileName;

        try {
            $db->execute(
                "UPDATE users SET photo_url = :photo_url WHERE id = :id",
                [':photo_url' => $photoUrl, ':id' => $adminId]
            );
        } catch (Exception $e) {
            errorResponse('Database error: ' . $e->getMessage(), 500);
        }

        successResponse(['photo_url' => $photoUrl]);
    }

    /* ── JSON body actions ── */
    $body   = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = $body['action'] ?? ($_POST['action'] ?? '');

    if ($action === 'update_profile') {
        $fullName = trim($body['full_name'] ?? '');
        $email    = trim($body['email']     ?? '');
        $phone    = trim($body['phone']     ?? '');

        if ($fullName === '') errorResponse('Full name is required');
        if ($email    === '') errorResponse('Email is required');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) errorResponse('Invalid email address');

                /* Check email uniqueness — one email, one user */
        $email = strtolower(trim($email));
        if (function_exists('nsmsAssertEmailAvailable')) {
            $taken = nsmsAssertEmailAvailable($db, $email, $adminId);
            if (!$taken['ok']) errorResponse($taken['error']);
        } else {
            $existing = $db->queryOne(
                "SELECT id FROM users WHERE LOWER(TRIM(email)) = :email AND id != :id LIMIT 1",
                [':email' => $email, ':id' => $adminId]
            );
            if ($existing) errorResponse('This email is already registered to another user. Each email can only belong to one account.');
        }

        /* Optional password change */
        if (!empty($body['change_password'])) {
            $currentPw = $body['current_password'] ?? '';
            $newPw     = $body['new_password']     ?? '';

            if (strlen($newPw) < 6)
                errorResponse('New password must be at least 6 characters');

            try {
                $pwRow = $db->queryOne(
                    "SELECT password FROM users WHERE id = :id LIMIT 1",
                    [':id' => $adminId]
                );
            } catch (Exception $e) {
                errorResponse('Database error: ' . $e->getMessage(), 500);
            }
            if (!$pwRow) errorResponse('User not found', 404);

            if (!password_verify($currentPw, $pwRow['password']))
                errorResponse('Current password is incorrect');

            $hashedPw = password_hash($newPw, PASSWORD_BCRYPT);
            try {
                $db->execute(
                    "UPDATE users SET full_name = :full_name, email = :email, phone = :phone, password = :password WHERE id = :id",
                    [':full_name' => $fullName, ':email' => $email, ':phone' => $phone, ':password' => $hashedPw, ':id' => $adminId]
                );
            } catch (Exception $e) {
                errorResponse('Database error: ' . $e->getMessage(), 500);
            }
        } else {
            try {
                $db->execute(
                    "UPDATE users SET full_name = :full_name, email = :email, phone = :phone WHERE id = :id",
                    [':full_name' => $fullName, ':email' => $email, ':phone' => $phone, ':id' => $adminId]
                );
            } catch (Exception $e) {
                errorResponse('Database error: ' . $e->getMessage(), 500);
            }
        }

        $_SESSION['user_name'] = $fullName;
        successResponse(['message' => 'Profile updated successfully']);
    }

    errorResponse('Unknown action');
}

errorResponse('Method not allowed', 405);
