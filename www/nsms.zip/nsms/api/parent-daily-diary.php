<?php
/**
 * Parent Daily Diary API
 * /nsms/api/parent-daily-diary.php
 * PHP 7.2 compatible.
 *
 * ── Schema requirements ────────────────────────────────────────
 *   students          : id, student_name, class_id        ← column is student_name, NOT full_name
 *   parents           : id, user_id, student_id           ← junction table, NOT students.parent_id
 *   homework          : id, class_id, posted_by, subject,
 *                       description, due_date, created_at
 *   users             : id, full_name  (teacher)
 *   homework_acknowledgements :
 *       id INT AUTO_INCREMENT PRIMARY KEY,
 *       homework_id INT NOT NULL,
 *       student_id  INT NOT NULL,
 *       parent_id   INT NOT NULL,
 *       acknowledged_at DATETIME NOT NULL,
 *       UNIQUE KEY uq_hw_ack (homework_id, student_id)
 *
 * ── Actions ────────────────────────────────────────────────────
 *   GET  ?action=get_children              — children of the logged-in parent
 *   GET  ?action=list&student_id=X         — homework for student X + ack status
 *   GET  ?action=list&student_id=X&filter=pending|acknowledged|all
 *   POST ?action=acknowledge               — body: {homework_id, student_id}
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/helpers.php';

if (function_exists('applyApiHeaders')) { applyApiHeaders(); }


requireRole(['parent', 'admin']);

$db = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

/* Ensure the acknowledgements table exists on first use */
ensureAckTable($db);

$action = isset($_GET['action']) ? trim($_GET['action']) : '';

switch ($action) {
    case 'get_children': getChildren($db); break;
    case 'list':         listHomework($db); break;
    case 'acknowledge':  acknowledgeHomework($db); break;
    case 'comment':      commentHomework($db); break;
    case 'list_comments': listHomeworkComments($db); break;
    default: ob_end_clean(); errorResponse('Invalid action');
}

/* ─────────────────────────────────────────────────────────────
   HELPER: current parent's user id
───────────────────────────────────────────────────────────── */
function getParentId()
{
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
}

/* ─────────────────────────────────────────────────────────────
   HELPER: date → human label (Today / Yesterday / Tomorrow / D d M)
───────────────────────────────────────────────────────────── */
function dateLabel($dateStr)
{
    if (!$dateStr) return '';
    $d         = date('Y-m-d', strtotime($dateStr));
    $today     = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    $tomorrow  = date('Y-m-d', strtotime('+1 day'));

    if ($d === $today)     return 'Today';
    if ($d === $yesterday) return 'Yesterday';
    if ($d === $tomorrow)  return 'Tomorrow';
    return date('D, d M', strtotime($d));   /* e.g. "Fri, 18 Apr" */
}

/* ─────────────────────────────────────────────────────────────
   ENSURE acknowledgements table exists
───────────────────────────────────────────────────────────── */
function ensureAckTable($db)
{
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS homework_acknowledgements (
                id              INT          NOT NULL AUTO_INCREMENT,
                homework_id     INT          NOT NULL,
                student_id      INT          NOT NULL,
                parent_id       INT          NOT NULL,
                acknowledged_at DATETIME     NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_hw_ack (homework_id, student_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            []
        );
    } catch (Exception $e) {
        /* Non-fatal — table may already exist */
    }
}

/* ─────────────────────────────────────────────────────────────
   GET CHILDREN
   Returns all students linked to the logged-in parent via the
   `parents` junction table (user_id → student_id).
   FIX: was using students.parent_id (column doesn't exist).
        Was also selecting s.full_name — correct column is s.student_name.
───────────────────────────────────────────────────────────── */
function getChildren($db)
{
    $parentId = getParentId();
    if (!$parentId) {
        ob_end_clean();
        successResponse([]);
        return;
    }

    $rows = $db->query(
        "SELECT s.id,
                s.student_name,
                s.class_id,
                c.class_name
         FROM   parents p
         JOIN   students s ON s.id = p.student_id
         LEFT   JOIN classes c ON c.id = s.class_id
         WHERE  p.user_id = :pid
           AND  s.status  = 'active'
         ORDER  BY s.student_name ASC",
        [':pid' => $parentId]
    );

    ob_end_clean();
    successResponse($rows ?: []);
}

/* ─────────────────────────────────────────────────────────────
   LIST HOMEWORK
   Returns homework for the student's class with acknowledge status.
   Optional ?filter=pending|acknowledged|all  (default: all)
   FIX: ownership check now uses parents junction table instead of
        students.parent_id (which doesn't exist in this schema).
───────────────────────────────────────────────────────────── */
function listHomework($db)
{
    $parentId  = getParentId();
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    $filter    = isset($_GET['filter']) ? trim($_GET['filter']) : 'all';

    /* ── Guard: missing IDs — return empty but valid shape ── */
    if (!$parentId || !$studentId) {
        ob_end_clean();
        successResponse(['homework' => []]);
        return;
    }

    /*
     * ── Two-step student verification ──────────────────────────────────────
     * Step 1: Does the student exist at all?
     * Step 2: Does it belong to this parent (via parents junction table)?
     *
     * FIXED: Previously queried students.parent_id which doesn't exist.
     *        Now uses: parents p JOIN students s ON s.id = p.student_id
     *        Also fixed column name: s.student_name (not s.full_name).
     */
    $studentAny = $db->queryOne(
        "SELECT id, class_id, student_name
         FROM   students
         WHERE  id = :sid",
        [':sid' => $studentId]
    );

    if (!$studentAny) {
        error_log("[NSMS parent-daily-diary] list: student_id={$studentId} does not exist in students table. parent_id(session)={$parentId}");
        ob_end_clean();
        errorResponse('Student not found', 404);
        return;
    }

    /* Student exists — check ownership via parents junction table */
    $ownership = $db->queryOne(
        "SELECT id FROM parents
         WHERE  student_id = :sid AND user_id = :pid",
        [':sid' => $studentId, ':pid' => $parentId]
    );

    if (!$ownership) {
        error_log(
            "[NSMS parent-daily-diary] list: PARENT MISMATCH. " .
            "student_id={$studentId} is not linked to session user_id={$parentId} " .
            "in the parents junction table. " .
            "Check parent-shared.js — ParentNavbar may be calling setSelectedChild() " .
            "with data from a different API whose student objects have a different shape."
        );
        ob_end_clean();
        errorResponse('Access denied: this student does not belong to your account', 403);
        return;
    }

    /* Use the verified student row */
    $student = [
        'id'           => (int)$studentAny['id'],
        'class_id'     => (int)$studentAny['class_id'],
        'student_name' => $studentAny['student_name'],
    ];

    $classId = (int)$student['class_id'];
    if (!$classId) {
        /* Student not yet assigned to a class */
        ob_end_clean();
        successResponse(['student' => $student, 'homework' => []]);
        return;
    }

    /* ── Build optional acknowledgement filter ── */
    $filterSql = '';
    if ($filter === 'pending') {
        $filterSql = ' AND ha.id IS NULL';
    } elseif ($filter === 'acknowledged') {
        $filterSql = ' AND ha.id IS NOT NULL';
    }


    try {
        $cols = $db->query("SHOW COLUMNS FROM homework LIKE 'attachment_url'");
        if (empty($cols)) {
            $db->execute("ALTER TABLE homework ADD COLUMN attachment_url VARCHAR(255) NULL DEFAULT NULL");
        }
    } catch (Exception $e) { /* ignore */ }
    $rows = $db->query(
        "SELECT h.id,
                h.subject,
                h.description,
                h.due_date,
                h.created_at,
                h.attachment_url,
                h.posted_by,
                u.full_name                                      AS posted_by_name,
                CASE WHEN ha.id IS NOT NULL THEN 1 ELSE 0 END   AS acknowledged,
                ha.acknowledged_at
         FROM   homework h
         JOIN   users    u  ON u.id  = h.posted_by
         LEFT   JOIN homework_acknowledgements ha
                        ON ha.homework_id = h.id
                       AND ha.student_id  = :sid
         WHERE  h.class_id = :cid
                $filterSql
         ORDER  BY h.created_at DESC
         LIMIT  40",
        [':cid' => $classId, ':sid' => $studentId]
    );

    /* Enrich each row with human-readable date labels + teacher replies */
    $result = [];
    ensureHomeworkCommentsTable($db);
    try {
        $col = $db->query("SHOW COLUMNS FROM homework_comments LIKE 'teacher_reply'");
        if (empty($col)) {
            $db->execute("ALTER TABLE homework_comments ADD COLUMN teacher_reply TEXT NULL");
            $db->execute("ALTER TABLE homework_comments ADD COLUMN replied_at DATETIME NULL");
            $db->execute("ALTER TABLE homework_comments ADD COLUMN replied_by INT NULL");
        }
    } catch (Exception $e) {}

    foreach (($rows ?: []) as $row) {
        $postedDate           = date('Y-m-d', strtotime($row['created_at']));
        $row['posted_label']  = dateLabel($postedDate);
        $row['due_label']     = dateLabel($row['due_date']);
        $row['acknowledged']  = (bool)$row['acknowledged'];
        if (isset($row['subject'])) {
            $row['subject'] = html_entity_decode($row['subject'], ENT_QUOTES, 'UTF-8');
        }
        if (isset($row['description'])) {
            $row['description'] = html_entity_decode($row['description'], ENT_QUOTES, 'UTF-8');
        }

        $row['has_teacher_reply'] = false;
        $row['teacher_reply'] = null;
        $row['teacher_reply_at'] = null;
        $row['my_comment_count'] = 0;
        try {
            $creplies = $db->query(
                "SELECT c.comment, c.teacher_reply, c.replied_at, c.created_at
                   FROM homework_comments c
                  WHERE c.homework_id = :hw AND c.student_id = :sid AND c.parent_id = :pid
                  ORDER BY c.created_at DESC
                  LIMIT 5",
                array(
                    ':hw' => (int)$row['id'],
                    ':sid' => $studentId,
                    ':pid' => getParentId(),
                )
            ) ?: array();
            $row['my_comment_count'] = count($creplies);
            foreach ($creplies as $cr) {
                if (!empty($cr['teacher_reply'])) {
                    $row['has_teacher_reply'] = true;
                    $row['teacher_reply'] = $cr['teacher_reply'];
                    $row['teacher_reply_at'] = $cr['replied_at'];
                    break;
                }
            }
        } catch (Exception $e) { /* table may not exist yet */ }

        $result[] = $row;
    }

    ob_end_clean();
    successResponse([
        'student'  => $student,
        'homework' => $result,
    ]);
}

/* ─────────────────────────────────────────────────────────────
   ACKNOWLEDGE HOMEWORK
   Body (JSON): { homework_id: int, student_id: int }
   Idempotent — re-acknowledging is a no-op.
   FIX: ownership check now uses parents junction table.
───────────────────────────────────────────────────────────── */
function acknowledgeHomework($db)
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean();
        errorResponse('Method not allowed', 405);
        return;
    }

    $parentId = getParentId();
    if (!$parentId) {
        ob_end_clean();
        errorResponse('Authentication required', 401);
        return;
    }

    $body       = json_decode(file_get_contents('php://input'), true);
    $homeworkId = isset($body['homework_id']) ? (int)$body['homework_id'] : 0;
    $studentId  = isset($body['student_id'])  ? (int)$body['student_id']  : 0;

    if (!$homeworkId || !$studentId) {
        ob_end_clean();
        errorResponse('homework_id and student_id are required');
        return;
    }

    /*
     * FIX: was "SELECT id FROM students WHERE id = :sid AND parent_id = :pid"
     * Correct ownership check uses the parents junction table.
     */
    $ownership = $db->queryOne(
        "SELECT p.id FROM parents p
         WHERE  p.student_id = :sid AND p.user_id = :pid",
        [':sid' => $studentId, ':pid' => $parentId]
    );
    if (!$ownership) {
        ob_end_clean();
        errorResponse('Student not found or access denied', 403);
        return;
    }

    /* Verify the homework exists (and the student's class matches) */
    $hw = $db->queryOne(
        "SELECT h.id
         FROM   homework h
         JOIN   students s ON s.class_id = h.class_id
         WHERE  h.id = :hwid
           AND  s.id = :sid",
        [':hwid' => $homeworkId, ':sid' => $studentId]
    );
    if (!$hw) {
        ob_end_clean();
        errorResponse('Homework not found', 404);
        return;
    }

    /* Idempotent upsert — UNIQUE KEY (homework_id, student_id) */
    $db->execute(
        "INSERT IGNORE INTO homework_acknowledgements
             (homework_id, student_id, parent_id, acknowledged_at)
         VALUES (:hwid, :sid, :pid, NOW())",
        [':hwid' => $homeworkId, ':sid' => $studentId, ':pid' => $parentId]
    );

    ob_end_clean();
    successResponse(
        ['homework_id' => $homeworkId, 'student_id' => $studentId],
        'Homework acknowledged successfully'
    );
}


/* ─────────────────────────────────────────────────────────────
   HOMEWORK COMMENTS (parent feedback → teacher notification)
───────────────────────────────────────────────────────────── */
function ensureHomeworkCommentsTable($db) {
    static $done = false;
    if ($done) return;
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS homework_comments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                homework_id INT NOT NULL,
                student_id INT NOT NULL,
                parent_id INT NOT NULL,
                comment TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_hc_hw (homework_id),
                KEY idx_hc_parent (parent_id)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) {
        error_log('ensureHomeworkCommentsTable: ' . $e->getMessage());
    }
    $done = true;
}

function commentHomework($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }
    requireRole(['parent', 'admin']);
    ensureHomeworkCommentsTable($db);

    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) $body = $_POST;

    $homeworkId = isset($body['homework_id']) ? (int)$body['homework_id'] : 0;
    $studentId  = isset($body['student_id']) ? (int)$body['student_id'] : 0;
    $comment    = isset($body['comment']) ? trim(strip_tags((string)$body['comment'])) : '';
    $parentId   = getParentId();

    if (!$homeworkId || !$studentId) {
        ob_end_clean(); errorResponse('homework_id and student_id are required', 400);
    }
    if ($comment === '' || mb_strlen($comment) < 2) {
        ob_end_clean(); errorResponse('Please write a short comment (at least 2 characters)', 400);
    }
    if (mb_strlen($comment) > 2000) {
        ob_end_clean(); errorResponse('Comment is too long (max 2000 characters)', 400);
    }
    if (!$parentId) {
        ob_end_clean(); errorResponse('Authentication required', 401);
    }

    // Parent must be linked to this student
    $link = $db->queryOne(
        "SELECT p.id FROM parents p
          WHERE p.user_id = :uid AND p.student_id = :sid LIMIT 1",
        array(':uid' => $parentId, ':sid' => $studentId)
    );
    if (!$link && (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin')) {
        ob_end_clean(); errorResponse('You are not linked to this student', 403);
    }

    // Homework must be for student's class
    $hw = $db->queryOne(
        "SELECT h.id, h.subject, h.posted_by, h.class_id, s.student_name
           FROM homework h
           JOIN students s ON s.id = :sid AND s.class_id = h.class_id
          WHERE h.id = :hwid LIMIT 1",
        array(':sid' => $studentId, ':hwid' => $homeworkId)
    );
    if (!$hw) {
        ob_end_clean(); errorResponse('Homework not found for this student', 404);
    }

    $cid = $db->execute(
        "INSERT INTO homework_comments (homework_id, student_id, parent_id, comment, created_at)
         VALUES (:hw, :sid, :pid, :c, NOW())",
        array(
            ':hw' => $homeworkId,
            ':sid' => $studentId,
            ':pid' => $parentId,
            ':c' => $comment,
        )
    );
    if (!$cid) {
        ob_end_clean(); errorResponse('Failed to save comment', 500);
    }

    // Notify the teacher who posted the homework
    $teacherId = (int)$hw['posted_by'];
    $parentName = '';
    $prow = $db->queryOne("SELECT full_name FROM users WHERE id = :id", array(':id' => $parentId));
    if ($prow) $parentName = $prow['full_name'];

    $title = 'Parent feedback on ' . $hw['subject'];
    $msg = ($parentName ? $parentName : 'A parent')
        . ' left feedback on homework for ' . $hw['student_name'] . ': "'
        . (mb_strlen($comment) > 120 ? mb_substr($comment, 0, 117) . '...' : $comment) . '"';
    $ref = 'hw_comment_' . $homeworkId . '_' . $cid;

    if (function_exists('_notifyTeacher')) {
        _notifyTeacher($db, $teacherId, 'homework_comment', $title, $msg, $ref);
    } else {
        try {
            $db->execute(
                "INSERT INTO notifications (user_id, type, title, message, is_read, created_at)
                 VALUES (:uid, 'homework_comment', :t, :m, 0, NOW())",
                array(':uid' => $teacherId, ':t' => $title, ':m' => $msg)
            );
        } catch (Exception $e) {
            error_log('comment notify: ' . $e->getMessage());
        }
    }

    ob_end_clean();
    successResponse(array(
        'id' => $cid,
        'homework_id' => $homeworkId,
        'comment' => $comment,
        'created_at' => date('Y-m-d H:i:s'),
        'parent_name' => $parentName,
    ), 'Comment sent to the teacher');
}

function listHomeworkComments($db) {
    requireRole(['parent', 'admin', 'teacher']);
    ensureHomeworkCommentsTable($db);
    $homeworkId = isset($_GET['homework_id']) ? (int)$_GET['homework_id'] : 0;
    $studentId  = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$homeworkId) {
        ob_end_clean(); errorResponse('homework_id required', 400);
    }

    try {
        $col = $db->query("SHOW COLUMNS FROM homework_comments LIKE 'teacher_reply'");
        if (empty($col)) {
            $db->execute("ALTER TABLE homework_comments ADD COLUMN teacher_reply TEXT NULL");
            $db->execute("ALTER TABLE homework_comments ADD COLUMN replied_at DATETIME NULL");
            $db->execute("ALTER TABLE homework_comments ADD COLUMN replied_by INT NULL");
        }
    } catch (Exception $e) {}
    $sql = "SELECT c.id, c.comment, c.created_at, c.student_id, c.parent_id,
                   c.teacher_reply, c.replied_at,
                   u.full_name AS parent_name, s.student_name
              FROM homework_comments c
              JOIN users u ON u.id = c.parent_id
              JOIN students s ON s.id = c.student_id
             WHERE c.homework_id = :hw";
    $params = array(':hw' => $homeworkId);
    if ($studentId > 0) {
        $sql .= " AND c.student_id = :sid";
        $params[':sid'] = $studentId;
    }
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
    if ($role === 'parent') {
        $sql .= " AND c.parent_id = :pid";
        $params[':pid'] = getParentId();
    }
    $sql .= " ORDER BY c.created_at ASC";
    $rows = $db->query($sql, $params) ?: array();
    ob_end_clean();
    successResponse($rows);
}

