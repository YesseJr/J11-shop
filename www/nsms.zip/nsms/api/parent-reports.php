<?php
/**
 * NSMS — Parent Reports API  (v2)
 * /nsms/api/parent-reports.php
 *
 * Reads from student_reports (is_published = 1).
 * Ownership via parents table (parents.user_id + parents.student_id).
 * PHP 7.2 compatible — no arrow functions, no JSON_LENGTH in SQL.
 *
 * Actions (GET):
 *   children    — students linked to this parent
 *   list        — all published reports for a student
 *   get         — full detail of one report
 *   school_info — school name, logo, motto for the report header
 */

ob_start();
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

applyApiHeaders();

/* ── Session ── */
$_sRole     = isset($_SESSION['role'])      ? strtolower(trim($_SESSION['role'])) : '';
$_sUserId   = isset($_SESSION['user_id'])   ? (int)$_SESSION['user_id']           : 0;
$_sParentId = isset($_SESSION['parent_id']) ? (int)$_SESSION['parent_id']         : 0;
$_isAdmin   = ($_sRole === 'admin');
$_isParent  = ($_sRole === 'parent') || ($_sParentId > 0) || ($_sUserId > 0);

if (!$_isAdmin && !$_isParent) {
    ob_end_clean();
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Not authenticated.']);
    exit;
}

try {
    $db   = new Database();
    $conn = $db->connect();
    if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

    $action = isset($_GET['action']) ? trim($_GET['action']) : '';
    switch ($action) {
        case 'children':    getChildren($db);   break;
        case 'list':        listReports($db);   break;
        case 'get':         getReport($db);     break;
        case 'school_info': getSchoolInfo($db); break;
        case 'class_rank': getClassRank($db); break;
        default: ob_end_clean(); errorResponse('Invalid action');
    }
} catch (Exception $e) {
    ob_end_clean();
    error_log('NSMS parent-reports: ' . $e->getMessage());
    errorResponse('Server error: ' . $e->getMessage(), 500);
} catch (Throwable $e) {
    ob_end_clean();
    error_log('NSMS parent-reports fatal: ' . $e->getMessage());
    errorResponse('Server error: ' . $e->getMessage(), 500);
}

/* ════════════════════════════════════════
   OWNERSHIP HELPERS
════════════════════════════════════════ */

/**
 * Return true if the current session's parent owns the given student.
 * Checks parents.user_id first (standard), then parents.id (legacy).
 */
function parentOwnsStudent($db, $studentId) {
    global $_isAdmin, $_sUserId, $_sParentId;
    if ($_isAdmin)    return true;
    if (!$studentId)  return false;

    if ($_sUserId) {
        $r = $db->queryOne(
            "SELECT 1 FROM parents WHERE user_id = :uid AND student_id = :sid LIMIT 1",
            [':uid' => $_sUserId, ':sid' => $studentId]
        );
        if ($r) return true;
    }
    if ($_sParentId) {
        $r = $db->queryOne(
            "SELECT 1 FROM parents WHERE id = :pid AND student_id = :sid LIMIT 1",
            [':pid' => $_sParentId, ':sid' => $studentId]
        );
        if ($r) return true;
    }
    return false;
}

/* ════════════════════════════════════════
   GRADE / LABEL HELPERS
════════════════════════════════════════ */

function pctToGrade($avg) {
    if ($avg === null || $avg === '') return null;
    $avg = (float)$avg;
    if ($avg >= 90) return 'A';
    if ($avg >= 75) return 'B';
    if ($avg >= 60) return 'C';
    if ($avg >= 50) return 'D';
    if ($avg >= 40) return 'E';
    return 'F';
}

function gradeToLabel($g) {
    $map = ['A'=>'Excellent','B'=>'Very Good','C'=>'Good','D'=>'Average','E'=>'Below Average','F'=>'Poor'];
    return isset($map[$g]) ? $map[$g] : (string)$g;
}

function gradeToColor($g) {
    $map = ['A'=>'#059669','B'=>'#2563EB','C'=>'#D97706','D'=>'#F59E0B','E'=>'#EF4444','F'=>'#DC2626'];
    return isset($map[$g]) ? $map[$g] : '#6B7280';
}

function typeLabel($t) {
    $map = ['daily'=>'Daily Report','weekly'=>'Weekly Report','midterm'=>'Mid-term Report','terminal'=>'Term Report'];
    return isset($map[$t]) ? $map[$t] : ucfirst($t).' Report';
}

/**
 * Parse subject_data JSON and return [subjects_array, subject_count, overall_grade, overall_avg].
 * PHP 7.2 compatible — no arrow functions.
 */
function parseSubjectData($json) {
    $subjects = [];
    if (empty($json)) {
        return [$subjects, 0, null, null];
    }
    $raw = json_decode($json, true);
    if (!is_array($raw)) {
        return [$subjects, 0, null, null];
    }
    foreach ($raw as $name => $d) {
        $g = isset($d['grade_letter']) ? $d['grade_letter'] : null;
        $subjects[] = [
            'subject_name'      => $name,
            'subject_code'      => isset($d['subject_code'])      ? $d['subject_code']      : '',
            'average_score'     => isset($d['average_score'])     ? $d['average_score']     : null,
            'grade_letter'      => $g,
            'grade_label'       => $g ? gradeToLabel($g)          : null,
            'grade_color'       => $g ? gradeToColor($g)          : '#6B7280',
            'performance_level' => isset($d['performance_level']) ? $d['performance_level'] : null,
            'rating'            => isset($d['rating'])            ? $d['rating']            : null,
        ];
    }
    /* Compute overall average — PHP 7.2: no arrow functions */
    $scores = [];
    foreach ($subjects as $s) {
        if ($s['average_score'] !== null && $s['average_score'] !== '') {
            $scores[] = (float)$s['average_score'];
        }
    }
    $overallAvg   = count($scores) > 0 ? round(array_sum($scores) / count($scores), 1) : null;
    $overallGrade = pctToGrade($overallAvg);

    return [$subjects, count($subjects), $overallGrade, $overallAvg];
}

/* ════════════════════════════════════════
   SAFE TEACHER NAME LOOKUP
   Tries common column names — never throws.
════════════════════════════════════════ */
function getTeacherName($db, $teacherId) {
    if (!($teacherId)) return 'Teacher';
    /* Try the most common column names used in school systems */
    $attempts = [
        "SELECT full_name AS n FROM users WHERE id=:id LIMIT 1",
        "SELECT username AS n FROM users WHERE id=:id LIMIT 1",
        "SELECT name AS n FROM users WHERE id=:id LIMIT 1",
    ];
    foreach ($attempts as $sql) {
        try {
            $row = $db->queryOne($sql, [':id' => (int)$teacherId]);
            if ($row && !empty($row['n'])) return $row['n'];
        } catch (Exception $e) {
            /* column doesn't exist — try next */
        }
    }
    return 'Teacher';
}

/* ════════════════════════════════════════
   GET: CHILDREN
════════════════════════════════════════ */
function getChildren($db) {
    global $_isAdmin, $_sUserId, $_sParentId;

    if ($_isAdmin) {
        $rows = $db->query(
            "SELECT s.id, s.student_name, s.photo_url, s.gender,
                    COALESCE(c.class_name, '') AS class_name, c.id AS class_id
             FROM students s
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE s.status = 'active'
             ORDER BY s.student_name
             LIMIT 100"
        ) ?: [];
        ob_end_clean();
        successResponse(['children' => $rows]);
        return;
    }

    /* For parents: try user_id first, fallback to parents.id */
    $rows = [];
    if ($_sUserId) {
        $rows = $db->query(
            "SELECT s.id, s.student_name, s.photo_url, s.gender,
                    COALESCE(c.class_name, '') AS class_name, c.id AS class_id
             FROM parents p
             JOIN students s ON s.id = p.student_id
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE p.user_id = :uid AND s.status = 'active'
             ORDER BY s.student_name",
            [':uid' => $_sUserId]
        ) ?: [];
    }
    if (empty($rows) && $_sParentId) {
        $rows = $db->query(
            "SELECT s.id, s.student_name, s.photo_url, s.gender,
                    COALESCE(c.class_name, '') AS class_name, c.id AS class_id
             FROM parents p
             JOIN students s ON s.id = p.student_id
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE p.id = :pid AND s.status = 'active'
             ORDER BY s.student_name",
            [':pid' => $_sParentId]
        ) ?: [];
    }

    ob_end_clean();
    successResponse(['children' => $rows]);
}

/* ════════════════════════════════════════
   GET: LIST REPORTS
════════════════════════════════════════ */
function listReports($db) {
    $sid = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$sid) { ob_end_clean(); errorResponse('student_id required.'); }
    if (!parentOwnsStudent($db, $sid)) { ob_end_clean(); errorResponse('Access denied.', 403); }

    $where  = ['sr.student_id = :sid', 'sr.is_published = 1'];
    $params = [':sid' => $sid];

    if (!empty($_GET['report_type'])) {
        $where[]              = 'sr.report_type = :rtype';
        $params[':rtype']     = trim($_GET['report_type']);
    }
    if (!empty($_GET['term'])) {
        $where[]          = 'sr.term = :term';
        $params[':term']  = trim($_GET['term']);
    }

    /* No JOIN to users — column names vary per install and silently break the whole query */
    $rows = $db->query(
        "SELECT sr.id, sr.report_type, sr.period_label, sr.term, sr.academic_year,
                sr.report_date, sr.published_at,
                sr.promotion_status, sr.subject_data, sr.teacher_id
         FROM student_reports sr
         WHERE " . implode(' AND ', $where) . "
         ORDER BY sr.published_at DESC, sr.report_date DESC
         LIMIT 100",
        $params
    ) ?: [];

    /* Build output — parse JSON in PHP, compute grade + count */
    $out    = [];
    $counts = ['daily' => 0, 'weekly' => 0, 'midterm' => 0, 'terminal' => 0, 'total' => 0];

    foreach ($rows as $row) {
        list($subjects, $subjectCount, $overallGrade, $overallAvg) = parseSubjectData(
            isset($row['subject_data']) ? $row['subject_data'] : null
        );

        $rtype = isset($row['report_type']) ? $row['report_type'] : 'daily';
        if (isset($counts[$rtype])) $counts[$rtype]++;
        $counts['total']++;

        $out[] = [
            'id'               => (int)$row['id'],
            'report_type'      => $rtype,
            'period_label'     => $row['period_label'],
            'term'             => $row['term'],
            'academic_year'    => $row['academic_year'],
            'report_date'      => $row['report_date'],
            'published_at'     => $row['published_at'],
            'teacher_name'     => getTeacherName($db, isset($row['teacher_id']) ? $row['teacher_id'] : null),
            'promotion_status' => $row['promotion_status'],
            'subject_count'    => $subjectCount,
            'overall_grade'    => $overallGrade,
            'overall_average'  => $overallAvg,
        ];
    }

    ob_end_clean();
    successResponse(['reports' => $out, 'counts' => $counts]);
}

/* ════════════════════════════════════════
   GET: SINGLE REPORT (full detail)
════════════════════════════════════════ */
function getReport($db) {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) { ob_end_clean(); errorResponse('id required.'); }

    /* No users JOIN — fetch teacher name separately to avoid unknown column errors */
    $r = $db->queryOne(
        "SELECT sr.*,
                s.student_name, s.photo_url, s.gender,
                COALESCE(c.class_name, '') AS class_name
         FROM student_reports sr
         JOIN students s ON s.id = sr.student_id
         LEFT JOIN classes c ON c.id = sr.class_id
         WHERE sr.id = :id AND sr.is_published = 1
         LIMIT 1",
        [':id' => $id]
    );
    if (!$r) { ob_end_clean(); errorResponse('Report not found.', 404); }
    if (!parentOwnsStudent($db, (int)$r['student_id'])) {
        ob_end_clean(); errorResponse('Access denied.', 403);
    }

    list($subjects, $subjectCount, $overallGrade, $overallAvg) = parseSubjectData(
        isset($r['subject_data']) ? $r['subject_data'] : null
    );

    ob_end_clean();
    successResponse([
        'id'                  => (int)$r['id'],
        'report_type'         => $r['report_type'],
        'type_label'          => typeLabel($r['report_type']),
        'period_label'        => $r['period_label'],
        'term'                => $r['term'],
        'academic_year'       => $r['academic_year'],
        'report_date'         => $r['report_date'],
        'published_at'        => $r['published_at'],
        /* IDs needed for auto class-rank calculation */
        'student_id'          => (int)$r['student_id'],
        'class_id'            => isset($r['class_id'])    ? (int)$r['class_id']    : 0,
        /* teacher_id exposed so the frontend can build the J11 Pulse link correctly */
        'teacher_id'          => isset($r['teacher_id'])  ? (int)$r['teacher_id']  : null,
        'student_name'        => $r['student_name'],
        'photo_url'           => isset($r['photo_url'])    ? $r['photo_url']    : '',
        'gender'              => isset($r['gender'])       ? $r['gender']       : '',
        'class_name'          => $r['class_name'],
        'teacher_name'        => getTeacherName($db, isset($r['teacher_id']) ? $r['teacher_id'] : null),
        'subjects'            => $subjects,
        'subject_count'       => $subjectCount,
        'overall_average'     => $overallAvg,
        'overall_grade'       => $overallGrade,
        'overall_grade_label' => $overallGrade ? gradeToLabel($overallGrade) : null,
        'conduct'             => isset($r['conduct'])             ? $r['conduct']             : null,
        'punctuality'         => isset($r['punctuality'])         ? $r['punctuality']         : null,
        'neatness'            => isset($r['neatness'])            ? $r['neatness']            : null,
        'class_participation' => isset($r['class_participation']) ? $r['class_participation'] : null,
        'social_skills'       => isset($r['social_skills'])       ? $r['social_skills']       : null,
        'teacher_comments'    => isset($r['teacher_comments'])    ? $r['teacher_comments']    : '',
        'recommendations'     => isset($r['recommendations'])     ? $r['recommendations']     : '',
        'promotion_status'    => isset($r['promotion_status'])    ? $r['promotion_status']    : null,
    ]);
}

/* ════════════════════════════════════════
   GET: SCHOOL INFO
════════════════════════════════════════ */
function getSchoolInfo($db) {
    $keys = ['school_name', 'school_motto', 'school_logo', 'school_address', 'school_phone', 'school_email'];
    $info = [];
    foreach ($keys as $k) {
        $row = $db->queryOne(
            "SELECT setting_value FROM school_settings WHERE setting_key = :k",
            [':k' => $k]
        );
        $info[$k] = $row ? $row['setting_value'] : null;
    }
    ob_end_clean();
    successResponse(['school' => $info]);
}

function getClassRank($db) {

    /* ── inputs ── */
    $studentId   = isset($_GET['student_id'])    ? (int)  trim($_GET['student_id'])    : 0;
    $classId     = isset($_GET['class_id'])      ? (int)  trim($_GET['class_id'])      : 0;
    $term        = isset($_GET['term'])          ? trim($_GET['term'])                 : '';
    $academicYear= isset($_GET['academic_year']) ? trim($_GET['academic_year'])        : '';
    $reportType  = isset($_GET['report_type'])   ? trim($_GET['report_type'])          : '';

    if (!$studentId || !$classId || !$term || !$academicYear || !in_array($reportType, ['midterm','terminal'], true)) {
        ob_end_clean();
        errorResponse('student_id, class_id, term, academic_year, report_type (midterm/terminal) are required.');
        return;
    }

    /*
     * ── Auth guard ──────────────────────────────────────────────────
     * Only allow a parent to query rank for their own linked child.
     * Bug fix: sessionInfo() does not exist in this file — use the
     * global variables set at the top of parent-reports.php instead.
     */
    global $_sRole, $_sUserId, $_isAdmin;
    if (!$_isAdmin && $_sRole === 'parent') {
        if (!$_sUserId) { ob_end_clean(); errorResponse('Access denied.', 403); return; }
        $linked = $db->queryOne(
            "SELECT 1 FROM parents WHERE user_id = :uid AND student_id = :sid LIMIT 1",
            [':uid' => $_sUserId, ':sid' => $studentId]
        );
        if (!$linked) {
            ob_end_clean();
            errorResponse('Access denied.', 403);
            return;
        }
    }

    /*
     * ── Rank query ──────────────────────────────────────────────────
     * Ranks by each student's average across every grade recorded for
     * assessments of this exact report type (midterm or terminal) —
     * the same live source teacher-reports.php now uses to build the
     * report itself, so the position always matches what's on the page.
     * (Previously this summed a separate, all-assessment-types-blended
     * cache table, which could disagree with the report's own numbers
     * and made a midterm report and a terminal report show the same
     * rank for the same term.)
     *
     * We use a sub-select for portability (MySQL 5.6+ / MariaDB 10.1+)
     * rather than window functions, so it works on shared hosting.
     */
    $rankedRows = $db->query(
        "SELECT gg.student_id,
                AVG(gg.score / ga.max_score * 100) AS total_score
         FROM   gradebook_grades gg
         JOIN   gradebook_assessments ga ON ga.id = gg.assessment_id
         WHERE  ga.class_id       = :cid
           AND  ga.term           = :term
           AND  ga.academic_year  = :yr
           AND  ga.assessment_type= :type
           AND  gg.score IS NOT NULL
           AND  ga.is_published   = 1
         GROUP  BY gg.student_id
         ORDER  BY total_score DESC",
        [':cid' => $classId, ':term' => $term, ':yr' => $academicYear, ':type' => $reportType]
    ) ?: [];

    $totalStudents = count($rankedRows);

    if ($totalStudents === 0) {
        ob_end_clean();
        successResponse([
            'position'       => null,
            'total_students' => 0,
            'total_score'    => null,
            'message'        => 'No performance data available yet for this term.',
        ]);
        return;
    }

    /* Walk the ranked list to find this student's position.
       Ties share the same position (dense rank). */
    $position    = null;
    $totalScore  = null;
    $lastScore   = null;
    $currentRank = 0;

    foreach ($rankedRows as $row) {
        $score = (float) $row['total_score'];
        if ($score !== $lastScore) {
            $currentRank++;
            $lastScore = $score;
        }
        if ((int)$row['student_id'] === $studentId) {
            $position   = $currentRank;
            $totalScore = $score;
            break;
        }
    }

    ob_end_clean();
    successResponse([
        'position'       => $position,
        'total_students' => $totalStudents,
        'total_score'    => $totalScore,
    ]);
}