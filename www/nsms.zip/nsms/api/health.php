<?php
/**
 * Health / diagnostics.
 *  - GET ?public=1  → limited status for uptime monitors (no secrets)
 *  - GET (admin)    → full operational diagnostics
 */
ob_start();
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once '../includes/fee_ledger.php';

applyApiHeaders();

$publicOnly = isset($_GET['public']) && $_GET['public'] !== '0' && $_GET['public'] !== 'false';

$db = new Database();
$conn = $db->connect();

$checks = array();
$ok = true;

// DB
if (!$conn) {
    $checks['database'] = array('ok' => false, 'detail' => 'connection failed');
    $ok = false;
} else {
    $checks['database'] = array('ok' => true, 'detail' => 'connected');
}

// SITE_URL
$site = defined('NSMS_SITE_URL') ? NSMS_SITE_URL : (defined('SITE_URL') ? SITE_URL : '');
$siteOk = $site !== '' && stripos($site, 'localhost') === false && stripos($site, '127.0.0.1') === false;
$checks['site_url'] = array(
    'ok' => $site !== '',
    'configured' => $site !== '',
    'looks_public' => $siteOk,
    'value' => $publicOnly ? ($siteOk ? 'set' : 'missing_or_local') : $site,
);
if ($site === '') $ok = false;

// Brevo
$brevoKey = defined('BREVO_API_KEY') ? BREVO_API_KEY : '';
$brevoOk = $brevoKey !== '' && strpos($brevoKey, 'xkeysib-xxxx') !== 0 && strlen($brevoKey) > 20;
$checks['brevo'] = array(
    'ok' => $brevoOk,
    'detail' => $brevoOk ? 'api_key_present' : 'api_key_missing_or_placeholder',
);
$sender = defined('MAIL_SENDER_EMAIL') ? MAIL_SENDER_EMAIL : '';
$checks['mail_sender'] = array(
    'ok' => $sender !== '' && strpos($sender, 'your-domain') === false,
    'value' => $publicOnly ? ($sender ? 'set' : 'missing') : $sender,
);

// Built frontend marker
$builtShared = dirname(__DIR__) . '/public/js/built/nsms-shared.js';
$checks['frontend_build'] = array(
    'ok' => is_file($builtShared),
    'detail' => is_file($builtShared) ? 'nsms-shared.js present' : 'run npm run build',
);

if ($publicOnly) {
    ob_end_clean();
    http_response_code($ok && $checks['database']['ok'] ? 200 : 503);
    echo json_encode(array(
        'success' => $ok && $checks['database']['ok'],
        'status' => ($ok && $checks['database']['ok']) ? 'ok' : 'degraded',
        'checks' => array(
            'database' => $checks['database']['ok'],
            'site_url_configured' => !empty($checks['site_url']['configured']),
            'brevo_configured' => $brevoOk,
            'frontend_build' => $checks['frontend_build']['ok'],
        ),
        'time' => date('c'),
    ));
    exit;
}

// Admin-only from here
if (!isLoggedIn()) {
    ob_end_clean();
    errorResponse('Admin login required for full diagnostics', 401);
}
$role = function_exists('getCurrentUserRole') ? getCurrentUserRole() : null;
if ($role !== 'admin') {
    ob_end_clean();
    errorResponse('Admin login required for full diagnostics', 403);
}

$metrics = array();
if ($conn) {
    try {
        $metrics['users_active'] = (int) (($db->queryOne("SELECT COUNT(*) AS c FROM users WHERE status='active'") ?: array('c'=>0))['c']);
        $metrics['parents'] = (int) (($db->queryOne("SELECT COUNT(*) AS c FROM users WHERE role='parent' AND status='active'") ?: array('c'=>0))['c']);
        $metrics['teachers'] = (int) (($db->queryOne("SELECT COUNT(*) AS c FROM users WHERE role='teacher' AND status='active'") ?: array('c'=>0))['c']);
        $metrics['students_active'] = (int) (($db->queryOne("SELECT COUNT(*) AS c FROM students WHERE status='active'") ?: array('c'=>0))['c']);
        $metrics['password_changed_0'] = (int) (($db->queryOne("SELECT COUNT(*) AS c FROM users WHERE role IN ('parent','teacher') AND password_changed=0") ?: array('c'=>0))['c']);
    } catch (Exception $e) {
        $metrics['error'] = $e->getMessage();
    }

    try {
        $metrics['reset_tokens_last_7d'] = (int) (($db->queryOne(
            "SELECT COUNT(*) AS c FROM password_reset_tokens WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
        ) ?: array('c'=>0))['c']);
        $metrics['reset_tokens_used_7d'] = (int) (($db->queryOne(
            "SELECT COUNT(*) AS c FROM password_reset_tokens WHERE used_at IS NOT NULL AND used_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
        ) ?: array('c'=>0))['c']);
    } catch (Exception $e) {
        $metrics['reset_tokens_last_7d'] = null;
    }

    try {
        $metrics['logins_7d'] = (int) (($db->queryOne(
            "SELECT COUNT(*) AS c FROM activity_logs WHERE action='LOGIN' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
        ) ?: array('c'=>0))['c']);
        $metrics['resets_7d'] = (int) (($db->queryOne(
            "SELECT COUNT(*) AS c FROM activity_logs WHERE action IN ('PASSWORD_RESET_LINK','PASSWORD_RESET_COMPLETE') AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
        ) ?: array('c'=>0))['c']);
    } catch (Exception $e) {
        $metrics['logins_7d'] = null;
    }

    try {
        $rec = nsmsLedgerReconcileSummary($db, 30);
        $metrics['ledger_mismatch_sample'] = isset($rec['mismatch_count']) ? $rec['mismatch_count'] : null;
        $metrics['ledger_students_sampled'] = isset($rec['students_checked']) ? $rec['students_checked'] : null;
    } catch (Exception $e) {
        $metrics['ledger_mismatch_sample'] = null;
    }
}

ob_end_clean();
successResponse(array(
    'status' => $ok ? 'ok' : 'degraded',
    'checks' => $checks,
    'metrics' => $metrics,
    'time' => date('c'),
    'tips' => array(
        'Set NSMS_SITE_URL to your public https URL',
        'Set NSMS_BREVO_API_KEY and verified MAIL_SENDER_EMAIL',
        'Run npm run build after frontend edits',
        'GET finance.php?action=ledger_reconcile to inspect fee dual-path',
        'POST finance.php?action=ledger_promote to insert missing fee_payments from gateway (no deletes)',
    ),
), $ok ? 'Healthy' : 'Degraded — review checks');
