<?php
/**
 * Teacher Attendance API
 * /nsms/api/teacher-attendance.php
 * PHP 7.2 compatible.
 *
 * Schema (attendance table):
 *   student_id, attendance_date, status, late_minutes (auto-added below),
 *   marked_by, marked_at, notes
 *   UNIQUE KEY unique_student_date (student_id, attendance_date)
 *
 * Actions:
 *   GET  ?action=get_today    [&date=YYYY-MM-DD] [&class_id=N]
 *        Students + saved statuses + late_minutes for the given date (marking view).
 *
 *   GET  ?action=get_history  [&date=YYYY-MM-DD] [&class_id=N]
 *        Full attendance record for a date, students grouped by status.
 *        Includes marked_at timestamp and teacher name (LEFT JOIN users).
 *        Students with no record appear in the "unmarked" group.
 *
 *   GET  ?action=get_holidays [&year=YYYY]
 *        Blocked dates from school_calendar / holidays tables.
 *        Weekends handled client-side.
 *
 *   POST ?action=save
 *        JSON: { "date": "YYYY-MM-DD", "records": [{ student_id, status, late_minutes? }] }
 *        Not future, not weekend. Upserts via ON DUPLICATE KEY UPDATE.
 *
 * DB MIGRATION (auto-runs, safe to repeat):
 *   ALTER TABLE attendance ADD COLUMN late_minutes INT UNSIGNED DEFAULT NULL;
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once __DIR__ . '/../includes/sync/SyncHooks.php';
require_once __DIR__ . '/../includes/sync/OfflineData.php';

applyApiHeaders();

requireRole(['admin', 'teacher']);

$db   = new Database();
$conn = $db->connect();
$mysqlOnline = (bool)$conn;
$action = isset($_GET['action']) ? $_GET['action'] : '';

if (!$mysqlOnline) {
    if ($action === 'save') {
        $data = json_decode(file_get_contents('php://input'), true);
        if (!is_array($data)) { ob_end_clean(); errorResponse('Invalid JSON body'); }
        $date = isset($data['date']) ? trim($data['date']) : date('Y-m-d');
        $records = isset($data['records']) ? $data['records'] : array();
        $classId = isset($data['class_id']) ? (int)$data['class_id'] : 0;
        if (!$classId && !empty($_SESSION['user_id'])) {
            // best-effort: first class in offline cache
            try {
                require_once __DIR__ . '/../includes/sync/SqliteStore.php';
                $pdo = (new SqliteStore())->connect();
                $classId = (int)$pdo->query('SELECT id FROM classes LIMIT 1')->fetchColumn();
            } catch (Exception $e) {}
        }
        $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
        $n = OfflineData::queueAttendance($classId, $date, $records, $userId);
        ob_end_clean();
        successResponse(array('saved' => $n, 'offline_mode' => true, 'queued' => $n), 'Attendance saved offline — will sync when online');
    }
    if ($action === 'get_today' || $action === 'get_history') {
        $date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
        $classId = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
        $rows = OfflineData::listAttendanceForDate($classId, $date);
        $students = OfflineData::listStudents('active', $classId ?: null);
        ob_end_clean();
        successResponse(array(
            'students' => $students,
            'records' => $rows,
            'offline_mode' => true,
            'date' => $date,
        ), 'Offline attendance cache');
    }
    ob_end_clean();
    errorResponse('Attendance requires MySQL for this action, or save/get_today offline only.', 503);
}

/* Auto-migrate */
try {
    $db->execute("ALTER TABLE attendance ADD COLUMN late_minutes INT UNSIGNED DEFAULT NULL");
} catch (Exception $e) {}

$action = isset($_GET['action']) ? trim($_GET['action']) : '';

switch ($action) {
    case 'get_today':    getTodayAttendance($db);   break;
    case 'get_history':  getAttendanceHistory($db); break;
    case 'get_holidays': getBlockedDates($db);      break;
    case 'save':         saveAttendance($db);       break;
    default: ob_end_clean(); errorResponse('Invalid action');
}

/* ═══════════════════════════════════════════════════════════════════════════
   HELPERS
═══════════════════════════════════════════════════════════════════════════ */
function resolveClassId($db) {
    if (isset($_GET['class_id']) && (int)$_GET['class_id'] > 0) return (int)$_GET['class_id'];
    $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
    if (!$userId) return null;
    $row = $db->queryOne("SELECT id FROM classes WHERE teacher_id = :uid LIMIT 1", [':uid' => $userId]);
    return $row ? (int)$row['id'] : null;
}

function validateAttendanceDate($date) {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date))
        return ['ok' => false, 'reason' => 'Invalid date format. Use YYYY-MM-DD.'];
    if ($date > date('Y-m-d'))
        return ['ok' => false, 'reason' => 'Cannot record attendance for future dates.'];
    $dow = (int)date('N', strtotime($date));
    if ($dow === 6) return ['ok' => false, 'reason' => 'Saturdays are not school days.'];
    if ($dow === 7) return ['ok' => false, 'reason' => 'Sundays are not school days.'];
    return ['ok' => true, 'reason' => ''];
}

/* ═══════════════════════════════════════════════════════════════════════════
   GET TODAY'S ATTENDANCE  (marking-mode — returns all students + current status)
═══════════════════════════════════════════════════════════════════════════ */
function getTodayAttendance($db) {
    $classId = resolveClassId($db);
    if (!$classId) { ob_end_clean(); errorResponse('No class is assigned to this teacher account.'); }

    $date = isset($_GET['date']) ? trim($_GET['date']) : date('Y-m-d');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');

    $students = $db->query(
        "SELECT s.id, s.student_name, s.photo_url, c.class_name, c.class_color
         FROM   students s JOIN classes c ON c.id = s.class_id
         WHERE  s.class_id = :cid AND s.status = 'active'
         ORDER  BY s.student_name ASC",
        [':cid' => $classId]
    ) ?: [];

    $existing = [];
    if (!empty($students)) {
        $ids      = implode(',', array_map(function($s){ return (int)$s['id']; }, $students));
        $existing = $db->query(
            "SELECT student_id, status, late_minutes
             FROM   attendance
             WHERE  student_id IN ($ids) AND attendance_date = :date",
            [':date' => $date]
        ) ?: [];
    }

    $attMap = [];
    foreach ($existing as $row) {
        $attMap[(int)$row['student_id']] = [
            'status'       => $row['status'],
            'late_minutes' => isset($row['late_minutes']) ? (int)$row['late_minutes'] : null,
        ];
    }
    foreach ($students as &$s) {
        $rec = isset($attMap[(int)$s['id']]) ? $attMap[(int)$s['id']] : null;
        $s['attendance_status'] = $rec ? $rec['status']       : null;
        $s['late_minutes']      = $rec ? $rec['late_minutes'] : null;
    }
    unset($s);

    $classRow = $db->queryOne("SELECT class_name FROM classes WHERE id = :id", [':id' => $classId]);

    ob_end_clean();
    successResponse([
        'date'          => $date,
        'class_id'      => $classId,
        'class_name'    => $classRow ? $classRow['class_name'] : '',
        'students'      => $students,
        'already_saved' => count($existing) > 0,
    ]);
}

/* ═══════════════════════════════════════════════════════════════════════════
   GET ATTENDANCE HISTORY  (read-only — grouped by status, includes metadata)
   Uses LEFT JOIN so unmarked students are visible even in partial saves.
═══════════════════════════════════════════════════════════════════════════ */
function getAttendanceHistory($db) {
    $classId = resolveClassId($db);
    if (!$classId) { ob_end_clean(); errorResponse('No class is assigned to this teacher account.'); }

    $date = isset($_GET['date']) ? trim($_GET['date']) : date('Y-m-d');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');

    $classRow = $db->queryOne("SELECT class_name FROM classes WHERE id = :id", [':id' => $classId]);

    /*
     * LEFT JOIN attendance: every active student appears even without a record.
     * LEFT JOIN users: get the display name of whoever marked attendance.
     */
    $rows = $db->query(
        "SELECT
             s.id           AS student_id,
             s.student_name,
             s.photo_url,
             a.status,
             a.late_minutes,
             a.marked_at,
             u.full_name    AS marked_by_name
         FROM   students s
         LEFT   JOIN attendance a
                  ON a.student_id      = s.id
                 AND a.attendance_date = :date
         LEFT   JOIN users u ON u.id = a.marked_by
         WHERE  s.class_id = :cid AND s.status = 'active'
         ORDER  BY
             FIELD(a.status, 'present', 'late', 'absent', NULL),
             s.student_name ASC",
        [':date' => $date, ':cid' => $classId]
    ) ?: [];

    $present  = [];
    $absent   = [];
    $late     = [];
    $unmarked = [];
    $markedAt      = null;
    $markedByName  = null;

    foreach ($rows as $row) {
        $entry = [
            'student_id'   => (int)$row['student_id'],
            'student_name' => $row['student_name'],
            'photo_url'    => $row['photo_url']    ?: null,
            'late_minutes' => isset($row['late_minutes']) && $row['late_minutes'] !== null
                              ? (int)$row['late_minutes'] : null,
        ];

        switch ($row['status']) {
            case 'present': $present[] = $entry; break;
            case 'absent':  $absent[]  = $entry; break;
            case 'late':    $late[]    = $entry; break;
            default:        $unmarked[] = $entry; break;
        }

        /* Capture first available marked_at + teacher name */
        if ($markedAt === null && !empty($row['marked_at'])) {
            $markedAt     = $row['marked_at'];
            $markedByName = !empty($row['marked_by_name']) ? $row['marked_by_name'] : null;
        }
    }

    $total       = count($rows);
    $markedCount = count($present) + count($absent) + count($late);
    $attRate     = $total > 0
        ? round((count($present) + count($late)) / $total * 100, 1)
        : 0;

    ob_end_clean();
    successResponse([
        'date'           => $date,
        'class_name'     => $classRow ? $classRow['class_name'] : '',
        'has_records'    => $markedCount > 0,
        'total'          => $total,
        'marked_count'   => $markedCount,
        'present'        => $present,
        'absent'         => $absent,
        'late'           => $late,
        'unmarked'       => $unmarked,
        'att_rate'       => $attRate,
        'marked_at'      => $markedAt,
        'marked_by_name' => $markedByName,
    ]);
}

/* ═══════════════════════════════════════════════════════════════════════════
   GET BLOCKED DATES
═══════════════════════════════════════════════════════════════════════════ */
function getBlockedDates($db) {
    $year     = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
    $nextYear = $year + 1;
    $blocked  = [];

    $attempts = [
        ['sql' => "SELECT event_date AS d, NULL AS end_d FROM school_calendar
                   WHERE (is_holiday = 1 OR event_type IN ('holiday','break','vacation','closed'))
                     AND YEAR(event_date) IN (:y, :y2)",
         'params' => [':y' => $year, ':y2' => $nextYear]],
        ['sql' => "SELECT start_date AS d, end_date AS end_d FROM school_calendar
                   WHERE (is_holiday = 1 OR event_type IN ('holiday','break','vacation','closed'))
                     AND YEAR(start_date) IN (:y, :y2)",
         'params' => [':y' => $year, ':y2' => $nextYear]],
        ['sql' => "SELECT holiday_date AS d, NULL AS end_d FROM holidays
                   WHERE YEAR(holiday_date) IN (:y, :y2)",
         'params' => [':y' => $year, ':y2' => $nextYear]],
        ['sql' => "SELECT event_date AS d, NULL AS end_d FROM calendar_events
                   WHERE event_type IN ('holiday','break','vacation')
                     AND YEAR(event_date) IN (:y, :y2)",
         'params' => [':y' => $year, ':y2' => $nextYear]],
    ];

    foreach ($attempts as $attempt) {
        try {
            $rows = $db->query($attempt['sql'], $attempt['params']) ?: [];
            foreach ($rows as $row) {
                if (empty($row['d'])) continue;
                if (!empty($row['end_d']) && $row['end_d'] > $row['d']) {
                    try {
                        $cur = new DateTime($row['d']); $end = new DateTime($row['end_d']);
                        while ($cur <= $end) { $blocked[] = $cur->format('Y-m-d'); $cur->modify('+1 day'); }
                    } catch (Exception $ex) { $blocked[] = $row['d']; }
                } else {
                    $blocked[] = $row['d'];
                }
            }
        } catch (Exception $e) {}
    }

    ob_end_clean();
    successResponse(['blocked_dates' => array_values(array_unique($blocked))]);
}

/* ═══════════════════════════════════════════════════════════════════════════
   SAVE ATTENDANCE
═══════════════════════════════════════════════════════════════════════════ */
function saveAttendance($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }

    $classId = resolveClassId($db);
    if (!$classId) { ob_end_clean(); errorResponse('No class is assigned to this teacher account.'); }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) { ob_end_clean(); errorResponse('Invalid JSON body'); }

    $date    = isset($data['date'])    ? trim($data['date']) : date('Y-m-d');
    $records = isset($data['records']) ? $data['records']   : [];

    $check = validateAttendanceDate($date);
    if (!$check['ok']) { ob_end_clean(); errorResponse($check['reason']); }

    if (empty($records) || !is_array($records)) { ob_end_clean(); errorResponse('No attendance records provided.'); }

    $validStatuses = ['present', 'absent', 'late'];
    $userId        = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
    $saved         = 0;
    $warnings      = [];

    $classRow  = $db->queryOne("SELECT class_name FROM classes WHERE id = :id", [':id' => $classId]);
    $className = $classRow ? $classRow['class_name'] : 'their class';

    foreach ($records as $rec) {
        $studentId   = isset($rec['student_id'])  ? (int)$rec['student_id']  : 0;
        $status      = isset($rec['status'])       ? trim($rec['status'])     : '';
        $lateMinutes = ($status === 'late' && isset($rec['late_minutes']) && $rec['late_minutes'] !== null && $rec['late_minutes'] !== '')
                       ? max(0, (int)$rec['late_minutes']) : null;

        if (!$studentId)                              { $warnings[] = 'Skipped: missing student_id'; continue; }
        if (!in_array($status, $validStatuses, true)) { $warnings[] = 'Skipped student '.$studentId.': invalid status'; continue; }

        // Only email parents the first time a student flips to absent for this
        // date, not on every re-save of an already-absent record.
        $wasAlreadyAbsent = $db->queryOne(
            "SELECT status FROM attendance WHERE student_id = :sid AND attendance_date = :adate",
            [':sid' => $studentId, ':adate' => $date]
        );
        $shouldNotify = ($status === 'absent') && (!$wasAlreadyAbsent || $wasAlreadyAbsent['status'] !== 'absent');

        $db->execute(
            "INSERT INTO attendance (student_id, attendance_date, status, late_minutes, marked_by, marked_at)
             VALUES (:sid, :adate, :st, :lm, :by, NOW())
             ON DUPLICATE KEY UPDATE
                 status       = VALUES(status),
                 late_minutes = VALUES(late_minutes),
                 marked_by    = VALUES(marked_by),
                 marked_at    = NOW()",
            [':sid' => $studentId, ':adate' => $date, ':st' => $status, ':lm' => $lateMinutes, ':by' => $userId]
        );
        $saved++;

        if ($shouldNotify) {
            notifyParentsOfAbsence($db, $studentId, $className, $date);
        }
    }

    $response = ['saved' => $saved, 'date' => $date];
    if (!empty($warnings)) $response['warnings'] = $warnings;

    ob_end_clean();
    if (class_exists('SyncHooks') && !empty($records)) {
        foreach ($records as $rec) {
            $sid = isset($rec['student_id']) ? (int)$rec['student_id'] : 0;
            if ($sid < 1) continue;
            $row = $db->queryOne(
                "SELECT id FROM attendance WHERE student_id = ? AND attendance_date = ? ORDER BY id DESC LIMIT 1",
                array($sid, $date)
            );
            if ($row) {
                SyncHooks::afterWrite($db, 'attendance', (int)$row['id'], 'UPDATE', array(
                    'student_id' => $sid,
                    'class_id' => $classId,
                    'attendance_date' => $date,
                    'status' => isset($rec['status']) ? $rec['status'] : null,
                    'recorded_by' => $userId,
                ));
            }
        }
    }
    successResponse($response, 'Attendance saved successfully');
}

/**
 * Email every parent/guardian linked to a student the moment that student
 * is first marked absent for a given date. Failure to send never blocks the
 * attendance save itself — this runs after the DB write already succeeded.
 */
function notifyParentsOfAbsence($db, $studentId, $className, $date) {
    try {
        $student = $db->queryOne("SELECT student_name FROM students WHERE id = :id", [':id' => $studentId]);
        if (!$student) return;

        $guardians = $db->query(
            "SELECT u.id AS user_id, u.email, u.full_name
               FROM parents p
               JOIN users u ON u.id = p.user_id
              WHERE p.student_id = :sid AND u.status = 'active'",
            [':sid' => $studentId]
        ) ?: [];

        $niceDate = date('l, j F Y', strtotime($date));
        $sName = $student['student_name'];
        foreach ($guardians as $g) {
            // In-app notification (bell)
            try {
                $db->execute(
                    "INSERT INTO notifications (user_id, title, message, type, reference_key, is_read, created_at)
                     VALUES (:uid, :title, :msg, 'attendance', :ref, 0, NOW())",
                    [
                        ':uid'   => (int)$g['user_id'],
                        ':title' => 'Absent today: ' . $sName,
                        ':msg'   => $sName . ' (' . $className . ') was marked absent on ' . $niceDate . '.',
                        ':ref'   => 'absent_' . $studentId . '_' . $date,
                    ]
                );
            } catch (Exception $ie) {
                error_log('absence notification insert: ' . $ie->getMessage());
            }

            if (empty($g['email'])) continue;
            $subject = 'Attendance Notice: ' . $sName . ' marked absent today';
            $body =
                '<p>Dear ' . htmlspecialchars($g['full_name']) . ',</p>' .
                '<p><strong>' . htmlspecialchars($sName) . '</strong> (' . htmlspecialchars($className) . ') ' .
                'was marked <strong>absent</strong> on ' . $niceDate . '.</p>' .
                '<p>If this is unexpected, or your child is home for a reason the school should know, ' .
                'please contact the school office or message the class teacher through the parent portal.</p>' .
                '<p style="color:#888;font-size:12px;">This is an automated notice from the school attendance system.</p>';
            sendEmail($g['email'], $subject, $body);
        }
    } catch (Exception $e) {
        error_log('notifyParentsOfAbsence error: ' . $e->getMessage());
    }
}
