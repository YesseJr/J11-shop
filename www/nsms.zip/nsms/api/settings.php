<?php
/**
 * Settings Management API
 * Handles school settings, fee structure, classes, subjects,
 * and public landing-page content (gallery, regulations, calendar).
 */

ob_start();

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once __DIR__ . '/../includes/sync/OfflineData.php';
require_once __DIR__ . '/../includes/sync/OfflineAdmin.php';
require_once __DIR__ . '/../includes/sync/SyncHooks.php';

applyApiHeaders();

$db   = new Database();
$conn = $db->connect();

$action = isset($_GET['action']) ? $_GET['action'] : 'get';

if (!$conn) {
    ob_end_clean();
    $uid = function_exists('getCurrentUserId') ? getCurrentUserId() : (isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null);
    $method = $_SERVER['REQUEST_METHOD'];
    $isAdmin = isLoggedIn() && isset($_SESSION['role']) && strtolower($_SESSION['role']) === 'admin';
    try {
        // --- Classes ---
        if ($action === 'get_classes') {
            echo json_encode(array('success' => true, 'data' => OfflineAdmin::listClasses(), 'message' => 'Offline classes', 'offline_mode' => true));
            exit;
        }
        if ($action === 'add_class' && $method === 'POST') {
            if (!$isAdmin) { echo json_encode(array('success' => false, 'error' => 'Unauthorized')); exit; }
            $data = json_decode(file_get_contents('php://input'), true);
            if (!is_array($data)) $data = $_POST;
            $res = OfflineAdmin::createClass($data, $uid);
            echo json_encode(array('success' => true, 'message' => 'Class saved offline — will sync when online', 'data' => $res));
            exit;
        }
        if ($action === 'update_class' && in_array($method, array('PUT', 'POST'), true)) {
            if (!$isAdmin) { echo json_encode(array('success' => false, 'error' => 'Unauthorized')); exit; }
            $data = json_decode(file_get_contents('php://input'), true);
            if (!is_array($data)) $data = $_POST;
            $id = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
            $res = OfflineAdmin::updateClass($id, $data, $uid);
            echo json_encode(array('success' => true, 'message' => 'Class updated offline — will sync when online', 'data' => $res));
            exit;
        }
        if ($action === 'delete_class' && in_array($method, array('DELETE', 'POST', 'GET'), true)) {
            if (!$isAdmin) { echo json_encode(array('success' => false, 'error' => 'Unauthorized')); exit; }
            $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
            if (!$id) {
                $data = json_decode(file_get_contents('php://input'), true);
                if (is_array($data) && isset($data['id'])) $id = (int)$data['id'];
            }
            $res = OfflineAdmin::deleteClass($id, $uid);
            echo json_encode(array('success' => true, 'message' => 'Class deleted offline — will sync when online', 'data' => $res));
            exit;
        }

        // --- Subjects ---
        if ($action === 'get_subjects') {
            echo json_encode(array('success' => true, 'data' => OfflineAdmin::listSubjects(), 'message' => 'Offline subjects', 'offline_mode' => true));
            exit;
        }
        if ($action === 'add_subject' && $method === 'POST') {
            if (!$isAdmin) { echo json_encode(array('success' => false, 'error' => 'Unauthorized')); exit; }
            $data = json_decode(file_get_contents('php://input'), true);
            if (!is_array($data)) $data = $_POST;
            $res = OfflineAdmin::createSubject($data, $uid);
            echo json_encode(array('success' => true, 'message' => 'Subject saved offline — will sync when online', 'data' => $res));
            exit;
        }
        if ($action === 'update_subject' && in_array($method, array('PUT', 'POST'), true)) {
            if (!$isAdmin) { echo json_encode(array('success' => false, 'error' => 'Unauthorized')); exit; }
            $data = json_decode(file_get_contents('php://input'), true);
            if (!is_array($data)) $data = $_POST;
            $id = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
            $res = OfflineAdmin::updateSubject($id, $data, $uid);
            echo json_encode(array('success' => true, 'message' => 'Subject updated offline — will sync when online', 'data' => $res));
            exit;
        }
        if ($action === 'delete_subject' && in_array($method, array('DELETE', 'POST', 'GET'), true)) {
            if (!$isAdmin) { echo json_encode(array('success' => false, 'error' => 'Unauthorized')); exit; }
            $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
            if (!$id) {
                $data = json_decode(file_get_contents('php://input'), true);
                if (is_array($data) && isset($data['id'])) $id = (int)$data['id'];
            }
            $res = OfflineAdmin::deleteSubject($id, $uid);
            echo json_encode(array('success' => true, 'message' => 'Subject deleted offline — will sync when online', 'data' => $res));
            exit;
        }

        // --- School profile ---
        if (in_array($action, array('get', 'get_public', 'get_logo'), true)) {
            $settings = OfflineAdmin::getSchoolSettings();
            if ($action === 'get_logo') {
                $logo = '';
                if (!empty($settings['school_logo'])) $logo = $settings['school_logo'];
                elseif (!empty($settings['logo_url'])) $logo = $settings['logo_url'];
                // Normalize legacy path
                if (is_string($logo) && strpos($logo, '/nsms/uploads/logos/') === 0) {
                    $logo = str_replace('/nsms/uploads/logos/', '/nsms/public/uploads/logos/', $logo);
                }
                echo json_encode(array(
                    'success' => true,
                    'data' => array('url' => $logo, 'logo_url' => $logo),
                    'offline_mode' => true,
                    'read_only' => true
                ));
                exit;
            }
            echo json_encode(array('success' => true, 'data' => $settings, 'offline_mode' => true, 'message' => 'Offline settings'));
            exit;
        }
        if ($action === 'update' && $method === 'POST') {
            if (!$isAdmin) { echo json_encode(array('success' => false, 'error' => 'Unauthorized')); exit; }
            $data = json_decode(file_get_contents('php://input'), true);
            if (!is_array($data)) $data = $_POST;
            $res = OfflineAdmin::updateSchoolSettings($data, $uid);
            echo json_encode(array('success' => true, 'message' => 'Settings saved offline — will sync when online', 'data' => $res));
            exit;
        }

        // --- Fee structure ---
        if ($action === 'get_academic_schedule') {
            $settings = OfflineAdmin::getSchoolSettings();
            $keys = array(
                'acad_term1_start','acad_term1_end','acad_term1_exam_start','acad_term1_exam_end',
                'acad_term2_start','acad_term2_end','acad_term2_exam_start','acad_term2_exam_end',
                'acad_graduation_date'
            );
            $sched = array();
            foreach ($keys as $k) {
                $sched[$k] = isset($settings[$k]) ? $settings[$k] : '';
            }
            $sched['offline_mode'] = true;
            $sched['read_only'] = true;
            echo json_encode(array('success' => true, 'data' => $sched, 'offline_mode' => true, 'message' => 'Offline academic schedule (read-only)'));
            exit;
        }
        if ($action === 'get_gallery') {
            echo json_encode(array(
                'success' => true,
                'data' => OfflineAdmin::listGallery(),
                'offline_mode' => true,
                'read_only' => true,
                'message' => 'Offline gallery (read-only)'
            ));
            exit;
        }
        if ($action === 'get_calendar') {
            echo json_encode(array(
                'success' => true,
                'data' => OfflineAdmin::listCalendar(),
                'offline_mode' => true,
                'read_only' => true,
                'message' => 'Offline calendar (read-only)'
            ));
            exit;
        }
        if ($action === 'get_regulations') {
            echo json_encode(array(
                'success' => true,
                'data' => array(),
                'offline_mode' => true,
                'read_only' => true,
                'message' => 'Regulations available online'
            ));
            exit;
        }
        if ($action === 'fee_structure_all' || $action === 'fee_structure') {
            $res = OfflineAdmin::feeStructureAll();
            echo json_encode(array('success' => true, 'data' => $res, 'message' => 'Offline fee structure', 'offline_mode' => true));
            exit;
        }
        if ($action === 'save_fee_structure' && $method === 'POST') {
            if (!$isAdmin) { echo json_encode(array('success' => false, 'error' => 'Unauthorized')); exit; }
            $data = json_decode(file_get_contents('php://input'), true);
            if (!is_array($data)) $data = $_POST;
            $res = OfflineAdmin::saveFeeStructure($data, $uid);
            echo json_encode(array('success' => true, 'message' => 'Fee structure saved offline — will sync when online', 'data' => $res));
            exit;
        }

        echo json_encode(array(
            'success' => false,
            'error' => 'This settings action requires a connection (uploads, password change, gallery, email)',
            'offline' => true
        ));
    } catch (Exception $e) {
        echo json_encode(array('success' => false, 'error' => $e->getMessage(), 'offline' => true));
    }
    exit;
}


ensureClassSortOrder($db);

// Public endpoints (no auth required)
$publicActions = ['get_public', 'get_gallery', 'get_regulations', 'get_calendar', 'get_logo', 'get_academic_schedule', 'get_classes'];
// landing image upload is admin-only

if (!in_array($action, $publicActions)) {
    try {
        requireRole('admin');
    } catch (Exception $e) {
        ob_end_clean();
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }
}

ob_end_clean();

switch ($action) {

    // -- Settings ---------------------------------------------------------
    case 'get':
        getSettings($db);
        break;

    case 'get_public':
        getPublicSettings($db);
        break;

    case 'update':
        updateSettings($db);
        break;

    case 'change_password':
        changePassword($db);
        break;

    // -- Public landing-page content --------------------------------------
    case 'get_gallery':
        getGallery($db);
        break;

    case 'save_gallery':
        saveGallery($db);
        break;

    case 'upload_gallery_image':
        uploadGalleryImage($db);
        break;

    case 'delete_gallery_item':
        deleteGalleryItem($db);
        break;

    case 'get_regulations':
        getRegulations($db);
        break;

    case 'save_regulations':
        saveRegulations($db);
        break;

    case 'get_calendar':
        getCalendarEvents($db);
        break;

    case 'save_calendar':
        saveCalendarEvent($db);
        break;

    case 'delete_calendar':
        deleteCalendarEvent($db);
        break;

    case 'get_academic_schedule':
        getAcademicSchedule($db);
        break;

    case 'save_academic_schedule':
        saveAcademicSchedule($db);
        break;

    case 'delete_regulation':
        deleteRegulation($db);
        break;

    // -- Logo
    case 'get_logo':
        getLogo($db);
        break;

    case 'upload_landing_image':
        if (!function_exists('requireAdmin')) { /* auth already */ }
        if (function_exists('getCurrentUserRole') && getCurrentUserRole() !== 'admin') { http_response_code(403); echo json_encode(['success'=>false,'error'=>'Admin only']); exit; }
        uploadLandingImage($db);
        break;
    case 'clear_landing_image':
        if (function_exists('getCurrentUserRole') && getCurrentUserRole() !== 'admin') { http_response_code(403); echo json_encode(['success'=>false,'error'=>'Admin only']); exit; }
        clearLandingImage($db);
        break;
    case 'upload_logo':
        uploadLogo($db);
        break;

    case 'delete_logo':
        deleteLogo($db);
        break;

    // -- Fee Structure ----------------------------------------------------
    case 'fee_structure':
        getFeeStructure($db);
        break;

    case 'fee_structure_all':
        getFeeStructureAll($db);
        break;

    case 'save_fee_structure':
        saveFeeStructure($db);
        break;

    case 'fee_by_class':
        getFeeByClass($db);
        break;

    // -- Classes ----------------------------------------------------------
    case 'get_classes':
        getClasses($db);
        break;

    case 'add_class':
        addClass($db);
        break;

    case 'update_class':
        updateClass($db);
        break;

    case 'delete_class':
        deleteClass($db);
        break;

    // -- Subjects ---------------------------------------------------------
    case 'get_subjects':
        getSubjects($db);
        break;

    case 'add_subject':
        addSubject($db);
        break;

    case 'update_subject':
        updateSubject($db);
        break;

    case 'delete_subject':
        deleteSubject($db);
        break;

    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}

exit;

/* =====================================================================
   FEE STRUCTURE — CONSTANTS & SHARED HELPERS
   ===================================================================== */

define('INSTALLABLE_FEES',   ['School Fees', 'Transport']);
define('TOTAL_INSTALLMENTS', 10);

/**
 * Central JSON output — safe regardless of whether ob is open.
 */
function fs_json($payload) {
    if (ob_get_level() > 0) ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}
function fs_ok($data, $msg = 'OK') {
    fs_json(['success' => true, 'data' => $data, 'message' => $msg]);
}
function fs_fail($msg, $code = 400) {
    http_response_code($code);
    fs_json(['success' => false, 'error' => $msg]);
}
function fs_readJson() {
    $d = json_decode(file_get_contents('php://input'), true);
    return is_array($d) ? $d : [];
}

/**
 * Current academic year.
 * Priority: most-populated year in fee_structure -> school_settings -> fallback.
 */
function getAcademicYear($db) {
    $row = $db->queryOne(
        "SELECT academic_year, COUNT(*) AS cnt
           FROM fee_structure
          GROUP BY academic_year
          ORDER BY cnt DESC, academic_year DESC
          LIMIT 1"
    );
    if ($row && !empty($row['academic_year'])) return $row['academic_year'];

    $setting = $db->queryOne(
        "SELECT setting_value FROM school_settings WHERE setting_key='academic_year'"
    );
    if ($setting && !empty($setting['setting_value'])) return $setting['setting_value'];

    $y = (int)date('Y');
    return $y . '/' . ($y + 1);
}

/** "2025/2026" -> [2025, 2026]   "2025" -> [2025, 2026] */
function getAcademicYearRange($academicYear) {
    $parts = explode('/', $academicYear);
    $y1 = (int)$parts[0];
    $y2 = count($parts) > 1 ? (int)$parts[1] : $y1 + 1;
    return [$y1, $y2];
}

function getActiveDiscount($db, $studentId) {
    $row = $db->queryOne(
        "SELECT discount_percent FROM student_discounts
          WHERE student_id = :sid
            AND effective_from <= CURDATE()
            AND (effective_to IS NULL OR effective_to >= CURDATE())
          ORDER BY effective_from DESC LIMIT 1",
        [':sid' => $studentId]
    );
    return $row ? (float)$row['discount_percent'] : 0;
}

function applyDiscount($amount, $discountPct) {
    if ($discountPct <= 0) return $amount;
    return round($amount * (1 - $discountPct / 100), 2);
}

function ensureInstallments($db, $studentId, $classId, $academicYear) {
    $fees = $db->query(
        "SELECT fee_type, amount FROM fee_structure
          WHERE academic_year = :yr
            AND fee_type = 'School Fees'
            AND (class_id = :cid OR class_id IS NULL)
          ORDER BY class_id DESC LIMIT 1",
        [':yr' => $academicYear, ':cid' => $classId]
    ) ?: [];

    if (empty($fees)) return;
    $annualAmount      = (float)$fees[0]['amount'];
    $discount          = getActiveDiscount($db, $studentId);
    $base              = round($annualAmount / TOTAL_INSTALLMENTS, 2);
    $installmentAmount = applyDiscount($base, $discount);

    for ($i = 1; $i <= TOTAL_INSTALLMENTS; $i++) {
        $db->execute(
            "INSERT IGNORE INTO fee_installments
               (student_id, academic_year, fee_type, installment_no, amount_due)
             VALUES (:sid, :yr, 'School Fees', :no, :amt)",
            [':sid' => $studentId, ':yr' => $academicYear,
             ':no'  => $i,         ':amt' => $installmentAmount]
        );
    }
}

/* =====================================================================
   FEE STRUCTURE — READ
   ===================================================================== */

function getFeeStructure($db) {
    try {
        $yr        = getAcademicYear($db);
        $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;

        if ($studentId > 0) {
            $student = $db->queryOne(
                "SELECT class_id FROM students WHERE id=:id AND status='active'",
                [':id' => $studentId]
            );
            if (!$student) { fs_ok([]); return; }
            $classId = (int)$student['class_id'];

            $rows = $db->query(
                "SELECT fs.id, fs.fee_type, fs.amount, fs.currency,
                        fs.academic_year, fs.class_id, c.class_name
                   FROM fee_structure fs
                   LEFT JOIN classes c ON c.id = fs.class_id
                  WHERE fs.academic_year = :yr
                    AND (fs.class_id = :cid OR fs.class_id IS NULL)
                  ORDER BY fs.class_id IS NULL ASC, fs.fee_type ASC",
                [':yr' => $yr, ':cid' => $classId]
            );
            if (empty($rows)) {
                $rows = $db->query(
                    "SELECT fs.id, fs.fee_type, fs.amount, fs.currency,
                            fs.academic_year, fs.class_id, c.class_name
                       FROM fee_structure fs
                       LEFT JOIN classes c ON c.id = fs.class_id
                      WHERE fs.class_id = :cid OR fs.class_id IS NULL
                      ORDER BY fs.academic_year DESC LIMIT 20",
                    [':cid' => $classId]
                ) ?: [];
            }
        } else {
            $rows = $db->query(
                "SELECT fs.id, fs.fee_type, fs.amount, fs.currency,
                        fs.academic_year, fs.class_id, c.class_name
                   FROM fee_structure fs
                   LEFT JOIN classes c ON c.id = fs.class_id
                  WHERE fs.academic_year = :yr
                  ORDER BY COALESCE(c.sort_order,0) ASC, c.class_name ASC, fs.fee_type ASC",
                [':yr' => $yr]
            );
            if (empty($rows)) {
                $rows = $db->query(
                    "SELECT fs.id, fs.fee_type, fs.amount, fs.currency,
                            fs.academic_year, fs.class_id, c.class_name
                       FROM fee_structure fs
                       LEFT JOIN classes c ON c.id = fs.class_id
                      ORDER BY fs.academic_year DESC LIMIT 50"
                ) ?: [];
            }
        }

        foreach ($rows as &$r) {
            $r['amount']   = (float)$r['amount'];
            $r['class_id'] = $r['class_id'] !== null ? (int)$r['class_id'] : null;
        }
        unset($r);
        fs_ok($rows);

    } catch (Exception $e) {
        error_log('getFeeStructure error: ' . $e->getMessage());
        fs_fail('Failed to load fee structure: ' . $e->getMessage());
    }
}

function getFeeStructureAll($db) {
    try {
        $yr = getAcademicYear($db);

        // Query only guaranteed columns first; add class_color opportunistically.
        $classes = $db->query(
            "SELECT id, class_name FROM classes ORDER BY COALESCE(sort_order,0) ASC, class_name ASC"
        ) ?: [];

        try {
            $withColor = $db->query(
                "SELECT id, class_name, class_color FROM classes ORDER BY COALESCE(sort_order,0) ASC, class_name ASC"
            );
            if ($withColor) $classes = $withColor;
        } catch (Exception $e) {
            // class_color column does not exist in this schema — use without it
        }

        $fees = $db->query(
            "SELECT fs.id, fs.fee_type, fs.amount, fs.class_id, fs.academic_year
               FROM fee_structure fs
              WHERE fs.academic_year = :yr
              ORDER BY fs.class_id ASC, fs.fee_type ASC",
            [':yr' => $yr]
        ) ?: [];

        $feeMap = [];
        foreach ($fees as $f) {
            $key            = $f['class_id'] ?? 'school_wide';
            $feeMap[$key][] = [
                'id'       => (int)$f['id'],
                'fee_type' => $f['fee_type'],
                'amount'   => (float)$f['amount'],
            ];
        }

        fs_ok([
            'academic_year'         => $yr,
            'classes'               => $classes,
            'fee_map'               => $feeMap,
            'fee_types'             => getFeeTypesList($db, $yr),
            'installable'           => INSTALLABLE_FEES,
            'school_wide_fee_types' => ['Registration Fee', 'Stationery', 'Uniform', 'Meals', 'Transport'],
            'class_fee_types'       => ['School Fees'],
        ]);

    } catch (Exception $e) {
        error_log('getFeeStructureAll error: ' . $e->getMessage());
        fs_fail('Failed to load fee structure: ' . $e->getMessage());
    }
}

function getFeeTypesList($db, $year) {
    $rows = $db->query(
        "SELECT DISTINCT fee_type FROM fee_structure
          WHERE academic_year = :yr
          ORDER BY fee_type ASC",
        [':yr' => $year]
    ) ?: [];
    return array_column($rows, 'fee_type');
}

function getFeeByClass($db) {
    try {
        $yr = getAcademicYear($db);
        list($yr1, $yr2) = getAcademicYearRange($yr);

        // Base query without class_color
        $classes = $db->query(
            "SELECT c.id, c.class_name AS name,
                    COUNT(s.id) AS student_count
               FROM classes c
               LEFT JOIN students s ON s.class_id = c.id AND s.status = 'active'
              GROUP BY c.id, c.class_name
              ORDER BY COALESCE(c.sort_order,0) ASC, c.class_name ASC"
        ) ?: [];

        // Try to enrich with class_color if the column exists
        try {
            $withColor = $db->query(
                "SELECT c.id, c.class_name AS name, c.class_color,
                        COUNT(s.id) AS student_count
                   FROM classes c
                   LEFT JOIN students s ON s.class_id = c.id AND s.status = 'active'
                  GROUP BY c.id, c.class_name, c.class_color
                  ORDER BY COALESCE(c.sort_order,0) ASC, c.class_name ASC"
            );
            if ($withColor) $classes = $withColor;
        } catch (Exception $e) {
            // class_color does not exist — proceed without it
        }

        if (empty($classes)) { fs_ok([]); return; }

        $instRows = [];
        try {
            $instRows = $db->query(
                "SELECT s.class_id,
                        COALESCE(SUM(fi.amount_due),0)  AS inst_due,
                        COALESCE(SUM(fi.amount_paid),0) AS inst_paid
                   FROM fee_installments fi
                   JOIN students s ON s.id = fi.student_id
                  WHERE fi.academic_year = :yr AND fi.fee_type != 'Transport'
                  GROUP BY s.class_id",
                [':yr' => $yr]
            ) ?: [];
        } catch (Exception $e) {
            // fee_installments not yet created
        }

        $instMap = [];
        foreach ($instRows as $r) {
            $instMap[(int)$r['class_id']] = [
                'due'  => (float)$r['inst_due'],
                'paid' => (float)$r['inst_paid'],
            ];
        }

        $otRows = $db->query(
            "SELECT class_id, COALESCE(SUM(amount),0) AS total
               FROM fee_structure
              WHERE academic_year = :yr
                AND fee_type NOT IN ('School Fees','Transport')
              GROUP BY class_id",
            [':yr' => $yr]
        ) ?: [];
        $otSchoolWide = 0;
        $otPerClass   = [];
        foreach ($otRows as $r) {
            if ($r['class_id'] === null) $otSchoolWide = (float)$r['total'];
            else $otPerClass[(int)$r['class_id']] = (float)$r['total'];
        }

        $paidRows = $db->query(
            "SELECT s.class_id, COALESCE(SUM(fp.amount),0) AS paid
               FROM fee_payments fp
               JOIN students s ON s.id = fp.student_id
              WHERE YEAR(fp.payment_date) BETWEEN :yr1 AND :yr2
                AND fp.status = 'confirmed'
              GROUP BY s.class_id",
            [':yr1' => $yr1, ':yr2' => $yr2]
        ) ?: [];
        $paidMap = [];
        foreach ($paidRows as $r) {
            $paidMap[(int)$r['class_id']] = (float)$r['paid'];
        }

        $result = [];
        foreach ($classes as $c) {
            $cid       = (int)$c['id'];
            $cnt       = (int)$c['student_count'];
            $otExp     = ($otSchoolWide + ($otPerClass[$cid] ?? 0)) * $cnt;
            $instDue   = $instMap[$cid]['due'] ?? 0;
            $expected  = $otExp + $instDue;
            $collected = $paidMap[$cid] ?? 0;
            $rate      = $expected > 0 ? round($collected / $expected, 4) : 0;
            $entry = [
                'name'             => $c['name'],
                'class_id'         => $cid,
                'student_count'    => $cnt,
                'collected_amount' => $collected,
                'expected_amount'  => $expected,
                'collection_rate'  => $rate,
            ];
            if (isset($c['class_color'])) $entry['class_color'] = $c['class_color'];
            $result[] = $entry;
        }
        fs_ok($result);

    } catch (Exception $e) {
        error_log('getFeeByClass error: ' . $e->getMessage());
        fs_fail('Failed to load fee collection data: ' . $e->getMessage());
    }
}

/* =====================================================================
   FEE STRUCTURE — SAVE
   ===================================================================== */

function saveFeeStructure($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') fs_fail('Method not allowed', 405);
    $data = fs_readJson();
    if (!isset($data['fees']) || !is_array($data['fees'])) fs_fail('fees array required');

    $yr      = !empty($data['academic_year']) ? $data['academic_year'] : getAcademicYear($db);
    $classId = (isset($data['class_id']) && $data['class_id'] !== '' && $data['class_id'] !== null)
               ? (int)$data['class_id'] : null;

    try {
        if ($classId !== null) {
            $db->execute(
                "DELETE FROM fee_structure WHERE class_id = :cid AND academic_year = :yr",
                [':cid' => $classId, ':yr' => $yr]
            );
        } else {
            $db->execute(
                "DELETE FROM fee_structure WHERE class_id IS NULL AND academic_year = :yr",
                [':yr' => $yr]
            );
        }

        $n = 0;
        foreach ($data['fees'] as $fee) {
            // trim() is sufficient — PDO prepared statements handle SQL injection
            $ft  = isset($fee['fee_type']) ? trim($fee['fee_type']) : '';
            $amt = isset($fee['amount'])   ? (float)$fee['amount']  : 0;
            if ($ft === '' || $amt <= 0) continue;

            if ($classId !== null) {
                $db->execute(
                    "INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
                     VALUES (:cid, :ft, :amt, 'TSh', :yr)",
                    [':cid' => $classId, ':ft' => $ft, ':amt' => $amt, ':yr' => $yr]
                );
            } else {
                $db->execute(
                    "INSERT INTO fee_structure (class_id, fee_type, amount, currency, academic_year)
                     VALUES (NULL, :ft, :amt, 'TSh', :yr)",
                    [':ft' => $ft, ':amt' => $amt, ':yr' => $yr]
                );
            }
            $n++;
        }

        // Rebuild School Fees installments when a class fee changes
        if ($classId !== null) {
            $students = $db->query(
                "SELECT id FROM students WHERE class_id = :cid AND status = 'active'",
                [':cid' => $classId]
            ) ?: [];
            foreach ($students as $s) {
                try {
                    $db->execute(
                        "DELETE FROM fee_installments
                          WHERE student_id = :sid AND academic_year = :yr
                            AND fee_type = 'School Fees' AND status = 'unpaid'",
                        [':sid' => $s['id'], ':yr' => $yr]
                    );
                    ensureInstallments($db, (int)$s['id'], $classId, $yr);
                } catch (Exception $e) {
                    // fee_installments table may not exist yet — skip silently
                }
            }
        }

        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'UPDATE_FEE_STRUCTURE',
                'Updated ' . ($classId ? "class {$classId}" : 'school-wide') . ", {$n} fees");
        }

        fs_ok(['inserted' => $n], 'Fee structure saved');

    } catch (Exception $e) {
        error_log('saveFeeStructure error: ' . $e->getMessage());
        fs_fail('Failed to save fee structure: ' . $e->getMessage());
    }
}

/* =====================================================================
   SETTINGS
   ===================================================================== */

function getSettings($db) {
    try {
        $results = $db->query("SELECT setting_key, setting_value FROM school_settings");

        $settings = [
            'school_name'         => 'Nursery School',
            'school_address'      => '',
            'school_phone'        => '',
            'school_email'        => '',
            'email_notifications' => 'true',
            'sms_notifications'   => 'true',
            'school_logo'         => '',
            'school_mission'      => '',
            'school_vision'       => '',
            'established_year'    => '',
            'school_tagline'      => '',
            'principal_name'      => '',
        ];

        if ($results) {
            foreach ($results as $row) {
                $val = $row['setting_value'];
                if (is_string($val) && function_exists('decodeText')) {
                    $val = decodeText($val);
                }
                $settings[$row['setting_key']] = $val;
            }
        }

        echo json_encode(['success' => true, 'data' => $settings]);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

function getPublicSettings($db) {
    try {
        $rows = $db->query("SELECT setting_key, setting_value FROM school_settings") ?: [];
        $map  = [];
        foreach ($rows as $r) { $map[$r['setting_key']] = $r['setting_value']; }

        $pub = [
                'school_name'      => $map['school_name']      ?? 'Nursery School',
                'school_tagline'   => $map['school_tagline']   ?? 'Nursery School',
                'school_phone'     => $map['school_phone']     ?? '',
                'school_email'     => $map['school_email']     ?? '',
                'school_address'   => $map['school_address']   ?? '',
                'established_year' => $map['established_year'] ?? '',
                'principal_name'   => $map['principal_name']   ?? '',
                'reg_number'       => $map['reg_number']       ?? '',
                'school_logo'      => (function ($u) {
                    $u = trim((string) $u);
                    if ($u === '') return '';
                    // Legacy path without /public/
                    if (strpos($u, '/nsms/uploads/logos/') === 0) {
                        $u = str_replace('/nsms/uploads/logos/', '/nsms/public/uploads/logos/', $u);
                    }
                    return $u;
                })($map['school_logo'] ?? ''),
                'school_mission'   => $map['school_mission']   ?? '',
                'school_vision'    => $map['school_vision']    ?? '',
                'landing_hero_image'   => !empty($map['landing_hero_image']) ? $map['landing_hero_image'] : '/nsms/public/uploads/landing/hero-kids.jpg',
                'landing_campus_image' => !empty($map['landing_campus_image']) ? $map['landing_campus_image'] : '/nsms/public/uploads/landing/campus-hero.jpg',
                'stat_children'    => $map['stat_children']    ?? '250+',
                'stat_teachers'    => $map['stat_teachers']    ?? '25+',
                'stat_programs'    => $map['stat_programs']    ?? '12+',
                'stat_years'       => $map['stat_years']       ?? '',
            ];

        // Live counts from database (preferred over any hard-coded marketing numbers)
        try {
            $pub['students_count'] = (int) (($db->queryOne(
                "SELECT COUNT(*) AS c FROM students WHERE status = 'active'"
            ) ?: array('c' => 0))['c']);
        } catch (Exception $e) { $pub['students_count'] = 0; }
        try {
            $pub['teachers_count'] = (int) (($db->queryOne(
                "SELECT COUNT(*) AS c FROM users WHERE role = 'teacher' AND status = 'active'"
            ) ?: array('c' => 0))['c']);
        } catch (Exception $e) { $pub['teachers_count'] = 0; }
        try {
            $pub['parents_count'] = (int) (($db->queryOne(
                "SELECT COUNT(*) AS c FROM users WHERE role = 'parent' AND status = 'active'"
            ) ?: array('c' => 0))['c']);
        } catch (Exception $e) { $pub['parents_count'] = 0; }
        try {
            $pub['classes_count'] = (int) (($db->queryOne(
                "SELECT COUNT(*) AS c FROM classes"
            ) ?: array('c' => 0))['c']);
        } catch (Exception $e) {
            try {
                $pub['classes_count'] = (int) (($db->queryOne(
                    "SELECT COUNT(*) AS c FROM school_classes"
                ) ?: array('c' => 0))['c']);
            } catch (Exception $e2) { $pub['classes_count'] = 0; }
        }
        try {
            $pub['programs_count'] = (int) (($db->queryOne(
                "SELECT COUNT(DISTINCT class_name) AS c FROM classes"
            ) ?: array('c' => 0))['c']);
            if ($pub['programs_count'] <= 0) {
                $pub['programs_count'] = $pub['classes_count'];
            }
        } catch (Exception $e) {
            $pub['programs_count'] = $pub['classes_count'];
        }
        // Years of operation from established_year if set
        $years = 0;
        if (!empty($pub['established_year']) && ctype_digit((string) $pub['established_year'])) {
            $years = max(0, (int) date('Y') - (int) $pub['established_year']);
        }
        $pub['years_count'] = $years;

        // Public class list for Programs section on landing page
        try {
            $classRows = $db->query(
                "SELECT id, class_name, COALESCE(class_color, '') AS class_color, COALESCE(capacity, 0) AS capacity, COALESCE(sort_order, 0) AS sort_order
                 FROM classes
                 ORDER BY COALESCE(sort_order, 0) ASC, class_name ASC"
            );
            if (!$classRows) {
                $classRows = $db->query(
                    "SELECT id, class_name FROM classes ORDER BY class_name ASC"
                ) ?: array();
            }
            $pub['classes'] = array();
            foreach ($classRows as $cr) {
                $pub['classes'][] = array(
                    'id' => (int) ($cr['id'] ?? 0),
                    'name' => $cr['class_name'] ?? ($cr['name'] ?? ''),
                    'class_name' => $cr['class_name'] ?? ($cr['name'] ?? ''),
                    'color' => $cr['class_color'] ?? '',
                    'capacity' => isset($cr['capacity']) ? (int) $cr['capacity'] : null,
                );
            }
        } catch (Exception $e) {
            $pub['classes'] = array();
        }

        foreach ($pub as $k => $v) {
            if (is_string($v)) {
                $pub[$k] = decodeText($v);
            }
        }
        echo json_encode([
            'success' => true,
            'data'    => $pub,
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'success' => true,
            'data'    => ['school_name' => 'Nursery School'],
        ]);
    }
}

function updateSettings($db) {
    // Accept PUT or POST (some shared hosts / proxies block PUT)
    if (!in_array($_SERVER['REQUEST_METHOD'], ['PUT', 'POST'], true)) {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }

    $data = json_decode(file_get_contents('php://input'), true);

    if (!$data || !is_array($data)) {
        echo json_encode(['success' => false, 'error' => 'Invalid data format']); return;
    }

    try {
        $updated = 0;

        // Allow empty string values so fields like mission/vision can be cleared.
        // Skip only null (key present with no value) and non-scalar junk.
        $allowedKeys = null; // null = any key; restrict if needed later

        foreach ($data as $key => $value) {
            if ($value === null) continue;
            if (is_array($value) || is_object($value)) continue;

            $key   = trim((string)$key);
            if ($key === '') continue;
            $value = is_string($value) ? trim($value) : $value;
            // Cast booleans from JSON true/false toggles
            if (is_bool($value)) {
                $value = $value ? 'true' : 'false';
            }

            $result = $db->execute(
                "INSERT INTO school_settings (setting_key, setting_value, created_at, updated_at)
                 VALUES (:skey, :sval, NOW(), NOW())
                 ON DUPLICATE KEY UPDATE
                     setting_value = VALUES(setting_value),
                     updated_at    = NOW()",
                [':skey' => $key, ':sval' => (string)$value]
            );
            if ($result !== false) $updated++;
        }

        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'UPDATE_SETTINGS', "Updated {$updated} settings");
        }

        echo json_encode([
            'success' => true,
            'message' => 'Settings updated successfully',
            'data'    => ['updated_count' => $updated],
        ]);

    } catch (Exception $e) {
        error_log('Settings update error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to update settings']);
    }
}

function changePassword($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }

    $data = json_decode(file_get_contents('php://input'), true);

    // Require old_password — user must prove identity before changing
    if (!isset($data['old_password']) || !isset($data['new_password'])) {
        echo json_encode(['success' => false, 'error' => 'Current password and new password are required']); return;
    }

    $oldPassword = trim($data['old_password']);
    $newPassword = trim($data['new_password']);

    if (empty($oldPassword)) {
        echo json_encode(['success' => false, 'error' => 'Current password cannot be empty']); return;
    }
    if (strlen($newPassword) < 6) {
        echo json_encode(['success' => false, 'error' => 'New password must be at least 6 characters']); return;
    }

    try {
        $userId = getCurrentUserId();
        if (!$userId) {
            echo json_encode(['success' => false, 'error' => 'User not authenticated']); return;
        }

        // Verify the current password before allowing the change
        $user = $db->queryOne(
            "SELECT password_hash FROM users WHERE id = :id",
            [':id' => $userId]
        );

        if (!$user || !password_verify($oldPassword, $user['password_hash'])) {
            echo json_encode(['success' => false, 'error' => 'Current password is incorrect']); return;
        }

        $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

        $result = $db->execute(
            "UPDATE users SET password_hash = :password_hash WHERE id = :id",
            [':password_hash' => $newPasswordHash, ':id' => $userId]
        );

        if ($result !== false) {
            if (function_exists('logActivity')) {
                logActivity($db, $userId, 'CHANGE_PASSWORD', 'Changed password');
            }
            echo json_encode(['success' => true, 'message' => 'Password changed successfully']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to update password']);
        }

    } catch (Exception $e) {
        error_log('Password change error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to change password']);
    }
}

/* =====================================================================
   CLASSES
   ===================================================================== */

function getClasses($db) {
    try {
        if (function_exists('nsmsEnsureClassMinimumAgeColumn')) {
            nsmsEnsureClassMinimumAgeColumn($db);
        }
        $results = $db->query(
            "SELECT id, class_name, capacity, COALESCE(sort_order, 0) AS sort_order,
                    minimum_age
               FROM classes
              ORDER BY sort_order ASC, class_name ASC"
        );
        // Fallback if column still missing on very old DBs
        if ($results === false || $results === null) {
            $results = $db->query(
                "SELECT id, class_name, capacity, COALESCE(sort_order, 0) AS sort_order
                   FROM classes
                  ORDER BY sort_order ASC, class_name ASC"
            );
        }
        echo json_encode(['success' => true, 'data' => $results ?: []]);
    } catch (Exception $e) {
        error_log('Get classes error: ' . $e->getMessage());
        // Last-resort without minimum_age
        try {
            $results = $db->query(
                "SELECT id, class_name, capacity, COALESCE(sort_order, 0) AS sort_order
                   FROM classes ORDER BY sort_order ASC, class_name ASC"
            );
            echo json_encode(['success' => true, 'data' => $results ?: []]);
        } catch (Exception $e2) {
            echo json_encode(['success' => false, 'error' => 'Failed to fetch classes']);
        }
    }
}

function addClass($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data || empty(trim($data['class_name'] ?? ''))) {
        echo json_encode(['success' => false, 'error' => 'Class name is required']); return;
    }

    $className = trim($data['class_name']);
    $capacity  = isset($data['capacity'])   && $data['capacity']   !== '' ? (int)$data['capacity']   : null;
    $sortOrder = isset($data['sort_order']) && $data['sort_order'] !== '' ? (int)$data['sort_order'] : null;
    if (function_exists('nsmsEnsureClassMinimumAgeColumn')) {
        nsmsEnsureClassMinimumAgeColumn($db);
    }
    $minAgeVal = null;
    if (array_key_exists('minimum_age', $data) && $data['minimum_age'] !== '' && $data['minimum_age'] !== null) {
        $minCheck = function_exists('nsmsValidateMinimumAge')
            ? nsmsValidateMinimumAge($data['minimum_age'])
            : array('ok' => true, 'value' => (int)$data['minimum_age'], 'error' => null);
        if (empty($minCheck['ok'])) {
            echo json_encode(['success' => false, 'error' => $minCheck['error'] ?? 'Invalid minimum age']); return;
        }
        $minAgeVal = $minCheck['value'];
    }

    // Auto-assign sort_order as max+1 when not provided
    if ($sortOrder === null) {
        $maxRow    = $db->queryOne("SELECT COALESCE(MAX(sort_order), 0) AS mx FROM classes");
        $sortOrder = $maxRow ? ((int)$maxRow['mx'] + 1) : 1;
    }

    // Colour palette — cycles based on how many classes already exist
    $palette = ['#2563EB','#10B981','#8B5CF6','#F59E0B','#EF4444',
                '#06B6D4','#EC4899','#84CC16','#F97316','#6366F1'];

    try {
        $existing = $db->queryOne(
            "SELECT id FROM classes WHERE class_name = :cname LIMIT 1",
            [':cname' => $className]
        );
        if ($existing) {
            echo json_encode(['success' => false, 'error' => 'A class with this name already exists']); return;
        }

        $countRow   = $db->queryOne("SELECT COUNT(*) AS cnt FROM classes");
        $colorIndex = $countRow ? ((int)$countRow['cnt'] % count($palette)) : 0;
        $classColor = $palette[$colorIndex];

        $db->execute(
            "INSERT INTO classes (class_name, capacity, class_color, sort_order, minimum_age)
             VALUES (:cname, :cap, :col, :so, :mage)",
            [
                ':cname' => $className,
                ':cap'   => $capacity,
                ':col'   => $classColor,
                ':so'    => $sortOrder,
                ':mage'  => $minAgeVal,
            ]
        );

        $newClass = $db->queryOne(
            "SELECT id, class_name, capacity, sort_order, minimum_age FROM classes WHERE class_name = :cname ORDER BY id DESC LIMIT 1",
            [':cname' => $className]
        );
        if (!$newClass) {
            echo json_encode(['success' => false, 'error' => 'Class was not saved — check PHP error log']); return;
        }

        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'ADD_CLASS', "Added class: {$className}");
        }
        if (class_exists('SyncHooks') && !empty($newClass['id'])) {
            SyncHooks::afterWrite($db, 'classes', (int)$newClass['id'], 'CREATE', array(
                'class_name' => $className,
                'capacity' => $capacity,
            ));
        }
        echo json_encode(['success' => true, 'message' => 'Class added successfully', 'data' => $newClass]);

    } catch (Exception $e) {
        error_log('Add class error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to add class']);
    }
}

function updateClass($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data || empty(trim($data['class_name'] ?? '')) || empty($data['id'])) {
        echo json_encode(['success' => false, 'error' => 'Class ID and name are required']); return;
    }

    $id        = (int)$data['id'];
    $className = trim($data['class_name']);
    $capacity  = isset($data['capacity'])   && $data['capacity']   !== '' ? (int)$data['capacity']   : null;
    $sortOrder = isset($data['sort_order']) && $data['sort_order'] !== '' ? (int)$data['sort_order'] : null;
    if (function_exists('nsmsEnsureClassMinimumAgeColumn')) {
        nsmsEnsureClassMinimumAgeColumn($db);
    }
    $minAgeVal = null;
    $minAgeProvided = array_key_exists('minimum_age', $data);
    if ($minAgeProvided) {
        $minCheck = function_exists('nsmsValidateMinimumAge')
            ? nsmsValidateMinimumAge($data['minimum_age'])
            : array('ok' => true, 'value' => ($data['minimum_age'] === '' || $data['minimum_age'] === null) ? null : (int)$data['minimum_age'], 'error' => null);
        if (empty($minCheck['ok'])) {
            echo json_encode(['success' => false, 'error' => $minCheck['error'] ?? 'Invalid minimum age']); return;
        }
        $minAgeVal = $minCheck['value'];
    }

    try {
        $existing = $db->queryOne(
            "SELECT id FROM classes WHERE class_name = :cname AND id != :id LIMIT 1",
            [':cname' => $className, ':id' => $id]
        );
        if ($existing) {
            echo json_encode(['success' => false, 'error' => 'Another class with this name already exists']); return;
        }

        if ($minAgeProvided) {
            $result = $db->execute(
                "UPDATE classes SET class_name = :cname, capacity = :cap, sort_order = :so, minimum_age = :mage WHERE id = :id",
                [':cname' => $className, ':cap' => $capacity, ':so' => $sortOrder, ':mage' => $minAgeVal, ':id' => $id]
            );
        } else {
            $result = $db->execute(
                "UPDATE classes SET class_name = :cname, capacity = :cap, sort_order = :so WHERE id = :id",
                [':cname' => $className, ':cap' => $capacity, ':so' => $sortOrder, ':id' => $id]
            );
        }

        if ($result !== false) {
            $userId = getCurrentUserId();
            if ($userId && function_exists('logActivity')) {
                logActivity($db, $userId, 'UPDATE_CLASS', "Updated class ID {$id}: {$className}");
            }
            if (class_exists('SyncHooks')) {
                SyncHooks::afterWrite($db, 'classes', (int)$id, 'UPDATE', array(
                    'class_name' => $className,
                    'capacity' => $capacity,
                ));
            }
            echo json_encode(['success' => true, 'message' => 'Class updated successfully']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to update class']);
        }

    } catch (Exception $e) {
        error_log('Update class error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to update class']);
    }
}

function deleteClass($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }

    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) {
        echo json_encode(['success' => false, 'error' => 'Class ID is required']); return;
    }

    try {
        $enrolled = $db->queryOne(
            "SELECT COUNT(*) AS cnt FROM students WHERE class_id = :id",
            [':id' => $id]
        );
        if ($enrolled && (int)$enrolled['cnt'] > 0) {
            echo json_encode([
                'success' => false,
                'error'   => "Cannot delete: {$enrolled['cnt']} student(s) are enrolled in this class",
            ]); return;
        }

        $result = $db->execute("DELETE FROM classes WHERE id = :id", [':id' => $id]);

        if ($result !== false) {
            $userId = getCurrentUserId();
            if ($userId && function_exists('logActivity')) {
                logActivity($db, $userId, 'DELETE_CLASS', "Deleted class ID {$id}");
            }
            echo json_encode(['success' => true, 'message' => 'Class deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to delete class']);
        }

    } catch (Exception $e) {
        error_log('Delete class error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to delete class']);
    }
}

/* =====================================================================
   SUBJECTS
   ===================================================================== */

function getSubjects($db) {
    try {
        $results = $db->query(
            "SELECT id, subject_name FROM subjects ORDER BY subject_name ASC"
        );
        echo json_encode(['success' => true, 'data' => $results ?: []]);
    } catch (Exception $e) {
        error_log('Get subjects error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to fetch subjects']);
    }
}

function addSubject($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data || empty(trim($data['subject_name'] ?? ''))) {
        echo json_encode(['success' => false, 'error' => 'Subject name is required']); return;
    }

    $subjectName = trim($data['subject_name']);

    try {
        $existing = $db->queryOne(
            "SELECT id FROM subjects WHERE subject_name = :sname LIMIT 1",
            [':sname' => $subjectName]
        );
        if ($existing) {
            echo json_encode(['success' => false, 'error' => 'A subject with this name already exists']); return;
        }

        // Auto-generate a unique subject_code (e.g. "Mathematics" → "MAT", "MAT1" if taken)
        $baseCode = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $subjectName), 0, 3));
        if (strlen($baseCode) < 2) $baseCode = strtoupper(substr(md5($subjectName), 0, 3));
        $subjectCode = $baseCode;
        $suffix = 1;
        while ($db->queryOne("SELECT id FROM subjects WHERE subject_code = :sc LIMIT 1", [':sc' => $subjectCode])) {
            $subjectCode = $baseCode . $suffix++;
        }

        $db->execute(
            "INSERT INTO subjects (subject_name, subject_code) VALUES (:sname, :scode)",
            [':sname' => $subjectName, ':scode' => $subjectCode]
        );

        $newSubject = $db->queryOne(
            "SELECT id, subject_name FROM subjects WHERE subject_name = :sname ORDER BY id DESC LIMIT 1",
            [':sname' => $subjectName]
        );
        if (!$newSubject) {
            echo json_encode(['success' => false, 'error' => 'Subject was not saved — check PHP error log']); return;
        }

        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'ADD_SUBJECT', "Added subject: {$subjectName}");
        }
        echo json_encode(['success' => true, 'message' => 'Subject added successfully', 'data' => $newSubject]);

    } catch (Exception $e) {
        error_log('Add subject error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to add subject']);
    }
}

function updateSubject($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data || empty(trim($data['subject_name'] ?? '')) || empty($data['id'])) {
        echo json_encode(['success' => false, 'error' => 'Subject ID and name are required']); return;
    }

    $id          = (int)$data['id'];
    $subjectName = trim($data['subject_name']);

    try {
        $existing = $db->queryOne(
            "SELECT id FROM subjects WHERE subject_name = :sname AND id != :id LIMIT 1",
            [':sname' => $subjectName, ':id' => $id]
        );
        if ($existing) {
            echo json_encode(['success' => false, 'error' => 'Another subject with this name already exists']); return;
        }

        $result = $db->execute(
            "UPDATE subjects SET subject_name = :sname WHERE id = :id",
            [':sname' => $subjectName, ':id' => $id]
        );

        if ($result !== false) {
            $userId = getCurrentUserId();
            if ($userId && function_exists('logActivity')) {
                logActivity($db, $userId, 'UPDATE_SUBJECT', "Updated subject ID {$id}: {$subjectName}");
            }
            echo json_encode(['success' => true, 'message' => 'Subject updated successfully']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to update subject']);
        }

    } catch (Exception $e) {
        error_log('Update subject error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to update subject']);
    }
}

function deleteSubject($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }

    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) {
        echo json_encode(['success' => false, 'error' => 'Subject ID is required']); return;
    }

    try {
        // Don't delete if teachers are still assigned this subject
        try {
            $assigned = $db->queryOne(
                "SELECT COUNT(*) AS cnt FROM teacher_subjects WHERE subject_id = :id",
                [':id' => $id]
            );
            if ($assigned && (int)$assigned['cnt'] > 0) {
                echo json_encode([
                    'success' => false,
                    'error'   => "Cannot delete: {$assigned['cnt']} teacher(s) are assigned this subject",
                ]); return;
            }
        } catch (Exception $e) {
            // teacher_subjects may not exist yet — continue with delete
        }

        $result = $db->execute("DELETE FROM subjects WHERE id = :id", [':id' => $id]);

        if ($result !== false) {
            $userId = getCurrentUserId();
            if ($userId && function_exists('logActivity')) {
                logActivity($db, $userId, 'DELETE_SUBJECT', "Deleted subject ID {$id}");
            }
            echo json_encode(['success' => true, 'message' => 'Subject deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to delete subject']);
        }

    } catch (Exception $e) {
        error_log('Delete subject error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to delete subject']);
    }
}

/* =====================================================================
   GALLERY — public read + admin write
   Table: school_gallery (id, url, caption, date, sort_order, is_visible, created_at)
   ===================================================================== */

/**
 * Handle an admin's gallery image file upload.
 * Saves the file to publicuploads/gallery/ (same convention as
 * payment-gateway.php's proof uploads) and hands back a URL the frontend
 * drops straight into the gallery form's `url` field.
 */
function uploadGalleryImage($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }
    if (!isset($_FILES['image'])) {
        echo json_encode(['success' => false, 'error' => 'No image uploaded']); return;
    }

    $uploadDir = dirname(__DIR__) . '/publicuploads/gallery/';
    $up = nsmsStoreUpload(
        $_FILES['image'],
        $uploadDir,
        array('jpg', 'jpeg', 'png', 'gif', 'webp'),
        5 * 1024 * 1024,
        array('image/jpeg', 'image/png', 'image/gif', 'image/webp')
    );
    if (empty($up['ok'])) {
        echo json_encode(['success' => false, 'error' => isset($up['error']) ? $up['error'] : 'Upload failed']); return;
    }

    echo json_encode([
        'success' => true,
        'data'    => ['url' => '/nsms/publicuploads/gallery/' . $up['filename']],
        'message' => 'Image uploaded',
    ]);
}

/**
 * The school_gallery table isn't guaranteed to exist yet on every install
 * (it's missing from at least one deployment's schema). Create it on first
 * use instead of failing silently — same self-healing approach already
 * used elsewhere in this codebase (e.g. fee_installments).
 */
/**
 * The classes table's class-management and promotions code already
 * expects a sort_order column (defensively COALESCE'd for NULLs) — but
 * on at least one live install, the column itself was never actually
 * added, which throws (not just returns null) and breaks class listing
 * entirely. Self-heals it here, same pattern as the other tables in
 * this file, and backfills sensible values from each class's id the
 * first time it's added, so Baby/Middle/Top Class immediately have a
 * real 1/2/3 hierarchy instead of every class tying at 0.
 */
function ensureClassSortOrder($db) {
    try { $db->execute("ALTER TABLE classes ADD COLUMN sort_order INT NOT NULL DEFAULT 0"); } catch (Exception $e) { /* already exists */ }
    try {
        $anySet = $db->queryOne("SELECT COUNT(*) AS c FROM classes WHERE sort_order != 0");
        if ($anySet && (int)$anySet['c'] === 0) {
            $db->execute("UPDATE classes SET sort_order = id");
        }
    } catch (Exception $e) { /* non-fatal */ }
}

function ensureGalleryTable($db) {
    $db->execute(
        "CREATE TABLE IF NOT EXISTS school_gallery (
            id int UNSIGNED NOT NULL AUTO_INCREMENT,
            url text NOT NULL,
            caption varchar(255) NOT NULL DEFAULT '',
            date date DEFAULT NULL,
            sort_order smallint NOT NULL DEFAULT '0',
            is_visible tinyint(1) NOT NULL DEFAULT '1',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
}

function getGallery($db) {
    ensureGalleryTable($db);
    try {
        $isAdmin = function_exists('isLoggedIn') && isLoggedIn()
            && isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
        $sql = $isAdmin
            ? "SELECT id, url, caption, date, sort_order, is_visible
                 FROM school_gallery
                ORDER BY sort_order ASC, id DESC
                LIMIT 100"
            : "SELECT id, url, caption, date
                 FROM school_gallery
                WHERE is_visible = 1
                ORDER BY sort_order ASC, id DESC
                LIMIT 50";
        $rows = $db->query($sql);
        echo json_encode(['success' => true, 'data' => $rows ?: []]);
    } catch (Exception $e) {
        // Table may not exist yet — return empty gracefully
        echo json_encode(['success' => true, 'data' => []]);
    }
}

function saveGallery($db) {
    ensureGalleryTable($db);
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data || !is_array($data)) {
        echo json_encode(['success' => false, 'error' => 'Invalid data']); return;
    }

    try {
        $id        = isset($data['id']) && $data['id'] ? (int)$data['id'] : null;
        $url       = trim($data['url']     ?? '');
        $caption   = trim($data['caption'] ?? '');
        $date      = trim($data['date']    ?? date('Y-m-d'));
        $sortOrder = isset($data['sort_order']) ? (int)$data['sort_order'] : 0;
        $isVisible = isset($data['is_visible']) ? (int)(bool)$data['is_visible'] : 1;

        if ($url === '') {
            echo json_encode(['success' => false, 'error' => 'URL is required']); return;
        }

        if ($id) {
            $result = $db->execute(
                "UPDATE school_gallery
                    SET url=:url, caption=:cap, date=:dt, sort_order=:so, is_visible=:vis
                  WHERE id=:id",
                [':url'=>$url, ':cap'=>$caption, ':dt'=>$date,
                 ':so'=>$sortOrder, ':vis'=>$isVisible, ':id'=>$id]
            );
            // execute() returns false only on a real SQL error — rowCount of 0
            // (nothing actually changed) is not a failure, so only false counts.
            if ($result === false) {
                echo json_encode(['success' => false, 'error' => 'Failed to update gallery item']); return;
            }
            echo json_encode(['success' => true, 'message' => 'Gallery item updated']);
        } else {
            $newId = $db->execute(
                "INSERT INTO school_gallery (url, caption, date, sort_order, is_visible, created_at)
                 VALUES (:url, :cap, :dt, :so, :vis, NOW())",
                [':url'=>$url, ':cap'=>$caption, ':dt'=>$date,
                 ':so'=>$sortOrder, ':vis'=>$isVisible]
            );
            if ($newId === false) {
                echo json_encode(['success' => false, 'error' => 'Failed to save gallery item']); return;
            }
            $id = (int)$newId;
            echo json_encode(['success' => true, 'message' => 'Gallery item added']);
        }

        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'UPDATE_GALLERY',
                $id ? "Updated item {$id}" : "Added: {$caption}");
        }
    } catch (Exception $e) {
        error_log('saveGallery error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to save gallery item']);
    }
}

function deleteGalleryItem($db) {
    ensureGalleryTable($db);
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) { echo json_encode(['success' => false, 'error' => 'ID required']); return; }
    try {
        $db->execute("DELETE FROM school_gallery WHERE id = :id", [':id' => $id]);
        echo json_encode(['success' => true, 'message' => 'Gallery item deleted']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Failed to delete item']);
    }
}

/* =====================================================================
   REGULATIONS — public read + admin write
   Table: school_regulations (id, icon, title, text, sort_order, is_visible)
   ===================================================================== */


/* =====================================================================
   ENSURE landing-page content tables exist (missing from some dumps)
   ===================================================================== */

function ensureRegulationsTable($db) {
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS school_regulations (
                id          INT AUTO_INCREMENT PRIMARY KEY,
                icon        VARCHAR(16)  NOT NULL DEFAULT 'book',
                title       VARCHAR(255) NOT NULL,
                text        TEXT         NULL,
                sort_order  INT          NOT NULL DEFAULT 0,
                is_visible  TINYINT(1)   NOT NULL DEFAULT 1,
                created_at  DATETIME     NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME     NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) {
        error_log('ensureRegulationsTable: ' . $e->getMessage());
    }
}

function ensureCalendarTable($db) {
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS school_calendar (
                id          INT AUTO_INCREMENT PRIMARY KEY,
                icon        VARCHAR(16)  NOT NULL DEFAULT 'calendar',
                type        VARCHAR(32)  NOT NULL DEFAULT 'event',
                title       VARCHAR(255) NOT NULL,
                date        DATE         NOT NULL,
                `desc`      TEXT         NULL,
                is_visible  TINYINT(1)   NOT NULL DEFAULT 1,
                created_at  DATETIME     NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) {
        error_log('ensureCalendarTable: ' . $e->getMessage());
    }
}

function getRegulations($db) {
    ensureRegulationsTable($db);
    try {
        // Admin panel needs hidden rows; public landing only visible ones
        $isAdmin = function_exists('isLoggedIn') && isLoggedIn()
            && isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
        $sql = $isAdmin
            ? "SELECT id, icon, title, text, sort_order, is_visible
                 FROM school_regulations
                ORDER BY sort_order ASC, id ASC"
            : "SELECT id, icon, title, text
                 FROM school_regulations
                WHERE is_visible = 1
                ORDER BY sort_order ASC, id ASC";
        $rows = $db->query($sql) ?: [];
        foreach ($rows as &$r) {
            if (isset($r['title'])) $r['title'] = decodeText($r['title']);
            if (isset($r['text']))  $r['text']  = decodeText($r['text']);
        }
        unset($r);
        echo json_encode(['success' => true, 'data' => $rows]);
    } catch (Exception $e) {
        echo json_encode(['success' => true, 'data' => []]);
    }
}

function saveRegulations($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }
    ensureRegulationsTable($db);
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data || !is_array($data)) {
        echo json_encode(['success' => false, 'error' => 'Invalid data']); return;
    }

    try {
        if (isset($data['items']) && is_array($data['items'])) {
            // Full replace: wipe and re-insert all
            $db->execute("DELETE FROM school_regulations WHERE 1=1");
            $n = 0;
            foreach ($data['items'] as $i => $item) {
                $icon  = trim($item['icon']  ?? 'book');
                $title = trim($item['title'] ?? '');
                $text  = trim($item['text']  ?? '');
                if ($title === '') continue;
                $db->execute(
                    "INSERT INTO school_regulations (icon, title, text, sort_order, is_visible)
                     VALUES (:ico, :tit, :txt, :so, 1)",
                    [':ico'=>$icon, ':tit'=>$title, ':txt'=>$text, ':so'=>$i]
                );
                $n++;
            }
            echo json_encode(['success' => true, 'message' => "{$n} regulations saved"]);
        } else {
            // Single upsert
            $id    = isset($data['id']) && $data['id'] ? (int)$data['id'] : null;
            $icon  = trim($data['icon']  ?? '📌');
            $title = trim($data['title'] ?? '');
            $text  = trim($data['text']  ?? '');
            $so    = isset($data['sort_order']) ? (int)$data['sort_order'] : 0;
            $vis   = isset($data['is_visible']) ? (int)(bool)$data['is_visible'] : 1;
            if ($title === '') {
                echo json_encode(['success' => false, 'error' => 'Title required']); return;
            }
            if ($id) {
                $db->execute(
                    "UPDATE school_regulations
                        SET icon=:ico, title=:tit, text=:txt, sort_order=:so, is_visible=:vis
                      WHERE id=:id",
                    [':ico'=>$icon, ':tit'=>$title, ':txt'=>$text,
                     ':so'=>$so, ':vis'=>$vis, ':id'=>$id]
                );
            } else {
                $db->execute(
                    "INSERT INTO school_regulations (icon, title, text, sort_order, is_visible)
                     VALUES (:ico, :tit, :txt, :so, :vis)",
                    [':ico'=>$icon, ':tit'=>$title, ':txt'=>$text, ':so'=>$so, ':vis'=>$vis]
                );
            }
            echo json_encode(['success' => true, 'message' => 'Regulation saved']);
        }

        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'UPDATE_REGULATIONS', 'Updated school regulations');
        }
    } catch (Exception $e) {
        error_log('saveRegulations error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to save regulations: ' . $e->getMessage()]);
    }
}

/* =====================================================================
   ACADEMIC YEAR SCHEDULE
   Stores structured term/exam/graduation dates in school_settings.
   Keys: acad_term1_start, acad_term1_end, acad_term1_exam_start,
         acad_term1_exam_end, acad_term2_start, acad_term2_end,
         acad_term2_exam_start, acad_term2_exam_end, acad_graduation_date
   ===================================================================== */

function getAcademicSchedule($db) {
    $keys = [
        'acad_term1_start',      'acad_term1_end',
        'acad_term1_exam_start', 'acad_term1_exam_end',
        'acad_term2_start',      'acad_term2_end',
        'acad_term2_exam_start', 'acad_term2_exam_end',
        'acad_graduation_date'
    ];
    try {
        $placeholders = [];
        foreach ($keys as $k) { $placeholders[] = "'" . $k . "'"; }
        $inClause = implode(',', $placeholders);
        $rows = $db->query(
            "SELECT setting_key, setting_value FROM school_settings WHERE setting_key IN ($inClause)"
        );
        $data = array_fill_keys($keys, '');
        if ($rows) {
            foreach ($rows as $r) {
                if (isset($data[$r['setting_key']])) {
                    $data[$r['setting_key']] = $r['setting_value'] ?? '';
                }
            }
        }
        echo json_encode(['success' => true, 'data' => $data]);
    } catch (Exception $e) {
        error_log('getAcademicSchedule error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to load academic schedule']);
    }
}

function saveAcademicSchedule($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        echo json_encode(['success' => false, 'error' => 'Invalid data']); return;
    }
    $allowed = [
        'acad_term1_start',      'acad_term1_end',
        'acad_term1_exam_start', 'acad_term1_exam_end',
        'acad_term2_start',      'acad_term2_end',
        'acad_term2_exam_start', 'acad_term2_exam_end',
        'acad_graduation_date'
    ];
    try {
        foreach ($allowed as $key) {
            $val = isset($data[$key]) ? trim($data[$key]) : '';
            $db->execute(
                "INSERT INTO school_settings (setting_key, setting_value, created_at, updated_at)
                 VALUES (:k, :v, NOW(), NOW())
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()",
                [':k' => $key, ':v' => $val]
            );
        }
        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'UPDATE_ACADEMIC_SCHEDULE', 'Updated academic year schedule');
        }
        echo json_encode(['success' => true, 'message' => 'Academic schedule saved']);
    } catch (Exception $e) {
        error_log('saveAcademicSchedule error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to save academic schedule']);
    }
}

/* =====================================================================
   CALENDAR EVENTS — public read + admin write
   Table: school_calendar (id, icon, type, title, date, desc, is_visible, created_at)
   type: 'term' | 'holiday' | 'event' | 'exam'
   ===================================================================== */

function getCalendarEvents($db) {
    ensureCalendarTable($db);
    try {
        $isAdmin = function_exists('isLoggedIn') && isLoggedIn()
            && isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
        $sql = $isAdmin
            ? "SELECT id, icon, type, title, date, `desc`, is_visible
                 FROM school_calendar
                ORDER BY date ASC
                LIMIT 200"
            : "SELECT id, icon, type, title, date, `desc`
                 FROM school_calendar
                WHERE is_visible = 1
                ORDER BY date ASC
                LIMIT 100";
        $rows = $db->query($sql);
        if ($rows) {
            foreach ($rows as &$r) {
                $r['date'] = substr($r['date'], 0, 10);
                if (isset($r['title'])) $r['title'] = decodeText($r['title']);
                if (isset($r['desc']))  $r['desc']  = decodeText($r['desc']);
            }
            unset($r);
        }
        echo json_encode(['success' => true, 'data' => $rows ?: []]);
    } catch (Exception $e) {
        echo json_encode(['success' => true, 'data' => []]);
    }
}

function saveCalendarEvent($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }
    ensureCalendarTable($db);
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data || !is_array($data)) {
        echo json_encode(['success' => false, 'error' => 'Invalid data']); return;
    }
    if (!$data || !is_array($data)) {
        echo json_encode(['success' => false, 'error' => 'Invalid data']); return;
    }

    try {
        $id    = isset($data['id']) && $data['id'] ? (int)$data['id'] : null;
        $icon  = trim($data['icon']  ?? '📅');
        $type  = trim($data['type']  ?? 'event');
        $title = trim($data['title'] ?? '');
        $date  = trim($data['date']  ?? '');
        $desc  = trim($data['desc']  ?? '');
        $vis   = isset($data['is_visible']) ? (int)(bool)$data['is_visible'] : 1;

        $validTypes = ['term', 'holiday', 'event', 'exam'];
        if (!in_array($type, $validTypes, true)) $type = 'event';
        if ($title === '') { echo json_encode(['success' => false, 'error' => 'Title required']); return; }
        if ($date  === '') { echo json_encode(['success' => false, 'error' => 'Date required']);  return; }

        if ($id) {
            $db->execute(
                "UPDATE school_calendar
                    SET icon=:ico, type=:type, title=:tit, date=:dt, `desc`=:dsc, is_visible=:vis
                  WHERE id=:id",
                [':ico'=>$icon, ':type'=>$type, ':tit'=>$title,
                 ':dt'=>$date, ':dsc'=>$desc, ':vis'=>$vis, ':id'=>$id]
            );
            echo json_encode(['success' => true, 'message' => 'Calendar event updated']);
        } else {
            $db->execute(
                "INSERT INTO school_calendar (icon, type, title, date, `desc`, is_visible, created_at)
                 VALUES (:ico, :type, :tit, :dt, :dsc, :vis, NOW())",
                [':ico'=>$icon, ':type'=>$type, ':tit'=>$title,
                 ':dt'=>$date, ':dsc'=>$desc, ':vis'=>$vis]
            );
            echo json_encode(['success' => true, 'message' => 'Calendar event added']);
        }

        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'UPDATE_CALENDAR',
                ($id ? 'Updated' : 'Added') . ": {$title}");
        }
    } catch (Exception $e) {
        error_log('saveCalendarEvent error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to save calendar event: ' . $e->getMessage()]);
    }
}

function deleteCalendarEvent($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }
    ensureCalendarTable($db);
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) { echo json_encode(['success' => false, 'error' => 'ID required']); return; }
    try {
        $db->execute("DELETE FROM school_calendar WHERE id = :id", [':id' => $id]);
        echo json_encode(['success' => true, 'message' => 'Calendar event deleted']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Failed to delete event']);
    }
}

/* =====================================================================
   REGULATION — single delete
   ===================================================================== */

function deleteRegulation($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }
    ensureRegulationsTable($db);
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) { echo json_encode(['success' => false, 'error' => 'ID required']); return; }
    try {
        $db->execute("DELETE FROM school_regulations WHERE id = :id", [':id' => $id]);
        echo json_encode(['success' => true, 'message' => 'Regulation deleted']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Failed to delete regulation']);
    }
}

/* =====================================================================
   SCHOOL LOGO — upload, get, delete
   Table: school_settings key = 'school_logo'
   File saved to: /nsms/uploads/logos/
   ===================================================================== */

function getLogo($db) {
    try {
        $row = $db->queryOne(
            "SELECT setting_value FROM school_settings WHERE setting_key = 'school_logo'"
        );
        $url = $row ? trim((string)($row['setting_value'] ?? '')) : '';
        if ($url !== '' && strpos($url, '/nsms/uploads/logos/') === 0) {
            $url = str_replace('/nsms/uploads/logos/', '/nsms/public/uploads/logos/', $url);
        }
        echo json_encode([
            'success' => true,
            'data'    => ['url' => $url]
        ]);
    } catch (Exception $e) {
        echo json_encode(['success' => true, 'data' => ['url' => '']]);
    }
}

function uploadLogo($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }

    // Accept either a file upload or a raw URL in JSON body
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $file    = $_FILES['logo'];
        $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
        if (!in_array($file['type'], $allowed)) {
            echo json_encode(['success' => false, 'error' => 'Only image files are allowed (JPEG, PNG, GIF, WEBP, SVG)']); return;
        }
        if ($file['size'] > 5 * 1024 * 1024) {
            echo json_encode(['success' => false, 'error' => 'File too large. Maximum size is 5 MB']); return;
        }

        // Build upload directory relative to this file (api/settings.php → project root)
        $uploadDir = dirname(dirname(__FILE__)) . '/public/uploads/logos/';
        if (!is_dir($uploadDir)) {
            if (!mkdir($uploadDir, 0755, true)) {
                echo json_encode(['success' => false, 'error' => 'Could not create upload directory']); return;
            }
        }

        // Remove old logo file if stored locally
        try {
            $old = $db->queryOne(
                "SELECT setting_value FROM school_settings WHERE setting_key='school_logo'"
            );
            if ($old && !empty($old['setting_value'])) {
                $oldRelative = ltrim($old['setting_value'], '/');
                // Strip leading 'nsms/' prefix to get a doc-root-relative path
                $docRoot  = rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/');
                $oldAbs   = $docRoot . '/' . $oldRelative;
                if (file_exists($oldAbs)) @unlink($oldAbs);
            }
        } catch (Exception $ignored) {}

        $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $filename = 'school_logo_' . time() . '.' . $ext;
        $destPath = $uploadDir . $filename;

        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file']); return;
        }

        $logoUrl = '/nsms/public/uploads/logos/' . $filename;

    } else {
        // Fallback: JSON body with { url: "..." }
        $body = json_decode(file_get_contents('php://input'), true);
        if (empty($body['url'])) {
            echo json_encode(['success' => false, 'error' => 'No file uploaded and no URL provided']); return;
        }
        $logoUrl = trim($body['url']);
    }

    try {
        $db->execute(
            "INSERT INTO school_settings (setting_key, setting_value, created_at, updated_at)
             VALUES ('school_logo', :url, NOW(), NOW())
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()",
            [':url' => $logoUrl]
        );
        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'UPDATE_LOGO', 'Uploaded school logo');
        }
        echo json_encode(['success' => true, 'data' => ['url' => $logoUrl], 'message' => 'Logo saved']);
    } catch (Exception $e) {
        error_log('uploadLogo DB error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to save logo URL to database']);
    }
}

function deleteLogo($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
        echo json_encode(['success' => false, 'error' => 'Method not allowed']); return;
    }
    try {
        $old = $db->queryOne(
            "SELECT setting_value FROM school_settings WHERE setting_key='school_logo'"
        );
        if ($old && !empty($old['setting_value'])) {
            $oldRelative = ltrim($old['setting_value'], '/');
            $docRoot     = rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/');
            $oldAbs      = $docRoot . '/' . $oldRelative;
            if (file_exists($oldAbs)) @unlink($oldAbs);
        }
        $db->execute(
            "DELETE FROM school_settings WHERE setting_key = 'school_logo'"
        );
        $userId = getCurrentUserId();
        if ($userId && function_exists('logActivity')) {
            logActivity($db, $userId, 'DELETE_LOGO', 'Removed school logo');
        }
        echo json_encode(['success' => true, 'message' => 'Logo removed']);
    } catch (Exception $e) {
        error_log('deleteLogo error: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to delete logo']);
    }
}


function uploadLandingImage($db) {
    $slot = isset($_POST['slot']) ? trim($_POST['slot']) : 'hero';
    if (!in_array($slot, array('hero', 'campus'), true)) {
        echo json_encode(array('success' => false, 'error' => 'Invalid slot (hero|campus)'));
        return;
    }
    $key = $slot === 'campus' ? 'landing_campus_image' : 'landing_hero_image';
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(array('success' => false, 'error' => 'No image uploaded'));
        return;
    }
    $dir = dirname(__DIR__) . '/public/uploads/landing/';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $res = nsmsStoreUpload($_FILES['image'], $dir, array('jpg', 'jpeg', 'png', 'webp'), 5242880);
    if (empty($res['ok'])) {
        echo json_encode(array('success' => false, 'error' => $res['error'] ?? 'Upload failed'));
        return;
    }
    $url = '/nsms/public/uploads/landing/' . $res['filename'];
    try {
        $exists = $db->queryOne("SELECT setting_key FROM school_settings WHERE setting_key = :k", array(':k' => $key));
        if ($exists) {
            $db->execute("UPDATE school_settings SET setting_value = :v, updated_at = NOW() WHERE setting_key = :k", array(':v' => $url, ':k' => $key));
        } else {
            $db->execute("INSERT INTO school_settings (setting_key, setting_value, created_at, updated_at) VALUES (:k, :v, NOW(), NOW())", array(':k' => $key, ':v' => $url));
        }
    } catch (Exception $e) {
        echo json_encode(array('success' => false, 'error' => $e->getMessage()));
        return;
    }
    echo json_encode(array('success' => true, 'data' => array('url' => $url, 'slot' => $slot)));
}

function clearLandingImage($db) {
    $slot = isset($_POST['slot']) ? trim($_POST['slot']) : (isset($_GET['slot']) ? trim($_GET['slot']) : 'hero');
    $key = $slot === 'campus' ? 'landing_campus_image' : 'landing_hero_image';
    try {
        $db->execute("DELETE FROM school_settings WHERE setting_key = :k", array(':k' => $key));
    } catch (Exception $e) {}
    $default = $slot === 'campus'
        ? '/nsms/public/uploads/landing/campus-hero.jpg'
        : '/nsms/public/uploads/landing/hero-kids.jpg';
    echo json_encode(array('success' => true, 'data' => array('url' => $default, 'slot' => $slot)));
}

