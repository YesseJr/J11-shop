<?php

/**
====================================

	* Author: Waython Yesse
	* Address: waythonny@yahoo.com
	* Year: 2026
	
	====================================
 * Finance Management API  —  PHP 7.2+ / MySQL 5.7+
 *
 * Tables required (run finance_migration.sql):
 *   expenses, fee_installments, student_discounts
 *
 * Installable fee types: School Fees, Transport  (÷10 over 10 months)
 * One-time fee types:    everything else (Registration, Stationery, Meals…)
 *
 * Payment allocation order:
 *   1. Unpaid one-time fees
 *   2. School Fees installments (≥10% of one installment)
 *   3. Transport excluded from auto-allocation (optional)
 */

ob_start();

header('Content-Type: application/json');

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/helpers.php';
require_once '../includes/fee_ledger.php';
require_once __DIR__ . '/../includes/sync/OfflineData.php';
require_once __DIR__ . '/../includes/sync/OfflineAdmin.php';
    require_once __DIR__ . '/../includes/sync/SqliteStore.php';

applyApiHeaders();

requireRole('admin');

$db   = new Database();
$conn = $db->connect();
if (!$conn) {
    $action = isset($_GET['action']) ? $_GET['action'] : 'overview';
    $method = $_SERVER['REQUEST_METHOD'];
    require_once __DIR__ . '/../includes/sync/OfflineAdmin.php';
    require_once __DIR__ . '/../includes/sync/OfflineData.php';
    ob_end_clean();
    header('Content-Type: application/json');
    $uid = function_exists('getCurrentUserId') ? getCurrentUserId() : (isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null);
    $readBody = function () {
        if (!empty($_POST) && is_array($_POST)) return $_POST;
        $raw = file_get_contents('php://input');
        $j = $raw ? json_decode($raw, true) : null;
        return is_array($j) ? $j : array();
    };
    try {
        // ── Reads ──────────────────────────────────────────────
        if ($action === 'overview') {
            echo json_encode(array('success' => true, 'data' => OfflineAdmin::financeOverview(isset($_GET['month']) ? $_GET['month'] : null), 'message' => 'Offline finance', 'offline' => true));
            exit;
        }
        if ($action === 'fee_by_class') {
            echo json_encode(array('success' => true, 'data' => OfflineAdmin::feeByClass(), 'offline' => true));
            exit;
        }
        if (in_array($action, array('payments', 'payment_history', 'list_payments', 'transactions'), true)) {
            $rows = OfflineAdmin::listPayments();
            echo json_encode(array('success' => true, 'data' => $rows, 'message' => 'Offline payments', 'offline' => true));
            exit;
        }
        if ($action === 'expenses') {
            echo json_encode(array('success' => true, 'data' => OfflineAdmin::listExpenses(), 'offline' => true));
            exit;
        }
        if ($action === 'students_list') {
            $q = isset($_GET['q']) ? $_GET['q'] : '';
            echo json_encode(array('success' => true, 'data' => OfflineAdmin::studentsForPayment($q), 'offline' => true));
            exit;
        }
        if ($action === 'student_payment_status') {
            $sid = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
            if ($sid < 1) {
                echo json_encode(array('success' => false, 'error' => 'student_id required', 'offline' => true));
                exit;
            }
            try {
                $status = OfflineAdmin::studentPaymentStatus($sid);
                echo json_encode(array('success' => true, 'data' => $status, 'offline' => true));
            } catch (Exception $e) {
                echo json_encode(array('success' => false, 'error' => $e->getMessage(), 'offline' => true));
            }
            exit;
        }
        if ($action === 'fee_structure_all' || $action === 'fee_structure') {
            // Shape must match online getFeeStructureAll() for the React tab
            $classes = array();
            $feeMap = array('school_wide' => array());
            $yr = date('Y');
            try {
                require_once __DIR__ . '/../includes/sync/SyncConfig.php';
                require_once __DIR__ . '/../includes/sync/SqliteStore.php';
                $pdo = (new SqliteStore())->connect();
                OfflineAdmin::ensureFinanceTables($pdo);
                try {
                    $classes = $pdo->query(
                        "SELECT id, class_name, class_color FROM classes ORDER BY class_name ASC"
                    )->fetchAll(PDO::FETCH_ASSOC);
                } catch (Throwable $e) {
                    $classes = array();
                }
                try {
                    $rows = $pdo->query("SELECT * FROM fee_structure_cache")->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($rows as $f) {
                        $cid = isset($f['class_id']) && $f['class_id'] !== '' && $f['class_id'] !== null
                            ? (int)$f['class_id'] : null;
                        $key = $cid === null ? 'school_wide' : $cid;
                        if (!isset($feeMap[$key])) $feeMap[$key] = array();
                        $feeMap[$key][] = array(
                            'id' => isset($f['id']) ? (int)$f['id'] : 0,
                            'fee_type' => isset($f['fee_type']) ? $f['fee_type'] : '',
                            'amount' => isset($f['amount']) ? (float)$f['amount'] : 0,
                        );
                    }
                } catch (Throwable $e) {}
            } catch (Throwable $e) {}
            if (!isset($feeMap['school_wide'])) $feeMap['school_wide'] = array();
            echo json_encode(array(
                'success' => true,
                'offline' => true,
                'message' => 'Fee structure read-only offline',
                'data' => array(
                    'academic_year' => $yr,
                    'classes' => $classes,
                    'fee_map' => $feeMap,
                    'fee_types' => array(),
                    'installable' => array('School Fees', 'Transport'),
                    'school_wide_fee_types' => array('Registration Fee','Stationery','Uniform','Meals','Transport'),
                    'class_fee_types' => array('School Fees'),
                ),
            ));
            exit;
        }

        // ── Writes allowed offline ─────────────────────────────
        if (($action === 'record_payment' || $action === 'add_payment' || $action === 'cash_payment') && $method === 'POST') {
            $body = $readBody();
            $res = OfflineAdmin::recordCashPayment($body, $uid);
            echo json_encode(array('success' => true, 'data' => $res, 'message' => 'Payment saved offline — will sync when online', 'offline' => true));
            exit;
        }
        if ($action === 'record_expense' && $method === 'POST') {
            $body = $readBody();
            $res = OfflineAdmin::recordExpense($body, $uid);
            echo json_encode(array('success' => true, 'data' => $res, 'message' => 'Expense saved offline — will sync when online', 'offline' => true));
            exit;
        }

        // ── Explicitly blocked (need live MySQL) ───────────────
        $onlineOnly = array(
            'verify', 'verify_payment', 'payment_verification', 'approve_payment',
            'ledger_reconcile', 'ledger_promote', 'send_fee_reminders',
            'save_fee_structure', 'set_discount', 'remove_discount', 'save_scholarship',
            'assign_transport', 'remove_transport', 'export_report',
        );
        if (in_array($action, $onlineOnly, true) || strpos($action, 'verify') !== false) {
            echo json_encode(array(
                'success' => false,
                'error' => 'Payment verification and advanced finance tools need an online connection.',
                'offline' => true,
                'code' => 'online_required',
            ));
            exit;
        }

        echo json_encode(array(
            'success' => false,
            'error' => 'This finance action needs MySQL online: ' . $action,
            'offline' => true,
        ));
        exit;
    } catch (Exception $e) {
        echo json_encode(array('success' => false, 'error' => $e->getMessage(), 'offline' => true));
        exit;
    }
}

$action = isset($_GET['action']) ? $_GET['action'] : 'overview';

// Constants must be defined before the switch calls any function that uses them
define('INSTALLABLE_FEES', ['School Fees', 'Transport']);
define('TOTAL_INSTALLMENTS', 10);

try {
    switch ($action) {
        case 'overview':              getFinancialOverview($db);   break;
        case 'transactions':          getTransactions($db);        break;
        case 'expenses':              getExpenses($db);            break;
        case 'fee_structure':         getFeeStructure($db);        break;
        case 'fee_structure_all':     getFeeStructureAll($db);     break;
        case 'save_fee_structure':    saveFeeStructure($db);       break;
        case 'students_list':         getStudentsList($db);        break;
        case 'student_payment_status':studentPaymentStatus($db);   break;
        case 'record_payment':        recordPayment($db);           break;
        case 'record_expense':        recordExpense($db);           break;
        case 'assign_transport':      assignTransport($db);         break;
        case 'remove_transport':      removeTransport($db);         break;
        case 'set_discount':          setDiscount($db);             break;
        case 'remove_discount':       removeDiscount($db);          break;
        case 'get_discount':          getDiscount($db);             break;
        case 'get_all_discounts':     getAllDiscounts($db);          break;
        case 'fee_by_class':          getFeeByClass($db);           break;
        case 'get_scholarships':      getScholarships($db);         break;
        case 'save_scholarship':      saveScholarship($db);         break;
        case 'export_report':         exportReport($db);            break;
        case 'get_payment_receipt':   getPaymentReceipt($db);       break;
        case 'send_fee_reminders':    sendFeeReminders($db);        break;
        case 'ledger_reconcile':      ledgerReconcile($db);         break;
        case 'ledger_promote':        ledgerPromote($db);           break;
        default: ob_end_clean(); echo json_encode(['success'=>false,'error'=>'Invalid action']); exit;
    }
} catch (Throwable $e) {
    ob_end_clean();
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
    exit;
}
ob_end_flush();

function getAcademicYear($db) {
    $row = $db->queryOne(
        "SELECT academic_year, COUNT(*) AS cnt
           FROM fee_structure
          GROUP BY academic_year
          ORDER BY cnt DESC, academic_year DESC
          LIMIT 1"
    );
    if ($row && !empty($row['academic_year'])) return $row['academic_year'];

    $setting = $db->queryOne(
        "SELECT setting_value FROM school_settings WHERE setting_key='academic_year'"
    );
    if ($setting && !empty($setting['setting_value'])) return $setting['setting_value'];

    $y = (int)date('Y');
    return $y . '/' . ($y + 1);
}

function getAcademicYearRange($academicYear) {
    $parts = explode('/', $academicYear);
    $y1 = (int)$parts[0];
    $y2 = count($parts) > 1 ? (int)$parts[1] : $y1 + 1;
    return [$y1, $y2];
}

function makeReceiptNumber() {
    return 'REC-' . date('Ymd') . '-' . strtoupper(substr(uniqid('',true), -6));
}
function readJson() {
    $d = json_decode(file_get_contents('php://input'), true);
    return is_array($d) ? $d : [];
}
function ok($data, $msg = 'OK') {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success'=>true,'data'=>$data,'message'=>$msg]);
    exit;
}
function fail($msg, $code = 400) {
    ob_end_clean();
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success'=>false,'error'=>$msg]);
    exit;
}

function cleanStr($v) {
    return htmlspecialchars_decode(strip_tags(trim((string)$v)), ENT_QUOTES);
}

function getActiveDiscount($db, $studentId) {
    $row = $db->queryOne(
        "SELECT discount_percent FROM student_discounts
          WHERE student_id = :sid
            AND effective_from <= CURDATE()
            AND (effective_to IS NULL OR effective_to >= CURDATE())
          ORDER BY effective_from DESC LIMIT 1",
        [':sid' => $studentId]
    );
    return $row ? (float)$row['discount_percent'] : 0;
}

function applyDiscount($amount, $discountPct) {
    if ($discountPct <= 0) return $amount;
    return round($amount * (1 - $discountPct / 100), 2);
}

function ensureInstallments($db, $studentId, $classId, $academicYear) {
    $fees = $db->query(
        "SELECT fee_type, amount FROM fee_structure
          WHERE academic_year = :yr
            AND fee_type = 'School Fees'
            AND (class_id = :cid OR class_id IS NULL)
          ORDER BY class_id DESC LIMIT 1",
        [':yr' => $academicYear, ':cid' => $classId]
    ) ?: [];

    if (empty($fees)) return;
    $annualAmount = (float)$fees[0]['amount'];
    $discount = getActiveDiscount($db, $studentId);
    $base = round($annualAmount / TOTAL_INSTALLMENTS, 2);
    $installmentAmount = applyDiscount($base, $discount);

    for ($i = 1; $i <= TOTAL_INSTALLMENTS; $i++) {
        $db->execute(
            "INSERT IGNORE INTO fee_installments
               (student_id, academic_year, fee_type, installment_no, amount_due)
             VALUES (:sid, :yr, 'School Fees', :no, :amt)",
            [':sid'=>$studentId, ':yr'=>$academicYear,
             ':no'=>$i, ':amt'=>$installmentAmount]
        );
    }
}

function ensureTransportInstallments($db, $studentId, $classId, $academicYear) {
    $fee = $db->queryOne(
        "SELECT amount FROM fee_structure
          WHERE academic_year = :yr AND fee_type = 'Transport'
            AND (class_id = :cid OR class_id IS NULL)
          ORDER BY class_id DESC LIMIT 1",
        [':yr' => $academicYear, ':cid' => $classId]
    );
    if (!$fee) return;
    $base = round((float)$fee['amount'] / TOTAL_INSTALLMENTS, 2);
    for ($i = 1; $i <= TOTAL_INSTALLMENTS; $i++) {
        $db->execute(
            "INSERT IGNORE INTO fee_installments
               (student_id, academic_year, fee_type, installment_no, amount_due)
             VALUES (:sid, :yr, 'Transport', :no, :amt)",
            [':sid'=>$studentId, ':yr'=>$academicYear, ':no'=>$i, ':amt'=>$base]
        );
    }
}


/**
 * Keep fee_installments in sync with confirmed fee_payments totals.
 * Payments recorded offline/gateway may land in fee_payments without updating installments,
 * which leaves the UI showing e.g. 2/10 while balance appears settled.
 */
function reconcileInstallmentsFromPayments($db, $studentId, $classId, $academicYear, $totalPaid, $oneTimeTotal) {
    $studentId = (int)$studentId;
    $available = max(0.0, round((float)$totalPaid - (float)$oneTimeTotal, 2));

    // School Fees installments (ordered)
    $rows = $db->query(
        "SELECT id, installment_no, amount_due, amount_paid, status
           FROM fee_installments
          WHERE student_id = :sid AND academic_year = :yr AND fee_type = 'School Fees'
          ORDER BY installment_no ASC",
        [':sid' => $studentId, ':yr' => $academicYear]
    ) ?: [];

    $remaining = $available;
    foreach ($rows as $r) {
        $due = round((float)$r['amount_due'], 2);
        if ($due <= 0) continue;
        $pay = min($due, $remaining);
        $pay = round($pay, 2);
        $status = 'unpaid';
        if ($pay >= $due - 0.009) {
            $pay = $due;
            $status = 'paid';
        } elseif ($pay > 0) {
            $status = 'partial';
        }
        $remaining = round(max(0, $remaining - $pay), 2);
        // Only write when changed to avoid noise
        if (abs((float)$r['amount_paid'] - $pay) > 0.009 || $r['status'] !== $status) {
            $db->execute(
                "UPDATE fee_installments
                    SET amount_paid = :paid,
                        status = :st,
                        paid_date = IF(:st2 = 'paid', COALESCE(paid_date, CURDATE()), paid_date),
                        updated_at = NOW()
                  WHERE id = :id",
                [
                    ':paid' => $pay,
                    ':st' => $status,
                    ':st2' => $status,
                    ':id' => (int)$r['id'],
                ]
            );
        }
    }

    // Transport if assigned — allocate leftover after school fees
    $transportAssigned = $db->queryOne(
        "SELECT id FROM student_transport
          WHERE student_id = :sid AND academic_year = :yr AND status = 'active' LIMIT 1",
        [':sid' => $studentId, ':yr' => $academicYear]
    );
    if ($transportAssigned && $remaining > 0) {
        $trows = $db->query(
            "SELECT id, amount_due, amount_paid, status
               FROM fee_installments
              WHERE student_id = :sid AND academic_year = :yr AND fee_type = 'Transport'
              ORDER BY installment_no ASC",
            [':sid' => $studentId, ':yr' => $academicYear]
        ) ?: [];
        foreach ($trows as $r) {
            $due = round((float)$r['amount_due'], 2);
            if ($due <= 0) continue;
            $pay = min($due, $remaining);
            $pay = round($pay, 2);
            $status = 'unpaid';
            if ($pay >= $due - 0.009) {
                $pay = $due;
                $status = 'paid';
            } elseif ($pay > 0) {
                $status = 'partial';
            }
            $remaining = round(max(0, $remaining - $pay), 2);
            if (abs((float)$r['amount_paid'] - $pay) > 0.009 || $r['status'] !== $status) {
                $db->execute(
                    "UPDATE fee_installments
                        SET amount_paid = :paid, status = :st,
                            paid_date = IF(:st2 = 'paid', COALESCE(paid_date, CURDATE()), paid_date),
                            updated_at = NOW()
                      WHERE id = :id",
                    [':paid' => $pay, ':st' => $status, ':st2' => $status, ':id' => (int)$r['id']]
                );
            }
        }
    }
}

function buildPaymentStatus($db, $studentId, $classId, $academicYear) {
    $discount = getActiveDiscount($db, $studentId);

    $feeRows = $db->query(
        "SELECT fs.fee_type, fs.amount, fs.class_id
           FROM fee_structure fs
          WHERE fs.academic_year = :yr
            AND fs.fee_type NOT IN ('School Fees','Transport')
            AND (fs.class_id = :cid OR fs.class_id IS NULL)
          ORDER BY fs.class_id DESC",
        [':yr' => $academicYear, ':cid' => $classId]
    ) ?: [];

    $oneTimeMap = [];
    foreach ($feeRows as $f) {
        if (!isset($oneTimeMap[$f['fee_type']])) {
            $oneTimeMap[$f['fee_type']] = (float)$f['amount'];
        }
    }

    [$yrNum1, $yrNum2] = getAcademicYearRange($academicYear);
    $totalPaidRow = $db->queryOne(
        "SELECT COALESCE(SUM(amount),0) AS paid
           FROM fee_payments
          WHERE student_id = :sid
            AND YEAR(payment_date) BETWEEN :yr1 AND :yr2
            AND status = 'confirmed'",
        [':sid' => $studentId, ':yr1' => $yrNum1, ':yr2' => $yrNum2]
    );
    $totalPaid = (float)($totalPaidRow['paid'] ?? 0);

    ensureInstallments($db, $studentId, $classId, $academicYear);

    // Apply discount to one-time map totals for allocation base
    $oneTimeTotalForRecon = 0.0;
    foreach ($oneTimeMap as $ft => $amt) {
        $oneTimeTotalForRecon += (float)$amt;
    }
    if ($discount > 0) {
        $oneTimeTotalForRecon = round($oneTimeTotalForRecon * (1 - $discount / 100), 2);
    }
    try {
        reconcileInstallmentsFromPayments($db, $studentId, $classId, $academicYear, $totalPaid, $oneTimeTotalForRecon);
    } catch (Throwable $e) {
        error_log('reconcileInstallmentsFromPayments: ' . $e->getMessage());
    }

    $transportAssigned = false;
    try {
        $transportAssigned = $db->queryOne(
            "SELECT id FROM student_transport
              WHERE student_id = :sid AND academic_year = :yr AND status = 'active'",
            [':sid' => $studentId, ':yr' => $academicYear]
        );
    } catch (Throwable $e) {
        $transportAssigned = false;
    }

    $installRows = $db->query(
        "SELECT fee_type, installment_no, amount_due, amount_paid, status, paid_date
           FROM fee_installments
          WHERE student_id = :sid AND academic_year = :yr
          ORDER BY fee_type ASC, installment_no ASC",
        [':sid' => $studentId, ':yr' => $academicYear]
    ) ?: [];

    $installments = [];
    foreach ($installRows as $r) {
        if ($r['fee_type'] === 'Transport' && !$transportAssigned) continue;
        $installments[$r['fee_type']][] = [
            'no'          => (int)$r['installment_no'],
            'amount_due'  => (float)$r['amount_due'],
            'amount_paid' => (float)$r['amount_paid'],
            'status'      => $r['status'],
            'paid_date'   => $r['paid_date'],
        ];
    }

    $oneTimeTotal = array_sum($oneTimeMap);
    $sfTotal = 0; $sfPaid = 0;
    $tpTotal = 0; $tpPaid = 0;
    foreach ($installments as $ft => $slots) {
        foreach ($slots as $s) {
            if ($ft === 'Transport') { $tpTotal += $s['amount_due']; $tpPaid += $s['amount_paid']; }
            else                     { $sfTotal += $s['amount_due']; $sfPaid += $s['amount_paid']; }
        }
    }

    $grandTotal = $oneTimeTotal + $sfTotal;

    $sfAllDone = true;
    if (isset($installments['School Fees'])) {
        foreach ($installments['School Fees'] as $s) {
            if ($s['amount_due'] > 0 && $s['status'] !== 'paid') { $sfAllDone = false; break; }
        }
    } else {
        $sfAllDone = false;
    }

    $oneTimeCovered   = ($totalPaid >= $oneTimeTotal);
    $mandatoryComplete = ($grandTotal > 0) && $oneTimeCovered && $sfAllDone;

    $tpAllDone = true;
    if ($transportAssigned && isset($installments['Transport'])) {
        foreach ($installments['Transport'] as $s) {
            if ($s['amount_due'] > 0 && $s['status'] !== 'paid') { $tpAllDone = false; break; }
        }
    }
    $transportComplete = (bool)$transportAssigned && $tpAllDone;

    $fullyPaid = $mandatoryComplete && (!$transportAssigned || $transportComplete);

    $scholarshipTotal = 0;
    try {
        $schRow = $db->queryOne(
            "SELECT COALESCE(SUM(amount),0) AS total
               FROM fee_payments
              WHERE student_id = :sid
                AND YEAR(payment_date) BETWEEN :yr1 AND :yr2
                AND payment_method LIKE 'Scholarship%'
                AND status = 'confirmed'",
            [':sid' => $studentId, ':yr1' => $yrNum1, ':yr2' => $yrNum2]
        );
        $scholarshipTotal = (float)($schRow['total'] ?? 0);
    } catch (Throwable $e) { }

    return [
        'student_id'          => $studentId,
        'academic_year'       => $academicYear,
        'discount_pct'        => $discount,
        'one_time_fees'       => $oneTimeMap,
        'one_time_total'      => $oneTimeTotal,
        'one_time_paid'       => min($totalPaid, $oneTimeTotal),
        'one_time_owed'       => max(0, $oneTimeTotal - min($totalPaid, $oneTimeTotal)),
        'installments'        => $installments,
        'install_total'       => $sfTotal,
        'install_paid'        => $sfPaid,
        'transport_total'     => $tpTotal,
        'transport_paid'      => $tpPaid,
        'transport_assigned'  => (bool)$transportAssigned,
        'transport_complete'  => $transportComplete,
        'mandatory_complete'  => $mandatoryComplete,
        'scholarship_total'   => $scholarshipTotal,
        'total_paid'          => $totalPaid,
        'grand_total'         => $grandTotal,
        'balance_owed'        => ($grandTotal > 0) ? max(0, $grandTotal - $totalPaid) : 0,
        'fully_paid'          => $fullyPaid,
        'no_fees_configured'  => ($grandTotal == 0),
    ];
}

function studentPaymentStatus($db) {
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$studentId) fail('student_id required');

    $student = $db->queryOne(
        "SELECT s.id, s.student_name, s.class_id, c.class_name, c.class_color
           FROM students s JOIN classes c ON c.id = s.class_id
          WHERE s.id = :id AND s.status = 'active'",
        [':id' => $studentId]
    );
    if (!$student) fail('Student not found');

    try {
        $status = buildPaymentStatus($db, $studentId, (int)$student['class_id'], getAcademicYear($db));
    } catch (Throwable $e) {
        ok([
            'student_id'         => $studentId,
            'student_name'       => $student['student_name'],
            'class_name'         => $student['class_name'],
            'class_color'        => $student['class_color'],
            'academic_year'      => getAcademicYear($db),
            'discount_pct'       => 0,
            'one_time_fees'      => [],
            'installments'       => [],
            'total_paid'         => 0,
            'grand_total'        => 0,
            'balance_owed'       => 0,
            'fully_paid'         => false,
            'no_fees_configured' => true,
            'transport_assigned' => false,
            'transport_total'    => 0,
            'migration_needed'   => true,
        ]);
        return;
    }
    $status['student_name'] = $student['student_name'];
    $status['class_name']   = $student['class_name'];
    $status['class_color']  = $student['class_color'];

    ok($status);
}

function getFinancialOverview($db) {
    $month = isset($_GET['month']) ? trim($_GET['month']) : date('Y-m');
    $year  = substr($month, 0, 4);
    $yr    = getAcademicYear($db);

    $rev = $db->queryOne(
        "SELECT COALESCE(SUM(amount),0) AS total FROM fee_payments
          WHERE DATE_FORMAT(payment_date,'%Y-%m')=:m AND status='confirmed'",
        [':m'=>$month]);
    $totalRevenue = (float)($rev['total']??0);

    $revYear = $db->queryOne(
        "SELECT COALESCE(SUM(amount),0) AS total FROM fee_payments
          WHERE YEAR(payment_date)=:y AND status='confirmed'", [':y'=>$year]);
    $yearRevenue = (float)($revYear['total']??0);

    $scholarshipRevMonth = 0;
    $scholarshipRevYear  = 0;
    $scholarshipCount    = 0;
    try {
        $schRow = $db->queryOne(
            "SELECT COALESCE(SUM(amount),0) AS total, COUNT(DISTINCT student_id) AS cnt
               FROM fee_payments
              WHERE DATE_FORMAT(payment_date,'%Y-%m')=:m
                AND payment_method LIKE 'Scholarship%'
                AND status='confirmed'",
            [':m' => $month]
        );
        $scholarshipRevMonth = (float)($schRow['total'] ?? 0);
        $scholarshipCount    = (int)($schRow['cnt']   ?? 0);

        $schYrRow = $db->queryOne(
            "SELECT COALESCE(SUM(amount),0) AS total
               FROM fee_payments
              WHERE YEAR(payment_date)=:y
                AND payment_method LIKE 'Scholarship%'
                AND status='confirmed'",
            [':y' => $year]
        );
        $scholarshipRevYear = (float)($schYrRow['total'] ?? 0);
    } catch (Throwable $e) { }

    $totalExpenses = 0;
    $breakdown     = [];
    try {
        $expRow = $db->queryOne(
            "SELECT COALESCE(SUM(amount),0) AS total FROM expenses
              WHERE DATE_FORMAT(expense_date,'%Y-%m')=:m", [':m'=>$month]);
        $totalExpenses = (float)($expRow['total']??0);

        $breakdown = $db->query(
            "SELECT category, COALESCE(SUM(amount),0) AS amount FROM expenses
              WHERE DATE_FORMAT(expense_date,'%Y-%m')=:m
              GROUP BY category ORDER BY amount DESC", [':m'=>$month]) ?: [];
        foreach ($breakdown as &$row) {
            $row['amount']=(float)$row['amount'];
            $row['percentage']=$totalExpenses>0?round(($row['amount']/$totalExpenses)*100):0;
        } unset($row);
    } catch (Throwable $e) {
    }

    $pendingCount  = 0;
    $pendingAmount = 0;
    try {
        // Full outstanding = one-time + school fees + transport (if assigned)
        // Prefer fee_structure amounts so students without installment rows are not undercounted.
        [$ovYr1, $ovYr2] = getAcademicYearRange($yr);
        $cashPaid = $db->query(
            "SELECT student_id, COALESCE(SUM(amount),0) AS paid
               FROM fee_payments
              WHERE YEAR(payment_date) BETWEEN :yr1 AND :yr2 AND status = 'confirmed'
              GROUP BY student_id",
            [':yr1' => $ovYr1, ':yr2' => $ovYr2]
        ) ?: [];
        $cashMap = [];
        foreach ($cashPaid as $r) {
            $cashMap[(int)$r['student_id']] = (float)$r['paid'];
        }

        $oneTimeFees = $db->query(
            "SELECT fs.class_id, COALESCE(SUM(fs.amount),0) AS total
               FROM fee_structure fs
              WHERE fs.academic_year = :yr
                AND fs.fee_type NOT IN ('School Fees','Transport')
              GROUP BY fs.class_id",
            [':yr' => $yr]
        ) ?: [];
        $oneTimePerClass = [];
        $schoolWideOneTime = 0.0;
        foreach ($oneTimeFees as $r) {
            if ($r['class_id'] === null) {
                $schoolWideOneTime = (float)$r['total'];
            } else {
                $oneTimePerClass[(int)$r['class_id']] = (float)$r['total'];
            }
        }

        $classSchoolFees = [];
        $sfRows = $db->query(
            "SELECT class_id, amount FROM fee_structure
              WHERE academic_year = :yr AND fee_type = 'School Fees'",
            [':yr' => $yr]
        ) ?: [];
        foreach ($sfRows as $r) {
            if ($r['class_id'] !== null) {
                $classSchoolFees[(int)$r['class_id']] = (float)$r['amount'];
            }
        }

        // Pending = structure one-time + school fees − paid (same base as collection rate).
        // Transport is optional and is tracked on the student payment screen, not school-wide pending.
        $activeStudents = $db->query(
            "SELECT s.id, s.class_id FROM students s WHERE s.status='active'"
        ) ?: [];

        foreach ($activeStudents as $s) {
            $sid = (int)$s['id'];
            $cid = (int)$s['class_id'];
            $oneTime = $schoolWideOneTime + ($oneTimePerClass[$cid] ?? 0);
            $schoolFees = $classSchoolFees[$cid] ?? 0.0;
            $grandTotal = $oneTime + $schoolFees;
            if ($grandTotal <= 0) continue;
            $totalCash = $cashMap[$sid] ?? 0;
            $balance = max(0, $grandTotal - $totalCash);
            if ($balance > 0.009) {
                $pendingCount++;
                $pendingAmount += $balance;
            }
        }
    } catch (Throwable $e) {
    }

    $methods = $db->query(
        "SELECT payment_method, COUNT(*) AS cnt, COALESCE(SUM(amount),0) AS total
           FROM fee_payments
          WHERE DATE_FORMAT(payment_date,'%Y-%m')=:m AND status='confirmed'
          GROUP BY payment_method", [':m'=>$month]) ?: [];
    foreach ($methods as &$r) { $r['total']=(float)$r['total']; $r['count']=(int)$r['cnt']; } unset($r);

    $trendRaw = $db->query(
        "SELECT DATE_FORMAT(payment_date,'%Y-%m') AS month,
                COALESCE(SUM(amount),0) AS revenue
           FROM fee_payments
          WHERE payment_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) AND status='confirmed'
          GROUP BY DATE_FORMAT(payment_date,'%Y-%m') ORDER BY month ASC") ?: [];
    $trendMap = [];
    foreach ($trendRaw as $r) {
        $trendMap[$r['month']] = (float)$r['revenue'];
    }
    $trend = [];
    for ($i = 5; $i >= 0; $i--) {
        $ts = strtotime(date('Y-m-01') . " -{$i} months");
        $ym = date('Y-m', $ts);
        $trend[] = [
            'month'   => $ym,
            'label'   => date('M Y', $ts),
            'revenue' => isset($trendMap[$ym]) ? (float)$trendMap[$ym] : 0.0,
        ];
    }


    ok([
        'month'                  => $month,
        'total_revenue'          => $totalRevenue,
        'total_year_revenue'     => $yearRevenue,
        'total_expenses'         => $totalExpenses,
        'net_profit'             => $totalRevenue - $totalExpenses,
        'pending_count'          => $pendingCount,
        'pending_amount'         => $pendingAmount,
        'scholarship_revenue'    => $scholarshipRevMonth,
        'scholarship_year_revenue'=> $scholarshipRevYear,
        'scholarship_count'      => $scholarshipCount,
        'expense_breakdown'      => $breakdown,
        'method_breakdown'       => $methods,
        'revenue_trend'          => $trend,
    ]);
}

function recordPayment($db) {
    if ($_SERVER['REQUEST_METHOD']!=='POST') fail('Method not allowed',405);
    $data = readJson();

    foreach (['student_id','amount','payment_method','payment_date'] as $f) {
        if (empty($data[$f])) fail("Field '{$f}' is required");
    }
    $validMethods = ['Cash','M-Pesa','Bank Transfer','Cheque'];
    if (!in_array($data['payment_method'],$validMethods,true)) fail('Invalid payment method');

    $studentId = (int)$data['student_id'];
    $received  = (float)$data['amount'];
    $method    = $data['payment_method'];
    $date      = $data['payment_date'];
    $ref       = !empty($data['reference_number']) ? sanitize($data['reference_number']) : null;
    $yr        = getAcademicYear($db);

    if ($received <= 0) fail('Amount must be greater than zero');

    $student = $db->queryOne(
        "SELECT s.id, s.student_name, s.class_id FROM students s
          WHERE s.id=:id AND s.status IN ('active','graduated')", [':id'=>$studentId]);
    if (!$student) fail('Student not found');

    $classId  = (int)$student['class_id'];
    $discount = getActiveDiscount($db, $studentId);

    ensureInstallments($db, $studentId, $classId, $yr);

    $status = buildPaymentStatus($db, $studentId, $classId, $yr);

    if ($status['fully_paid']) fail('This student has no outstanding balance — all fees are fully paid.');

    $remaining   = $received;
    $allocations = [];

    $prevPayBudget = $status['total_paid'];

    foreach ($status['one_time_fees'] as $feeType => $feeAmount) {
        $alreadyCovered = min($feeAmount, max(0.0, $prevPayBudget));
        $prevPayBudget  = max(0.0, $prevPayBudget - $feeAmount);
        $owed = max(0, $feeAmount - $alreadyCovered);
        if ($owed > 0 && $remaining > 0) {
            $pay = min($owed, $remaining);
            $allocations[] = ['fee_type'=>$feeType,'amount'=>$pay,'type'=>'one_time'];
            $remaining -= $pay;
        }
    }

    $sfInstallments = $status['installments']['School Fees'] ?? [];
    foreach ($sfInstallments as $inst) {
        if ($inst['status'] === 'paid') continue;
        if ($remaining <= 0) break;

        $owed     = $inst['amount_due'] - $inst['amount_paid'];
        $minPay   = max(0.01, round($inst['amount_due'] * 0.10, 2));
        if ($remaining < $minPay) break;

        $pay = min($owed, $remaining);
        $allocations[] = [
            'fee_type'       => 'School Fees',
            'amount'         => $pay,
            'type'           => 'installment',
            'installment_no' => $inst['no'],
        ];
        $remaining -= $pay;
    }
    if ($status['transport_assigned']) {
        $tpInstallments = $status['installments']['Transport'] ?? [];
        foreach ($tpInstallments as $inst) {
            if ($inst['status'] === 'paid') continue;
            if ($remaining <= 0) break;
            $owed = $inst['amount_due'] - $inst['amount_paid'];
            if ($owed <= 0) continue;
            $pay = min($owed, $remaining);
            $allocations[] = [
                'fee_type'       => 'Transport',
                'amount'         => $pay,
                'type'           => 'installment',
                'installment_no' => $inst['no'],
            ];
            $remaining -= $pay;
        }
    }

    $receipt = null;
    for ($i=0; $i<5; $i++) {
        $c = makeReceiptNumber();
        if (!$db->queryOne("SELECT id FROM fee_payments WHERE receipt_number=:r",[':r'=>$c])) {
            $receipt = $c; break;
        }
    }
    if (!$receipt) fail('Could not generate receipt number',500);

    $payId = $db->execute(
        "INSERT INTO fee_payments
           (student_id,amount,payment_method,payment_date,receipt_number,reference_number,status,recorded_by,created_at)
         VALUES (:sid,:amt,:mth,:dt,:rec,:ref,'confirmed',:by,NOW())",
        [':sid'=>$studentId,':amt'=>$received,':mth'=>$method,
         ':dt'=>$date,':rec'=>$receipt,':ref'=>$ref,':by'=>getCurrentUserId()]
    );
    if (!$payId) fail('INSERT failed — check DB permissions',500);

    foreach ($allocations as $alloc) {
        if ($alloc['type'] !== 'installment') continue;
        $instRow = $db->queryOne(
            "SELECT id, amount_due, amount_paid FROM fee_installments
              WHERE student_id=:sid AND academic_year=:yr
                AND fee_type=:ft AND installment_no=:no",
            [':sid'=>$studentId,':yr'=>$yr,':ft'=>$alloc['fee_type'],':no'=>$alloc['installment_no']]
        );
        if ($instRow) {
            $newPaid  = round((float)$instRow['amount_paid'] + $alloc['amount'], 2);
            $newStatus = $newPaid >= (float)$instRow['amount_due'] ? 'paid' : 'partial';
            $db->execute(
                "UPDATE fee_installments
                    SET amount_paid=:paid, status=:st, payment_id=:pid,
                        paid_date=IF(:st2='paid',:pd,paid_date)
                  WHERE id=:id",
                [':paid'=>$newPaid,':st'=>$newStatus,':pid'=>$payId,
                 ':st2'=>$newStatus,':pd'=>$date,':id'=>(int)$instRow['id']]
            );
        }
    }

    logActivity($db, getCurrentUserId(), 'RECORD_PAYMENT',
        "{$method} TSh ".number_format($received)." for student ID {$studentId} — {$receipt}");

    ok([
        'id'             => $payId,
        'receipt_number' => $receipt,
        'student_name'   => $student['student_name'],
        'amount'         => $received,
        'allocations'    => $allocations,
        'remaining'      => $remaining,
        'discount_pct'   => $discount,
    ], 'Payment recorded successfully');
}

function setDiscount($db) {
    if ($_SERVER['REQUEST_METHOD']!=='POST') fail('Method not allowed',405);
    $data = readJson();

    if (empty($data['student_id']))        fail('student_id required');
    if (!isset($data['discount_percent'])) fail('discount_percent required');

    $studentId = (int)$data['student_id'];
    $pct       = (float)$data['discount_percent'];
    $reason    = !empty($data['reason'])         ? sanitize($data['reason'])         : null;
    $from      = !empty($data['effective_from']) ? $data['effective_from']            : date('Y-m-d');

    $to = null;
    if (!empty($data['effective_to'])) {
        $to = $data['effective_to'];
    } elseif (!empty($data['duration_months']) && (int)$data['duration_months'] > 0) {
        $months = (int)$data['duration_months'];
        $to = date('Y-m-d', strtotime($from . " +{$months} months"));
    }

    if ($pct < 0 || $pct > 100) fail('discount_percent must be 0–100');

    if (!$db->queryOne("SELECT id FROM students WHERE id=:id",[':id'=>$studentId])) {
        fail('Student not found');
    }

    $db->execute(
        "UPDATE student_discounts SET effective_to=:today
          WHERE student_id=:sid AND (effective_to IS NULL OR effective_to >= CURDATE())",
        [':today'=>date('Y-m-d'),':sid'=>$studentId]
    );

    if ($pct > 0) {
        $id = $db->execute(
            "INSERT INTO student_discounts
               (student_id,discount_percent,reason,effective_from,effective_to,created_by)
             VALUES (:sid,:pct,:reason,:from,:to,:by)",
            [':sid'=>$studentId,':pct'=>$pct,':reason'=>$reason,
             ':from'=>$from,':to'=>$to,':by'=>getCurrentUserId()]
        );
        if (!$id) fail('Failed to save discount',500);

        $db->execute(
            "DELETE FROM fee_installments
              WHERE student_id=:sid AND academic_year=:yr
                AND fee_type='School Fees' AND status='unpaid'",
            [':sid'=>$studentId,':yr'=>getAcademicYear($db)]
        );
        $student = $db->queryOne("SELECT class_id FROM students WHERE id=:id",[':id'=>$studentId]);
        if ($student) ensureInstallments($db,(int)$studentId,(int)$student['class_id'],getAcademicYear($db));
    }

    logActivity($db,getCurrentUserId(),'SET_DISCOUNT',
        "Set {$pct}% discount for student ID {$studentId}" . ($to ? " until {$to}" : ''));

    ok(['discount_percent'=>$pct,'effective_to'=>$to],
        $pct > 0 ? "Discount of {$pct}% applied" . ($to ? " until {$to}" : ' (no expiry)') : 'Discount removed');
}

function removeDiscount($db) {
    if ($_SERVER['REQUEST_METHOD']!=='POST') fail('Method not allowed',405);
    $data = readJson();
    if (empty($data['student_id'])) fail('student_id required');
    $studentId = (int)$data['student_id'];

    $db->execute(
        "UPDATE student_discounts SET effective_to=:today
          WHERE student_id=:sid AND (effective_to IS NULL OR effective_to >= CURDATE())",
        [':today'=>date('Y-m-d'),':sid'=>$studentId]
    );

    $db->execute(
        "DELETE FROM fee_installments
          WHERE student_id=:sid AND academic_year=:yr
            AND fee_type='School Fees' AND status='unpaid'",
        [':sid'=>$studentId,':yr'=>getAcademicYear($db)]
    );
    $student = $db->queryOne("SELECT class_id FROM students WHERE id=:id",[':id'=>$studentId]);
    if ($student) ensureInstallments($db,(int)$studentId,(int)$student['class_id'],getAcademicYear($db));

    logActivity($db,getCurrentUserId(),'REMOVE_DISCOUNT',"Removed discount for student ID {$studentId}");
    ok([],'Discount removed successfully');
}

function getDiscount($db) {
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$studentId) fail('student_id required');

    $rows = $db->query(
        "SELECT sd.*, u.full_name AS created_by_name
           FROM student_discounts sd
           LEFT JOIN users u ON u.id = sd.created_by
          WHERE sd.student_id=:sid
          ORDER BY sd.effective_from DESC LIMIT 10",
        [':sid'=>$studentId]
    ) ?: [];

    $activeRow = $db->queryOne(
        "SELECT * FROM student_discounts
          WHERE student_id=:sid
            AND effective_from <= CURDATE()
            AND (effective_to IS NULL OR effective_to >= CURDATE())
          ORDER BY effective_from DESC LIMIT 1",
        [':sid'=>$studentId]
    );

    $active = $activeRow ? (float)$activeRow['discount_percent'] : 0;

    ok([
        'active_percent'  => $active,
        'active_row'      => $activeRow ?: null,
        'history'         => $rows,
    ]);
}

function getAllDiscounts($db) {
    $rows = $db->query(
        "SELECT sd.id, sd.discount_percent, sd.reason,
                sd.effective_from, sd.effective_to,
                s.student_name, c.class_name, c.class_color,
                u.full_name AS created_by_name
           FROM student_discounts sd
           JOIN students s ON s.id = sd.student_id
           JOIN classes  c ON c.id = s.class_id
           LEFT JOIN users u ON u.id = sd.created_by
          WHERE sd.effective_from <= CURDATE()
            AND (sd.effective_to IS NULL OR sd.effective_to >= CURDATE())
          ORDER BY sd.effective_from DESC"
    ) ?: [];
    ok($rows);
}

function assignTransport($db) {
    if ($_SERVER['REQUEST_METHOD']!=='POST') fail('Method not allowed',405);
    $data = readJson();
    if (empty($data['student_id'])) fail('student_id required');
    $sid = (int)$data['student_id'];
    $yr  = getAcademicYear($db);

    $student = $db->queryOne("SELECT class_id FROM students WHERE id=:id AND status='active'",[':id'=>$sid]);
    if (!$student) fail('Student not found');

    try {
        $db->execute(
            "INSERT IGNORE INTO student_transport (student_id, academic_year, status, assigned_by, assigned_date)
             VALUES (:sid, :yr, 'active', :by, CURDATE())",
            [':sid'=>$sid,':yr'=>$yr,':by'=>getCurrentUserId()]
        );
        ensureTransportInstallments($db, $sid, (int)$student['class_id'], $yr);
    } catch (Throwable $e) {
        fail('student_transport table missing — please run finance_migration.sql (v3 section)', 500);
    }

    logActivity($db, getCurrentUserId(), 'ASSIGN_TRANSPORT', "Transport assigned to student ID {$sid}");
    ok([], 'Transport assigned successfully');
}

function removeTransport($db) {
    if ($_SERVER['REQUEST_METHOD']!=='POST') fail('Method not allowed',405);
    $data = readJson();
    if (empty($data['student_id'])) fail('student_id required');
    $sid = (int)$data['student_id'];
    $yr  = getAcademicYear($db);

    try {
        $db->execute(
            "UPDATE student_transport SET status='inactive' WHERE student_id=:sid AND academic_year=:yr",
            [':sid'=>$sid,':yr'=>$yr]
        );
    } catch (Throwable $e) {
        fail('student_transport table missing — please run finance_migration.sql (v3 section)', 500);
    }
    $db->execute(
        "DELETE FROM fee_installments WHERE student_id=:sid AND academic_year=:yr AND fee_type='Transport' AND status='unpaid'",
        [':sid'=>$sid,':yr'=>$yr]
    );
    logActivity($db, getCurrentUserId(), 'REMOVE_TRANSPORT', "Transport removed from student ID {$sid}");
    ok([], 'Transport removed');
}

function getScholarships($db) {
    try {
        $rows = $db->query(
            "SELECT sc.*, u.full_name AS created_by_name,
                    GROUP_CONCAT(s.student_name ORDER BY s.student_name SEPARATOR ', ') AS beneficiaries,
                    COUNT(ss.student_id) AS beneficiary_count
               FROM scholarships sc
               LEFT JOIN scholarship_students ss ON ss.scholarship_id = sc.id
               LEFT JOIN students s ON s.id = ss.student_id
               LEFT JOIN users u ON u.id = sc.created_by
              WHERE sc.academic_year = :yr
              GROUP BY sc.id
              ORDER BY sc.created_at DESC",
            [':yr' => getAcademicYear($db)]
        ) ?: [];
        foreach ($rows as &$r) { $r['amount']=(float)$r['amount']; } unset($r);
        ok($rows);
    } catch (Throwable $e) {
        ok([], 'Scholarships table not yet created — run finance_migration.sql (v3)');
    }
}

function saveScholarship($db) {
    if ($_SERVER['REQUEST_METHOD']!=='POST') fail('Method not allowed',405);
    $data = readJson();

    if (empty($data['name']))   fail('Scholarship name required');
    if (empty($data['amount'])||$data['amount']<=0) fail('Amount required');

    $yr           = getAcademicYear($db);
    $name         = cleanStr($data['name']);
    $desc         = !empty($data['description']) ? cleanStr($data['description']) : null;
    $amount       = (float)$data['amount'];
    $validSrc     = ['Cash','M-Pesa','Bank Transfer','Cheque'];
    $sourceMethod = !empty($data['source_method']) && in_array($data['source_method'], $validSrc, true)
                    ? $data['source_method'] : 'Cash';
    $payMethod    = 'Scholarship (' . $sourceMethod . ')';
    $students     = !empty($data['student_ids']) && is_array($data['student_ids']) ? $data['student_ids'] : [];

    try {
        $scId = $db->execute(
            "INSERT INTO scholarships (name, description, amount, academic_year, created_by)
             VALUES (:name, :desc, :amt, :yr, :by)",
            [':name'=>$name,':desc'=>$desc,':amt'=>$amount,':yr'=>$yr,':by'=>getCurrentUserId()]
        );
    } catch (Throwable $e) {
        fail('Scholarships table missing — please run finance_migration.sql (v3 section)', 500);
    }
    if (!$scId) fail('Failed to save scholarship', 500);

    $assignedCount = 0;
    $skippedCount  = 0;
    $debugErrors   = [];
    foreach ($students as $rawSid) {
        $sid = (int)$rawSid;
        try {
            $student = $db->queryOne(
                "SELECT s.id, s.class_id FROM students s WHERE s.id=:id AND s.status='active'",
                [':id'=>$sid]
            );
            if (!$student) {
                $debugErrors[] = "Student ID {$sid}: not found or not active";
                $skippedCount++; continue;
            }
            $classId = (int)$student['class_id'];

            ensureInstallments($db, $sid, $classId, $yr);

            $db->execute(
                "INSERT IGNORE INTO scholarship_students (scholarship_id, student_id) VALUES (:sc, :sid)",
                [':sc'=>$scId,':sid'=>$sid]
            );

            $status = buildPaymentStatus($db, $sid, $classId, $yr);

            if ($status['fully_paid']) {
                $debugErrors[] = "Student ID {$sid}: already fully paid — beneficiary recorded, no payment needed";
                $assignedCount++; continue;
            }

            $receipt  = 'SCH-'.date('Ymd').'-'.strtoupper(substr(uniqid('',true),-5));
            $byUserId = getCurrentUserId();
            $today    = date('Y-m-d');
            $now      = date('Y-m-d H:i:s');
            $db->execute(
                "INSERT INTO fee_payments
                   (student_id, amount, payment_method, payment_date, receipt_number,
                    reference_number, status, recorded_by, created_at)
                 VALUES (:sid, :amt, :mth, :pdate, :rec,
                         :ref, 'confirmed', :by, :creat)",
                [':sid'=>$sid, ':amt'=>$amount, ':mth'=>$payMethod,
                 ':pdate'=>$today, ':rec'=>$receipt, ':ref'=>null,
                 ':by'=>$byUserId, ':creat'=>$now]
            );
            $payRow = $db->queryOne(
                "SELECT id FROM fee_payments WHERE receipt_number = :rec",
                [':rec' => $receipt]
            );
            if (!$payRow) {
                $debugErrors[] = "Student ID {$sid}: failed to insert fee_payment record";
                $skippedCount++; continue;
            }
            $payId = (int)$payRow['id'];

            $remaining   = $amount;
            $allocations = [];

            $prevPayBudget = $status['total_paid'];
            foreach ($status['one_time_fees'] as $feeType => $feeAmount) {
                $alreadyCovered = min($feeAmount, max(0.0, $prevPayBudget));
                $prevPayBudget  = max(0.0, $prevPayBudget - $feeAmount);
                $owed = max(0, $feeAmount - $alreadyCovered);
                if ($owed > 0 && $remaining > 0) {
                    $pay = min($owed, $remaining);
                    $allocations[] = ['fee_type'=>$feeType,'amount'=>$pay,'type'=>'one_time'];
                    $remaining -= $pay;
                }
            }

            $sfInstallments = $status['installments']['School Fees'] ?? [];
            foreach ($sfInstallments as $inst) {
                if ($inst['status'] === 'paid' || $inst['amount_due'] == 0) continue;
                if ($remaining <= 0) break;
                $owed = $inst['amount_due'] - $inst['amount_paid'];
                if ($owed <= 0) continue;
                $pay = min($owed, $remaining);
                $allocations[] = [
                    'fee_type'       => 'School Fees',
                    'amount'         => $pay,
                    'type'           => 'installment',
                    'installment_no' => $inst['no'],
                ];
                $remaining -= $pay;
            }

            if ($remaining > 0) {
                if (!$status['transport_assigned']) {
                    try {
                        $db->execute(
                            "INSERT IGNORE INTO student_transport
                               (student_id, academic_year, status, assigned_by, assigned_date)
                             VALUES (:sid, :yr, 'active', :by, CURDATE())",
                            [':sid'=>$sid,':yr'=>$yr,':by'=>getCurrentUserId()]
                        );
                        ensureTransportInstallments($db, $sid, $classId, $yr);
                        $tpRows = $db->query(
                            "SELECT installment_no AS no, amount_due, amount_paid, status
                               FROM fee_installments
                              WHERE student_id=:sid AND academic_year=:yr AND fee_type='Transport'
                              ORDER BY installment_no ASC",
                            [':sid'=>$sid,':yr'=>$yr]
                        ) ?: [];
                        foreach ($tpRows as $inst) {
                            if ($inst['status'] === 'paid') continue;
                            if ($remaining <= 0) break;
                            $owed = (float)$inst['amount_due'] - (float)$inst['amount_paid'];
                            if ($owed <= 0) continue;
                            $pay = min($owed, $remaining);
                            $allocations[] = [
                                'fee_type'       => 'Transport',
                                'amount'         => $pay,
                                'type'           => 'installment',
                                'installment_no' => (int)$inst['no'],
                            ];
                            $remaining -= $pay;
                        }
                        logActivity($db, getCurrentUserId(), 'ASSIGN_TRANSPORT',
                            "Auto-assigned transport for student ID {$sid} via scholarship {$name}");
                    } catch (Throwable $e) { }
                } else {
                    foreach ($status['installments']['Transport'] ?? [] as $inst) {
                        if ($inst['status'] === 'paid' || $inst['amount_due'] == 0) continue;
                        if ($remaining <= 0) break;
                        $owed = $inst['amount_due'] - $inst['amount_paid'];
                        if ($owed <= 0) continue;
                        $pay = min($owed, $remaining);
                        $allocations[] = [
                            'fee_type'       => 'Transport',
                            'amount'         => $pay,
                            'type'           => 'installment',
                            'installment_no' => $inst['no'],
                        ];
                        $remaining -= $pay;
                    }
                }
            }

            foreach ($allocations as $alloc) {
                if ($alloc['type'] !== 'installment') continue;
                $instRow = $db->queryOne(
                    "SELECT id, amount_due, amount_paid FROM fee_installments
                      WHERE student_id=:sid AND academic_year=:yr
                        AND fee_type=:ft AND installment_no=:no",
                    [':sid'=>$sid,':yr'=>$yr,':ft'=>$alloc['fee_type'],':no'=>$alloc['installment_no']]
                );
                if ($instRow) {
                    $newPaid   = round((float)$instRow['amount_paid'] + $alloc['amount'], 2);
                    $newStatus = $newPaid >= (float)$instRow['amount_due'] ? 'paid' : 'partial';
                    $db->execute(
                        "UPDATE fee_installments
                            SET amount_paid=:paid, status=:st, payment_id=:pid,
                                paid_date=IF(:st2='paid',CURDATE(),paid_date)
                          WHERE id=:id",
                        [':paid'=>$newPaid,':st'=>$newStatus,':pid'=>$payId,
                         ':st2'=>$newStatus,':id'=>(int)$instRow['id']]
                    );
                }
            }

            $assignedCount++;
        } catch (Throwable $studentErr) {
            $errMsg = "Student ID {$sid}: " . $studentErr->getMessage();
            error_log("Scholarship '{$name}' — {$errMsg}");
            $debugErrors[] = $errMsg;
            $skippedCount++;
            continue;
        }
    }

    logActivity($db, getCurrentUserId(), 'SAVE_SCHOLARSHIP',
        "{$name} — TSh ".number_format($amount)." ({$payMethod}) for {$assignedCount} student(s), {$skippedCount} skipped");
    ok([
        'id'               => $scId,
        'students_assigned'=> $assignedCount,
        'skipped_count'    => $skippedCount,
        'source_method'    => $sourceMethod,
        'debug_errors'     => $debugErrors,
    ], 'Scholarship saved successfully');
}

function getTransactions($db) {
    $limit  = min((int)($_GET['limit']??50),200);
    $offset = (int)($_GET['offset']??0);
    $month  = trim($_GET['month']??'');
    $where  = '1=1'; $params = [];
    if ($month!=='') { $where.=" AND DATE_FORMAT(fp.payment_date,'%Y-%m')=:m"; $params[':m']=$month; }

    $rows = $db->query(
        "SELECT fp.id,fp.amount,fp.payment_method,fp.payment_date,
                fp.receipt_number,fp.reference_number,fp.status,
                s.student_name, c.class_name,
                up.full_name AS parent_name,
                p.relationship AS parent_relationship,
                ua.full_name AS recorded_by_name
           FROM fee_payments fp
           JOIN students s ON s.id=fp.student_id
           JOIN classes  c ON c.id=s.class_id
           LEFT JOIN parents p ON p.id=(SELECT id FROM parents WHERE student_id=s.id ORDER BY id LIMIT 1)
           LEFT JOIN users up ON up.id=p.user_id
           LEFT JOIN users ua ON ua.id=fp.recorded_by
          WHERE {$where}
          ORDER BY fp.payment_date DESC, fp.id DESC", $params) ?: [];

    $rows = array_slice($rows,$offset,$limit);
    foreach ($rows as &$r) { $r['amount']=(float)$r['amount']; } unset($r);
    ok($rows);
}

function getExpenses($db) {
    $limit  = min((int)($_GET['limit']??50),200);
    $offset = (int)($_GET['offset']??0);
    $month  = trim($_GET['month']??'');
    $where  = '1=1'; $params = [];
    if ($month!=='') { $where.=" AND DATE_FORMAT(e.expense_date,'%Y-%m')=:m"; $params[':m']=$month; }

    try {
        $rows = $db->query(
            "SELECT e.id,e.category,e.description,e.amount,
                    e.payment_method,e.expense_date,e.reference_number,
                    u.full_name AS recorded_by_name
               FROM expenses e
               LEFT JOIN users u ON u.id=e.recorded_by
              WHERE {$where}
              ORDER BY e.expense_date DESC, e.id DESC", $params) ?: [];
        $rows = array_slice($rows,$offset,$limit);
        foreach ($rows as &$r) { $r['amount']=(float)$r['amount']; } unset($r);
        ok($rows);
    } catch (Throwable $e) {
        ok([], 'Expenses table not yet created — run finance_migration.sql');
    }
}

function getFeeStructure($db) {
    $yr = getAcademicYear($db);
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;

    if ($studentId > 0) {
        $student = $db->queryOne(
            "SELECT class_id FROM students WHERE id=:id AND status='active'", [':id'=>$studentId]);
        if (!$student) { ok([]); return; }
        $classId = (int)$student['class_id'];

        $rows = $db->query(
            "SELECT fs.id,fs.fee_type,fs.amount,fs.currency,fs.academic_year,fs.class_id,c.class_name
               FROM fee_structure fs
               LEFT JOIN classes c ON c.id=fs.class_id
              WHERE fs.academic_year=:yr AND (fs.class_id=:cid OR fs.class_id IS NULL)
              ORDER BY fs.class_id IS NULL ASC, fs.fee_type ASC",
            [':yr'=>$yr,':cid'=>$classId]);
        if (empty($rows)) {
            $rows = $db->query(
                "SELECT fs.id,fs.fee_type,fs.amount,fs.currency,fs.academic_year,fs.class_id,c.class_name
                   FROM fee_structure fs LEFT JOIN classes c ON c.id=fs.class_id
                  WHERE fs.class_id=:cid OR fs.class_id IS NULL
                  ORDER BY fs.academic_year DESC LIMIT 20",
                [':cid'=>$classId]) ?: [];
        }
    } else {
        $rows = $db->query(
            "SELECT fs.id,fs.fee_type,fs.amount,fs.currency,fs.academic_year,fs.class_id,c.class_name
               FROM fee_structure fs LEFT JOIN classes c ON c.id=fs.class_id
              WHERE fs.academic_year=:yr ORDER BY c.class_name ASC,fs.fee_type ASC", [':yr'=>$yr]);
        if (empty($rows)) {
            $rows = $db->query(
                "SELECT fs.id,fs.fee_type,fs.amount,fs.currency,fs.academic_year,fs.class_id,c.class_name
                   FROM fee_structure fs LEFT JOIN classes c ON c.id=fs.class_id
                  ORDER BY fs.academic_year DESC LIMIT 50") ?: [];
        }
    }
    foreach ($rows as &$r) { $r['amount']=(float)$r['amount']; $r['class_id']=$r['class_id']!==null?(int)$r['class_id']:null; } unset($r);
    ok($rows);
}

function getEffectiveClassMap($db, $academicYear) {
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS student_class_history (
                id int UNSIGNED NOT NULL AUTO_INCREMENT,
                student_id int NOT NULL,
                class_id int NOT NULL,
                academic_year varchar(10) NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_student_year (student_id, academic_year)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) { }

    $rows = $db->query(
        "SELECT s.id AS student_id, COALESCE(sch.class_id, s.class_id) AS class_id
           FROM students s
           LEFT JOIN student_class_history sch ON sch.student_id = s.id AND sch.academic_year = :yr
          WHERE s.status IN ('active', 'graduated')",
        [':yr' => $academicYear]
    ) ?: [];

    $map = [];
    foreach ($rows as $r) { $map[(int)$r['student_id']] = (int)$r['class_id']; }
    return $map;
}

function getFeeByClass($db) {
    $yr = getAcademicYear($db);
    [$yr1, $yr2] = getAcademicYearRange($yr);

    $studentClassMap = getEffectiveClassMap($db, $yr);

    $classes = $db->query("SELECT id, class_name AS name, class_color FROM classes ORDER BY class_name ASC") ?: [];
    if (empty($classes)) { ok([]); return; }

    $classHeadcount = [];
    foreach ($studentClassMap as $cid) { $classHeadcount[$cid] = ($classHeadcount[$cid] ?? 0) + 1; }

    $instMap = [];
    try {
        $instRows = $db->query(
            "SELECT student_id, COALESCE(SUM(amount_due),0) AS due, COALESCE(SUM(amount_paid),0) AS paid
               FROM fee_installments
              WHERE academic_year = :yr AND fee_type != 'Transport'
              GROUP BY student_id",
            [':yr' => $yr]
        ) ?: [];
        foreach ($instRows as $r) {
            $sid = (int)$r['student_id'];
            if (!isset($studentClassMap[$sid])) continue;
            $cid = $studentClassMap[$sid];
            if (!isset($instMap[$cid])) $instMap[$cid] = ['due' => 0, 'paid' => 0];
            $instMap[$cid]['due']  += (float)$r['due'];
            $instMap[$cid]['paid'] += (float)$r['paid'];
        }
    } catch (Throwable $e) { }

    $otRows = $db->query(
        "SELECT class_id, COALESCE(SUM(amount),0) AS total
           FROM fee_structure
          WHERE academic_year = :yr
            AND fee_type NOT IN ('School Fees','Transport')
          GROUP BY class_id",
        [':yr' => $yr]
    ) ?: [];
    $otSchoolWide = 0; $otPerClass = [];
    foreach ($otRows as $r) {
        if ($r['class_id'] === null) $otSchoolWide = (float)$r['total'];
        else $otPerClass[(int)$r['class_id']] = (float)$r['total'];
    }

    $paidMap = [];
    $payRows = $db->query(
        "SELECT student_id, COALESCE(SUM(amount),0) AS paid
           FROM fee_payments
          WHERE YEAR(payment_date) BETWEEN :yr1 AND :yr2
            AND status = 'confirmed'
          GROUP BY student_id",
        [':yr1' => $yr1, ':yr2' => $yr2]
    ) ?: [];
    foreach ($payRows as $r) {
        $sid = (int)$r['student_id'];
        if (!isset($studentClassMap[$sid])) continue;
        $cid = $studentClassMap[$sid];
        $paidMap[$cid] = ($paidMap[$cid] ?? 0) + (float)$r['paid'];
    }

    $result = [];
    foreach ($classes as $c) {
        $cid      = (int)$c['id'];
        $cnt      = $classHeadcount[$cid] ?? 0;
        $otExp    = ($otSchoolWide + ($otPerClass[$cid] ?? 0)) * $cnt;
        $instDue  = $instMap[$cid]['due'] ?? 0;
        $sfStruct = 0.0;
        static $sfMapCache = null;
        if ($sfMapCache === null) {
            $sfMapCache = [];
            try {
                $sfR = $db->query(
                    "SELECT class_id, amount FROM fee_structure
                      WHERE academic_year = :yr AND fee_type = 'School Fees'",
                    [':yr' => $yr]
                ) ?: [];
                foreach ($sfR as $row) {
                    if ($row['class_id'] !== null) $sfMapCache[(int)$row['class_id']] = (float)$row['amount'];
                }
            } catch (Throwable $e) {}
        }
        $sfStruct = ($sfMapCache[$cid] ?? 0) * $cnt;
        // Structure is the configured total for the class; installments may be partial
        $expected = $otExp + max($sfStruct, $instDue);
        $collected = $paidMap[$cid] ?? 0;
        $rate      = $expected > 0 ? round($collected / $expected, 4) : 0;
        $result[]  = [
            'name'             => $c['name'],
            'class_id'         => $cid,
            'class_color'      => $c['class_color'],
            'student_count'    => $cnt,
            'collected_amount' => $collected,
            'expected_amount'  => $expected,
            'collection_rate'  => $rate,
        ];
    }
    ok($result);
}

function getFeeStructureAll($db) {
    $yr = getAcademicYear($db);
    $classes = $db->query("SELECT id,class_name,class_color FROM classes ORDER BY class_name ASC") ?: [];
    $fees    = $db->query(
        "SELECT fs.id,fs.fee_type,fs.amount,fs.class_id,fs.academic_year
           FROM fee_structure fs WHERE fs.academic_year=:yr
          ORDER BY fs.class_id ASC,fs.fee_type ASC", [':yr'=>$yr]) ?: [];

    $feeMap = [];
    foreach ($fees as $f) {
        $key = $f['class_id'] ?? 'school_wide';
        $feeMap[$key][] = ['id'=>(int)$f['id'],'fee_type'=>$f['fee_type'],'amount'=>(float)$f['amount']];
    }
    ok([
        'academic_year'        => $yr,
        'classes'              => $classes,
        'fee_map'              => $feeMap,
        'fee_types'            => getFeeTypesList($db,$yr),
        'installable'          => INSTALLABLE_FEES,
        'school_wide_fee_types'=> ['Registration Fee','Stationery','Uniform','Meals','Transport'],
        'class_fee_types'      => ['School Fees'],
    ]);
}

function getFeeTypesList($db,$year) {
    $rows = $db->query("SELECT DISTINCT fee_type FROM fee_structure WHERE academic_year=:yr ORDER BY fee_type ASC",[':yr'=>$year]) ?: [];
    return array_column($rows,'fee_type');
}

function saveFeeStructure($db) {
    if ($_SERVER['REQUEST_METHOD']!=='POST') fail('Method not allowed',405);
    $data = readJson();
    if (!isset($data['fees'])||!is_array($data['fees'])) fail('fees array required');

    $yr      = !empty($data['academic_year']) ? $data['academic_year'] : getAcademicYear($db);
    $classId = isset($data['class_id'])&&$data['class_id']!==''&&$data['class_id']!==null ? (int)$data['class_id'] : null;

    if ($classId!==null) {
        $db->execute("DELETE FROM fee_structure WHERE class_id=:cid AND academic_year=:yr",[':cid'=>$classId,':yr'=>$yr]);
    } else {
        $db->execute("DELETE FROM fee_structure WHERE class_id IS NULL AND academic_year=:yr",[':yr'=>$yr]);
    }
    $n=0;
    foreach ($data['fees'] as $fee) {
        $ft=(isset($fee['fee_type'])?trim(sanitize($fee['fee_type'])):'');
        $amt=(isset($fee['amount'])?(float)$fee['amount']:0);
        if ($ft===''||$amt<=0) continue;
        if ($classId!==null) {
            $db->execute("INSERT INTO fee_structure (class_id,fee_type,amount,currency,academic_year) VALUES (:cid,:ft,:amt,'TSh',:yr)",[':cid'=>$classId,':ft'=>$ft,':amt'=>$amt,':yr'=>$yr]);
        } else {
            $db->execute("INSERT INTO fee_structure (class_id,fee_type,amount,currency,academic_year) VALUES (NULL,:ft,:amt,'TSh',:yr)",[':ft'=>$ft,':amt'=>$amt,':yr'=>$yr]);
        }
        $n++;
    }
    if ($classId!==null) {
        $students = $db->query("SELECT id FROM students WHERE class_id=:cid AND status='active'",[':cid'=>$classId]) ?: [];
        foreach ($students as $s) {
            $db->execute(
                "DELETE FROM fee_installments
                  WHERE student_id=:sid AND academic_year=:yr
                    AND fee_type='School Fees' AND status='unpaid'",
                [':sid'=>$s['id'],':yr'=>$yr]
            );
            ensureInstallments($db,(int)$s['id'],$classId,$yr);
        }
    }
    logActivity($db,getCurrentUserId(),'UPDATE_FEE_STRUCTURE',"Updated ".($classId?"class {$classId}":"school-wide").", {$n} fees");
    ok(['inserted'=>$n],'Fee structure saved');
}

function getStudentsList($db) {
    $q = trim($_GET['q']??''); $params=[]; $where="s.status='active'";
    if ($q!=='') {
        $like='%'.$q.'%';
        $params[':q1']=$like; $params[':q2']=$like; $params[':q3']=$like;
        $where.=" AND s.id IN (SELECT s2.id FROM students s2
                               LEFT JOIN parents p2 ON p2.student_id=s2.id
                               LEFT JOIN users u2 ON u2.id=p2.user_id
                               WHERE s2.student_name LIKE :q1 OR u2.full_name LIKE :q2 OR u2.phone LIKE :q3)";
    }
    $rows = $db->query(
        "SELECT s.id,s.student_name,c.class_name,c.class_color,
                u.full_name AS parent_name, u.phone AS parent_phone, p.relationship AS parent_relationship
           FROM students s JOIN classes c ON c.id=s.class_id
           LEFT JOIN parents p ON p.id=(SELECT id FROM parents WHERE student_id=s.id ORDER BY id LIMIT 1)
           LEFT JOIN users u ON u.id=p.user_id
          WHERE {$where} ORDER BY s.student_name ASC LIMIT 50", $params) ?: [];
    ok($rows);
}

function sendFeeReminders($db) {
    if (function_exists('nsmsRateLimit') && !nsmsRateLimit('fee_reminders:admin:' . (int)getCurrentUserId(), 3, 3600)) {
        fail('Fee reminders already sent recently. Please wait before sending again.', 429);
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Method not allowed', 405);
    $data      = readJson();
    $onlyOneId = !empty($data['student_id']) ? (int)$data['student_id'] : null;
    $yr        = getAcademicYear($db);

    $where  = "s.status = 'active'";
    $params = [];
    if ($onlyOneId) { $where .= " AND s.id = :sid"; $params[':sid'] = $onlyOneId; }

    $students = $db->query(
        "SELECT s.id, s.student_name, s.class_id, c.class_name
           FROM students s JOIN classes c ON c.id = s.class_id
          WHERE {$where}
          ORDER BY s.student_name ASC",
        $params
    ) ?: [];

    $sentCount    = 0;
    $skippedCount = 0;

    foreach ($students as $student) {
        try {
            $status = buildPaymentStatus($db, (int)$student['id'], (int)$student['class_id'], $yr);
        } catch (Exception $e) {
            $skippedCount++; continue;
        }

        $owed = isset($status['balance_owed']) ? (float)$status['balance_owed'] : 0;
        if ($owed <= 0) { $skippedCount++; continue; }

        $guardians = $db->query(
            "SELECT u.email, u.full_name
               FROM parents p JOIN users u ON u.id = p.user_id
              WHERE p.student_id = :sid AND u.email IS NOT NULL AND u.email != ''",
            [':sid' => $student['id']]
        ) ?: [];

        foreach ($guardians as $g) {
            $subject = 'Fee Payment Reminder — ' . $student['student_name'];
            $body =
                '<p>Dear ' . htmlspecialchars($g['full_name']) . ',</p>' .
                '<p>This is a friendly reminder that a balance of <strong>TSh ' . number_format($owed, 0) . '</strong> ' .
                'remains outstanding on <strong>' . htmlspecialchars($student['student_name']) . '</strong>\'s ' .
                '(' . htmlspecialchars($student['class_name']) . ') school fees for the ' . htmlspecialchars($yr) . ' academic year.</p>' .
                '<p>You can view the full breakdown and make a payment anytime through the Fee Payments section of the parent portal' .
                ((defined('NSMS_SITE_URL') && NSMS_SITE_URL) ? (' at <a href="' . htmlspecialchars(rtrim(NSMS_SITE_URL, '/') . '/public/parent/pay-fees.html') . '">' . htmlspecialchars(rtrim(NSMS_SITE_URL, '/') . '/public/parent/pay-fees.html') . '</a>') : '') .
                '.</p>' .
                '<p style="color:#888;font-size:12px;">This is an automated reminder. If you have already paid, please disregard this message — it may take a short while for a recent payment to be verified.</p>';
            if (sendEmail($g['email'], $subject, $body)) $sentCount++;
        }
    }

    logActivity($db, getCurrentUserId(), 'SEND_FEE_REMINDERS',
        $onlyOneId ? "Reminder sent for student #{$onlyOneId}" : "Bulk reminders: {$sentCount} sent");

    ok(['reminders_sent' => $sentCount, 'students_skipped' => $skippedCount], 'Fee reminders sent');
}

function recordExpense($db) {
    if ($_SERVER['REQUEST_METHOD']!=='POST') fail('Method not allowed',405);
    $data=readJson();
    foreach (['category','description','amount','payment_method','expense_date'] as $f) {
        if (empty($data[$f])) fail("Field '{$f}' is required");
    }
    $validMethods=['Cash','M-Pesa','Bank Transfer','Cheque'];
    if (!in_array($data['payment_method'],$validMethods,true)) fail('Invalid payment method');
    $amount=(float)$data['amount'];
    if ($amount<=0) fail('Amount must be greater than zero');

    $id=$db->execute(
        "INSERT INTO expenses (category,description,amount,payment_method,expense_date,reference_number,recorded_by,created_at)
         VALUES (:cat,:desc,:amt,:mth,:dt,:ref,:by,NOW())",
        [':cat'=>sanitize($data['category']),':desc'=>sanitize($data['description']),
         ':amt'=>$amount,':mth'=>$data['payment_method'],':dt'=>$data['expense_date'],
         ':ref'=>!empty($data['reference_number'])?sanitize($data['reference_number']):null,
         ':by'=>getCurrentUserId()]);
    if (!$id) fail('INSERT failed',500);
    logActivity($db,getCurrentUserId(),'RECORD_EXPENSE',$data['category'].' — TSh '.number_format($amount));
    ok(['id'=>$id],'Expense recorded');
}

function exportReport($db) {
    $month = trim($_GET['month']??date('Y-m'));
    $settings=[];
    foreach ($db->query("SELECT setting_key,setting_value FROM school_settings")??[] as $r) {
        $settings[$r['setting_key']]=$r['setting_value'];
    }
    $rev=$db->queryOne("SELECT COALESCE(SUM(amount),0) AS total,COUNT(*) AS cnt FROM fee_payments WHERE DATE_FORMAT(payment_date,'%Y-%m')=:m AND status='confirmed'",[':m'=>$month]);
    $expRow=$db->queryOne("SELECT COALESCE(SUM(amount),0) AS total,COUNT(*) AS cnt FROM expenses WHERE DATE_FORMAT(expense_date,'%Y-%m')=:m",[':m'=>$month]);
    $methods=$db->query("SELECT payment_method,COUNT(*) AS cnt,COALESCE(SUM(amount),0) AS total FROM fee_payments WHERE DATE_FORMAT(payment_date,'%Y-%m')=:m AND status='confirmed' GROUP BY payment_method ORDER BY total DESC",[':m'=>$month])??[];
    $expCats=$db->query("SELECT category,COUNT(*) AS cnt,COALESCE(SUM(amount),0) AS total FROM expenses WHERE DATE_FORMAT(expense_date,'%Y-%m')=:m GROUP BY category ORDER BY total DESC",[':m'=>$month])??[];
    $payments=$db->query(
        "SELECT fp.receipt_number,fp.payment_date,fp.amount,fp.payment_method,fp.reference_number,fp.status,
                s.student_name,c.class_name,u.full_name AS parent_name,p.relationship
           FROM fee_payments fp
           JOIN students s ON s.id=fp.student_id JOIN classes c ON c.id=s.class_id
           LEFT JOIN parents p ON p.id=(SELECT id FROM parents WHERE student_id=s.id ORDER BY id LIMIT 1)
           LEFT JOIN users u ON u.id=p.user_id
          WHERE DATE_FORMAT(fp.payment_date,'%Y-%m')=:m AND fp.status='confirmed' ORDER BY fp.payment_date DESC",[':m'=>$month])??[];
    $expenses=$db->query(
        "SELECT e.expense_date,e.category,e.description,e.amount,e.payment_method,e.reference_number,u.full_name AS recorded_by
           FROM expenses e LEFT JOIN users u ON u.id=e.recorded_by
          WHERE DATE_FORMAT(e.expense_date,'%Y-%m')=:m ORDER BY e.expense_date DESC",[':m'=>$month])??[];
    $pending=$db->query(
        "SELECT s.student_name,c.class_name,u.full_name AS parent_name
           FROM students s JOIN classes c ON c.id=s.class_id
           LEFT JOIN parents p ON p.id=(SELECT id FROM parents WHERE student_id=s.id ORDER BY id LIMIT 1)
           LEFT JOIN users u ON u.id=p.user_id
           LEFT JOIN fee_payments fp ON fp.student_id=s.id AND DATE_FORMAT(fp.payment_date,'%Y-%m')=:m AND fp.status='confirmed'
          WHERE s.status='active' AND fp.id IS NULL ORDER BY c.class_name,s.student_name",[':m'=>$month])??[];

    foreach ($payments as &$r){$r['amount']=(float)$r['amount'];} unset($r);
    foreach ($expenses as &$r){$r['amount']=(float)$r['amount'];} unset($r);
    foreach ($methods  as &$r){$r['total']=(float)$r['total'];$r['count']=(int)$r['cnt'];} unset($r);
    foreach ($expCats  as &$r){$r['total']=(float)$r['total'];$r['count']=(int)$r['cnt'];} unset($r);

    $rT=(float)($rev['total']??0); $eT=(float)($expRow['total']??0);
    ok(['month'=>$month,'settings'=>$settings,
        'revenue'=>['total'=>$rT,'count'=>(int)($rev['cnt']??0)],
        'expenses_total'=>['total'=>$eT,'count'=>(int)($expRow['cnt']??0)],
        'net'=>$rT-$eT,'method_breakdown'=>$methods,'exp_breakdown'=>$expCats,
        'payments'=>$payments,'expenses'=>$expenses,'pending_students'=>$pending,
        'generated_at'=>date('Y-m-d H:i:s'),'generated_by'=>getCurrentUserId()]);
}

function getPaymentReceipt($db) {
    $payId = isset($_GET['payment_id']) ? (int)$_GET['payment_id'] : 0;
    if (!$payId) fail('payment_id required');

    $pay = $db->queryOne(
        "SELECT fp.id, fp.student_id, fp.amount, fp.payment_method,
                fp.payment_date, fp.receipt_number, fp.reference_number,
                fp.status, fp.created_at,
                s.student_name, s.class_id,
                c.class_name, c.class_color,
                up.full_name AS parent_name,
                pr.relationship AS parent_relationship,
                ua.full_name  AS recorded_by_name
           FROM fee_payments fp
           JOIN students s  ON s.id  = fp.student_id
           JOIN classes  c  ON c.id  = s.class_id
           LEFT JOIN parents pr ON pr.id = (SELECT id FROM parents WHERE student_id = s.id ORDER BY id LIMIT 1)
           LEFT JOIN users up   ON up.id = pr.user_id
           LEFT JOIN users ua   ON ua.id = fp.recorded_by
          WHERE fp.id = :id",
        [':id' => $payId]
    );
    if (!$pay) fail('Payment not found');
    $pay['amount'] = (float)$pay['amount'];

    $linkedInst = [];
    try {
        $linkedInst = $db->query(
            "SELECT fee_type, installment_no, amount_due, amount_paid, status, paid_date
               FROM fee_installments
              WHERE payment_id = :pid
              ORDER BY fee_type ASC, installment_no ASC",
            [':pid' => $payId]
        ) ?: [];
        foreach ($linkedInst as &$r) {
            $r['amount_due']  = (float)$r['amount_due'];
            $r['amount_paid'] = (float)$r['amount_paid'];
            $r['installment_no'] = (int)$r['installment_no'];
        } unset($r);
    } catch (Throwable $e) { }

    $status = null;
    try {
        $status = buildPaymentStatus(
            $db,
            (int)$pay['student_id'],
            (int)$pay['class_id'],
            getAcademicYear($db)
        );
    } catch (Throwable $e) { }

    $settings = [];
    try {
        foreach ($db->query("SELECT setting_key, setting_value FROM school_settings") ?? [] as $r) {
            $settings[$r['setting_key']] = $r['setting_value'];
        }
    } catch (Throwable $e) { }

    ok([
        'payment'             => $pay,
        'linked_installments' => $linkedInst,
        'status'              => $status,
        'settings'            => $settings,
        'generated_at'        => date('Y-m-d H:i:s'),
    ]);
}

function ledgerReconcile($db) {
    if (function_exists('requireRole')) {
        requireRole(array('admin'));
    }
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
    $data = nsmsLedgerReconcileSummary($db, $limit);
    if (function_exists('successResponse')) {
        successResponse($data, 'Ledger reconciliation (read-only)');
    } else {
        ob_end_clean();
        echo json_encode(array('success' => true, 'data' => $data));
        exit;
    }
}


function ledgerPromote($db) {
    if (function_exists('requireRole')) {
        requireRole(array('admin'));
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        if (function_exists('errorResponse')) {
            errorResponse('POST required', 405);
        }
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'POST required'));
        exit;
    }
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 100;
    $data = nsmsLedgerPromoteTransactions($db, $limit);
    if (function_exists('successResponse')) {
        successResponse($data, 'Ledger promote finished (insert-only, nothing deleted)');
    } else {
        ob_end_clean();
        echo json_encode(array('success' => true, 'data' => $data));
        exit;
    }
}
