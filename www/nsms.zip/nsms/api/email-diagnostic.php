<?php
/**
 * Email integration test — admin only.
 *
 * Visit while logged in as admin:
 *   /nsms/api/email-diagnostic.php?to=waythonny@yahoo.com
 *
 * Delete this file once you've confirmed email sending works, or leave it —
 * it's harmless (admin-gated, sends exactly one email per request).
 */

ob_start();
header('Content-Type: application/json');

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

requireRole('admin');

$to = isset($_GET['to']) ? trim($_GET['to']) : '';
if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
    ob_end_clean();
    echo json_encode(['success' => false, 'error' => 'Pass a valid address: ?to=waythonny@yahoo.com']);
    exit;
}

$sent = sendEmail(
    $to,
    'NSMS Email Test',
    '<p>If you\'re reading this in your inbox, the Brevo integration is working. 🎉</p>'
);

ob_end_clean();
echo json_encode([
    'success' => $sent,
    'message' => $sent
        ? "Sent! Check {$to}'s inbox (and spam folder, just in case)."
        : 'Not sent — check your PHP error log for the exact reason (missing config, bad API key, unverified sender, etc.).',
]);
