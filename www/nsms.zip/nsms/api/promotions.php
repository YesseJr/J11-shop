<?php
/**
 * Promotions & Graduation API — admin only.
 * PHP 7.2 compatible
 *
 * End-of-year class transition: students in the graduating class (the
 * one with the highest classes.sort_order) graduate — moved out of the
 * active roster into a permanent `graduates` record, not deleted.
 * Students in every other class either advance to the next class up
 * (next sort_order) or repeat their current class, based on a decision
 * the admin confirms per student — pre-filled from the promotion_status
 * a teacher already set on that student's published terminal report,
 * but always overridable by the admin before anything is executed.
 *
 * Actions (GET):  preview | graduates_list
 * Actions (POST): execute
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    exit(0);
}

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

applyApiHeaders();

requireRole('admin');

$db   = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

ensureGraduatesTable($db);
ensureClassSortOrder($db);
ensureClassHistoryTable($db);

$action = isset($_GET['action']) ? $_GET['action'] : '';

try {
    switch ($action) {
        case 'preview':          getPreview($db);          break;
        case 'execute':          executeTransition($db);   break;
        case 'graduates_list':   getGraduatesList($db);     break;
        case 'graduate_detail':  getGraduateDetail($db);    break;
        default: ob_end_clean(); errorResponse('Invalid action', 400);
    }
} catch (Exception $e) {
    ob_end_clean();
    error_log('NSMS promotions: ' . $e->getMessage());
    errorResponse('Server error: ' . $e->getMessage(), 500);
}

/**
 * Same self-heal as settings.php — defends against this page being the
 * first one hit in a session, before settings.php ever runs its own copy.
 * See settings.php's ensureClassSortOrder() for the full explanation.
 */
function ensureClassSortOrder($db) {
    try { $db->execute("ALTER TABLE classes ADD COLUMN sort_order INT NOT NULL DEFAULT 0"); } catch (Exception $e) { /* already exists */ }
    try {
        $anySet = $db->queryOne("SELECT COUNT(*) AS c FROM classes WHERE sort_order != 0");
        if ($anySet && (int)$anySet['c'] === 0) {
            $db->execute("UPDATE classes SET sort_order = id");
        }
    } catch (Exception $e) { /* non-fatal */ }
}

/**
 * Records which class a student was actually in during a specific
 * academic year — permanently, even after they're later promoted out of
 * it. Without this, any report joining fee data to "the student's class"
 * would use their *current* class_id, silently reattributing a past
 * year's fee collection to whatever class they've since moved to. This
 * table is what api/finance.php's getFeeByClass() reads to stay accurate
 * across promotions.
 */
function ensureClassHistoryTable($db) {
    $db->execute(
        "CREATE TABLE IF NOT EXISTS student_class_history (
            id int UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id int NOT NULL,
            class_id int NOT NULL,
            academic_year varchar(10) NOT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_student_year (student_id, academic_year)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
}

/**
 * The graduates table is new — create it on first use rather than
 * requiring a manual migration, same self-healing pattern used
 * elsewhere in NSMS (school_gallery, student_emergency_contacts, etc.).
 */
function ensureGraduatesTable($db) {
    $db->execute(
        "CREATE TABLE IF NOT EXISTS graduates (
            id int UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id int NOT NULL,
            student_name varchar(100) NOT NULL,
            final_class_id int NULL,
            final_class_name varchar(50) NULL,
            photo_url varchar(255) NULL,
            graduation_year varchar(10) NOT NULL,
            graduated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            processed_by int NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_student_year (student_id, graduation_year)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
}

/**
 * Every active class in hierarchy order, each with its active students
 * and — for each student — their latest published terminal report's
 * promotion_status for the given academic year, if one exists. This is
 * a read-only preview; nothing here changes any student's record.
 */
function getPreview($db) {
    $academicYear = isset($_GET['academic_year']) ? trim($_GET['academic_year']) : getCurrentAcademicYear();

    $classes = $db->query("SELECT id, class_name, class_color, sort_order FROM classes ORDER BY sort_order ASC") ?: [];
    if (empty($classes)) { ob_end_clean(); successResponse(['academic_year'=>$academicYear,'classes'=>[]]); return; }

    $maxSortOrder = max(array_column($classes, 'sort_order'));

    $result = [];
    foreach ($classes as $cls) {
        $isGraduatingClass = ((int)$cls['sort_order'] === (int)$maxSortOrder);

        $students = $db->query(
            "SELECT id, student_name, photo_url FROM students
              WHERE class_id = :cid AND status = 'active'
              ORDER BY student_name ASC",
            [':cid' => $cls['id']]
        ) ?: [];

        foreach ($students as &$s) {
            $report = $db->queryOne(
                "SELECT promotion_status, overall_average, id AS report_id
                   FROM student_reports
                  WHERE student_id = :sid AND report_type = 'terminal'
                    AND academic_year = :yr AND is_published = 1
                  ORDER BY published_at DESC LIMIT 1",
                [':sid' => $s['id'], ':yr' => $academicYear]
            );
            $s['promotion_status'] = $report ? $report['promotion_status'] : null;
            $s['has_terminal_report'] = (bool)$report;
            // Sensible default recommendation — admin can override every one of these
            // before executing. When in doubt (no report, or "Under Review"), default
            // to "repeat" rather than silently advancing a student without a clear signal.
            $s['recommended_decision'] = ($report && $report['promotion_status'] === 'Promoted') ? 'advance' : 'repeat';
        }
        unset($s);

        $result[] = [
            'class_id'    => (int)$cls['id'],
            'class_name'  => $cls['class_name'],
            'class_color' => $cls['class_color'],
            'is_graduating_class' => $isGraduatingClass,
            'students'    => $students,
        ];
    }

    ob_end_clean();
    successResponse(['academic_year' => $academicYear, 'classes' => $result]);
}

/**
 * Executes the transition for a batch of students in one call.
 * Input: { academic_year, decisions: [ { student_id, decision: 'advance'|'repeat' }, ... ] }
 *
 * For each 'advance' decision: if the student's CURRENT class is the
 * graduating class (highest sort_order), they graduate — status flips
 * to 'graduated' and a graduates record is created. Otherwise they move
 * to the class with the next-higher sort_order.
 * For 'repeat': no class change; the student simply remains for another year.
 */
function executeTransition($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }

    $userId = getCurrentUserId();
    $input  = json_decode(file_get_contents('php://input'), true) ?: [];
    $academicYear = isset($input['academic_year']) ? trim($input['academic_year']) : getCurrentAcademicYear();
    $decisions    = isset($input['decisions']) && is_array($input['decisions']) ? $input['decisions'] : [];

    if (empty($decisions)) { ob_end_clean(); errorResponse('No decisions provided'); }

    $classes = $db->query("SELECT id, class_name, sort_order FROM classes ORDER BY sort_order ASC") ?: [];
    if (empty($classes)) { ob_end_clean(); errorResponse('No classes configured'); }
    $maxSortOrder = max(array_column($classes, 'sort_order'));

    // Quick lookup: class_id -> ['sort_order'=>, 'next_class_id'=>, 'next_class_name'=>]
    $classMeta = [];
    foreach ($classes as $i => $cls) {
        $next = isset($classes[$i + 1]) ? $classes[$i + 1] : null;
        $classMeta[(int)$cls['id']] = [
            'sort_order'      => (int)$cls['sort_order'],
            'name'            => $cls['class_name'],
            'next_class_id'   => $next ? (int)$next['id'] : null,
            'next_class_name' => $next ? $next['class_name'] : null,
        ];
    }

    $advancedCount  = 0;
    $graduatedCount = 0;
    $repeatedCount  = 0;
    $skipped        = [];

    foreach ($decisions as $d) {
        $studentId = isset($d['student_id']) ? (int)$d['student_id'] : 0;
        $decision  = isset($d['decision']) ? trim($d['decision']) : '';
        if (!$studentId || !in_array($decision, ['advance', 'repeat'], true)) { continue; }

        $student = $db->queryOne(
            "SELECT id, student_name, class_id, photo_url FROM students WHERE id = :id AND status = 'active'",
            [':id' => $studentId]
        );
        if (!$student) { $skipped[] = $studentId; continue; }

        $curClassId = (int)$student['class_id'];
        if (!isset($classMeta[$curClassId])) { $skipped[] = $studentId; continue; }
        $meta = $classMeta[$curClassId];

        // Record which class this student was actually in for the year that's
        // ending, BEFORE any class_id change below — this is what keeps
        // fee-by-class reporting accurate after a promotion (see
        // ensureClassHistoryTable() for why this exists).
        $db->execute(
            "INSERT IGNORE INTO student_class_history (student_id, class_id, academic_year)
             VALUES (:sid, :cid, :yr)",
            [':sid' => $studentId, ':cid' => $curClassId, ':yr' => $academicYear]
        );

        if ($decision === 'repeat') {
            $repeatedCount++;
            continue; // no changes — student simply stays for another year
        }

        // decision === 'advance'
        if ($meta['sort_order'] === $maxSortOrder) {
            // Graduating class — student graduates rather than moving class.
            $ok = $db->execute(
                "INSERT INTO graduates (student_id, student_name, final_class_id, final_class_name, photo_url, graduation_year, graduated_at, processed_by)
                 VALUES (:sid, :name, :cid, :cname, :photo, :yr, NOW(), :uid)
                 ON DUPLICATE KEY UPDATE student_name = VALUES(student_name)",
                [':sid'=>$studentId, ':name'=>$student['student_name'], ':cid'=>$curClassId,
                 ':cname'=>$meta['name'], ':photo'=>$student['photo_url'], ':yr'=>$academicYear, ':uid'=>$userId]
            );
            if ($ok !== false) {
                $db->execute("UPDATE students SET status = 'graduated' WHERE id = :id", [':id' => $studentId]);
                $graduatedCount++;
                notifyGraduation($db, $studentId, $student['student_name'], $academicYear);
            } else {
                $skipped[] = $studentId;
            }
        } else {
            if (!$meta['next_class_id']) { $skipped[] = $studentId; continue; }
            $db->execute("UPDATE students SET class_id = :cid WHERE id = :id", [':cid'=>$meta['next_class_id'], ':id'=>$studentId]);
            $advancedCount++;
            notifyPromotion($db, $studentId, $student['student_name'], $meta['next_class_name'], $academicYear);
        }
    }

    logActivity($db, $userId, 'END_OF_YEAR_TRANSITION',
        "Advanced: {$advancedCount}, Graduated: {$graduatedCount}, Repeated: {$repeatedCount}, Skipped: " . count($skipped));

    ob_end_clean();
    successResponse([
        'advanced'  => $advancedCount,
        'graduated' => $graduatedCount,
        'repeated'  => $repeatedCount,
        'skipped'   => $skipped,
    ], 'Transition complete');
}

function getGraduatesList($db) {
    $year = isset($_GET['year']) ? trim($_GET['year']) : '';
    $where = '';
    $params = [];
    if ($year !== '') { $where = 'WHERE graduation_year = :yr'; $params[':yr'] = $year; }

    $rows = $db->query(
        "SELECT * FROM graduates {$where} ORDER BY graduation_year DESC, student_name ASC",
        $params
    ) ?: [];

    // Fee status per graduate — small school, small graduating cohorts each
    // year, so computing this per row on the list view is perfectly fine.
    foreach ($rows as &$g) {
        $fee = getStudentFeeBalance($db, (int)$g['student_id'], (int)$g['final_class_id'], $g['graduation_year']);
        $g['fee_status'] = $fee;
    }
    unset($g);

    $years = $db->query("SELECT DISTINCT graduation_year FROM graduates ORDER BY graduation_year DESC") ?: [];

    ob_end_clean();
    successResponse(['graduates' => $rows, 'years' => array_column($years, 'graduation_year')]);
}

/**
 * Full detail for one graduate: fee status with the actual figures (not
 * just the badge), how long they were enrolled, their parent/guardian
 * contacts (the student record itself is never deleted, so this still
 * resolves live), and a summary of their final terminal report if one
 * was published.
 */
function getGraduateDetail($db) {
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$studentId) { ob_end_clean(); errorResponse('student_id required'); }

    $grad = $db->queryOne(
        "SELECT * FROM graduates WHERE student_id = :sid ORDER BY graduated_at DESC LIMIT 1",
        [':sid' => $studentId]
    );
    if (!$grad) { ob_end_clean(); errorResponse('No graduation record found for this student', 404); }

    $student = $db->queryOne(
        "SELECT id, student_name, date_of_birth, gender, address, photo_url, enrollment_date
           FROM students WHERE id = :id",
        [':id' => $studentId]
    );

    $enrolledYears = null;
    if ($student && !empty($student['enrollment_date'])) {
        $start = new DateTime($student['enrollment_date']);
        $end   = new DateTime(substr($grad['graduated_at'], 0, 10));
        $diff  = $start->diff($end);
        $enrolledYears = ['years' => $diff->y, 'months' => $diff->m];
    }

    $guardians = $db->query(
        "SELECT u.full_name, u.email, u.phone, p.relationship
           FROM parents p JOIN users u ON u.id = p.user_id
          WHERE p.student_id = :sid",
        [':sid' => $studentId]
    ) ?: [];

    $feeStatus = getStudentFeeBalance($db, $studentId, (int)$grad['final_class_id'], $grad['graduation_year']);

    $finalReport = $db->queryOne(
        "SELECT id, teacher_comments, recommendations, promotion_status, subject_data
           FROM student_reports
          WHERE student_id = :sid AND report_type = 'terminal'
            AND academic_year = :yr AND is_published = 1
          ORDER BY published_at DESC LIMIT 1",
        [':sid' => $studentId, ':yr' => $grad['graduation_year']]
    );
    if ($finalReport && !empty($finalReport['subject_data'])) {
        $finalReport['subject_data'] = json_decode($finalReport['subject_data'], true);
    }

    ob_end_clean();
    successResponse([
        'graduate'       => $grad,
        'student'        => $student,
        'enrolled_span'  => $enrolledYears,
        'guardians'      => $guardians,
        'fee_status'     => $feeStatus,
        'final_report'   => $finalReport ?: null,
    ]);
}

/**
 * A simplified, self-contained fee balance calculation for a single
 * academic year — mirrors the core logic in parent-finance.php's
 * buildPaymentStatus() without needing to include that file (which has
 * its own top-level parent-only auth check that would break here).
 * Good enough for a graduate's "did they clear their fees" badge; not
 * intended to replace the full parent/admin finance views.
 */
/**
 * Fee balance for a single academic year — a faithful port of
 * buildPaymentStatus() in api/finance.php (can't require_once that file
 * directly; it has its own top-level auth/routing that would run
 * immediately and break this context).
 *
 * IMPORTANT: an earlier, simpler version of this function summed *every*
 * fee_installments row for the student regardless of fee_type — which
 * silently counted Transport installments even for students who were
 * never actually assigned transport (a leftover/unused row), overstating
 * their balance. This version checks student_transport the same way
 * finance.php does and excludes Transport unless it's actually active,
 * so this now agrees with what admin Finance and the parent portal show.
 */
function getStudentFeeBalance($db, $studentId, $classId, $academicYear) {
    // One-time fees (NOT School Fees, NOT Transport)
    $feeRows = $db->query(
        "SELECT fs.fee_type, fs.amount, fs.class_id FROM fee_structure fs
          WHERE fs.academic_year = :yr AND fs.fee_type NOT IN ('School Fees', 'Transport')
            AND (fs.class_id = :cid OR fs.class_id IS NULL)
          ORDER BY fs.class_id DESC",
        [':yr' => $academicYear, ':cid' => $classId]
    ) ?: [];
    $oneTimeMap = [];
    foreach ($feeRows as $f) {
        if (!isset($oneTimeMap[$f['fee_type']])) { $oneTimeMap[$f['fee_type']] = (float)$f['amount']; }
    }
    $oneTimeTotal = array_sum($oneTimeMap);

    // Total confirmed payments this academic year
    $yParts = explode('/', $academicYear);
    $y1 = (int)$yParts[0];
    $y2 = isset($yParts[1]) ? (int)$yParts[1] : ($y1 + 1);
    $paidRow = $db->queryOne(
        "SELECT COALESCE(SUM(amount),0) AS total FROM fee_payments
          WHERE student_id = :sid AND status = 'confirmed'
            AND YEAR(payment_date) BETWEEN :y1 AND :y2",
        [':sid' => $studentId, ':y1' => $y1, ':y2' => $y2]
    );
    $totalPaid = $paidRow ? (float)$paidRow['total'] : 0;

    // Make sure School Fees installment rows actually exist before reading them
    ensureFeeInstallments($db, $studentId, $classId, $academicYear);

    // Transport only counts if the student is actually assigned it this year
    $transportAssigned = false;
    try {
        $transportAssigned = (bool)$db->queryOne(
            "SELECT id FROM student_transport WHERE student_id = :sid AND academic_year = :yr AND status = 'active'",
            [':sid' => $studentId, ':yr' => $academicYear]
        );
    } catch (Exception $e) { $transportAssigned = false; }

    $installRows = $db->query(
        "SELECT fee_type, amount_due, amount_paid, status FROM fee_installments
          WHERE student_id = :sid AND academic_year = :yr",
        [':sid' => $studentId, ':yr' => $academicYear]
    ) ?: [];

    $sfTotal = 0;
    foreach ($installRows as $r) {
        if ($r['fee_type'] === 'Transport') {
            if (!$transportAssigned) continue; // exactly what buildPaymentStatus() does
            continue; // Transport itself is excluded from the mandatory grand total too
        }
        $sfTotal += (float)$r['amount_due'];
    }

    $grandTotal = $oneTimeTotal + $sfTotal;
    $balance    = max(0, $grandTotal - $totalPaid);

    return [
        'grand_total' => round($grandTotal, 2),
        'total_paid'  => round($totalPaid, 2),
        'balance'     => round($balance, 2),
        'has_debt'    => ($grandTotal > 0 && $balance > 0.5),
    ];
}

/**
 * Mirrors finance.php's ensureInstallments() — only School Fees gets
 * installments here; Transport is assigned per-student separately.
 */
function ensureFeeInstallments($db, $studentId, $classId, $academicYear) {
    $fees = $db->query(
        "SELECT amount FROM fee_structure
          WHERE academic_year = :yr AND fee_type = 'School Fees'
            AND (class_id = :cid OR class_id IS NULL)
          ORDER BY class_id DESC LIMIT 1",
        [':yr' => $academicYear, ':cid' => $classId]
    ) ?: [];
    if (empty($fees)) return;

    $annualAmount = (float)$fees[0]['amount'];
    $discountRow  = $db->queryOne(
        "SELECT discount_percent FROM student_discounts
          WHERE student_id = :sid AND effective_from <= CURDATE()
            AND (effective_to IS NULL OR effective_to >= CURDATE())
          ORDER BY effective_from DESC LIMIT 1",
        [':sid' => $studentId]
    );
    $discount = $discountRow ? (float)$discountRow['discount_percent'] : 0;

    $base = round($annualAmount / 10, 2); // TOTAL_INSTALLMENTS = 10, matching finance.php
    $installmentAmount = $discount > 0 ? round($base * (1 - $discount / 100), 2) : $base;

    for ($i = 1; $i <= 10; $i++) {
        $db->execute(
            "INSERT IGNORE INTO fee_installments (student_id, academic_year, fee_type, installment_no, amount_due)
             VALUES (:sid, :yr, 'School Fees', :no, :amt)",
            [':sid' => $studentId, ':yr' => $academicYear, ':no' => $i, ':amt' => $installmentAmount]
        );
    }
}

/**
 * Best-effort notification to every parent linked to a student who has
 * just graduated. Never blocks the transition itself if it fails.
 */
function notifyGraduation($db, $studentId, $studentName, $year) {
    try {
        $schoolRow  = $db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key = 'school_name'");
        $schoolName = ($schoolRow && !empty($schoolRow['setting_value'])) ? $schoolRow['setting_value'] : 'our school';

        $guardians = $db->query(
            "SELECT u.email, u.full_name FROM parents p JOIN users u ON u.id = p.user_id
              WHERE p.student_id = :sid AND u.email IS NOT NULL AND u.email != ''",
            [':sid' => $studentId]
        ) ?: [];
        foreach ($guardians as $g) {
            $subject = 'Congratulations — ' . $studentName . ' has graduated! 🎓';
            $body =
                '<p>Dear ' . htmlspecialchars($g['full_name']) . ',</p>' .
                '<p>🎉 Congratulations! <strong>' . htmlspecialchars($studentName) . '</strong> has successfully completed ' .
                'the ' . htmlspecialchars($year) . ' academic year at <strong>' . htmlspecialchars($schoolName) . '</strong> and has graduated.</p>' .
                '<p>We are so proud of everything they\'ve achieved with us, and wish them all the best as they move on to the next stage of their education.</p>' .
                '<p style="color:#888;font-size:12px;">This is an automated notice from the school management system.</p>';
            sendEmail($g['email'], $subject, $body);
        }
    } catch (Exception $e) { error_log('notifyGraduation error: ' . $e->getMessage()); }
}

/**
 * Best-effort notification to every parent linked to a student who has
 * just been promoted to a new class.
 */
function notifyPromotion($db, $studentId, $studentName, $newClassName, $year) {
    try {
        $guardians = $db->query(
            "SELECT u.email, u.full_name FROM parents p JOIN users u ON u.id = p.user_id
              WHERE p.student_id = :sid AND u.email IS NOT NULL AND u.email != ''",
            [':sid' => $studentId]
        ) ?: [];
        foreach ($guardians as $g) {
            $subject = $studentName . ' has been promoted to ' . $newClassName . '! 🎉';
            $body =
                '<p>Dear ' . htmlspecialchars($g['full_name']) . ',</p>' .
                '<p>Great news — following the ' . htmlspecialchars($year) . ' academic year, <strong>' . htmlspecialchars($studentName) . '</strong> ' .
                'has been promoted to <strong>' . htmlspecialchars($newClassName) . '</strong> for the new academic year.</p>' .
                '<p style="color:#888;font-size:12px;">This is an automated notice from the school management system.</p>';
            sendEmail($g['email'], $subject, $body);
        }
    } catch (Exception $e) { error_log('notifyPromotion error: ' . $e->getMessage()); }
}