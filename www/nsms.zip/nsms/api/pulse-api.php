<?php
/**
 * J11 Pulse API  —  /nsms/api/pulse-api.php
 * PHP 7.2 compatible. Handles admin AND teacher roles.
 *
 * ── Direct Messages ─────────────────────────────────────────
 *   GET  ?action=whoami
 *   GET  ?action=conversations
 *   GET  ?action=thread&contact_id=X
 *   GET  ?action=thread_updates&contact_id=X&since_id=N
 *   GET  ?action=contacts
 *   GET  ?action=typing_status&contact_id=X
 *   POST ?action=send
 *   POST ?action=send_file
 *   POST ?action=mark_read&contact_id=X
 *   POST ?action=set_typing&contact_id=X
 *   POST ?action=heartbeat
 *
 * ── Collaboration Hub ────────────────────────────────────────
 *   GET  ?action=my_groups
 *   GET  ?action=available_groups
 *   GET  ?action=group_thread&group_id=X
 *   GET  ?action=group_thread_updates&group_id=X&since_id=N
 *   GET  ?action=group_members&group_id=X
 *   GET  ?action=resources&group_id=X
 *   POST ?action=create_group        { name, description, color }
 *   POST ?action=join_group&group_id=X
 *   POST ?action=leave_group&group_id=X
 *   POST ?action=group_send          { group_id, message }
 *   POST ?action=group_send_file     (multipart: group_id, message, attachment)
 *   POST ?action=upload_resource     (multipart: group_id, title, description, attachment)
 *
 * ── Alerts ──────────────────────────────────────────────────
 *   GET  ?action=my_alerts
 *   GET  ?action=sent_alerts
 *   POST ?action=send_alert          { title, body, priority, target_type, target_role, target_user_id }
 *   POST ?action=mark_alert_read&alert_id=X
 *
 * ── Broadcast (post = admin only) ────────────────────────────
 *   GET  ?action=announcements
 *   GET  ?action=newsletters
 *   POST ?action=post_announcement   { title, body, target_role, pinned, expires_at }
 *   POST ?action=post_newsletter     { subject, content, target_role }
 *   POST ?action=delete_announcement&id=X
 *   POST ?action=delete_newsletter&id=X
 *
 * ── Unread summary ───────────────────────────────────────────
 *   GET  ?action=unread_counts
 */

ob_start();

// A PHP warning/notice printed here would land in the response body
// BEFORE the JSON below, breaking every fetch().then(r=>r.json()) call
// on the frontend — and since most of those don't have a .catch(),
// the failure shows up as a UI stuck on "Loading…" forever with no
// visible error anywhere. Log issues instead of printing them, same
// safe pattern already used in api/settings.php.
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

applyApiHeaders();

requireRole(['admin', 'teacher']);

$db   = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

$action = isset($_GET['action']) ? trim($_GET['action']) : '';
_pulsePresence($db);
_pulseEnsureModernSchema($db);

switch ($action) {
    case 'whoami':               pulseWhoAmI($db);             break;
    case 'conversations':        pulseConversations($db);      break;
    case 'thread':               pulseThread($db);             break;
    case 'thread_updates':       pulseThreadUpdates($db);      break;
    case 'contacts':             pulseContacts($db);           break;
    case 'typing_status':        pulseTypingStatus($db);       break;
    case 'send':                 pulseSend($db);               break;
    case 'send_file':            pulseSendFile($db);           break;
    case 'mark_read':            pulseMarkRead($db);           break;
    case 'set_typing':           pulseSetTyping($db);          break;
    case 'heartbeat':            pulseHeartbeat($db);          break;
    case 'toggle_reaction':      pulseToggleReaction($db);     break;
    case 'edit_message':         pulseEditMessage($db);        break;
    case 'delete_message':       pulseDeleteMessage($db);      break;
    case 'my_groups':            pulseMyGroups($db);           break;
    case 'available_groups':     pulseAvailableGroups($db);    break;
    case 'group_thread':         pulseGroupThread($db);        break;
    case 'mark_group_read':      pulseMarkGroupRead($db);      break;
    case 'group_thread_updates': pulseGroupThreadUpdates($db); break;
    case 'group_members':        pulseGroupMembers($db);       break;
    case 'resources':            pulseResources($db);          break;
    case 'create_group':         pulseCreateGroup($db);        break;
    case 'join_group':           pulseJoinGroup($db);          break;
    case 'leave_group':          pulseLeaveGroup($db);         break;
    case 'group_send':           pulseGroupSend($db);          break;
    case 'group_send_file':      pulseGroupSendFile($db);      break;
    case 'upload_resource':      pulseUploadResource($db);     break;
    case 'my_alerts':            pulseMyAlerts($db);           break;
    case 'sent_alerts':          pulseSentAlerts($db);         break;
    case 'send_alert':           pulseSendAlert($db);          break;
    case 'mark_alert_read':      pulseMarkAlertRead($db);      break;
    case 'announcements':        pulseAnnouncements($db);      break;
    case 'newsletters':          pulseNewsletters($db);        break;
    case 'post_announcement':    pulsePostAnnouncement($db);   break;
    case 'post_newsletter':      pulsePostNewsletter($db);     break;
    case 'delete_announcement':  pulseDeleteAnnouncement($db); break;
    case 'delete_newsletter':    pulseDeleteNewsletter($db);   break;
    case 'unread_counts':        pulseUnreadCounts($db);       break;
    default: ob_end_clean(); errorResponse('Invalid action');
}

/* ════════════════════════════════════════════════════════
   UTILITIES
════════════════════════════════════════════════════════ */
function _me()     { return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0; }
function _myRole() { return isset($_SESSION['role'])    ? $_SESSION['role']          : ''; }

function _pulsePresence($db) {
    $me = _me(); if (!$me) return;
    try {
        $db->execute(
            "INSERT INTO user_presence (user_id, last_seen) VALUES (:uid, NOW())
             ON DUPLICATE KEY UPDATE last_seen = NOW()",
            [':uid' => $me]
        );
    } catch (\Exception $e) {}
}

function _isOnline($db, $userId) {
    try {
        $r = $db->queryOne(
            "SELECT user_id FROM user_presence WHERE user_id = :uid AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)",
            [':uid' => $userId]
        );
        return (bool)$r;
    } catch (\Exception $e) { return false; }
}

function _attachDmFiles($db, array &$messages) {
    if (empty($messages)) return;
    $ids = array_filter(array_column($messages, 'id'));
    if (empty($ids)) return;
    $ph = implode(',', array_fill(0, count($ids), '?'));
    try {
        $files = $db->query(
            "SELECT message_id, id AS file_id, original_name, stored_name, mime_type, file_size
             FROM message_files WHERE message_id IN ($ph)",
            array_values($ids)
        ) ?: [];
    } catch (\Exception $e) { $files = []; }
    $fmap = [];
    foreach ($files as $f) {
        $mid = $f['message_id'];
        if (!isset($fmap[$mid])) $fmap[$mid] = [];
        $fmap[$mid][] = [
            'file_id'       => $f['file_id'],
            'original_name' => $f['original_name'],
            'mime_type'     => $f['mime_type'],
            'file_size'     => (int)$f['file_size'],
            'url'           => '/nsms/uploads/messages/' . $f['stored_name'],
        ];
    }
    foreach ($messages as &$m) { $m['files'] = isset($fmap[$m['id']]) ? $fmap[$m['id']] : []; }
    unset($m);
}

/**
 * Attaches a compact reaction summary to each message: one entry per
 * distinct emoji used on that message, with a count and whether the
 * current user is one of the reactors (so the UI can highlight their
 * own reaction). Mirrors _attachDmFiles()'s batch-fetch-then-map shape.
 */
function _attachReactions($db, array &$messages, $me) {
    if (empty($messages)) return;
    $ids = array_filter(array_column($messages, 'id'));
    if (empty($ids)) return;
    $ph = implode(',', array_fill(0, count($ids), '?'));
    try {
        $rows = $db->query(
            "SELECT message_id, emoji, user_id FROM message_reactions WHERE message_id IN ($ph)",
            array_values($ids)
        ) ?: [];
    } catch (\Exception $e) { $rows = []; }

    $map = []; // message_id => emoji => ['count'=>n,'mine'=>bool]
    foreach ($rows as $r) {
        $mid = $r['message_id']; $emoji = $r['emoji'];
        if (!isset($map[$mid])) $map[$mid] = [];
        if (!isset($map[$mid][$emoji])) $map[$mid][$emoji] = ['emoji' => $emoji, 'count' => 0, 'mine' => false];
        $map[$mid][$emoji]['count']++;
        if ((int)$r['user_id'] === (int)$me) $map[$mid][$emoji]['mine'] = true;
    }
    foreach ($messages as &$m) { $m['reactions'] = isset($map[$m['id']]) ? array_values($map[$m['id']]) : []; }
    unset($m);
}

/**
 * For any message with deleted_at set, blanks its text/files/reactions and
 * marks is_deleted=true so the frontend renders the standard "This message
 * was deleted" placeholder instead of the original content — the row
 * itself is never removed, keeping reply-quotes and thread order intact.
 */
function _maskDeletedMessages(array &$messages) {
    foreach ($messages as &$m) {
        $m['is_deleted'] = !empty($m['deleted_at']);
        if ($m['is_deleted']) {
            $m['message']   = null;
            $m['files']     = [];
            $m['reactions'] = [];
        }
    }
    unset($m);
}

/**
 * Adds the columns/table the modern messaging features (reactions, edit,
 * soft-delete) need, on first use — self-healing, no manual migration
 * required, same pattern used throughout NSMS.
 */
function _pulseEnsureModernSchema($db) {
    try { $db->execute("ALTER TABLE messages ADD COLUMN edited_at DATETIME NULL"); } catch (\Exception $e) { /* already exists */ }
    try { $db->execute("ALTER TABLE messages ADD COLUMN deleted_at DATETIME NULL"); } catch (\Exception $e) { /* already exists */ }
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS message_reactions (
                id int UNSIGNED NOT NULL AUTO_INCREMENT,
                message_id int NOT NULL,
                user_id int NOT NULL,
                emoji varchar(16) NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_reaction (message_id, user_id, emoji)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (\Exception $e) { /* non-fatal */ }
}

/**
 * Toggle a reaction: if the calling user already reacted with this exact
 * emoji on this message, it's removed; otherwise it's added. A user can
 * have multiple different-emoji reactions on the same message (Slack-style),
 * just not the same emoji twice.
 */
function pulseToggleReaction($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $messageId = isset($body['message_id']) ? (int)$body['message_id'] : 0;
    $emoji     = isset($body['emoji']) ? trim($body['emoji']) : '';
    if (!$messageId || $emoji === '') { ob_end_clean(); errorResponse('message_id and emoji required'); }

    // Only react to a message you can actually see (sender or recipient of this DM)
    $msg = $db->queryOne("SELECT id, sender_id, recipient_id FROM messages WHERE id = :id", [':id' => $messageId]);
    if (!$msg || ((int)$msg['sender_id'] !== $me && (int)$msg['recipient_id'] !== $me)) {
        ob_end_clean(); errorResponse('Message not found', 404);
    }

    $existing = $db->queryOne(
        "SELECT id FROM message_reactions WHERE message_id = :mid AND user_id = :uid AND emoji = :e",
        [':mid' => $messageId, ':uid' => $me, ':e' => $emoji]
    );
    if ($existing) {
        $db->execute("DELETE FROM message_reactions WHERE id = :id", [':id' => $existing['id']]);
        $action = 'removed';
    } else {
        $db->execute(
            "INSERT INTO message_reactions (message_id, user_id, emoji, created_at) VALUES (:mid, :uid, :e, NOW())",
            [':mid' => $messageId, ':uid' => $me, ':e' => $emoji]
        );
        $action = 'added';
    }

    ob_end_clean(); successResponse(['action' => $action, 'emoji' => $emoji], 'OK');
}

/**
 * Edit the text of your own message. Allowed within 15 minutes of
 * sending, matching the familiar WhatsApp-style edit window — long
 * enough to fix a typo, short enough that a "corrected" message can't
 * quietly rewrite history in an old conversation.
 */
function pulseEditMessage($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $messageId  = isset($body['message_id']) ? (int)$body['message_id'] : 0;
    $newMessage = isset($body['message']) ? trim($body['message']) : '';
    if (!$messageId) { ob_end_clean(); errorResponse('message_id required'); }
    if ($newMessage === '') { ob_end_clean(); errorResponse('Message cannot be empty'); }

    $msg = $db->queryOne("SELECT id, sender_id, created_at, deleted_at FROM messages WHERE id = :id", [':id' => $messageId]);
    if (!$msg || (int)$msg['sender_id'] !== $me) { ob_end_clean(); errorResponse('Message not found', 404); }
    if ($msg['deleted_at']) { ob_end_clean(); errorResponse('Cannot edit a deleted message'); }
    if (strtotime($msg['created_at']) < strtotime('-15 minutes')) {
        ob_end_clean(); errorResponse('This message is too old to edit (15-minute window)');
    }

    $db->execute(
        "UPDATE messages SET message = :msg, edited_at = NOW() WHERE id = :id",
        [':msg' => $newMessage, ':id' => $messageId]
    );
    ob_end_clean(); successResponse(['id' => $messageId, 'message' => $newMessage], 'Message updated');
}

/**
 * Soft-delete your own message — replaced with a "This message was
 * deleted" placeholder in the thread rather than removed outright, so
 * conversation flow (replies quoting it, read-receipt history) stays
 * intact for the other participant, same principle as WhatsApp/Slack.
 */
function pulseDeleteMessage($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $messageId = isset($body['message_id']) ? (int)$body['message_id'] : 0;
    if (!$messageId) { ob_end_clean(); errorResponse('message_id required'); }

    $msg = $db->queryOne("SELECT id, sender_id FROM messages WHERE id = :id", [':id' => $messageId]);
    if (!$msg || (int)$msg['sender_id'] !== $me) { ob_end_clean(); errorResponse('Message not found', 404); }

    $db->execute("UPDATE messages SET deleted_at = NOW() WHERE id = :id", [':id' => $messageId]);
    // Reactions on a deleted message no longer make sense to show
    try { $db->execute("DELETE FROM message_reactions WHERE message_id = :id", [':id' => $messageId]); } catch (\Exception $e) {}

    ob_end_clean(); successResponse(['id' => $messageId], 'Message deleted');
}

function _attachGroupFiles($db, array &$messages) {
    if (empty($messages)) return;
    $ids = array_filter(array_column($messages, 'id'));
    if (empty($ids)) return;
    $ph = implode(',', array_fill(0, count($ids), '?'));
    try {
        $files = $db->query(
            "SELECT group_message_id AS message_id, id AS file_id, original_name, stored_name, mime_type, file_size
             FROM pulse_group_files WHERE group_message_id IN ($ph)",
            array_values($ids)
        ) ?: [];
    } catch (\Exception $e) { $files = []; }
    $fmap = [];
    foreach ($files as $f) {
        $mid = $f['message_id'];
        if (!isset($fmap[$mid])) $fmap[$mid] = [];
        $fmap[$mid][] = [
            'file_id'       => $f['file_id'],
            'original_name' => $f['original_name'],
            'mime_type'     => $f['mime_type'],
            'file_size'     => (int)$f['file_size'],
            'url'           => '/nsms/uploads/messages/' . $f['stored_name'],
        ];
    }
    foreach ($messages as &$m) { $m['files'] = isset($fmap[$m['id']]) ? $fmap[$m['id']] : []; }
    unset($m);
}

function _resolveTeacherClassId($db) {
    $uid = _me(); if (!$uid) return null;
    $r = $db->queryOne("SELECT id FROM classes WHERE teacher_id = :uid LIMIT 1", [':uid' => $uid]);
    return $r ? (int)$r['id'] : null;
}

function _requireAdmin() {
    if (_myRole() !== 'admin') { ob_end_clean(); errorResponse('Admin access required', 403); }
}

function _uploadFile($field, $destDir) {
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return null;
    $file    = $_FILES[$field];
    $origName = basename($file['name']);
    $mime    = mime_content_type($file['tmp_name']) ?: 'application/octet-stream';
    $size    = $file['size'];
    $allowed = [
        'image/jpeg','image/png','image/gif','image/webp',
        'application/pdf','text/plain',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ];
    if ($size > 10 * 1024 * 1024) { ob_end_clean(); errorResponse('File too large (max 10 MB)'); }
    if (!in_array($mime, $allowed, true)) { ob_end_clean(); errorResponse('File type not allowed'); }
    if (!is_dir($destDir)) { mkdir($destDir, 0755, true); }
    $ext    = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    $stored = bin2hex(random_bytes(12)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $destDir . $stored)) {
        ob_end_clean(); errorResponse('Failed to save file', 500);
    }
    return ['original_name' => $origName, 'stored_name' => $stored, 'mime_type' => $mime, 'file_size' => $size];
}

/* ════════════════════════════════════════════════════════
   WHO AM I
════════════════════════════════════════════════════════ */
function pulseWhoAmI($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $row = $db->queryOne("SELECT id, full_name, photo_url, role FROM users WHERE id = :id", [':id' => $me]);
    if (!$row) { ob_end_clean(); errorResponse('User not found', 404); }
    ob_end_clean();
    successResponse($row);
}

/* ════════════════════════════════════════════════════════
   DIRECT MESSAGES — conversations
════════════════════════════════════════════════════════ */
function pulseConversations($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT contact_id, MAX(created_at) AS last_at, SUM(is_unread) AS unread_count
         FROM (
             SELECT CASE WHEN sender_id = :me1 THEN recipient_id ELSE sender_id END AS contact_id,
                    created_at,
                    CASE WHEN recipient_id = :me2 AND is_read = 0 THEN 1 ELSE 0 END AS is_unread
             FROM messages WHERE sender_id = :me3 OR recipient_id = :me4
         ) sub
         GROUP BY contact_id ORDER BY last_at DESC",
        [':me1' => $me, ':me2' => $me, ':me3' => $me, ':me4' => $me]
    ) ?: [];

    if (empty($rows)) { ob_end_clean(); successResponse([]); return; }

    $contactIds = array_column($rows, 'contact_id');
    $ph = implode(',', array_fill(0, count($contactIds), '?'));
    $userMap = []; $presRows = [];
    $users = $db->query("SELECT id, full_name, photo_url, role FROM users WHERE id IN ($ph)", array_values($contactIds)) ?: [];
    foreach ($users as $u) { $userMap[$u['id']] = $u; }
    try {
        $pr = $db->query("SELECT user_id FROM user_presence WHERE user_id IN ($ph) AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)", array_values($contactIds)) ?: [];
        foreach ($pr as $p) { $presRows[$p['user_id']] = true; }
    } catch (\Exception $e) {}

    $out = [];
    foreach ($rows as $row) {
        $cid = (int)$row['contact_id'];
        $contact = isset($userMap[$cid]) ? $userMap[$cid] : null;
        if (!$contact) continue;
        $latest = $db->queryOne(
            "SELECT message, subject FROM messages
             WHERE (sender_id = :me AND recipient_id = :cid) OR (sender_id = :cid2 AND recipient_id = :me2)
             ORDER BY created_at DESC LIMIT 1",
            [':me' => $me, ':cid' => $cid, ':cid2' => $cid, ':me2' => $me]
        );
        $out[] = [
            'contact_id'    => $cid,
            'full_name'     => $contact['full_name'],
            'photo_url'     => $contact['photo_url'],
            'role'          => $contact['role'],
            'last_at'       => $row['last_at'],
            'unread_count'  => (int)$row['unread_count'],
            'last_message'  => $latest ? $latest['message']  : '',
            'last_subject'  => $latest ? $latest['subject']  : '',
            'is_online'     => isset($presRows[$cid]),
        ];
    }
    ob_end_clean(); successResponse($out);
}

/* ════════════════════════════════════════════════════════
   DIRECT MESSAGES — thread
════════════════════════════════════════════════════════ */
function pulseThread($db) {
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $cid = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$cid) { ob_end_clean(); errorResponse('contact_id required'); }

    $messages = $db->query(
        "SELECT m.id, m.sender_id, m.recipient_id, m.subject, m.message,
                m.is_read, m.has_file, m.reply_to_id, m.created_at,
                m.edited_at, m.deleted_at,
                rm.message AS reply_to_message,
                ru.full_name AS reply_to_sender
         FROM messages m
         LEFT JOIN messages rm ON rm.id = m.reply_to_id
         LEFT JOIN users   ru ON ru.id  = rm.sender_id
         WHERE (m.sender_id = :me AND m.recipient_id = :cid)
            OR (m.sender_id = :cid2 AND m.recipient_id = :me2)
         ORDER BY m.created_at ASC, m.id ASC",
        [':me' => $me, ':cid' => $cid, ':cid2' => $cid, ':me2' => $me]
    ) ?: [];
    _attachDmFiles($db, $messages);
    _attachReactions($db, $messages, $me);
    _maskDeletedMessages($messages);

    $contact = $db->queryOne("SELECT id, full_name, photo_url, role FROM users WHERE id = :id", [':id' => $cid]);
    $online  = _isOnline($db, $cid);

    ob_end_clean(); successResponse(['messages' => $messages, 'contact' => $contact, 'is_online' => $online]);
}

function pulseThreadUpdates($db) {
    $me      = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $cid     = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    $sinceId = isset($_GET['since_id'])   ? (int)$_GET['since_id']   : 0;
    if (!$cid) { ob_end_clean(); errorResponse('contact_id required'); }

    $messages = $db->query(
        "SELECT m.id, m.sender_id, m.recipient_id, m.subject, m.message,
                m.is_read, m.has_file, m.reply_to_id, m.created_at,
                m.edited_at, m.deleted_at,
                rm.message AS reply_to_message,
                ru.full_name AS reply_to_sender
         FROM messages m
         LEFT JOIN messages rm ON rm.id = m.reply_to_id
         LEFT JOIN users   ru ON ru.id  = rm.sender_id
         WHERE m.id > :sid
           AND ((m.sender_id = :me AND m.recipient_id = :cid)
             OR (m.sender_id = :cid2 AND m.recipient_id = :me2))
         ORDER BY m.created_at ASC, m.id ASC",
        [':sid' => $sinceId, ':me' => $me, ':cid' => $cid, ':cid2' => $cid, ':me2' => $me]
    ) ?: [];
    _attachDmFiles($db, $messages);
    _attachReactions($db, $messages, $me);
    _maskDeletedMessages($messages);

    $isTyping = false;
    try {
        $t = $db->queryOne(
            "SELECT updated_at FROM typing_status WHERE user_id = :cid AND contact_id = :me AND updated_at >= DATE_SUB(NOW(), INTERVAL 5 SECOND)",
            [':cid' => $cid, ':me' => $me]
        );
        $isTyping = (bool)$t;
    } catch (\Exception $e) {}

    $online = _isOnline($db, $cid);
    ob_end_clean(); successResponse(['messages' => $messages, 'is_typing' => $isTyping, 'is_online' => $online]);
}

/* ════════════════════════════════════════════════════════
   DIRECT MESSAGES — contacts (role-aware)
════════════════════════════════════════════════════════ */
function pulseContacts($db) {
    $me   = _me();     if (!$me)   { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $role = _myRole();

    if ($role === 'admin') {
        $rows = $db->query(
            "SELECT id, full_name, photo_url, role FROM users
             WHERE role IN ('admin','teacher','parent') AND id != :me
             ORDER BY FIELD(role,'admin','teacher','parent'), full_name",
            [':me' => $me]
        ) ?: [];
    } else {
        /* Teacher: admins + other teachers + parents of their class's students */
        $staffRows = $db->query(
            "SELECT id, full_name, photo_url, role FROM users
             WHERE role IN ('admin','teacher') AND id != :me
             ORDER BY FIELD(role,'admin','teacher'), full_name",
            [':me' => $me]
        ) ?: [];
        $parentRows = [];
        $classId = _resolveTeacherClassId($db);
        if ($classId) {
            $parentRows = $db->query(
                "SELECT DISTINCT u.id, u.full_name, u.photo_url, u.role
                 FROM users u
                 JOIN parents p ON p.user_id = u.id
                 JOIN students s ON s.id = p.student_id
                 WHERE s.class_id = :cid
                 ORDER BY u.full_name",
                [':cid' => $classId]
            ) ?: [];
        }
        $seen = []; $rows = [];
        foreach (array_merge($staffRows, $parentRows) as $r) {
            if (!isset($seen[$r['id']])) { $seen[$r['id']] = true; $rows[] = $r; }
        }
    }
    ob_end_clean(); successResponse($rows);
}

/* ════════════════════════════════════════════════════════
   DIRECT MESSAGES — typing / presence
════════════════════════════════════════════════════════ */
function pulseTypingStatus($db) {
    $me  = _me(); $cid = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$cid) { ob_end_clean(); errorResponse('contact_id required'); }
    $isTyping = false;
    try {
        $t = $db->queryOne(
            "SELECT updated_at FROM typing_status WHERE user_id = :cid AND contact_id = :me AND updated_at >= DATE_SUB(NOW(), INTERVAL 5 SECOND)",
            [':cid' => $cid, ':me' => $me]
        );
        $isTyping = (bool)$t;
    } catch (\Exception $e) {}
    $online = _isOnline($db, $cid);
    ob_end_clean(); successResponse(['is_typing' => $isTyping, 'is_online' => $online]);
}

/* ════════════════════════════════════════════════════════
   DIRECT MESSAGES — send / send_file
════════════════════════════════════════════════════════ */

/**
 * Notify a message recipient.
 * Admin/teacher bell reads pulse_alert_recipients; parent bell reads notifications table.
 * This helper writes to both so all roles see the notification.
 */
function _pulseInsertNotification($db, $recipientId, $title, $body, $actualSenderId = 0) {
    $userRow = $db->queryOne("SELECT role FROM users WHERE id = :id", [':id' => $recipientId]);
    $role    = $userRow ? $userRow['role'] : 'parent';
    /* Use the real sender; fall back to recipient only if nothing else is available */
    $senderId = $actualSenderId ?: $recipientId;

    if (in_array($role, ['admin','teacher'], true)) {
        // Admin/teacher bell reads pulse_alert_recipients
        try {
            $targetRole = $role; // 'admin' or 'teacher' — both valid ENUM values
            $aid = $db->execute(
                "INSERT INTO pulse_alerts
                    (sender_id, title, body, priority, target_type, target_role, target_user_id, created_at)
                 VALUES (:sid, :t, :b, 'medium', 'user', :tr, :uid, NOW())",
                [':sid'=>$senderId, ':t'=>$title, ':b'=>$body,
                 ':tr'=>$targetRole, ':uid'=>$recipientId]
            );
            if ($aid) {
                $db->execute(
                    "INSERT IGNORE INTO pulse_alert_recipients (alert_id, user_id, is_read)
                     VALUES (:aid, :uid, 0)",
                    [':aid'=>$aid, ':uid'=>$recipientId]
                );
            }
        } catch (\Exception $e) { error_log('_pulseInsertNotification pulse: '.$e->getMessage()); }
    }
    // Always also write to notifications table (parent bell + legacy display)
    try {
        $db->execute(
            "INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
             VALUES (:uid, :title, :msg, 'message', 0, NOW())",
            [':uid' => $recipientId, ':title' => $title, ':msg' => $body]
        );
    } catch (\Exception $e) { error_log('_pulseInsertNotification notif: '.$e->getMessage()); }
}

function pulseSend($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $recipientId = isset($body['recipient_id']) ? (int)$body['recipient_id'] : 0;
    $message     = isset($body['message'])      ? trim($body['message'])      : '';
    $subject     = isset($body['subject'])      ? sanitize($body['subject'])  : '';
    $replyToId   = isset($body['reply_to_id'])  ? (int)$body['reply_to_id']  : null;
    if (!$recipientId) { ob_end_clean(); errorResponse('recipient_id required'); }
    if ($message === '') { ob_end_clean(); errorResponse('message required'); }

    $msgId = $db->execute(
        "INSERT INTO messages (sender_id, recipient_id, subject, message, reply_to_id, is_read, has_file, created_at)
         VALUES (:sid, :rid, :sub, :msg, :rto, 0, 0, NOW())",
        [':sid' => $me, ':rid' => $recipientId, ':sub' => $subject,
         ':msg' => $message, ':rto' => $replyToId ?: null]
    );
    if (!$msgId) { ob_end_clean(); errorResponse('Failed to send', 500); }

    $sender = $db->queryOne("SELECT full_name FROM users WHERE id = :id", [':id' => $me]);
    $name   = $sender ? $sender['full_name'] : 'User';
    _pulseInsertNotification($db, $recipientId, 'New message from ' . $name, mb_substr($message, 0, 100), $me);

    ob_end_clean(); successResponse([
        'id' => $msgId, 'sender_id' => $me, 'recipient_id' => $recipientId,
        'subject' => $subject, 'message' => $message,
        'reply_to_id' => $replyToId, 'reply_to_message' => null, 'reply_to_sender' => null,
        'is_read' => 0, 'has_file' => 0,
        'edited_at' => null, 'deleted_at' => null, 'is_deleted' => false, 'reactions' => [],
        'files' => [], 'created_at' => date('Y-m-d H:i:s'),
    ], 'Sent');
}

function pulseSendFile($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $recipientId = isset($_POST['recipient_id']) ? (int)$_POST['recipient_id'] : 0;
    $message     = isset($_POST['message'])      ? trim($_POST['message'])      : '';
    $subject     = isset($_POST['subject'])      ? sanitize($_POST['subject'])  : '';
    $replyToId   = isset($_POST['reply_to_id'])  ? (int)$_POST['reply_to_id']  : null;
    if (!$recipientId) { ob_end_clean(); errorResponse('recipient_id required'); }
    $dir  = dirname(__DIR__) . '/uploads/messages/';
    $info = _uploadFile('attachment', $dir);
    if (!$info) { ob_end_clean(); errorResponse('No file provided or upload error'); }

    $msgId = $db->execute(
        "INSERT INTO messages (sender_id, recipient_id, subject, message, reply_to_id, is_read, has_file, created_at)
         VALUES (:sid, :rid, :sub, :msg, :rto, 0, 1, NOW())",
        [':sid' => $me, ':rid' => $recipientId, ':sub' => $subject,
         ':msg' => $message, ':rto' => $replyToId ?: null]
    );
    if (!$msgId) { ob_end_clean(); errorResponse('Failed to save message', 500); }
    try {
        $db->execute(
            "INSERT INTO message_files (message_id, original_name, stored_name, mime_type, file_size, created_at)
             VALUES (:mid, :orig, :stored, :mime, :size, NOW())",
            [':mid' => $msgId, ':orig' => $info['original_name'], ':stored' => $info['stored_name'],
             ':mime' => $info['mime_type'], ':size' => $info['file_size']]
        );
    } catch (\Exception $e) {}
    $sender = $db->queryOne("SELECT full_name FROM users WHERE id = :id", [':id' => $me]);
    $name   = $sender ? $sender['full_name'] : 'User';
    _pulseInsertNotification($db, $recipientId, 'File from ' . $name, "\xf0\x9f\x93\x8e " . $info['original_name'], $me);
    ob_end_clean(); successResponse([
        'id' => $msgId, 'sender_id' => $me, 'recipient_id' => $recipientId,
        'subject' => $subject, 'message' => $message, 'is_read' => 0, 'has_file' => 1,
        'edited_at' => null, 'deleted_at' => null, 'is_deleted' => false, 'reactions' => [],
        'files' => [[
            'file_id' => null, 'original_name' => $info['original_name'],
            'mime_type' => $info['mime_type'], 'file_size' => $info['file_size'],
            'url' => '/nsms/uploads/messages/' . $info['stored_name'],
        ]],
        'created_at' => date('Y-m-d H:i:s'),
    ], 'File sent');
}

function pulseMarkRead($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $cid = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$cid) { ob_end_clean(); errorResponse('contact_id required'); }
    $db->execute(
        "UPDATE messages SET is_read = 1, read_at = NOW() WHERE sender_id = :cid AND recipient_id = :me AND is_read = 0",
        [':cid' => $cid, ':me' => $me]
    );
    ob_end_clean(); successResponse(null, 'Marked read');
}

function pulseMarkGroupRead($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$me || !$gid) { ob_end_clean(); errorResponse('group_id required'); }
    /* Find the latest message id in this group */
    $latest = $db->queryOne(
        "SELECT MAX(id) AS max_id FROM pulse_group_messages WHERE group_id = :g",
        [':g' => $gid]
    );
    $maxId = $latest ? (int)$latest['max_id'] : 0;
    try {
        $db->execute(
            "INSERT INTO pulse_group_message_reads (group_id, user_id, last_read_id)
             VALUES (:g, :u, :mid)
             ON DUPLICATE KEY UPDATE last_read_id = GREATEST(last_read_id, :mid2)",
            [':g' => $gid, ':u' => $me, ':mid' => $maxId, ':mid2' => $maxId]
        );
    } catch (\Exception $e) { /* table may not exist yet — silent */ }
    ob_end_clean(); successResponse(null, 'Group marked read');
}

function pulseSetTyping($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); $cid = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$cid) { ob_end_clean(); errorResponse('contact_id required'); }
    try {
        $db->execute(
            "INSERT INTO typing_status (user_id, contact_id, updated_at) VALUES (:me, :cid, NOW())
             ON DUPLICATE KEY UPDATE updated_at = NOW()",
            [':me' => $me, ':cid' => $cid]
        );
    } catch (\Exception $e) {}
    ob_end_clean(); successResponse(null);
}

function pulseHeartbeat($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    _pulsePresence($db);
    ob_end_clean(); successResponse(null);
}

/* ════════════════════════════════════════════════════════
   COLLABORATION — groups
════════════════════════════════════════════════════════ */
function pulseMyGroups($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT g.id, g.name, g.description, g.avatar_color, g.created_by, g.created_at,
                m.role AS my_role,
                (SELECT COUNT(*) FROM pulse_group_members WHERE group_id = g.id) AS member_count,
                (SELECT COUNT(*) FROM pulse_group_messages WHERE group_id = g.id) AS message_count,
                (SELECT pgm2.message FROM pulse_group_messages pgm2 WHERE pgm2.group_id = g.id ORDER BY pgm2.created_at DESC, pgm2.id DESC LIMIT 1) AS last_message,
                (SELECT pgm3.created_at FROM pulse_group_messages pgm3 WHERE pgm3.group_id = g.id ORDER BY pgm3.created_at DESC, pgm3.id DESC LIMIT 1) AS last_at
         FROM pulse_groups g
         JOIN pulse_group_members m ON m.group_id = g.id AND m.user_id = :me
         ORDER BY COALESCE((SELECT pgm4.created_at FROM pulse_group_messages pgm4 WHERE pgm4.group_id = g.id ORDER BY pgm4.created_at DESC LIMIT 1), g.created_at) DESC",
        [':me' => $me]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function pulseAvailableGroups($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT g.id, g.name, g.description, g.avatar_color, g.created_at,
                (SELECT COUNT(*) FROM pulse_group_members WHERE group_id = g.id) AS member_count,
                CASE WHEN (SELECT 1 FROM pulse_group_members WHERE group_id = g.id AND user_id = :me1) IS NOT NULL THEN 1 ELSE 0 END AS is_member
         FROM pulse_groups g
         ORDER BY g.name",
        [':me1' => $me]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function pulseGroupThread($db) {
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$gid) { ob_end_clean(); errorResponse('group_id required'); }
    /* check membership */
    $mem = $db->queryOne("SELECT user_id FROM pulse_group_members WHERE group_id = :g AND user_id = :u", [':g' => $gid, ':u' => $me]);
    if (!$mem) { ob_end_clean(); errorResponse('Not a member of this group', 403); }

    $msgs = $db->query(
        "SELECT pgm.id, pgm.group_id, pgm.sender_id, pgm.message, pgm.has_file, pgm.created_at,
                u.full_name AS sender_name, u.photo_url AS sender_photo
         FROM pulse_group_messages pgm
         JOIN users u ON u.id = pgm.sender_id
         WHERE pgm.group_id = :g
         ORDER BY pgm.created_at ASC, pgm.id ASC",
        [':g' => $gid]
    ) ?: [];
    _attachGroupFiles($db, $msgs);

    $group = $db->queryOne("SELECT id, name, description, avatar_color FROM pulse_groups WHERE id = :g", [':g' => $gid]);
    ob_end_clean(); successResponse(['messages' => $msgs, 'group' => $group]);
}

function pulseGroupThreadUpdates($db) {
    $me     = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid    = isset($_GET['group_id'])  ? (int)$_GET['group_id']  : 0;
    $sinceId = isset($_GET['since_id']) ? (int)$_GET['since_id']  : 0;
    if (!$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $mem = $db->queryOne("SELECT user_id FROM pulse_group_members WHERE group_id = :g AND user_id = :u", [':g' => $gid, ':u' => $me]);
    if (!$mem) { ob_end_clean(); errorResponse('Not a member', 403); }
    $msgs = $db->query(
        "SELECT pgm.id, pgm.group_id, pgm.sender_id, pgm.message, pgm.has_file, pgm.created_at,
                u.full_name AS sender_name, u.photo_url AS sender_photo
         FROM pulse_group_messages pgm
         JOIN users u ON u.id = pgm.sender_id
         WHERE pgm.group_id = :g AND pgm.id > :sid
         ORDER BY pgm.created_at ASC, pgm.id ASC",
        [':g' => $gid, ':sid' => $sinceId]
    ) ?: [];
    _attachGroupFiles($db, $msgs);
    ob_end_clean(); successResponse(['messages' => $msgs]);
}

function pulseGroupMembers($db) {
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $rows = $db->query(
        "SELECT u.id, u.full_name, u.photo_url, u.role, m.role AS group_role, m.joined_at
         FROM pulse_group_members m
         JOIN users u ON u.id = m.user_id
         WHERE m.group_id = :g
         ORDER BY FIELD(m.role,'owner','member'), u.full_name",
        [':g' => $gid]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function pulseCreateGroup($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $name  = isset($body['name'])        ? sanitize($body['name'])        : '';
    $desc  = isset($body['description']) ? sanitize($body['description']) : '';
    $color = isset($body['color'])       ? sanitize($body['color'])       : '#10B981';
    if (!$name) { ob_end_clean(); errorResponse('Group name required'); }
    $gid = $db->execute(
        "INSERT INTO pulse_groups (name, description, avatar_color, created_by, created_at) VALUES (:n, :d, :c, :cb, NOW())",
        [':n' => $name, ':d' => $desc, ':c' => $color, ':cb' => $me]
    );
    if (!$gid) { ob_end_clean(); errorResponse('Failed to create group', 500); }
    $db->execute(
        "INSERT INTO pulse_group_members (group_id, user_id, role, joined_at) VALUES (:g, :u, 'owner', NOW())",
        [':g' => $gid, ':u' => $me]
    );
    ob_end_clean(); successResponse(['id' => $gid, 'name' => $name, 'description' => $desc, 'avatar_color' => $color], 'Group created');
}

function pulseJoinGroup($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$me || !$gid) { ob_end_clean(); errorResponse('group_id required'); }
    try {
        $db->execute(
            "INSERT IGNORE INTO pulse_group_members (group_id, user_id, role, joined_at) VALUES (:g, :u, 'member', NOW())",
            [':g' => $gid, ':u' => $me]
        );
    } catch (\Exception $e) { ob_end_clean(); errorResponse('Failed to join', 500); }
    ob_end_clean(); successResponse(null, 'Joined group');
}

function pulseLeaveGroup($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$me || !$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $db->execute("DELETE FROM pulse_group_members WHERE group_id = :g AND user_id = :u", [':g' => $gid, ':u' => $me]);
    ob_end_clean(); successResponse(null, 'Left group');
}

function pulseGroupSend($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $gid  = isset($body['group_id']) ? (int)$body['group_id'] : 0;
    $msg  = isset($body['message'])  ? trim($body['message'])  : '';
    if (!$gid || $msg === '') { ob_end_clean(); errorResponse('group_id and message required'); }
    $mem = $db->queryOne("SELECT user_id FROM pulse_group_members WHERE group_id = :g AND user_id = :u", [':g' => $gid, ':u' => $me]);
    if (!$mem) { ob_end_clean(); errorResponse('Not a member of this group', 403); }
    $mid = $db->execute(
        "INSERT INTO pulse_group_messages (group_id, sender_id, message, has_file, created_at) VALUES (:g, :u, :m, 0, NOW())",
        [':g' => $gid, ':u' => $me, ':m' => $msg]
    );
    $sender = $db->queryOne("SELECT full_name, photo_url FROM users WHERE id = :id", [':id' => $me]);
    ob_end_clean(); successResponse([
        'id' => $mid, 'group_id' => $gid, 'sender_id' => $me, 'message' => $msg,
        'has_file' => 0, 'files' => [], 'created_at' => date('Y-m-d H:i:s'),
        'sender_name' => $sender ? $sender['full_name'] : '', 'sender_photo' => $sender ? $sender['photo_url'] : '',
    ]);
}

function pulseGroupSendFile($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid = isset($_POST['group_id']) ? (int)$_POST['group_id'] : 0;
    $msg = isset($_POST['message'])  ? trim($_POST['message'])  : '';
    if (!$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $mem = $db->queryOne("SELECT user_id FROM pulse_group_members WHERE group_id = :g AND user_id = :u", [':g' => $gid, ':u' => $me]);
    if (!$mem) { ob_end_clean(); errorResponse('Not a member', 403); }
    $dir  = dirname(__DIR__) . '/uploads/messages/';
    $info = _uploadFile('attachment', $dir);
    if (!$info) { ob_end_clean(); errorResponse('No file provided'); }
    $mid = $db->execute(
        "INSERT INTO pulse_group_messages (group_id, sender_id, message, has_file, created_at) VALUES (:g, :u, :m, 1, NOW())",
        [':g' => $gid, ':u' => $me, ':m' => $msg]
    );
    $db->execute(
        "INSERT INTO pulse_group_files (group_message_id, original_name, stored_name, mime_type, file_size, created_at) VALUES (:mid, :orig, :stored, :mime, :size, NOW())",
        [':mid' => $mid, ':orig' => $info['original_name'], ':stored' => $info['stored_name'], ':mime' => $info['mime_type'], ':size' => $info['file_size']]
    );
    $sender = $db->queryOne("SELECT full_name, photo_url FROM users WHERE id = :id", [':id' => $me]);
    ob_end_clean(); successResponse([
        'id' => $mid, 'group_id' => $gid, 'sender_id' => $me, 'message' => $msg, 'has_file' => 1,
        'files' => [['original_name' => $info['original_name'], 'mime_type' => $info['mime_type'], 'file_size' => $info['file_size'], 'url' => '/nsms/uploads/messages/' . $info['stored_name']]],
        'created_at' => date('Y-m-d H:i:s'),
        'sender_name' => $sender ? $sender['full_name'] : '', 'sender_photo' => $sender ? $sender['photo_url'] : '',
    ]);
}

/* ════════════════════════════════════════════════════════
   COLLABORATION — resources
════════════════════════════════════════════════════════ */
function pulseResources($db) {
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    $cond = $gid ? "WHERE r.group_id = :g" : "WHERE r.group_id IS NULL";
    $params = $gid ? [':g' => $gid] : [];
    $rows = $db->query(
        "SELECT r.id, r.group_id, r.shared_by, r.title, r.description, r.original_name,
                r.stored_name, r.mime_type, r.file_size, r.download_count, r.created_at,
                u.full_name AS shared_by_name, u.photo_url AS shared_by_photo
         FROM pulse_resources r
         JOIN users u ON u.id = r.shared_by
         $cond
         ORDER BY r.created_at DESC",
        $params
    ) ?: [];
    foreach ($rows as &$r) { $r['url'] = '/nsms/uploads/resources/' . $r['stored_name']; }
    unset($r);
    ob_end_clean(); successResponse($rows);
}

function pulseUploadResource($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me    = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid   = isset($_POST['group_id'])    ? (int)$_POST['group_id']         : null;
    $title = isset($_POST['title'])       ? sanitize($_POST['title'])        : '';
    $desc  = isset($_POST['description']) ? sanitize($_POST['description'])  : '';
    if (!$title) { ob_end_clean(); errorResponse('title required'); }
    $dir  = dirname(__DIR__) . '/uploads/resources/';
    $info = _uploadFile('attachment', $dir);
    if (!$info) { ob_end_clean(); errorResponse('No file provided'); }
    $rid = $db->execute(
        "INSERT INTO pulse_resources (group_id, shared_by, title, description, original_name, stored_name, mime_type, file_size, created_at)
         VALUES (:g, :u, :title, :desc, :orig, :stored, :mime, :size, NOW())",
        [':g' => $gid ?: null, ':u' => $me, ':title' => $title, ':desc' => $desc,
         ':orig' => $info['original_name'], ':stored' => $info['stored_name'],
         ':mime' => $info['mime_type'], ':size' => $info['file_size']]
    );
    ob_end_clean(); successResponse(['id' => $rid, 'title' => $title, 'original_name' => $info['original_name']], 'Resource uploaded');
}

/* ════════════════════════════════════════════════════════
   ALERTS
════════════════════════════════════════════════════════ */
function pulseMyAlerts($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT a.id, a.sender_id, a.title, a.body, a.priority, a.target_type, a.target_role, a.created_at,
                r.is_read, r.read_at,
                u.full_name AS sender_name, u.photo_url AS sender_photo, u.role AS sender_role
         FROM pulse_alert_recipients r
         JOIN pulse_alerts a ON a.id = r.alert_id
         JOIN users u ON u.id = a.sender_id
         WHERE r.user_id = :me
         ORDER BY a.created_at DESC",
        [':me' => $me]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function pulseSentAlerts($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT a.id, a.title, a.body, a.priority, a.target_type, a.target_role, a.target_user_id, a.created_at,
                (SELECT COUNT(*) FROM pulse_alert_recipients WHERE alert_id = a.id) AS recipient_count,
                (SELECT COUNT(*) FROM pulse_alert_recipients WHERE alert_id = a.id AND is_read = 1) AS read_count
         FROM pulse_alerts a
         WHERE a.sender_id = :me
         ORDER BY a.created_at DESC",
        [':me' => $me]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function pulseSendAlert($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me   = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $role = _myRole();
    $body = json_decode(file_get_contents('php://input'), true) ?: [];

    $title       = isset($body['title'])          ? sanitize($body['title'])              : '';
    $alertBody   = isset($body['body'])            ? sanitize($body['body'])               : '';
    $priority    = isset($body['priority'])        ? $body['priority']                     : 'medium';
    $targetType  = isset($body['target_type'])     ? $body['target_type']                  : 'role';
    $targetRole  = isset($body['target_role'])     ? $body['target_role']                  : 'all';
    $targetUser  = isset($body['target_user_id'])  ? (int)$body['target_user_id']           : null;

    if (!$title || !$alertBody) { ob_end_clean(); errorResponse('title and body required'); }
    if (!in_array($priority, ['low','medium','high','urgent'], true)) $priority = 'medium';

    /* Teachers can only alert admin or their class's parents */
    if ($role === 'teacher') {
        if (!in_array($targetRole, ['admin','parent'], true) && $targetType === 'role') {
            ob_end_clean(); errorResponse('Teachers can only alert admin or parents');
        }
    }

    $aid = $db->execute(
        "INSERT INTO pulse_alerts (sender_id, title, body, priority, target_type, target_role, target_user_id, created_at)
         VALUES (:sid, :t, :b, :p, :tt, :tr, :tu, NOW())",
        [':sid' => $me, ':t' => $title, ':b' => $alertBody, ':p' => $priority,
         ':tt' => $targetType, ':tr' => $targetRole, ':tu' => $targetUser ?: null]
    );
    if (!$aid) { ob_end_clean(); errorResponse('Failed to create alert', 500); }

    /* Resolve recipients */
    if ($targetType === 'user' && $targetUser) {
        $db->execute("INSERT IGNORE INTO pulse_alert_recipients (alert_id, user_id) VALUES (:aid, :uid)", [':aid' => $aid, ':uid' => $targetUser]);
    } elseif ($targetType === 'role' && $targetRole !== 'all') {
        $users = $db->query("SELECT id FROM users WHERE role = :r AND id != :me", [':r' => $targetRole, ':me' => $me]) ?: [];
        foreach ($users as $u) {
            $db->execute("INSERT IGNORE INTO pulse_alert_recipients (alert_id, user_id) VALUES (:aid, :uid)", [':aid' => $aid, ':uid' => $u['id']]);
        }
    } else {
        $users = $db->query("SELECT id FROM users WHERE id != :me AND role IN ('admin','teacher','parent')", [':me' => $me]) ?: [];
        foreach ($users as $u) {
            $db->execute("INSERT IGNORE INTO pulse_alert_recipients (alert_id, user_id) VALUES (:aid, :uid)", [':aid' => $aid, ':uid' => $u['id']]);
        }
    }

    // Mirror to notifications table for parents (bell + history)
    try {
        $parentRecipients = $db->query(
            "SELECT par.user_id FROM pulse_alert_recipients par
             JOIN users u ON u.id = par.user_id AND u.role = 'parent'
             WHERE par.alert_id = :aid",
            array(':aid' => $aid)
        ) ?: array();
        foreach ($parentRecipients as $pr) {
            $db->execute(
                "INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
                 VALUES (:uid, :t, :m, 'pulse_alert', 0, NOW())",
                array(':uid' => (int)$pr['user_id'], ':t' => $title, ':m' => $alertBody)
            );
        }
    } catch (Exception $e) {
        error_log('pulseSendAlert notifications mirror: ' . $e->getMessage());
    }

    ob_end_clean(); successResponse(['id' => $aid], 'Alert sent');
}

function pulseMarkAlertRead($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $aid = isset($_GET['alert_id']) ? (int)$_GET['alert_id'] : 0;
    if (!$me || !$aid) { ob_end_clean(); errorResponse('alert_id required'); }
    $db->execute(
        "UPDATE pulse_alert_recipients SET is_read = 1, read_at = NOW() WHERE alert_id = :aid AND user_id = :me AND is_read = 0",
        [':aid' => $aid, ':me' => $me]
    );
    ob_end_clean(); successResponse(null, 'Marked read');
}

/* ════════════════════════════════════════════════════════
   BROADCAST — announcements
════════════════════════════════════════════════════════ */
function pulseAnnouncements($db) {
    $me   = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $role = _myRole();
    $rows = $db->query(
        "SELECT a.id, a.author_id, a.title, a.body, a.target_role, a.pinned, a.created_at, a.expires_at,
                u.full_name AS author_name, u.photo_url AS author_photo
         FROM pulse_announcements a
         JOIN users u ON u.id = a.author_id
         WHERE (a.target_role = 'all' OR a.target_role = :role)
           AND (a.expires_at IS NULL OR a.expires_at > NOW())
         ORDER BY a.pinned DESC, a.created_at DESC",
        [':role' => $role]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function pulsePostAnnouncement($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    _requireAdmin();
    $me   = _me();
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $title      = isset($body['title'])       ? sanitize($body['title'])       : '';
    $content    = isset($body['body'])        ? sanitize($body['body'])        : '';
    $targetRole = isset($body['target_role']) ? $body['target_role']           : 'all';
    $pinned     = isset($body['pinned'])      ? (int)$body['pinned']           : 0;
    $expiresAt  = isset($body['expires_at'])  ? $body['expires_at']            : null;
    if (!$title || !$content) { ob_end_clean(); errorResponse('title and body required'); }
    $aid = $db->execute(
        "INSERT INTO pulse_announcements (author_id, title, body, target_role, pinned, created_at, expires_at)
         VALUES (:uid, :t, :b, :tr, :p, NOW(), :exp)",
        [':uid' => $me, ':t' => $title, ':b' => $content, ':tr' => $targetRole, ':p' => $pinned, ':exp' => $expiresAt]
    );
    ob_end_clean(); successResponse(['id' => $aid, 'title' => $title], 'Announcement posted');
}

function pulseDeleteAnnouncement($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    _requireAdmin();
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) { ob_end_clean(); errorResponse('id required'); }
    $db->execute("DELETE FROM pulse_announcements WHERE id = :id", [':id' => $id]);
    ob_end_clean(); successResponse(null, 'Deleted');
}

/* ════════════════════════════════════════════════════════
   BROADCAST — newsletters
════════════════════════════════════════════════════════ */
function pulseNewsletters($db) {
    $me   = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $role = _myRole();
    $rows = $db->query(
        "SELECT n.id, n.author_id, n.subject, n.content, n.target_role, n.created_at,
                u.full_name AS author_name, u.photo_url AS author_photo
         FROM pulse_newsletters n
         JOIN users u ON u.id = n.author_id
         WHERE n.target_role = 'all' OR n.target_role = :role
         ORDER BY n.created_at DESC",
        [':role' => $role]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function pulsePostNewsletter($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    _requireAdmin();
    $me   = _me();
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $subject    = isset($body['subject'])     ? sanitize($body['subject'])     : '';
    $content    = isset($body['content'])     ? sanitize($body['content'])     : '';
    $targetRole = isset($body['target_role']) ? $body['target_role']           : 'all';
    if (!$subject || !$content) { ob_end_clean(); errorResponse('subject and content required'); }
    $nid = $db->execute(
        "INSERT INTO pulse_newsletters (author_id, subject, content, target_role, created_at) VALUES (:uid, :s, :c, :tr, NOW())",
        [':uid' => $me, ':s' => $subject, ':c' => $content, ':tr' => $targetRole]
    );
    ob_end_clean(); successResponse(['id' => $nid], 'Newsletter posted');
}

function pulseDeleteNewsletter($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    _requireAdmin();
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) { ob_end_clean(); errorResponse('id required'); }
    $db->execute("DELETE FROM pulse_newsletters WHERE id = :id", [':id' => $id]);
    ob_end_clean(); successResponse(null, 'Deleted');
}

/* ════════════════════════════════════════════════════════
   UNREAD COUNTS (for tab badges)
════════════════════════════════════════════════════════ */
function pulseUnreadCounts($db) {
    $me   = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    /* Unread DMs */
    $dmRow = $db->queryOne(
        "SELECT COUNT(*) AS cnt FROM messages WHERE recipient_id = :me AND is_read = 0",
        [':me' => $me]
    );
    $dmCount = $dmRow ? (int)$dmRow['cnt'] : 0;
    /* Unread alerts */
    $alertRow = $db->queryOne(
        "SELECT COUNT(*) AS cnt FROM pulse_alert_recipients WHERE user_id = :me AND is_read = 0",
        [':me' => $me]
    );
    $alertCount = $alertRow ? (int)$alertRow['cnt'] : 0;
    /* Unread group messages — count messages newer than last read per group */
    $collabCount = 0;
    try {
        $collabRow = $db->queryOne(
            "SELECT COUNT(*) AS cnt
             FROM pulse_group_members gm
             JOIN pulse_group_messages pgm ON pgm.group_id = gm.group_id
             LEFT JOIN pulse_group_message_reads r
                    ON r.group_id = gm.group_id AND r.user_id = :me2
             WHERE gm.user_id = :me3
               AND pgm.sender_id != :me4
               AND pgm.id > COALESCE(r.last_read_id, 0)",
            [':me2' => $me, ':me3' => $me, ':me4' => $me]
        );
        $collabCount = $collabRow ? (int)$collabRow['cnt'] : 0;
    } catch (\Exception $e) { $collabCount = 0; }
    ob_end_clean(); successResponse(['dm' => $dmCount, 'alerts' => $alertCount, 'collab' => $collabCount, 'broadcast' => 0]);
}