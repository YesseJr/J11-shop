<?php
require_once __DIR__ . '/config.php';   // adjust path if needed — same as your other api files
header('Content-Type: application/json');

session_start();
$adminId = $_SESSION['admin_id'] ?? null;
if (!$adminId) {
    echo json_encode(['success' => false, 'message' => 'Unauthenticated']); exit;
}

/* ── GET: return current profile ── */
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $row = $db->queryOne(
        "SELECT id, full_name, email, role, photo_url FROM users WHERE id = :id",
        [':id' => $adminId]
    );
    if ($row) {
        echo json_encode(['success' => true, 'data' => $row]);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
    exit;
}

/* ── POST: update profile ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body      = json_decode(file_get_contents('php://input'), true) ?? [];
    $full_name = trim($body['full_name'] ?? '');
    $email     = trim($body['email']     ?? '');
    $password  = $body['password']       ?? '';

    if (!$full_name || !$email) {
        echo json_encode(['success' => false, 'message' => 'Name and email are required']); exit;
    }

    // Check email uniqueness (exclude self)
    $conflict = $db->queryOne(
        "SELECT id FROM users WHERE email = :email AND id != :id",
        [':email' => $email, ':id' => $adminId]
    );
    if ($conflict) {
        echo json_encode(['success' => false, 'message' => 'Email already in use']); exit;
    }

    if ($password) {
        // Update with new password
        $db->execute(
            "UPDATE users SET full_name = :name, email = :email, password = :pass WHERE id = :id",
            [':name' => $full_name, ':email' => $email, ':pass' => password_hash($password, PASSWORD_DEFAULT), ':id' => $adminId]
        );
    } else {
        // Update without touching password
        $db->execute(
            "UPDATE users SET full_name = :name, email = :email WHERE id = :id",
            [':name' => $full_name, ':email' => $email, ':id' => $adminId]
        );
    }

    $updated = $db->queryOne(
        "SELECT id, full_name, email, role, photo_url FROM users WHERE id = :id",
        [':id' => $adminId]
    );
    echo json_encode(['success' => true, 'data' => $updated]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Method not allowed']);