<?php
/**
 * NSMS Synchronization API
 * POST actions: push | pull | run | register_device
 * GET actions:  health | status | sessions | conflicts
 *
 * Does not replace existing CRUD APIs. Existing MySQL app continues to work online.
 */
ob_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/sync/SyncConfig.php';
require_once __DIR__ . '/../includes/sync/DeviceIdentity.php';
require_once __DIR__ . '/../includes/sync/SyncMysql.php';
require_once __DIR__ . '/../includes/sync/SqliteStore.php';
require_once __DIR__ . '/../includes/sync/SyncEngine.php';
require_once __DIR__ . '/../includes/sync/OfflineAuth.php';
require_once __DIR__ . '/../includes/sync/OfflineData.php';
require_once __DIR__ . '/../includes/sync/OfflineAdmin.php';

if (function_exists('applyApiHeaders')) {
    applyApiHeaders();
}

$action = isset($_GET['action']) ? trim($_GET['action']) : '';
$method = $_SERVER['REQUEST_METHOD'];

function syncOk($data = null, $msg = 'OK') {
    ob_end_clean();
    echo json_encode(array('success' => true, 'data' => $data, 'message' => $msg));
    exit;
}
function syncErr($msg, $code = 400) {
    http_response_code($code);
    ob_end_clean();
    echo json_encode(array('success' => false, 'error' => $msg));
    exit;
}

// Health is public (used for connectivity probe) — no secrets
if ($action === 'health') {
    $dbOk = false;
    try {
        $db = new Database();
        $c = $db->connect();
        $dbOk = (bool)$c;
        if ($dbOk && method_exists('Database', 'clearDownCache')) {
            Database::clearDownCache();
        }
    } catch (Exception $e) {
        $dbOk = false;
    }
    $sqliteAuth = class_exists('OfflineAuth') ? OfflineAuth::sqliteReady() : array('ok' => false);
            syncOk(array(
                'offline_auth' => $sqliteAuth,

        'status' => $dbOk ? 'ok' : 'degraded',
        'database' => $dbOk,
        'time' => date('c'),
        'entities' => SyncConfig::entities(),
    ), $dbOk ? 'Healthy' : 'Database unavailable');
}

// Remaining actions require auth
if (function_exists('requireAuth')) {
    requireAuth();
} else {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['user_id'])) syncErr('Unauthorized', 401);
}

$userId = function_exists('getCurrentUserId') ? getCurrentUserId() : (int)($_SESSION['user_id'] ?? 0);
$role = function_exists('getCurrentUserRole') ? getCurrentUserRole() : ($_SESSION['role'] ?? '');

try {
    $db = new Database();
    if (!$db->connect()) syncErr('Database connection failed', 500);
    $mysqlOnline = true; // reached only when MySQL connect succeeded
    $syncDb = new SyncMysql($db);

    $body = array();
    if ($method === 'POST') {
        if (!empty($GLOBALS['NSMS_JSON_BODY']) && is_array($GLOBALS['NSMS_JSON_BODY'])) {
            $body = $GLOBALS['NSMS_JSON_BODY'];
        } else {
            $raw = file_get_contents('php://input');
            $body = json_decode($raw, true);
            if (!is_array($body)) $body = $_POST;
        }
    }

    switch ($action) {
        case 'status': {
            $engine = new SyncEngine();
            $local = $engine->status();
            $remote = $syncDb->stats();
            $local['offline_users_cached'] = class_exists('OfflineAuth') ? OfflineAuth::countCached() : 0;
            $local['offline_mode_session'] = !empty($_SESSION['offline_mode']);
            syncOk(array_merge($local, array('server' => $remote)));
            break;
        }

        case 'register_device': {
            $deviceUuid = isset($body['device_uuid']) ? trim($body['device_uuid']) : DeviceIdentity::getUuid();
            $name = isset($body['device_name']) ? trim($body['device_name']) : (isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 100) : 'NSMS Client');
            $id = $syncDb->registerDevice($deviceUuid, $userId, $name);
            $sqliteAuth = class_exists('OfflineAuth') ? OfflineAuth::sqliteReady() : array('ok' => false);
            syncOk(array(
                'offline_auth' => $sqliteAuth,
'device_uuid' => $deviceUuid, 'id' => $id), 'Device registered');
            break;
        }

        case 'push': {
            if ($method !== 'POST') syncErr('POST required');
            $ops = isset($body['operations']) && is_array($body['operations']) ? $body['operations'] : array();
            if (count($ops) > SyncConfig::batchSize()) {
                syncErr('Batch too large (max ' . SyncConfig::batchSize() . ')');
            }
            $deviceUuid = isset($body['device_uuid']) ? $body['device_uuid'] : DeviceIdentity::getUuid();
            $syncDb->registerDevice($deviceUuid, $userId, null);
            $sessionId = $syncDb->startSession($deviceUuid, $userId, 'push');
            $ok = 0; $fail = 0; $results = array();
            foreach ($ops as $op) {
                if (empty($op['device_uuid'])) $op['device_uuid'] = $deviceUuid;
                $r = $syncDb->applyPushOp($op);
                $results[] = array(
                    'op_id' => isset($op['op_id']) ? $op['op_id'] : null,
                    'ok' => !empty($r['ok']),
                    'duplicate' => !empty($r['duplicate']),
                    'error' => isset($r['error']) ? $r['error'] : null,
                );
                if (!empty($r['ok'])) $ok++; else $fail++;
            }
            $syncDb->finishSession($sessionId, $ok, 0, $fail, 0, $fail ? 'partial' : 'completed');
            $sqliteAuth = class_exists('OfflineAuth') ? OfflineAuth::sqliteReady() : array('ok' => false);
            syncOk(array(
                'offline_auth' => $sqliteAuth,
'results' => $results, 'uploaded' => $ok, 'failed' => $fail));
            break;
        }

        case 'pull': {
            $cursor = isset($body['cursor']) ? (int)$body['cursor'] : (isset($_GET['cursor']) ? (int)$_GET['cursor'] : 0);
            $limit = isset($body['limit']) ? (int)$body['limit'] : SyncConfig::batchSize();
            $limit = max(1, min(500, $limit));
            $deviceUuid = isset($body['device_uuid']) ? $body['device_uuid'] : DeviceIdentity::getUuid();
            $syncDb->registerDevice($deviceUuid, $userId, null);
            $sessionId = $syncDb->startSession($deviceUuid, $userId, 'pull');
            $changes = $syncDb->pullChanges($cursor, $limit);
            $maxId = $cursor;
            foreach ($changes as $ch) {
                if ((int)$ch['id'] > $maxId) $maxId = (int)$ch['id'];
            }
            $syncDb->finishSession($sessionId, 0, count($changes), 0, 0, 'completed');
            $sqliteAuth = class_exists('OfflineAuth') ? OfflineAuth::sqliteReady() : array('ok' => false);
            syncOk(array(
                'offline_auth' => $sqliteAuth,

                'changes' => $changes,
                'cursor' => $maxId,
                'count' => count($changes),
            ));
            break;
        }

        case 'run': {
            // In-process sync — do NOT HTTP-call this same API (that re-triggers CSRF without a token).
            $deviceUuid = DeviceIdentity::getUuid();
            $syncDb->registerDevice($deviceUuid, $userId, 'NSMS Admin Panel');
            $sessionId = $syncDb->startSession($deviceUuid, $userId, 'full');
            $store = new SqliteStore();
            $store->connect();
            // Re-queue offline-only students missing from MySQL
            try {
                require_once __DIR__ . '/../includes/sync/OfflineData.php';
                OfflineData::requeueOrphanStudents();
                OfflineData::requeueOrphanTeachers();
            } catch (Exception $e) {
                error_log('requeueOrphanStudents: ' . $e->getMessage());
            }
            // Re-queue previously failed ops so reconnect can retry
            try {
                $store->connect()->exec("UPDATE sync_queue SET status = 'pending', error_message = NULL WHERE status = 'failed'");
            } catch (Exception $e) {}
            $batch = $store->pendingQueue(SyncConfig::batchSize());
            $uploaded = 0;
            $failed = 0;
            $results = array();
            foreach ($batch as $row) {
                $op = array(
                    'op_id' => $row['op_id'],
                    'entity_type' => $row['entity_type'],
                    'record_uuid' => $row['record_uuid'],
                    'operation' => $row['operation'],
                    'payload' => json_decode($row['payload'], true),
                    'device_uuid' => $deviceUuid,
                );
                $r = $syncDb->applyPushOp($op);
                if (!empty($r['ok'])) {
                    $store->markQueue($row['id'], 'synced', null);
                    $uploaded++;
                } else {
                    $err = isset($r['error']) ? $r['error'] : 'Push failed';
                    $store->markQueue($row['id'], 'failed', $err);
                    $failed++;
                }
                $results[] = $r;
            }
            // Pull remote change log into SQLite cursor (download)
            $cursor = (int)$store->getMeta('pull_cursor', '0');
            $changes = $syncDb->pullChanges($cursor, SyncConfig::batchSize());
            $downloaded = count($changes);
            $maxId = $cursor;
            foreach ($changes as $ch) {
                if ((int)$ch['id'] > $maxId) $maxId = (int)$ch['id'];
            }
            $store->setMeta('pull_cursor', (string)$maxId);
            $store->setMeta('last_sync_at', date('c'));
            $status = $failed ? 'partial' : 'completed';
            $syncDb->finishSession($sessionId, $uploaded, $downloaded, $failed, 0, $status);
            $sqliteAuth = class_exists('OfflineAuth') ? OfflineAuth::sqliteReady() : array('ok' => false);
            syncOk(array(
                'offline_auth' => $sqliteAuth,

                'uploaded' => $uploaded,
                'downloaded' => $downloaded,
                'failed' => $failed,
                'pending' => $store->pendingCount(),
                'device_uuid' => $deviceUuid,
                'results' => $results,
            ), 'Sync complete');
            break;
        }

        case 'sessions': {
            if ($role !== 'admin') syncErr('Admins only', 403);
            $rows = $db->query(
                'SELECT * FROM sync_sessions ORDER BY id DESC LIMIT 50'
            ) ?: array();
            $sqliteAuth = class_exists('OfflineAuth') ? OfflineAuth::sqliteReady() : array('ok' => false);
            syncOk(array(
                'offline_auth' => $sqliteAuth,
'sessions' => $rows));
            break;
        }

        case 'conflicts': {
            if ($role !== 'admin') syncErr('Admins only', 403);
            $rows = $db->query(
                "SELECT * FROM sync_conflicts ORDER BY id DESC LIMIT 50"
            ) ?: array();
            $sqliteAuth = class_exists('OfflineAuth') ? OfflineAuth::sqliteReady() : array('ok' => false);
            syncOk(array(
                'offline_auth' => $sqliteAuth,
'conflicts' => $rows));
            break;
        }

        case 'warm_offline_auth': {
            requireRole('admin');
            // MySQL is already connected above; double-check for clear errors
            try {
                $probe = $db->queryOne('SELECT 1 AS ok');
                if (!$probe) {
                    syncErr('MySQL must be online to prepare offline logins', 503);
                }
            } catch (Exception $e) {
                syncErr('MySQL must be online to prepare offline logins', 503);
            }
            $result = OfflineAuth::warmFromMysql($db);
            if (empty($result['ok'])) {
                syncErr(isset($result['error']) ? $result['error'] : 'Warm failed', 500);
            }
            try {
                $roster = OfflineData::warmRosterFromMysql($db);
                $result['roster'] = $roster;
                $result['teachers'] = OfflineData::warmTeachersFromMysql($db);
                $result['settings'] = OfflineData::warmSettingsFromMysql($db);
                $result['gallery'] = OfflineAdmin::warmGalleryFromMysql($db);
                $result['calendar'] = OfflineAdmin::warmCalendarFromMysql($db);
                $result['payments'] = OfflineAdmin::warmFinanceFromMysql($db);
                $result['subjects'] = OfflineAdmin::warmSubjectsFromMysql($db);
            } catch (Exception $e) {
                $result['roster_error'] = $e->getMessage();
            }
            syncOk($result, 'Offline logins and roster prepared');
            break;
        }

        case 'enqueue_demo': {
            // Dev helper: enqueue a sample local change (does not modify production data)
            if ($role !== 'admin') syncErr('Admins only', 403);
            $store = new SqliteStore();
            $store->connect();
            $uuid = DeviceIdentity::generateUuid();
            $opId = $store->enqueue('students', $uuid, 'CREATE', array(
                'student_name' => 'Offline Demo Student',
                'status' => 'active',
                'sync_version' => 1,
            ));
            $sqliteAuth = class_exists('OfflineAuth') ? OfflineAuth::sqliteReady() : array('ok' => false);
            syncOk(array(
                'offline_auth' => $sqliteAuth,
'op_id' => $opId, 'record_uuid' => $uuid, 'pending' => $store->pendingCount()), 'Demo op queued in SQLite');
            break;
        }

        default:
            syncErr('Unknown action. Use health|status|push|pull|run|register_device|sessions|conflicts');
    }
} catch (Exception $e) {
    error_log('sync.php: ' . $e->getMessage());
    syncErr('Server error: ' . $e->getMessage(), 500);
}
