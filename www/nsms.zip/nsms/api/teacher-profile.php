<?php
/**
 * Teacher Profile API  —  PHP 7.2 compatible
 * Path: /nsms/api/teacher-profile.php
 * Actions (GET):  get
 * Actions (POST): update_profile | upload_photo
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

if (function_exists('applyApiHeaders')) { applyApiHeaders(); }


if (!isLoggedIn() || $_SESSION['role'] !== 'teacher') {
    ob_end_clean();
    echo json_encode(['success' => false, 'error' => 'unauthorized']);
    exit;
}

$userId = (int)$_SESSION['user_id'];
$db     = new Database();
$conn   = $db->connect();

if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

// ── Route ─────────────────────────────────────────────────────────────────────
$action = $_SERVER['REQUEST_METHOD'] === 'GET'
    ? (isset($_GET['action']) ? $_GET['action'] : 'get')
    : 'post';

if ($action === 'post') {
    $ct    = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    $input = (strpos($ct, 'application/json') !== false)
        ? (json_decode(file_get_contents('php://input'), true) ?: [])
        : $_POST;
    $action = isset($input['action']) ? $input['action'] : '';
}

// ── GET profile ───────────────────────────────────────────────────────────────
if ($action === 'get') {
    $rows = $db->query(
        "SELECT u.id, u.full_name, u.email, u.phone, u.photo_url, u.status, u.created_at, u.last_login,
                c.class_name, c.class_color,
                GROUP_CONCAT(DISTINCT s.subject_name ORDER BY s.subject_name SEPARATOR ', ') AS subjects
         FROM users u
         LEFT JOIN classes c ON c.teacher_id = u.id
         LEFT JOIN teacher_subjects ts ON ts.teacher_id = u.id
         LEFT JOIN subjects s ON s.id = ts.subject_id
         WHERE u.id = ? AND u.role = 'teacher'
         GROUP BY u.id, c.class_name, c.class_color",
        [$userId]
    );
    ob_end_clean();
    if (!$rows) { errorResponse('Profile not found', 404); }
    successResponse($rows[0]);
}

// ── UPDATE profile ────────────────────────────────────────────────────────────
elseif ($action === 'update_profile') {
    $ct    = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    $input = json_decode(file_get_contents('php://input'), true) ?: [];

    $fullName = isset($input['full_name']) ? trim($input['full_name']) : '';
    $email    = isset($input['email'])     ? trim($input['email'])     : '';
    $phone    = isset($input['phone'])     ? trim($input['phone'])     : '';

    if (!$fullName) { ob_end_clean(); errorResponse('Full name is required', 400); }
    if (!$email)    { ob_end_clean(); errorResponse('Email is required', 400); }

    // Check email not taken by another user
    $existing = $db->query(
        "SELECT id FROM users WHERE email = ? AND id != ?", [$email, $userId]
    );
    if ($existing) { ob_end_clean(); errorResponse('Email already in use by another account', 409); }

    $db->execute(
        "UPDATE users SET full_name = :n, email = :e, phone = :p WHERE id = :id",
        [':n' => $fullName, ':e' => $email, ':p' => $phone, ':id' => $userId]
    );

    // Optional password change
    if (!empty($input['change_password'])) {
        $currentPw = isset($input['current_password']) ? $input['current_password'] : '';
        $newPw     = isset($input['new_password'])     ? $input['new_password']     : '';
        $confirm   = isset($input['confirm_password']) ? $input['confirm_password'] : '';

        $row = $db->query("SELECT password_hash FROM users WHERE id = ?", [$userId]);
        if (!$row || !password_verify($currentPw, $row[0]['password_hash'])) {
            ob_end_clean(); errorResponse('Current password is incorrect', 400);
        }
        if (strlen($newPw) < 6) { ob_end_clean(); errorResponse('New password must be at least 6 characters', 400); }
        if ($newPw !== $confirm) { ob_end_clean(); errorResponse('New passwords do not match', 400); }

        $db->execute(
            "UPDATE users SET password_hash = :h WHERE id = :id",
            [':h' => password_hash($newPw, PASSWORD_BCRYPT), ':id' => $userId]
        );
    }

    // Update session name
    $_SESSION['full_name'] = $fullName;
    $_SESSION['email']     = $email;

    ob_end_clean();
    successResponse(['message' => 'Profile updated successfully.']);
}

// ── UPLOAD photo ──────────────────────────────────────────────────────────────
elseif ($action === 'upload_photo') {
    if (empty($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
        ob_end_clean(); errorResponse('No valid file uploaded', 400);
    }
    $file = $_FILES['photo'];
    if ($file['size'] > 5 * 1024 * 1024) { ob_end_clean(); errorResponse('Image must be under 5 MB', 400); }

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $mime    = function_exists('finfo_open')
        ? finfo_file(finfo_open(FILEINFO_MIME_TYPE), $file['tmp_name'])
        : $file['type'];
    if (!isset($allowed[$mime])) { ob_end_clean(); errorResponse('Invalid image type. Use JPG, PNG, or WEBP', 400); }

    $nsmsRoot  = dirname(dirname(realpath(__FILE__)));
    $uploadDir = $nsmsRoot . '/public/uploads/teachers/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $filename = 'teacher_' . time() . '_' . mt_rand(1000, 9999) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
        ob_end_clean(); errorResponse('Failed to save image', 500);
    }

    $photoUrl = '/nsms/public/uploads/teachers/' . $filename;
    $db->execute("UPDATE users SET photo_url = :u WHERE id = :id", [':u' => $photoUrl, ':id' => $userId]);

    ob_end_clean();
    successResponse(['photo_url' => $photoUrl]);
}

else {
    ob_end_clean();
    errorResponse('Unknown action', 400);
}
