<?php
/**
 * NSMS — Teacher Reports API  (v2)
 * /nsms/api/teacher-reports.php
 *
 * Assessment types: daily | weekly | midterm | terminal
 * PHP 7.2 compatible.
 */

ob_start();
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

applyApiHeaders();

requireRole(['admin', 'teacher']);

$db   = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

ensureReviewSchema($db);

$method   = $_SERVER['REQUEST_METHOD'];
$postData = [];
if ($method === 'POST') {
    $raw      = file_get_contents('php://input');
    $postData = json_decode($raw, true) ?: [];
    $action   = isset($postData['action']) ? trim($postData['action']) : '';
} else {
    $action = isset($_GET['action']) ? trim($_GET['action']) : '';
}

try {
    switch ($action) {
        case 'students':          getStudents($db);               break;
        case 'draft_from_grades': getDraftFromGrades($db);        break;
        case 'existing_report':   getExistingReport($db);         break;
        case 'report_list':       getReportList($db);             break;
        case 'save_report':       saveOrPublish($db,$postData,false); break;
        case 'publish_report':    saveOrPublish($db,$postData,true);  break;
        case 'review_queue':      getReviewQueue($db);             break;
        case 'approve_report':    approveReport($db,$postData);    break;
        case 'reject_report':     rejectReport($db,$postData);     break;
        default: ob_end_clean(); errorResponse('Invalid action');
    }
} catch (Exception $e) {
    ob_end_clean(); error_log('NSMS teacher-reports: '.$e->getMessage());
    errorResponse('Server error: '.$e->getMessage(), 500);
} catch (Throwable $e) {
    ob_end_clean(); error_log('NSMS teacher-reports fatal: '.$e->getMessage());
    errorResponse('Server error: '.$e->getMessage(), 500);
}

/* ════════════════════════ UTILITIES ════════════════════════ */
function sessionInfo(){
    return [
        isset($_SESSION['user_id'])?(int)$_SESSION['user_id']:0,
        isset($_SESSION['role'])?$_SESSION['role']:''
    ];
}
function resolveTeacherClassId($db,$tid){
    $r=$db->queryOne("SELECT id FROM classes WHERE teacher_id=:tid LIMIT 1",[':tid'=>$tid]);
    return $r?(int)$r['id']:null;
}
function pctToGrade($p){
    if($p===null) return null;
    $p=(float)$p;
    if($p>=90)return 'A';if($p>=75)return 'B';if($p>=60)return 'C';
    if($p>=50)return 'D';if($p>=40)return 'E';return 'F';
}
function gradeToPerf($g){
    return ['A'=>'Excellent','B'=>'Very Good','C'=>'Good','D'=>'Average','E'=>'Below Average','F'=>'Poor'][$g]??'';
}
function gradeToRating($g){
    return ['A'=>'Excellent','B'=>'Very Good','C'=>'Good','D'=>'Fair','E'=>'Needs Improvement','F'=>'Needs Improvement'][$g]??'';
}

/**
 * Adds the columns the midterm/terminal review workflow needs, on first
 * use — no manual migration required. review_status stays NULL for
 * daily/weekly reports, which are never routed through admin review.
 */
function ensureReviewSchema($db) {
    try { $db->execute("ALTER TABLE student_reports ADD COLUMN review_status VARCHAR(20) NULL AFTER is_published"); } catch (Exception $e) { /* already exists */ }
    try { $db->execute("ALTER TABLE student_reports ADD COLUMN review_note TEXT NULL AFTER review_status"); } catch (Exception $e) { /* already exists */ }
    try { $db->execute("ALTER TABLE student_reports ADD COLUMN submitted_at DATETIME NULL AFTER review_note"); } catch (Exception $e) { /* already exists */ }
    try { $db->execute("ALTER TABLE student_reports ADD COLUMN reviewed_at DATETIME NULL AFTER submitted_at"); } catch (Exception $e) { /* already exists */ }
    try { $db->execute("ALTER TABLE student_reports ADD COLUMN reviewed_by INT NULL AFTER reviewed_at"); } catch (Exception $e) { /* already exists */ }
}

function getAdminUserIds($db) {
    $rows = $db->query("SELECT id FROM users WHERE role='admin' AND status='active'");
    return $rows ? array_column($rows, 'id') : [];
}

/**
 * Turns a rank number into "3rd", "21st", etc.
 */
function ordinalSuffix($n) {
    $n = (int)$n;
    if (!in_array($n % 100, [11, 12, 13])) {
        switch ($n % 10) {
            case 1: return $n . 'st';
            case 2: return $n . 'nd';
            case 3: return $n . 'rd';
        }
    }
    return $n . 'th';
}

/**
 * Ranks every student in a class by their overall average for a specific
 * report type (midterm or terminal) — computed live from that exact
 * assessment_type's grades, the same source getDraftFromGrades now uses,
 * so the position always matches the numbers shown on the report itself.
 * Dense ranking — ties share the same position and the next distinct
 * average does NOT skip (1st, 2nd, 2nd, 3rd) — matching the tie-handling
 * already used by getClassRank() in parent-reports.php, so a student's
 * position reads the same on both sides of the system.
 *
 * Only students with at least one graded assessment of this exact type
 * are ranked — there's nothing meaningful to rank for a student with no
 * exam grades yet.
 *
 * @return array student_id => ['position'=>int,'class_size'=>int,'overall_average'=>float,'label'=>'3rd of 24']
 */
function computeClassPositions($db, $classId, $term, $academicYear, $assessmentType) {
    $rows = $db->query(
        "SELECT gg.student_id, AVG(gg.score/ga.max_score*100) AS overall_avg
           FROM gradebook_grades gg
           JOIN gradebook_assessments ga ON ga.id = gg.assessment_id
          WHERE ga.class_id = :cid AND ga.term = :term AND ga.academic_year = :yr
            AND ga.assessment_type = :type
            AND gg.score IS NOT NULL AND ga.is_published = 1
          GROUP BY gg.student_id",
        [':cid' => $classId, ':term' => $term, ':yr' => $academicYear, ':type' => $assessmentType]
    ) ?: [];

    if (empty($rows)) return [];

    usort($rows, function($a, $b) { return $b['overall_avg'] <=> $a['overall_avg']; });

    $total     = count($rows);
    $map       = [];
    $rank      = 0;
    $lastScore = null;
    foreach ($rows as $row) {
        $avg = round((float)$row['overall_avg'], 2);
        if ($avg !== $lastScore) { $rank++; $lastScore = $avg; }
        $map[(int)$row['student_id']] = [
            'position'        => $rank,
            'class_size'      => $total,
            'overall_average' => $avg,
            'label'           => ordinalSuffix($rank) . ' of ' . $total,
        ];
    }
    return $map;
}

/* ════════════════════════ GET ════════════════════════ */
function getStudents($db){
    list($userId,$role)=sessionInfo();
    $classId=$role==='admin'?(isset($_GET['class_id'])?(int)$_GET['class_id']:null):resolveTeacherClassId($db,$userId);
    if(!$classId){ob_end_clean();errorResponse('No class assigned.');}
    $rows=$db->query(
        "SELECT id,student_name,photo_url,gender FROM students WHERE class_id=:cid AND status='active' ORDER BY student_name",
        [':cid'=>$classId]
    )?:[];
    ob_end_clean();successResponse(['students'=>$rows,'class_id'=>$classId]);
}

function getDraftFromGrades($db){
    list($userId,$role)=sessionInfo();
    $sid   =isset($_GET['student_id'])   ?(int)$_GET['student_id']   :0;
    $term  =isset($_GET['term'])         ?trim($_GET['term'])         :'';
    $yr    =isset($_GET['academic_year'])?trim($_GET['academic_year']):'';
    $rtype =isset($_GET['report_type'])  ?trim($_GET['report_type'])  :'';
    $pl    =isset($_GET['period_label']) ?trim($_GET['period_label']) :'';

    $valid=['daily','weekly','midterm','terminal'];
    if(!$sid||!$term||!$yr||!in_array($rtype,$valid)){
        ob_end_clean();errorResponse('student_id, term, academic_year, report_type required.');
    }
    $student=$db->queryOne("SELECT id,student_name,photo_url,class_id,gender FROM students WHERE id=:id",[':id'=>$sid]);
    if(!$student){ob_end_clean();errorResponse('Student not found.',404);}

    /* Compute subject averages scoped to this specific report type.
       Every type — daily/weekly/midterm/terminal — is computed the same
       way: only grades from assessments of that exact assessment_type.
       (Previously midterm/terminal read a shared, all-types-blended cache
       table, which meant a midterm report and a terminal report for the
       same term showed identical numbers, potentially polluted by
       ordinary daily/weekly grades. This computes live from the actual
       exam-type assessments instead — daily/weekly already worked this
       way; midterm/terminal now match.) */
    $perfs=$db->query(
        "SELECT ga.subject_id,ROUND(AVG(gg.score/ga.max_score*100),2) AS average_score,
                s.subject_name,s.subject_code
         FROM gradebook_grades gg
         JOIN gradebook_assessments ga ON ga.id=gg.assessment_id
         JOIN subjects s ON s.id=ga.subject_id
         WHERE gg.student_id=:sid AND ga.class_id=:cid AND ga.term=:term
           AND ga.academic_year=:yr AND ga.assessment_type=:type
           AND gg.score IS NOT NULL AND ga.is_published=1
         GROUP BY ga.subject_id ORDER BY s.subject_name",
        [':sid'=>$sid,':cid'=>(int)$student['class_id'],':term'=>$term,':yr'=>$yr,':type'=>$rtype]
    )?:[];
    foreach($perfs as &$p){
        $p['grade_letter']     =pctToGrade($p['average_score']);
        $p['performance_level']=gradeToPerf($p['grade_letter']);
    } unset($p);

    $subjectData=[];
    foreach($perfs as $p){
        $subjectData[$p['subject_name']]=[
            'subject_id'        =>(int)$p['subject_id'],
            'subject_code'      =>$p['subject_code'],
            'average_score'     =>$p['average_score'],
            'grade_letter'      =>$p['grade_letter'],
            'performance_level' =>$p['performance_level']??gradeToPerf($p['grade_letter']),
            'rating'            =>gradeToRating($p['grade_letter']),
        ];
    }

    /* Check if draft/published already exists for this slot */
    $existing=$pl?$db->queryOne(
        "SELECT id,is_published FROM student_reports
         WHERE student_id=:sid AND report_type=:rtype AND period_label=:pl
           AND term=:term AND academic_year=:yr",
        [':sid'=>$sid,':rtype'=>$rtype,':pl'=>$pl,':term'=>$term,':yr'=>$yr]
    ):null;

    /* Class position — midterm/terminal only, ranked by overall average
       (mean of each student's subject averages) across the whole class. */
    $positionInfo = null;
    if (in_array($rtype, ['midterm','terminal'])) {
        $positions = computeClassPositions($db, (int)$student['class_id'], $term, $yr, $rtype);
        if (isset($positions[$sid])) {
            $positionInfo = $positions[$sid];
        }
    }

    ob_end_clean();successResponse([
        'student'            =>$student,
        'subject_data'       =>$subjectData,
        'has_grades'         =>count($subjectData)>0,
        'existing_report_id' =>$existing?(int)$existing['id']:null,
        'is_published'       =>$existing&&$existing['is_published']?true:false,
        'class_position'     =>$positionInfo,
    ]);
}

function getExistingReport($db){
    list($userId,$role)=sessionInfo();
    $id=isset($_GET['id'])?(int)$_GET['id']:0;
    if(!$id){ob_end_clean();errorResponse('id required.');}
    $r=$db->queryOne("SELECT * FROM student_reports WHERE id=:id",[':id'=>$id]);
    if(!$r){ob_end_clean();errorResponse('Report not found.',404);}
    if($role!=='admin'&&(int)$r['teacher_id']!==$userId){ob_end_clean();errorResponse('Access denied.',403);}
    $student=$db->queryOne("SELECT id,student_name,photo_url FROM students WHERE id=:id",[':id'=>$r['student_id']]);
    $r['subject_data']=$r['subject_data']?json_decode($r['subject_data'],true):[];
    ob_end_clean();successResponse(['report'=>$r,'student'=>$student]);
}

function getReportList($db){
    list($userId,$role)=sessionInfo();
    $sid=isset($_GET['student_id'])?(int)$_GET['student_id']:0;
    if(!$sid){ob_end_clean();errorResponse('student_id required.');}
    $where=['student_id=:sid'];$params=[':sid'=>$sid];
    if($role!=='admin'){$where[]='teacher_id=:tid';$params[':tid']=$userId;}
    $rows=$db->query(
        "SELECT id,report_type,period_label,term,academic_year,is_draft,is_published,
                review_status,review_note,submitted_at,published_at,created_at
         FROM student_reports WHERE ".implode(' AND ',$where)." ORDER BY created_at DESC",
        $params
    )?:[];
    ob_end_clean();successResponse(['reports'=>$rows]);
}

/* ════════════════════════ POST ════════════════════════ */
function saveOrPublish($db,$data,$publish){
    list($userId)=sessionInfo();

    $sid          =isset($data['student_id'])         ?(int)$data['student_id']          :0;
    $classId      =isset($data['class_id'])           ?(int)$data['class_id']            :0;
    $rtype        =isset($data['report_type'])        ?trim($data['report_type'])         :'';
    $pl           =isset($data['period_label'])       ?trim($data['period_label'])        :'';
    $term         =isset($data['term'])               ?trim($data['term'])                :'';
    $yr           =isset($data['academic_year'])      ?trim($data['academic_year'])       :'';
    $rd           =isset($data['report_date'])        ?trim($data['report_date'])         :date('Y-m-d');
    $subjectData  =isset($data['subject_data'])       ?$data['subject_data']              :[];
    $conduct      =isset($data['conduct'])            ?trim($data['conduct'])             :null;
    $punctuality  =isset($data['punctuality'])        ?trim($data['punctuality'])         :null;
    $neatness     =isset($data['neatness'])           ?trim($data['neatness'])            :null;
    $classPartic  =isset($data['class_participation'])?trim($data['class_participation']) :null;
    $socialSkills =isset($data['social_skills'])      ?trim($data['social_skills'])       :null;
    $comments     =isset($data['teacher_comments'])   ?trim($data['teacher_comments'])    :null;
    $recommend    =isset($data['recommendations'])    ?trim($data['recommendations'])     :null;
    $promoStatus  =isset($data['promotion_status'])   ?trim($data['promotion_status'])    :null;

    $valid=['daily','weekly','midterm','terminal'];
    if(!$sid||!in_array($rtype,$valid)||!$pl||!$term||!$yr){
        ob_end_clean();errorResponse('Missing required fields.');
    }
    if(!$classId){
        $st=$db->queryOne("SELECT class_id FROM students WHERE id=:id",[':id'=>$sid]);
        $classId=$st?(int)$st['class_id']:0;
    }
    $subjectJson=!empty($subjectData)?json_encode($subjectData):null;

    // Midterm/terminal reports go to an admin for review instead of
    // publishing straight to parents — daily/weekly are unaffected and
    // still publish immediately, exactly as before.
    $needsReview = $publish && in_array($rtype, ['midterm','terminal']);

    /* Upsert */
    $existing=$db->queryOne(
        "SELECT id,is_published FROM student_reports
         WHERE student_id=:sid AND report_type=:rtype AND period_label=:pl AND term=:term AND academic_year=:yr",
        [':sid'=>$sid,':rtype'=>$rtype,':pl'=>$pl,':term'=>$term,':yr'=>$yr]
    );
    if($existing&&$existing['is_published']&&!$publish){
        ob_end_clean();errorResponse('Report already published and locked.');
    }

    // Publishing here only means "actually goes live" for report types that
    // don't need review. For midterm/terminal, a "publish" click submits
    // for review — it stays unpublished (and undraft) until an admin approves it.
    $isDraft = $publish ? 0 : 1;
    $isPub   = ($publish && !$needsReview) ? 1 : 0;
    $reviewStatus = $needsReview ? 'pending' : ($publish ? null : null);
    // A draft save on a report that's already mid-review shouldn't silently
    // clear its pending status — only an explicit (re)submit does that.
    if (!$publish && $existing) {
        $prior = $db->queryOne("SELECT review_status FROM student_reports WHERE id=:id", [':id'=>$existing['id']]);
        $reviewStatus = $prior ? $prior['review_status'] : null;
    }
    $needsReviewFlag = $needsReview ? 1 : 0;

    if($existing){
        $reportId=(int)$existing['id'];
        // Bug fix: was interpolating $isDraft/$isPub/$publish directly into SQL string.
        // Now fully parameterised. published_at handled via CASE to avoid raw NOW().
        $sql="UPDATE student_reports SET
               subject_data=:sd,conduct=:co,punctuality=:pu,neatness=:ne,
               class_participation=:cp,social_skills=:ss,
               teacher_comments=:tc,recommendations=:re,
               promotion_status=:ps,report_date=:rd,class_id=:cid,teacher_id=:tid,
               is_draft=:isd,is_published=:isp,review_status=:revstatus,
               review_note=CASE WHEN :needsreview=1 THEN NULL ELSE review_note END,
               reviewed_at=CASE WHEN :needsreview=1 THEN NULL ELSE reviewed_at END,
               reviewed_by=CASE WHEN :needsreview=1 THEN NULL ELSE reviewed_by END,
               submitted_at=CASE WHEN :needsreview=1 THEN NOW() ELSE submitted_at END,
               published_at=CASE WHEN :pub=1 THEN NOW() ELSE published_at END
             WHERE id=:id";
        $result=$db->execute($sql,[
            ':sd'=>$subjectJson,':co'=>$conduct,':pu'=>$punctuality,':ne'=>$neatness,
            ':cp'=>$classPartic,':ss'=>$socialSkills,':tc'=>$comments,':re'=>$recommend,
            ':ps'=>$promoStatus,':rd'=>$rd,':cid'=>$classId,':tid'=>$userId,
            ':isd'=>$isDraft,':isp'=>$isPub,':revstatus'=>$reviewStatus,':needsreview'=>$needsReviewFlag,
            ':pub'=>$isPub,':id'=>$reportId
        ]);
        if($result===false){ob_end_clean();errorResponse('Failed to update report (DB error). Check server log.',500);}
    } else {
        $result=$db->execute(
            "INSERT INTO student_reports
               (student_id,class_id,teacher_id,report_type,period_label,term,academic_year,
                report_date,subject_data,conduct,punctuality,neatness,class_participation,
                social_skills,teacher_comments,recommendations,promotion_status,
                is_draft,is_published,review_status,submitted_at,published_at)
             VALUES (:sid,:cid,:tid,:rtype,:pl,:term,:yr,:rd,:sd,:co,:pu,:ne,:cp,:ss,:tc,:re,:ps,
                     :isd,:isp,:revstatus,
                     CASE WHEN :needsreview=1 THEN NOW() ELSE NULL END,
                     CASE WHEN :pub=1 THEN NOW() ELSE NULL END)",
            [':sid'=>$sid,':cid'=>$classId,':tid'=>$userId,':rtype'=>$rtype,':pl'=>$pl,
             ':term'=>$term,':yr'=>$yr,':rd'=>$rd,':sd'=>$subjectJson,':co'=>$conduct,
             ':pu'=>$punctuality,':ne'=>$neatness,':cp'=>$classPartic,':ss'=>$socialSkills,
             ':tc'=>$comments,':re'=>$recommend,':ps'=>$promoStatus,
             ':isd'=>$isDraft,':isp'=>$isPub,':revstatus'=>$reviewStatus,':needsreview'=>$needsReviewFlag,
             ':pub'=>$isPub]
        );
        if($result===false||!$result){ob_end_clean();errorResponse('Failed to create report (DB error). Check server log.',500);}
        $reportId=(int)$result;
    }

    if ($needsReview) {
        notifyAdminsReportSubmitted($db, $reportId, $sid, $rtype, $pl, $userId);
    } elseif ($publish) {
        notifyParentsReportPublished($db, $reportId, $sid, $rtype, $pl);
    }

    $message = $needsReview
        ? 'Submitted for admin review — you\'ll be notified once it\'s approved.'
        : ($publish ? 'Report published. Parents notified.' : 'Draft saved.');

    ob_end_clean();successResponse([
        'report_id'=>$reportId,
        'needs_review'=>$needsReview,
        'message'  =>$message,
    ]);
}

/**
 * Notifies every parent linked to the student that a report has been
 * published — used for daily/weekly (direct publish) and for midterm/
 * terminal once an admin approves them.
 */
function notifyParentsReportPublished($db, $reportId, $sid, $rtype, $pl) {
    $typeLabels=['daily'=>'Daily Report','weekly'=>'Weekly Report','midterm'=>'Mid-term Report','terminal'=>'Term Report'];
    $tLabel=$typeLabels[$rtype]??'Report';
    $student=$db->queryOne("SELECT student_name FROM students WHERE id=:id",[':id'=>$sid]);
    $sName=$student?$student['student_name']:'your child';
    $parents=$db->query(
        "SELECT DISTINCT p.user_id, u.email, u.full_name
           FROM parents p JOIN users u ON u.id = p.user_id
          WHERE p.student_id=:sid AND p.user_id IS NOT NULL",
        [':sid'=>$sid]
    )?:[];
    foreach($parents as $p){
        // 'link' column does not exist in notifications schema; use 'reference_key' instead
        $r=$db->execute(
            "INSERT INTO notifications (user_id,title,message,type,reference_key,is_read)
             VALUES (:uid,:title,:msg,'report',:refkey,0)",
            [':uid'=>(int)$p['user_id'],':title'=>"$tLabel Available",
             ':msg'=>"A new $tLabel for $sName has been published. Period: $pl.",
             ':refkey'=>"report_id=$reportId"]
        );
        if($r===false) error_log("NSMS notify: INSERT notifications failed for user_id={$p['user_id']} report_id=$reportId");

        if(!empty($p['email'])){
            try{
                $body='<p>Dear '.htmlspecialchars($p['full_name']).',</p>'.
                      '<p>A new <strong>'.htmlspecialchars($tLabel).'</strong> for <strong>'.htmlspecialchars($sName).'</strong> has been published.</p>'.
                      '<p>Period: '.htmlspecialchars($pl).'</p>'.
                      '<p>You can view the full report anytime from the Reports section of the parent portal.</p>'.
                      '<p style="color:#888;font-size:12px;">This is an automated notice from the school reporting system.</p>';
                sendEmail($p['email'],"$tLabel Published — $sName",$body);
            }catch(Exception $e){error_log('report publish email error: '.$e->getMessage());}
        }
    }
}

/**
 * Notifies every admin that a midterm/terminal report is waiting for
 * their review, in-app and by email.
 */
function notifyAdminsReportSubmitted($db, $reportId, $sid, $rtype, $pl, $teacherId) {
    $typeLabels=['midterm'=>'Mid-term Report','terminal'=>'Term Report'];
    $tLabel=$typeLabels[$rtype]??'Report';
    $student=$db->queryOne("SELECT student_name FROM students WHERE id=:id",[':id'=>$sid]);
    $sName=$student?$student['student_name']:'A student';
    $teacher=$db->queryOne("SELECT full_name,email FROM users WHERE id=:id",[':id'=>$teacherId]);
    $tName=$teacher?$teacher['full_name']:'A teacher';

    $adminIds = getAdminUserIds($db);
    foreach ($adminIds as $adminId) {
        $db->execute(
            "INSERT INTO notifications (user_id,title,message,type,reference_key,is_read)
             VALUES (:uid,:title,:msg,'report',:refkey,0)",
            [':uid'=>$adminId,':title'=>"📝 $tLabel Awaiting Review",
             ':msg'=>"$tName submitted a $tLabel for $sName ($pl). Please review before it's sent to the parent.",
             ':refkey'=>"report_id=$reportId"]
        );
    }

    try {
        $admins = $db->query("SELECT email, full_name FROM users WHERE role='admin' AND status='active' AND email IS NOT NULL AND email != ''") ?: [];
        foreach ($admins as $a) {
            $body =
                '<p>Dear '.htmlspecialchars($a['full_name']).',</p>'.
                '<p><strong>'.htmlspecialchars($tName).'</strong> has submitted a <strong>'.htmlspecialchars($tLabel).'</strong> '.
                'for <strong>'.htmlspecialchars($sName).'</strong> ('.htmlspecialchars($pl).'), awaiting your review before it reaches the parent.</p>'.
                '<p>Please review it from the Reports section of the admin portal.</p>'.
                '<p style="color:#888;font-size:12px;">This is an automated notice from the school reporting system.</p>';
            sendEmail($a['email'], "$tLabel Awaiting Review — $sName", $body);
        }
    } catch (Exception $e) { error_log('notifyAdminsReportSubmitted email error: '.$e->getMessage()); }
}

/**
 * Admin approves a pending midterm/terminal report — publishes it and
 * notifies parents, reusing the exact same notification path daily/weekly
 * reports use when a teacher publishes them directly.
 */
function approveReport($db, $data) {
    list($userId, $role) = sessionInfo();
    if ($role !== 'admin') { ob_end_clean(); errorResponse('Admin only', 403); }

    $reportId = isset($data['report_id']) ? (int)$data['report_id'] : 0;
    if (!$reportId) { ob_end_clean(); errorResponse('report_id required'); }

    $r = $db->queryOne("SELECT * FROM student_reports WHERE id=:id", [':id'=>$reportId]);
    if (!$r) { ob_end_clean(); errorResponse('Report not found', 404); }
    if ($r['review_status'] !== 'pending') { ob_end_clean(); errorResponse('This report is not awaiting review.'); }

    $ok = $db->execute(
        "UPDATE student_reports
            SET is_published=1, review_status='approved', reviewed_by=:uid, reviewed_at=NOW(), published_at=NOW()
          WHERE id=:id",
        [':uid'=>$userId, ':id'=>$reportId]
    );
    if ($ok === false) { ob_end_clean(); errorResponse('Failed to approve report', 500); }

    notifyParentsReportPublished($db, $reportId, (int)$r['student_id'], $r['report_type'], $r['period_label']);

    ob_end_clean();
    successResponse(['report_id'=>$reportId], 'Report approved and published to parents.');
}

/**
 * Admin sends a pending midterm/terminal report back to the teacher with
 * a note explaining what needs to change. The report returns to draft so
 * the teacher can edit and resubmit.
 */
function rejectReport($db, $data) {
    list($userId, $role) = sessionInfo();
    if ($role !== 'admin') { ob_end_clean(); errorResponse('Admin only', 403); }

    $reportId = isset($data['report_id']) ? (int)$data['report_id'] : 0;
    $note     = isset($data['note']) ? trim($data['note']) : '';
    if (!$reportId) { ob_end_clean(); errorResponse('report_id required'); }
    if ($note === '') { ob_end_clean(); errorResponse('Please explain what needs to change before sending it back.'); }

    $r = $db->queryOne("SELECT * FROM student_reports WHERE id=:id", [':id'=>$reportId]);
    if (!$r) { ob_end_clean(); errorResponse('Report not found', 404); }
    if ($r['review_status'] !== 'pending') { ob_end_clean(); errorResponse('This report is not awaiting review.'); }

    $ok = $db->execute(
        "UPDATE student_reports
            SET is_draft=1, is_published=0, review_status='rejected',
                review_note=:note, reviewed_by=:uid, reviewed_at=NOW()
          WHERE id=:id",
        [':note'=>$note, ':uid'=>$userId, ':id'=>$reportId]
    );
    if ($ok === false) { ob_end_clean(); errorResponse('Failed to send back report', 500); }

    // Notify the teacher who wrote it
    $typeLabels=['midterm'=>'Mid-term Report','terminal'=>'Term Report'];
    $tLabel=$typeLabels[$r['report_type']]??'Report';
    $student=$db->queryOne("SELECT student_name FROM students WHERE id=:id",[':id'=>$r['student_id']]);
    $sName=$student?$student['student_name']:'a student';
    $db->execute(
        "INSERT INTO notifications (user_id,title,message,type,reference_key,is_read)
         VALUES (:uid,:title,:msg,'report',:refkey,0)",
        [':uid'=>(int)$r['teacher_id'],':title'=>"✏️ $tLabel Needs Changes",
         ':msg'=>"Your $tLabel for $sName ($r[period_label]) was sent back: \"$note\"",
         ':refkey'=>"report_id=$reportId"]
    );
    try {
        $teacher = $db->queryOne("SELECT email, full_name FROM users WHERE id=:id", [':id'=>$r['teacher_id']]);
        if ($teacher && !empty($teacher['email'])) {
            $body =
                '<p>Dear '.htmlspecialchars($teacher['full_name']).',</p>'.
                '<p>Your <strong>'.htmlspecialchars($tLabel).'</strong> for <strong>'.htmlspecialchars($sName).'</strong> '.
                '('.htmlspecialchars($r['period_label']).') has been sent back for changes before it can go to the parent:</p>'.
                '<blockquote style="border-left:3px solid #ccc;margin:12px 0;padding:6px 14px;color:#555;">'.htmlspecialchars($note).'</blockquote>'.
                '<p>Please update it in the Reports section and resubmit.</p>'.
                '<p style="color:#888;font-size:12px;">This is an automated notice from the school reporting system.</p>';
            sendEmail($teacher['email'], "$tLabel Needs Changes — $sName", $body);
        }
    } catch (Exception $e) { error_log('rejectReport email error: '.$e->getMessage()); }

    ob_end_clean();
    successResponse(['report_id'=>$reportId], 'Sent back to teacher for changes.');
}

/**
 * Every midterm/terminal report currently awaiting admin review, across
 * every class — this is school-wide, not scoped to one teacher.
 */
function getReviewQueue($db) {
    list($userId, $role) = sessionInfo();
    if ($role !== 'admin') { ob_end_clean(); errorResponse('Admin only', 403); }

    $rows = $db->query(
        "SELECT sr.id, sr.report_type, sr.period_label, sr.term, sr.academic_year, sr.submitted_at,
                s.student_name, c.class_name, u.full_name AS teacher_name
           FROM student_reports sr
           JOIN students s ON s.id = sr.student_id
           LEFT JOIN classes c ON c.id = sr.class_id
           LEFT JOIN users u ON u.id = sr.teacher_id
          WHERE sr.review_status = 'pending'
          ORDER BY sr.submitted_at ASC"
    ) ?: [];

    ob_end_clean();
    successResponse(['reports'=>$rows, 'count'=>count($rows)]);
}