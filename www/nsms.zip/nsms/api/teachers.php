<?php
/**
 * Teachers Management API
 * PHP 7.2 compatible
 * Actions: list, get, subjects, classes, create, update, delete
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    exit(0);
}

require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once __DIR__ . '/../includes/sync/OfflineData.php';
require_once __DIR__ . '/../includes/sync/OfflineAdmin.php';

applyApiHeaders();

requireRole('admin');

$db = new Database();
$conn = $db->connect();

if (!$conn) {
    $action = isset($_GET['action']) ? $_GET['action'] : '';
    require_once __DIR__ . '/../includes/sync/OfflineAdmin.php';
    $uid = function_exists('getCurrentUserId') ? getCurrentUserId() : (isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null);
    if ($action === 'list' && class_exists('OfflineData')) {
        ob_end_clean();
        successResponse(OfflineData::listTeachers(), 'Offline teachers cache');
    }
    if ($action === 'get' && class_exists('OfflineData')) {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $all = OfflineData::listTeachers();
        $found = null;
        foreach ($all as $t) {
            if ((int)$t['id'] === $id) { $found = $t; break; }
        }
        if (!$found) { ob_end_clean(); errorResponse('Teacher not found in offline cache', 404); }
        ob_end_clean();
        successResponse($found, 'Offline teacher');
    }
    // Class/subject lists still useful offline
    if ($action === 'classes' && class_exists('OfflineData')) {
        try {
            $pdo = (new SqliteStore())->connect();
            $rows = $pdo->query("SELECT id, class_name, class_color, capacity, minimum_age, teacher_id FROM classes ORDER BY sort_order, class_name")->fetchAll(PDO::FETCH_ASSOC);
            ob_end_clean();
            successResponse($rows ?: array(), 'Offline classes');
        } catch (Exception $e) {
            ob_end_clean();
            successResponse(array(), 'Offline classes empty');
        }
    }
    if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        try {
            $data = array();
            if (!empty($_POST) && is_array($_POST)) $data = $_POST;
            else {
                $raw = file_get_contents('php://input');
                $decoded = $raw ? json_decode($raw, true) : null;
                if (is_array($decoded)) $data = $decoded;
            }
            $res = OfflineAdmin::createTeacher($data, $uid);
            ob_end_clean();
            successResponse($res, 'Teacher saved offline — will sync when online');
        } catch (Exception $e) {
            ob_end_clean();
            errorResponse($e->getMessage(), 400);
        }
    }
    if ($action === 'update' && in_array($_SERVER['REQUEST_METHOD'], array('POST','PUT'), true)) {
        try {
            $data = array();
            if (!empty($_POST) && is_array($_POST)) $data = $_POST;
            else {
                $raw = file_get_contents('php://input');
                $decoded = $raw ? json_decode($raw, true) : null;
                if (is_array($decoded)) $data = $decoded;
            }
            $id = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
            $res = OfflineAdmin::updateTeacher($id, $data, $uid);
            ob_end_clean();
            successResponse($res, 'Teacher updated offline — will sync when online');
        } catch (Exception $e) {
            ob_end_clean();
            errorResponse($e->getMessage(), 400);
        }
    }
    ob_end_clean();
    errorResponse('Database connection failed', 500);
}

$action = isset($_GET['action']) ? $_GET['action'] : 'list';


function nsmsEnsureTeacherClassAssignments($db) {
    static $done = false;
    if ($done) return;
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS teacher_class_assignments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                teacher_id INT NOT NULL,
                class_id INT NOT NULL,
                subject_id INT NULL,
                academic_year VARCHAR(20) NULL,
                assigned_date DATE NULL,
                status ENUM('active','inactive') NOT NULL DEFAULT 'active',
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_tca (teacher_id, class_id, subject_id),
                KEY idx_tca_teacher (teacher_id),
                KEY idx_tca_class (class_id)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) {
        error_log('nsmsEnsureTeacherClassAssignments: ' . $e->getMessage());
    }
    $done = true;
}

/** Sync multi-class assignments for a teacher. $classIds = list of class ids. First becomes primary teacher_id. */
function nsmsSyncTeacherClasses($db, $teacherId, $classIds) {
    nsmsEnsureTeacherClassAssignments($db);
    $teacherId = (int) $teacherId;
    $classIds = array_values(array_unique(array_filter(array_map('intval', (array) $classIds))));

    // Clear primary homeroom links for this teacher
    $db->execute("UPDATE classes SET teacher_id = NULL WHERE teacher_id = :tid", array(':tid' => $teacherId));
    // Deactivate prior extra assignments
    try {
        $db->execute(
            "UPDATE teacher_class_assignments SET status = 'inactive' WHERE teacher_id = :tid",
            array(':tid' => $teacherId)
        );
    } catch (Exception $e) {}

    if (empty($classIds)) return;

    // Primary = first class (backward compatible single teacher_id)
    $primary = $classIds[0];
    $db->execute(
        "UPDATE classes SET teacher_id = :tid WHERE id = :cid",
        array(':tid' => $teacherId, ':cid' => $primary)
    );

    foreach ($classIds as $cid) {
        try {
            $db->execute(
                "INSERT INTO teacher_class_assignments (teacher_id, class_id, assigned_date, status, created_at)
                 VALUES (:tid, :cid, CURDATE(), 'active', NOW())
                 ON DUPLICATE KEY UPDATE status = 'active', assigned_date = CURDATE()",
                array(':tid' => $teacherId, ':cid' => $cid)
            );
        } catch (Exception $e) {
            // UNIQUE may include subject_id NULL — try without subject uniqueness issues
            try {
                $ex = $db->queryOne(
                    "SELECT id FROM teacher_class_assignments WHERE teacher_id = :tid AND class_id = :cid AND subject_id IS NULL LIMIT 1",
                    array(':tid' => $teacherId, ':cid' => $cid)
                );
                if ($ex) {
                    $db->execute(
                        "UPDATE teacher_class_assignments SET status = 'active', assigned_date = CURDATE() WHERE id = :id",
                        array(':id' => $ex['id'])
                    );
                } else {
                    $db->execute(
                        "INSERT INTO teacher_class_assignments (teacher_id, class_id, assigned_date, status, created_at)
                         VALUES (:tid, :cid, CURDATE(), 'active', NOW())",
                        array(':tid' => $teacherId, ':cid' => $cid)
                    );
                }
            } catch (Exception $e2) {
                error_log('nsmsSyncTeacherClasses: ' . $e2->getMessage());
            }
        }
    }
}

switch ($action) {

    // ------------------------------------------------
    // LIST  – all teachers with class, subjects, rating
    // ------------------------------------------------
    case 'list':
        $sql = "SELECT
                    u.id,
                    u.email,
                    u.full_name,
                    u.phone,
                    u.status,
                    u.photo_url,
                    u.created_at,
                    c.id         AS class_id,
                    c.class_name,
                    c.class_color,
                    ROUND(AVG(tr.rating), 1)                                              AS avg_rating,
                    COUNT(DISTINCT tr.id)                                                 AS rating_count,
                    GROUP_CONCAT(DISTINCT s.subject_name  ORDER BY s.subject_name SEPARATOR ', ') AS subjects,
                    GROUP_CONCAT(DISTINCT ts.subject_id   ORDER BY ts.subject_id  SEPARATOR ',')  AS subject_ids
                FROM users u
                LEFT JOIN classes          c  ON c.teacher_id  = u.id
                LEFT JOIN teacher_ratings  tr ON tr.teacher_id = u.id
                LEFT JOIN teacher_subjects ts ON ts.teacher_id = u.id
                LEFT JOIN subjects         s  ON s.id          = ts.subject_id
                WHERE u.role = 'teacher'
                GROUP BY u.id, u.email, u.full_name, u.phone, u.status, u.photo_url,
                         u.created_at, c.id, c.class_name, c.class_color
                ORDER BY u.full_name ASC";

        $teachers = $db->query($sql);
        ob_end_clean();
        successResponse($teachers ?: []);
        break;

    // ------------------------------------------------
    // GET  – single teacher full profile
    // ------------------------------------------------
    case 'get':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if (!$id) {
            ob_end_clean();
            errorResponse('Teacher ID required', 400);
        }

        $sql = "SELECT
                    u.id,
                    u.email,
                    u.full_name,
                    u.phone,
                    u.status,
                    u.photo_url,
                    u.created_at,
                    u.last_login,
                    c.id         AS class_id,
                    c.class_name,
                    c.class_color,
                    ROUND(AVG(tr.rating), 1)                                              AS avg_rating,
                    COUNT(DISTINCT tr.id)                                                 AS rating_count,
                    GROUP_CONCAT(DISTINCT s.subject_name  ORDER BY s.subject_name SEPARATOR ', ') AS subjects,
                    GROUP_CONCAT(DISTINCT ts.subject_id   ORDER BY ts.subject_id  SEPARATOR ',')  AS subject_ids
                FROM users u
                LEFT JOIN classes          c  ON c.teacher_id  = u.id
                LEFT JOIN teacher_ratings  tr ON tr.teacher_id = u.id
                LEFT JOIN teacher_subjects ts ON ts.teacher_id = u.id
                LEFT JOIN subjects         s  ON s.id          = ts.subject_id
                WHERE u.id = :id AND u.role = 'teacher'
                GROUP BY u.id, u.email, u.full_name, u.phone, u.status, u.photo_url,
                         u.created_at, u.last_login, c.id, c.class_name, c.class_color";

        $rows = $db->query($sql, [':id' => $id]);
        if ($rows && count($rows) > 0) {
            ob_end_clean();
            successResponse($rows[0]);
        } else {
            ob_end_clean();
            errorResponse('Teacher not found', 404);
        }
        break;

    // ------------------------------------------------
    // SUBJECTS  – all subjects for assignment UI
    // ------------------------------------------------
    case 'subjects':
        $sql = "SELECT id, subject_name, subject_code FROM subjects ORDER BY subject_name ASC";
        $subjects = $db->query($sql);
        ob_end_clean();
        successResponse($subjects ?: []);
        break;

    // ------------------------------------------------
    // CLASSES  – available classes for assignment
    // ------------------------------------------------
    case 'classes':
        $teacherId = isset($_GET['teacher_id']) ? (int)$_GET['teacher_id'] : 0;

        if ($teacherId) {
            // Return unassigned classes + this teacher's own class
            $sql = "SELECT c.id, c.class_name, c.class_color, c.teacher_id,
                           u.full_name AS assigned_teacher_name
                    FROM classes c
                    LEFT JOIN users u ON u.id = c.teacher_id AND u.role = 'teacher'
                    WHERE c.teacher_id IS NULL OR c.teacher_id = :tid
                    ORDER BY c.class_name ASC";
            $classes = $db->query($sql, [':tid' => $teacherId]);
        } else {
            $sql = "SELECT c.id, c.class_name, c.class_color, c.teacher_id,
                           u.full_name AS assigned_teacher_name
                    FROM classes c
                    LEFT JOIN users u ON u.id = c.teacher_id AND u.role = 'teacher'
                    ORDER BY c.class_name ASC";
            $classes = $db->query($sql);
        }

        ob_end_clean();
        successResponse($classes ?: []);
        break;

    // ------------------------------------------------
    // CREATE  – new teacher (multipart/form-data for photo)
    // ------------------------------------------------
    case 'create':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('Method not allowed', 405);
        }

        $contentType = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
        $isMultipart = strpos($contentType, 'multipart/form-data') !== false;

        if ($isMultipart) {
            $data = $_POST;
        } else {
            $data = json_decode(file_get_contents('php://input'), true);
        }

        if (empty($data['email']) || empty($data['full_name'])) {
            ob_end_clean();
            errorResponse('Email and full name are required', 400);
        }

        $nameV = nsmsValidatePersonName($data['full_name'], 'Full name');
        if (!$nameV['ok']) { ob_end_clean(); errorResponse($nameV['error'], 400); }
        $data['full_name'] = $nameV['value'];

        $emailV = nsmsValidateEmail($data['email'], true, 'Email');
        if (!$emailV['ok']) { ob_end_clean(); errorResponse($emailV['error'], 400); }
        $data['email'] = $emailV['value'];

        // One email = one user only
        if (function_exists('nsmsAssertEmailAvailable')) {
            $taken = nsmsAssertEmailAvailable($db, $data['email'], null);
            if (!$taken['ok']) {
                ob_end_clean();
                errorResponse($taken['error'], 400);
            }
        } else {
            $dup = $db->queryOne(
                "SELECT id FROM users WHERE LOWER(TRIM(email)) = :e LIMIT 1",
                array(':e' => $data['email'])
            );
            if ($dup) {
                ob_end_clean();
                errorResponse('This email is already registered to another user. Each email can only belong to one account.', 400);
            }
        }

        $ph = nsmsValidatePhone(isset($data['phone']) ? $data['phone'] : '', true, 'Phone number');
        if (!$ph['ok']) { ob_end_clean(); errorResponse($ph['error'], 400); }
        $data['phone'] = $ph['value'];

        if (isset($data['status']) && $data['status'] !== '') {
            if (!in_array($data['status'], array('active', 'inactive'), true)) {
                ob_end_clean(); errorResponse('Invalid status', 400);
            }
        }

        // Handle passport photo upload
        $photoUrl     = null;
        $photoWarning = null;
        if ($isMultipart && isset($_FILES['photo'])) {
            if ($_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = uploadTeacherPhoto($_FILES['photo']);
                if ($uploadResult['success']) {
                    $photoUrl = $uploadResult['url'];
                } else {
                    $photoWarning = 'Photo upload failed: ' . $uploadResult['error'];
                }
            } elseif ($_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
                $phpUploadErrors = [
                    UPLOAD_ERR_INI_SIZE   => 'File exceeds upload_max_filesize in php.ini',
                    UPLOAD_ERR_FORM_SIZE  => 'File exceeds MAX_FILE_SIZE in form',
                    UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded',
                    UPLOAD_ERR_NO_TMP_DIR => 'No temporary folder available',
                    UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                    UPLOAD_ERR_EXTENSION  => 'Upload blocked by PHP extension',
                ];
                $errCode = $_FILES['photo']['error'];
                $photoWarning = 'Photo upload failed: '
                    . (isset($phpUploadErrors[$errCode]) ? $phpUploadErrors[$errCode] : 'Error code ' . $errCode);
            }
        }
        $rawPassword = (isset($data['password']) && trim((string)$data['password']) !== '')
            ? trim((string)$data['password'])
            : 'teacher123';
        $status      = (isset($data['status']) && $data['status'])   ? $data['status']   : 'active';

        $sql = "INSERT INTO users (email, password_hash, role, full_name, phone, status, photo_url, password_changed, created_at)
                VALUES (:email, :password_hash, 'teacher', :full_name, :phone, :status, :photo_url, 0, NOW())";

        $params = [
            ':email'         => strtolower(trim($data['email'])),
            ':password_hash' => password_hash($rawPassword, PASSWORD_DEFAULT),
            ':full_name'     => trim($data['full_name']),
            ':phone'         => isset($data['phone']) ? trim($data['phone']) : null,
            ':status'        => $status,
            ':photo_url'     => $photoUrl,
        ];

        $teacherId = $db->execute($sql, $params);

        if (!$teacherId) {
            ob_end_clean();
            errorResponse('This email is already registered to another user. Each email can only belong to one account.', 409);
        }

        notifyNewTeacherWelcome($db, trim($data['email']), trim($data['full_name']), $rawPassword);

        // Assign class
        $classIds = array();
        if (!empty($data['class_ids']) && is_array($data['class_ids'])) {
            $classIds = $data['class_ids'];
        } elseif (!empty($data['class_id'])) {
            $classIds = array($data['class_id']);
        }
        if (!empty($classIds)) {
            nsmsSyncTeacherClasses($db, $teacherId, $classIds);
        }

        // Assign subjects
        _assignSubjects($db, $teacherId, isset($data['subject_ids']) ? $data['subject_ids'] : null);

        // ── Notify teacher: class assignment ─────────────────────────────────
        if (!empty($data['class_id'])) {
            $clsRow = $db->query(
                "SELECT class_name FROM classes WHERE id = :cid",
                [':cid' => (int)$data['class_id']]
            );
            if ($clsRow) {
                _notifyTeacher(
                    $db, $teacherId,
                    'class_assignment',
                    '🏫 Class Assigned: ' . $clsRow[0]['class_name'],
                    'You have been assigned as the class teacher for ' . $clsRow[0]['class_name']
                    . '. You can now manage attendance, homework, and reports for this class.',
                    'class_assign_' . (int)$data['class_id']
                );
            }
        }

        // ── Notify teacher: each subject assigned ─────────────────────────────
        if (!empty($data['subject_ids'])) {
            $sids = is_array($data['subject_ids'])
                  ? $data['subject_ids']
                  : explode(',', $data['subject_ids']);
            foreach ($sids as $sid) {
                $sid = (int)$sid;
                if ($sid <= 0) continue;
                $subRow = $db->query(
                    "SELECT subject_name FROM subjects WHERE id = :sid",
                    [':sid' => $sid]
                );
                if ($subRow) {
                    _notifyTeacher(
                        $db, $teacherId,
                        'subject_assignment',
                        '📚 Subject Assigned: ' . $subRow[0]['subject_name'],
                        'You have been assigned to teach ' . $subRow[0]['subject_name'] . '.',
                        'subject_assign_' . $sid . '_' . $teacherId
                    );
                }
            }
        }

        $responseData = ['id' => $teacherId, 'photo_url' => $photoUrl];
        if ($photoWarning) {
            $responseData['photo_warning'] = $photoWarning;
        }
        ob_end_clean();
        successResponse($responseData, 'Teacher created successfully');
        break;

    // ------------------------------------------------
    // UPDATE  – edit teacher details, photo, class, subjects
    // ------------------------------------------------
    case 'update':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('Method not allowed', 405);
        }

        $contentType = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
        $isMultipart = strpos($contentType, 'multipart/form-data') !== false;

        if ($isMultipart) {
            $data = $_POST;
        } else {
            $data = json_decode(file_get_contents('php://input'), true);
        }

        $id = isset($data['id']) ? (int)$data['id'] : 0;
        if (!$id) {
            ob_end_clean();
            errorResponse('Teacher ID required', 400);
        }

        // Handle new photo upload
        $photoSql     = '';
        $photoParam   = [];
        $photoWarning = null;
        if ($isMultipart && isset($_FILES['photo'])) {
            if ($_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = uploadTeacherPhoto($_FILES['photo']);
                if ($uploadResult['success']) {
                    $photoSql               = ', photo_url = :photo_url';
                    $photoParam[':photo_url'] = $uploadResult['url'];
                } else {
                    $photoWarning = 'Photo upload failed: ' . $uploadResult['error'];
                }
            } elseif ($_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
                $phpUploadErrors = [
                    UPLOAD_ERR_INI_SIZE   => 'File exceeds upload_max_filesize in php.ini',
                    UPLOAD_ERR_FORM_SIZE  => 'File exceeds MAX_FILE_SIZE in form',
                    UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded',
                    UPLOAD_ERR_NO_TMP_DIR => 'No temporary folder available',
                    UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                    UPLOAD_ERR_EXTENSION  => 'Upload blocked by PHP extension',
                ];
                $errCode = $_FILES['photo']['error'];
                $photoWarning = 'Photo upload failed: '
                    . (isset($phpUploadErrors[$errCode]) ? $phpUploadErrors[$errCode] : 'Error code ' . $errCode);
            }
        }

        if (empty($data['email']) || empty($data['full_name'])) {
            ob_end_clean();
            errorResponse('Email and full name are required', 400);
        }
        $nameV = nsmsValidatePersonName($data['full_name'], 'Full name');
        if (!$nameV['ok']) { ob_end_clean(); errorResponse($nameV['error'], 400); }
        $emailV = nsmsValidateEmail($data['email'], true, 'Email');
        if (!$emailV['ok']) { ob_end_clean(); errorResponse($emailV['error'], 400); }
        if (function_exists('nsmsAssertEmailAvailable')) {
            $taken = nsmsAssertEmailAvailable($db, $emailV['value'], $id);
            if (!$taken['ok']) {
                ob_end_clean();
                errorResponse($taken['error'], 400);
            }
        } else {
            $dup = $db->queryOne(
                "SELECT id FROM users WHERE LOWER(TRIM(email)) = :e AND id != :id LIMIT 1",
                array(':e' => $emailV['value'], ':id' => $id)
            );
            if ($dup) {
                ob_end_clean();
                errorResponse('This email is already registered to another user. Each email can only belong to one account.', 400);
            }
        }
        $phoneVal = null;
        if (isset($data['phone']) && trim((string)$data['phone']) !== '') {
            $ph = nsmsValidatePhone($data['phone'], false, 'Phone number');
            if (!$ph['ok']) { ob_end_clean(); errorResponse($ph['error'], 400); }
            $phoneVal = $ph['value'];
        }
        $status = (isset($data['status']) && $data['status']) ? $data['status'] : 'active';
        if (!in_array($status, array('active', 'inactive'), true)) {
            ob_end_clean(); errorResponse('Invalid status', 400);
        }

        $sql = "UPDATE users
                SET full_name = :full_name,
                    email     = :email,
                    phone     = :phone,
                    status    = :status
                    {$photoSql}
                WHERE id = :id AND role = 'teacher'";

        $params = [
            ':id'        => $id,
            ':full_name' => $nameV['value'],
            ':email'     => $emailV['value'],
            ':phone'     => $phoneVal,
            ':status'    => $status,
        ];
        $params = array_merge($params, $photoParam);

        $result = $db->execute($sql, $params);

        if ($result === false) {
            ob_end_clean();
            errorResponse('Failed to update teacher', 500);
        }

        // ── Snapshot current assignments BEFORE wiping (for diff-based notifications) ──
        $oldClassRow = $db->query(
            "SELECT id, class_name FROM classes WHERE teacher_id = :tid",
            [':tid' => $id]
        );
        $oldClassId   = $oldClassRow ? (int)$oldClassRow[0]['id']        : 0;

        $oldSubRows   = $db->query(
            "SELECT subject_id FROM teacher_subjects WHERE teacher_id = :tid",
            [':tid' => $id]
        ) ?: [];
        $oldSubjectIds = array_map('intval', array_column($oldSubRows, 'subject_id'));

        if (array_key_exists('class_ids', $data) || array_key_exists('class_id', $data)) {
            $classIds = array();
            if (array_key_exists('class_ids', $data) && is_array($data['class_ids'])) {
                $classIds = $data['class_ids'];
            } elseif (!empty($data['class_id'])) {
                $classIds = array($data['class_id']);
            }
            nsmsSyncTeacherClasses($db, $id, $classIds);
        }


        // Re-assign subjects: wipe and re-insert
        $db->execute("DELETE FROM teacher_subjects WHERE teacher_id = :tid", [':tid' => $id]);
        _assignSubjects($db, $id, isset($data['subject_ids']) ? $data['subject_ids'] : null);

        // ── Notify teacher: class changed? ────────────────────────────────────
        $newClassId = !empty($data['class_id']) ? (int)$data['class_id'] : 0;
        if ($newClassId && $newClassId !== $oldClassId) {
            $clsRow = $db->query(
                "SELECT class_name FROM classes WHERE id = :cid",
                [':cid' => $newClassId]
            );
            if ($clsRow) {
                _notifyTeacher(
                    $db, $id,
                    'class_assignment',
                    '🏫 Class Assigned: ' . $clsRow[0]['class_name'],
                    'You have been assigned as the class teacher for ' . $clsRow[0]['class_name']
                    . '. You can now manage attendance, homework, and reports for this class.',
                    'class_assign_' . $newClassId
                );
            }
        }

        // ── Notify teacher: newly added subjects only ─────────────────────────
        $newSubjectIds = [];
        if (!empty($data['subject_ids'])) {
            $raw = is_array($data['subject_ids'])
                 ? $data['subject_ids']
                 : explode(',', $data['subject_ids']);
            foreach ($raw as $s) {
                $s = (int)$s;
                if ($s > 0) $newSubjectIds[] = $s;
            }
        }
        $addedSubjectIds = array_diff($newSubjectIds, $oldSubjectIds);
        foreach ($addedSubjectIds as $sid) {
            $subRow = $db->query(
                "SELECT subject_name FROM subjects WHERE id = :sid",
                [':sid' => (int)$sid]
            );
            if ($subRow) {
                _notifyTeacher(
                    $db, $id,
                    'subject_assignment',
                    '📚 Subject Assigned: ' . $subRow[0]['subject_name'],
                    'You have been assigned to teach ' . $subRow[0]['subject_name'] . '.',
                    'subject_assign_' . (int)$sid . '_' . $id
                );
            }
        }

        $responseData = [];
        if ($photoWarning) {
            $responseData['photo_warning'] = $photoWarning;
        }
        ob_end_clean();
        successResponse($responseData ?: null, 'Teacher updated successfully');
        break;

    // ------------------------------------------------
    // DELETE  – soft delete (set inactive, unlink class)
    // ------------------------------------------------
    case 'delete':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('Method not allowed', 405);
        }

        $body = json_decode(file_get_contents('php://input'), true);
        $id   = isset($body['id']) ? (int)$body['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

        if (!$id) {
            ob_end_clean();
            errorResponse('Teacher ID required', 400);
        }

        $db->execute("UPDATE classes SET teacher_id = NULL WHERE teacher_id = :tid", [':tid' => $id]);
        $result = $db->execute(
            "UPDATE users SET status = 'inactive' WHERE id = :id AND role = 'teacher'",
            [':id' => $id]
        );

        if ($result !== false) {
            ob_end_clean();
            successResponse(null, 'Teacher removed successfully');
        } else {
            ob_end_clean();
            errorResponse('Failed to remove teacher', 500);
        }
        break;

    // ------------------------------------------------
    // RESET PASSWORD – admin re-issues activation credentials
    // ------------------------------------------------
    case 'reset_password':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('Method not allowed', 405);
        }
        if (!function_exists('requireRole')) {
            ob_end_clean();
            errorResponse('Unauthorized', 401);
        }
        requireRole(array('admin'));

        $body = json_decode(file_get_contents('php://input'), true);
        if (!is_array($body)) $body = array();
        $id = isset($body['id']) ? (int)$body['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        if (!$id) {
            ob_end_clean();
            errorResponse('Teacher ID required', 400);
        }

        $row = $db->queryOne(
            "SELECT id FROM users WHERE id = :id AND role = 'teacher' LIMIT 1",
            array(':id' => $id)
        );
        if (!$row) {
            ob_end_clean();
            errorResponse('Teacher not found', 404);
        }

        $result = nsmsResetActivation($db, $id);
        if (empty($result['ok'])) {
            ob_end_clean();
            errorResponse(isset($result['error']) ? $result['error'] : 'Reset failed', 400);
        }

        ob_end_clean();
        $payload = array(
            'email'         => $result['user']['email'],
            'email_sent'    => !empty($result['email_sent']),
            'mode'          => isset($result['mode']) ? $result['mode'] : 'link',
            'reset_url'     => isset($result['reset_url']) ? $result['reset_url'] : null,
            'temp_password' => isset($result['temp_password']) ? $result['temp_password'] : null,
        );
        $msg = !empty($result['email_sent'])
            ? 'Reset link emailed to the teacher (valid 1 hour).'
            : (isset($result['reset_url'])
                ? 'Email failed — copy the reset link from the response and share it securely.'
                : 'Password reset completed.');
        successResponse($payload, $msg);
        break;

    default:
        ob_end_clean();
        errorResponse('Invalid action');
}

// ====================================================
// HELPERS
// ====================================================

/**
 * Insert subject assignments for a teacher.
 * $subjectIds can be a comma-separated string or an array.
 */
function _assignSubjects($db, $teacherId, $subjectIds) {
    if (empty($subjectIds)) {
        return;
    }
    if (!is_array($subjectIds)) {
        $subjectIds = explode(',', $subjectIds);
    }
    foreach ($subjectIds as $sid) {
        $sid = (int)$sid;
        if ($sid > 0) {
            $db->execute(
                "INSERT IGNORE INTO teacher_subjects (teacher_id, subject_id) VALUES (:tid, :sid)",
                [':tid' => $teacherId, ':sid' => $sid]
            );
        }
    }
}

/**
 * Upload a teacher passport photo.
 * Returns ['success' => bool, 'url' => string] or ['success' => false, 'error' => string]
 *
 * Path is resolved from __FILE__ so it works regardless of how PHP resolves __DIR__
 * at include/require depth.
 * Structure assumed:
 *   nsms/
 *     api/teachers.php   ← this file
 *     public/uploads/teachers/
 */
function uploadTeacherPhoto($file) {
    // Step 1: resolve absolute upload directory from this file's real location
    $thisFile  = realpath(__FILE__);                          // /…/nsms/api/teachers.php
    $apiDir    = dirname($thisFile);                          // /…/nsms/api
    $nsmsRoot  = dirname($apiDir);                            // /…/nsms
    $uploadDir = $nsmsRoot . DIRECTORY_SEPARATOR . 'public'
               . DIRECTORY_SEPARATOR . 'uploads'
               . DIRECTORY_SEPARATOR . 'teachers'
               . DIRECTORY_SEPARATOR;

    // Step 2: create directory if missing
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0755, true)) {
            return [
                'success' => false,
                'error'   => 'Cannot create upload directory: ' . $uploadDir
            ];
        }
    }

    // Step 3: check directory is writable
    if (!is_writable($uploadDir)) {
        return [
            'success' => false,
            'error'   => 'Upload directory is not writable: ' . $uploadDir
        ];
    }

    // Step 4: check file size BEFORE touching type (fast fail)
    if ($file['size'] > 5 * 1024 * 1024) {
        return ['success' => false, 'error' => 'File too large — max 5 MB'];
    }

    // Step 5: detect MIME type from actual file bytes (not browser-supplied type)
    $allowedMime = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $allowedExt  = ['jpg' => 'jpg', 'jpeg' => 'jpg', 'png' => 'png', 'gif' => 'gif', 'webp' => 'webp'];

    if (function_exists('finfo_open')) {
        $finfo    = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
    } else {
        // Fallback: trust browser type but normalise 'image/jpg' → 'image/jpeg'
        $mimeType = ($file['type'] === 'image/jpg') ? 'image/jpeg' : $file['type'];
    }

    if (!in_array($mimeType, $allowedMime)) {
        return [
            'success' => false,
            'error'   => 'Invalid file type (' . $mimeType . '). Use JPG, PNG, or WebP'
        ];
    }

    // Step 6: pick safe extension from detected MIME, not from filename
    $mimeToExt = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
    ];
    $ext = $mimeToExt[$mimeType];

    // Step 7: generate unique filename and move
    $filename = 'teacher_' . time() . '_' . mt_rand(1000, 9999) . '.' . $ext;
    $dest     = $uploadDir . $filename;

    if (move_uploaded_file($file['tmp_name'], $dest)) {
        // Web URL path (adjust if your public root differs)
        $webUrl = '/nsms/public/uploads/teachers/' . $filename;
        return ['success' => true, 'url' => $webUrl, 'path' => $dest];
    }

    return [
        'success' => false,
        'error'   => 'move_uploaded_file failed. tmp=' . $file['tmp_name'] . ' dest=' . $dest
    ];
}

/**
 * Insert a notification for a teacher, de-duplicated by reference_key.
 * Degrades gracefully if the notifications table or reference_key column
 * does not exist yet.
 *
 * @param Database $db
 * @param int      $teacherUserId  users.id of the recipient teacher
 * @param string   $type           notification type slug
 * @param string   $title          short headline shown in the bell panel
 * @param string   $message        full descriptive text
 * @param string   $refKey         unique key — prevents duplicate inserts
 */
function _notifyTeacher($db, $teacherUserId, $type, $title, $message, $refKey) {
    try {
        // ── De-duplicate: prefer reference_key lookup, fall back to title+type+today ──
        $isDup = false;
        try {
            $ex = $db->query(
                "SELECT id FROM notifications
                  WHERE user_id = ? AND reference_key = ? LIMIT 1",
                [$teacherUserId, $refKey]
            );
            $isDup = (bool)$ex;
        } catch (Exception $e) {
            try {
                $ex = $db->query(
                    "SELECT id FROM notifications
                      WHERE user_id = ? AND type = ? AND title = ?
                        AND DATE(created_at) = CURDATE() LIMIT 1",
                    [$teacherUserId, $type, $title]
                );
                $isDup = (bool)$ex;
            } catch (Exception $e2) { /* can't check — allow insert */ }
        }
        if ($isDup) return;

        // ── Insert: try with reference_key, fall back without ────────────────
        try {
            $db->execute(
                "INSERT INTO notifications
                     (user_id, type, title, message, is_read, reference_key, created_at)
                 VALUES (?, ?, ?, ?, 0, ?, NOW())",
                [$teacherUserId, $type, $title, $message, $refKey]
            );
        } catch (Exception $e) {
            // reference_key column not yet added — insert without it
            $db->execute(
                "INSERT INTO notifications
                     (user_id, type, title, message, is_read, created_at)
                 VALUES (?, ?, ?, ?, 0, NOW())",
                [$teacherUserId, $type, $title, $message]
            );
        }
    } catch (Exception $e) { /* non-fatal — never break the main response */ }
}

/**
 * Warm welcome email sent once, right after a new teacher account is
 * created — includes the initial login credentials needed for their very
 * first sign-in. Best-effort: never blocks teacher creation if it fails.
 */
function notifyNewTeacherWelcome($db, $email, $fullName, $plainPassword) {
    try {
        $schoolRow  = $db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key = 'school_name'");
        $schoolName = ($schoolRow && !empty($schoolRow['setting_value'])) ? $schoolRow['setting_value'] : 'our school';
        $loginUrl   = defined('SITE_URL') ? rtrim(SITE_URL, '/') . '/public/index.html' : '#';

        $subject = 'Welcome to ' . $schoolName . ', ' . $fullName . '! 🎉';
        $body =
            '<p>Dear ' . htmlspecialchars($fullName) . ',</p>' .
            '<p>Welcome to the <strong>' . htmlspecialchars($schoolName) . '</strong> team! We\'re delighted to have you on board. 🌱</p>' .
            '<p>A staff account has been created for you on our school management portal, where you\'ll be able to manage ' .
            'your class register, gradebook, attendance, homework, and messages with parents — all in one place.</p>' .
            '<p><strong>Your login details:</strong><br>' .
            'Email: ' . htmlspecialchars($email) . '<br>' .
            'Temporary password: <strong>' . htmlspecialchars($plainPassword) . '</strong></p>' .
            '<p>Please log in and you\'ll be guided to set your own personal password on your first visit:</p>' .
            '<p><a href="' . htmlspecialchars($loginUrl) . '" style="display:inline-block;padding:10px 20px;background:#1B3D2F;color:#fff;text-decoration:none;border-radius:6px;">Log In to the Teacher Portal</a></p>' .
            '<p style="color:#888;font-size:12px;">If you weren\'t expecting this email, please contact the school administrator.</p>';

        sendEmail($email, $subject, $body);
    } catch (Exception $e) {
        error_log('notifyNewTeacherWelcome error: ' . $e->getMessage());
    }
}
