<?php
/**
 * Teacher Homework API
 * /nsms/api/teacher-homework.php
 * PHP 7.2 compatible.
 *
 * Schema facts:
 *   classes.teacher_id = users.id  (teacher → class)
 *   homework: id, class_id, posted_by, subject, description, due_date, created_at
 *   teacher_subjects: id, teacher_id, subject_id, assigned_at
 *   subjects: id, subject_name, subject_code
 *
 * Actions:
 *   GET  ?action=subjects               — subjects assigned to the teacher
 *   GET  ?action=list                   — homework for the teacher's class (recent first)
 *   POST ?action=create                 — post new homework assignment
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once __DIR__ . '/../includes/sync/SyncHooks.php';

if (function_exists('applyApiHeaders')) { applyApiHeaders(); }


requireRole(['admin', 'teacher']);

$db   = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

ensureHomeworkSchema($db);

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'subjects':       getSubjects($db);              break;
    case 'list':            listHomework($db);            break;
    case 'create':          createHomework($db);          break;
    case 'acknowledgments': getHomeworkAcknowledgments($db); break;
    case 'update':           updateHomework($db);         break;
    case 'grade':            gradeHomework($db);          break;
    case 'comments':         listHomeworkCommentsTeacher($db); break;
    default: ob_end_clean(); errorResponse('Invalid action');
}

/**
 * Adds the columns/tables newer homework features need, on first use —
 * no manual migration required. Safe to call on every request: each
 * statement is wrapped so an "already exists" error is a silent no-op.
 */
function ensureHomeworkSchema($db) {
    try { $db->execute("ALTER TABLE homework ADD COLUMN due_time TIME NULL AFTER due_date"); } catch (Exception $e) { /* already exists */ }
    try { $db->execute("ALTER TABLE homework ADD COLUMN updated_at DATETIME NULL AFTER created_at"); } catch (Exception $e) { /* already exists */ }
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS homework_grades (
                id int UNSIGNED NOT NULL AUTO_INCREMENT,
                homework_id int NOT NULL,
                student_id int NOT NULL,
                grade varchar(20) NOT NULL,
                feedback varchar(500) DEFAULT NULL,
                graded_by int NOT NULL,
                graded_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_hw_student (homework_id, student_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) { /* non-fatal */ }

    // Numeric score (0-10), so a homework grade can feed the gradebook's
    // percentage-based averages the same way every other assessment does.
    try { $db->execute("ALTER TABLE homework_grades ADD COLUMN score DECIMAL(4,2) NULL AFTER grade"); } catch (Exception $e) { /* already exists */ }

    // Links a gradebook_assessments row back to the homework it was
    // generated from, so every student's grade for the same homework
    // reuses one shared assessment instead of creating duplicates.
    try { $db->execute("ALTER TABLE gradebook_assessments ADD COLUMN homework_id INT NULL AFTER id"); } catch (Exception $e) { /* already exists */ }
}

/**
 * A teacher may manage a homework item if they originally posted it, or if
 * they're the class's currently-assigned teacher (covers reassignment).
 */
function teacherOwnsHomework($db, $homeworkId, $userId) {
    $row = $db->queryOne(
        "SELECT h.id
           FROM homework h
           JOIN classes  c ON c.id = h.class_id
          WHERE h.id = ? AND (h.posted_by = ? OR c.teacher_id = ?)",
        [$homeworkId, $userId, $userId]
    );
    return (bool)$row;
}

/* ─────────────────────────────────────────
   HELPER: resolve class_id
   classes.teacher_id = session user id
───────────────────────────────────────── */
function resolveClassId($db) {
    if (isset($_GET['class_id']) && (int)$_GET['class_id'] > 0) {
        return (int)$_GET['class_id'];
    }
    $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
    if (!$userId) return null;
    $row = $db->queryOne(
        "SELECT id FROM classes WHERE teacher_id = :uid LIMIT 1",
        [':uid' => $userId]
    );
    return $row ? (int)$row['id'] : null;
}

/* ─────────────────────────────────────────
   HELPER: resolve teacher's user id
───────────────────────────────────────── */
function resolveUserId() {
    if (isset($_GET['teacher_id']) && (int)$_GET['teacher_id'] > 0) {
        return (int)$_GET['teacher_id'];
    }
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
}

/* ─────────────────────────────────────────
   GET SUBJECTS assigned to teacher
───────────────────────────────────────── */
function getSubjects($db) {
    $userId = resolveUserId();
    if (!$userId) {
        ob_end_clean();
        successResponse([]); /* graceful empty */
        return;
    }

    $rows = $db->query(
        "SELECT s.id, s.subject_name, s.subject_code
         FROM   teacher_subjects ts
         JOIN   subjects s ON s.id = ts.subject_id
         WHERE  ts.teacher_id = :uid
         ORDER  BY s.subject_name ASC",
        [':uid' => $userId]
    );

    ob_end_clean();
    successResponse($rows ?: []);
}

/* ─────────────────────────────────────────
   LIST HOMEWORK for teacher's class
───────────────────────────────────────── */
function listHomework($db) {
    $classId = resolveClassId($db);
    if (!$classId) {
        ob_end_clean();
        successResponse([]);
        return;
    }

    $rows = $db->query(
        "SELECT h.id, h.subject, h.description, h.due_date, h.due_time,
                h.created_at, h.updated_at, u.full_name AS posted_by_name,
                (SELECT COUNT(*) FROM students s2
                  WHERE s2.class_id = h.class_id AND s2.status = 'active')  AS total_students,
                (SELECT COUNT(*) FROM homework_acknowledgements a
                  WHERE a.homework_id = h.id)                               AS acknowledged_count
         FROM   homework h
         JOIN   users    u ON u.id = h.posted_by
         WHERE  h.class_id = :cid
         ORDER  BY h.created_at DESC
         LIMIT  20",
        [':cid' => $classId]
    );

    if ($rows) {
        foreach ($rows as &$row) {
            if (isset($row['subject'])) {
                $row['subject'] = html_entity_decode($row['subject'], ENT_QUOTES, 'UTF-8');
            }
            if (isset($row['description'])) {
                $row['description'] = html_entity_decode($row['description'], ENT_QUOTES, 'UTF-8');
            }
        }
        unset($row);
    }

    ob_end_clean();
    successResponse($rows ?: []);
}

/* ─────────────────────────────────────────
   CREATE HOMEWORK
   Accepts multipart/form-data (supports file attachments)
───────────────────────────────────────── */
function createHomework($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }

    $classId = resolveClassId($db);
    if (!$classId) { ob_end_clean(); errorResponse('No class assigned to this teacher.'); }

    $userId = resolveUserId();
    if (!$userId)  { ob_end_clean(); errorResponse('Authentication required.', 401); }

    // Store plain text (React/JSON consumers escape on display).
    // htmlspecialchars here caused subjects like "Culture & Arts" to show as "Culture &amp; Arts".
    $subject     = isset($_POST['subject'])     ? trim(strip_tags($_POST['subject']))     : '';
    $description = isset($_POST['description']) ? trim(strip_tags($_POST['description'])) : '';
    $dueDate     = isset($_POST['due_date'])     ? trim($_POST['due_date'])        : '';

    if (!$subject)     { ob_end_clean(); errorResponse('Subject is required.'); }
    if (!$description) { ob_end_clean(); errorResponse('Homework task is required.'); }
    if (!$dueDate || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dueDate)) {
        ob_end_clean(); errorResponse('Valid due date is required.');
    }

    // Optional file attachment (first file wins for attachment_url; keep simple for parents)
    $attachmentUrl = null;
    $fileKey = null;
    if (!empty($_FILES)) {
        foreach ($_FILES as $key => $f) {
            if (is_array($f) && isset($f['error']) && (int)$f['error'] === UPLOAD_ERR_OK) {
                $fileKey = $key;
                break;
            }
        }
    }
    if ($fileKey !== null) {
        $allowed = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'doc', 'docx');
        if (function_exists('nsmsStoreUpload')) {
            $up = nsmsStoreUpload($_FILES[$fileKey], 'homework', $allowed, 5 * 1024 * 1024);
            if (!empty($up['success']) && !empty($up['url'])) {
                $attachmentUrl = $up['url'];
            } elseif (!empty($up['error'])) {
                error_log('homework attachment: ' . $up['error']);
            }
        } else {
            $up = uploadFile($_FILES[$fileKey], 'uploads/homework/', $allowed);
            if (!empty($up['success']) && !empty($up['path'])) {
                $attachmentUrl = $up['path'];
            }
        }
    }

    // Ensure attachment_url column exists
    try {
        $cols = $db->query("SHOW COLUMNS FROM homework LIKE 'attachment_url'");
        if (empty($cols)) {
            $db->execute("ALTER TABLE homework ADD COLUMN attachment_url VARCHAR(255) NULL DEFAULT NULL");
        }
    } catch (Exception $e) { /* ignore */ }

    if ($attachmentUrl) {
        $hwId = $db->execute(
            "INSERT INTO homework (class_id, posted_by, subject, description, due_date, attachment_url, created_at)
             VALUES (:cid, :by, :sub, :desc, :due, :att, NOW())",
            [':cid'  => $classId, ':by'   => $userId,
             ':sub'  => $subject, ':desc' => $description, ':due'  => $dueDate,
             ':att'  => $attachmentUrl]
        );
    } else {
        $hwId = $db->execute(
            "INSERT INTO homework (class_id, posted_by, subject, description, due_date, created_at)
             VALUES (:cid, :by, :sub, :desc, :due, NOW())",
            [':cid'  => $classId, ':by'   => $userId,
             ':sub'  => $subject, ':desc' => $description, ':due'  => $dueDate]
        );
    }

    if (!$hwId) { ob_end_clean(); errorResponse('Failed to create homework.', 500); }

    notifyClassOfHomework($db, $classId, $subject, $description, $dueDate);

    ob_end_clean();
    if (class_exists('SyncHooks')) {
        SyncHooks::afterWrite($db, 'homework', (int)$hwId, 'CREATE', array(
            'class_id' => $classId,
            'subject' => $subject,
            'description' => isset($description) ? $description : null,
            'due_date' => isset($dueDate) ? $dueDate : null,
            'posted_by' => $userId,
        ));
    }
    successResponse(['id' => $hwId, 'subject' => $subject], 'Homework posted successfully');
}

/**
 * Email every parent whose child is in this class about the new homework.
 * Best-effort — runs after the homework row is already saved, so an email
 * failure never blocks the teacher from posting.
 */
function notifyClassOfHomework($db, $classId, $subject, $description, $dueDate) {
    try {
        $classRow  = $db->queryOne("SELECT class_name FROM classes WHERE id = ?", [$classId]);
        $className = $classRow ? $classRow['class_name'] : 'the class';

        $guardians = $db->query(
            "SELECT DISTINCT u.email, u.full_name, s.student_name
               FROM students s
               JOIN parents p ON p.student_id = s.id
               JOIN users u   ON u.id = p.user_id
              WHERE s.class_id = ? AND s.status = 'active'
                AND u.email IS NOT NULL AND u.email != ''",
            [$classId]
        ) ?: [];

        $niceDate = date('l, j F Y', strtotime($dueDate));
        foreach ($guardians as $g) {
            $emailSubject = 'New Homework Posted — ' . $className . ' (' . $subject . ')';
            $body =
                '<p>Dear ' . htmlspecialchars($g['full_name']) . ',</p>' .
                '<p>New homework has been posted for <strong>' . htmlspecialchars($g['student_name']) . '</strong> ' .
                '(' . htmlspecialchars($className) . '):</p>' .
                '<p><strong>Subject:</strong> ' . htmlspecialchars($subject) . '<br>' .
                '<strong>Task:</strong> ' . htmlspecialchars($description) . '<br>' .
                '<strong>Due:</strong> ' . $niceDate . '</p>' .
                '<p>You can view and acknowledge this homework anytime from the parent portal.</p>' .
                '<p style="color:#888;font-size:12px;">This is an automated notice from the school homework system.</p>';
            sendEmail($g['email'], $emailSubject, $body);
        }
    } catch (Exception $e) {
        error_log('notifyClassOfHomework error: ' . $e->getMessage());
    }
}

/* ─────────────────────────────────────────
   ACKNOWLEDGMENTS ROSTER
   Every student in the class, whether they've acknowledged, and any
   grade already given — regardless of acknowledgment status.
───────────────────────────────────────── */
function getHomeworkAcknowledgments($db) {
    $userId = resolveUserId();
    if (!$userId) { ob_end_clean(); errorResponse('Authentication required.', 401); }

    $hwId = isset($_GET['homework_id']) ? (int)$_GET['homework_id'] : 0;
    if (!$hwId) { ob_end_clean(); errorResponse('homework_id required'); }

    $hw = $db->queryOne(
        "SELECT h.*, c.class_name
           FROM homework h JOIN classes c ON c.id = h.class_id
          WHERE h.id = ?",
        [$hwId]
    );
    if (!$hw) { ob_end_clean(); errorResponse('Homework not found', 404); }
    if (!teacherOwnsHomework($db, $hwId, $userId)) { ob_end_clean(); errorResponse('Not authorized for this homework', 403); }

    $roster = $db->query(
        "SELECT s.id AS student_id, s.student_name,
                a.acknowledged_at,
                g.grade, g.score, g.feedback, g.graded_at
           FROM students s
           LEFT JOIN homework_acknowledgements a ON a.homework_id = ? AND a.student_id = s.id
           LEFT JOIN homework_grades g          ON g.homework_id = ? AND g.student_id = s.id
          WHERE s.class_id = ? AND s.status = 'active'
          ORDER BY s.student_name ASC",
        [$hwId, $hwId, $hw['class_id']]
    ) ?: [];

    $ackCount = 0;
    foreach ($roster as $r) { if (!empty($r['acknowledged_at'])) $ackCount++; }

    if ($hw) {
        if (isset($hw['subject'])) {
            $hw['subject'] = html_entity_decode($hw['subject'], ENT_QUOTES, 'UTF-8');
        }
        if (isset($hw['description'])) {
            $hw['description'] = html_entity_decode($hw['description'], ENT_QUOTES, 'UTF-8');
        }
    }

    ob_end_clean();
    successResponse([
        'homework'           => $hw,
        'roster'             => $roster,
        'acknowledged_count' => $ackCount,
        'total_count'        => count($roster),
    ]);
}

/* ─────────────────────────────────────────
   UPDATE HOMEWORK
   Edit subject/description, and/or move the deadline — either to an
   explicit new due_date (+ optional due_time), or relatively via
   extend_days / extend_hours added on top of the current deadline.
───────────────────────────────────────── */
function updateHomework($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }

    $userId = resolveUserId();
    if (!$userId) { ob_end_clean(); errorResponse('Authentication required.', 401); }

    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $hwId  = isset($input['id']) ? (int)$input['id'] : 0;
    if (!$hwId) { ob_end_clean(); errorResponse('Homework id required'); }
    if (!teacherOwnsHomework($db, $hwId, $userId)) { ob_end_clean(); errorResponse('Not authorized for this homework', 403); }

    $current = $db->queryOne("SELECT * FROM homework WHERE id = ?", [$hwId]);
    if (!$current) { ob_end_clean(); errorResponse('Homework not found', 404); }

    $updates = [];
    $params  = [];
    $deadlineChanged = false;

    if (isset($input['subject']) && trim($input['subject']) !== '') {
        $updates[] = "subject = ?"; $params[] = trim(strip_tags($input['subject']));
    }
    if (isset($input['description']) && trim($input['description']) !== '') {
        $updates[] = "description = ?"; $params[] = trim(strip_tags($input['description']));
    }

    if (!empty($input['due_date'])) {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $input['due_date'])) {
            ob_end_clean(); errorResponse('Invalid due_date format (expected YYYY-MM-DD)');
        }
        $updates[] = "due_date = ?"; $params[] = $input['due_date'];
        if (!empty($input['due_time'])) {
            $updates[] = "due_time = ?"; $params[] = $input['due_time'];
        }
        $deadlineChanged = true;
    } elseif (!empty($input['extend_days']) || !empty($input['extend_hours'])) {
        $addDays  = isset($input['extend_days'])  ? (int)$input['extend_days']  : 0;
        $addHours = isset($input['extend_hours']) ? (int)$input['extend_hours'] : 0;
        if ($addDays < 0 || $addHours < 0) {
            ob_end_clean(); errorResponse('Extension must be positive — use due_date to move a deadline earlier instead.');
        }

        $baseTime     = !empty($current['due_time']) ? $current['due_time'] : '23:59:59';
        $baseDateTime = $current['due_date'] . ' ' . $baseTime;
        $newDateTime  = date('Y-m-d H:i:s', strtotime($baseDateTime . " +{$addDays} days +{$addHours} hours"));
        list($newDate, $newTime) = explode(' ', $newDateTime);

        $updates[] = "due_date = ?"; $params[] = $newDate;
        $updates[] = "due_time = ?"; $params[] = $newTime;
        $deadlineChanged = true;
    }

    if (empty($updates)) { ob_end_clean(); errorResponse('Nothing to update'); }

    $updates[] = "updated_at = NOW()";
    $params[]  = $hwId;

    $db->execute("UPDATE homework SET " . implode(', ', $updates) . " WHERE id = ?", $params);

    if ($deadlineChanged) {
        $fresh = $db->queryOne("SELECT * FROM homework WHERE id = ?", [$hwId]);
        notifyClassOfDeadlineChange($db, $fresh);
    }

    ob_end_clean();
    successResponse(['id' => $hwId], 'Homework updated successfully');
}

/* ─────────────────────────────────────────
   GRADE HOMEWORK
   A teacher can grade a student's homework regardless of whether that
   student's parent has acknowledged it. Score is out of 10 — this also
   feeds a shared gradebook_assessments/gradebook_grades row (type
   'weekly'), so homework becomes part of the same continuous-assessment
   average that weekly report cards already pull from.
───────────────────────────────────────── */
function gradeHomework($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }

    $userId = resolveUserId();
    if (!$userId) { ob_end_clean(); errorResponse('Authentication required.', 401); }

    $input     = json_decode(file_get_contents('php://input'), true) ?: [];
    $hwId      = isset($input['homework_id']) ? (int)$input['homework_id'] : 0;
    $studentId = isset($input['student_id'])  ? (int)$input['student_id']  : 0;
    $feedback  = isset($input['feedback'])    ? trim($input['feedback'])   : '';

    if (!$hwId || !$studentId) { ob_end_clean(); errorResponse('homework_id and student_id required'); }
    if (!isset($input['score']) || $input['score'] === '') { ob_end_clean(); errorResponse('Score is required'); }

    $score = (float)$input['score'];
    if ($score < 0 || $score > 10) { ob_end_clean(); errorResponse('Score must be between 0 and 10'); }

    if (!teacherOwnsHomework($db, $hwId, $userId)) { ob_end_clean(); errorResponse('Not authorized for this homework', 403); }

    $hw = $db->queryOne("SELECT * FROM homework WHERE id = ?", [$hwId]);
    if (!$hw) { ob_end_clean(); errorResponse('Homework not found', 404); }

    $belongs = $db->queryOne(
        "SELECT id FROM students WHERE id = ? AND class_id = ?",
        [$studentId, $hw['class_id']]
    );
    if (!$belongs) { ob_end_clean(); errorResponse('That student is not in this homework\'s class', 404); }

    // Display-friendly "8/10" string, kept alongside the numeric score so
    // anything already reading the old free-text grade column still works.
    $gradeLabel = rtrim(rtrim(number_format($score, 1), '0'), '.') . '/10';

    $existing = $db->queryOne(
        "SELECT id FROM homework_grades WHERE homework_id = ? AND student_id = ?",
        [$hwId, $studentId]
    );
    if ($existing) {
        $db->execute(
            "UPDATE homework_grades SET grade = ?, score = ?, feedback = ?, graded_by = ?, updated_at = NOW() WHERE id = ?",
            [$gradeLabel, $score, $feedback !== '' ? $feedback : null, $userId, $existing['id']]
        );
    } else {
        $db->execute(
            "INSERT INTO homework_grades (homework_id, student_id, grade, score, feedback, graded_by, graded_at)
             VALUES (?, ?, ?, ?, ?, ?, NOW())",
            [$hwId, $studentId, $gradeLabel, $score, $feedback !== '' ? $feedback : null, $userId]
        );
    }

    $gradebookSynced = syncHomeworkGradeToGradebook($db, $hw, $studentId, $score, $feedback, $userId);

    ob_end_clean();
    successResponse([
        'homework_id'      => $hwId,
        'student_id'       => $studentId,
        'gradebook_synced' => $gradebookSynced,
    ], 'Grade saved');
}

/**
 * Feeds a homework grade into the standard gradebook tables so it
 * contributes to the student's weekly continuous-assessment average —
 * the same tables and averaging logic teacher-reports.php already uses,
 * so no changes were needed there at all. Best-effort: a sync failure
 * (e.g. the homework's subject name doesn't match an official subject)
 * never blocks the homework grade itself from saving.
 */
function syncHomeworkGradeToGradebook($db, $hw, $studentId, $score, $feedback, $userId) {
    try {
        $subjectRow = $db->queryOne("SELECT id FROM subjects WHERE subject_name = ?", [$hw['subject']]);
        if (!$subjectRow) {
            error_log("syncHomeworkGradeToGradebook: no subject named '{$hw['subject']}' — skipping gradebook sync for homework #{$hw['id']}");
            return false;
        }
        $subjectId = (int)$subjectRow['id'];

        // Reuse the same assessment row for every student graded on this
        // homework — only create it the first time anyone is graded.
        $assessment = $db->queryOne("SELECT id FROM gradebook_assessments WHERE homework_id = ?", [$hw['id']]);
        if ($assessment) {
            $assessmentId = (int)$assessment['id'];
        } else {
            $term  = 'Term ' . getCurrentTerm($db);
            $yr    = getCurrentAcademicYear();
            $label = 'Week ' . getWeekOfMonth($hw['due_date']) . ' - ' . date('F Y', strtotime($hw['due_date']));

            $assessmentId = $db->execute(
                "INSERT INTO gradebook_assessments
                    (homework_id, class_id, subject_id, teacher_id, title, assessment_type,
                     period_label, term, academic_year, max_score, weight, assessment_date, is_published, created_at)
                 VALUES (?, ?, ?, ?, ?, 'weekly', ?, ?, ?, 10, 100, ?, 1, NOW())",
                [$hw['id'], $hw['class_id'], $subjectId, $userId,
                 'Homework: ' . $hw['subject'], $label, $term, $yr, $hw['due_date']]
            );
            if ($assessmentId === false) {
                error_log("syncHomeworkGradeToGradebook: failed to create gradebook_assessments row for homework #{$hw['id']}");
                return false;
            }
        }

        $db->execute(
            "INSERT INTO gradebook_grades (assessment_id, student_id, score, remarks, graded_by)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE score = VALUES(score), remarks = VALUES(remarks),
                 graded_by = VALUES(graded_by), graded_at = CURRENT_TIMESTAMP",
            [$assessmentId, $studentId, $score, $feedback !== '' ? $feedback : null, $userId]
        );
        return true;
    } catch (Exception $e) {
        error_log('syncHomeworkGradeToGradebook error: ' . $e->getMessage());
        return false;
    }
}

/**
 * Email every parent in the class when a homework deadline is moved,
 * so nobody is caught out by a due date that quietly changed.
 */
function notifyClassOfDeadlineChange($db, $hw) {
    try {
        $classRow  = $db->queryOne("SELECT class_name FROM classes WHERE id = ?", [$hw['class_id']]);
        $className = $classRow ? $classRow['class_name'] : 'the class';

        $guardians = $db->query(
            "SELECT DISTINCT u.email, u.full_name, s.student_name
               FROM students s
               JOIN parents p ON p.student_id = s.id
               JOIN users u   ON u.id = p.user_id
              WHERE s.class_id = ? AND s.status = 'active'
                AND u.email IS NOT NULL AND u.email != ''",
            [$hw['class_id']]
        ) ?: [];

        $niceDate = date('l, j F Y', strtotime($hw['due_date']));
        $niceTime = !empty($hw['due_time']) ? date('g:i A', strtotime($hw['due_time'])) : null;

        foreach ($guardians as $g) {
            $subject = 'Homework Deadline Updated — ' . $className . ' (' . $hw['subject'] . ')';
            $body =
                '<p>Dear ' . htmlspecialchars($g['full_name']) . ',</p>' .
                '<p>The deadline for <strong>' . htmlspecialchars($hw['subject']) . '</strong> homework ' .
                '(' . htmlspecialchars($className) . ') for <strong>' . htmlspecialchars($g['student_name']) . '</strong> has been updated.</p>' .
                '<p><strong>New due date:</strong> ' . $niceDate . ($niceTime ? ' at ' . $niceTime : '') . '</p>' .
                '<p style="color:#888;font-size:12px;">This is an automated notice from the school homework system.</p>';
            sendEmail($g['email'], $subject, $body);
        }
    } catch (Exception $e) {
        error_log('notifyClassOfDeadlineChange error: ' . $e->getMessage());
    }
}

function listHomeworkCommentsTeacher($db) {
    requireRole(['teacher', 'admin']);
    $hwId = isset($_GET['homework_id']) ? (int)$_GET['homework_id'] : 0;
    if (!$hwId) { ob_end_clean(); errorResponse('homework_id required'); }
    $userId = function_exists('resolveUserId') ? resolveUserId() : (isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0);
    if (function_exists('teacherOwnsHomework') && !teacherOwnsHomework($db, $hwId, $userId)
        && (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin')) {
        ob_end_clean(); errorResponse('Not authorized', 403);
    }
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS homework_comments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                homework_id INT NOT NULL,
                student_id INT NOT NULL,
                parent_id INT NOT NULL,
                comment TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_hc_hw (homework_id)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) {}
    $rows = $db->query(
        "SELECT c.id, c.comment, c.created_at, c.student_id,
                u.full_name AS parent_name, s.student_name
           FROM homework_comments c
           JOIN users u ON u.id = c.parent_id
           JOIN students s ON s.id = c.student_id
          WHERE c.homework_id = ?
          ORDER BY c.created_at DESC",
        array($hwId)
    );
    if ($rows === false || $rows === null) $rows = array();
    ob_end_clean();
    successResponse($rows);
}
