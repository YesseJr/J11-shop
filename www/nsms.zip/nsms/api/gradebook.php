<?php
/**
 * NSMS — Gradebook & Assessment API  (v2)
 * /nsms/api/gradebook.php
 *
 * Assessment types: daily | weekly | midterm | terminal
 * PHP 7.2 compatible.
 */

ob_start();
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

applyApiHeaders();

requireRole(['admin', 'teacher']);

$db   = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

$method   = $_SERVER['REQUEST_METHOD'];
$postData = [];
if ($method === 'POST') {
    $raw      = file_get_contents('php://input');
    $postData = json_decode($raw, true) ?: [];
    $action   = isset($postData['action']) ? trim($postData['action']) : '';
} else {
    $action = isset($_GET['action']) ? trim($_GET['action']) : '';
}

try {
    switch ($action) {
        case 'subjects':           getSubjects($db);                  break;
        case 'terms':              getTerms($db);                     break;
        case 'assessments':        getAssessments($db);               break;
        case 'assessment_grades':  getAssessmentGrades($db);          break;
        case 'class_overview':     getClassOverview($db);             break;
        case 'student_progress':   getStudentProgress($db);           break;
        case 'create_assessment':  createAssessment($db, $postData);  break;
        case 'delete_assessment':  deleteAssessment($db, $postData);  break;
        case 'save_grades':        saveGrades($db, $postData);        break;
        case 'publish_assessment': publishAssessment($db, $postData); break;
        default: ob_end_clean(); errorResponse('Invalid action');
    }
} catch (Exception $e) {
    ob_end_clean();
    error_log('NSMS gradebook.php: ' . $e->getMessage());
    errorResponse('Server error: ' . $e->getMessage(), 500);
} catch (Throwable $e) {
    ob_end_clean();
    error_log('NSMS gradebook.php fatal: ' . $e->getMessage());
    errorResponse('Server error: ' . $e->getMessage(), 500);
}

/* ═══════════════════════════════ SECURITY ═══════════════════════════════ */
function sessionInfo() {
    return [
        isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0,
        isset($_SESSION['role'])    ? $_SESSION['role']          : ''
    ];
}
function resolveTeacherClassId($db, $tid) {
    $r = $db->queryOne("SELECT id FROM classes WHERE teacher_id=:tid LIMIT 1",[':tid'=>$tid]);
    return $r ? (int)$r['id'] : null;
}
function resolveTeacherSubjectIds($db, $tid) {
    $rows = $db->query("SELECT subject_id FROM teacher_subjects WHERE teacher_id=:tid",[':tid'=>$tid]);
    return $rows ? array_map('intval', array_column($rows,'subject_id')) : [];
}
function assertTeacherOwnership($db, $classId, $subjectId = null) {
    list($userId, $role) = sessionInfo();
    if ($role === 'admin') return;
    if (resolveTeacherClassId($db, $userId) !== $classId) {
        ob_end_clean(); errorResponse('Access denied: class not assigned to you.', 403);
    }
    if ($subjectId !== null) {
        if (!in_array((int)$subjectId, resolveTeacherSubjectIds($db, $userId))) {
            ob_end_clean(); errorResponse('Access denied: subject not assigned to you.', 403);
        }
    }
}
function assertAssessmentOwner($db, $id) {
    list($userId, $role) = sessionInfo();
    if ($role === 'admin') return;
    $r = $db->queryOne("SELECT teacher_id FROM gradebook_assessments WHERE id=:id",[':id'=>$id]);
    if (!$r) { ob_end_clean(); errorResponse('Assessment not found.',404); }
    if ((int)$r['teacher_id'] !== $userId) { ob_end_clean(); errorResponse('Access denied.',403); }
}

/* ════════════════════════════ GRADE UTILITIES ════════════════════════════ */
function pctToGrade($pct) {
    if ($pct === null) return null;
    $p = (float)$pct;
    if ($p >= 90) return 'A';
    if ($p >= 75) return 'B';
    if ($p >= 60) return 'C';
    if ($p >= 50) return 'D';
    if ($p >= 40) return 'E';
    return 'F';
}
function gradeToPerf($g) {
    $m = ['A'=>'Excellent','B'=>'Very Good','C'=>'Good','D'=>'Average','E'=>'Below Average','F'=>'Poor'];
    return isset($m[$g]) ? $m[$g] : null;
}
function gradeToRating($g) {
    $m = ['A'=>'Excellent','B'=>'Very Good','C'=>'Good','D'=>'Fair','E'=>'Needs Improvement','F'=>'Needs Improvement'];
    return isset($m[$g]) ? $m[$g] : '';
}

function recalcPerformance($db, $studentId, $subjectId, $classId, $term, $yr, $updatedBy) {
    $row = $db->queryOne(
        "SELECT ROUND(AVG(gg.score / ga.max_score * 100), 2) AS avg_pct, COUNT(gg.id) AS n
         FROM gradebook_grades gg
         JOIN gradebook_assessments ga ON ga.id=gg.assessment_id
         WHERE gg.student_id=:sid AND ga.subject_id=:sub AND ga.class_id=:cid
           AND ga.term=:term AND ga.academic_year=:yr
           AND gg.score IS NOT NULL AND ga.is_published=1",
        [':sid'=>$studentId,':sub'=>$subjectId,':cid'=>$classId,':term'=>$term,':yr'=>$yr]
    );
    if (!$row||!$row['n']) return;
    $avg=$row['avg_pct']; $letter=pctToGrade($avg); $perf=gradeToPerf($letter);
    $ex = $db->queryOne(
        "SELECT id FROM student_subject_performance
         WHERE student_id=:sid AND subject_id=:sub AND term=:term AND academic_year=:yr",
        [':sid'=>$studentId,':sub'=>$subjectId,':term'=>$term,':yr'=>$yr]
    );
    if ($ex) {
        $result = $db->execute(
            "UPDATE student_subject_performance
             SET average_score=:avg,grade_letter=:gl,performance_level=:pl,class_id=:cid,updated_by=:ub
             WHERE id=:id",
            [':avg'=>$avg,':gl'=>$letter,':pl'=>$perf,':cid'=>$classId,':ub'=>$updatedBy,':id'=>$ex['id']]
        );
        if ($result === false) error_log("NSMS recalcPerformance: UPDATE failed for student $studentId / subject $subjectId");
    } else {
        $result = $db->execute(
            "INSERT INTO student_subject_performance
               (student_id,subject_id,class_id,term,academic_year,average_score,grade_letter,performance_level,updated_by)
             VALUES (:sid,:sub,:cid,:term,:yr,:avg,:gl,:pl,:ub)",
            [':sid'=>$studentId,':sub'=>$subjectId,':cid'=>$classId,':term'=>$term,':yr'=>$yr,
             ':avg'=>$avg,':gl'=>$letter,':pl'=>$perf,':ub'=>$updatedBy]
        );
        if ($result === false) error_log("NSMS recalcPerformance: INSERT failed for student $studentId / subject $subjectId");
    }
}

/* ═══════════════════════════ GET HANDLERS ═══════════════════════════ */
function getSubjects($db) {
    list($userId,$role) = sessionInfo();
    if ($role==='admin') {
        $rows = $db->query("SELECT id,subject_name,subject_code FROM subjects ORDER BY subject_name") ?: [];
        ob_end_clean(); successResponse(['subjects'=>$rows,'class_id'=>null]); return;
    }
    $classId = resolveTeacherClassId($db,$userId);
    $rows = $db->query(
        "SELECT s.id,s.subject_name,s.subject_code
         FROM teacher_subjects ts JOIN subjects s ON s.id=ts.subject_id
         WHERE ts.teacher_id=:tid ORDER BY s.subject_name",
        [':tid'=>$userId]
    ) ?: [];
    ob_end_clean(); successResponse(['subjects'=>$rows,'class_id'=>$classId]);
}

function getTerms($db) {
    $names=[];
    for ($i=1;$i<=2;$i++) {
        $r=$db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key=:k",[':k'=>"acad_term{$i}_start"]);
        if ($r) $names[]="Term $i";
    }
    // Fall back to Tanzania's actual 2-term calendar (matches helpers.php getCurrentTerm()) if nothing configured yet
    if (empty($names)) $names=['Term 1','Term 2'];
    $yr=$db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key='academic_year'");
    // Bug fix: was date('Y').'/'.(date('Y')+1) written without parens, causing PHP to
    // evaluate as (date('Y').'/'.date('Y'))+1 = integer 0. Now explicit.
    $academicYear = ($yr && !empty($yr['setting_value'])) ? $yr['setting_value'] : (date('Y').'/'.(date('Y')+1));
    ob_end_clean(); successResponse(['terms'=>$names,'academic_year'=>$academicYear]);
}

function getAssessments($db) {
    list($userId,$role)=sessionInfo();
    $classId=$role==='admin'?(isset($_GET['class_id'])?(int)$_GET['class_id']:null):resolveTeacherClassId($db,$userId);
    if (!$classId){ ob_end_clean(); errorResponse('No class assigned.'); }
    $where=['ga.class_id=:cid']; $params=[':cid'=>$classId];
    if ($role!=='admin'){ $where[]='ga.teacher_id=:tid'; $params[':tid']=$userId; }
    if (!empty($_GET['type']))          { $where[]='ga.assessment_type=:type'; $params[':type']=trim($_GET['type']); }
    if (!empty($_GET['term']))          { $where[]='ga.term=:term';            $params[':term']=trim($_GET['term']); }
    if (!empty($_GET['period_label']))  { $where[]='ga.period_label=:pl';      $params[':pl']=trim($_GET['period_label']); }
    if (!empty($_GET['subject_id']))    { $where[]='ga.subject_id=:sub';       $params[':sub']=(int)$_GET['subject_id']; }
    if (!empty($_GET['academic_year'])) { $where[]='ga.academic_year=:yr';     $params[':yr']=trim($_GET['academic_year']); }
    $rows=$db->query(
        "SELECT ga.id,ga.title,ga.assessment_type,ga.period_label,ga.term,ga.academic_year,
                ga.max_score,ga.is_published,ga.assessment_date,ga.created_at,
                s.id AS subject_id,s.subject_name,s.subject_code,
                (SELECT COUNT(*) FROM gradebook_grades gg WHERE gg.assessment_id=ga.id AND gg.score IS NOT NULL) AS graded_count,
                (SELECT COUNT(*) FROM students st WHERE st.class_id=ga.class_id AND st.status='active') AS total_students
         FROM gradebook_assessments ga JOIN subjects s ON s.id=ga.subject_id
         WHERE ".implode(' AND ',$where)."
         ORDER BY ga.assessment_date DESC,ga.created_at DESC",
        $params
    ) ?: [];
    ob_end_clean(); successResponse(['assessments'=>$rows,'class_id'=>$classId]);
}

function getAssessmentGrades($db) {
    $id=isset($_GET['assessment_id'])?(int)$_GET['assessment_id']:0;
    if (!$id){ ob_end_clean(); errorResponse('assessment_id required'); }
    $a=$db->queryOne(
        "SELECT ga.*,s.subject_name,s.subject_code
         FROM gradebook_assessments ga JOIN subjects s ON s.id=ga.subject_id WHERE ga.id=:id",
        [':id'=>$id]
    );
    if (!$a){ ob_end_clean(); errorResponse('Assessment not found.',404); }
    assertTeacherOwnership($db,(int)$a['class_id'],(int)$a['subject_id']);
    $grades=$db->query(
        "SELECT st.id AS student_id,st.student_name,st.photo_url,st.gender,
                gg.id AS grade_id,gg.score,gg.remarks,gg.graded_at
         FROM students st
         LEFT JOIN gradebook_grades gg ON gg.student_id=st.id AND gg.assessment_id=:aid
         WHERE st.class_id=:cid AND st.status='active' ORDER BY st.student_name",
        [':aid'=>$id,':cid'=>(int)$a['class_id']]
    ) ?: [];
    ob_end_clean(); successResponse(['assessment'=>$a,'grades'=>$grades]);
}

function getClassOverview($db) {
    list($userId,$role)=sessionInfo();
    $classId=$role==='admin'?(isset($_GET['class_id'])?(int)$_GET['class_id']:null):resolveTeacherClassId($db,$userId);
    $term=isset($_GET['term'])?trim($_GET['term']):'';
    $yr=isset($_GET['academic_year'])?trim($_GET['academic_year']):'';
    if (!$classId||!$term||!$yr){ ob_end_clean(); errorResponse('class_id, term, academic_year required.'); }
    $students=$db->query(
        "SELECT id,student_name,photo_url FROM students WHERE class_id=:cid AND status='active' ORDER BY student_name",
        [':cid'=>$classId]
    ) ?: [];
    $perfs=$db->query(
        "SELECT ssp.student_id,ssp.subject_id,ssp.average_score,ssp.grade_letter,ssp.performance_level,
                s.subject_name,s.subject_code
         FROM student_subject_performance ssp JOIN subjects s ON s.id=ssp.subject_id
         WHERE ssp.class_id=:cid AND ssp.term=:term AND ssp.academic_year=:yr",
        [':cid'=>$classId,':term'=>$term,':yr'=>$yr]
    ) ?: [];
    ob_end_clean(); successResponse(['students'=>$students,'performances'=>$perfs]);
}

function getStudentProgress($db) {
    $sid=isset($_GET['student_id'])?(int)$_GET['student_id']:0;
    $term=isset($_GET['term'])?trim($_GET['term']):'';
    $yr=isset($_GET['academic_year'])?trim($_GET['academic_year']):'';
    if (!$sid||!$term||!$yr){ ob_end_clean(); errorResponse('student_id, term, academic_year required.'); }
    $st=$db->queryOne("SELECT class_id FROM students WHERE id=:id",[':id'=>$sid]);
    if (!$st){ ob_end_clean(); errorResponse('Student not found.',404); }
    assertTeacherOwnership($db,(int)$st['class_id']);
    $perfs=$db->query(
        "SELECT ssp.subject_id,ssp.average_score,ssp.grade_letter,ssp.performance_level,
                s.subject_name,s.subject_code
         FROM student_subject_performance ssp JOIN subjects s ON s.id=ssp.subject_id
         WHERE ssp.student_id=:sid AND ssp.term=:term AND ssp.academic_year=:yr
         ORDER BY s.subject_name",
        [':sid'=>$sid,':term'=>$term,':yr'=>$yr]
    ) ?: [];
    $assessments=$db->query(
        "SELECT ga.id AS assessment_id,ga.title,ga.assessment_type,ga.period_label,
                ga.subject_id,ga.max_score,ga.assessment_date,gg.score,gg.remarks
         FROM gradebook_assessments ga
         LEFT JOIN gradebook_grades gg ON gg.assessment_id=ga.id AND gg.student_id=:sid
         WHERE ga.class_id=:cid AND ga.term=:term AND ga.academic_year=:yr AND ga.is_published=1
         ORDER BY ga.subject_id,ga.assessment_type,ga.assessment_date",
        [':sid'=>$sid,':cid'=>(int)$st['class_id'],':term'=>$term,':yr'=>$yr]
    ) ?: [];
    ob_end_clean(); successResponse(['subject_performances'=>$perfs,'assessments'=>$assessments]);
}

/* ══════════════════════════ POST HANDLERS ══════════════════════════ */
function createAssessment($db, $data) {
    list($userId,$role)=sessionInfo();
    $classId=$role==='admin'?(isset($data['class_id'])?(int)$data['class_id']:0):resolveTeacherClassId($db,$userId);
    $subjectId   =isset($data['subject_id'])    ?(int)$data['subject_id']       :0;
    $title       =isset($data['title'])         ?trim($data['title'])           :'';
    $type        =isset($data['assessment_type'])?trim($data['assessment_type']):'';
    $periodLabel =isset($data['period_label'])  ?trim($data['period_label'])    :'';
    $term        =isset($data['term'])          ?trim($data['term'])            :'';
    $yr          =isset($data['academic_year']) ?trim($data['academic_year'])   :'';
    $maxScore    =isset($data['max_score'])     ?(float)$data['max_score']      :100;
    $asmDate     =isset($data['assessment_date'])?trim($data['assessment_date']):'';

    $validTypes=['daily','weekly','midterm','terminal'];
    if (!$classId)                   { ob_end_clean(); errorResponse('No class found.'); }
    if (!$subjectId)                 { ob_end_clean(); errorResponse('subject_id required.'); }
    if (!$title)                     { ob_end_clean(); errorResponse('Title required.'); }
    if (!in_array($type,$validTypes)){ ob_end_clean(); errorResponse('Invalid type.'); }
    if (!$periodLabel)               { ob_end_clean(); errorResponse('period_label required.'); }
    if (!$term)                      { ob_end_clean(); errorResponse('term required.'); }
    if (!$yr)                        { ob_end_clean(); errorResponse('academic_year required.'); }
    if ($maxScore<=0)                { ob_end_clean(); errorResponse('max_score must be > 0.'); }

    assertTeacherOwnership($db,$classId,$subjectId);

    $newId=$db->execute(
        "INSERT INTO gradebook_assessments
           (class_id,subject_id,teacher_id,title,assessment_type,period_label,term,academic_year,max_score,assessment_date)
         VALUES (:cid,:sub,:tid,:title,:type,:pl,:term,:yr,:max,:date)",
        [':cid'=>$classId,':sub'=>$subjectId,':tid'=>$userId,':title'=>$title,
         ':type'=>$type,':pl'=>$periodLabel,':term'=>$term,':yr'=>$yr,
         ':max'=>$maxScore,':date'=>$asmDate?:null]
    );

    if ($newId === false || !$newId) {
        ob_end_clean(); errorResponse('Failed to create assessment (DB error). Check error log.', 500);
    }

    $students=$db->query("SELECT id FROM students WHERE class_id=:cid AND status='active'",[':cid'=>$classId]) ?: [];
    $slotErrors=0;
    foreach ($students as $s) {
        $r=$db->execute(
            "INSERT IGNORE INTO gradebook_grades (assessment_id,student_id,score,graded_by) VALUES (:aid,:sid,NULL,:gid)",
            [':aid'=>$newId,':sid'=>$s['id'],':gid'=>$userId]
        );
        if ($r === false) { $slotErrors++; error_log("NSMS slot fill failed: assessment $newId student {$s['id']}"); }
    }

    ob_end_clean(); successResponse(['assessment_id'=>$newId,'message'=>'Assessment created.'.($slotErrors?" ($slotErrors slot(s) failed — check logs)":'')]);
}

function deleteAssessment($db,$data) {
    $id=isset($data['id'])?(int)$data['id']:0;
    if (!$id){ ob_end_clean(); errorResponse('id required.'); }
    assertAssessmentOwner($db,$id);
    $r=$db->queryOne("SELECT is_published FROM gradebook_assessments WHERE id=:id",[':id'=>$id]);
    if ($r&&$r['is_published']){ ob_end_clean(); errorResponse('Published assessments cannot be deleted.'); }
    $db->execute("DELETE FROM gradebook_grades WHERE assessment_id=:id",[':id'=>$id]);
    $db->execute("DELETE FROM gradebook_assessments WHERE id=:id",[':id'=>$id]);
    ob_end_clean(); successResponse(['message'=>'Assessment deleted.']);
}

function saveGrades($db,$data) {
    list($userId)=sessionInfo();
    $aid=isset($data['assessment_id'])?(int)$data['assessment_id']:0;
    $grades=isset($data['grades'])?$data['grades']:[];
    if (!$aid){ ob_end_clean(); errorResponse('assessment_id required.'); }
    if (!is_array($grades)||empty($grades)){ ob_end_clean(); errorResponse('grades array required.'); }
    assertAssessmentOwner($db,$aid);
    $a=$db->queryOne("SELECT * FROM gradebook_assessments WHERE id=:id",[':id'=>$aid]);
    if (!$a){ ob_end_clean(); errorResponse('Assessment not found.',404); }
    if ($a['is_published']){ ob_end_clean(); errorResponse('Scores are locked.'); }
    $max=(float)$a['max_score'];
    foreach ($grades as $g) {
        $sid=isset($g['student_id'])?(int)$g['student_id']:0;
        $score=isset($g['score'])?$g['score']:null;
        $rem=isset($g['remarks'])?trim($g['remarks']):null;
        if (!$sid) continue;
        if ($score!==null&&$score!=='') {
            $score=(float)$score;
            if ($score<0||$score>$max){ ob_end_clean(); errorResponse("Score $score out of range for student $sid."); }
        } else { $score=null; }
        $db->execute(
            "INSERT INTO gradebook_grades (assessment_id,student_id,score,remarks,graded_by)
             VALUES (:aid,:sid,:score,:rem,:gid)
             ON DUPLICATE KEY UPDATE score=VALUES(score),remarks=VALUES(remarks),
               graded_by=VALUES(graded_by),graded_at=CURRENT_TIMESTAMP",
            [':aid'=>$aid,':sid'=>$sid,':score'=>$score,':rem'=>$rem,':gid'=>$userId]
        );
    }
    ob_end_clean(); successResponse(['message'=>'Grades saved.']);
}

function publishAssessment($db,$data) {
    list($userId)=sessionInfo();
    $aid=isset($data['assessment_id'])?(int)$data['assessment_id']:0;
    if (!$aid){ ob_end_clean(); errorResponse('assessment_id required.'); }
    assertAssessmentOwner($db,$aid);
    $a=$db->queryOne("SELECT * FROM gradebook_assessments WHERE id=:id",[':id'=>$aid]);
    if (!$a){ ob_end_clean(); errorResponse('Assessment not found.',404); }
    $cnt=$db->queryOne("SELECT COUNT(*) AS n FROM gradebook_grades WHERE assessment_id=:id AND score IS NOT NULL",[':id'=>$aid]);
    if (!$cnt||$cnt['n']==0){ ob_end_clean(); errorResponse('Cannot publish: no grades entered yet.'); }
    $db->execute("UPDATE gradebook_assessments SET is_published=1 WHERE id=:id",[':id'=>$aid]);
    $graded=$db->query("SELECT DISTINCT student_id FROM gradebook_grades WHERE assessment_id=:id AND score IS NOT NULL",[':id'=>$aid]) ?: [];
    foreach ($graded as $gs) {
        recalcPerformance($db,(int)$gs['student_id'],(int)$a['subject_id'],(int)$a['class_id'],$a['term'],$a['academic_year'],$userId);
    }
    ob_end_clean(); successResponse(['message'=>'Assessment published. Performances updated.']);
}