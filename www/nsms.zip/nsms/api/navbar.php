<?php
/**
 * Navbar API
 * GET /nsms/api/navbar.php
 * Returns school settings + current authenticated user info.
 * Used by the top navigation bar on all admin pages.
 */

ob_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean(); exit(0);
}

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

if (function_exists('applyApiHeaders')) { applyApiHeaders(); }


requireRole(['admin', 'teacher']);

$db   = new Database();
$conn = $db->connect();

if (!$conn) {
    ob_end_clean();
    echo json_encode(['success' => false, 'error' => 'DB connection failed']);
    exit;
}

// ── School settings ──────────────────────────────────────────────
$settingKeys = ['school_name', 'school_address', 'school_phone', 'school_email', 'logo_url'];
$settings    = [];

$rows = $db->query(
    "SELECT setting_key, setting_value FROM school_settings
      WHERE setting_key IN ('" . implode("','", $settingKeys) . "')"
);
foreach ($rows ?: [] as $r) {
    $settings[$r['setting_key']] = $r['setting_value'];
}

// ── Current user ─────────────────────────────────────────────────
$userId  = getCurrentUserId();
$user    = null;
if ($userId) {
    $user = $db->queryOne(
        "SELECT id, full_name, email, role, photo_url
           FROM users WHERE id = :id LIMIT 1",
        [':id' => $userId]
    );
}

ob_end_clean();
echo json_encode([
    'success' => true,
    'data'    => [
        'school_name'    => $settings['school_name']    ?? 'Nursery School',
        'school_address' => $settings['school_address'] ?? '',
        'school_phone'   => $settings['school_phone']   ?? '',
        'school_email'   => $settings['school_email']   ?? '',
        'logo_url'       => $settings['logo_url']       ?? null,
        'user'           => $user ? [
            'id'        => (int)$user['id'],
            'full_name' => $user['full_name'],
            'email'     => $user['email'],
            'role'      => $user['role'],
            'photo_url' => $user['photo_url'] ?? null,
        ] : null,
    ],
]);
