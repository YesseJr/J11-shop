<?php
/**
====================================
 * Author: Waython Yesse / J11 Technologies
 * Year: 2026
====================================
 * Payment Gateway API  v4
 *
 * Transaction/Items model:
 *   payment_transactions = one row per parent submission (header)
 *   payment_items         = one row per fee/instalment within it
 *
 * A single submission can cover multiple fee_types and instalments.
 * The server (never the client) determines network provider / card
 * type and generates the transaction reference + receipt number.
 *
 * Parent GET  : fee_summary, my_transactions, transaction_detail
 * Parent POST : submit_transaction, upload_proof
 * Admin  GET  : all_transactions, verification_stats, transaction_detail
 * Admin  POST : approve_transaction, reject_transaction
 */

ob_start();
header('Content-Type: application/json');
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once __DIR__ . '/../includes/sync/SyncHooks.php';

if (function_exists('applyApiHeaders')) { applyApiHeaders(); }


requireAuth();

$db     = new Database();
$conn   = $db->connect();
if (!$conn) { ob_end_clean(); echo json_encode(['success'=>false,'error'=>'DB connection failed']); exit; }

$role   = getCurrentUserRole();
$userId = getCurrentUserId();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

$uploadDir = dirname(__DIR__) . '/publicuploads/payment_proofs/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

define('GW_INSTALLABLE_FEES', ['School Fees', 'Transport']);
define('GW_MAX_INSTALLMENTS', 10);

/* Mobile money providers (display name => prefixes) */
define('MM_PROVIDERS', [
    'Vodacom'    => ['074','075','076'],
    'Airtel'     => ['068','069','078','073'],
    'Tigo/Yas'   => ['071','065','067'],
    'Halotel'    => ['062','061'],
    'Zantel'     => ['077'],
]);
/* Maps a selected gateway method to which provider list / channel it belongs to */
define('METHOD_CHANNEL', [
    'M-Pesa'          => 'mobile_money',
    'Tigo Pesa'       => 'mobile_money',
    'Airtel Money'    => 'mobile_money',
    'HaloPesa'        => 'mobile_money',
    'Mixx by Yas'     => 'mobile_money',
    'Visa'            => 'card',
    'Mastercard'      => 'card',
    'Control Number'  => 'control_number',
]);

try {
    if ($method === 'GET') {
        switch ($action) {
            case 'fee_summary':          requireRole('parent'); handleFeeSummary($db, $userId);        break;
            case 'my_transactions':      requireRole('parent'); handleMyTransactions($db, $userId);     break;
            case 'transaction_detail':   handleGetDetail($db, $role, $userId);                          break;
            case 'all_transactions':     requireRole('admin');  handleAllTransactions($db);              break;
            case 'verification_stats':   requireRole('admin');  handleVerificationStats($db);            break;
            default: apiError('Invalid action');
        }
    } elseif ($method === 'POST') {
        $ct   = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
        $body = strpos($ct, 'application/json') !== false
            ? (json_decode(file_get_contents('php://input'), true) ?: [])
            : $_POST;
        switch ($action) {
            case 'submit_transaction':   requireRole('parent'); handleSubmitTransaction($db, $userId, $body); break;
            case 'upload_proof':         requireRole('parent'); handleUploadProof($db, $userId, $uploadDir);   break;
            case 'approve_transaction':  requireRole('admin');  handleApproveTransaction($db, $userId, $body); break;
            case 'reject_transaction':   requireRole('admin');  handleRejectTransaction($db, $userId, $body);  break;
            default: apiError('Invalid action');
        }
    } else {
        apiError('Method not allowed', 405);
    }
} catch (Throwable $e) {
    ob_end_clean(); http_response_code(500); header('Content-Type: application/json');
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]); exit;
}
ob_end_flush();

/* ═══════════════════════════════════════════════════════
   HELPERS
═══════════════════════════════════════════════════════ */

function apiOk($data=null, $msg='OK') {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['success'=>true,'message'=>$msg,'data'=>$data]); exit;
}
function apiError($msg, $code=400) {
    ob_end_clean(); http_response_code($code); header('Content-Type: application/json');
    echo json_encode(['success'=>false,'error'=>$msg]); exit;
}
function rf($body, $field) {
    if (!isset($body[$field]) || (is_string($body[$field]) && trim($body[$field])==='')) apiError("Missing required field: $field");
    return $body[$field];
}
function parentOwnsStudent($db, $parentUserId, $studentId) {
    return !!$db->queryOne("SELECT id FROM parents WHERE user_id=? AND student_id=?", [$parentUserId, $studentId]);
}
/**
 * Insert a notification for a user.
 * Uses pulse_alerts/pulse_alert_recipients (the system the admin/teacher bell reads)
 * for admin and teacher recipients, and the notifications table for parents.
 * Falls back to notifications table for any role on DB error.
 *
 * NOTE: notifications.type ENUM must include 'payment' — ensured by fix_migration.sql.
 */
function insertNotification($db, $userId, $title, $message, $type='payment') {
    // Determine the user's role so we can route to the correct table.
    $userRow = $db->queryOne("SELECT role FROM users WHERE id=?", [$userId]);
    $role    = $userRow ? $userRow['role'] : 'parent';

    if (in_array($role, ['admin', 'teacher'])) {
        // Admin/Teacher bell reads pulse_alerts + pulse_alert_recipients.
        try {
            $systemUserId = 0; // 0 = system/automated sender
            // Find the first admin to act as system sender (required FK).
            $senderRow = $db->queryOne("SELECT id FROM users WHERE role='admin' LIMIT 1");
            $senderId  = $senderRow ? (int)$senderRow['id'] : $userId;

            $alertId = $db->execute(
                "INSERT INTO pulse_alerts
                    (sender_id, title, body, priority, target_type, target_role, target_user_id, created_at)
                 VALUES (?, ?, ?, 'high', 'user', ?, ?, NOW())",
                [$senderId, $title, $message, $role, $userId]
            );
            if ($alertId) {
                $db->execute(
                    "INSERT IGNORE INTO pulse_alert_recipients (alert_id, user_id, is_read)
                     VALUES (?, ?, 0)",
                    [$alertId, $userId]
                );
            }
        } catch (Exception $e) {
            error_log('Pulse alert insert error: ' . $e->getMessage());
        }
    }

    // Always also write to notifications table for any legacy display code.
    // The ENUM fix in fix_migration.sql ensures 'payment' is valid.
    try {
        $db->execute(
            "INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
             VALUES (?, ?, ?, 'payment', 0, NOW())",
            [$userId, $title, $message]
        );
    } catch (Exception $e) {
        error_log('Notifications insert error: ' . $e->getMessage());
    }
}

function getAdminUserIds($db) {
    $rows = $db->query("SELECT id FROM users WHERE role='admin' AND status='active'");
    return $rows ? array_column($rows,'id') : [];
}

/**
 * Email the parent a payment confirmation once their transaction is
 * approved. Runs after commit — a failed email never rolls back or blocks
 * an already-successful payment approval.
 */
function notifyParentOfPaymentConfirmation($db, $parentUserId, $studentName, $amount, $receipt) {
    try {
        $user = $db->queryOne("SELECT email, full_name FROM users WHERE id = ?", [$parentUserId]);
        if (!$user || empty($user['email'])) return;

        $subject = 'Payment Confirmed — Receipt ' . $receipt;
        $body =
            '<p>Dear ' . htmlspecialchars($user['full_name']) . ',</p>' .
            '<p>We\'ve received and verified your payment of <strong>TSh ' . number_format($amount, 0) . '</strong> ' .
            'for <strong>' . htmlspecialchars($studentName) . '</strong>.</p>' .
            '<p>Receipt number: <strong>' . htmlspecialchars($receipt) . '</strong></p>' .
            '<p>You can view the full receipt and your payment history anytime from the Fee Payments section of the parent portal.</p>' .
            '<p style="color:#888;font-size:12px;">This is an automated confirmation from the school fee management system.</p>';
        sendEmail($user['email'], $subject, $body);
    } catch (Exception $e) {
        error_log('notifyParentOfPaymentConfirmation error: ' . $e->getMessage());
    }
}

function getAcademicYear($db) {
    $r = $db->queryOne("SELECT academic_year FROM fee_structure GROUP BY academic_year ORDER BY COUNT(*) DESC, academic_year DESC LIMIT 1");
    if ($r && $r['academic_year']) return $r['academic_year'];
    $s = $db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key='academic_year'");
    if ($s && $s['setting_value']) return $s['setting_value'];
    $y = (int)date('Y'); return $y.'/'.($y+1);
}
function yearRange($yr) {
    // "2025/2026" -> [2025, 2026]. Matches finance.php's getAcademicYearRange()
    // semantics: used to query fee_payments across both calendar years a
    // single academic year can span.
    $p = explode('/', $yr);
    $y1 = (int)$p[0];
    return [$y1, count($p) > 1 ? (int)$p[1] : $y1 + 1];
}

function activeDiscount($db, $studentId) {
    $r = $db->queryOne("SELECT discount_percent FROM student_discounts WHERE student_id=? AND effective_from<=CURDATE() AND (effective_to IS NULL OR effective_to>=CURDATE()) ORDER BY effective_from DESC LIMIT 1",[$studentId]);
    return $r ? (float)$r['discount_percent'] : 0;
}

/* ── Server-side provider / card detection (never trust client) ── */
function detectNetworkProvider($phone) {
    $digits = preg_replace('/\D/', '', $phone);
    // normalize: strip leading 255 or 0
    if (substr($digits, 0, 3) === '255') $digits = '0' . substr($digits, 3);
    if (strlen($digits) < 4) return null;
    $prefix3 = substr($digits, 0, 4); // e.g. 0744
    $prefix3 = substr($digits, 0, 4);
    $p = substr($digits, 0, 4); // 0xxx
    foreach (MM_PROVIDERS as $provider => $prefixes) {
        foreach ($prefixes as $pre) {
            if (substr($digits, 0, 3) === $pre) return $provider;
        }
    }
    return 'Unknown';
}
function normalizePhone($phone) {
    $digits = preg_replace('/\D/', '', $phone);
    if (substr($digits, 0, 3) === '255') $digits = '0' . substr($digits, 3);
    return $digits;
}
function detectCardType($cardNumber) {
    $num = preg_replace('/\D/', '', $cardNumber);
    if (preg_match('/^4/', $num)) return 'Visa';
    if (preg_match('/^(5[1-5]|22[2-9]|2[3-6][0-9]|27[0-1]|2720)/', $num)) return 'Mastercard';
    return 'Unknown';
}
/**
 * Simulated control number (Tanzania-style style digits).
 * Replace with real bank/mobile API response when integrating.
 */
/**
 * Widen ENUMs + add control_number column so Control Number payments can be stored.
 */
function nsmsEnsureControlNumberPaymentSupport($db) {
    try {
        $db->execute(
            "ALTER TABLE payment_transactions
             MODIFY COLUMN payment_method ENUM(
                'M-Pesa','Tigo Pesa','Airtel Money','HaloPesa','Mixx by Yas',
                'Visa','Mastercard','Control Number'
             ) NOT NULL"
        );
    } catch (Exception $e) {
        error_log('ensure payment_method enum: ' . $e->getMessage());
    }
    try {
        $db->execute(
            "ALTER TABLE payment_transactions
             MODIFY COLUMN payment_channel ENUM('mobile_money','card','control_number') NOT NULL"
        );
    } catch (Exception $e) {
        error_log('ensure payment_channel enum: ' . $e->getMessage());
    }
    try {
        $col = $db->query("SHOW COLUMNS FROM payment_transactions LIKE 'control_number'");
        if (empty($col)) {
            $db->execute(
                "ALTER TABLE payment_transactions
                 ADD COLUMN control_number VARCHAR(32) NULL DEFAULT NULL AFTER transaction_reference"
            );
        }
    } catch (Exception $e) {
        error_log('ensure control_number col: ' . $e->getMessage());
    }
    // fee_payments ledger must accept Control Number on admin approval
    try {
        $db->execute(
            "ALTER TABLE fee_payments
             MODIFY COLUMN payment_method ENUM(
                'M-Pesa','Bank Transfer','Cash','Cheque','Other',
                'Tigo Pesa','Airtel Money','HaloPesa','Mixx by Yas',
                'Visa','Mastercard','Control Number'
             ) NOT NULL DEFAULT 'M-Pesa'"
        );
    } catch (Exception $e) {
        error_log('ensure fee_payments.payment_method enum: ' . $e->getMessage());
    }
}

function generateControlNumber($studentId) {
    $school = '99';
    $sid = str_pad((string)((int)$studentId % 100000), 5, '0', STR_PAD_LEFT);
    $rand = str_pad((string)random_int(0, 9999999), 7, '0', STR_PAD_LEFT);
    return $school . $sid . $rand; // 14 digits
}

function generateTxnReference($methodChannel, $provider=null) {
    if ($methodChannel === 'control_number') {
        return 'CN-' . random_int(100000000, 999999999);
    }
    if ($methodChannel === 'card') {
        return 'CARD-' . random_int(100000000, 999999999);
    }
    $prefixMap = ['Vodacom'=>'MP','Airtel'=>'AM','Tigo/Yas'=>'TP','Halotel'=>'HP','Unknown'=>'MM'];
    $prefix = $prefixMap[$provider] ?? 'TXN';
    return $prefix . '-' . random_int(1000000000, 9999999999);
}
function generateTxnReceiptNumber() {
    return 'RCP-' . date('Ymd') . '-' . strtoupper(substr(md5(uniqid()), 0, 6));
}

/* ═══════════════════════════════════════════════════════
   CORE: BUILD FULL FEE SUMMARY (unchanged logic, now reads
   from payment_items instead of the old single-item table)
═══════════════════════════════════════════════════════ */

function buildFeeSummary($db, $studentId, $classId, $yr) {
    $discount = activeDiscount($db, $studentId);
    [$yr1, $yr2] = yearRange($yr);

    /* ── 1. Fee structure: one-time items ── */
    $fsRows = $db->query(
        "SELECT fee_type, amount FROM fee_structure
          WHERE academic_year=? AND fee_type NOT IN('School Fees','Transport')
            AND (class_id=? OR class_id IS NULL)
          ORDER BY class_id DESC",
        [$yr, $classId]
    ) ?: [];
    $oneTimeDue = []; // fee_type => amount (class-specific wins)
    foreach ($fsRows as $r) {
        if (!isset($oneTimeDue[$r['fee_type']])) $oneTimeDue[$r['fee_type']] = (float)$r['amount'];
    }

    /* ── 2. REAL total paid — read from fee_payments, the authoritative ledger.
       This is the SAME source finance.php uses (buildPaymentStatus()), so it
       picks up every payment regardless of how it was recorded: admin manual
       entry (cash/bank/cheque), or approved transactions from this gateway
       module (which also write into fee_payments on approval).
       Without this, payments recorded outside the gateway module — e.g. by
       an admin typing them into the Finance panel directly — would be
       invisible here. This is the fix for "missing payment data".          */
    $totalPaidRow = $db->queryOne(
        "SELECT COALESCE(SUM(amount),0) AS paid
           FROM fee_payments
          WHERE student_id=? AND YEAR(payment_date) BETWEEN ? AND ? AND status='confirmed'",
        [$studentId, $yr1, $yr2]
    );
    $totalPaidLedger = (float)($totalPaidRow['paid'] ?? 0);

    /* ── 3. Pending items per fee_type / instalment (from THIS gateway's
       queue only — pending submissions naturally can't be in the ledger
       yet, so payment_items is the correct and only source for "pending"). */
    $pendingRows = $db->query(
        "SELECT pi.fee_type, pi.installment_no, COALESCE(SUM(pi.amount),0) AS total
           FROM payment_items pi
           JOIN payment_transactions pt ON pt.id = pi.payment_id
          WHERE pi.student_id=? AND pt.status='pending_verification'
          GROUP BY pi.fee_type, pi.installment_no",
        [$studentId]
    ) ?: [];
    $pendingMap = []; // fee_type => [ installment_no => amount ]  (0 = one-time)
    foreach ($pendingRows as $r) {
        $ft  = $r['fee_type'];
        $ins = (int)($r['installment_no'] ?? 0);
        if (!isset($pendingMap[$ft])) $pendingMap[$ft] = [];
        $pendingMap[$ft][$ins] = (float)$r['total'];
    }

    /* ── 4. Transport assignment ── */
    $hasTransport = false;
    try {
        $hasTransport = !!$db->queryOne(
            "SELECT id FROM student_transport WHERE student_id=? AND academic_year=? AND status='active'",
            [$studentId, $yr]
        );
    } catch (Throwable $e) {}

    /* ── 5. Ensure installment rows exist ── */
    ensureInstallments($db, $studentId, $classId, $yr, $discount);

    /* ── 6. Load installment slots.
       amount_paid / status on each row are already maintained by the
       approval flow (handleApproveTransaction marks slots 'paid' and
       sets amount_paid = amount_due), so these reflect real ledger state
       directly — no separate reconciliation needed here.                  */
    $instRows = $db->query(
        "SELECT fee_type, installment_no, amount_due, amount_paid, status, paid_date
           FROM fee_installments
          WHERE student_id=? AND academic_year=?
          ORDER BY fee_type ASC, installment_no ASC",
        [$studentId, $yr]
    ) ?: [];
    $installSlots = []; // fee_type => [slots]
    foreach ($instRows as $r) {
        if ($r['fee_type'] === 'Transport' && !$hasTransport) continue;
        $installSlots[$r['fee_type']][] = [
            'no'          => (int)$r['installment_no'],
            'amount_due'  => (float)$r['amount_due'],
            'amount_paid' => (float)$r['amount_paid'],
            'status'      => $r['status'],
            'paid_date'   => $r['paid_date'],
            'pending'     => (float)($pendingMap[$r['fee_type']][(int)$r['installment_no']] ?? 0),
        ];
    }

    /* ── 7. School Fees + Transport paid totals, straight from fee_installments
       (already kept in sync by the approval handler — matches finance.php). */
    $sfPaidFromInstallments = 0;
    $tpPaidFromInstallments = 0;
    foreach ($installSlots as $ft => $slots) {
        foreach ($slots as $s) {
            if ($ft === 'Transport') $tpPaidFromInstallments += $s['amount_paid'];
            else                     $sfPaidFromInstallments += $s['amount_paid'];
        }
    }

    /* ── 8. One-time fees paid — same sequential-bucket allocation as
       finance.php's buildPaymentStatus(): the ledger total is one
       undivided pool, applied against one-time fees first (in declared
       order), then whatever's left over implicitly covers instalments.
       This mirrors how the admin Finance panel already reports things,
       so the parent page and admin page never disagree.                  */
    $oneTimeTotal = array_sum($oneTimeDue);
    $oneTimePaidPool = min($totalPaidLedger, $oneTimeTotal);

    $oneTimeLines = [];
    $allocatedSoFar = 0;
    $allOneTimeDone = true;
    foreach ($oneTimeDue as $ft => $due) {
        $paid    = min($due, max(0, $oneTimePaidPool - $allocatedSoFar));
        $allocatedSoFar += $paid;
        $balance = max(0, $due - $paid);
        $pending = (float)($pendingMap[$ft][0] ?? 0);
        $done    = ($balance <= 0);
        if (!$done) $allOneTimeDone = false;
        $oneTimeLines[] = [
            'fee_type'=>$ft, 'amount_due'=>$due, 'amount_paid'=>$paid, 'balance'=>$balance,
            'pending'=>$pending, 'is_paid'=>$done, 'installable'=>false,
        ];
    }

    /* ── 9. Build installable fee lines (School Fees / Transport) ── */
    $installLines = [];
    foreach ($installSlots as $ft => $slots) {
        $ftDue  = array_sum(array_column($slots, 'amount_due'));
        $ftPaid = array_sum(array_column($slots, 'amount_paid'));
        $ftBal  = max(0, $ftDue - $ftPaid);
        $ftPend = array_sum(array_column($slots, 'pending'));
        $canPay = ($ft === 'Transport') || $allOneTimeDone;
        $installLines[] = [
            'fee_type'=>$ft, 'amount_due'=>$ftDue, 'amount_paid'=>$ftPaid, 'balance'=>$ftBal,
            'pending'=>$ftPend, 'is_paid'=>($ftBal<=0), 'installable'=>true, 'can_pay'=>$canPay, 'slots'=>$slots,
        ];
    }

    /* ── 10. Totals — Transport excluded from compulsory grand total,
       same rule as finance.php (Transport is optional).                  */
    $grandDue  = $oneTimeTotal + $sfPaidFromInstallments + array_sum(array_filter(
        array_map(fn($l) => $l['fee_type'] !== 'Transport' ? max(0, $l['amount_due'] - $l['amount_paid']) : 0, $installLines)
    ));
    // simpler/clearer: recompute directly
    $sfDue = 0;
    foreach ($installLines as $l) if ($l['fee_type'] !== 'Transport') $sfDue += $l['amount_due'];
    $grandDue  = $oneTimeTotal + $sfDue;
    $grandPaid = min($totalPaidLedger, $grandDue); // ledger total naturally covers one-time + school fees together
    $grandBal  = max(0, $grandDue - $grandPaid);

    $totalPending = array_sum(array_column($oneTimeLines, 'pending')) + array_sum(array_column($installLines, 'pending'));

    return [
        'student_id'        => (int)$studentId,
        'academic_year'     => $yr,
        'discount_pct'      => $discount,
        'one_time_lines'    => $oneTimeLines,
        'install_lines'     => $installLines,
        'all_one_time_done' => $allOneTimeDone,
        'has_transport'     => $hasTransport,
        'grand_due'         => $grandDue,
        'grand_paid'        => $grandPaid,
        'grand_balance'     => $grandBal,
        'total_pending'     => $totalPending,
        'fully_paid'        => ($grandDue > 0 && $grandBal <= 0),
    ];
}
function ensureInstallments($db, $studentId, $classId, $yr, $discount) {
    $fees = $db->query(
        "SELECT fee_type, amount FROM fee_structure
          WHERE academic_year=? AND fee_type IN('School Fees','Transport')
            AND (class_id=? OR class_id IS NULL) ORDER BY class_id DESC",
        [$yr,$classId]
    ) ?: [];
    $seen = [];
    foreach ($fees as $f) {
        $ft = $f['fee_type'];
        if (isset($seen[$ft])) continue;
        $seen[$ft] = true;
        $base = round((float)$f['amount'] / GW_MAX_INSTALLMENTS, 2);
        $amt  = $discount > 0 ? round($base*(1-$discount/100),2) : $base;
        for ($i=1; $i<=GW_MAX_INSTALLMENTS; $i++) {
            $db->execute(
                "INSERT IGNORE INTO fee_installments (student_id,academic_year,fee_type,installment_no,amount_due) VALUES (?,?,?,?,?)",
                [$studentId,$yr,$ft,$i,$amt]
            );
        }
    }
}

/* ═══════════════════════════════════════════════════════
   PARENT: FEE SUMMARY
═══════════════════════════════════════════════════════ */

function handleFeeSummary($db, $userId) {
    $children = $db->query(
        "SELECT s.id,s.student_name,s.status,c.id AS class_id,c.class_name
           FROM parents p JOIN students s ON s.id=p.student_id JOIN classes c ON c.id=s.class_id
          WHERE p.user_id=? AND s.status IN ('active','graduated') ORDER BY (s.status='graduated'), s.student_name",
        [$userId]
    ) ?: [];
    $yr = getAcademicYear($db);
    $out = [];
    foreach ($children as $ch) {
        $summary = buildFeeSummary($db, $ch['id'], $ch['class_id'], $yr);
        $summary['student_name'] = $ch['student_name'];
        $summary['class_name']   = $ch['class_name'];
        $summary['status']       = $ch['status'];
        $out[] = $summary;
    }
    apiOk($out);
}

/* ═══════════════════════════════════════════════════════
   PARENT: MY TRANSACTIONS (header rows + item count)
═══════════════════════════════════════════════════════ */

function handleMyTransactions($db, $userId) {
    $rows = $db->query(
        "SELECT pt.*, s.student_name, c.class_name,
                (SELECT COUNT(*) FROM payment_items WHERE payment_id=pt.id) AS item_count
           FROM payment_transactions pt
           JOIN students s ON s.id=pt.student_id
           JOIN classes  c ON c.id=s.class_id
          WHERE pt.parent_id=?
          ORDER BY pt.created_at DESC LIMIT 100",
        [$userId]
    ) ?: [];
    apiOk($rows);
}

/* ═══════════════════════════════════════════════════════
   PARENT: SUBMIT TRANSACTION
   Body: {
     student_id, items: [{fee_type, installment_no?, amount}, ...],
     payment_method, phone_number? | card_number?+card_holder_name?+expiry?+cvv?,
     payment_date, notes?
   }
═══════════════════════════════════════════════════════ */

function handleSubmitTransaction($db, $userId, $body) {
    $studentId = (int)rf($body, 'student_id');
    $items     = rf($body, 'items'); // array
    $pmethod   = rf($body, 'payment_method');
    $payDate   = rf($body, 'payment_date');
    $notes     = isset($body['notes']) ? trim((string)$body['notes']) : null;

    if (!parentOwnsStudent($db, $userId, $studentId)) apiError('Access denied', 403);
    if (!is_array($items) || count($items) === 0)     apiError('At least one fee item must be selected');
    if (count($items) > 20)                           apiError('Too many items in a single transaction');

    if (!isset(METHOD_CHANNEL[$pmethod])) apiError('Invalid payment method');
    $channel = METHOD_CHANNEL[$pmethod];

    /* ── channel-specific fields ── */
    $phone = null; $provider = null;
    $cardHolder = null; $cardLast4 = null; $cardType = null;

    $controlNumber = null;
    if ($channel === 'mobile_money') {
        $phone = rf($body, 'phone_number');
        $phoneNorm = normalizePhone($phone);
        if (strlen($phoneNorm) < 9) apiError('Invalid phone number');
        $provider = detectNetworkProvider($phoneNorm);
        $phone = $phoneNorm;
    } elseif ($channel === 'card') {
        $cardHolder = rf($body, 'card_holder_name');
        $cardNumber = rf($body, 'card_number');
        $expiry     = rf($body, 'card_expiry');
        $cvv        = rf($body, 'card_cvv');
        $cardDigits = preg_replace('/\D/', '', $cardNumber);
        if (strlen($cardDigits) < 13 || strlen($cardDigits) > 19) apiError('Invalid card number');
        if (!preg_match('/^\d{3,4}$/', $cvv)) apiError('Invalid CVV');
        if (!preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $expiry)) apiError('Invalid expiry format (MM/YY)');
        $cardType  = detectCardType($cardDigits);
        $cardLast4 = substr($cardDigits, -4);
        if ($cardType === 'Unknown') apiError('Unrecognized card type. Please check the card number.');
        if ($cardType !== $pmethod) apiError("Card number does not match selected card type ($pmethod).");
    } elseif ($channel === 'control_number') {
        $controlNumber = generateControlNumber($studentId);
        $provider = 'Control Number (Simulation)';
    } else {
        apiError('Unsupported payment channel');
    }

    /* ── validate each item against the live fee summary ── */
    $student = $db->queryOne("SELECT class_id FROM students WHERE id=?", [$studentId]);
    if (!$student) apiError('Student not found');
    $yr      = getAcademicYear($db);
    $summary = buildFeeSummary($db, $studentId, $student['class_id'], $yr);

    $validatedItems = [];
    $totalAmount = 0;

    foreach ($items as $idx => $item) {
        if (!isset($item['fee_type']) || !isset($item['amount'])) apiError("Item #".($idx+1)." is missing fee_type or amount");
        $ft     = trim((string)$item['fee_type']);
        $amt    = (float)$item['amount'];
        $instNo = isset($item['installment_no']) && $item['installment_no'] !== null ? (int)$item['installment_no'] : null;

        if ($amt <= 0) apiError("Invalid amount for $ft");

        if ($ft === 'School Fees') {
            if (!$summary['all_one_time_done']) {
                apiError('All contribution fees must be fully paid before submitting School Fee instalments.');
            }
            if (!$instNo || $instNo < 1 || $instNo > GW_MAX_INSTALLMENTS) apiError("Valid instalment number required for School Fees item.");
            $sfLine = null;
            foreach ($summary['install_lines'] as $il) if ($il['fee_type']==='School Fees') { $sfLine=$il; break; }
            if ($sfLine) {
                foreach ($sfLine['slots'] as $slot) {
                    if ($slot['no']===$instNo) {
                        if ($slot['status']==='paid') apiError("School Fees instalment #$instNo is already paid.");
                        if ($slot['pending']>0)       apiError("School Fees instalment #$instNo already has a pending submission.");
                        break;
                    }
                }
            }
        } elseif ($ft === 'Transport') {
            if (!$instNo || $instNo < 1 || $instNo > GW_MAX_INSTALLMENTS) apiError("Valid instalment number required for Transport item.");
            $tpLine = null;
            foreach ($summary['install_lines'] as $il) if ($il['fee_type']==='Transport') { $tpLine=$il; break; }
            if ($tpLine) {
                foreach ($tpLine['slots'] as $slot) {
                    if ($slot['no']===$instNo) {
                        if ($slot['status']==='paid') apiError("Transport instalment #$instNo is already paid.");
                        if ($slot['pending']>0)       apiError("Transport instalment #$instNo already has a pending submission.");
                        break;
                    }
                }
            }
        } else {
            // one-time fee
            $found = false;
            foreach ($summary['one_time_lines'] as $line) {
                if ($line['fee_type'] === $ft) {
                    $found = true;
                    if ($line['is_paid'])     apiError("$ft is already fully paid.");
                    if ($line['pending'] > 0) apiError("$ft already has a pending submission.");
                    if ($amt > $line['balance'] + 0.01) apiError("Amount for $ft exceeds outstanding balance.");
                    break;
                }
            }
            if (!$found) apiError("Unknown fee type: $ft");
        }

        $validatedItems[] = ['fee_type'=>$ft, 'installment_no'=>$instNo, 'amount'=>$amt];
        $totalAmount += $amt;
    }

    // guard against duplicate items in the same submission
    $seenKeys = [];
    foreach ($validatedItems as $it) {
        $key = $it['fee_type'].'|'.($it['installment_no'] ?? '0');
        if (isset($seenKeys[$key])) apiError('Duplicate item in submission: '.$it['fee_type']);
        $seenKeys[$key] = true;
    }

    if ($channel === 'control_number') {
        nsmsEnsureControlNumberPaymentSupport($db);
    }

    $txnRef = generateTxnReference($channel, $provider);
    $tries = 0;
    while ($db->queryOne("SELECT id FROM payment_transactions WHERE transaction_reference=?", [$txnRef]) && $tries < 5) {
        $txnRef = generateTxnReference($channel, $provider);
        $tries++;
    }

    try {
        $col = $db->query("SHOW COLUMNS FROM payment_transactions LIKE 'control_number'");
        if (empty($col)) {
            $db->execute("ALTER TABLE payment_transactions ADD COLUMN control_number VARCHAR(32) NULL DEFAULT NULL AFTER transaction_reference");
        }
    } catch (Exception $e) {}

    if ($channel === 'control_number' && $controlNumber) {
        $notes = trim(($notes ? $notes . ' | ' : '') . 'Control Number: ' . $controlNumber);
    }

    $conn = $db->connect();
    $conn->beginTransaction();
    try {
        if ($channel === 'control_number' && $controlNumber) {
            $ptId = $db->execute(
                "INSERT INTO payment_transactions
                    (student_id,parent_id,total_amount,payment_method,payment_channel,network_provider,
                     phone_number,card_type,card_last_four,card_holder_name,transaction_reference,control_number,
                     payment_date,notes,status,created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending_verification',NOW())",
                [$studentId,$userId,$totalAmount,$pmethod,$channel,$provider,
                 $phone,$cardType,$cardLast4,$cardHolder,$txnRef,$controlNumber,$payDate,$notes]
            );
        } else {
            $ptId = $db->execute(
                "INSERT INTO payment_transactions
                    (student_id,parent_id,total_amount,payment_method,payment_channel,network_provider,
                     phone_number,card_type,card_last_four,card_holder_name,transaction_reference,
                     payment_date,notes,status,created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'pending_verification',NOW())",
                [$studentId,$userId,$totalAmount,$pmethod,$channel,$provider,
                 $phone,$cardType,$cardLast4,$cardHolder,$txnRef,$payDate,$notes]
            );
        }
        if (!$ptId) {
            // Fallback without control_number column if ALTER did not apply
            if ($channel === 'control_number' && $controlNumber) {
                $ptId = $db->execute(
                    "INSERT INTO payment_transactions
                        (student_id,parent_id,total_amount,payment_method,payment_channel,network_provider,
                         phone_number,card_type,card_last_four,card_holder_name,transaction_reference,
                         payment_date,notes,status,created_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'pending_verification',NOW())",
                    [$studentId,$userId,$totalAmount,$pmethod,$channel,$provider,
                     $phone,$cardType,$cardLast4,$cardHolder,$txnRef,$payDate,$notes]
                );
            }
            if (!$ptId) throw new Exception('Failed to create transaction (check payment_method/payment_channel ENUM allows Control Number)');
        }

        foreach ($validatedItems as $it) {
            $db->execute(
                "INSERT INTO payment_items (payment_id,student_id,fee_type,installment_no,amount,status,created_at)
                 VALUES (?,?,?,?,?,'pending_verification',NOW())",
                [$ptId,$studentId,$it['fee_type'],$it['installment_no'],$it['amount']]
            );
        }
        $conn->commit();
    } catch (Exception $e) {
        $conn->rollBack();
        apiError('Failed to submit transaction: '.$e->getMessage(), 500);
    }

    // Notify all admins — full details per requirements
    $st    = $db->queryOne("SELECT student_name FROM students WHERE id=?", [$studentId]);
    $pu    = $db->queryOne("SELECT full_name FROM users WHERE id=?", [$userId]);
    $sName = $st ? $st['student_name'] : 'Student';
    $pName = $pu ? $pu['full_name']    : 'Parent';

    // PHP 7.2 compatible — no arrow functions
    $itemParts = [];
    foreach ($validatedItems as $vi) {
        $itemParts[] = $vi['fee_type'] . ($vi['installment_no'] ? " #{$vi['installment_no']}" : '');
    }
    $itemSummary = implode(', ', $itemParts);

    if ($channel === 'control_number' && !empty($controlNumber)) {
        $adminTitle = "Control Number Issued — Awaiting Payment";
        $adminMsg   = "Parent: {$pName} | Student: {$sName} | "
                    . "Amount: TSh " . number_format($totalAmount, 0) . " | "
                    . "Fees: {$itemSummary} | "
                    . "Control Number: {$controlNumber} | "
                    . "Parent will pay via bank/mobile using this number. "
                    . "Verify in Payment Verification when funds appear.";
    } else {
        $adminTitle = "New Payment Submitted — Verification Required";
        $adminMsg   = "Parent: {$pName} | Student: {$sName} | "
                    . "Amount: TSh " . number_format($totalAmount, 0) . " | "
                    . "Fees: {$itemSummary} | "
                    . "Method: {$pmethod} | "
                    . "Date: " . date('d M Y', strtotime($payDate)) . " | "
                    . "Status: Pending Verification. "
                    . "Please review in the Payment Verification panel.";
    }
    /* PLACEHOLDER_SKIP_OLD_ADMIN */

    foreach (getAdminUserIds($db) as $aid) {
        insertNotification($db, $aid, $adminTitle, $adminMsg);
    }

    apiOk([
        'transaction_id'        => (int)$ptId,
        'transaction_reference' => $txnRef,
        'control_number'        => isset($controlNumber) ? $controlNumber : null,
        'total_amount'          => $totalAmount,
        'network_provider'      => $provider,
        'card_type'             => $cardType,
        'payment_method'        => $pmethod,
        'payment_channel'       => $channel,
        'simulation'            => ($channel === 'control_number'),
    ], $channel === 'control_number'
        ? 'Control number generated. Use it to complete payment (simulation).'
        : 'Payment submitted successfully.');
}

/* ═══════════════════════════════════════════════════════
   PARENT: UPLOAD PROOF (attaches to the transaction header)
═══════════════════════════════════════════════════════ */

function handleUploadProof($db, $userId, $uploadDir) {
    $txnId = isset($_POST['transaction_id']) ? (int)$_POST['transaction_id'] : 0;
    if (!$txnId) apiError('transaction_id required');
    $txn = $db->queryOne("SELECT id,status FROM payment_transactions WHERE id=? AND parent_id=?", [$txnId,$userId]);
    if (!$txn)                                   apiError('Transaction not found', 404);
    if ($txn['status'] !== 'pending_verification') apiError('Cannot update proof — already reviewed');
    if (!isset($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) apiError('No valid file');

    $file = $_FILES['proof'];
    $allowedMimes = ['image/jpeg','image/png','image/gif','image/webp','application/pdf'];
    $extMap = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','application/pdf'=>'pdf'];
    if ($file['size'] > 5*1024*1024) apiError('Max 5MB');
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo,$file['tmp_name']); finfo_close($finfo);
    if (!in_array($mime,$allowedMimes)) apiError('Invalid file type');

    $fname = 'proof_txn'.$txnId.'_'.time().'.'.$extMap[$mime];
    if (!move_uploaded_file($file['tmp_name'], $uploadDir.$fname)) apiError('File save failed');
    $db->execute("UPDATE payment_transactions SET payment_proof=? WHERE id=?", ['payment_proofs/'.$fname, $txnId]);
    apiOk(['proof_path'=>'payment_proofs/'.$fname], 'Proof uploaded.');
}

/* ═══════════════════════════════════════════════════════
   ADMIN: ALL TRANSACTIONS
═══════════════════════════════════════════════════════ */

function handleAllTransactions($db) {
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $limit  = min((int)($_GET['limit'] ?? 50), 100);
    $offset = max((int)($_GET['offset'] ?? 0), 0);
    $valid  = ['pending_verification','received','rejected'];
    $where=[]; $params=[];
    if ($status && in_array($status,$valid)) { $where[]='pt.status=?'; $params[]=$status; }
    $wq = $where ? 'WHERE '.implode(' AND ',$where) : '';

    $total = (int)($db->queryOne("SELECT COUNT(*) AS c FROM payment_transactions pt $wq", $params)['c'] ?? 0);
    $params[]=$limit; $params[]=$offset;

    $rows = $db->query(
        "SELECT pt.*, s.student_name, c.class_name,
                u.full_name AS parent_name, u.phone AS parent_phone,
                v.full_name AS verified_by_name,
                (SELECT COUNT(*) FROM payment_items WHERE payment_id=pt.id) AS item_count
           FROM payment_transactions pt
           JOIN students s ON s.id=pt.student_id
           JOIN classes  c ON c.id=s.class_id
           JOIN users    u ON u.id=pt.parent_id
           LEFT JOIN users v ON v.id=pt.verified_by
           $wq ORDER BY pt.created_at DESC LIMIT ? OFFSET ?",
        $params
    ) ?: [];

    apiOk(['transactions'=>$rows, 'total'=>$total, 'limit'=>$limit, 'offset'=>$offset]);
}

/* ═══════════════════════════════════════════════════════
   ADMIN: STATS
═══════════════════════════════════════════════════════ */

function handleVerificationStats($db) {
    $counts = $db->query("SELECT status, COUNT(*) AS c FROM payment_transactions GROUP BY status") ?: [];
    $stats  = ['pending_verification'=>0,'received'=>0,'rejected'=>0];
    foreach ($counts as $r) $stats[$r['status']] = (int)$r['c'];
    $recv  = $db->queryOne("SELECT COALESCE(SUM(total_amount),0) AS t FROM payment_transactions WHERE status='received'");
    $today = $db->queryOne("SELECT COUNT(*) AS c FROM payment_transactions WHERE status='pending_verification' AND DATE(created_at)=CURDATE()");
    apiOk(['counts'=>$stats, 'total_received'=>(float)($recv['t']??0), 'new_today'=>(int)($today['c']??0)]);
}

/* ═══════════════════════════════════════════════════════
   SHARED: TRANSACTION DETAIL (header + items)
═══════════════════════════════════════════════════════ */

function handleGetDetail($db, $role, $userId) {
    $id = (int)($_GET['transaction_id'] ?? $_GET['submission_id'] ?? 0);
    if (!$id) apiError('transaction_id required');
    $params=[$id]; $extra='';
    if ($role==='parent') { $extra='AND pt.parent_id=?'; $params[]=$userId; }

    $txn = $db->queryOne(
        "SELECT pt.*, s.student_name, c.class_name,
                u.full_name AS parent_name, u.phone AS parent_phone, u.email AS parent_email,
                v.full_name AS verified_by_name
           FROM payment_transactions pt
           JOIN students s ON s.id=pt.student_id
           JOIN classes  c ON c.id=s.class_id
           JOIN users    u ON u.id=pt.parent_id
           LEFT JOIN users v ON v.id=pt.verified_by
          WHERE pt.id=? $extra",
        $params
    );
    if (!$txn) apiError('Transaction not found', 404);

    $items = $db->query("SELECT * FROM payment_items WHERE payment_id=? ORDER BY id ASC", [$id]) ?: [];
    $txn['items'] = $items;
    apiOk($txn);
}

/* ═══════════════════════════════════════════════════════
   ADMIN: APPROVE TRANSACTION
   - Marks transaction + all items received
   - Inserts one fee_payments ledger row per item
   - Updates fee_installments for installable items
   - Recalculates student_fee_accounts
   - Notifies parent once for the whole transaction
═══════════════════════════════════════════════════════ */

function handleApproveTransaction($db, $adminId, $body) {
    $txnId = (int)rf($body, 'transaction_id');
    $txn = $db->queryOne(
        "SELECT pt.*, s.student_name, s.class_id FROM payment_transactions pt JOIN students s ON s.id=pt.student_id WHERE pt.id=?",
        [$txnId]
    );
    if (!$txn)                                    apiError('Transaction not found', 404);
    if ($txn['status'] !== 'pending_verification') apiError('Only pending transactions can be approved');

    // Ensure ledger ENUM accepts gateway methods (including Control Number)
    nsmsEnsureControlNumberPaymentSupport($db);

    $items = $db->query("SELECT * FROM payment_items WHERE payment_id=?", [$txnId]) ?: [];
    if (!$items) apiError('Transaction has no items');

    /* NOTE: $db->execute() catches PDOExceptions internally and returns
       false on failure instead of throwing — it never lets a try/catch
       around it detect a failed write. So every write below is checked
       explicitly against its return value, and we throw our own
       Exception the moment one fails. This is what actually surfaces
       errors (e.g. an out-of-range ENUM value) instead of silently
       committing a transaction that wrote nothing.                    */
    $conn = $db->connect();
    $conn->beginTransaction();
    try {
        // The transaction-level receipt shown to parent/admin — one shared
        // reference for the whole payment, stored on payment_transactions.
        $receipt = generateTxnReceiptNumber();

        $txnUpdateResult = $db->execute(
            "UPDATE payment_transactions SET status='received',verified_by=?,verified_at=NOW(),receipt_number=?,updated_at=NOW() WHERE id=?",
            [$adminId, $receipt, $txnId]
        );
        if ($txnUpdateResult === false) {
            throw new Exception('Failed to update transaction status. Check server error log for the underlying SQL error.');
        }

        $itemIndex = 0;
        foreach ($items as $item) {
            $itemIndex++;
            // fee_payments.receipt_number has a UNIQUE KEY — one row per
            // item means one INSERT per item, so each row needs its OWN
            // receipt number. Reusing $receipt across multiple items was
            // the actual bug: the 2nd+ item in any multi-item transaction
            // collided on the unique key and silently failed, which is why
            // approval appeared to do nothing for transactions with more
            // than one fee item — regardless of payment_method.
            // The shared $receipt above (on payment_transactions) is what
            // parents/admins see as "the" receipt for the whole payment;
            // these per-item ledger receipts are suffixed so they stay
            // traceable back to it.
            $itemReceipt = $receipt . '-' . $itemIndex;

            $ledgerMethod = $txn['payment_method'];
            // Map control number payments to ledger-friendly method if ENUM still lagging
            $allowedMethods = array(
                'M-Pesa','Bank Transfer','Cash','Cheque','Other',
                'Tigo Pesa','Airtel Money','HaloPesa','Mixx by Yas',
                'Visa','Mastercard','Control Number'
            );
            if (!in_array($ledgerMethod, $allowedMethods, true)) {
                $ledgerMethod = 'Bank Transfer';
            }
            $ledgerRef = $txn['transaction_reference'];
            if (!empty($txn['control_number'])) {
                $ledgerRef = $ledgerRef . ' / CN:' . $txn['control_number'];
            }
            $fpId = $db->execute(
                "INSERT INTO fee_payments (student_id,amount,payment_method,payment_date,receipt_number,reference_number,status,recorded_by,created_at)
                 VALUES (?,?,?,?,?,?,'confirmed',?,NOW())",
                [$item['student_id'], $item['amount'], $ledgerMethod, $txn['payment_date'], $itemReceipt, $ledgerRef, $adminId]
            );
            // Retry once with Bank Transfer if ENUM still rejects Control Number
            if (($fpId === false || !$fpId) && $ledgerMethod === 'Control Number') {
                $fpId = $db->execute(
                    "INSERT INTO fee_payments (student_id,amount,payment_method,payment_date,receipt_number,reference_number,status,recorded_by,created_at)
                     VALUES (?,?,?,?,?,?,'confirmed',?,NOW())",
                    [$item['student_id'], $item['amount'], 'Bank Transfer', $txn['payment_date'], $itemReceipt, $ledgerRef, $adminId]
                );
            }
            if ($fpId === false || !$fpId) {
                // Most likely causes, in order of likelihood:
                // 1. payment_method value isn't in the fee_payments ENUM yet
                //    (run payment_gateway_migration.sql v4.1 patch).
                // 2. A genuinely duplicate receipt_number collision (should
                //    no longer happen now that each item gets its own).
                throw new Exception(
                    "Failed to record ledger entry for {$item['fee_type']} (TSh ".number_format($item['amount'],0)."). ".
                    "This usually means the payment_method '{$txn['payment_method']}' is not yet allowed in the fee_payments table, ".
                    "or a receipt_number collision occurred. Run payment_gateway_migration.sql v4.1 (or verify_and_fix_payment_method_enum.sql) and try again."
                );
            }

            $itemUpdateResult = $db->execute("UPDATE payment_items SET status='received', fee_payment_id=? WHERE id=?", [$fpId, $item['id']]);
            if ($itemUpdateResult === false) {
                throw new Exception("Failed to mark item #{$item['id']} ({$item['fee_type']}) as received.");
            }

            if ($item['fee_type'] && $item['installment_no'] && in_array($item['fee_type'], GW_INSTALLABLE_FEES)) {
                $instResult = $db->execute(
                    "UPDATE fee_installments SET amount_paid=amount_due,status='paid',payment_id=?,paid_date=? WHERE student_id=? AND fee_type=? AND installment_no=? AND status!='paid'",
                    [$fpId, $txn['payment_date'], $item['student_id'], $item['fee_type'], $item['installment_no']]
                );
                if ($instResult === false) {
                    throw new Exception("Failed to update {$item['fee_type']} instalment #{$item['installment_no']} for student #{$item['student_id']}.");
                }
                // 0 rows affected is NOT necessarily an error (slot may already
                // be 'paid' from a prior approval, guarded by status!='paid'),
                // so we don't throw on $instResult === 0 — only on false.
            }
        }

        // recalc student_fee_accounts — read total_paid from fee_payments (the
        // real ledger), not just this gateway's payment_items. This makes sure
        // any payments recorded elsewhere (e.g. admin manual entry via the
        // Finance panel) are reflected, matching finance.php's own totals.
        $yr = getAcademicYear($db);
        [$yr1, $yr2] = yearRange($yr);
        $fs = $db->queryOne("SELECT COALESCE(SUM(amount),0) AS t FROM fee_structure WHERE academic_year=? AND (class_id=? OR class_id IS NULL)", [$yr, $txn['class_id']]);
        $fp = $db->queryOne(
            "SELECT COALESCE(SUM(amount),0) AS t FROM fee_payments WHERE student_id=? AND YEAR(payment_date) BETWEEN ? AND ? AND status='confirmed'",
            [$txn['student_id'], $yr1, $yr2]
        );
        $totalFee  = (float)($fs['t']??0);
        $totalPaid = (float)($fp['t']??0);
        $acctResult = $db->execute(
            "INSERT INTO student_fee_accounts (student_id,total_fee,total_paid,balance) VALUES (?,?,?,?)
             ON DUPLICATE KEY UPDATE total_paid=VALUES(total_paid),balance=VALUES(balance),last_updated=NOW()",
            [$txn['student_id'], $totalFee, $totalPaid, max(0,$totalFee-$totalPaid)]
        );
        if ($acctResult === false) {
            throw new Exception('Failed to update student_fee_accounts balance.');
        }

        $conn->commit();

        insertNotification($db, $txn['parent_id'], "Payment Received ✓",
            "Your payment of TSh ".number_format($txn['total_amount'],0)." for {$txn['student_name']} has been verified and received successfully. Receipt: {$receipt}."
        );
        notifyParentOfPaymentConfirmation($db, $txn['parent_id'], $txn['student_name'], $txn['total_amount'], $receipt);

        if (class_exists('SyncHooks')) {
            foreach ($items as $it) {
                // fee_payments rows created during approve — best-effort notify
                SyncHooks::afterWrite($db, 'fee_payments', 0, 'CREATE', array(
                    'student_id' => $txn['student_id'],
                    'amount' => $it['amount'],
                    'payment_method' => $txn['payment_method'],
                    'status' => 'confirmed',
                    'uuid' => class_exists('DeviceIdentity') ? DeviceIdentity::generateUuid() : null,
                ));
            }
        }
        apiOk(['receipt_number'=>$receipt, 'items_approved'=>count($items)], 'Transaction approved and all items updated.');
    } catch (Exception $e) {
        $conn->rollBack();
        apiError('Approval failed: '.$e->getMessage(), 500);
    }
}

/* ═══════════════════════════════════════════════════════
   ADMIN: REJECT TRANSACTION
═══════════════════════════════════════════════════════ */

function handleRejectTransaction($db, $adminId, $body) {
    $txnId  = (int)rf($body, 'transaction_id');
    $reason = rf($body, 'rejection_reason');
    $txn = $db->queryOne(
        "SELECT pt.*, s.student_name FROM payment_transactions pt JOIN students s ON s.id=pt.student_id WHERE pt.id=?",
        [$txnId]
    );
    if (!$txn)                                    apiError('Transaction not found', 404);
    if ($txn['status'] !== 'pending_verification') apiError('Only pending transactions can be rejected');

    $db->execute(
        "UPDATE payment_transactions SET status='rejected',verified_by=?,verified_at=NOW(),rejection_reason=?,updated_at=NOW() WHERE id=?",
        [$adminId, $reason, $txnId]
    );
    $db->execute("UPDATE payment_items SET status='rejected' WHERE payment_id=?", [$txnId]);

    insertNotification($db, $txn['parent_id'], "Payment Submission Rejected",
        "Your payment of TSh ".number_format($txn['total_amount'],0)." for {$txn['student_name']} was rejected. Reason: {$reason}."
    );
    apiOk(null, 'Transaction rejected and parent notified.');
}