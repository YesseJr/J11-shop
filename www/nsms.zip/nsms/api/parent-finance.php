<?php
/**
====================================
    * Author: Waython Yesse
    * Address: waythonny@yahoo.com
    * Year: 2026
====================================
 * Parent Finance API  —  PHP 7.2+ / MySQL 5.7+
 *
 * Read-only, parent-scoped view of a child's fee status. Mirrors the
 * calculation logic in api/finance.php (buildPaymentStatus etc.) but every
 * action is locked to students that actually belong to the logged-in
 * parent (via the `parents` table), and never exposes admin-only actions
 * like recording payments or editing the fee structure.
 *
 * Actions (GET):
 *   my_children | child_payment_status | child_payments | fee_structure | payment_receipt
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

applyApiHeaders();

requireRole('parent');

$db   = new Database();
$conn = $db->connect();
if (!$conn) {
    ob_end_clean();
    echo json_encode(['success' => false, 'error' => 'DB connection failed']);
    exit;
}

$userId = getCurrentUserId();
$action = isset($_GET['action']) ? $_GET['action'] : '';

define('TOTAL_INSTALLMENTS', 10);

try {
    switch ($action) {
        case 'my_children':          getMyChildren($db, $userId);          break;
        case 'child_payment_status': getChildPaymentStatus($db, $userId);  break;
        case 'child_payments':       getChildPayments($db, $userId);       break;
        case 'fee_structure':        getParentFeeStructure($db, $userId);  break;
        case 'payment_receipt':      getParentPaymentReceipt($db, $userId);break;
        default:
            fail('Invalid action', 400);
    }
} catch (Throwable $e) {
    ob_end_clean();
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
    exit;
}

/* ═══════════════════════════════════════════════
   RESPONSE HELPERS
═══════════════════════════════════════════════ */
function ok($data, $msg = 'OK') {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'data' => $data, 'message' => $msg]);
    exit;
}
function fail($msg, $code = 400) {
    ob_end_clean();
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $msg]);
    exit;
}

/**
 * Ownership guard — every action below must call this before touching a
 * student's records, so one parent can never pull another family's data
 * just by changing a student_id / payment_id in the request.
 */
function studentBelongsToParent($db, $studentId, $userId) {
    $row = $db->queryOne(
        "SELECT id FROM parents WHERE student_id = :sid AND user_id = :uid LIMIT 1",
        [':sid' => $studentId, ':uid' => $userId]
    );
    return (bool)$row;
}

/* ═══════════════════════════════════════════════
   SHARED CALCULATION HELPERS
   (mirrors api/finance.php so numbers always agree
   with what the admin panel shows)
═══════════════════════════════════════════════ */
function getAcademicYear($db) {
    $row = $db->queryOne(
        "SELECT academic_year, COUNT(*) AS cnt
           FROM fee_structure
          GROUP BY academic_year
          ORDER BY cnt DESC, academic_year DESC
          LIMIT 1"
    );
    if ($row && !empty($row['academic_year'])) return $row['academic_year'];

    $setting = $db->queryOne(
        "SELECT setting_value FROM school_settings WHERE setting_key='academic_year'"
    );
    if ($setting && !empty($setting['setting_value'])) return $setting['setting_value'];

    $y = (int)date('Y');
    return $y . '/' . ($y + 1);
}

function getAcademicYearRange($academicYear) {
    $parts = explode('/', $academicYear);
    $y1 = (int)$parts[0];
    $y2 = count($parts) > 1 ? (int)$parts[1] : $y1 + 1;
    return [$y1, $y2];
}

function getActiveDiscount($db, $studentId) {
    $row = $db->queryOne(
        "SELECT discount_percent FROM student_discounts
          WHERE student_id = :sid
            AND effective_from <= CURDATE()
            AND (effective_to IS NULL OR effective_to >= CURDATE())
          ORDER BY effective_from DESC LIMIT 1",
        [':sid' => $studentId]
    );
    return $row ? (float)$row['discount_percent'] : 0;
}

function applyDiscount($amount, $discountPct) {
    if ($discountPct <= 0) return $amount;
    return round($amount * (1 - $discountPct / 100), 2);
}

function ensureInstallments($db, $studentId, $classId, $academicYear) {
    $fees = $db->query(
        "SELECT fee_type, amount FROM fee_structure
          WHERE academic_year = :yr
            AND fee_type = 'School Fees'
            AND (class_id = :cid OR class_id IS NULL)
          ORDER BY class_id DESC LIMIT 1",
        [':yr' => $academicYear, ':cid' => $classId]
    ) ?: [];

    if (empty($fees)) return;
    $annualAmount = (float)$fees[0]['amount'];
    $discount = getActiveDiscount($db, $studentId);
    $base = round($annualAmount / TOTAL_INSTALLMENTS, 2);
    $installmentAmount = applyDiscount($base, $discount);

    for ($i = 1; $i <= TOTAL_INSTALLMENTS; $i++) {
        $db->execute(
            "INSERT IGNORE INTO fee_installments
               (student_id, academic_year, fee_type, installment_no, amount_due)
             VALUES (:sid, :yr, 'School Fees', :no, :amt)",
            [':sid' => $studentId, ':yr' => $academicYear, ':no' => $i, ':amt' => $installmentAmount]
        );
    }
}

/**
 * Get full payment status for a student for the current academic year.
 * Identical shape to what the admin finance page uses, so parent-facing
 * pages can share the same rendering logic.
 */
function buildPaymentStatus($db, $studentId, $classId, $academicYear) {
    $discount = getActiveDiscount($db, $studentId);

    $feeRows = $db->query(
        "SELECT fs.fee_type, fs.amount, fs.class_id
           FROM fee_structure fs
          WHERE fs.academic_year = :yr
            AND fs.fee_type NOT IN ('School Fees','Transport')
            AND (fs.class_id = :cid OR fs.class_id IS NULL)
          ORDER BY fs.class_id DESC",
        [':yr' => $academicYear, ':cid' => $classId]
    ) ?: [];

    $oneTimeMap = [];
    foreach ($feeRows as $f) {
        if (!isset($oneTimeMap[$f['fee_type']])) {
            $oneTimeMap[$f['fee_type']] = (float)$f['amount'];
        }
    }

    [$yrNum1, $yrNum2] = getAcademicYearRange($academicYear);
    $totalPaidRow = $db->queryOne(
        "SELECT COALESCE(SUM(amount),0) AS paid
           FROM fee_payments
          WHERE student_id = :sid
            AND YEAR(payment_date) BETWEEN :yr1 AND :yr2
            AND status = 'confirmed'",
        [':sid' => $studentId, ':yr1' => $yrNum1, ':yr2' => $yrNum2]
    );
    $totalPaid = (float)($totalPaidRow['paid'] ?? 0);

    ensureInstallments($db, $studentId, $classId, $academicYear);

    $transportAssigned = false;
    try {
        $transportAssigned = $db->queryOne(
            "SELECT id FROM student_transport
              WHERE student_id = :sid AND academic_year = :yr AND status = 'active'",
            [':sid' => $studentId, ':yr' => $academicYear]
        );
    } catch (Throwable $e) {
        $transportAssigned = false;
    }

    $installRows = $db->query(
        "SELECT fee_type, installment_no, amount_due, amount_paid, status, paid_date
           FROM fee_installments
          WHERE student_id = :sid AND academic_year = :yr
          ORDER BY fee_type ASC, installment_no ASC",
        [':sid' => $studentId, ':yr' => $academicYear]
    ) ?: [];

    $installments = [];
    foreach ($installRows as $r) {
        if ($r['fee_type'] === 'Transport' && !$transportAssigned) continue;
        $installments[$r['fee_type']][] = [
            'no'          => (int)$r['installment_no'],
            'amount_due'  => (float)$r['amount_due'],
            'amount_paid' => (float)$r['amount_paid'],
            'status'      => $r['status'],
            'paid_date'   => $r['paid_date'],
        ];
    }

    $oneTimeTotal = array_sum($oneTimeMap);
    $sfTotal = 0; $sfPaid = 0;
    $tpTotal = 0; $tpPaid = 0;
    foreach ($installments as $ft => $slots) {
        foreach ($slots as $s) {
            if ($ft === 'Transport') { $tpTotal += $s['amount_due']; $tpPaid += $s['amount_paid']; }
            else                     { $sfTotal += $s['amount_due']; $sfPaid += $s['amount_paid']; }
        }
    }

    $grandTotal = $oneTimeTotal + $sfTotal;

    $sfAllDone = true;
    if (isset($installments['School Fees'])) {
        foreach ($installments['School Fees'] as $s) {
            if ($s['amount_due'] > 0 && $s['status'] !== 'paid') { $sfAllDone = false; break; }
        }
    } else {
        $sfAllDone = false;
    }

    $oneTimeCovered    = ($totalPaid >= $oneTimeTotal);
    $mandatoryComplete = ($grandTotal > 0) && $oneTimeCovered && $sfAllDone;

    $tpAllDone = true;
    if ($transportAssigned && isset($installments['Transport'])) {
        foreach ($installments['Transport'] as $s) {
            if ($s['amount_due'] > 0 && $s['status'] !== 'paid') { $tpAllDone = false; break; }
        }
    }
    $transportComplete = (bool)$transportAssigned && $tpAllDone;
    $fullyPaid = $mandatoryComplete && (!$transportAssigned || $transportComplete);

    $scholarshipTotal = 0;
    try {
        $schRow = $db->queryOne(
            "SELECT COALESCE(SUM(amount),0) AS total
               FROM fee_payments
              WHERE student_id = :sid
                AND YEAR(payment_date) BETWEEN :yr1 AND :yr2
                AND payment_method LIKE 'Scholarship%'
                AND status = 'confirmed'",
            [':sid' => $studentId, ':yr1' => $yrNum1, ':yr2' => $yrNum2]
        );
        $scholarshipTotal = (float)($schRow['total'] ?? 0);
    } catch (Throwable $e) { }

    return [
        'student_id'          => $studentId,
        'academic_year'       => $academicYear,
        'discount_pct'        => $discount,
        'one_time_fees'       => $oneTimeMap,
        'one_time_total'      => $oneTimeTotal,
        'one_time_paid'       => min($totalPaid, $oneTimeTotal),
        'one_time_owed'       => max(0, $oneTimeTotal - min($totalPaid, $oneTimeTotal)),
        'installments'        => $installments,
        'install_total'       => $sfTotal,
        'install_paid'        => $sfPaid,
        'transport_total'     => $tpTotal,
        'transport_paid'      => $tpPaid,
        'transport_assigned'  => (bool)$transportAssigned,
        'transport_complete'  => $transportComplete,
        'mandatory_complete'  => $mandatoryComplete,
        'scholarship_total'   => $scholarshipTotal,
        'total_paid'          => $totalPaid,
        'grand_total'         => $grandTotal,
        'balance_owed'        => ($grandTotal > 0) ? max(0, $grandTotal - $totalPaid) : 0,
        'fully_paid'          => $fullyPaid,
        'no_fees_configured'  => ($grandTotal == 0),
    ];
}

/* ═══════════════════════════════════════════════
   MY CHILDREN
   Every student linked to the logged-in parent.
═══════════════════════════════════════════════ */
function getMyChildren($db, $userId) {
    $rows = $db->query(
        "SELECT s.id, s.student_name, s.class_id, s.status, c.class_name, c.class_color, p.relationship
           FROM parents p
           JOIN students s ON s.id = p.student_id
           JOIN classes  c ON c.id = s.class_id
          WHERE p.user_id = :uid AND s.status IN ('active', 'graduated')
          ORDER BY (s.status = 'graduated'), s.student_name ASC",
        [':uid' => $userId]
    ) ?: [];
    ok($rows);
}

/* ═══════════════════════════════════════════════
   CHILD PAYMENT STATUS
═══════════════════════════════════════════════ */
function getChildPaymentStatus($db, $userId) {
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$studentId) fail('student_id required');
    if (!studentBelongsToParent($db, $studentId, $userId)) fail('Not authorized for this student', 403);

    $student = $db->queryOne(
        "SELECT s.id, s.student_name, s.class_id, s.status, c.class_name, c.class_color
           FROM students s JOIN classes c ON c.id = s.class_id
          WHERE s.id = :id AND s.status IN ('active', 'graduated')",
        [':id' => $studentId]
    );
    if (!$student) fail('Student not found');

    try {
        $status = buildPaymentStatus($db, $studentId, (int)$student['class_id'], getAcademicYear($db));
    } catch (Throwable $e) {
        ok([
            'student_id'          => $studentId,
            'student_name'        => $student['student_name'],
            'class_name'          => $student['class_name'],
            'class_color'         => $student['class_color'],
            'academic_year'       => getAcademicYear($db),
            'discount_pct'        => 0,
            'one_time_fees'       => [],
            'installments'        => [],
            'total_paid'          => 0,
            'grand_total'         => 0,
            'balance_owed'        => 0,
            'fully_paid'          => false,
            'no_fees_configured'  => true,
            'transport_assigned'  => false,
            'transport_total'     => 0,
            'migration_needed'    => true,
        ]);
        return;
    }
    $status['student_name']   = $student['student_name'];
    $status['class_name']     = $student['class_name'];
    $status['class_color']    = $student['class_color'];
    $status['student_status'] = $student['status'];

    ok($status);
}

/* ═══════════════════════════════════════════════
   CHILD PAYMENTS — history + per-installment allocation
═══════════════════════════════════════════════ */
function getChildPayments($db, $userId) {
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$studentId) fail('student_id required');
    if (!studentBelongsToParent($db, $studentId, $userId)) fail('Not authorized for this student', 403);

    $limit  = min((int)($_GET['limit'] ?? 50), 200);
    $offset = (int)($_GET['offset'] ?? 0);

    $countRow = $db->queryOne(
        "SELECT COUNT(*) AS c FROM fee_payments WHERE student_id = :sid",
        [':sid' => $studentId]
    );
    $total = $countRow ? (int)$countRow['c'] : 0;

    $rows = $db->query(
        "SELECT fp.id, fp.amount, fp.payment_method, fp.payment_date,
                fp.receipt_number, fp.reference_number, fp.status,
                u.full_name AS recorded_by
           FROM fee_payments fp
           LEFT JOIN users u ON u.id = fp.recorded_by
          WHERE fp.student_id = :sid
          ORDER BY fp.payment_date DESC, fp.id DESC
          LIMIT $limit OFFSET $offset",
        [':sid' => $studentId]
    ) ?: [];

    foreach ($rows as &$r) {
        $r['amount'] = (float)$r['amount'];
        try {
            $allocs = $db->query(
                "SELECT fee_type, installment_no, amount_paid
                   FROM fee_installments
                  WHERE payment_id = :pid
                  ORDER BY fee_type ASC, installment_no ASC",
                [':pid' => $r['id']]
            ) ?: [];
            foreach ($allocs as &$a) {
                $a['amount_paid']    = (float)$a['amount_paid'];
                $a['installment_no'] = (int)$a['installment_no'];
            }
            unset($a);
            $r['allocations'] = $allocs;
        } catch (Throwable $e) {
            $r['allocations'] = [];
        }
    }
    unset($r);

    ok(['payments' => $rows, 'total' => $total]);
}

/* ═══════════════════════════════════════════════
   FEE STRUCTURE — class-scoped, read-only
   Frontend expects { academic_year, fees: [{ fee_type, amount,
   installable, installments, is_optional }] } — one row per fee_type,
   class-specific amount preferred over the school-wide default.
═══════════════════════════════════════════════ */
function getParentFeeStructure($db, $userId) {
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$studentId) fail('student_id required');
    if (!studentBelongsToParent($db, $studentId, $userId)) fail('Not authorized for this student', 403);

    $yr = getAcademicYear($db);
    $student = $db->queryOne(
        "SELECT class_id FROM students WHERE id = :id AND status IN ('active', 'graduated')",
        [':id' => $studentId]
    );
    if (!$student) { ok(['academic_year' => $yr, 'fees' => []]); return; }
    $classId = (int)$student['class_id'];

    $rows = $db->query(
        "SELECT fs.fee_type, fs.amount, fs.class_id
           FROM fee_structure fs
          WHERE fs.academic_year = :yr AND (fs.class_id = :cid OR fs.class_id IS NULL)
          ORDER BY fs.class_id DESC",
        [':yr' => $yr, ':cid' => $classId]
    ) ?: [];

    // Class-specific row (class_id = $classId) wins over the school-wide default (class_id IS NULL)
    $byType = [];
    foreach ($rows as $r) {
        if (!isset($byType[$r['fee_type']]) || $r['class_id'] !== null) {
            $byType[$r['fee_type']] = (float)$r['amount'];
        }
    }

    $installableTypes = ['School Fees', 'Transport'];
    $fees = [];
    foreach ($byType as $feeType => $amount) {
        $installable = in_array($feeType, $installableTypes, true);
        $fees[] = [
            'fee_type'     => $feeType,
            'amount'       => $amount,
            'installable'  => $installable,
            'installments' => $installable ? TOTAL_INSTALLMENTS : 1,
            'is_optional'  => ($feeType === 'Transport'),
        ];
    }

    ok(['academic_year' => $yr, 'fees' => $fees]);
}

/* ═══════════════════════════════════════════════
   PAYMENT RECEIPT — printable receipt data
═══════════════════════════════════════════════ */
function getParentPaymentReceipt($db, $userId) {
    $payId = isset($_GET['payment_id']) ? (int)$_GET['payment_id'] : 0;
    if (!$payId) fail('payment_id required');

    $pay = $db->queryOne(
        "SELECT fp.id, fp.student_id, fp.amount, fp.payment_method,
                fp.payment_date, fp.receipt_number, fp.reference_number,
                fp.status, fp.created_at,
                s.student_name, s.class_id,
                c.class_name, c.class_color,
                up.full_name AS parent_name,
                pr.relationship AS parent_relationship,
                ua.full_name  AS recorded_by_name
           FROM fee_payments fp
           JOIN students s  ON s.id  = fp.student_id
           JOIN classes  c  ON c.id  = s.class_id
           LEFT JOIN parents pr ON pr.id = (SELECT id FROM parents WHERE student_id = s.id ORDER BY id LIMIT 1)
           LEFT JOIN users up   ON up.id = pr.user_id
           LEFT JOIN users ua   ON ua.id = fp.recorded_by
          WHERE fp.id = :id",
        [':id' => $payId]
    );
    if (!$pay) fail('Payment not found');
    if (!studentBelongsToParent($db, (int)$pay['student_id'], $userId)) fail('Not authorized for this payment', 403);
    $pay['amount'] = (float)$pay['amount'];

    $linkedInst = [];
    try {
        $linkedInst = $db->query(
            "SELECT fee_type, installment_no, amount_due, amount_paid, status, paid_date
               FROM fee_installments
              WHERE payment_id = :pid
              ORDER BY fee_type ASC, installment_no ASC",
            [':pid' => $payId]
        ) ?: [];
        foreach ($linkedInst as &$r) {
            $r['amount_due']      = (float)$r['amount_due'];
            $r['amount_paid']     = (float)$r['amount_paid'];
            $r['installment_no']  = (int)$r['installment_no'];
        }
        unset($r);
    } catch (Throwable $e) { }

    $status = null;
    try {
        $status = buildPaymentStatus(
            $db,
            (int)$pay['student_id'],
            (int)$pay['class_id'],
            getAcademicYear($db)
        );
    } catch (Throwable $e) { }

    $settings = [];
    try {
        foreach ($db->query("SELECT setting_key, setting_value FROM school_settings") ?? [] as $r) {
            $settings[$r['setting_key']] = $r['setting_value'];
        }
    } catch (Throwable $e) { }

    ok([
        'payment'             => $pay,
        'linked_installments' => $linkedInst,
        'status'              => $status,
        'settings'            => $settings,
        'generated_at'        => date('Y-m-d H:i:s'),
    ]);
}