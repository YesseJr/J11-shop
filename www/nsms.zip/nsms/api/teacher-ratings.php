<?php
/**
 * Teacher ratings & reviews
 *
 * GET  action=public_list     — approved reviews for landing (no auth)
 * GET  action=my_teachers     — teachers a parent may rate (parent)
 * GET  action=my_reviews      — this parent's existing reviews (parent)
 * POST action=submit          — create/update rating 1–5 + comment (parent)
 * POST action=admin_set_visibility — is_approved 0|1 (admin)
 * GET  action=admin_list      — all reviews (admin)
 * GET  action=teacher_feedback — own ratings summary + reviews (teacher)
 */
ob_start();
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

applyApiHeaders();

$db = new Database();
$conn = $db->connect();
if (!$conn) {
    ob_end_clean();
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

function ensureTeacherRatingsTable($db) {
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS teacher_ratings (
                id          INT AUTO_INCREMENT PRIMARY KEY,
                teacher_id  INT NOT NULL,
                rated_by    INT NOT NULL,
                student_id  INT NULL,
                rating      DECIMAL(2,1) NOT NULL,
                comment     TEXT NULL,
                is_approved TINYINT(1) NOT NULL DEFAULT 1,
                created_at  TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at  TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uq_parent_teacher (rated_by, teacher_id),
                KEY idx_teacher (teacher_id),
                KEY idx_approved (is_approved)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Exception $e) {
        error_log('ensureTeacherRatingsTable: ' . $e->getMessage());
    }
    // Older installs may lack columns
    foreach (array(
        "ALTER TABLE teacher_ratings ADD COLUMN is_approved TINYINT(1) NOT NULL DEFAULT 1",
        "ALTER TABLE teacher_ratings ADD COLUMN student_id INT NULL",
        "ALTER TABLE teacher_ratings ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP",
    ) as $sql) {
        try { $db->execute($sql); } catch (Exception $e) { /* exists */ }
    }
}

ensureTeacherRatingsTable($db);

$action = isset($_GET['action']) ? trim($_GET['action']) : '';
$publicActions = array('public_list');

if (!in_array($action, $publicActions, true)) {
    // parent or admin
    $role = function_exists('getCurrentUserRole') ? getCurrentUserRole() : (isset($_SESSION['role']) ? $_SESSION['role'] : '');
    if ($role !== 'parent' && $role !== 'admin') {
        try {
            requireAuth();
            $role = getCurrentUserRole();
        } catch (Exception $e) {
            ob_end_clean();
            echo json_encode(['success' => false, 'error' => 'Not authenticated']);
            exit;
        }
    }
    if ($action === 'admin_list' || $action === 'admin_set_visibility') {
        if ($role !== 'admin') {
            ob_end_clean();
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Admin only']);
            exit;
        }
    } elseif ($action === 'reply_homework_comment' || $action === 'teacher_feedback') {
        if ($role !== 'teacher' && $role !== 'admin') {
            ob_end_clean();
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Teachers only']);
            exit;
        }
    } else {
        if ($role !== 'parent' && $role !== 'admin') {
            ob_end_clean();
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Parents only']);
            exit;
        }
    }
}

try {
    switch ($action) {
        case 'public_list':
            publicList($db);
            break;
        case 'my_teachers':
            myTeachers($db);
            break;
        case 'my_reviews':
            myReviews($db);
            break;
        case 'submit':
            submitReview($db);
            break;
        case 'admin_list':
            adminList($db);
            break;
        case 'admin_set_visibility':
            adminSetVisibility($db);
            break;
        case 'reply_homework_comment':
            replyHomeworkComment($db);
            break;
        case 'teacher_feedback':
            teacherFeedback($db);
            break;
        default:
            ob_end_clean();
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
} catch (Exception $e) {
    error_log('teacher-ratings: ' . $e->getMessage());
    ob_end_clean();
    echo json_encode(['success' => false, 'error' => 'Server error']);
}

function publicList($db) {
    $limit = isset($_GET['limit']) ? max(1, min(50, (int)$_GET['limit'])) : 12;
    $rows = $db->query(
        "SELECT tr.id, tr.rating, tr.comment, tr.created_at,
                t.full_name AS teacher_name, t.photo_url AS teacher_photo,
                p.full_name AS parent_name
           FROM teacher_ratings tr
           JOIN users t ON t.id = tr.teacher_id AND t.role = 'teacher'
           JOIN users p ON p.id = tr.rated_by
          WHERE tr.is_approved = 1
            AND tr.comment IS NOT NULL AND TRIM(tr.comment) != ''
          ORDER BY tr.created_at DESC
          LIMIT {$limit}"
    ) ?: [];

    $out = array();
    foreach ($rows as $r) {
        $pn = isset($r['parent_name']) ? $r['parent_name'] : 'Parent';
        $parts = preg_split('/\s+/', trim($pn));
        $display = $parts[0];
        if (count($parts) > 1) {
            $display .= ' ' . strtoupper(substr($parts[count($parts) - 1], 0, 1)) . '.';
        }
        $out[] = array(
            'id' => (int)$r['id'],
            'rating' => (float)$r['rating'],
            'comment' => $r['comment'],
            'created_at' => $r['created_at'],
            'teacher_name' => $r['teacher_name'],
            'teacher_photo' => $r['teacher_photo'],
            'parent_display' => $display,
        );
    }

    // Aggregate per teacher for optional summary
    $summary = $db->query(
        "SELECT t.id, t.full_name, t.photo_url,
                ROUND(AVG(tr.rating), 1) AS avg_rating,
                COUNT(tr.id) AS rating_count
           FROM users t
           INNER JOIN teacher_ratings tr ON tr.teacher_id = t.id AND tr.is_approved = 1
          WHERE t.role = 'teacher' AND t.status = 'active'
          GROUP BY t.id, t.full_name, t.photo_url
         HAVING rating_count > 0
          ORDER BY avg_rating DESC, rating_count DESC
          LIMIT 8"
    ) ?: [];

    ob_end_clean();
    echo json_encode(array(
        'success' => true,
        'data' => array(
            'reviews' => $out,
            'teachers' => $summary,
        ),
    ));
}

function parentMayRateTeacher($db, $parentUserId, $teacherId) {
    $row = $db->queryOne(
        "SELECT u.id
           FROM parents p
           JOIN students s ON s.id = p.student_id AND s.status = 'active'
           JOIN classes c ON c.id = s.class_id AND c.teacher_id = :tid
           JOIN users u ON u.id = c.teacher_id AND u.role = 'teacher' AND u.status = 'active'
          WHERE p.user_id = :uid
          LIMIT 1",
        array(':uid' => (int)$parentUserId, ':tid' => (int)$teacherId)
    );
    return !empty($row);
}

function myTeachers($db) {
    $uid = (int)getCurrentUserId();
    // Only teachers assigned as class teacher for this parent's active children
    $teachers = $db->query(
        "SELECT DISTINCT u.id, u.full_name, u.photo_url,
                GROUP_CONCAT(DISTINCT c.class_name ORDER BY c.class_name SEPARATOR ', ') AS class_name
           FROM parents p
           JOIN students s ON s.id = p.student_id AND s.status = 'active'
           JOIN classes c ON c.id = s.class_id AND c.teacher_id IS NOT NULL
           JOIN users u ON u.id = c.teacher_id AND u.role = 'teacher' AND u.status = 'active'
          WHERE p.user_id = :uid
          GROUP BY u.id, u.full_name, u.photo_url
          ORDER BY u.full_name ASC",
        array(':uid' => $uid)
    ) ?: [];

    $mine = $db->query(
        "SELECT teacher_id, rating, comment, is_approved, updated_at, created_at
           FROM teacher_ratings WHERE rated_by = :uid",
        array(':uid' => $uid)
    ) ?: [];
    $mineMap = array();
    foreach ($mine as $m) {
        $mineMap[(int)$m['teacher_id']] = $m;
    }

    foreach ($teachers as &$trow) {
        $tid = (int)$trow['id'];
        $trow['my_review'] = isset($mineMap[$tid]) ? $mineMap[$tid] : null;
        $agg = $db->queryOne(
            "SELECT ROUND(AVG(rating),1) AS avg_rating, COUNT(*) AS rating_count
               FROM teacher_ratings WHERE teacher_id = :tid AND is_approved = 1",
            array(':tid' => $tid)
        );
        $trow['avg_rating'] = $agg && $agg['avg_rating'] !== null ? (float)$agg['avg_rating'] : null;
        $trow['rating_count'] = $agg ? (int)$agg['rating_count'] : 0;
    }
    unset($trow);

    ob_end_clean();
    echo json_encode(array('success' => true, 'data' => $teachers));
}

function myReviews($db) {
    $uid = (int)getCurrentUserId();
    $rows = $db->query(
        "SELECT tr.*, u.full_name AS teacher_name
           FROM teacher_ratings tr
           JOIN users u ON u.id = tr.teacher_id
          WHERE tr.rated_by = :uid
          ORDER BY tr.updated_at DESC, tr.created_at DESC",
        array(':uid' => $uid)
    ) ?: [];
    ob_end_clean();
    echo json_encode(array('success' => true, 'data' => $rows));
}

function submitReview($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Method not allowed'));
        return;
    }
    if (function_exists('enforceCsrf')) {
        enforceCsrf();
    }
    if (function_exists('nsmsRateLimit')) {
        $ip = function_exists('nsmsClientIp') ? nsmsClientIp() : '0.0.0.0';
        if (!nsmsRateLimit('teacher_review:' . getCurrentUserId() . ':' . $ip, 20, 3600)) {
            ob_end_clean();
            http_response_code(429);
            echo json_encode(array('success' => false, 'error' => 'Too many review submissions. Try again later.'));
            return;
        }
    }

    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) $data = $_POST;

    $teacherId = isset($data['teacher_id']) ? (int)$data['teacher_id'] : 0;
    $rating = isset($data['rating']) ? (float)$data['rating'] : 0;
    $comment = isset($data['comment']) ? trim($data['comment']) : '';
    $studentId = isset($data['student_id']) ? (int)$data['student_id'] : null;

    if ($teacherId <= 0) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'teacher_id required'));
        return;
    }
    if ($rating < 1 || $rating > 5) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Rating must be between 1 and 5'));
        return;
    }
    // Half stars allowed: 1, 1.5, … 5
    $rating = round($rating * 2) / 2;
    if (strlen($comment) < 10) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Please write a short review (at least 10 characters).'));
        return;
    }
    if (strlen($comment) > 1000) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Review is too long (max 1000 characters).'));
        return;
    }

    $teacher = $db->queryOne(
        "SELECT id, full_name FROM users WHERE id = :id AND role = 'teacher' AND status = 'active'",
        array(':id' => $teacherId)
    );
    if (!$teacher) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Teacher not found'));
        return;
    }

    $uid = (int)getCurrentUserId();
    // Soft ownership: parent should have at least one linked student
    $hasChild = $db->queryOne(
        "SELECT id FROM parents WHERE user_id = :uid LIMIT 1",
        array(':uid' => $uid)
    );
    if (!$hasChild) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'No student linked to your account'));
        return;
    }
    if (!parentMayRateTeacher($db, $uid, $teacherId)) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'You can only rate the class teacher of your child\'s class.'));
        return;
    }

    $existing = $db->queryOne(
        "SELECT id FROM teacher_ratings WHERE rated_by = :uid AND teacher_id = :tid",
        array(':uid' => $uid, ':tid' => $teacherId)
    );

    if ($existing) {
        $db->execute(
            "UPDATE teacher_ratings
                SET rating = :r, comment = :c, student_id = :sid, is_approved = 1, updated_at = NOW()
              WHERE id = :id",
            array(
                ':r' => $rating,
                ':c' => $comment,
                ':sid' => $studentId ?: null,
                ':id' => (int)$existing['id'],
            )
        );
        $id = (int)$existing['id'];
        $msg = 'Review updated. Thank you!';
    } else {
        $id = $db->execute(
            "INSERT INTO teacher_ratings (teacher_id, rated_by, student_id, rating, comment, is_approved, created_at)
             VALUES (:tid, :uid, :sid, :r, :c, 1, NOW())",
            array(
                ':tid' => $teacherId,
                ':uid' => $uid,
                ':sid' => $studentId ?: null,
                ':r' => $rating,
                ':c' => $comment,
            )
        );
        $msg = 'Review submitted. It is now visible on the school website.';
    }

    if (function_exists('logActivity')) {
        logActivity($db, $uid, 'TEACHER_REVIEW', 'Rated teacher #' . $teacherId . ' with ' . $rating);
    }

    ob_end_clean();
    echo json_encode(array(
        'success' => true,
        'message' => $msg,
        'data' => array('id' => $id, 'rating' => $rating),
    ));
}


function teacherFeedback($db) {
    $role = function_exists('getCurrentUserRole') ? getCurrentUserRole() : '';
    $uid = (int)getCurrentUserId();
    // Admin may pass teacher_id to inspect
    if ($role === 'admin' && isset($_GET['teacher_id']) && (int)$_GET['teacher_id'] > 0) {
        $uid = (int)$_GET['teacher_id'];
    } elseif ($role !== 'teacher' && $role !== 'admin') {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Teachers only'));
        return;
    }

    $teacher = $db->queryOne(
        "SELECT id, full_name, photo_url, status FROM users WHERE id = :id AND role = 'teacher'",
        array(':id' => $uid)
    );
    if (!$teacher) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Teacher not found'));
        return;
    }

    $agg = $db->queryOne(
        "SELECT ROUND(AVG(rating), 1) AS avg_rating,
                COUNT(*) AS total_reviews,
                SUM(CASE WHEN is_approved = 1 THEN 1 ELSE 0 END) AS public_reviews,
                SUM(CASE WHEN rating >= 4 THEN 1 ELSE 0 END) AS positive_reviews,
                SUM(CASE WHEN rating <= 2 THEN 1 ELSE 0 END) AS low_reviews
           FROM teacher_ratings
          WHERE teacher_id = :tid",
        array(':tid' => $uid)
    );

    $distRows = $db->query(
        "SELECT FLOOR(rating) AS star, COUNT(*) AS cnt
           FROM teacher_ratings
          WHERE teacher_id = :tid AND is_approved = 1
          GROUP BY FLOOR(rating)
          ORDER BY star DESC",
        array(':tid' => $uid)
    ) ?: [];
    $distribution = array(5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0);
    foreach ($distRows as $dr) {
        $s = (int)$dr['star'];
        if ($s >= 1 && $s <= 5) $distribution[$s] = (int)$dr['cnt'];
    }

    $reviews = $db->query(
        "SELECT tr.id, tr.rating, tr.comment, tr.is_approved, tr.created_at, tr.updated_at,
                p.full_name AS parent_name
           FROM teacher_ratings tr
           JOIN users p ON p.id = tr.rated_by
          WHERE tr.teacher_id = :tid
          ORDER BY tr.created_at DESC
          LIMIT 100",
        array(':tid' => $uid)
    ) ?: [];

    $out = array();
    foreach ($reviews as $r) {
        $pn = isset($r['parent_name']) ? $r['parent_name'] : 'Parent';
        $parts = preg_split('/\s+/', trim($pn));
        $display = $parts[0];
        if (count($parts) > 1) {
            $display .= ' ' . strtoupper(substr($parts[count($parts) - 1], 0, 1)) . '.';
        }
        $out[] = array(
            'id' => (int)$r['id'],
            'rating' => (float)$r['rating'],
            'comment' => $r['comment'],
            'is_approved' => (int)$r['is_approved'],
            'created_at' => $r['created_at'],
            'updated_at' => $r['updated_at'],
            'parent_display' => $display,
        );
    }

    $class = $db->queryOne(
        "SELECT class_name FROM classes WHERE teacher_id = :tid LIMIT 1",
        array(':tid' => $uid)
    );

    ob_end_clean();
    echo json_encode(array(
        'success' => true,
        'data' => array(
            'teacher' => array(
                'id' => (int)$teacher['id'],
                'full_name' => $teacher['full_name'],
                'photo_url' => $teacher['photo_url'],
                'class_name' => $class ? $class['class_name'] : null,
            ),
            'summary' => array(
                'avg_rating' => $agg && $agg['avg_rating'] !== null ? (float)$agg['avg_rating'] : null,
                'total_reviews' => $agg ? (int)$agg['total_reviews'] : 0,
                'public_reviews' => $agg ? (int)$agg['public_reviews'] : 0,
                'positive_reviews' => $agg ? (int)$agg['positive_reviews'] : 0,
                'low_reviews' => $agg ? (int)$agg['low_reviews'] : 0,
            ),
            'distribution' => $distribution,
            'reviews' => $out,
            'homework_comments' => nsmsTeacherHomeworkComments($db, $uid),
        ),
    ));
}

/**
 * Homework parent comments for this teacher's assignments (+ optional teacher reply).
 */
function nsmsEnsureHomeworkCommentReplies($db) {
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS homework_comments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                homework_id INT NOT NULL,
                student_id INT NOT NULL,
                parent_id INT NOT NULL,
                comment TEXT NOT NULL,
                teacher_reply TEXT NULL,
                replied_at DATETIME NULL,
                replied_by INT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_hc_hw (homework_id),
                KEY idx_hc_parent (parent_id)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) {}
    try {
        $col = $db->query("SHOW COLUMNS FROM homework_comments LIKE 'teacher_reply'");
        if (empty($col)) {
            $db->execute("ALTER TABLE homework_comments ADD COLUMN teacher_reply TEXT NULL");
            $db->execute("ALTER TABLE homework_comments ADD COLUMN replied_at DATETIME NULL");
            $db->execute("ALTER TABLE homework_comments ADD COLUMN replied_by INT NULL");
        }
    } catch (Exception $e) {}
}

function nsmsTeacherHomeworkComments($db, $teacherId) {
    nsmsEnsureHomeworkCommentReplies($db);
    try {
        $rows = $db->query(
            "SELECT c.id, c.comment, c.created_at, c.teacher_reply, c.replied_at,
                    c.homework_id, c.student_id, c.parent_id,
                    h.subject AS homework_subject, h.due_date,
                    u.full_name AS parent_name,
                    s.student_name
               FROM homework_comments c
               JOIN homework h ON h.id = c.homework_id AND h.posted_by = :tid
               JOIN users u ON u.id = c.parent_id
               JOIN students s ON s.id = c.student_id
              ORDER BY c.created_at DESC
              LIMIT 100",
            array(':tid' => (int)$teacherId)
        ) ?: array();
    } catch (Exception $e) {
        error_log('nsmsTeacherHomeworkComments: ' . $e->getMessage());
        return array();
    }
    $out = array();
    foreach ($rows as $r) {
        $pn = isset($r['parent_name']) ? $r['parent_name'] : 'Parent';
        $parts = preg_split('/\s+/', trim($pn));
        $display = $parts[0];
        if (count($parts) > 1) {
            $display .= ' ' . strtoupper(substr($parts[count($parts) - 1], 0, 1)) . '.';
        }
        $out[] = array(
            'id' => (int)$r['id'],
            'type' => 'homework',
            'comment' => $r['comment'],
            'teacher_reply' => $r['teacher_reply'],
            'replied_at' => $r['replied_at'],
            'created_at' => $r['created_at'],
            'homework_id' => (int)$r['homework_id'],
            'homework_subject' => $r['homework_subject'],
            'due_date' => $r['due_date'],
            'student_name' => $r['student_name'],
            'parent_display' => $display,
            'parent_id' => (int)$r['parent_id'],
        );
    }
    return $out;
}

function replyHomeworkComment($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Method not allowed'));
        return;
    }
    if (function_exists('enforceCsrf')) {
        try { enforceCsrf(); } catch (Exception $e) {}
    }
    $uid = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
    if ($role !== 'teacher' && $role !== 'admin') {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Teachers only'));
        return;
    }
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) $data = $_POST;
    $id = isset($data['comment_id']) ? (int)$data['comment_id'] : (isset($data['id']) ? (int)$data['id'] : 0);
    $reply = isset($data['reply']) ? trim(strip_tags((string)$data['reply'])) : '';
    if ($id < 1) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'comment_id required'));
        return;
    }
    if ($reply === '' || mb_strlen($reply) < 2) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Please write a reply (at least 2 characters)'));
        return;
    }
    if (mb_strlen($reply) > 2000) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Reply is too long'));
        return;
    }
    nsmsEnsureHomeworkCommentReplies($db);
    $row = $db->queryOne(
        "SELECT c.*, h.posted_by, h.subject, s.student_name
           FROM homework_comments c
           JOIN homework h ON h.id = c.homework_id
           JOIN students s ON s.id = c.student_id
          WHERE c.id = :id LIMIT 1",
        array(':id' => $id)
    );
    if (!$row) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Comment not found'));
        return;
    }
    if ($role === 'teacher' && (int)$row['posted_by'] !== $uid) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Not authorized for this comment'));
        return;
    }
    $ok = $db->execute(
        "UPDATE homework_comments
            SET teacher_reply = :r, replied_at = NOW(), replied_by = :uid
          WHERE id = :id",
        array(':r' => $reply, ':uid' => $uid, ':id' => $id)
    );
    if ($ok === false) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Failed to save reply'));
        return;
    }

    // Notify parent (in-app + email)
    $parentId = (int)$row['parent_id'];
    $teacherName = 'Your teacher';
    $trow = $db->queryOne("SELECT full_name FROM users WHERE id = :id", array(':id' => $uid));
    if ($trow && !empty($trow['full_name'])) $teacherName = $trow['full_name'];

    $snippet = mb_strlen($reply) > 140 ? mb_substr($reply, 0, 137) . '...' : $reply;
    $title = $teacherName . ' replied on ' . $row['subject'];
    $msg = 'Regarding homework for ' . $row['student_name'] . ': "' . $snippet . '" — open Daily Diary to read the full reply.';

    try {
        // Prefer reference_key when available
        try {
            $db->execute(
                "INSERT INTO notifications (user_id, type, title, message, is_read, reference_key, created_at)
                 VALUES (:uid, 'homework_reply', :t, :m, 0, :ref, NOW())",
                array(
                    ':uid' => $parentId,
                    ':t' => $title,
                    ':m' => $msg,
                    ':ref' => 'hw_reply_' . $id,
                )
            );
        } catch (Exception $e) {
            $db->execute(
                "INSERT INTO notifications (user_id, type, title, message, is_read, created_at)
                 VALUES (:uid, 'homework_reply', :t, :m, 0, NOW())",
                array(':uid' => $parentId, ':t' => $title, ':m' => $msg)
            );
        }
    } catch (Exception $e) {
        error_log('reply notify parent: ' . $e->getMessage());
    }

    // Best-effort email
    try {
        $parentUser = $db->queryOne(
            "SELECT email, full_name FROM users WHERE id = :id LIMIT 1",
            array(':id' => $parentId)
        );
        if ($parentUser && !empty($parentUser['email']) && function_exists('sendEmail')) {
            $schoolRow = $db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key = 'school_name' LIMIT 1");
            $schoolName = ($schoolRow && !empty($schoolRow['setting_value'])) ? $schoolRow['setting_value'] : 'School';
            $diaryUrl = defined('SITE_URL') ? rtrim(SITE_URL, '/') . '/public/parent/daily-diary.html' : '';
            $subject = $schoolName . ' — Teacher reply on ' . $row['subject'];
            $body =
                '<p>Dear ' . htmlspecialchars($parentUser['full_name'] ?: 'Parent') . ',</p>' .
                '<p><strong>' . htmlspecialchars($teacherName) . '</strong> replied to your feedback on ' .
                '<strong>' . htmlspecialchars($row['subject']) . '</strong> homework for ' .
                '<strong>' . htmlspecialchars($row['student_name']) . '</strong>.</p>' .
                '<blockquote style="border-left:3px solid #1D5C42;padding:8px 14px;margin:16px 0;background:#F8FAFC;color:#334155;">' .
                nl2br(htmlspecialchars($reply)) .
                '</blockquote>' .
                ($diaryUrl
                    ? '<p><a href="' . htmlspecialchars($diaryUrl) . '" style="display:inline-block;padding:10px 16px;background:#1D5C42;color:#fff;text-decoration:none;border-radius:8px;font-weight:600;">Open Daily Diary</a></p>'
                    : '<p>Log in to the parent portal and open <strong>Daily Diary</strong> to continue the conversation.</p>') .
                '<p style="color:#888;font-size:12px;">This is an automated message from ' . htmlspecialchars($schoolName) . '.</p>';
            sendEmail($parentUser['email'], $subject, $body);
        }
    } catch (Exception $e) {
        error_log('reply email parent: ' . $e->getMessage());
    }

    ob_end_clean();
    echo json_encode(array(
        'success' => true,
        'message' => 'Reply sent to parent',
        'data' => array(
            'id' => $id,
            'teacher_reply' => $reply,
            'replied_at' => date('Y-m-d H:i:s'),
        ),
    ));
}

function adminList($db) {
    $rows = $db->query(
        "SELECT tr.*, t.full_name AS teacher_name, p.full_name AS parent_name
           FROM teacher_ratings tr
           JOIN users t ON t.id = tr.teacher_id
           JOIN users p ON p.id = tr.rated_by
          ORDER BY tr.created_at DESC
          LIMIT 200"
    ) ?: [];
    ob_end_clean();
    echo json_encode(array('success' => true, 'data' => $rows));
}

function adminSetVisibility($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'Method not allowed'));
        return;
    }
    if (function_exists('enforceCsrf')) enforceCsrf();
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) $data = $_POST;
    $id = isset($data['id']) ? (int)$data['id'] : 0;
    $approved = !empty($data['is_approved']) ? 1 : 0;
    if ($id <= 0) {
        ob_end_clean();
        echo json_encode(array('success' => false, 'error' => 'id required'));
        return;
    }
    $db->execute(
        "UPDATE teacher_ratings SET is_approved = :a WHERE id = :id",
        array(':a' => $approved, ':id' => $id)
    );
    ob_end_clean();
    echo json_encode(array('success' => true, 'message' => $approved ? 'Review visible' : 'Review hidden'));
}
