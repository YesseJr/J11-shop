<?php
/**
 * Teacher Messages API
 * /nsms/api/teacher-messages.php
 * PHP 7.2 compatible.
 *
 * Schema facts:
 *   messages:       id, sender_id, recipient_id, subject, message, is_read, read_at, has_file, created_at
 *   notifications:  id, user_id, title, message, type, is_read, read_at, created_at
 *   users:          id, full_name, email, phone, photo_url, role
 *   parents:        user_id, student_id, relationship
 *   students:       id, student_name, class_id
 *   classes:        id, teacher_id  (teacher's class resolved here)
 *   typing_status:  user_id, contact_id, updated_at          [run db-migration.sql]
 *   user_presence:  user_id, last_seen                        [run db-migration.sql]
 *   message_files:  id, message_id, original_name, stored_name, mime_type, file_size, created_at  [run db-migration.sql]
 *
 * Actions:
 *   GET  ?action=conversations                          — conversation list (grouped by contact pair)
 *   GET  ?action=thread&contact_id=X                   — full message thread with user X
 *   GET  ?action=thread_updates&contact_id=X&since_id=N— only messages with id > N (efficient poll)
 *   GET  ?action=contacts                              — people teacher can message (parents + admins)
 *   GET  ?action=typing_status&contact_id=X            — is contact X typing to me right now?
 *   POST ?action=send                                  — send a text message (JSON body)
 *   POST ?action=send_file                             — send message + file (multipart/form-data)
 *   POST ?action=mark_read&contact_id=X                — mark all messages from X as read
 *   POST ?action=set_typing&contact_id=X               — heartbeat while composing
 *   POST ?action=heartbeat                             — update own presence timestamp
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

if (function_exists('applyApiHeaders')) { applyApiHeaders(); }


requireRole(['admin', 'teacher']);

$db   = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

$action = isset($_GET['action']) ? $_GET['action'] : '';

/* Bump own presence on every request */
_teacherUpdatePresence($db);

switch ($action) {
    case 'conversations':  getConversations($db);  break;
    case 'thread':         getThread($db);          break;
    case 'thread_updates': getThreadUpdates($db);   break;
    case 'contacts':       getContacts($db);        break;
    case 'typing_status':  getTypingStatus($db);    break;
    case 'send':           sendMessage($db);        break;
    case 'send_file':      sendFile($db);           break;
    case 'mark_read':      markRead($db);           break;
    case 'set_typing':     setTyping($db);          break;
    case 'heartbeat':      doHeartbeat($db);        break;
    default: ob_end_clean(); errorResponse('Invalid action');
}

/* ─────────────────────────────────────────
   HELPER: current user id from session
───────────────────────────────────────── */
function myId() {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
}

/* ─────────────────────────────────────────
   HELPER: resolve class_id for teacher
───────────────────────────────────────── */
function resolveClassId($db) {
    if (isset($_GET['class_id']) && (int)$_GET['class_id'] > 0) {
        return (int)$_GET['class_id'];
    }
    $uid = myId();
    if (!$uid) return null;
    $row = $db->queryOne(
        "SELECT id FROM classes WHERE teacher_id = :uid LIMIT 1",
        [':uid' => $uid]
    );
    return $row ? (int)$row['id'] : null;
}

/* ─────────────────────────────────────────
   HELPER: update own presence timestamp
───────────────────────────────────────── */
function _teacherUpdatePresence($db) {
    $me = myId();
    if (!$me) return;
    try {
        $db->execute(
            "INSERT INTO user_presence (user_id, last_seen)
             VALUES (:uid, NOW())
             ON DUPLICATE KEY UPDATE last_seen = NOW()",
            [':uid' => $me]
        );
    } catch (\Exception $e) { /* table not yet migrated — silently skip */ }
}

/* ─────────────────────────────────────────
   HELPER: attach file rows to an array of messages
───────────────────────────────────────── */
function _teacherAttachFiles($db, array &$messages) {
    if (empty($messages)) return;
    $ids = array_filter(array_column($messages, 'id'));
    if (empty($ids)) return;
    $ph = implode(',', array_fill(0, count($ids), '?'));
    try {
        $files = $db->query(
            "SELECT message_id, id AS file_id, original_name, stored_name, mime_type, file_size
             FROM message_files WHERE message_id IN ($ph)",
            array_values($ids)
        ) ?: [];
    } catch (\Exception $e) { $files = []; }

    $fmap = [];
    foreach ($files as $f) {
        $mid = $f['message_id'];
        if (!isset($fmap[$mid])) $fmap[$mid] = [];
        $fmap[$mid][] = [
            'file_id'       => $f['file_id'],
            'original_name' => $f['original_name'],
            'mime_type'     => $f['mime_type'],
            'file_size'     => (int)$f['file_size'],
            'url'           => '/nsms/uploads/messages/' . $f['stored_name'],
        ];
    }
    foreach ($messages as &$m) {
        $m['files'] = isset($fmap[$m['id']]) ? $fmap[$m['id']] : [];
    }
    unset($m);
}

/* ─────────────────────────────────────────
   GET CONVERSATIONS
   Groups messages by the contact on the other side.
   Returns latest message per contact, unread count,
   contact details, and online status.
───────────────────────────────────────── */
function getConversations($db) {
    $me = myId();
    if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }

    $rows = $db->query(
        "SELECT
             contact_id,
             MAX(created_at)  AS last_at,
             SUM(is_unread)   AS unread_count
         FROM (
             SELECT
                 CASE WHEN sender_id = :me1 THEN recipient_id ELSE sender_id END AS contact_id,
                 created_at,
                 CASE WHEN recipient_id = :me2 AND is_read = 0 THEN 1 ELSE 0 END AS is_unread,
                 message  AS last_msg,
                 subject  AS last_subject
             FROM messages
             WHERE sender_id = :me3 OR recipient_id = :me4
         ) sub
         GROUP BY contact_id
         ORDER BY last_at DESC",
        [':me1' => $me, ':me2' => $me, ':me3' => $me, ':me4' => $me]
    ) ?: [];

    if (empty($rows)) { ob_end_clean(); successResponse([]); return; }

    $contactIds   = array_column($rows, 'contact_id');
    $placeholders = implode(',', array_fill(0, count($contactIds), '?'));

    /* Contact user details */
    $userRows = $db->query(
        "SELECT id, full_name, photo_url, role
         FROM users
         WHERE id IN ($placeholders)",
        array_values($contactIds)
    ) ?: [];

    $userMap = [];
    foreach ($userRows as $u) { $userMap[$u['id']] = $u; }

    /* Online status map */
    $onlineMap = [];
    try {
        $presRows = $db->query(
            "SELECT user_id FROM user_presence
             WHERE user_id IN ($placeholders) AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)",
            array_values($contactIds)
        ) ?: [];
        foreach ($presRows as $p) { $onlineMap[$p['user_id']] = true; }
    } catch (\Exception $e) {}

    $out = [];
    foreach ($rows as $row) {
        $cid     = (int)$row['contact_id'];
        $contact = isset($userMap[$cid]) ? $userMap[$cid] : null;
        if (!$contact) continue;

        /* Latest message for accurate preview */
        $latest = $db->queryOne(
            "SELECT message, subject, has_file FROM messages
             WHERE (sender_id = :me AND recipient_id = :cid)
                OR (sender_id = :cid2 AND recipient_id = :me2)
             ORDER BY created_at DESC LIMIT 1",
            [':me' => $me, ':cid' => $cid, ':cid2' => $cid, ':me2' => $me]
        );

        /* Student name for parents */
        $studentName = null;
        if ($contact['role'] === 'parent') {
            $stuRow = $db->queryOne(
                "SELECT s.student_name FROM parents p
                 JOIN students s ON s.id = p.student_id
                 WHERE p.user_id = :uid LIMIT 1",
                [':uid' => $cid]
            );
            if ($stuRow) $studentName = $stuRow['student_name'];
        }

        $preview = '';
        if ($latest) {
            $preview = (!empty($latest['has_file']) && !$latest['message'])
                ? '📎 Attachment'
                : mb_substr($latest['message'], 0, 80);
        }

        $out[] = [
            'contact_id'    => $cid,
            'contact_name'  => $contact['full_name'],
            'contact_photo' => $contact['photo_url'],
            'contact_role'  => $contact['role'] === 'admin' ? 'Administrator' :
                               ($studentName ? 'Parent of ' . $studentName : 'Parent'),
            'student_name'  => $studentName,
            'last_message'  => $preview,
            'subject'       => $latest ? $latest['subject'] : '',
            'last_at'       => $row['last_at'],
            'unread_count'  => (int)$row['unread_count'],
            'is_online'     => isset($onlineMap[$cid]),
        ];
    }

    ob_end_clean();
    successResponse($out);
}

/* ─────────────────────────────────────────
   GET THREAD — all messages between me and contact X
   Returns: { messages: [...], contact_online: bool }
───────────────────────────────────────── */
function getThread($db) {
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;

    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    $rows = $db->query(
        "SELECT id, sender_id, recipient_id, subject, message, is_read, read_at, has_file, created_at
         FROM   messages
         WHERE  (sender_id = :me  AND recipient_id = :cid)
             OR (sender_id = :cid2 AND recipient_id = :me2)
         ORDER  BY created_at ASC",
        [':me' => $me, ':cid' => $contactId, ':cid2' => $contactId, ':me2' => $me]
    ) ?: [];

    _teacherAttachFiles($db, $rows);

    /* Contact online status */
    $isOnline = false;
    try {
        $prow = $db->queryOne(
            "SELECT 1 FROM user_presence
             WHERE user_id = :uid AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)",
            [':uid' => $contactId]
        );
        $isOnline = (bool)$prow;
    } catch (\Exception $e) {}

    ob_end_clean();
    successResponse(['messages' => $rows, 'contact_online' => $isOnline]);
}

/* ─────────────────────────────────────────
   GET THREAD UPDATES — only messages with id > since_id
   Returns: { new_messages: [...], contact_online: bool, contact_typing: bool }
───────────────────────────────────────── */
function getThreadUpdates($db) {
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    $sinceId   = isset($_GET['since_id'])   ? (int)$_GET['since_id']   : 0;

    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    $rows = $db->query(
        "SELECT id, sender_id, recipient_id, subject, message, is_read, read_at, has_file, created_at
         FROM   messages
         WHERE  ((sender_id = :me AND recipient_id = :cid) OR (sender_id = :cid2 AND recipient_id = :me2))
           AND  id > :sid
         ORDER  BY created_at ASC",
        [':me' => $me, ':cid' => $contactId, ':cid2' => $contactId, ':me2' => $me, ':sid' => $sinceId]
    ) ?: [];

    _teacherAttachFiles($db, $rows);

    $isOnline = false; $isTyping = false;
    try {
        $prow = $db->queryOne(
            "SELECT 1 FROM user_presence
             WHERE user_id = :uid AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)",
            [':uid' => $contactId]
        );
        $isOnline = (bool)$prow;

        $trow = $db->queryOne(
            "SELECT 1 FROM typing_status
             WHERE user_id = :uid AND contact_id = :me
               AND updated_at >= DATE_SUB(NOW(), INTERVAL 5 SECOND)",
            [':uid' => $contactId, ':me' => $me]
        );
        $isTyping = (bool)$trow;
    } catch (\Exception $e) {}

    ob_end_clean();
    successResponse(['new_messages' => $rows, 'contact_online' => $isOnline, 'contact_typing' => $isTyping]);
}

/* ─────────────────────────────────────────
   GET CONTACTS — parents of teacher's class + admins
───────────────────────────────────────── */
function getContacts($db) {
    $me      = myId();
    $classId = resolveClassId($db);

    $out = [];

    /* Admins */
    $admins = $db->query(
        "SELECT id, full_name, photo_url, 'admin' AS role, NULL AS student_name
         FROM users
         WHERE role = 'admin' AND status = 'active' AND id != :me",
        [':me' => $me]
    ) ?: [];

    foreach ($admins as $a) {
        $out[] = [
            'id'           => (int)$a['id'],
            'full_name'    => $a['full_name'],
            'photo_url'    => $a['photo_url'],
            'role'         => 'admin',
            'student_name' => null,
        ];
    }

    /* Parents of students in teacher's class */
    if ($classId) {
        $parents = $db->query(
            "SELECT DISTINCT u.id, u.full_name, u.photo_url, 'parent' AS role, s.student_name
             FROM   users u
             JOIN   parents p  ON p.user_id    = u.id
             JOIN   students s ON s.id          = p.student_id
             WHERE  s.class_id = :cid
               AND  u.status   = 'active'
             ORDER  BY u.full_name ASC",
            [':cid' => $classId]
        ) ?: [];

        foreach ($parents as $p) {
            $out[] = [
                'id'           => (int)$p['id'],
                'full_name'    => $p['full_name'],
                'photo_url'    => $p['photo_url'],
                'role'         => 'parent',
                'student_name' => $p['student_name'],
            ];
        }
    }

    ob_end_clean();
    successResponse($out);
}

/* ─────────────────────────────────────────
   GET TYPING STATUS — is contact X typing to me right now?
───────────────────────────────────────── */
function getTypingStatus($db) {
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    $isTyping = false;
    try {
        $row = $db->queryOne(
            "SELECT 1 FROM typing_status
             WHERE user_id = :uid AND contact_id = :me
               AND updated_at >= DATE_SUB(NOW(), INTERVAL 5 SECOND)",
            [':uid' => $contactId, ':me' => $me]
        );
        $isTyping = (bool)$row;
    } catch (\Exception $e) {}

    ob_end_clean();
    successResponse(['is_typing' => $isTyping]);
}

/* ─────────────────────────────────────────
   SEND MESSAGE (JSON body)
   Also creates a notification so the bell lights up for the recipient.
───────────────────────────────────────── */
function sendMessage($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }

    $me = myId();
    if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }

    $data        = json_decode(file_get_contents('php://input'), true);
    $recipientId = isset($data['recipient_id']) ? (int)$data['recipient_id'] : 0;
    $subject     = isset($data['subject'])      ? sanitize($data['subject'])  : '';
    $message     = isset($data['message'])      ? trim($data['message'])      : '';

    if (!$recipientId) { ob_end_clean(); errorResponse('recipient_id is required'); }
    if (!$message)     { ob_end_clean(); errorResponse('Message body is required'); }
    if (mb_strlen($message) > 5000) { ob_end_clean(); errorResponse('Message too long (max 5000 chars)'); }

    /* Insert message — has_file = 0 for plain text */
    $msgId = $db->execute(
        "INSERT INTO messages (sender_id, recipient_id, subject, message, is_read, has_file, created_at)
         VALUES (:sid, :rid, :sub, :msg, 0, 0, NOW())",
        [':sid' => $me, ':rid' => $recipientId, ':sub' => $subject, ':msg' => $message]
    );

    if (!$msgId) { ob_end_clean(); errorResponse('Failed to send message', 500); }

    /* Create notification for the recipient */
    $sender     = $db->queryOne("SELECT full_name FROM users WHERE id = :id", [':id' => $me]);
    $senderName = $sender ? $sender['full_name'] : 'Teacher';
    $notifTitle = 'New message from ' . $senderName;
    $notifBody  = $subject ? $subject . ': ' . mb_substr($message, 0, 80) : mb_substr($message, 0, 100);

    $db->execute(
        "INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
         VALUES (:uid, :title, :msg, 'message', 0, NOW())",
        [':uid' => $recipientId, ':title' => $notifTitle, ':msg' => $notifBody]
    );

    ob_end_clean();
    successResponse([
        'id'           => $msgId,
        'sender_id'    => $me,
        'recipient_id' => $recipientId,
        'subject'      => $subject,
        'message'      => $message,
        'is_read'      => 0,
        'has_file'     => 0,
        'files'        => [],
        'created_at'   => date('Y-m-d H:i:s'),
    ], 'Message sent successfully');
}

/* ─────────────────────────────────────────
   SEND FILE (multipart/form-data)
   Fields: recipient_id, message (optional caption), subject (optional)
   File:   attachment (image/pdf/doc/xls/txt — max 10 MB)
───────────────────────────────────────── */
function sendFile($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }

    $me = myId();
    if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }

    $recipientId = isset($_POST['recipient_id']) ? (int)$_POST['recipient_id'] : 0;
    $message     = isset($_POST['message'])      ? trim($_POST['message'])      : '';
    $subject     = isset($_POST['subject'])      ? sanitize($_POST['subject'])  : '';

    if (!$recipientId) { ob_end_clean(); errorResponse('recipient_id required'); }
    if (!isset($_FILES['attachment']) || $_FILES['attachment']['error'] !== UPLOAD_ERR_OK) {
        ob_end_clean(); errorResponse('No file provided or upload error');
    }

    $file    = $_FILES['attachment'];
    $origName= basename($file['name']);
    $mime    = mime_content_type($file['tmp_name']) ?: 'application/octet-stream';
    $size    = $file['size'];
    $allowed = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'application/pdf', 'text/plain',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ];

    if ($size > 10 * 1024 * 1024)           { ob_end_clean(); errorResponse('File too large (max 10 MB)'); }
    if (!in_array($mime, $allowed, true))    { ob_end_clean(); errorResponse('File type not allowed'); }

    /* Store file on disk */
    $dir = dirname(__DIR__) . '/uploads/messages/';
    if (!is_dir($dir)) { mkdir($dir, 0755, true); }
    $ext    = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    $stored = bin2hex(random_bytes(16)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . $stored)) {
        ob_end_clean(); errorResponse('Failed to save uploaded file', 500);
    }

    /* Insert message row */
    $msgId = $db->execute(
        "INSERT INTO messages (sender_id, recipient_id, subject, message, is_read, has_file, created_at)
         VALUES (:sid, :rid, :sub, :msg, 0, 1, NOW())",
        [':sid' => $me, ':rid' => $recipientId, ':sub' => $subject, ':msg' => $message]
    );
    if (!$msgId) { ob_end_clean(); errorResponse('Failed to save message', 500); }

    /* Insert file record */
    try {
        $db->execute(
            "INSERT INTO message_files (message_id, original_name, stored_name, mime_type, file_size, created_at)
             VALUES (:mid, :orig, :stored, :mime, :size, NOW())",
            [':mid' => $msgId, ':orig' => $origName, ':stored' => $stored, ':mime' => $mime, ':size' => $size]
        );
    } catch (\Exception $e) { /* migration pending */ }

    /* Notification */
    $sender     = $db->queryOne("SELECT full_name FROM users WHERE id = :id", [':id' => $me]);
    $senderName = $sender ? $sender['full_name'] : 'Teacher';
    $db->execute(
        "INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
         VALUES (:uid, :title, :msg, 'message', 0, NOW())",
        [':uid' => $recipientId, ':title' => 'File from ' . $senderName, ':msg' => '📎 ' . $origName]
    );

    ob_end_clean();
    successResponse([
        'id'           => $msgId,
        'sender_id'    => $me,
        'recipient_id' => $recipientId,
        'subject'      => $subject,
        'message'      => $message,
        'is_read'      => 0,
        'has_file'     => 1,
        'files'        => [[
            'file_id'       => null,
            'original_name' => $origName,
            'mime_type'     => $mime,
            'file_size'     => $size,
            'url'           => '/nsms/uploads/messages/' . $stored,
        ]],
        'created_at'   => date('Y-m-d H:i:s'),
    ], 'File sent');
}

/* ─────────────────────────────────────────
   MARK READ — mark all messages from contact X to me as read.
   Also marks message-type notifications from this contact as read.
───────────────────────────────────────── */
function markRead($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }

    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;

    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    $db->execute(
        "UPDATE messages
         SET is_read = 1, read_at = NOW()
         WHERE sender_id = :cid AND recipient_id = :me AND is_read = 0",
        [':cid' => $contactId, ':me' => $me]
    );

    $sender = $db->queryOne(
        "SELECT full_name FROM users WHERE id = :id", [':id' => $contactId]
    );
    if ($sender) {
        $db->execute(
            "UPDATE notifications
             SET is_read = 1, read_at = NOW()
             WHERE user_id = :me
               AND type    = 'message'
               AND is_read = 0
               AND title LIKE :title",
            [':me' => $me, ':title' => '%' . $sender['full_name'] . '%']
        );
    }

    ob_end_clean();
    successResponse(null, 'Marked as read');
}

/* ─────────────────────────────────────────
   SET TYPING — POST heartbeat while composing
   The recipient polls thread_updates which checks this table.
───────────────────────────────────────── */
function setTyping($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    try {
        $db->execute(
            "INSERT INTO typing_status (user_id, contact_id, updated_at)
             VALUES (:me, :cid, NOW())
             ON DUPLICATE KEY UPDATE updated_at = NOW()",
            [':me' => $me, ':cid' => $contactId]
        );
    } catch (\Exception $e) { /* migration pending */ }

    ob_end_clean();
    successResponse(null);
}

/* ─────────────────────────────────────────
   HEARTBEAT — explicitly update own presence
───────────────────────────────────────── */
function doHeartbeat($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }
    _teacherUpdatePresence($db);
    ob_end_clean();
    successResponse(null);
}
