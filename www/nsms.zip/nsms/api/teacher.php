<?php
/**
 * Teacher Panel API  —  PHP 7.2 compatible
 * Path: /nsms/api/teacher-panel.php
 *
 * Actions (GET):  session | dashboard | my_class
 * Actions (POST): change_password
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    exit(0);
}

require_once '../includes/db.php';
require_once '../includes/auth.php';      // starts session + provides isLoggedIn()
require_once '../includes/helpers.php';

applyApiHeaders();

// ── Auth guard ────────────────────────────────────────────────────────────────
// requireRole() in this project returns JSON on failure (not a redirect),
// so it is safe. We add our own success:false envelope so the frontend
// if (!d.success) check works correctly.
$sessionRole = isset($_SESSION['role']) ? strtolower(trim((string)$_SESSION['role'])) : '';
if (!isLoggedIn() || $sessionRole !== 'teacher') {
    ob_end_clean();
    echo json_encode(array(
        'success' => false,
        'error' => 'unauthorized',
        'debug_role' => $sessionRole,
        'debug_logged_in' => isLoggedIn() ? 1 : 0,
    ));
    exit;
}

$sessionUserId = (int)$_SESSION['user_id'];

// ── DB ────────────────────────────────────────────────────────────────────────
$db   = new Database();
// Force a real connect attempt (ignore short offline down-cache) for teacher panel
$conn = $db->connect(true);

$action = isset($_GET['action']) ? $_GET['action'] : 'session';

if (!$conn) {
    require_once __DIR__ . '/../includes/sync/OfflineData.php';
    require_once __DIR__ . '/../includes/sync/SqliteStore.php';
    // Keep the user logged in offline — serve session from PHP session + SQLite
    if ($action === 'session') {
        $data = array(
            'id' => $sessionUserId,
            'full_name' => isset($_SESSION['full_name']) ? $_SESSION['full_name'] : '',
            'email' => isset($_SESSION['email']) ? $_SESSION['email'] : '',
            'phone' => isset($_SESSION['phone']) ? $_SESSION['phone'] : null,
            'photo_url' => null,
            'status' => 'active',
            'password_changed' => 1,
            'offline_mode' => true,
            'class_id' => null,
            'class_name' => null,
            'class_color' => null,
        );
        try {
            $pdo = (new SqliteStore())->connect();
            $st = $pdo->prepare("SELECT id, class_name, class_color FROM classes WHERE teacher_id = ? AND (deleted_at IS NULL OR deleted_at = '') LIMIT 1");
            $st->execute(array($sessionUserId));
            $c = $st->fetch(PDO::FETCH_ASSOC);
            if ($c) {
                $data['class_id'] = (int)$c['id'];
                $data['class_name'] = $c['class_name'];
                $data['class_color'] = isset($c['class_color']) ? $c['class_color'] : null;
                $_SESSION['class_id'] = (int)$c['id'];
                $_SESSION['class_name'] = $c['class_name'];
            }
            // Fallback: match by class name from session if teacher_id not set on classes row
            if (empty($data['class_id']) && !empty($_SESSION['class_name'])) {
                $st = $pdo->prepare("SELECT id, class_name, class_color FROM classes WHERE class_name = ? LIMIT 1");
                $st->execute(array($_SESSION['class_name']));
                $c2 = $st->fetch(PDO::FETCH_ASSOC);
                if ($c2) {
                    $data['class_id'] = (int)$c2['id'];
                    $data['class_name'] = $c2['class_name'];
                    $data['class_color'] = isset($c2['class_color']) ? $c2['class_color'] : null;
                    $_SESSION['class_id'] = (int)$c2['id'];
                }
            }
        } catch (Exception $e) {}
        ob_end_clean();
        echo json_encode(array('success' => true, 'data' => $data, 'message' => 'Offline session'));
        exit;
    }
    if ($action === 'dashboard') {
        try {
            $preferClass = 0;
            if (!empty($_GET['class_id'])) $preferClass = (int)$_GET['class_id'];
            if (!$preferClass && !empty($_SESSION['class_id'])) $preferClass = (int)$_SESSION['class_id'];
            $data = OfflineData::teacherDashboard($sessionUserId, $preferClass);
            // If still no class, re-read from sqlite by teacher and stash
            if (empty($data['class_id'])) {
                try {
                    $pdo = (new SqliteStore())->connect();
                    $st = $pdo->prepare("SELECT id FROM classes WHERE CAST(teacher_id AS INTEGER) = ? LIMIT 1");
                    $st->execute(array($sessionUserId));
                    $cid = (int)$st->fetchColumn();
                    if ($cid) {
                        $data = OfflineData::teacherDashboard($sessionUserId, $cid);
                    }
                } catch (Exception $e2) {}
            }
        } catch (Exception $e) {
            error_log('offline teacher dashboard: ' . $e->getMessage());
            $data = array(
                'day_info' => array('type' => 'school_day', 'name' => null),
                'class_id' => null,
                'class_name' => null,
                'class_color' => '#94A3B8',
                'total_students' => 0,
                'present_today' => 0,
                'absent_today' => 0,
                'late_today' => 0,
                'attendance_rate' => 0,
                'pending_homework' => 0,
                'unread_messages' => 0,
                'schedule' => array(),
                'announcements' => array(),
                'performance' => array(
                    'attendance_rate' => 0,
                    'homework_completion' => 0,
                    'overall_progress' => 0,
                ),
                'offline_mode' => true,
            );
        }
        if (!is_array($data)) $data = array();
        if (!isset($data['announcements']) || !is_array($data['announcements'])) $data['announcements'] = array();
        if (!isset($data['schedule']) || !is_array($data['schedule'])) $data['schedule'] = array();
        if (!isset($data['performance']) || !is_array($data['performance'])) {
            $data['performance'] = array('attendance_rate' => 0, 'homework_completion' => 0, 'overall_progress' => 0);
        }
        $data['offline_mode'] = true;
        if (!isset($data['unread_messages'])) $data['unread_messages'] = 0;
        if (!isset($data['pending_homework'])) $data['pending_homework'] = 0;
        if (!isset($data['present_today'])) $data['present_today'] = 0;
        if (!isset($data['total_students'])) $data['total_students'] = 0;
        ob_end_clean();
        echo json_encode(array('success' => true, 'data' => $data, 'message' => 'Offline dashboard'));
        exit;
    }
    if ($action === 'my_class') {
        $classId = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
        $data = OfflineData::teacherMyClass($sessionUserId, $classId);
        ob_end_clean();
        echo json_encode(array('success' => true, 'data' => $data, 'message' => 'Offline my class'));
        exit;
    }
    ob_end_clean();
    echo json_encode(array(
        'success' => false,
        'error' => 'This teacher action needs a connection offline support is limited to session, dashboard, my class, and attendance',
        'offline' => true
    ));
    exit;
}

// ─────────────────────────────────────────────────────────────────────────────

switch ($action) {

    // ── SESSION ──────────────────────────────────────────────────────────────
    case 'session':

        $teacher = null;
        $rows = $db->query(
            "SELECT
                 u.id,
                 u.full_name,
                 u.email,
                 u.phone,
                 u.photo_url,
                 u.status,
                 u.last_login,
                 c.id          AS class_id,
                 c.class_name,
                 c.class_color
             FROM users u
             LEFT JOIN classes c ON c.teacher_id = u.id
             WHERE u.id = ?
             LIMIT 1",
            array($sessionUserId)
        );
        if (is_array($rows) && count($rows) > 0) {
            $teacher = $rows[0];
        }

        // Fallback: keep the teacher logged in even if the JOIN/query fails
        if (!$teacher) {
            $teacher = array(
                'id' => $sessionUserId,
                'full_name' => isset($_SESSION['full_name']) ? $_SESSION['full_name'] : '',
                'email' => isset($_SESSION['email']) ? $_SESSION['email'] : '',
                'phone' => isset($_SESSION['phone']) ? $_SESSION['phone'] : null,
                'photo_url' => null,
                'status' => 'active',
                'last_login' => null,
                'class_id' => null,
                'class_name' => null,
                'class_color' => null,
            );
        }

        $teacher['password_changed'] = 1; // default: do not bounce activated sessions to setup
        try {
            $pcRow = $db->query(
                "SELECT password_changed FROM users WHERE id = ?",
                array($sessionUserId)
            );
            if ($pcRow && isset($pcRow[0]) && array_key_exists('password_changed', $pcRow[0])
                && $pcRow[0]['password_changed'] !== null && $pcRow[0]['password_changed'] !== '') {
                $teacher['password_changed'] = (int)$pcRow[0]['password_changed'];
            }
        } catch (Exception $e) {
            $teacher['password_changed'] = 1;
        }

        ob_end_clean();
        successResponse($teacher);
        break;

    // ── DASHBOARD ────────────────────────────────────────────────────────────
    case 'dashboard':
        $today = date('Y-m-d');

        // ── Day type: weekend or school/public holiday ────────────────────────
        // ISO day: 1 = Monday … 6 = Saturday, 7 = Sunday
        $dayOfWeek = (int)date('N');
        $dayInfo   = ['type' => 'school_day', 'name' => null];

        if ($dayOfWeek >= 6) {
            $dayInfo = [
                'type' => 'weekend',
                'name' => $dayOfWeek === 6 ? 'Saturday' : 'Sunday',
            ];
        } else {
            // Query calendar_events for a holiday on today's date.
            // Wrapped in try-catch so missing table/columns degrade gracefully.
            try {
                $hRow = $db->query(
                    "SELECT title, event_type
                       FROM calendar_events
                      WHERE event_date = ?
                        AND event_type IN ('public_holiday','school_holiday','holiday')
                      LIMIT 1",
                    [$today]
                );
                if ($hRow) {
                    $eType   = strtolower($hRow[0]['event_type']);
                    $dayInfo = [
                        'type' => ($eType === 'public_holiday') ? 'public_holiday' : 'school_holiday',
                        'name' => $hRow[0]['title'],
                    ];
                }
            } catch (Exception $e) { /* table/column not yet created — stay school_day */ }
        }
        // ─────────────────────────────────────────────────────────────────────

        $classRows  = $db->query(
            "SELECT id, class_name, class_color FROM classes WHERE teacher_id = ?",
            [$sessionUserId]
        );
        $classId    = $classRows ? (int)$classRows[0]['id']    : 0;
        $className  = $classRows ? $classRows[0]['class_name']  : null;
        $classColor = $classRows ? $classRows[0]['class_color'] : '#94A3B8';

        $totalStudents = 0;
        if ($classId) {
            $r = $db->query(
                "SELECT COUNT(*) AS cnt FROM students WHERE class_id = ? AND status = 'active'",
                [$classId]
            );
            $totalStudents = $r ? (int)$r[0]['cnt'] : 0;
        }

        $presentToday = 0;
        if ($classId) {
            $r = $db->query(
                "SELECT COUNT(*) AS cnt
                 FROM attendance a
                 JOIN students s ON s.id = a.student_id
                 WHERE s.class_id = ? AND a.attendance_date = ? AND a.status = 'present'",
                [$classId, $today]
            );
            $presentToday = $r ? (int)$r[0]['cnt'] : 0;
        }

        $r = $db->query(
            "SELECT COUNT(*) AS cnt FROM homework WHERE posted_by = ? AND due_date >= ?",
            [$sessionUserId, $today]
        );
        $pendingHomework = $r ? (int)$r[0]['cnt'] : 0;

        $r = $db->query(
            "SELECT COUNT(*) AS cnt FROM messages WHERE recipient_id = ? AND is_read = 0",
            [$sessionUserId]
        );
        $unreadMessages = $r ? (int)$r[0]['cnt'] : 0;

        $schedule = [];
        if ($classId) {
            $schedule = $db->query(
                "SELECT h.id, h.subject, h.description, h.due_date,
                     CASE
                         WHEN h.due_date = ? THEN 'due_today'
                         WHEN h.due_date > ? THEN 'upcoming'
                         ELSE                    'overdue'
                     END AS hw_status
                 FROM homework h
                 WHERE h.class_id = ? AND h.due_date >= DATE_SUB(?, INTERVAL 1 DAY)
                 ORDER BY h.due_date ASC LIMIT 5",
                [$today, $today, $classId, $today]
            ) ?: [];
        }

        $perf = ['attendance_rate' => 0.0, 'homework_completion' => 0.0, 'overall_progress' => 0.0];
        if ($classId && $totalStudents > 0) {
            $r = $db->query(
                "SELECT COUNT(CASE WHEN a.status='present' THEN 1 END) AS p, COUNT(*) AS t
                 FROM attendance a JOIN students s ON s.id=a.student_id
                 WHERE s.class_id=? AND a.attendance_date>=DATE_SUB(?,INTERVAL 30 DAY)",
                [$classId, $today]
            );
            if ($r && (int)$r[0]['t'] > 0) {
                $perf['attendance_rate'] = round(((int)$r[0]['p'] / (int)$r[0]['t']) * 100, 1);
            }
            // Homework completion for this class:
            //   denominator = all posted assignments × active students
            //   numerator   = unique (homework, student) pairs that are either
            //                 parent-acknowledged OR graded by the teacher
            // Do NOT filter by due_date — future-due work that parents already
            // acknowledged (or the teacher graded) must still count.
            $hwTot = $db->query(
                "SELECT COUNT(*) AS cnt FROM homework WHERE class_id = ?",
                [$classId]
            );
            $n = $hwTot ? (int)$hwTot[0]['cnt'] : 0;

            $done = $db->query(
                "SELECT COUNT(*) AS cnt FROM (
                    SELECT ha.homework_id, ha.student_id
                      FROM homework_acknowledgements ha
                      JOIN homework h ON h.id = ha.homework_id
                     WHERE h.class_id = ?
                    UNION
                    SELECT hg.homework_id, hg.student_id
                      FROM homework_grades hg
                      JOIN homework h ON h.id = hg.homework_id
                     WHERE h.class_id = ?
                ) AS done_pairs",
                [$classId, $classId]
            );
            $a = $done ? (int)$done[0]['cnt'] : 0;

            if ($n > 0 && $totalStudents > 0) {
                $perf['homework_completion'] = round(min(($a / ($n * $totalStudents)) * 100, 100), 1);
            }
            $perf['overall_progress'] = round(($perf['attendance_rate'] + $perf['homework_completion']) / 2, 1);
        }

        $announcements = $db->query(
            "SELECT id, title, content, is_urgent, created_at FROM announcements WHERE target_audience IN ('all','teachers') ORDER BY created_at DESC LIMIT 5"
        ) ?: [];

        // Decode any over-escaped homework text for the UI
        foreach ($schedule as &$sch) {
            if (isset($sch['subject'])) {
                $sch['subject'] = html_entity_decode($sch['subject'], ENT_QUOTES, 'UTF-8');
            }
            if (isset($sch['description'])) {
                $sch['description'] = html_entity_decode($sch['description'], ENT_QUOTES, 'UTF-8');
            }
        }
        unset($sch);

        ob_end_clean();
        successResponse([
            'class_id'         => $classId,
            'class_name'       => $className,
            'class_color'      => $classColor,
            'total_students'   => $totalStudents,
            'present_today'    => $presentToday,
            'pending_homework' => $pendingHomework,
            'unread_messages'  => $unreadMessages,
            'schedule'         => $schedule,
            'performance'      => $perf,
            'announcements'    => $announcements,
            'day_info'         => $dayInfo,
        ]);
        break;

    // ── MY CLASS ─────────────────────────────────────────────────────────────
    case 'my_class':
        $classRows = $db->query(
            "SELECT id FROM classes WHERE teacher_id = ?", [$sessionUserId]
        );
        if (!$classRows) { ob_end_clean(); successResponse([]); break; }
        $classId  = (int)$classRows[0]['id'];
        $students = $db->query(
            "SELECT s.id, s.student_name, s.date_of_birth, s.gender, s.photo_url,
                    s.enrollment_date, s.status,
                    (SELECT a.status FROM attendance a WHERE a.student_id=s.id ORDER BY a.attendance_date DESC LIMIT 1) AS last_attendance,
                    (SELECT u.full_name FROM parents p JOIN users u ON u.id=p.user_id WHERE p.student_id=s.id LIMIT 1) AS parent_name
             FROM students s WHERE s.class_id=? AND s.status='active' ORDER BY s.student_name ASC",
            [$classId]
        ) ?: [];
        ob_end_clean();
        successResponse($students);
        break;

    // ── CHANGE PASSWORD ──────────────────────────────────────────────────────
    case 'change_password':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean(); errorResponse('POST required', 405);
        }
        $input   = json_decode(file_get_contents('php://input'), true);
        $newPass = isset($input['new_password'])     ? trim($input['new_password'])     : '';
        $confirm = isset($input['confirm_password']) ? trim($input['confirm_password']) : '';

        if (strlen($newPass) < 8) { ob_end_clean(); errorResponse('Password must be at least 8 characters', 400); }
        if ($newPass !== $confirm)  { ob_end_clean(); errorResponse('Passwords do not match', 400); }

        $hash = password_hash($newPass, PASSWORD_BCRYPT);

        // Only a true first-time activation (0 -> 1) should trigger the
        // welcome email — guards against this endpoint later being reused
        // for a voluntary password change elsewhere in the teacher panel.
        $wasAlreadyActive = false;
        try {
            $priorRow = $db->queryOne("SELECT password_changed FROM users WHERE id = :id", [':id' => $sessionUserId]);
            $wasAlreadyActive = $priorRow && (int)$priorRow['password_changed'] === 1;
        } catch (Exception $e) { /* column missing — treat as first activation */ }

        // Step 1: update password — this column always exists
        $db->execute(
            "UPDATE users SET password_hash = :hash WHERE id = :id AND role = 'teacher'",
            [':hash' => $hash, ':id' => $sessionUserId]
        );

        // Step 2: mark as changed — column added by migration, try-catch so missing column is non-fatal
        try {
            $db->execute(
                "UPDATE users SET password_changed = 1 WHERE id = :id",
                [':id' => $sessionUserId]
            );
        } catch (Exception $e) { /* column not yet created — non-fatal */ }

        if (!$wasAlreadyActive) {
            notifyTeacherAccountActivated($db, $sessionUserId);
        }

        ob_end_clean();
        successResponse(['message' => 'Password changed. Please log in again.']);
        break;

    // ── NOTIFICATIONS COUNT ──────────────────────────────────────────────────
    // Returns total unread: messages + system notifications
    // Used by the bell icon in TeacherNavbar
    case 'notifications_count':
        $rMsg  = $db->query(
            "SELECT COUNT(*) AS cnt FROM messages WHERE recipient_id = ? AND is_read = 0",
            [$sessionUserId]
        );
        $rNotif = $db->query(
            "SELECT COUNT(*) AS cnt FROM pulse_alert_recipients
              WHERE user_id = ? AND is_read = 0",
            [$sessionUserId]
        );
        $msgs   = $rMsg   ? (int)$rMsg[0]['cnt']   : 0;
        $notifs = $rNotif ? (int)$rNotif[0]['cnt'] : 0;
        ob_end_clean();
        successResponse([
            'messages'      => $msgs,
            'notifications' => $notifs,
            'total'         => $msgs + $notifs,
        ]);
        break;

    // ── NOTIFICATIONS (items) ────────────────────────────────────────────────
    // Returns the most recent 30 notification rows for this teacher.
    // Used by TcBell to render the Alerts tab with real content.
    // Wrapped in try-catch — if the table hasn't been created yet, returns [].
    case 'notifications':
        $items = [];
        try {
            $items = $db->query(
                "SELECT par.alert_id AS id,
                        'pulse_alert'  AS type,
                        pa.title,
                        pa.body        AS message,
                        pa.priority,
                        par.is_read,
                        pa.created_at
                   FROM pulse_alert_recipients par
                   JOIN pulse_alerts pa ON pa.id = par.alert_id
                  WHERE par.user_id = ?
                  ORDER BY pa.created_at DESC
                  LIMIT 30",
                [$sessionUserId]
            ) ?: [];
        } catch (Exception $e) { /* pulse_alerts table not yet created — return empty */ }
        ob_end_clean();
        successResponse($items);
        break;

    // ── MARK NOTIFICATIONS READ ──────────────────────────────────────────────
    // POST body: { "id": N }   — mark single notification N as read
    // POST body: { "id": 0 }   — mark ALL notifications as read (bulk dismiss)
    case 'mark_notifications_read':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean(); errorResponse('POST required', 405);
        }
        $input = json_decode(file_get_contents('php://input'), true);
        $nid   = isset($input['id']) ? (int)$input['id'] : 0;
        try {
            if ($nid > 0) {
                $db->execute(
                    "UPDATE pulse_alert_recipients SET is_read = 1, read_at = NOW()
                      WHERE alert_id = ? AND user_id = ?",
                    [$nid, $sessionUserId]
                );
            } else {
                // id = 0 → mark all for this teacher
                $db->execute(
                    "UPDATE pulse_alert_recipients SET is_read = 1, read_at = NOW()
                      WHERE user_id = ? AND is_read = 0",
                    [$sessionUserId]
                );
            }
        } catch (Exception $e) { /* non-fatal — table may not exist yet */ }
        ob_end_clean();
        successResponse(['marked' => true]);
        break;

    // ── GENERATE REMINDERS ──────────────────────────────────────────────────────
    // Auto-creates notifications for:
    //   • Upcoming calendar exams / assessments   (≤ 14 days ahead)
    //   • Homework approaching its deadline        (≤ 2  days ahead)
    //   • Students with 3+ consecutive absences
    //   • Students with attendance < 75% in last 30 days (fires once per week)
    //
    // De-duplication: uses a reference_key column on the notifications table.
    // If that column doesn't exist yet the code degrades gracefully — it falls
    // back to a title+type+date check so duplicates are still avoided.
    //
    // Add the column with:
    //   ALTER TABLE notifications
    //     ADD COLUMN reference_key VARCHAR(120) NULL DEFAULT NULL,
    //     ADD INDEX idx_notif_refkey (user_id, reference_key);
    case 'generate_reminders':

        $today   = date('Y-m-d');
        $created = 0;

        // ── Helper closure: insert only if this reference_key hasn't been used ──
        $insertReminder = function($type, $title, $message, $refKey)
            use ($db, $sessionUserId, &$created)
        {
            try {
                // Duplicate check — prefer reference_key, fall back to title+type+date
                $isDup = false;
                try {
                    $ex = $db->query(
                        "SELECT id FROM notifications
                          WHERE user_id = ? AND reference_key = ? LIMIT 1",
                        [$sessionUserId, $refKey]
                    );
                    $isDup = (bool)$ex;
                } catch (Exception $e) {
                    // reference_key column missing — check by title + type today
                    try {
                        $ex = $db->query(
                            "SELECT id FROM notifications
                              WHERE user_id = ? AND type = ? AND title = ?
                                AND DATE(created_at) = CURDATE() LIMIT 1",
                            [$sessionUserId, $type, $title]
                        );
                        $isDup = (bool)$ex;
                    } catch (Exception $e2) { /* can't check — allow insert */ }
                }
                if ($isDup) return;

                // Insert — try with reference_key, fall back without
                try {
                    $db->execute(
                        "INSERT INTO notifications
                             (user_id, type, title, message, is_read, reference_key, created_at)
                         VALUES (?, ?, ?, ?, 0, ?, NOW())",
                        [$sessionUserId, $type, $title, $message, $refKey]
                    );
                } catch (Exception $e) {
                    // reference_key column absent — insert without it
                    $db->execute(
                        "INSERT INTO notifications
                             (user_id, type, title, message, is_read, created_at)
                         VALUES (?, ?, ?, ?, 0, NOW())",
                        [$sessionUserId, $type, $title, $message]
                    );
                }
                $created++;
            } catch (Exception $e) { /* non-fatal */ }
        };

        // ── 1. UPCOMING EXAM / ASSESSMENT REMINDERS ──────────────────────────
        // Triggers for events in calendar_events with exam-like event_type
        // that fall within the next 14 days.
        try {
            $twoWeeksOut = date('Y-m-d', strtotime('+14 days'));
            $exams = $db->query(
                "SELECT id, title, event_date, description, event_type
                   FROM calendar_events
                  WHERE event_type IN ('exam','examination','test','assessment','exams')
                    AND event_date BETWEEN ? AND ?
                  ORDER BY event_date ASC",
                [$today, $twoWeeksOut]
            ) ?: [];

            foreach ($exams as $exam) {
                $daysLeft = (int)ceil(
                    (strtotime($exam['event_date']) - strtotime($today)) / 86400
                );
                $dayLabel = $daysLeft === 0 ? 'today'
                          : ($daysLeft === 1 ? 'tomorrow'
                          : 'in ' . $daysLeft . ' days');
                $dateStr  = date('D, d M Y', strtotime($exam['event_date']));
                $desc     = !empty($exam['description'])
                          ? ' — ' . $exam['description'] : '';

                $refKey = 'exam_' . (int)$exam['id'] . '_' . $exam['event_date'];

                $insertReminder(
                    'exam_reminder',
                    '📝 Exam ' . $dayLabel . ': ' . $exam['title'],
                    'Scheduled ' . $dayLabel . ' (' . $dateStr . ')' . $desc,
                    $refKey
                );
            }
        } catch (Exception $e) { /* calendar_events table may differ — skip */ }

        // ── 2. HOMEWORK DEADLINE REMINDERS ───────────────────────────────────
        // Fires for the teacher's own homework assignments due within 2 days.
        try {
            $twoDaysOut = date('Y-m-d', strtotime('+2 days'));
            $hwList = $db->query(
                "SELECT id, subject, due_date, description
                   FROM homework
                  WHERE posted_by = ?
                    AND due_date BETWEEN ? AND ?
                  ORDER BY due_date ASC",
                [$sessionUserId, $today, $twoDaysOut]
            ) ?: [];

            foreach ($hwList as $hw) {
                $daysLeft = (int)ceil(
                    (strtotime($hw['due_date']) - strtotime($today)) / 86400
                );
                $dayLabel = $daysLeft === 0 ? 'due today'
                          : ($daysLeft === 1 ? 'due tomorrow'
                          : 'due in 2 days');
                $dateStr  = date('D, d M Y', strtotime($hw['due_date']));
                $desc     = !empty($hw['description'])
                          ? $hw['description'] . ' — ' : '';

                $refKey = 'hw_' . (int)$hw['id'] . '_' . $hw['due_date'];

                $insertReminder(
                    'homework_deadline',
                    '✏️ Homework ' . $dayLabel . ': ' . $hw['subject'],
                    $desc . 'Due: ' . $dateStr,
                    $refKey
                );
            }
        } catch (Exception $e) { /* homework table issue — skip */ }

        // ── 3. ATTENDANCE ISSUE REMINDERS ────────────────────────────────────
        try {
            $classRows = $db->query(
                "SELECT id FROM classes WHERE teacher_id = ?", [$sessionUserId]
            );
            if ($classRows) {
                $classId  = (int)$classRows[0]['id'];
                $students = $db->query(
                    "SELECT id, student_name FROM students
                      WHERE class_id = ? AND status = 'active'",
                    [$classId]
                ) ?: [];

                foreach ($students as $stu) {
                    $stuId = (int)$stu['id'];

                    // ── 3a. 3+ consecutive absences ──────────────────────────
                    $recent = $db->query(
                        "SELECT status FROM attendance
                          WHERE student_id = ?
                          ORDER BY attendance_date DESC LIMIT 3",
                        [$stuId]
                    ) ?: [];

                    if (count($recent) === 3
                        && $recent[0]['status'] === 'absent'
                        && $recent[1]['status'] === 'absent'
                        && $recent[2]['status'] === 'absent'
                    ) {
                        $refKey = 'att_consec_' . $stuId . '_' . $today;
                        $insertReminder(
                            'attendance_issue',
                            '⚠️ Consecutive Absences: ' . $stu['student_name'],
                            $stu['student_name'] . ' has been absent for 3 or more '
                            . 'consecutive school days. Consider contacting the parent.',
                            $refKey
                        );
                    }

                    // ── 3b. Attendance rate < 75 % over last 30 days ─────────
                    // de-dup key uses ISO year-week so it fires at most once a week
                    $refKey = 'att_low_' . $stuId . '_' . date('Y-W');
                    try {
                        $ex = $db->query(
                            "SELECT id FROM notifications
                              WHERE user_id = ? AND reference_key = ? LIMIT 1",
                            [$sessionUserId, $refKey]
                        );
                        if ($ex) continue; // already sent this week — skip
                    } catch (Exception $e) { /* column missing — proceed */ }

                    $attRow = $db->query(
                        "SELECT
                             COUNT(*)                                            AS total,
                             SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) AS present_cnt
                           FROM attendance
                          WHERE student_id = ?
                            AND attendance_date >= DATE_SUB(?, INTERVAL 30 DAY)",
                        [$stuId, $today]
                    );
                    if ($attRow && (int)$attRow[0]['total'] >= 10) {
                        $total   = (int)$attRow[0]['total'];
                        $present = (int)$attRow[0]['present_cnt'];
                        $rate    = round(($present / $total) * 100);
                        if ($rate < 75) {
                            $insertReminder(
                                'attendance_issue',
                                '📉 Low Attendance: ' . $stu['student_name'],
                                $stu['student_name'] . ' has only ' . $rate . '% attendance '
                                . 'over the last 30 days (' . $present . '/' . $total . ' days). '
                                . 'Parental contact is advised.',
                                $refKey
                            );
                        }
                    }
                }
            }
        } catch (Exception $e) { /* attendance / classes tables issue — skip */ }

        // ── 4. NEW STUDENT ENROLLED IN TEACHER'S CLASS ───────────────────────
        // Fires once per student based on their enrollment_date being recent.
        // reference_key = 'new_student_{student_id}' — fires exactly once ever.
        try {
            $classRows = $db->query(
                "SELECT id, class_name FROM classes WHERE teacher_id = ?",
                [$sessionUserId]
            );
            if ($classRows) {
                $classId   = (int)$classRows[0]['id'];
                $className = $classRows[0]['class_name'];

                // Students enrolled within the last 30 days in this class
                $newStudents = $db->query(
                    "SELECT id, student_name, gender, enrollment_date
                       FROM students
                      WHERE class_id = ?
                        AND status   = 'active'
                        AND enrollment_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                      ORDER BY enrollment_date DESC",
                    [$classId]
                ) ?: [];

                foreach ($newStudents as $ns) {
                    $refKey  = 'new_student_' . (int)$ns['id'];
                    $pronoun = (isset($ns['gender']) && strtolower($ns['gender']) === 'female')
                               ? 'She' : 'They';
                    $dateStr = date('d M Y', strtotime($ns['enrollment_date']));

                    $insertReminder(
                        'new_student',
                        '🎒 New Student: ' . $ns['student_name'],
                        $ns['student_name'] . ' has been enrolled in ' . $className
                        . ' as of ' . $dateStr . '. ' . $pronoun
                        . ' will appear in your attendance and class list.',
                        $refKey
                    );
                }
            }
        } catch (Exception $e) { /* classes / students table issue — skip */ }

        // ── 5. CLASS ASSIGNMENT (teacher assigned / re-assigned to a class) ───
        // reference_key = 'class_assign_{class_id}' — fires once per class assignment.
        try {
            $classRows = $db->query(
                "SELECT id, class_name FROM classes WHERE teacher_id = ?",
                [$sessionUserId]
            );
            if ($classRows) {
                foreach ($classRows as $cls) {
                    $refKey = 'class_assign_' . (int)$cls['id'];
                    $insertReminder(
                        'class_assignment',
                        '🏫 Class Assigned: ' . $cls['class_name'],
                        'You have been assigned as the class teacher for '
                        . $cls['class_name'] . '. You can now manage attendance, '
                        . 'homework, and reports for this class.',
                        $refKey
                    );
                }
            }
        } catch (Exception $e) { /* classes table issue — skip */ }

        // ── 6. SUBJECT ASSIGNMENT ─────────────────────────────────────────────
        // Supports two common schema patterns:
        //   A) class_subjects (class_id, subject_id, teacher_id) + subjects (id, subject_name)
        //   B) teacher_subjects (teacher_id, subject_id, class_id) + subjects (id, subject_name)
        // reference_key = 'subject_assign_{subject_id}_{class_id}'

        // Pattern A — class_subjects with teacher_id column
        try {
            $subjRows = $db->query(
                "SELECT cs.subject_id, cs.class_id, s.subject_name, c.class_name
                   FROM class_subjects cs
                   JOIN subjects s ON s.id = cs.subject_id
                   JOIN classes  c ON c.id = cs.class_id
                  WHERE cs.teacher_id = ?",
                [$sessionUserId]
            ) ?: [];

            foreach ($subjRows as $sr) {
                $refKey = 'subject_assign_' . (int)$sr['subject_id']
                        . '_' . (int)$sr['class_id'];
                $insertReminder(
                    'subject_assignment',
                    '📚 Subject Assigned: ' . $sr['subject_name'],
                    'You have been assigned to teach ' . $sr['subject_name']
                    . ' in ' . $sr['class_name'] . '.',
                    $refKey
                );
            }
        } catch (Exception $e) {
            // Pattern B — teacher_subjects table
            try {
                $subjRows = $db->query(
                    "SELECT ts.subject_id, ts.class_id, s.subject_name, c.class_name
                       FROM teacher_subjects ts
                       JOIN subjects s ON s.id = ts.subject_id
                       JOIN classes  c ON c.id = ts.class_id
                      WHERE ts.teacher_id = ?",
                    [$sessionUserId]
                ) ?: [];

                foreach ($subjRows as $sr) {
                    $refKey = 'subject_assign_' . (int)$sr['subject_id']
                            . '_' . (int)$sr['class_id'];
                    $insertReminder(
                        'subject_assignment',
                        '📚 Subject Assigned: ' . $sr['subject_name'],
                        'You have been assigned to teach ' . $sr['subject_name']
                        . ' in ' . $sr['class_name'] . '.',
                        $refKey
                    );
                }
            } catch (Exception $e2) { /* neither schema matches — skip */ }
        }

        ob_end_clean();
        successResponse(['generated' => $created]);
        break;

    default:
        ob_end_clean();
        errorResponse('Unknown action', 400);
}

/**
 * Email a short welcome note the moment a teacher account finishes
 * first-login setup. Best-effort — never blocks the password change itself.
 */
function notifyTeacherAccountActivated($db, $userId) {
    try {
        $user = $db->queryOne("SELECT email, full_name FROM users WHERE id = ?", [$userId]);
        if (!$user || empty($user['email'])) return;

        $subject = 'Your NSMS Teacher Account is Now Active';
        $body =
            '<p>Dear ' . htmlspecialchars($user['full_name']) . ',</p>' .
            '<p>Your teacher account has been successfully activated. You can now log in with your new password ' .
            'to manage your class register, gradebook, attendance, and messages.</p>' .
            '<p style="color:#888;font-size:12px;">If you did not make this change, please contact the school administrator immediately.</p>';
        sendEmail($user['email'], $subject, $body);
    } catch (Exception $e) {
        error_log('notifyTeacherAccountActivated error: ' . $e->getMessage());
    }
}
