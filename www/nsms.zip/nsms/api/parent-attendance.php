<?php
/**
 * Parent Attendance API
 * /nsms/api/parent-attendance.php
 * PHP 7.2 compatible.
 *
 * Auth: includes auth.php for successResponse/errorResponse/session,
 *        but does NOT call requireRole() — checks role manually instead.
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';   // provides successResponse, errorResponse, session
require_once '../includes/helpers.php';

applyApiHeaders();

/* Session inspection */
$_sRole     = isset($_SESSION['role'])      ? strtolower(trim($_SESSION['role'])) : '';
$_sParentId = isset($_SESSION['parent_id']) ? (int)$_SESSION['parent_id']         : 0;
$_sUserId   = isset($_SESSION['user_id'])   ? (int)$_SESSION['user_id']           : 0;

$_isAdmin  = ($_sRole === 'admin');
$_isParent = ($_sParentId > 0) || ($_sRole === 'parent');

if (!$_isAdmin && !$_isParent) {
    ob_end_clean();
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'error'   => 'Not authenticated. Please log in to the parent portal.',
        '_debug'  => [
            'role'         => $_sRole,
            'parent_id'    => $_sParentId,
            'user_id'      => $_sUserId,
            'session_keys' => array_keys($_SESSION),
        ],
    ]);
    exit;
}

$db   = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

$action = isset($_GET['action']) ? trim($_GET['action']) : '';
switch ($action) {
    case 'get_attendance':   getMonthlyAttendance($db);  break;
    case 'get_yearly_stats': getYearlyStats($db);        break;
    default: ob_end_clean(); errorResponse('Invalid action');
}

/* Resolve parent ID from session */
function resolveParentId($db) {
    global $_isAdmin, $_sParentId, $_sUserId;
    if ($_isAdmin) return null; /* admin bypasses ownership */
    if ($_sParentId > 0) return $_sParentId;
    if ($_sUserId > 0) {
        $row = $db->queryOne(
            "SELECT id FROM parents WHERE user_id = :uid LIMIT 1",
            [':uid' => $_sUserId]
        );
        return $row ? (int)$row['id'] : 0;
    }
    return 0;
}

function authoriseStudent($db, $studentId) {
    global $_isAdmin, $_sUserId;
    if ($_isAdmin) return true;

    if (!$_sUserId) { ob_end_clean(); errorResponse('Not authenticated.', 403); }

    // Schema: parents(user_id, student_id) — one row per parent-child link
    $linked = $db->queryOne(
        "SELECT 1 FROM parents WHERE user_id = :uid AND student_id = :sid LIMIT 1",
        [':uid' => $_sUserId, ':sid' => $studentId]
    );
    if (!$linked) { ob_end_clean(); errorResponse('You do not have access to this student.', 403); }
    return true;
}

function getMonthlyAttendance($db) {
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$studentId) { ob_end_clean(); errorResponse('student_id is required'); }
    authoriseStudent($db, $studentId);

    $year  = isset($_GET['year'])  ? (int)$_GET['year']  : (int)date('Y');
    $month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('n');
    if ($year < 2000 || $year > 2100) $year = (int)date('Y');
    if ($month < 1 || $month > 12)    $month = (int)date('n');

    $dateStart = sprintf('%04d-%02d-01', $year, $month);
    $dateEnd   = date('Y-m-t', strtotime($dateStart));

    $rows = $db->query(
        "SELECT attendance_date, status, late_minutes, notes, marked_at
         FROM   attendance
         WHERE  student_id = :sid AND attendance_date BETWEEN :ds AND :de
         ORDER  BY attendance_date ASC",
        [':sid' => $studentId, ':ds' => $dateStart, ':de' => $dateEnd]
    ) ?: [];

    $recMap = [];
    foreach ($rows as $row) {
        $recMap[$row['attendance_date']] = [
            'status'       => $row['status'],
            'late_minutes' => $row['late_minutes'] !== null ? (int)$row['late_minutes'] : null,
            'notes'        => isset($row['notes'])    ? $row['notes']    : null,
            'marked_at'    => isset($row['marked_at'])? $row['marked_at']: null,
        ];
    }

    /* Holidays */
    $holidays = [];
    $hQueries = [
        "SELECT event_date AS d FROM school_calendar
         WHERE (is_holiday=1 OR event_type IN ('holiday','break','vacation','closed'))
           AND event_date BETWEEN :ds AND :de",
        "SELECT holiday_date AS d FROM holidays WHERE holiday_date BETWEEN :ds AND :de",
    ];
    foreach ($hQueries as $sql) {
        try {
            foreach ($db->query($sql,[':ds'=>$dateStart,':de'=>$dateEnd]) ?: [] as $h)
                if (!empty($h['d'])) $holidays[] = $h['d'];
        } catch (Exception $e) {}
    }
    $holidays = array_values(array_unique($holidays));
    $holSet   = array_flip($holidays);
    $today    = date('Y-m-d');

    $records = []; $present = $absent = $late = $schoolDays = 0;
    $cursor  = new DateTime($dateStart);
    $end     = new DateTime($dateEnd);
    while ($cursor <= $end) {
        $ds  = $cursor->format('Y-m-d');
        $dow = (int)$cursor->format('N');
        $isWeekend  = ($dow >= 6);
        $isHoliday  = isset($holSet[$ds]);
        $isFuture   = ($ds > $today);
        $rec        = isset($recMap[$ds]) ? $recMap[$ds] : null;

        if (!$isWeekend && !$isHoliday && !$isFuture) {
            $schoolDays++;
            if ($rec) {
                if ($rec['status']==='present') $present++;
                elseif ($rec['status']==='absent')  $absent++;
                elseif ($rec['status']==='late')    $late++;
            }
        }

        $records[] = [
            'date'         => $ds,
            'status'       => $rec ? $rec['status']       : null,
            'late_minutes' => $rec ? $rec['late_minutes'] : null,
            'notes'        => $rec ? $rec['notes']        : null,
            'marked_at'    => $rec ? $rec['marked_at']    : null,
            'is_weekend'   => $isWeekend,
            'is_holiday'   => $isHoliday,
            'is_future'    => $isFuture,
        ];
        $cursor->modify('+1 day');
    }
    $marked = $present + $absent + $late;
    $rate   = $marked > 0 ? round(($present + $late) / $marked * 100, 1) : null;

    $student = $db->queryOne(
        "SELECT s.student_name, s.photo_url, c.class_name
         FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=:sid",
        [':sid' => $studentId]
    );

    ob_end_clean();
    successResponse([
        'student'  => $student ?: ['student_name'=>'','class_name'=>''],
        'year'     => $year, 'month' => $month,
        'records'  => $records, 'holidays' => $holidays,
        'summary'  => ['present'=>$present,'absent'=>$absent,'late'=>$late,
                       'school_days'=>$schoolDays,'marked_days'=>$marked,'rate'=>$rate],
    ]);
}

function getYearlyStats($db) {
    $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
    if (!$studentId) { ob_end_clean(); errorResponse('student_id is required'); }
    authoriseStudent($db, $studentId);

    $year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
    $yearStart = $year.'-01-01'; $yearEnd = $year.'-12-31';
    try {
        $r = $db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key='acad_year_start' LIMIT 1");
        if ($r && !empty($r['setting_value'])) $yearStart = $r['setting_value'];
        $r = $db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key='acad_year_end' LIMIT 1");
        if ($r && !empty($r['setting_value'])) $yearEnd = $r['setting_value'];
    } catch (Exception $e) {}
    $today = date('Y-m-d');
    if ($yearEnd > $today) $yearEnd = $today;

    $rows = $db->query(
        "SELECT status, COUNT(*) AS cnt FROM attendance
         WHERE student_id=:sid AND attendance_date BETWEEN :ds AND :de GROUP BY status",
        [':sid'=>$studentId,':ds'=>$yearStart,':de'=>$yearEnd]
    ) ?: [];

    $present=$absent=$late=0;
    foreach ($rows as $row) {
        if ($row['status']==='present') $present=(int)$row['cnt'];
        elseif ($row['status']==='absent')  $absent=(int)$row['cnt'];
        elseif ($row['status']==='late')    $late=(int)$row['cnt'];
    }
    $total = $present+$absent+$late;
    $rate  = $total > 0 ? round(($present+$late)/$total*100,1) : null;

    ob_end_clean();
    successResponse(['present'=>$present,'absent'=>$absent,'late'=>$late,
                     'total_days'=>$total,'rate'=>$rate,
                     'year_start'=>$yearStart,'year_end'=>$yearEnd]);
}
