<?php
/**
 * J11 Pulse — Parent API  /nsms/api/parent-pulse-api.php
 * PHP 7.2 compatible. Parent role only.
 *
 * ── Schema assumptions ───────────────────────────────────────
 *   student_parents      (student_id, parent_id)
 *   students             (id, full_name, class_id, ...)
 *   classes              (id, name, ...)
 *   class_teachers       (class_id, teacher_id)
 *   pulse_groups         (id, name, description, avatar_color, created_by, created_at)
 *   pulse_group_members  (group_id, user_id, group_role, joined_at)
 *   pulse_group_messages (id, group_id, sender_id, message, created_at)
 *   pulse_group_files    (message_id, original_name, stored_name, mime_type, file_size)
 *   group_resources      (id, group_id, uploaded_by, title, description, stored_name,
 *                          original_name, mime_type, file_size, created_at)
 *
 * ── Contact access rules ─────────────────────────────────────
 *   ✅ All school admins
 *   ✅ Teachers in class_teachers whose class contains this parent's child(ren)
 *   ✅ Other parents whose child shares a class with this parent's child(ren)
 *   ❌ All other teachers / parents
 *
 * ── Permission matrix ────────────────────────────────────────
 *   Direct Messages    : full read/write (scoped contacts above)
 *   Collaboration Hub  : full participation (chat, resources, create/join/leave groups)
 *   Alerts             : receive + mark-read ONLY
 *   Broadcast          : read ONLY
 */

ob_start();

// See pulse-api.php for why this matters: an undisplayed warning here
// would otherwise corrupt every JSON response and silently strand the
// frontend on "Loading…" forever (most fetches here have no .catch()).
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

if (function_exists('applyApiHeaders')) { applyApiHeaders(); }


requireRole(['parent']);

$db   = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

$action = isset($_GET['action']) ? trim($_GET['action']) : '';
_prPresence($db);
_prEnsureModernSchema($db);

switch ($action) {
    /* ── DM ── */
    case 'whoami':               prWhoAmI($db);              break;
    case 'conversations':        prConversations($db);       break;
    case 'thread':               prThread($db);              break;
    case 'thread_updates':       prThreadUpdates($db);       break;
    case 'contacts':             prContacts($db);            break;
    case 'typing_status':        prTypingStatus($db);        break;
    case 'send':                 prSend($db);                break;
    case 'send_file':            prSendFile($db);            break;
    case 'mark_read':            prMarkRead($db);            break;
    case 'set_typing':           prSetTyping($db);           break;
    case 'heartbeat':            prHeartbeat($db);           break;
    case 'toggle_reaction':      prToggleReaction($db);      break;
    case 'edit_message':         prEditMessage($db);         break;
    case 'delete_message':       prDeleteMessage($db);       break;
    /* ── Collab Hub ── */
    case 'my_groups':            prMyGroups($db);            break;
    case 'available_groups':     prAvailableGroups($db);     break;
    case 'group_thread':         prGroupThread($db);         break;
    case 'group_thread_updates': prGroupThreadUpdates($db);  break;
    case 'group_members':        prGroupMembers($db);        break;
    case 'resources':            prResources($db);           break;
    case 'create_group':         prCreateGroup($db);         break;
    case 'join_group':           prJoinGroup($db);           break;
    case 'leave_group':          prLeaveGroup($db);          break;
    case 'mark_group_read':      prMarkGroupRead($db);       break;
    case 'group_send':           prGroupSend($db);           break;
    case 'group_send_file':      prGroupSendFile($db);       break;
    case 'upload_resource':      prUploadResource($db);      break;
    /* ── Alerts (receive-only) ── */
    case 'my_alerts':            prMyAlerts($db);            break;
    case 'mark_alert_read':      prMarkAlertRead($db);       break;
    /* ── Broadcast (read-only) ── */
    case 'announcements':        prAnnouncements($db);       break;
    case 'newsletters':          prNewsletters($db);         break;
    /* ── Unread summary ── */
    case 'unread_counts':        prUnreadCounts($db);        break;
    default: ob_end_clean(); errorResponse('Invalid action');
}

/* ════════════════════════════════════════════════════════
   CORE UTILITIES
════════════════════════════════════════════════════════ */
function _me()  { return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0; }

function _prPresence($db) {
    $me = _me(); if (!$me) return;
    try {
        $db->execute(
            "INSERT INTO user_presence (user_id, last_seen) VALUES (:uid, NOW())
             ON DUPLICATE KEY UPDATE last_seen = NOW()",
            [':uid' => $me]
        );
    } catch (\Exception $e) {}
}

function _prIsOnline($db, $userId) {
    try {
        $r = $db->queryOne(
            "SELECT user_id FROM user_presence
             WHERE user_id = :uid AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)",
            [':uid' => $userId]
        );
        return (bool)$r;
    } catch (\Exception $e) { return false; }
}

/**
 * Returns array of user IDs this parent is permitted to DM.
 * Covers: all admins, teachers of their (active) children's classes,
 * co-parents who share a class with them.
 *
 * Bug fix: this used to query class_teachers/student_parents — two
 * tables that exist in the schema but were never actually populated
 * (zero rows in production). That silently limited every parent to
 * admins only, no matter who else should have been reachable. Fixed to
 * use the real, populated tables: classes.teacher_id and parents
 * (student_id/user_id) — the same tables used throughout the rest of
 * NSMS (fee payments, emergency contacts, promotions, etc.).
 */
function _prGetPermittedContactIds($db, $me) {
    $ids = [];
    /* Admins */
    $rows = $db->query("SELECT id FROM users WHERE role='admin'", []) ?: [];
    foreach ($rows as $r) { $ids[] = (int)$r['id']; }
    /* Teachers of this parent's own active children's classes */
    $rows = $db->query(
        "SELECT DISTINCT c.teacher_id AS id
           FROM parents p
           JOIN students s ON s.id = p.student_id
           JOIN classes  c ON c.id = s.class_id
          WHERE p.user_id = :me AND s.status = 'active' AND c.teacher_id IS NOT NULL",
        [':me' => $me]
    ) ?: [];
    foreach ($rows as $r) { $ids[] = (int)$r['id']; }
    /* Co-parents — anyone who parents a student in the same class as any of my children */
    $rows = $db->query(
        "SELECT DISTINCT p2.user_id AS id
           FROM parents p1
           JOIN students s1 ON s1.id = p1.student_id AND s1.status = 'active'
           JOIN students s2 ON s2.class_id = s1.class_id AND s2.status = 'active'
           JOIN parents p2  ON p2.student_id = s2.id
          WHERE p1.user_id = :me AND p2.user_id != :me2",
        [':me' => $me, ':me2' => $me]
    ) ?: [];
    foreach ($rows as $r) { $ids[] = (int)$r['id']; }
    return array_values(array_unique($ids));
}

function _prCanDm($db, $me, $targetId) {
    return in_array((int)$targetId, _prGetPermittedContactIds($db, $me), true);
}

/**
 * Notify a recipient of a new message.
 * Routes through pulse_alerts for admin/teacher (since their bell reads pulse_alert_recipients)
 * and through the notifications table for parents.
 */
function _prInsertNotification($db, $recipientId, $title, $body, $senderId = 0) {
    $userRow = $db->queryOne("SELECT role FROM users WHERE id=:id",[':id'=>$recipientId]);
    $role    = $userRow ? $userRow['role'] : 'parent';

    if (in_array($role, ['admin','teacher'], true)) {
        // Admin/teacher bell reads pulse_alert_recipients
        try {
            $targetRole = $role; // 'admin' or 'teacher' — matches pulse_alerts.target_role ENUM
            $aid = $db->execute(
                "INSERT INTO pulse_alerts
                    (sender_id, title, body, priority, target_type, target_role, target_user_id, created_at)
                 VALUES (:sid, :t, :b, 'medium', 'user', :tr, :uid, NOW())",
                [':sid'=>$senderId, ':t'=>$title, ':b'=>$body,
                 ':tr'=>$targetRole, ':uid'=>$recipientId]
            );
            if ($aid) {
                $db->execute(
                    "INSERT IGNORE INTO pulse_alert_recipients (alert_id, user_id, is_read) VALUES (:aid, :uid, 0)",
                    [':aid'=>$aid, ':uid'=>$recipientId]
                );
            }
        } catch (Exception $e) { error_log('_prInsertNotification pulse: '.$e->getMessage()); }
    }

    // Also write to notifications table (parent bell + legacy display code).
    try {
        $db->execute(
            "INSERT INTO notifications (user_id, title, message, type, is_read, created_at) VALUES (:uid,:t,:b,'message',0,NOW())",
            [':uid'=>$recipientId, ':t'=>$title, ':b'=>$body]
        );
    } catch (Exception $e) { error_log('_prInsertNotification notif: '.$e->getMessage()); }
}

function _prAttachDmFiles($db, array &$messages) {
    if (empty($messages)) return;
    $ids = array_filter(array_column($messages, 'id'));
    if (empty($ids)) return;
    $ph = implode(',', array_fill(0, count($ids), '?'));
    try {
        $files = $db->query(
            "SELECT message_id, original_name, stored_name, mime_type, file_size
             FROM message_files WHERE message_id IN ($ph)",
            array_values($ids)
        ) ?: [];
    } catch (\Exception $e) { $files = []; }
    $fmap = [];
    foreach ($files as $f) {
        $fmap[$f['message_id']][] = [
            'original_name' => $f['original_name'],
            'mime_type'     => $f['mime_type'],
            'file_size'     => (int)$f['file_size'],
            'url'           => '/nsms/uploads/messages/' . $f['stored_name'],
        ];
    }
    foreach ($messages as &$m) { $m['files'] = $fmap[$m['id']] ?? []; }
    unset($m);
}

/**
 * Attaches a compact reaction summary to each message — mirrors
 * pulse-api.php's _attachReactions() so parents and staff see identical
 * reaction behavior on the same underlying messages/message_reactions data.
 */
function _prAttachReactions($db, array &$messages, $me) {
    if (empty($messages)) return;
    $ids = array_filter(array_column($messages, 'id'));
    if (empty($ids)) return;
    $ph = implode(',', array_fill(0, count($ids), '?'));
    try {
        $rows = $db->query(
            "SELECT message_id, emoji, user_id FROM message_reactions WHERE message_id IN ($ph)",
            array_values($ids)
        ) ?: [];
    } catch (\Exception $e) { $rows = []; }

    $map = [];
    foreach ($rows as $r) {
        $mid = $r['message_id']; $emoji = $r['emoji'];
        if (!isset($map[$mid])) $map[$mid] = [];
        if (!isset($map[$mid][$emoji])) $map[$mid][$emoji] = ['emoji' => $emoji, 'count' => 0, 'mine' => false];
        $map[$mid][$emoji]['count']++;
        if ((int)$r['user_id'] === (int)$me) $map[$mid][$emoji]['mine'] = true;
    }
    foreach ($messages as &$m) { $m['reactions'] = isset($map[$m['id']]) ? array_values($map[$m['id']]) : []; }
    unset($m);
}

/**
 * For any message with deleted_at set, blanks its text/files/reactions
 * and marks is_deleted=true — same masking rule as pulse-api.php, so a
 * deleted message looks identical from either side of the conversation.
 */
function _prMaskDeletedMessages(array &$messages) {
    foreach ($messages as &$m) {
        $m['is_deleted'] = !empty($m['deleted_at']);
        if ($m['is_deleted']) {
            $m['message']   = null;
            $m['files']     = [];
            $m['reactions'] = [];
        }
    }
    unset($m);
}

/**
 * Adds the columns/table the modern messaging features need, on first
 * use. Shares the exact same messages/message_reactions schema as
 * pulse-api.php — whichever of the two files runs first for a given
 * installation creates it; the other's ALTER/CREATE calls are then
 * silent no-ops.
 */
function _prEnsureModernSchema($db) {
    try { $db->execute("ALTER TABLE messages ADD COLUMN edited_at DATETIME NULL"); } catch (\Exception $e) { /* already exists */ }
    try { $db->execute("ALTER TABLE messages ADD COLUMN deleted_at DATETIME NULL"); } catch (\Exception $e) { /* already exists */ }
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS message_reactions (
                id int UNSIGNED NOT NULL AUTO_INCREMENT,
                message_id int NOT NULL,
                user_id int NOT NULL,
                emoji varchar(16) NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_reaction (message_id, user_id, emoji)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (\Exception $e) { /* non-fatal */ }
}

function prToggleReaction($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $messageId = isset($body['message_id']) ? (int)$body['message_id'] : 0;
    $emoji     = isset($body['emoji']) ? trim($body['emoji']) : '';
    if (!$messageId || $emoji === '') { ob_end_clean(); errorResponse('message_id and emoji required'); }

    $msg = $db->queryOne("SELECT id, sender_id, recipient_id FROM messages WHERE id = :id", [':id' => $messageId]);
    if (!$msg || ((int)$msg['sender_id'] !== $me && (int)$msg['recipient_id'] !== $me)) {
        ob_end_clean(); errorResponse('Message not found', 404);
    }

    $existing = $db->queryOne(
        "SELECT id FROM message_reactions WHERE message_id = :mid AND user_id = :uid AND emoji = :e",
        [':mid' => $messageId, ':uid' => $me, ':e' => $emoji]
    );
    if ($existing) {
        $db->execute("DELETE FROM message_reactions WHERE id = :id", [':id' => $existing['id']]);
        $action = 'removed';
    } else {
        $db->execute(
            "INSERT INTO message_reactions (message_id, user_id, emoji, created_at) VALUES (:mid, :uid, :e, NOW())",
            [':mid' => $messageId, ':uid' => $me, ':e' => $emoji]
        );
        $action = 'added';
    }
    ob_end_clean(); successResponse(['action' => $action, 'emoji' => $emoji], 'OK');
}

/**
 * Edit within a 15-minute window of sending — same rule as pulse-api.php.
 */
function prEditMessage($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $messageId  = isset($body['message_id']) ? (int)$body['message_id'] : 0;
    $newMessage = isset($body['message']) ? trim($body['message']) : '';
    if (!$messageId) { ob_end_clean(); errorResponse('message_id required'); }
    if ($newMessage === '') { ob_end_clean(); errorResponse('Message cannot be empty'); }

    $msg = $db->queryOne("SELECT id, sender_id, created_at, deleted_at FROM messages WHERE id = :id", [':id' => $messageId]);
    if (!$msg || (int)$msg['sender_id'] !== $me) { ob_end_clean(); errorResponse('Message not found', 404); }
    if ($msg['deleted_at']) { ob_end_clean(); errorResponse('Cannot edit a deleted message'); }
    if (strtotime($msg['created_at']) < strtotime('-15 minutes')) {
        ob_end_clean(); errorResponse('This message is too old to edit (15-minute window)');
    }

    $db->execute("UPDATE messages SET message = :msg, edited_at = NOW() WHERE id = :id", [':msg' => $newMessage, ':id' => $messageId]);
    ob_end_clean(); successResponse(['id' => $messageId, 'message' => $newMessage], 'Message updated');
}

/**
 * Soft-delete — same placeholder approach as pulse-api.php.
 */
function prDeleteMessage($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    $messageId = isset($body['message_id']) ? (int)$body['message_id'] : 0;
    if (!$messageId) { ob_end_clean(); errorResponse('message_id required'); }

    $msg = $db->queryOne("SELECT id, sender_id FROM messages WHERE id = :id", [':id' => $messageId]);
    if (!$msg || (int)$msg['sender_id'] !== $me) { ob_end_clean(); errorResponse('Message not found', 404); }

    $db->execute("UPDATE messages SET deleted_at = NOW() WHERE id = :id", [':id' => $messageId]);
    try { $db->execute("DELETE FROM message_reactions WHERE message_id = :id", [':id' => $messageId]); } catch (\Exception $e) {}

    ob_end_clean(); successResponse(['id' => $messageId], 'Message deleted');
}

function _prAttachGroupFiles($db, array &$messages) {
    if (empty($messages)) return;
    $ids = array_filter(array_column($messages, 'id'));
    if (empty($ids)) return;
    $ph = implode(',', array_fill(0, count($ids), '?'));
    try {
        $files = $db->query(
            "SELECT message_id, original_name, stored_name, mime_type, file_size
             FROM pulse_group_files WHERE message_id IN ($ph)",
            array_values($ids)
        ) ?: [];
    } catch (\Exception $e) { $files = []; }
    $fmap = [];
    foreach ($files as $f) {
        $fmap[$f['message_id']][] = [
            'original_name' => $f['original_name'],
            'mime_type'     => $f['mime_type'],
            'file_size'     => (int)$f['file_size'],
            'url'           => '/nsms/uploads/group_files/' . $f['stored_name'],
        ];
    }
    foreach ($messages as &$m) { $m['files'] = $fmap[$m['id']] ?? []; }
    unset($m);
}

/* ════════════════════════════════════════════════════════
   WHO AM I
════════════════════════════════════════════════════════ */
function prWhoAmI($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $u  = $db->queryOne("SELECT id, full_name, role, photo_url, email FROM users WHERE id=:id",[':id'=>$me]);
    if (!$u) { ob_end_clean(); errorResponse('User not found', 404); }
    ob_end_clean(); successResponse($u);
}

/* ════════════════════════════════════════════════════════
   CONVERSATIONS
════════════════════════════════════════════════════════ */
function prConversations($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $permitted = _prGetPermittedContactIds($db, $me);
    if (empty($permitted)) { ob_end_clean(); successResponse([]); return; }
    $ph = implode(',', array_fill(0, count($permitted), '?'));
    $p  = array_values($permitted);
    /* Build in-list safely using positional params */
    $rows = $db->query(
        "SELECT u.id, u.full_name, u.role, u.photo_url,
                (SELECT m2.message FROM messages m2
                 WHERE (m2.sender_id=u.id AND m2.recipient_id={$me}) OR (m2.sender_id={$me} AND m2.recipient_id=u.id)
                 ORDER BY m2.created_at DESC LIMIT 1) AS last_message,
                (SELECT m3.created_at FROM messages m3
                 WHERE (m3.sender_id=u.id AND m3.recipient_id={$me}) OR (m3.sender_id={$me} AND m3.recipient_id=u.id)
                 ORDER BY m3.created_at DESC LIMIT 1) AS last_at,
                (SELECT COUNT(*) FROM messages m4
                 WHERE m4.sender_id=u.id AND m4.recipient_id={$me} AND m4.is_read=0) AS unread_count
         FROM users u
         WHERE u.id IN ($ph)
           AND EXISTS (
               SELECT 1 FROM messages mx
               WHERE (mx.sender_id=u.id AND mx.recipient_id={$me})
                  OR (mx.sender_id={$me} AND mx.recipient_id=u.id)
           )
         ORDER BY last_at DESC",
        $p
    ) ?: [];
    foreach ($rows as &$r) { $r['is_online'] = _prIsOnline($db, $r['id']); }
    unset($r);
    ob_end_clean(); successResponse($rows);
}

/* ════════════════════════════════════════════════════════
   THREAD
════════════════════════════════════════════════════════ */
function prThread($db) {
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $cid = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$cid) { ob_end_clean(); errorResponse('contact_id required'); }
    if (!_prCanDm($db, $me, $cid)) { ob_end_clean(); errorResponse('Not permitted to message this contact', 403); }
    $contact = $db->queryOne("SELECT id, full_name, role, photo_url FROM users WHERE id=:cid",[':cid'=>$cid]);
    if (!$contact) { ob_end_clean(); errorResponse('Contact not found', 404); }
    $msgs = $db->query(
        "SELECT m.id, m.sender_id, m.recipient_id, m.message, m.is_read, m.has_file,
                m.reply_to_id, m.created_at, m.edited_at, m.deleted_at,
                rm.message AS reply_to_message,
                ru.full_name AS reply_to_sender
         FROM messages m
         LEFT JOIN messages rm ON rm.id = m.reply_to_id
         LEFT JOIN users   ru ON ru.id  = rm.sender_id
         WHERE (m.sender_id=:me1 AND m.recipient_id=:c1) OR (m.sender_id=:c2 AND m.recipient_id=:me2)
         ORDER BY m.created_at ASC",
        [':me1'=>$me,':c1'=>$cid,':c2'=>$cid,':me2'=>$me]
    ) ?: [];
    _prAttachDmFiles($db, $msgs);
    _prAttachReactions($db, $msgs, $me);
    _prMaskDeletedMessages($msgs);
    $typRow = $db->queryOne(
        "SELECT is_typing FROM typing_status WHERE user_id=:cid AND contact_id=:me AND updated_at >= DATE_SUB(NOW(), INTERVAL 8 SECOND)",
        [':cid'=>$cid,':me'=>$me]
    );
    ob_end_clean(); successResponse([
        'messages'  => $msgs,
        'contact'   => $contact,
        'is_online' => _prIsOnline($db, $cid),
        'is_typing' => $typRow ? (bool)$typRow['is_typing'] : false,
    ]);
}

/* ════════════════════════════════════════════════════════
   THREAD UPDATES (polling)
════════════════════════════════════════════════════════ */
function prThreadUpdates($db) {
    $me     = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $cid    = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    $sinceId= isset($_GET['since_id'])   ? (int)$_GET['since_id']   : 0;
    if (!$cid) { ob_end_clean(); errorResponse('contact_id required'); }
    $new = $db->query(
        "SELECT m.id, m.sender_id, m.recipient_id, m.message, m.is_read, m.has_file,
                m.reply_to_id, m.created_at, m.edited_at, m.deleted_at,
                rm.message AS reply_to_message,
                ru.full_name AS reply_to_sender
         FROM messages m
         LEFT JOIN messages rm ON rm.id = m.reply_to_id
         LEFT JOIN users   ru ON ru.id  = rm.sender_id
         WHERE m.id > :sid AND ((m.sender_id=:me1 AND m.recipient_id=:c1) OR (m.sender_id=:c2 AND m.recipient_id=:me2))
         ORDER BY m.created_at ASC",
        [':sid'=>$sinceId,':me1'=>$me,':c1'=>$cid,':c2'=>$cid,':me2'=>$me]
    ) ?: [];
    _prAttachDmFiles($db, $new);
    _prAttachReactions($db, $new, $me);
    _prMaskDeletedMessages($new);
    $typRow = $db->queryOne(
        "SELECT is_typing FROM typing_status WHERE user_id=:cid AND contact_id=:me AND updated_at >= DATE_SUB(NOW(), INTERVAL 8 SECOND)",
        [':cid'=>$cid,':me'=>$me]
    );
    ob_end_clean(); successResponse([
        'new_messages' => $new,
        'is_online'    => _prIsOnline($db, $cid),
        'is_typing'    => $typRow ? (bool)$typRow['is_typing'] : false,
    ]);
}

/* ════════════════════════════════════════════════════════
   CONTACTS — scoped, grouped by type
════════════════════════════════════════════════════════ */
function prContacts($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }

    /* Admins */
    $admins = $db->query(
        "SELECT id, full_name, role, photo_url FROM users WHERE role='admin' ORDER BY full_name",
        []
    ) ?: [];

    /*
     * Teachers of this parent's own (active) children's classes.
     *
     * Bug fix: this used to join through class_teachers/student_parents —
     * two tables that exist in the schema but were never actually
     * populated (zero rows). Every parent except the school admin was
     * silently unreachable as a result. The real, populated tables are
     * classes.teacher_id (one teacher per class, set directly on the
     * class) and parents (student_id/user_id, used everywhere else in
     * NSMS — fee payments, emergency contacts, promotions, etc.).
     */
    $teachers = $db->query(
        "SELECT DISTINCT u.id, u.full_name, u.role, u.photo_url, c.class_name
           FROM parents p
           JOIN students s ON s.id = p.student_id
           JOIN classes  c ON c.id = s.class_id
           JOIN users    u ON u.id = c.teacher_id
          WHERE p.user_id = :me AND s.status = 'active' AND c.teacher_id IS NOT NULL
          ORDER BY c.class_name, u.full_name",
        [':me' => $me]
    ) ?: [];

    /* Co-parents sharing any class — include shared class name for context */
    $coParents = $db->query(
        "SELECT DISTINCT u.id, u.full_name, u.role, u.photo_url,
                c.class_name AS shared_class
           FROM parents p1
           JOIN students s1 ON s1.id = p1.student_id AND s1.status = 'active'
           JOIN classes  c  ON c.id  = s1.class_id
           JOIN students s2 ON s2.class_id = s1.class_id AND s2.status = 'active'
           JOIN parents p2  ON p2.student_id = s2.id
           JOIN users    u  ON u.id  = p2.user_id
          WHERE p1.user_id = :me AND u.id != :me2
          ORDER BY c.class_name, u.full_name",
        [':me' => $me, ':me2' => $me]
    ) ?: [];

    foreach ($admins    as &$r) { $r['is_online'] = _prIsOnline($db, $r['id']); $r['contact_group'] = 'admin'; }
    foreach ($teachers  as &$r) { $r['is_online'] = _prIsOnline($db, $r['id']); $r['contact_group'] = 'teacher'; }
    foreach ($coParents as &$r) { $r['is_online'] = _prIsOnline($db, $r['id']); $r['contact_group'] = 'parent'; }
    unset($r);

    ob_end_clean(); successResponse([
        'admins'    => $admins,
        'teachers'  => $teachers,
        'coParents' => $coParents,
    ]);
}

/* ════════════════════════════════════════════════════════
   TYPING / MARK READ / HEARTBEAT
════════════════════════════════════════════════════════ */
function prTypingStatus($db) {
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $cid = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$cid) { ob_end_clean(); errorResponse('contact_id required'); }
    $r = $db->queryOne(
        "SELECT is_typing FROM typing_status WHERE user_id=:cid AND contact_id=:me AND updated_at >= DATE_SUB(NOW(), INTERVAL 8 SECOND)",
        [':cid'=>$cid,':me'=>$me]
    );
    ob_end_clean(); successResponse(['is_typing' => $r ? (bool)$r['is_typing'] : false]);
}

function prMarkRead($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $cid = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$cid) { ob_end_clean(); errorResponse('contact_id required'); }
    $db->execute("UPDATE messages SET is_read=1 WHERE sender_id=:cid AND recipient_id=:me AND is_read=0",[':cid'=>$cid,':me'=>$me]);
    ob_end_clean(); successResponse(null, 'Marked read');
}

function prSetTyping($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $cid = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    $b   = json_decode(file_get_contents('php://input'), true) ?: [];
    $it  = isset($b['is_typing']) ? (int)$b['is_typing'] : 0;
    if (!$me || !$cid) { ob_end_clean(); errorResponse('contact_id required'); }
    $db->execute(
        "INSERT INTO typing_status (user_id,contact_id,target_id,is_typing,updated_at) VALUES (:me,:cid,:cid2,:it,NOW())
         ON DUPLICATE KEY UPDATE is_typing=:it2, updated_at=NOW()",
        [':me'=>$me,':cid'=>$cid,':cid2'=>$cid,':it'=>$it,':it2'=>$it]
    );
    ob_end_clean(); successResponse(null);
}

function prHeartbeat($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    _prPresence($db); ob_end_clean(); successResponse(null);
}

/* ════════════════════════════════════════════════════════
   SEND / SEND FILE
════════════════════════════════════════════════════════ */
function prSend($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me   = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $b       = json_decode(file_get_contents('php://input'), true) ?: [];
    $rid     = isset($b['recipient_id']) ? (int)$b['recipient_id'] : 0;
    $msg     = isset($b['message'])      ? trim($b['message'])      : '';
    $replyId = isset($b['reply_to_id'])  ? (int)$b['reply_to_id']  : 0;
    if (!$rid || !$msg) { ob_end_clean(); errorResponse('recipient_id and message required'); }
    if (!_prCanDm($db, $me, $rid)) { ob_end_clean(); errorResponse('Not permitted to message this person', 403); }
    $mid = $db->execute(
        "INSERT INTO messages (sender_id, recipient_id, message, is_read, has_file, reply_to_id, created_at) VALUES (:s,:r,:m,0,0,:rp,NOW())",
        [':s'=>$me,':r'=>$rid,':m'=>sanitize($msg),':rp'=>($replyId ?: null)]
    );
    if (!$mid) { ob_end_clean(); errorResponse('Failed to send', 500); }
    // Clear typing indicator
    $db->execute(
        "INSERT INTO typing_status (user_id,contact_id,target_id,is_typing,updated_at) VALUES (:me,:rid,:rid2,0,NOW())
         ON DUPLICATE KEY UPDATE is_typing=0, updated_at=NOW()",
        [':me'=>$me,':rid'=>$rid,':rid2'=>$rid]
    );
    // Notify recipient — route through pulse_alerts for admin/teacher, notifications for parent
    $senderRow = $db->queryOne("SELECT full_name, role FROM users WHERE id=:id",[':id'=>$me]);
    $sName = $senderRow ? $senderRow['full_name'] : 'Parent';
    _prInsertNotification($db, $rid, "New message from {$sName}", mb_substr($msg, 0, 100), $me);

    $newMsg = $db->queryOne("SELECT id, sender_id, recipient_id, message, is_read, created_at FROM messages WHERE id=:id",[':id'=>$mid]);
    $newMsg['files'] = [];
    $newMsg['edited_at'] = null; $newMsg['deleted_at'] = null; $newMsg['is_deleted'] = false; $newMsg['reactions'] = [];
    ob_end_clean(); successResponse($newMsg, 'Message sent');
}

function prSendFile($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rid     = isset($_POST['recipient_id']) ? (int)$_POST['recipient_id'] : 0;
    $msg     = isset($_POST['message'])      ? trim($_POST['message'])      : '';
    $replyId = isset($_POST['reply_to_id'])  ? (int)$_POST['reply_to_id']  : 0;
    if (!$rid) { ob_end_clean(); errorResponse('recipient_id required'); }
    if (!_prCanDm($db, $me, $rid)) { ob_end_clean(); errorResponse('Not permitted', 403); }
    $mid = $db->execute(
        "INSERT INTO messages (sender_id, recipient_id, message, is_read, has_file, reply_to_id, created_at) VALUES (:s,:r,:m,0,1,:rp,NOW())",
        [':s'=>$me,':r'=>$rid,':m'=>sanitize($msg),':rp'=>($replyId ?: null)]
    );
    if (!$mid) { ob_end_clean(); errorResponse('Failed', 500); }
    $fileData = [];
    if (!empty($_FILES['attachment']['tmp_name'])) {
        $file = $_FILES['attachment']; $orig = sanitize($file['name']);
        $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','pdf','doc','docx','xls','xlsx','txt'])) {
            $stored = uniqid('msg_', true).'.'.$ext;
            $dir    = dirname(__DIR__).'/uploads/messages/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            if (move_uploaded_file($file['tmp_name'], $dir.$stored)) {
                $db->execute("INSERT INTO message_files (message_id,original_name,stored_name,mime_type,file_size) VALUES (:mid,:on,:sn,:mt,:fs)",
                    [':mid'=>$mid,':on'=>$orig,':sn'=>$stored,':mt'=>$file['type'],':fs'=>$file['size']]);
                $fileData = [['original_name'=>$orig,'mime_type'=>$file['type'],'file_size'=>$file['size'],'url'=>'/nsms/uploads/messages/'.$stored]];
            }
        }
    }
    $newMsg = $db->queryOne("SELECT id, sender_id, recipient_id, message, is_read, created_at FROM messages WHERE id=:id",[':id'=>$mid]);
    $newMsg['files'] = $fileData;
    $newMsg['edited_at'] = null; $newMsg['deleted_at'] = null; $newMsg['is_deleted'] = false; $newMsg['reactions'] = [];
    // Notify recipient
    $senderRow = $db->queryOne("SELECT full_name FROM users WHERE id=:id",[':id'=>$me]);
    $sName = $senderRow ? $senderRow['full_name'] : 'Parent';
    $fname = !empty($fileData) ? $fileData[0]['original_name'] : 'file';
    _prInsertNotification($db, $rid, "File from {$sName}", "\xf0\x9f\x93\x8e {$fname}", $me);
    ob_end_clean(); successResponse($newMsg, 'File sent');
}

/* ════════════════════════════════════════════════════════
   COLLABORATION HUB
════════════════════════════════════════════════════════ */
function prMyGroups($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT g.id, g.name, g.description, g.avatar_color, g.created_at, gm.group_role,
                (SELECT COUNT(*) FROM pulse_group_members gm2 WHERE gm2.group_id=g.id) AS member_count
         FROM pulse_groups g
         JOIN pulse_group_members gm ON gm.group_id=g.id AND gm.user_id=:me
         ORDER BY g.name ASC",
        [':me' => $me]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function prAvailableGroups($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT g.id, g.name, g.description, g.avatar_color,
                (SELECT COUNT(*) FROM pulse_group_members gm2 WHERE gm2.group_id=g.id) AS member_count,
                (SELECT COUNT(*) FROM pulse_group_members gm3 WHERE gm3.group_id=g.id AND gm3.user_id=:me1) AS is_member
         FROM pulse_groups g
         ORDER BY g.name ASC",
        [':me1' => $me]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function prGroupThread($db) {
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $mem = $db->queryOne("SELECT group_role FROM pulse_group_members WHERE group_id=:gid AND user_id=:me",[':gid'=>$gid,':me'=>$me]);
    if (!$mem) { ob_end_clean(); errorResponse('Not a group member', 403); }
    $grp = $db->queryOne("SELECT id, name, description, avatar_color FROM pulse_groups WHERE id=:gid",[':gid'=>$gid]);
    $msgs = $db->query(
        "SELECT m.id, m.sender_id, m.message, m.created_at, u.full_name AS sender_name, u.photo_url AS sender_photo
         FROM pulse_group_messages m JOIN users u ON u.id=m.sender_id
         WHERE m.group_id=:gid ORDER BY m.created_at ASC",
        [':gid'=>$gid]
    ) ?: [];
    _prAttachGroupFiles($db, $msgs);
    ob_end_clean(); successResponse(['group'=>$grp,'messages'=>$msgs]);
}

function prGroupThreadUpdates($db) {
    $me     = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid    = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    $sinceId= isset($_GET['since_id']) ? (int)$_GET['since_id'] : 0;
    if (!$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $new = $db->query(
        "SELECT m.id, m.sender_id, m.message, m.created_at, u.full_name AS sender_name, u.photo_url AS sender_photo
         FROM pulse_group_messages m JOIN users u ON u.id=m.sender_id
         WHERE m.group_id=:gid AND m.id > :sid ORDER BY m.created_at ASC",
        [':gid'=>$gid,':sid'=>$sinceId]
    ) ?: [];
    _prAttachGroupFiles($db, $new);
    ob_end_clean(); successResponse(['messages'=>$new]);
}

function prGroupMembers($db) {
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $rows = $db->query(
        "SELECT u.id, u.full_name, u.role, u.photo_url, gm.group_role, gm.joined_at
         FROM pulse_group_members gm JOIN users u ON u.id=gm.user_id
         WHERE gm.group_id=:gid ORDER BY gm.group_role='owner' DESC, u.full_name ASC",
        [':gid'=>$gid]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function prResources($db) {
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $rows = $db->query(
        "SELECT r.id, r.title, r.description, r.stored_name, r.original_name, r.mime_type, r.file_size, r.created_at,
                u.full_name AS shared_by_name
         FROM group_resources r JOIN users u ON u.id=r.uploaded_by
         WHERE r.group_id=:gid ORDER BY r.created_at DESC",
        [':gid'=>$gid]
    ) ?: [];
    foreach ($rows as &$r) { $r['url'] = '/nsms/uploads/group_resources/' . $r['stored_name']; }
    unset($r);
    ob_end_clean(); successResponse($rows);
}

function prCreateGroup($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me   = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $b    = json_decode(file_get_contents('php://input'), true) ?: [];
    $name = isset($b['name'])        ? sanitize($b['name'])        : '';
    $desc = isset($b['description']) ? sanitize($b['description']) : '';
    $color= isset($b['color'])       ? $b['color']                 : '#10B981';
    if (!$name) { ob_end_clean(); errorResponse('Group name required'); }
    $gid = $db->execute(
        "INSERT INTO pulse_groups (name, description, avatar_color, created_by, created_at) VALUES (:n,:d,:c,:me,NOW())",
        [':n'=>$name,':d'=>$desc,':c'=>$color,':me'=>$me]
    );
    if (!$gid) { ob_end_clean(); errorResponse('Failed to create group', 500); }
    $db->execute(
        "INSERT INTO pulse_group_members (group_id, user_id, group_role, joined_at) VALUES (:gid,:me,'owner',NOW())",
        [':gid'=>$gid,':me'=>$me]
    );
    ob_end_clean(); successResponse(['id'=>$gid,'name'=>$name], 'Group created');
}

function prJoinGroup($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$me || !$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $db->execute(
        "INSERT IGNORE INTO pulse_group_members (group_id, user_id, group_role, joined_at) VALUES (:gid,:me,'member',NOW())",
        [':gid'=>$gid,':me'=>$me]
    );
    ob_end_clean(); successResponse(null, 'Joined');
}

function prLeaveGroup($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$me || !$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $db->execute(
        "DELETE FROM pulse_group_members WHERE group_id=:gid AND user_id=:me AND group_role!='owner'",
        [':gid'=>$gid,':me'=>$me]
    );
    ob_end_clean(); successResponse(null, 'Left group');
}

function prMarkGroupRead($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
    if (!$me || !$gid) { ob_end_clean(); errorResponse('group_id required'); }
    /* Verify membership before marking read */
    $mem = $db->queryOne(
        "SELECT group_role FROM pulse_group_members WHERE group_id=:gid AND user_id=:me",
        [':gid'=>$gid,':me'=>$me]
    );
    if (!$mem) { ob_end_clean(); errorResponse('Not a group member', 403); }
    try {
        $db->execute(
            "INSERT INTO pulse_group_message_reads (group_id, user_id, last_read_at)
             VALUES (:gid, :me, NOW())
             ON DUPLICATE KEY UPDATE last_read_at = NOW()",
            [':gid'=>$gid,':me'=>$me]
        );
    } catch (\Exception $e) { /* table may not exist yet — silent fail */ }
    ob_end_clean(); successResponse(null, 'Marked read');
}

function prGroupSend($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me   = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $b    = json_decode(file_get_contents('php://input'), true) ?: [];
    $gid  = isset($b['group_id']) ? (int)$b['group_id'] : 0;
    $msg  = isset($b['message'])  ? trim($b['message'])  : '';
    if (!$gid || !$msg) { ob_end_clean(); errorResponse('group_id and message required'); }
    $mem  = $db->queryOne("SELECT group_role FROM pulse_group_members WHERE group_id=:gid AND user_id=:me",[':gid'=>$gid,':me'=>$me]);
    if (!$mem) { ob_end_clean(); errorResponse('Not a group member', 403); }
    $mid  = $db->execute(
        "INSERT INTO pulse_group_messages (group_id, sender_id, message, created_at) VALUES (:gid,:me,:msg,NOW())",
        [':gid'=>$gid,':me'=>$me,':msg'=>sanitize($msg)]
    );
    if (!$mid) { ob_end_clean(); errorResponse('Failed to send', 500); }
    $info = $db->queryOne("SELECT full_name, photo_url FROM users WHERE id=:me",[':me'=>$me]);
    ob_end_clean(); successResponse([
        'id'=>$mid,'sender_id'=>$me,'message'=>sanitize($msg),
        'sender_name'=>$info['full_name'],'sender_photo'=>$info['photo_url'],
        'created_at'=>date('Y-m-d H:i:s'),'files'=>[]
    ], 'Sent');
}

function prGroupSendFile($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid = isset($_POST['group_id']) ? (int)$_POST['group_id'] : 0;
    $msg = isset($_POST['message'])  ? trim($_POST['message'])  : '';
    if (!$gid) { ob_end_clean(); errorResponse('group_id required'); }
    $mem = $db->queryOne("SELECT group_role FROM pulse_group_members WHERE group_id=:gid AND user_id=:me",[':gid'=>$gid,':me'=>$me]);
    if (!$mem) { ob_end_clean(); errorResponse('Not a group member', 403); }
    $mid = $db->execute(
        "INSERT INTO pulse_group_messages (group_id, sender_id, message, created_at) VALUES (:gid,:me,:msg,NOW())",
        [':gid'=>$gid,':me'=>$me,':msg'=>sanitize($msg)]
    );
    if (!$mid) { ob_end_clean(); errorResponse('Failed', 500); }
    $fileData = [];
    if (!empty($_FILES['attachment']['tmp_name'])) {
        $file = $_FILES['attachment']; $orig = sanitize($file['name']);
        $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','pdf','doc','docx','xls','xlsx','txt','pptx'])) {
            $stored = uniqid('grp_', true).'.'.$ext;
            $dir    = dirname(__DIR__).'/uploads/group_files/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            if (move_uploaded_file($file['tmp_name'], $dir.$stored)) {
                $db->execute("INSERT INTO pulse_group_files (message_id,original_name,stored_name,mime_type,file_size) VALUES (:mid,:on,:sn,:mt,:fs)",
                    [':mid'=>$mid,':on'=>$orig,':sn'=>$stored,':mt'=>$file['type'],':fs'=>$file['size']]);
                $fileData = [['original_name'=>$orig,'mime_type'=>$file['type'],'file_size'=>$file['size'],'url'=>'/nsms/uploads/group_files/'.$stored]];
            }
        }
    }
    $info = $db->queryOne("SELECT full_name, photo_url FROM users WHERE id=:me",[':me'=>$me]);
    ob_end_clean(); successResponse([
        'id'=>$mid,'sender_id'=>$me,'message'=>sanitize($msg),
        'sender_name'=>$info['full_name'],'sender_photo'=>$info['photo_url'],
        'created_at'=>date('Y-m-d H:i:s'),'files'=>$fileData
    ]);
}

function prUploadResource($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me    = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $gid   = isset($_POST['group_id'])    ? (int)$_POST['group_id']        : 0;
    $title = isset($_POST['title'])       ? sanitize($_POST['title'])       : '';
    $desc  = isset($_POST['description']) ? sanitize($_POST['description']) : '';
    if (!$gid || !$title) { ob_end_clean(); errorResponse('group_id and title required'); }
    $mem = $db->queryOne("SELECT group_role FROM pulse_group_members WHERE group_id=:gid AND user_id=:me",[':gid'=>$gid,':me'=>$me]);
    if (!$mem) { ob_end_clean(); errorResponse('Not a group member', 403); }
    if (empty($_FILES['attachment']['tmp_name'])) { ob_end_clean(); errorResponse('File required'); }
    $file   = $_FILES['attachment']; $orig = sanitize($file['name']);
    $ext    = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','pdf','doc','docx','xls','xlsx','txt','pptx','zip'])) {
        ob_end_clean(); errorResponse('File type not allowed');
    }
    $stored = uniqid('res_', true).'.'.$ext;
    $dir    = dirname(__DIR__).'/uploads/group_resources/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    if (!move_uploaded_file($file['tmp_name'], $dir.$stored)) { ob_end_clean(); errorResponse('Upload failed', 500); }
    $rid = $db->execute(
        "INSERT INTO group_resources (group_id, uploaded_by, title, description, stored_name, original_name, mime_type, file_size, created_at)
         VALUES (:gid,:me,:t,:d,:sn,:on,:mt,:fs,NOW())",
        [':gid'=>$gid,':me'=>$me,':t'=>$title,':d'=>$desc,':sn'=>$stored,':on'=>$orig,':mt'=>$file['type'],':fs'=>$file['size']]
    );
    ob_end_clean(); successResponse(['id'=>$rid], 'Resource shared');
}

/* ════════════════════════════════════════════════════════
   ALERTS (receive-only)
════════════════════════════════════════════════════════ */
function prMyAlerts($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT a.id, a.title, a.body, a.priority, a.created_at,
                u.full_name AS sender_name, u.role AS sender_role, u.photo_url AS sender_photo,
                COALESCE(r.is_read,0) AS is_read, r.read_at
         FROM pulse_alerts a
         JOIN pulse_alert_recipients r ON r.alert_id=a.id AND r.user_id=:me
         JOIN users u ON u.id=a.sender_id
         ORDER BY a.created_at DESC",
        [':me' => $me]
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function prMarkAlertRead($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me  = _me(); $aid = isset($_GET['alert_id']) ? (int)$_GET['alert_id'] : 0;
    if (!$me || !$aid) { ob_end_clean(); errorResponse('alert_id required'); }
    $db->execute(
        "UPDATE pulse_alert_recipients SET is_read=1, read_at=NOW() WHERE alert_id=:aid AND user_id=:me AND is_read=0",
        [':aid'=>$aid,':me'=>$me]
    );
    ob_end_clean(); successResponse(null, 'Marked read');
}

/* ════════════════════════════════════════════════════════
   BROADCAST (read-only)
════════════════════════════════════════════════════════ */
function prAnnouncements($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT a.id, a.title, a.body, a.target_role, a.pinned, a.created_at, a.expires_at,
                u.full_name AS author_name, u.photo_url AS author_photo
         FROM pulse_announcements a JOIN users u ON u.id=a.author_id
         WHERE (a.target_role='all' OR a.target_role='parent')
           AND (a.expires_at IS NULL OR a.expires_at > NOW())
         ORDER BY a.pinned DESC, a.created_at DESC",
        []
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

function prNewsletters($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $rows = $db->query(
        "SELECT n.id, n.subject, n.content, n.target_role, n.created_at,
                u.full_name AS author_name, u.photo_url AS author_photo
         FROM pulse_newsletters n JOIN users u ON u.id=n.author_id
         WHERE n.target_role='all' OR n.target_role='parent'
         ORDER BY n.created_at DESC",
        []
    ) ?: [];
    ob_end_clean(); successResponse($rows);
}

/* ════════════════════════════════════════════════════════
   UNREAD COUNTS
════════════════════════════════════════════════════════ */
function prUnreadCounts($db) {
    $me = _me(); if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }
    $dm    = $db->queryOne("SELECT COUNT(*) AS cnt FROM messages WHERE recipient_id=:me AND is_read=0",[':me'=>$me]);
    $alert = $db->queryOne("SELECT COUNT(*) AS cnt FROM pulse_alert_recipients WHERE user_id=:me AND is_read=0",[':me'=>$me]);
    ob_end_clean(); successResponse([
        'dm'        => $dm    ? (int)$dm['cnt']    : 0,
        'alerts'    => $alert ? (int)$alert['cnt'] : 0,
        'collab'    => 0,
        'broadcast' => 0,
    ]);
}