<?php
/**
 * Admin Messages API
 * /nsms/api/admin-messages.php
 * PHP 7.2 compatible.
 *
 * DB additions required (run db-migration.sql once):
 *   typing_status, user_presence, message_files tables
 *   messages.has_file column
 *
 * Actions:
 *   GET  ?action=conversations                         — grouped conversation list
 *   GET  ?action=thread&contact_id=X                   — full thread + updates own presence
 *   GET  ?action=thread_updates&contact_id=X&since_id=N — only messages with id > N (efficient poll)
 *   GET  ?action=contacts                              — all teachers + parents + other admins
 *   GET  ?action=typing_status&contact_id=X            — is contact X currently typing?
 *   GET  ?action=presence&contact_id=X                 — is contact X online? (last_seen < 2 min)
 *   POST ?action=send                                  — send text message (JSON body)
 *   POST ?action=send_file                             — send message + file (multipart/form-data)
 *   POST ?action=mark_read&contact_id=X                — mark messages from X as read
 *   POST ?action=set_typing&contact_id=X               — update typing heartbeat
 *   POST ?action=heartbeat                             — update own presence timestamp
 */

ob_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { ob_end_clean(); exit(0); }

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

if (function_exists('applyApiHeaders')) { applyApiHeaders(); }


requireRole(['admin']);

$db   = new Database();
$conn = $db->connect();
if (!$conn) { ob_end_clean(); errorResponse('Database connection failed', 500); }

$action = isset($_GET['action']) ? $_GET['action'] : '';

/* Bump own presence on every request */
_updatePresence($db);

switch ($action) {
    case 'conversations':   getConversations($db);   break;
    case 'thread':          getThread($db);           break;
    case 'thread_updates':  getThreadUpdates($db);    break;
    case 'contacts':        getContacts($db);          break;
    case 'typing_status':   getTypingStatus($db);      break;
    case 'presence':        getPresence($db);          break;
    case 'send':            sendMessage($db);          break;
    case 'send_file':       sendFile($db);             break;
    case 'mark_read':       markRead($db);             break;
    case 'set_typing':      setTyping($db);            break;
    case 'heartbeat':       doHeartbeat($db);          break;
    default: ob_end_clean(); errorResponse('Invalid action');
}

/* ─────────────────────────────────────────
   HELPERS
───────────────────────────────────────── */
function myId() {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
}

function _updatePresence($db) {
    $me = myId();
    if (!$me) return;
    /* Upsert presence; ignore errors if table doesn't exist yet */
    try {
        $db->execute(
            "INSERT INTO user_presence (user_id, last_seen)
             VALUES (:uid, NOW())
             ON DUPLICATE KEY UPDATE last_seen = NOW()",
            [':uid' => $me]
        );
    } catch (\Exception $e) { /* migration not run yet — silently skip */ }
}

/* Attach file rows to a set of messages */
function _attachFiles($db, array &$messages) {
    if (empty($messages)) return;
    $ids = array_filter(array_column($messages, 'id'));
    if (empty($ids)) return;
    $ph = implode(',', array_fill(0, count($ids), '?'));
    try {
        $files = $db->query(
            "SELECT message_id, id AS file_id, original_name, stored_name, mime_type, file_size
             FROM message_files WHERE message_id IN ($ph)",
            array_values($ids)
        ) ?: [];
    } catch (\Exception $e) { $files = []; }

    $fmap = [];
    foreach ($files as $f) {
        $mid = $f['message_id'];
        if (!isset($fmap[$mid])) $fmap[$mid] = [];
        $fmap[$mid][] = [
            'file_id'       => $f['file_id'],
            'original_name' => $f['original_name'],
            'mime_type'     => $f['mime_type'],
            'file_size'     => (int)$f['file_size'],
            'url'           => '/nsms/uploads/messages/' . $f['stored_name'],
        ];
    }
    foreach ($messages as &$m) {
        $m['files'] = isset($fmap[$m['id']]) ? $fmap[$m['id']] : [];
    }
    unset($m);
}

/* ─────────────────────────────────────────
   GET CONVERSATIONS
───────────────────────────────────────── */
function getConversations($db) {
    $me = myId();
    if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }

    $rows = $db->query(
        "SELECT
             contact_id,
             MAX(created_at)  AS last_at,
             SUM(is_unread)   AS unread_count
         FROM (
             SELECT
                 CASE WHEN sender_id = :me1 THEN recipient_id ELSE sender_id END AS contact_id,
                 created_at,
                 CASE WHEN recipient_id = :me2 AND is_read = 0 THEN 1 ELSE 0 END AS is_unread
             FROM messages
             WHERE sender_id = :me3 OR recipient_id = :me4
         ) sub
         GROUP BY contact_id
         ORDER BY last_at DESC",
        [':me1' => $me, ':me2' => $me, ':me3' => $me, ':me4' => $me]
    ) ?: [];

    if (empty($rows)) { ob_end_clean(); successResponse([]); return; }

    $contactIds   = array_column($rows, 'contact_id');
    $placeholders = implode(',', array_fill(0, count($contactIds), '?'));

    $userRows = $db->query(
        "SELECT id, full_name, photo_url, role FROM users WHERE id IN ($placeholders)",
        array_values($contactIds)
    ) ?: [];
    $userMap = [];
    foreach ($userRows as $u) { $userMap[$u['id']] = $u; }

    /* Online map */
    $onlineMap = [];
    try {
        $presRows = $db->query(
            "SELECT user_id FROM user_presence
             WHERE user_id IN ($placeholders) AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)",
            array_values($contactIds)
        ) ?: [];
        foreach ($presRows as $p) { $onlineMap[$p['user_id']] = true; }
    } catch (\Exception $e) {}

    $out = [];
    foreach ($rows as $row) {
        $cid     = (int)$row['contact_id'];
        $contact = isset($userMap[$cid]) ? $userMap[$cid] : null;
        if (!$contact) continue;

        $latest = $db->queryOne(
            "SELECT message, subject, has_file FROM messages
             WHERE (sender_id = :me AND recipient_id = :cid)
                OR (sender_id = :cid2 AND recipient_id = :me2)
             ORDER BY created_at DESC LIMIT 1",
            [':me' => $me, ':cid' => $cid, ':cid2' => $cid, ':me2' => $me]
        );

        /* Role label */
        $role = $contact['role'];
        $roleLabel = 'User';
        $studentName = null;
        if ($role === 'admin')   { $roleLabel = 'Administrator'; }
        if ($role === 'teacher') { $roleLabel = 'Teacher'; }
        if ($role === 'parent')  {
            $roleLabel = 'Parent';
            $stuRow = $db->queryOne(
                "SELECT s.student_name FROM parents p
                 JOIN students s ON s.id = p.student_id
                 WHERE p.user_id = :uid LIMIT 1",
                [':uid' => $cid]
            );
            if ($stuRow) { $studentName = $stuRow['student_name']; $roleLabel = 'Parent of ' . $studentName; }
        }

        $preview = '';
        if ($latest) {
            $preview = ($latest['has_file'] && !$latest['message'])
                ? '📎 Attachment'
                : mb_substr($latest['message'], 0, 80);
        }

        $out[] = [
            'contact_id'    => $cid,
            'contact_name'  => $contact['full_name'],
            'contact_photo' => $contact['photo_url'],
            'contact_role'  => $contact['role'],
            'role_label'    => $roleLabel,
            'student_name'  => $studentName,
            'last_message'  => $preview,
            'subject'       => $latest ? $latest['subject'] : '',
            'last_at'       => $row['last_at'],
            'unread_count'  => (int)$row['unread_count'],
            'is_online'     => isset($onlineMap[$cid]),
        ];
    }

    ob_end_clean();
    successResponse($out);
}

/* ─────────────────────────────────────────
   GET THREAD
───────────────────────────────────────── */
function getThread($db) {
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    $rows = $db->query(
        "SELECT id, sender_id, recipient_id, subject, message, is_read, read_at, has_file, created_at
         FROM   messages
         WHERE  (sender_id = :me  AND recipient_id = :cid)
             OR (sender_id = :cid2 AND recipient_id = :me2)
         ORDER  BY created_at ASC",
        [':me' => $me, ':cid' => $contactId, ':cid2' => $contactId, ':me2' => $me]
    ) ?: [];

    _attachFiles($db, $rows);

    /* Contact online status */
    $isOnline = false;
    try {
        $prow = $db->queryOne(
            "SELECT 1 FROM user_presence WHERE user_id = :uid AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)",
            [':uid' => $contactId]
        );
        $isOnline = (bool)$prow;
    } catch (\Exception $e) {}

    ob_end_clean();
    successResponse(['messages' => $rows, 'contact_online' => $isOnline]);
}

/* ─────────────────────────────────────────
   GET THREAD UPDATES (incremental poll)
   Returns only messages with id > since_id
───────────────────────────────────────── */
function getThreadUpdates($db) {
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    $sinceId   = isset($_GET['since_id'])   ? (int)$_GET['since_id']   : 0;
    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    $rows = $db->query(
        "SELECT id, sender_id, recipient_id, subject, message, is_read, read_at, has_file, created_at
         FROM   messages
         WHERE  ((sender_id = :me AND recipient_id = :cid) OR (sender_id = :cid2 AND recipient_id = :me2))
           AND  id > :sid
         ORDER  BY created_at ASC",
        [':me' => $me, ':cid' => $contactId, ':cid2' => $contactId, ':me2' => $me, ':sid' => $sinceId]
    ) ?: [];

    _attachFiles($db, $rows);

    /* Also return contact's online status + typing */
    $isOnline = false; $isTyping = false;
    try {
        $prow = $db->queryOne(
            "SELECT 1 FROM user_presence WHERE user_id = :uid AND last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)",
            [':uid' => $contactId]
        );
        $isOnline = (bool)$prow;

        $trow = $db->queryOne(
            "SELECT 1 FROM typing_status
             WHERE user_id = :uid AND contact_id = :me
               AND updated_at >= DATE_SUB(NOW(), INTERVAL 5 SECOND)",
            [':uid' => $contactId, ':me' => $me]
        );
        $isTyping = (bool)$trow;
    } catch (\Exception $e) {}

    ob_end_clean();
    successResponse(['new_messages' => $rows, 'contact_online' => $isOnline, 'contact_typing' => $isTyping]);
}

/* ─────────────────────────────────────────
   GET CONTACTS
   Admin can message: other admins, all teachers, all parents
───────────────────────────────────────── */
function getContacts($db) {
    $me  = myId();
    $out = [];

    /* Admins (excluding self) */
    $admins = $db->query(
        "SELECT id, full_name, photo_url FROM users WHERE role='admin' AND status='active' AND id != :me ORDER BY full_name",
        [':me' => $me]
    ) ?: [];
    foreach ($admins as $a) {
        $out[] = ['id'=>(int)$a['id'],'full_name'=>$a['full_name'],'photo_url'=>$a['photo_url'],'role'=>'admin','role_group'=>'Administration','student_name'=>null];
    }

    /* Teachers */
    $teachers = $db->query(
        "SELECT u.id, u.full_name, u.photo_url, c.class_name
         FROM users u
         LEFT JOIN classes c ON c.teacher_id = u.id
         WHERE u.role='teacher' AND u.status='active'
         ORDER BY u.full_name"
    ) ?: [];
    foreach ($teachers as $t) {
        $out[] = ['id'=>(int)$t['id'],'full_name'=>$t['full_name'],'photo_url'=>$t['photo_url'],'role'=>'teacher','role_group'=>'Teachers','student_name'=>null,'class_name'=>$t['class_name']];
    }

    /* Parents with student names */
    $parents = $db->query(
        "SELECT DISTINCT u.id, u.full_name, u.photo_url, s.student_name, s.class_id
         FROM users u
         JOIN parents p  ON p.user_id    = u.id
         JOIN students s ON s.id          = p.student_id
         WHERE u.role='parent' AND u.status='active' AND s.status='active'
         ORDER BY u.full_name"
    ) ?: [];
    foreach ($parents as $p) {
        $out[] = ['id'=>(int)$p['id'],'full_name'=>$p['full_name'],'photo_url'=>$p['photo_url'],'role'=>'parent','role_group'=>'Parents','student_name'=>$p['student_name']];
    }

    ob_end_clean();
    successResponse($out);
}

/* ─────────────────────────────────────────
   TYPING STATUS
───────────────────────────────────────── */
function getTypingStatus($db) {
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    $isTyping = false;
    try {
        $row = $db->queryOne(
            "SELECT 1 FROM typing_status
             WHERE user_id = :uid AND contact_id = :me
               AND updated_at >= DATE_SUB(NOW(), INTERVAL 5 SECOND)",
            [':uid' => $contactId, ':me' => $me]
        );
        $isTyping = (bool)$row;
    } catch (\Exception $e) {}

    ob_end_clean();
    successResponse(['is_typing' => $isTyping]);
}

/* ─────────────────────────────────────────
   PRESENCE
───────────────────────────────────────── */
function getPresence($db) {
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    $isOnline = false; $lastSeen = null;
    try {
        $row = $db->queryOne(
            "SELECT last_seen FROM user_presence WHERE user_id = :uid",
            [':uid' => $contactId]
        );
        if ($row) {
            $lastSeen = $row['last_seen'];
            $isOnline = (strtotime($row['last_seen']) >= time() - 120);
        }
    } catch (\Exception $e) {}

    ob_end_clean();
    successResponse(['is_online' => $isOnline, 'last_seen' => $lastSeen]);
}

/* ─────────────────────────────────────────
   SEND MESSAGE (JSON)
───────────────────────────────────────── */
function sendMessage($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = myId();
    if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }

    $data        = json_decode(file_get_contents('php://input'), true);
    $recipientId = isset($data['recipient_id']) ? (int)$data['recipient_id']   : 0;
    $subject     = isset($data['subject'])      ? sanitize($data['subject'])    : '';
    $message     = isset($data['message'])      ? trim($data['message'])        : '';

    if (!$recipientId) { ob_end_clean(); errorResponse('recipient_id required'); }
    if (!$message)     { ob_end_clean(); errorResponse('Message body required'); }
    if (mb_strlen($message) > 5000) { ob_end_clean(); errorResponse('Message too long (max 5000 chars)'); }

    $msgId = $db->execute(
        "INSERT INTO messages (sender_id, recipient_id, subject, message, is_read, has_file, created_at)
         VALUES (:sid, :rid, :sub, :msg, 0, 0, NOW())",
        [':sid' => $me, ':rid' => $recipientId, ':sub' => $subject, ':msg' => $message]
    );
    if (!$msgId) { ob_end_clean(); errorResponse('Failed to save message', 500); }

    _createNotification($db, $me, $recipientId, $subject, $message);

    ob_end_clean();
    successResponse([
        'id'         => $msgId,
        'sender_id'  => $me,
        'recipient_id'=> $recipientId,
        'subject'    => $subject,
        'message'    => $message,
        'is_read'    => 0,
        'has_file'   => 0,
        'files'      => [],
        'created_at' => date('Y-m-d H:i:s'),
    ], 'Message sent');
}

/* ─────────────────────────────────────────
   SEND FILE (multipart/form-data)
   Fields: recipient_id, message (optional), subject (optional)
   File:   attachment
───────────────────────────────────────── */
function sendFile($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me = myId();
    if (!$me) { ob_end_clean(); errorResponse('Not authenticated', 401); }

    $recipientId = isset($_POST['recipient_id']) ? (int)$_POST['recipient_id'] : 0;
    $message     = isset($_POST['message'])      ? trim($_POST['message'])      : '';
    $subject     = isset($_POST['subject'])      ? sanitize($_POST['subject'])  : '';

    if (!$recipientId) { ob_end_clean(); errorResponse('recipient_id required'); }
    if (!isset($_FILES['attachment'])) {
        ob_end_clean(); errorResponse('File upload failed or no file provided');
    }

    $origName = basename(isset($_FILES['attachment']['name']) ? $_FILES['attachment']['name'] : 'file');
    $dir = dirname(__DIR__) . '/uploads/messages/';
    $up = nsmsStoreUpload(
        $_FILES['attachment'],
        $dir,
        array('jpg','jpeg','png','gif','webp','pdf','txt','doc','docx','xls','xlsx'),
        10 * 1024 * 1024,
        array(
            'image/jpeg','image/png','image/gif','image/webp',
            'application/pdf','text/plain',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        )
    );
    if (empty($up['ok'])) {
        ob_end_clean(); errorResponse(isset($up['error']) ? $up['error'] : 'Upload failed');
    }
    $stored   = $up['filename'];
    $mime     = $up['mime'];
    $size     = $up['size'];
    $destPath = $up['path'];

    /* Insert message */
    $msgId = $db->execute(
        "INSERT INTO messages (sender_id, recipient_id, subject, message, is_read, has_file, created_at)
         VALUES (:sid, :rid, :sub, :msg, 0, 1, NOW())",
        [':sid' => $me, ':rid' => $recipientId, ':sub' => $subject, ':msg' => $message]
    );
    if (!$msgId) { ob_end_clean(); errorResponse('Failed to save message', 500); }

    /* Insert file record */
    try {
        $db->execute(
            "INSERT INTO message_files (message_id, original_name, stored_name, mime_type, file_size, created_at)
             VALUES (:mid, :orig, :stored, :mime, :size, NOW())",
            [':mid' => $msgId, ':orig' => $origName, ':stored' => $stored, ':mime' => $mime, ':size' => $size]
        );
    } catch (\Exception $e) { /* migration pending */ }

    _createNotification($db, $me, $recipientId, $subject ?: '📎 Attachment', $message ?: 'Sent a file');

    ob_end_clean();
    successResponse([
        'id'          => $msgId,
        'sender_id'   => $me,
        'recipient_id'=> $recipientId,
        'subject'     => $subject,
        'message'     => $message,
        'is_read'     => 0,
        'has_file'    => 1,
        'files'       => [[
            'file_id'       => null,
            'original_name' => $origName,
            'mime_type'     => $mime,
            'file_size'     => $size,
            'url'           => '/nsms/uploads/messages/' . $stored,
        ]],
        'created_at'  => date('Y-m-d H:i:s'),
    ], 'File sent');
}

/* ─────────────────────────────────────────
   MARK READ
───────────────────────────────────────── */
function markRead($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    $db->execute(
        "UPDATE messages SET is_read=1, read_at=NOW()
         WHERE sender_id=:cid AND recipient_id=:me AND is_read=0",
        [':cid' => $contactId, ':me' => $me]
    );

    /* Also clear matching message notifications */
    $sender = $db->queryOne("SELECT full_name FROM users WHERE id=:id",[':id'=>$contactId]);
    if ($sender) {
        $db->execute(
            "UPDATE notifications SET is_read=1, read_at=NOW()
             WHERE user_id=:me AND type='message' AND is_read=0 AND title LIKE :t",
            [':me' => $me, ':t' => '%' . $sender['full_name'] . '%']
        );
    }

    ob_end_clean();
    successResponse(null, 'Marked as read');
}

/* ─────────────────────────────────────────
   SET TYPING (heartbeat while composing)
───────────────────────────────────────── */
function setTyping($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    $me        = myId();
    $contactId = isset($_GET['contact_id']) ? (int)$_GET['contact_id'] : 0;
    if (!$me || !$contactId) { ob_end_clean(); errorResponse('contact_id required'); }

    try {
        $db->execute(
            "INSERT INTO typing_status (user_id, contact_id, updated_at)
             VALUES (:me, :cid, NOW())
             ON DUPLICATE KEY UPDATE updated_at = NOW()",
            [':me' => $me, ':cid' => $contactId]
        );
    } catch (\Exception $e) { /* migration pending */ }

    ob_end_clean();
    successResponse(null);
}

/* ─────────────────────────────────────────
   HEARTBEAT — update own presence
───────────────────────────────────────── */
function doHeartbeat($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); errorResponse('Method not allowed', 405); }
    _updatePresence($db);
    ob_end_clean();
    successResponse(null);
}

/* ─────────────────────────────────────────
   INTERNAL: create notification for recipient
───────────────────────────────────────── */
function _createNotification($db, $senderId, $recipientId, $subject, $message) {
    $sender = $db->queryOne("SELECT full_name FROM users WHERE id=:id",[':id'=>$senderId]);
    $name   = $sender ? $sender['full_name'] : 'Admin';
    $title  = 'New message from ' . $name;
    $body   = $subject ? $subject . ': ' . mb_substr($message, 0, 80) : mb_substr($message, 0, 100);
    $db->execute(
        "INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
         VALUES (:uid, :title, :msg, 'message', 0, NOW())",
        [':uid' => $recipientId, ':title' => $title, ':msg' => $body]
    );
}
