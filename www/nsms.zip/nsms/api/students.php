<?php
/**
 * Students Management API
 * PHP 7.2 compatible
 * Actions: list, get, create, update, delete, search
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    exit(0);
}

require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once __DIR__ . '/../includes/sync/SyncHooks.php';
require_once __DIR__ . '/../includes/sync/OfflineData.php';
require_once __DIR__ . '/../includes/sync/OfflineAdmin.php';

applyApiHeaders();

requireRole(['admin', 'teacher']);

$db   = new Database();
$conn = $db->connect();
$mysqlOnline = (bool)$conn;
$action = isset($_GET['action']) ? $_GET['action'] : '';

if (!$mysqlOnline) {
    require_once __DIR__ . '/../includes/sync/OfflineAdmin.php';
    $uid = function_exists('getCurrentUserId') ? getCurrentUserId() : (isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null);
    if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        try {
            // Admin UI posts multipart FormData — prefer $_POST
            $data = array();
            if (!empty($_POST) && is_array($_POST)) {
                $data = $_POST;
            } else {
                $raw = file_get_contents('php://input');
                $decoded = $raw ? json_decode($raw, true) : null;
                if (is_array($decoded)) $data = $decoded;
            }
            if (!is_array($data) || !$data) {
                throw new Exception('No student data received');
            }
            $res = OfflineAdmin::createStudent($data, $uid);
            ob_end_clean();
            successResponse($res, 'Student saved offline — will sync when online');
        } catch (Exception $e) {
            ob_end_clean();
            errorResponse($e->getMessage(), 400);
        }
    }
    if ($action === 'update' && in_array($_SERVER['REQUEST_METHOD'], array('POST','PUT'), true)) {
        try {
            $data = array();
            if (!empty($_POST) && is_array($_POST)) {
                $data = $_POST;
            } else {
                $raw = file_get_contents('php://input');
                $decoded = $raw ? json_decode($raw, true) : null;
                if (is_array($decoded)) $data = $decoded;
            }
            if (!is_array($data)) $data = array();
            $id = isset($data['id']) ? (int)$data['id'] : 0;
            if ($id < 1) { ob_end_clean(); errorResponse('Student ID required'); }
            $res = OfflineAdmin::updateStudent($id, $data, $uid);
            ob_end_clean();
            successResponse($res, 'Student updated offline — will sync when online');
        } catch (Exception $e) {
            ob_end_clean();
            errorResponse($e->getMessage(), 400);
        }
    }
    $offlineRead = array('list', 'status_counts', 'get', 'search');
    if (!in_array($action, $offlineRead, true)) {
        ob_end_clean();
        errorResponse('This action requires an online connection (MySQL).', 503);
    }
    if ($action === 'list') {
        $status = isset($_GET['status']) ? $_GET['status'] : 'active';
        $classId = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;
        $rows = OfflineData::listStudents($status, $classId ?: null);
        ob_end_clean();
        successResponse($rows, 'Offline cached student list');
    }
    if ($action === 'status_counts') {
        ob_end_clean();
        successResponse(OfflineData::statusCounts(), 'Offline status counts');
    }
    if ($action === 'search') {
        $q = isset($_GET['q']) ? strtolower(trim($_GET['q'])) : '';
        $rows = OfflineData::listStudents('all', null);
        if ($q !== '') {
            $rows = array_values(array_filter($rows, function ($r) use ($q) {
                return strpos(strtolower($r['student_name'] ?? ''), $q) !== false;
            }));
        }
        ob_end_clean();
        successResponse($rows, 'Offline search');
    }
    // get: minimal
    if ($action === 'get') {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $rows = OfflineData::listStudents('all', null);
        $found = null;
        foreach ($rows as $r) {
            if ((int)$r['id'] === $id) { $found = $r; break; }
        }
        if (!$found) {
            ob_end_clean();
            errorResponse('Student not found in offline cache', 404);
        }
        ob_end_clean();
        successResponse($found, 'Offline student record');
    }
}


$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'list':   listStudents($db);   break;
    case 'get':    getStudent($db);     break;
    case 'create': createStudent($db);  break;
    case 'update': updateStudent($db);  break;
    case 'delete': deleteStudent($db);  break; // soft → withdrawn
    case 'search': searchStudents($db); break;
    case 'reset_parent_password': resetParentPassword($db); break;
    case 'transfer':          transferStudent($db); break;
    case 'withdraw':          withdrawStudent($db); break;
    case 'graduate':          graduateStudent($db); break;
    case 'suspend':           suspendStudent($db); break;
    case 'reactivate':        reactivateStudent($db); break;
    case 'lifecycle_history': studentLifecycleHistory($db); break;
    case 'status_counts':     studentStatusCounts($db); break;
    default:
        ob_end_clean();
        errorResponse('Invalid action');
}

/* ─────────────────────────────────────────
   HELPER: read request body
   Handles JSON (no file) and multipart (file)
───────────────────────────────────────── */
function readBody() {
    $ct = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    if (strpos($ct, 'application/json') !== false) {
        return json_decode(file_get_contents('php://input'), true) ?: [];
    }
    return $_POST; // multipart or urlencoded
}

/* ─────────────────────────────────────────
   HELPER: photo upload
   Uses realpath(__FILE__) to resolve absolute
   directory — avoids dirname(__DIR__) depth bugs.

   Directory structure assumed:
     nsms/
       api/students.php   ← this file
       public/uploads/students/
   Returns web path string on success, or null.
   On PHP-level error sets $uploadWarning.
───────────────────────────────────────── */
function handlePhotoUpload(&$uploadWarning = null) {
    if (empty($_FILES['photo'])) {
        return null; // no file field at all
    }

    $errCode = $_FILES['photo']['error'];

    if ($errCode === UPLOAD_ERR_NO_FILE) {
        return null; // field present but nothing chosen — normal
    }

    if ($errCode !== UPLOAD_ERR_OK) {
        $phpErrors = [
            UPLOAD_ERR_INI_SIZE   => 'File exceeds upload_max_filesize in php.ini',
            UPLOAD_ERR_FORM_SIZE  => 'File exceeds MAX_FILE_SIZE in the form',
            UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'No temporary folder on server',
            UPLOAD_ERR_CANT_WRITE => 'Server failed to write file to disk',
            UPLOAD_ERR_EXTENSION  => 'Upload blocked by a PHP extension',
        ];
        $uploadWarning = isset($phpErrors[$errCode])
            ? $phpErrors[$errCode]
            : 'PHP upload error code ' . $errCode;
        return null;
    }

    $file = $_FILES['photo'];

    // Size check
    if ($file['size'] > 5 * 1024 * 1024) {
        $uploadWarning = 'Photo too large — max 5 MB';
        return null;
    }

    // MIME check from actual bytes, not browser-supplied type
    $allowedMime  = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $mimeToExt    = ['image/jpeg' => 'jpg', 'image/png' => 'png',
                     'image/gif'  => 'gif', 'image/webp' => 'webp'];

    if (function_exists('finfo_open')) {
        $fi   = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($fi, $file['tmp_name']);
        finfo_close($fi);
    } else {
        // Fallback: normalise 'image/jpg' which some browsers emit
        $mime = ($file['type'] === 'image/jpg') ? 'image/jpeg' : $file['type'];
    }

    if (!in_array($mime, $allowedMime)) {
        $uploadWarning = 'Invalid image type (' . $mime . '). Use JPG, PNG, GIF, or WEBP';
        return null;
    }

    // Resolve upload directory from this file's real location
    $thisFile  = realpath(__FILE__);          // /…/nsms/api/students.php
    $apiDir    = dirname($thisFile);          // /…/nsms/api
    $nsmsRoot  = dirname($apiDir);            // /…/nsms
    $uploadDir = $nsmsRoot . DIRECTORY_SEPARATOR . 'public'
               . DIRECTORY_SEPARATOR . 'uploads'
               . DIRECTORY_SEPARATOR . 'students'
               . DIRECTORY_SEPARATOR;

    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0755, true)) {
            $uploadWarning = 'Cannot create upload directory: ' . $uploadDir;
            return null;
        }
    }

    if (!is_writable($uploadDir)) {
        $uploadWarning = 'Upload directory is not writable: ' . $uploadDir;
        return null;
    }

    $ext      = $mimeToExt[$mime];
    $filename = 'student_' . time() . '_' . mt_rand(1000, 9999) . '.' . $ext;
    $dest     = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        $uploadWarning = 'move_uploaded_file failed — tmp=' . $file['tmp_name'] . ' dest=' . $dest;
        return null;
    }

    return '/nsms/public/uploads/students/' . $filename;
}

/* ─────────────────────────────────────────
   HELPER: upsert parent user and link
───────────────────────────────────────── */

/**
 * Admin: reset parent portal password (activation credentials by email).
 * Body JSON: { "user_id": N } or { "student_id": N }
 * Does not remove parent/student links or any school data.
 */
function resetParentPassword($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        errorResponse('Method not allowed', 405);
    }
    if (function_exists('requireRole')) {
        requireRole(array('admin'));
    }

    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) $body = array();

    $userId = isset($body['user_id']) ? (int) $body['user_id'] : 0;
    $studentId = isset($body['student_id']) ? (int) $body['student_id'] : 0;

    if (!$userId && $studentId) {
        $row = $db->queryOne(
            "SELECT user_id FROM parents WHERE student_id = :sid ORDER BY id ASC LIMIT 1",
            array(':sid' => $studentId)
        );
        if ($row) $userId = (int) $row['user_id'];
    }

    if (!$userId) {
        errorResponse('Parent user_id or student_id required');
    }

    $row = $db->queryOne(
        "SELECT id FROM users WHERE id = :id AND role = 'parent' LIMIT 1",
        array(':id' => $userId)
    );
    if (!$row) {
        errorResponse('Parent account not found', 404);
    }

    $result = nsmsResetActivation($db, $userId);
    if (empty($result['ok'])) {
        errorResponse(isset($result['error']) ? $result['error'] : 'Reset failed', 400);
    }

    successResponse(array(
        'email'         => $result['user']['email'],
        'email_sent'    => !empty($result['email_sent']),
        'mode'          => isset($result['mode']) ? $result['mode'] : 'link',
        'reset_url'     => isset($result['reset_url']) ? $result['reset_url'] : null,
        'temp_password' => isset($result['temp_password']) ? $result['temp_password'] : null,
    ), !empty($result['email_sent'])
        ? 'Reset link emailed to the parent (valid 1 hour).'
        : (isset($result['reset_url'])
            ? 'Email failed — copy the reset link from the response and share it securely.'
            : 'Password reset completed.'));
}

function saveParentForStudent($db, $studentId, $studentName, $name, $phone, $email, $relationship = 'Guardian') {
    // Validate relationship against ENUM
    $validRels = ['Father', 'Mother', 'Guardian', 'Other'];
    if (!in_array($relationship, $validRels)) {
        $relationship = 'Guardian';
    }

    $userId        = null;
    $isNewAccount  = false;
    $plainPassword = null;

    // Email is the unique account key: one email → one user only.
    $emailNorm = $email ? strtolower(trim($email)) : '';
    if ($emailNorm !== '') {
        $row = function_exists('nsmsFindUserByEmail')
            ? nsmsFindUserByEmail($db, $emailNorm)
            : $db->queryOne("SELECT id, role, full_name FROM users WHERE LOWER(TRIM(email)) = :e LIMIT 1", [':e' => $emailNorm]);
        if ($row) {
            $existingRole = strtolower(trim((string) ($row['role'] ?? '')));
            if ($existingRole !== 'parent') {
                // Teacher/admin/other must not be reused as a parent under the same email
                return array(
                    'user_id' => null,
                    'is_new_account' => false,
                    'temp_password' => null,
                    'welcome_email_sent' => false,
                    'parent_email' => $emailNorm,
                    'error' => 'This email is already registered to another user. Each email can only belong to one account. Use a different parent email.',
                );
            }
            $userId = (int) $row['id'];
        }
    }

    if (!$userId) {
        $safeEmail  = $emailNorm !== '' ? $emailNorm : ('parent_' . $studentId . '_' . time() . '@nsms.local');
        // Initial password: digits-only phone (min 6) so formatting (+255, spaces) does not
        // block first login; otherwise parent123. Setup forces a personal password next.
        $phoneDigits = preg_replace('/\D+/', '', (string) $phone);
        if ($phoneDigits !== '' && strlen($phoneDigits) >= 6) {
            $initialPass = $phoneDigits;
        } else {
            $initialPass = 'parent123';
        }
        $passHash    = password_hash($initialPass, PASSWORD_DEFAULT);
        $safeEmail   = strtolower(trim($safeEmail));
        $userId     = $db->execute(
            "INSERT INTO users (full_name, email, phone, password_hash, role, status, password_changed, created_at)
             VALUES (:n, :e, :p, :pw, 'parent', 'active', 0, NOW())",
            [':n' => $name, ':e' => $safeEmail, ':p' => $phone ?: '', ':pw' => $passHash]
        );
        $isNewAccount  = true;
        $plainPassword = $initialPass;
    } else {
        // Update existing user's details
        $db->execute(
            "UPDATE users SET full_name = :n, phone = :p WHERE id = :id",
            [':n' => $name, ':p' => $phone ?: '', ':id' => $userId]
        );
    }

    if ($userId) {
        $db->execute(
            "INSERT IGNORE INTO parents (student_id, user_id, relationship, created_at)
             VALUES (:s, :u, :rel, NOW())",
            [':s' => $studentId, ':u' => $userId, ':rel' => $relationship]
        );
    }

    // Only a genuinely new account, with a real email address to send to
    // (not the auto-generated @nsms.local placeholder used when no email
    // was given), gets the welcome email. An existing parent gaining a
    // second child here isn't a new account, so they shouldn't get one.
    $welcomeSent = false;
    if ($isNewAccount && $email && strpos($email, '@nsms.local') === false) {
        $welcomeSent = notifyNewParentWelcome($db, $email, $name, $studentName, $plainPassword);
    }

    return array(
        'user_id' => $userId,
        'is_new_account' => $isNewAccount,
        'temp_password' => $isNewAccount ? $plainPassword : null,
        'welcome_email_sent' => $welcomeSent,
        'parent_email' => $email,
    );
}

/**
 * Warm welcome email sent once when a brand-new parent account is created
 * during child registration. Includes default credentials for first login.
 * @return bool whether the email was accepted by the mail provider
 */
function notifyNewParentWelcome($db, $email, $parentName, $studentName, $plainPassword) {
    try {
        $schoolRow  = $db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key = 'school_name'");
        $schoolName = ($schoolRow && !empty($schoolRow['setting_value'])) ? $schoolRow['setting_value'] : 'our school';

        if (function_exists('nsmsPublicBaseUrl')) {
            $base = nsmsPublicBaseUrl();
        } elseif (defined('SITE_URL') && SITE_URL) {
            $base = rtrim(SITE_URL, '/');
        } else {
            $base = '';
        }
        $loginUrl    = $base !== '' ? $base . '/public/index.html?activate=1' : '#';
        $safeName    = htmlspecialchars((string) $parentName, ENT_QUOTES, 'UTF-8');
        $safeSchool  = htmlspecialchars((string) $schoolName, ENT_QUOTES, 'UTF-8');
        $safeChild   = htmlspecialchars((string) $studentName, ENT_QUOTES, 'UTF-8');
        $safeEmail   = htmlspecialchars((string) $email, ENT_QUOTES, 'UTF-8');
        $safePass    = htmlspecialchars((string) $plainPassword, ENT_QUOTES, 'UTF-8');
        $safeLogin   = htmlspecialchars($loginUrl, ENT_QUOTES, 'UTF-8');

        $subject = 'Welcome to ' . $schoolName . ' — your parent portal is ready';

        $body = '
<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f3ee;font-family:Segoe UI,Helvetica,Arial,sans-serif;color:#1a2e24;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f3ee;padding:24px 12px;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 28px rgba(29,92,66,0.1);">
        <tr><td style="background:linear-gradient(135deg,#1D5C42,#2E8B57);padding:28px 32px;color:#fff;">
          <div style="font-size:13px;letter-spacing:0.08em;text-transform:uppercase;opacity:0.85;">Parent portal</div>
          <div style="font-size:24px;font-weight:700;margin-top:6px;">Welcome to ' . $safeSchool . '</div>
        </td></tr>
        <tr><td style="padding:28px 32px;">
          <p style="margin:0 0 14px;font-size:16px;">Dear <strong>' . $safeName . '</strong>,</p>
          <p style="margin:0 0 14px;font-size:15px;line-height:1.6;color:#3d4f45;">
            We are delighted to welcome <strong>' . $safeChild . '</strong> to the ' . $safeSchool . ' family.
            Your parent account has been created so you can stay close to their learning journey —
            attendance, homework, reports, messages, and fees — all in one secure place.
          </p>
          <p style="margin:0 0 10px;font-size:15px;line-height:1.6;color:#3d4f45;">
            Please use these details for your <strong>first sign-in</strong>. You will then be asked to choose your own password.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#EAF7F1;border-radius:12px;margin:16px 0 20px;">
            <tr><td style="padding:16px 18px;font-size:14px;line-height:1.7;">
              <div style="color:#1D5C42;font-weight:700;margin-bottom:6px;">Your login credentials</div>
              <div><strong>Email:</strong> ' . $safeEmail . '</div>
              <div><strong>Temporary password:</strong> <span style="font-family:Consolas,monospace;background:#fff;padding:2px 8px;border-radius:6px;border:1px solid #cfe8db;">' . $safePass . '</span></div>
            </td></tr>
          </table>
          <p style="margin:0 0 20px;text-align:center;">
            <a href="' . $safeLogin . '" style="display:inline-block;padding:12px 24px;background:#1D5C42;color:#ffffff;text-decoration:none;border-radius:999px;font-weight:700;font-size:14px;">
              Activate &amp; sign in
            </a>
          </p>
          <p style="margin:0 0 8px;font-size:13px;color:#6b7280;line-height:1.55;">
            Tip: open the school website, choose <em>Activate Account</em>, enter the email and temporary password above, then set a password only you know.
          </p>
          <p style="margin:0;font-size:13px;color:#6b7280;line-height:1.55;">
            If you did not expect this message, please contact the school office. We look forward to partnering with you.
          </p>
          <p style="margin:18px 0 0;font-size:14px;color:#1a2e24;">
            With warm regards,<br/>
            <strong>' . $safeSchool . '</strong>
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>';

        if (!function_exists('sendEmail')) {
            error_log('notifyNewParentWelcome: sendEmail() not available');
            return false;
        }
        return (bool) sendEmail($email, $subject, $body);
    } catch (Exception $e) {
        error_log('notifyNewParentWelcome error: ' . $e->getMessage());
        return false;
    }
}


/* ─* ─────────────────────────────────────────
   LIST STUDENTS
───────────────────────────────────────── */
function listStudents($db) {
    nsmsEnsureStudentLifecycleSchema($db);
    $classId = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;
    $status  = isset($_GET['status'])   ? $_GET['status']         : 'active';
    $gender  = isset($_GET['gender'])   ? $_GET['gender']         : '';

    $sql = "SELECT
                s.id, s.student_name, s.class_id,
                c.class_name, c.class_color,
                s.date_of_birth, s.gender, s.address,
                s.enrollment_date, s.status, s.photo_url,
                u.id             AS parent_user_id,
                u.full_name      AS parent_name,
                u.phone          AS parent_phone,
                u.email          AS parent_email,
                p.relationship   AS parent_relationship
            FROM students s
            JOIN   classes c ON s.class_id = c.id
            LEFT JOIN parents p ON s.id = p.student_id
            LEFT JOIN users   u ON p.user_id = u.id
            WHERE 1=1";

    $params = [];
    if ($classId) { $sql .= " AND s.class_id = :class_id"; $params[':class_id'] = $classId; }
    if ($status !== 'all') {
        if ($status === 'former') {
            $sql .= " AND s.status IN ('transferred','withdrawn','graduated','suspended')";
        } else {
            $sql .= " AND s.status = :status";
            $params[':status'] = $status;
        }
    }
    if ($gender !== '' && in_array($gender, array('Male', 'Female', 'Other'), true)) {
        $sql .= " AND s.gender = :gender";
        $params[':gender'] = $gender;
    }
    $sql .= " ORDER BY s.student_name ASC";

    ob_end_clean();
    successResponse($db->query($sql, $params) ?: []);
}

/* ─────────────────────────────────────────
   GET SINGLE STUDENT (full profile + fees)
───────────────────────────────────────── */
function getStudent($db) {
    if (!isset($_GET['id'])) {
        ob_end_clean();
        errorResponse('Student ID required');
    }
    $id = (int)$_GET['id'];

    $student = $db->queryOne(
        "SELECT s.*, c.class_name, c.class_color
         FROM students s JOIN classes c ON s.class_id = c.id
         WHERE s.id = :id LIMIT 1",
        [':id' => $id]
    );

    if (!$student) {
        ob_end_clean();
        errorResponse('Student not found', 404);
    }

    // Parents
    $student['parents'] = $db->query(
        "SELECT u.id, u.full_name, u.email, u.phone, p.relationship
         FROM parents p JOIN users u ON p.user_id = u.id
         WHERE p.student_id = :sid",
        [':sid' => $id]
    ) ?: [];

    // Flatten first parent for convenience
    if (!empty($student['parents'])) {
        $p = $student['parents'][0];
        $student['parent_name']         = $p['full_name'];
        $student['parent_email']        = $p['email'];
        $student['parent_phone']        = $p['phone'];
        $student['parent_relationship'] = $p['relationship'];
    }

    // ── Fee payment data (per-type breakdown) ──────────────────────────
    $classId = (int)$student['class_id'];

    // Determine current academic year (mirrors finance.php logic)
    $yrRow = $db->queryOne(
        "SELECT academic_year FROM fee_structure
         GROUP BY academic_year ORDER BY COUNT(*) DESC, academic_year DESC LIMIT 1"
    );
    if (!$yrRow) {
        $yrRow = $db->queryOne(
            "SELECT setting_value AS academic_year
             FROM school_settings WHERE setting_key='academic_year'"
        );
    }
    $yr = ($yrRow && !empty($yrRow['academic_year']))
        ? $yrRow['academic_year']
        : (date('Y') . '/' . ((int)date('Y') + 1));

    // ── 1. Other fees (one-time: Registration, Stationery, Uniform, Meals…) ──
    // Class-specific row overrides school-wide row for the same fee_type.
    $otherFeeRows = $db->query(
        "SELECT fee_type,
                MAX(CASE WHEN class_id = :cid THEN amount ELSE NULL END) AS class_amt,
                MAX(CASE WHEN class_id IS NULL THEN amount ELSE NULL END) AS school_amt
           FROM fee_structure
          WHERE academic_year = :yr
            AND fee_type NOT IN ('School Fees', 'Transport')
            AND (class_id = :cid2 OR class_id IS NULL)
          GROUP BY fee_type
          ORDER BY fee_type ASC",
        [':yr' => $yr, ':cid' => $classId, ':cid2' => $classId]
    ) ?: [];

    $otherItems    = [];
    $otherTotalDue = 0.0;
    foreach ($otherFeeRows as $r) {
        // class-specific amount wins over school-wide
        $amt = ($r['class_amt'] !== null) ? (float)$r['class_amt'] : (float)$r['school_amt'];
        $otherItems[]   = ['name' => $r['fee_type'], 'amount' => $amt];
        $otherTotalDue += $amt;
    }

    // Total confirmed cash received from this student
    $totalPaidRow = $db->queryOne(
        "SELECT COALESCE(SUM(amount), 0) AS total FROM fee_payments
          WHERE student_id = :sid AND status = 'confirmed'",
        [':sid' => $id]
    );
    $totalPaid    = (float)($totalPaidRow['total'] ?? 0);

    // Payments attributed to one-time fees first (same logic as finance.php)
    $otherPaid    = min($totalPaid, $otherTotalDue);
    $otherBalance = max(0, $otherTotalDue - $otherPaid);

    // ── 2 & 3. Installment rows (School Fees + Transport) ──────────────
    // Month-name map: Jun & Dec are holidays → 10 teaching months
    $instMonthMap = [
        1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May',
        6=>'Jul', 7=>'Aug', 8=>'Sep', 9=>'Oct', 10=>'Nov',
    ];

    $mapInstRows = function($rows) use ($instMonthMap) {
        return array_map(function($r) use ($instMonthMap) {
            $no = (int)$r['installment_no'];
            return [
                'no'         => $no,
                'month_name' => isset($instMonthMap[$no]) ? $instMonthMap[$no] : (string)$no,
                'amount_due' => (float)$r['amount_due'],
                'amount_paid'=> (float)$r['amount_paid'],
                'status'     => $r['status'],
                'paid_date'  => $r['paid_date'],
            ];
        }, $rows);
    };

    // School Fees installments
    $sfRows = $db->query(
        "SELECT installment_no, amount_due, amount_paid, status, paid_date
           FROM fee_installments
          WHERE student_id = :sid AND academic_year = :yr AND fee_type = 'School Fees'
          ORDER BY installment_no ASC",
        [':sid' => $id, ':yr' => $yr]
    ) ?: [];

    $sfInstallments = $mapInstRows($sfRows);
    $sfTotalDue     = array_sum(array_column($sfRows, 'amount_due'));
    $sfTotalPaid    = array_sum(array_column($sfRows, 'amount_paid'));
    $sfPaidCount    = count(array_filter($sfRows, function($r) { return $r['status'] === 'paid'; }));
    $sfConfigured   = count($sfRows) > 0;

    // Transport installments
    $trRows = $db->query(
        "SELECT installment_no, amount_due, amount_paid, status, paid_date
           FROM fee_installments
          WHERE student_id = :sid AND academic_year = :yr AND fee_type = 'Transport'
          ORDER BY installment_no ASC",
        [':sid' => $id, ':yr' => $yr]
    ) ?: [];

    // Check if transport is in fee_structure at all for this class/school
    $trInStructure = (bool)$db->queryOne(
        "SELECT id FROM fee_structure
          WHERE academic_year = :yr AND fee_type = 'Transport'
            AND (class_id = :cid OR class_id IS NULL) LIMIT 1",
        [':yr' => $yr, ':cid' => $classId]
    );

    $trInstallments = $mapInstRows($trRows);
    $trTotalDue     = array_sum(array_column($trRows, 'amount_due'));
    $trTotalPaid    = array_sum(array_column($trRows, 'amount_paid'));
    $trPaidCount    = count(array_filter($trRows, function($r) { return $r['status'] === 'paid'; }));
    $trConfigured   = $trInStructure || count($trRows) > 0;

    // Last payment (most recent regardless of type)
    $lastPayRow = $db->queryOne(
        "SELECT payment_date, amount, payment_method FROM fee_payments
          WHERE student_id = :sid AND status = 'confirmed'
          ORDER BY payment_date DESC LIMIT 1",
        [':sid' => $id]
    );

    // Attach structured fee data to student response
    $student['fees'] = [
        'academic_year' => $yr,
        'total_paid'    => $totalPaid,
        'other' => [
            'items'      => $otherItems,
            'total_due'  => $otherTotalDue,
            'total_paid' => $otherPaid,
            'balance'    => $otherBalance,
            'configured' => count($otherItems) > 0,
        ],
        'school_fees' => [
            'installments' => $sfInstallments,
            'total_due'    => $sfTotalDue,
            'total_paid'   => $sfTotalPaid,
            'paid_count'   => $sfPaidCount,
            'configured'   => $sfConfigured,
        ],
        'transport' => [
            'installments' => $trInstallments,
            'total_due'    => $trTotalDue,
            'total_paid'   => $trTotalPaid,
            'paid_count'   => $trPaidCount,
            'configured'   => $trConfigured,
        ],
        'last_payment' => $lastPayRow ? [
            'date'   => $lastPayRow['payment_date'],
            'amount' => (float)$lastPayRow['amount'],
            'method' => $lastPayRow['payment_method'],
        ] : null,
    ];

    ob_end_clean();
    successResponse($student);
}

/* ─────────────────────────────────────────
   CREATE STUDENT
───────────────────────────────────────── */
function createStudent($db) {
    requireRole('admin');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean();
        errorResponse('Method not allowed', 405);
    }

    $data = readBody();

    foreach (['student_name', 'class_id', 'date_of_birth', 'gender', 'enrollment_date'] as $f) {
        if (empty($data[$f])) {
            ob_end_clean();
            errorResponse("Field '{$f}' is required");
        }
    }

    $photoWarning = null;
    $photoUrl     = handlePhotoUpload($photoWarning);

    // ── Strict field validation ──────────────────────────────────────────
    $nameV = nsmsValidatePersonName($data['student_name'], 'Student name');
    if (!$nameV['ok']) { ob_end_clean(); errorResponse($nameV['error'], 400); }
    $studentName = $nameV['value'];

    $classId = (int) $data['class_id'];
    if ($classId < 1) { ob_end_clean(); errorResponse('Please select a valid class', 400); }
    if (function_exists('nsmsEnsureClassMinimumAgeColumn')) {
        nsmsEnsureClassMinimumAgeColumn($db);
    }
    $classRow = $db->queryOne(
        "SELECT id, class_name, minimum_age FROM classes WHERE id = :id LIMIT 1",
        [':id' => $classId]
    );
    if (!$classRow) {
        // Legacy select without minimum_age
        $classRow = $db->queryOne("SELECT id, class_name FROM classes WHERE id = :id LIMIT 1", [':id' => $classId]);
        if ($classRow) {
            $classRow['minimum_age'] = null;
        }
    }
    if (!$classRow) {
        ob_end_clean();
        errorResponse('Please select a valid class', 400);
    }

    $dobV = nsmsValidateDate($data['date_of_birth'], 'Date of birth', false, 1990);
    if (!$dobV['ok']) { ob_end_clean(); errorResponse($dobV['error'], 400); }
    $dob = $dobV['value'];

    $genderV = nsmsValidateGender($data['gender']);
    if (!$genderV['ok']) { ob_end_clean(); errorResponse($genderV['error'], 400); }
    $gender = $genderV['value'];

    $address = !empty($data['address']) ? sanitize($data['address']) : '';
    if ($address !== '' && mb_strlen($address) > 500) {
        ob_end_clean();
        errorResponse('Address is too long', 400);
    }

    $enrollV = nsmsValidateDate($data['enrollment_date'], 'Enrollment date', true, 2000);
    if (!$enrollV['ok']) { ob_end_clean(); errorResponse($enrollV['error'], 400); }
    $enrollmentDate = $enrollV['value'];

    // Age vs class minimum
    $minAge = isset($classRow['minimum_age']) && $classRow['minimum_age'] !== null && $classRow['minimum_age'] !== ''
        ? (int) $classRow['minimum_age'] : 0;
    if ($minAge > 0) {
        $ageCheck = nsmsMeetsMinimumAge($dob, $minAge, $enrollmentDate);
        if (!$ageCheck['ok']) {
            ob_end_clean();
            errorResponse(
                'This student does not meet the minimum age requirement for '
                . $classRow['class_name'] . '. The minimum required age is '
                . $minAge . ' years.',
                400
            );
        }
    }

    $parentName = null;
    $parentPhone = null;
    $parentEmail = null;
    $parentRel = 'Guardian';

    if (!empty($data['parent_name'])) {
        $pn = nsmsValidatePersonName($data['parent_name'], 'Parent name');
        if (!$pn['ok']) { ob_end_clean(); errorResponse($pn['error'], 400); }
        $parentName = $pn['value'];
    }
    if (!empty($data['parent_phone'])) {
        $pp = nsmsValidatePhone($data['parent_phone'], false, 'Phone number');
        if (!$pp['ok']) { ob_end_clean(); errorResponse($pp['error'], 400); }
        $parentPhone = $pp['value'];
    }
    if (!empty($data['parent_email'])) {
        $pe = nsmsValidateEmail($data['parent_email'], false, 'Email');
        if (!$pe['ok']) { ob_end_clean(); errorResponse($pe['error'], 400); }
        $parentEmail = $pe['value'];
        // One email = one user. Parent email may only match an existing *parent* account.
        if ($parentEmail !== '' && function_exists('nsmsFindUserByEmail')) {
            $existing = nsmsFindUserByEmail($db, $parentEmail);
            if ($existing) {
                $role = strtolower(trim((string) ($existing['role'] ?? '')));
                if ($role !== 'parent') {
                    ob_end_clean();
                    errorResponse(
                        'This email is already registered to another user. Each email can only belong to one account. Use a different parent email.',
                        400
                    );
                }
            }
        }
    }
    if (!empty($data['parent_relationship'])) {
        $rel = sanitize($data['parent_relationship']);
        $validRels = array('Father', 'Mother', 'Guardian', 'Other');
        if (!in_array($rel, $validRels, true)) {
            ob_end_clean();
            errorResponse('Please select a valid parent relationship', 400);
        }
        $parentRel = $rel;
    }

    $studentId = $db->execute(
        "INSERT INTO students
             (student_name, class_id, date_of_birth, gender, address,
              enrollment_date, photo_url, status, created_at)
         VALUES
             (:sn, :cid, :dob, :gender, :address,
              :enroll, :photo, 'active', NOW())",
        [
            ':sn'     => $studentName,
            ':cid'    => $classId,
            ':dob'    => $dob,
            ':gender' => $gender,
            ':address'=> $address,
            ':enroll' => $enrollmentDate,
            ':photo'  => $photoUrl,
        ]
    );

    if (!$studentId) {
        ob_end_clean();
        errorResponse('Failed to create student', 500);
    }

    $parentResult = null;
    if ($parentName) {
        $parentResult = saveParentForStudent($db, $studentId, $studentName, $parentName, $parentPhone, $parentEmail, $parentRel);
        if (is_array($parentResult) && !empty($parentResult['error'])) {
            // Student row already created; surface clear message (parent link failed on unique email)
            ob_end_clean();
            errorResponse($parentResult['error'], 400);
        }
    }

    // ── Notify the class teacher about the new enrollment ────────────────────
    _notifyClassTeacher($db, $classId, $studentName, $studentId, $gender, $enrollmentDate);

    $responseData = [
        'id'           => $studentId,
        'student_name' => $studentName,
        'photo_url'    => $photoUrl,
    ];
    if ($photoWarning) {
        $responseData['photo_warning'] = $photoWarning;
    }
    if (is_array($parentResult)) {
        $responseData['parent_account_created'] = !empty($parentResult['is_new_account']);
        $responseData['welcome_email_sent'] = !empty($parentResult['welcome_email_sent']);
        if (!empty($parentResult['is_new_account']) && !empty($parentResult['parent_email'])) {
            $responseData['parent_email'] = $parentResult['parent_email'];
            // Temp password is emailed to the parent; also return for admin confirmation only
            $responseData['parent_temp_password'] = $parentResult['temp_password'];
        }
    }

    $msg = 'Student created successfully';
    if (is_array($parentResult) && !empty($parentResult['is_new_account'])) {
        if (!empty($parentResult['welcome_email_sent'])) {
            $msg .= '. A welcome email with login credentials was sent to the parent.';
        } elseif (!empty($parentResult['parent_email'])) {
            $msg .= '. Parent account created — welcome email could not be sent (check mail settings).';
        } else {
            $msg .= '. Parent account created (no email on file for welcome message).';
        }
    }

    if (class_exists('SyncHooks')) {
        SyncHooks::afterWrite($db, 'students', (int)$studentId, 'CREATE', array(
            'student_name' => $studentName,
            'class_id' => isset($classId) ? (int)$classId : null,
            'gender' => isset($gender) ? $gender : null,
            'date_of_birth' => isset($dob) ? $dob : (isset($dateOfBirth) ? $dateOfBirth : null),
            'status' => 'active',
        ));
    }

    ob_end_clean();
    successResponse($responseData, $msg);
}

/* ─────────────────────────────────────────
   UPDATE STUDENT
   Accepts PUT (JSON) or POST (multipart/file)
───────────────────────────────────────── */
function updateStudent($db) {
    requireRole('admin');

    $method = $_SERVER['REQUEST_METHOD'];
    if ($method !== 'PUT' && $method !== 'POST') {
        ob_end_clean();
        errorResponse('Method not allowed', 405);
    }

    $data = readBody();
    if (empty($data['id'])) {
        ob_end_clean();
        errorResponse('Student ID required');
    }
    $studentId = (int)$data['id'];

    $photoWarning = null;
    $newPhoto     = handlePhotoUpload($photoWarning);

    $updates = [];
    $params  = [':id' => $studentId];

    // ── Snapshot before validation (for transfer + age as-of) ──
    $beforeRow    = $db->queryOne(
        "SELECT class_id, student_name, gender, date_of_birth, enrollment_date FROM students WHERE id = :id",
        [':id' => $studentId]
    );
    if (!$beforeRow) {
        ob_end_clean();
        errorResponse('Student not found', 404);
    }
    $oldClassId      = (int) $beforeRow['class_id'];
    $currentName     = $beforeRow['student_name'];
    $currentGender   = $beforeRow['gender'];

    if (isset($data['student_name']) && $data['student_name'] !== '') {
        $nv = nsmsValidatePersonName($data['student_name'], 'Student name');
        if (!$nv['ok']) { ob_end_clean(); errorResponse($nv['error'], 400); }
        $updates[] = 'student_name = :student_name';
        $params[':student_name'] = $nv['value'];
    }
    if (isset($data['gender']) && $data['gender'] !== '') {
        $gv = nsmsValidateGender($data['gender']);
        if (!$gv['ok']) { ob_end_clean(); errorResponse($gv['error'], 400); }
        $updates[] = 'gender = :gender';
        $params[':gender'] = $gv['value'];
    }
    if (isset($data['address'])) {
        $address = sanitize($data['address']);
        if (mb_strlen($address) > 500) { ob_end_clean(); errorResponse('Address is too long', 400); }
        $updates[] = 'address = :address';
        $params[':address'] = $address;
    }
    if (isset($data['status']) && $data['status'] !== '') {
        $st = sanitize($data['status']);
        if (!in_array($st, array('active', 'inactive', 'graduated', 'transferred', 'withdrawn', 'suspended'), true)) {
            ob_end_clean(); errorResponse('Invalid status', 400);
        }
        $updates[] = 'status = :status';
        $params[':status'] = $st;
    }

    $dobForAge = $beforeRow['date_of_birth'];
    if (isset($data['date_of_birth']) && $data['date_of_birth'] !== '') {
        $dv = nsmsValidateDate($data['date_of_birth'], 'Date of birth', false, 1990);
        if (!$dv['ok']) { ob_end_clean(); errorResponse($dv['error'], 400); }
        $updates[] = 'date_of_birth = :date_of_birth';
        $params[':date_of_birth'] = $dv['value'];
        $dobForAge = $dv['value'];
    }
    $enrollForAge = !empty($beforeRow['enrollment_date']) ? $beforeRow['enrollment_date'] : date('Y-m-d');
    if (isset($data['enrollment_date']) && $data['enrollment_date'] !== '') {
        $ev = nsmsValidateDate($data['enrollment_date'], 'Enrollment date', true, 2000);
        if (!$ev['ok']) { ob_end_clean(); errorResponse($ev['error'], 400); }
        $updates[] = 'enrollment_date = :enrollment_date';
        $params[':enrollment_date'] = $ev['value'];
        $enrollForAge = $ev['value'];
    }

    $classIdForAge = $oldClassId;
    if (isset($data['class_id']) && $data['class_id'] !== '') {
        $classId = (int) $data['class_id'];
        if ($classId < 1) { ob_end_clean(); errorResponse('Please select a valid class', 400); }
        if (function_exists('nsmsEnsureClassMinimumAgeColumn')) {
            nsmsEnsureClassMinimumAgeColumn($db);
        }
        $classRow = $db->queryOne(
            "SELECT id, class_name, minimum_age FROM classes WHERE id = :id LIMIT 1",
            [':id' => $classId]
        );
        if (!$classRow) {
            $classRow = $db->queryOne("SELECT id, class_name FROM classes WHERE id = :id LIMIT 1", [':id' => $classId]);
            if ($classRow) $classRow['minimum_age'] = null;
        }
        if (!$classRow) { ob_end_clean(); errorResponse('Please select a valid class', 400); }
        $updates[] = 'class_id = :class_id';
        $params[':class_id'] = $classId;
        $classIdForAge = $classId;
        $minAge = isset($classRow['minimum_age']) && $classRow['minimum_age'] !== null && $classRow['minimum_age'] !== ''
            ? (int) $classRow['minimum_age'] : 0;
        if ($minAge > 0 && $dobForAge) {
            $ageCheck = nsmsMeetsMinimumAge($dobForAge, $minAge, $enrollForAge);
            if (!$ageCheck['ok']) {
                ob_end_clean();
                errorResponse(
                    'This student does not meet the minimum age requirement for '
                    . $classRow['class_name'] . '. The minimum required age is ' . $minAge . ' years.',
                    400
                );
            }
        }
    } elseif (isset($data['date_of_birth']) && $data['date_of_birth'] !== '' && $oldClassId) {
        // DOB changed while staying in same class — re-check min age
        if (function_exists('nsmsEnsureClassMinimumAgeColumn')) {
            nsmsEnsureClassMinimumAgeColumn($db);
        }
        $classRow = $db->queryOne(
            "SELECT id, class_name, minimum_age FROM classes WHERE id = :id LIMIT 1",
            [':id' => $oldClassId]
        );
        if ($classRow && isset($classRow['minimum_age']) && (int)$classRow['minimum_age'] > 0) {
            $ageCheck = nsmsMeetsMinimumAge($dobForAge, (int)$classRow['minimum_age'], $enrollForAge);
            if (!$ageCheck['ok']) {
                ob_end_clean();
                errorResponse(
                    'This student does not meet the minimum age requirement for '
                    . $classRow['class_name'] . '. The minimum required age is '
                    . (int)$classRow['minimum_age'] . ' years.',
                    400
                );
            }
        }
    }

    if ($newPhoto !== null) {
        $updates[]            = "photo_url = :photo_url";
        $params[':photo_url'] = $newPhoto;
    }

    if (empty($updates)) {
        ob_end_clean();
        errorResponse('No fields to update');
    }

    $result = $db->execute(
        "UPDATE students SET " . implode(', ', $updates) . " WHERE id = :id",
        $params
    );

    if ($result === false) {
        ob_end_clean();
        errorResponse('Failed to update student', 500);
    }

    // ── Detect class transfer and notify affected teachers ────────────────────
    $newClassId = isset($params[':class_id']) ? (int)$params[':class_id'] : 0;
    if ($newClassId && $newClassId !== $oldClassId) {
        $stuName = isset($params[':student_name'])
                 ? $params[':student_name']
                 : ($currentName ?: 'A student');
        $stuGender = isset($params[':gender']) ? $params[':gender'] : $currentGender;

        // Notify NEW class teacher
        _notifyClassTeacher($db, $newClassId, $stuName, $studentId, $stuGender, date('Y-m-d'), true);

        // Notify OLD class teacher (if they existed)
        if ($oldClassId) {
            _notifyTransferOut($db, $oldClassId, $stuName, $studentId);
        }
    }

    // Update parent details if provided
    $parentName  = null;
    $parentPhone = null;
    $parentEmail = null;
    $parentRel   = 'Guardian';
    if (isset($data['parent_name']) && $data['parent_name'] !== '') {
        $pn = nsmsValidatePersonName($data['parent_name'], 'Parent name');
        if (!$pn['ok']) { ob_end_clean(); errorResponse($pn['error'], 400); }
        $parentName = $pn['value'];
    }
    if (isset($data['parent_phone']) && $data['parent_phone'] !== '') {
        $pp = nsmsValidatePhone($data['parent_phone'], false, 'Phone number');
        if (!$pp['ok']) { ob_end_clean(); errorResponse($pp['error'], 400); }
        $parentPhone = $pp['value'];
    }
    if (isset($data['parent_email']) && $data['parent_email'] !== '') {
        $pe = nsmsValidateEmail($data['parent_email'], false, 'Email');
        if (!$pe['ok']) { ob_end_clean(); errorResponse($pe['error'], 400); }
        $parentEmail = $pe['value'];
        if ($parentEmail !== '' && function_exists('nsmsFindUserByEmail')) {
            $existing = nsmsFindUserByEmail($db, $parentEmail);
            if ($existing) {
                $role = strtolower(trim((string) ($existing['role'] ?? '')));
                if ($role !== 'parent') {
                    ob_end_clean();
                    errorResponse(
                        'This email is already registered to another user. Each email can only belong to one account. Use a different parent email.',
                        400
                    );
                }
            }
        }
    }
    if (isset($data['parent_relationship']) && $data['parent_relationship'] !== '') {
        $rel = sanitize($data['parent_relationship']);
        if (!in_array($rel, array('Father', 'Mother', 'Guardian', 'Other'), true)) {
            ob_end_clean(); errorResponse('Please select a valid parent relationship', 400);
        }
        $parentRel = $rel;
    }

    if ($parentName !== null && $parentName !== '') {
        $existing = $db->queryOne(
            "SELECT p.id, p.user_id FROM parents p WHERE p.student_id = :sid LIMIT 1",
            [':sid' => $studentId]
        );
        if ($existing) {
            $uUpdates = [];
            $uParams  = [':uid' => $existing['user_id']];
            $uUpdates[] = "full_name = :fn"; $uParams[':fn'] = $parentName;
            if ($parentPhone !== null) { $uUpdates[] = "phone = :ph"; $uParams[':ph'] = $parentPhone; }
            if ($parentEmail !== null) { $uUpdates[] = "email = :em"; $uParams[':em'] = $parentEmail; }
            $db->execute("UPDATE users SET " . implode(', ', $uUpdates) . " WHERE id = :uid", $uParams);

            // Update relationship too
            $validRels = ['Father', 'Mother', 'Guardian', 'Other'];
            $rel = in_array($parentRel, $validRels) ? $parentRel : 'Guardian';
            $db->execute(
                "UPDATE parents SET relationship = :rel WHERE id = :pid",
                [':rel' => $rel, ':pid' => $existing['id']]
            );
        } else {
            saveParentForStudent($db, $studentId, $currentName, $parentName, $parentPhone, $parentEmail, $parentRel);
        }
    }

    $responseData = ['photo_url' => $newPhoto];
    if ($photoWarning) {
        $responseData['photo_warning'] = $photoWarning;
    }

    if (class_exists('SyncHooks') && !empty($data['id'])) {
        SyncHooks::afterWrite($db, 'students', (int)$data['id'], 'UPDATE', array(
            'student_name' => isset($data['student_name']) ? $data['student_name'] : null,
            'class_id' => isset($data['class_id']) ? (int)$data['class_id'] : null,
            'gender' => isset($data['gender']) ? $data['gender'] : null,
            'status' => isset($data['status']) ? $data['status'] : null,
        ));
    }

    ob_end_clean();
    successResponse($responseData, 'Student updated successfully');
}

/* ─────────────────────────────────────────
   STUDENT LIFECYCLE — no hard deletes
───────────────────────────────────────── */

function nsmsEnsureStudentLifecycleSchema($db) {
    static $done = false;
    if ($done) return;
    try {
        // Expand status enum if needed (MySQL 5.7+ / MariaDB)
        $col = $db->queryOne("SHOW COLUMNS FROM students LIKE 'status'");
        if ($col && isset($col['Type']) && strpos($col['Type'], 'suspended') === false) {
            $db->execute(
                "ALTER TABLE students
                 MODIFY COLUMN status ENUM('active','graduated','transferred','withdrawn','suspended','inactive')
                 NOT NULL DEFAULT 'active'"
            );
        }
    } catch (Exception $e) {
        error_log('nsmsEnsureStudentLifecycleSchema enum: ' . $e->getMessage());
    }
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS student_lifecycle_events (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                student_id INT NOT NULL,
                action VARCHAR(40) NOT NULL,
                from_status VARCHAR(30) NULL,
                to_status VARCHAR(30) NOT NULL,
                event_date DATE NULL,
                destination VARCHAR(255) NULL,
                reason TEXT NULL,
                remarks TEXT NULL,
                authorized_by_name VARCHAR(120) NULL,
                performed_by INT NULL,
                meta_json TEXT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_sle_student (student_id),
                KEY idx_sle_action (action),
                KEY idx_sle_created (created_at)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) {
        error_log('nsmsEnsureStudentLifecycleSchema table: ' . $e->getMessage());
    }
    $done = true;
}

function nsmsStudentStatuses() {
    return array('active', 'transferred', 'withdrawn', 'graduated', 'suspended', 'inactive');
}

function nsmsRecordLifecycleEvent($db, $studentId, $action, $from, $to, $fields = array()) {
    nsmsEnsureStudentLifecycleSchema($db);
    $performedBy = null;
    if (function_exists('getCurrentUserId')) {
        $performedBy = getCurrentUserId();
    } elseif (!empty($_SESSION['user_id'])) {
        $performedBy = (int) $_SESSION['user_id'];
    }
    try {
        $db->execute(
            "INSERT INTO student_lifecycle_events
                (student_id, action, from_status, to_status, event_date, destination, reason, remarks,
                 authorized_by_name, performed_by, meta_json, created_at)
             VALUES
                (:sid, :act, :fs, :ts, :ed, :dest, :reason, :remarks, :auth, :pb, :meta, NOW())",
            array(
                ':sid' => (int) $studentId,
                ':act' => $action,
                ':fs' => $from,
                ':ts' => $to,
                ':ed' => !empty($fields['event_date']) ? $fields['event_date'] : date('Y-m-d'),
                ':dest' => isset($fields['destination']) ? $fields['destination'] : null,
                ':reason' => isset($fields['reason']) ? $fields['reason'] : null,
                ':remarks' => isset($fields['remarks']) ? $fields['remarks'] : null,
                ':auth' => isset($fields['authorized_by']) ? $fields['authorized_by'] : null,
                ':pb' => $performedBy,
                ':meta' => !empty($fields['meta']) ? json_encode($fields['meta']) : null,
            )
        );
    } catch (Exception $e) {
        error_log('nsmsRecordLifecycleEvent: ' . $e->getMessage());
    }
    if ($performedBy && function_exists('logActivity')) {
        logActivity($db, $performedBy, strtoupper($action) . '_STUDENT',
            "Student #{$studentId}: {$from} → {$to}");
    }
}

function nsmsChangeStudentStatus($db, $studentId, $toStatus, $action, $fields = array()) {
    requireRole('admin');
    nsmsEnsureStudentLifecycleSchema($db);
    $allowed = nsmsStudentStatuses();
    if (!in_array($toStatus, $allowed, true)) {
        ob_end_clean();
        errorResponse('Invalid target status', 400);
    }
    $row = $db->queryOne(
        "SELECT id, student_name, status, class_id FROM students WHERE id = :id LIMIT 1",
        array(':id' => (int) $studentId)
    );
    if (!$row) {
        ob_end_clean();
        errorResponse('Student not found', 404);
    }
    $from = $row['status'] ?: 'active';
    if ($from === $toStatus && $action !== 'reactivate') {
        ob_end_clean();
        errorResponse('Student is already ' . $toStatus, 400);
    }
    $ok = $db->execute(
        "UPDATE students SET status = :st WHERE id = :id",
        array(':st' => $toStatus, ':id' => (int) $studentId)
    );
    if ($ok === false) {
        ob_end_clean();
        errorResponse('Failed to update student status', 500);
    }
    nsmsRecordLifecycleEvent($db, $studentId, $action, $from, $toStatus, $fields);

    // Notify old class teacher on transfer/withdraw out
    if (in_array($toStatus, array('transferred', 'withdrawn'), true) && !empty($row['class_id'])) {
        if (function_exists('_notifyClassTeacherOnTransferOut')) {
            _notifyClassTeacherOnTransferOut($db, (int)$row['class_id'], $row['student_name'], (int)$studentId);
        }
    }

    if (class_exists('SyncHooks')) {
        SyncHooks::afterWrite($db, 'students', (int)$studentId, 'UPDATE', array(
            'status' => $toStatus,
            'lifecycle_action' => $action,
        ));
    }
    return array(
        'id' => (int) $studentId,
        'student_name' => $row['student_name'],
        'from_status' => $from,
        'to_status' => $toStatus,
        'status' => $toStatus,
    );
}

function transferStudent($db) {
    requireRole('admin');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }
    $data = readBody();
    $id = isset($data['student_id']) ? (int)$data['student_id'] : (isset($data['id']) ? (int)$data['id'] : 0);
    if ($id < 1) { ob_end_clean(); errorResponse('Student ID required', 400); }

    $eventDate = !empty($data['transfer_date']) ? $data['transfer_date'] : date('Y-m-d');
    $dv = function_exists('nsmsValidateDate') ? nsmsValidateDate($eventDate, 'Transfer date', true, 2000) : array('ok' => true, 'value' => $eventDate);
    if (empty($dv['ok'])) { ob_end_clean(); errorResponse($dv['error'], 400); }

    $destination = isset($data['destination']) ? trim(sanitize($data['destination'])) : '';
    $reason = isset($data['reason']) ? trim(sanitize($data['reason'])) : '';
    $remarks = isset($data['remarks']) ? trim(sanitize($data['remarks'])) : '';
    $auth = isset($data['authorized_by']) ? trim(sanitize($data['authorized_by'])) : '';

    if ($destination === '') {
        ob_end_clean(); errorResponse('Destination school/institution is required', 400);
    }

    $result = nsmsChangeStudentStatus($db, $id, 'transferred', 'transfer', array(
        'event_date' => $dv['value'],
        'destination' => $destination,
        'reason' => $reason,
        'remarks' => $remarks,
        'authorized_by' => $auth,
    ));
    ob_end_clean();
    successResponse($result, 'Student transferred. Historical records are preserved.');
}

function withdrawStudent($db) {
    requireRole('admin');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }
    $data = readBody();
    $id = isset($data['student_id']) ? (int)$data['student_id'] : (isset($data['id']) ? (int)$data['id'] : 0);
    if ($id < 1) { ob_end_clean(); errorResponse('Student ID required', 400); }

    $eventDate = !empty($data['leave_date']) ? $data['leave_date'] : (!empty($data['withdraw_date']) ? $data['withdraw_date'] : date('Y-m-d'));
    $dv = function_exists('nsmsValidateDate') ? nsmsValidateDate($eventDate, 'Leave date', true, 2000) : array('ok' => true, 'value' => $eventDate);
    if (empty($dv['ok'])) { ob_end_clean(); errorResponse($dv['error'], 400); }

    $reason = isset($data['reason']) ? trim(sanitize($data['reason'])) : '';
    if ($reason === '') { ob_end_clean(); errorResponse('Reason for leaving is required', 400); }

    $result = nsmsChangeStudentStatus($db, $id, 'withdrawn', 'withdraw', array(
        'event_date' => $dv['value'],
        'destination' => isset($data['destination']) ? trim(sanitize($data['destination'])) : null,
        'reason' => $reason,
        'remarks' => isset($data['remarks']) ? trim(sanitize($data['remarks'])) : null,
        'authorized_by' => isset($data['authorized_by']) ? trim(sanitize($data['authorized_by'])) : null,
        'meta' => array('last_class_id' => isset($data['last_class_id']) ? (int)$data['last_class_id'] : null),
    ));
    ob_end_clean();
    successResponse($result, 'Student marked as withdrawn. All historical records are preserved.');
}

function graduateStudent($db) {
    requireRole('admin');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }
    $data = readBody();
    $id = isset($data['student_id']) ? (int)$data['student_id'] : (isset($data['id']) ? (int)$data['id'] : 0);
    if ($id < 1) { ob_end_clean(); errorResponse('Student ID required', 400); }
    $eventDate = !empty($data['graduation_date']) ? $data['graduation_date'] : date('Y-m-d');
    $result = nsmsChangeStudentStatus($db, $id, 'graduated', 'graduate', array(
        'event_date' => $eventDate,
        'reason' => isset($data['reason']) ? trim(sanitize($data['reason'])) : 'Graduated',
        'remarks' => isset($data['remarks']) ? trim(sanitize($data['remarks'])) : null,
        'authorized_by' => isset($data['authorized_by']) ? trim(sanitize($data['authorized_by'])) : null,
    ));
    ob_end_clean();
    successResponse($result, 'Student marked as graduated. Records preserved.');
}

function suspendStudent($db) {
    requireRole('admin');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }
    $data = readBody();
    $id = isset($data['student_id']) ? (int)$data['student_id'] : (isset($data['id']) ? (int)$data['id'] : 0);
    if ($id < 1) { ob_end_clean(); errorResponse('Student ID required', 400); }
    $reason = isset($data['reason']) ? trim(sanitize($data['reason'])) : '';
    if ($reason === '') { ob_end_clean(); errorResponse('Suspension reason is required', 400); }
    $result = nsmsChangeStudentStatus($db, $id, 'suspended', 'suspend', array(
        'event_date' => !empty($data['suspend_date']) ? $data['suspend_date'] : date('Y-m-d'),
        'reason' => $reason,
        'remarks' => isset($data['remarks']) ? trim(sanitize($data['remarks'])) : null,
        'authorized_by' => isset($data['authorized_by']) ? trim(sanitize($data['authorized_by'])) : null,
    ));
    ob_end_clean();
    successResponse($result, 'Student suspended. Records preserved.');
}

function reactivateStudent($db) {
    requireRole('admin');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean(); errorResponse('Method not allowed', 405);
    }
    $data = readBody();
    $id = isset($data['student_id']) ? (int)$data['student_id'] : (isset($data['id']) ? (int)$data['id'] : 0);
    if ($id < 1) { ob_end_clean(); errorResponse('Student ID required', 400); }

    $row = $db->queryOne("SELECT id, status, class_id, student_name FROM students WHERE id = :id", array(':id' => $id));
    if (!$row) { ob_end_clean(); errorResponse('Student not found', 404); }
    if (($row['status'] ?: '') === 'active') {
        ob_end_clean(); errorResponse('Student is already active', 400);
    }

    $newClassId = !empty($data['class_id']) ? (int)$data['class_id'] : (int)$row['class_id'];
    if ($newClassId > 0) {
        $cls = $db->queryOne("SELECT id, class_name FROM classes WHERE id = :id", array(':id' => $newClassId));
        if (!$cls) { ob_end_clean(); errorResponse('Please select a valid class', 400); }
    }

    $eventDate = !empty($data['reactivation_date']) ? $data['reactivation_date'] : date('Y-m-d');
    $from = $row['status'];

    $sql = "UPDATE students SET status = 'active'";
    $params = array(':id' => $id);
    if ($newClassId > 0) {
        $sql .= ", class_id = :cid";
        $params[':cid'] = $newClassId;
    }
    $sql .= " WHERE id = :id";
    if ($db->execute($sql, $params) === false) {
        ob_end_clean(); errorResponse('Failed to reactivate student', 500);
    }

    nsmsEnsureStudentLifecycleSchema($db);
    nsmsRecordLifecycleEvent($db, $id, 'reactivate', $from, 'active', array(
        'event_date' => $eventDate,
        'reason' => isset($data['reason']) ? trim(sanitize($data['reason'])) : 'Re-enrolled',
        'remarks' => isset($data['remarks']) ? trim(sanitize($data['remarks'])) : null,
        'authorized_by' => isset($data['authorized_by']) ? trim(sanitize($data['authorized_by'])) : null,
        'meta' => array(
            'new_class_id' => $newClassId,
            'academic_year' => isset($data['academic_year']) ? $data['academic_year'] : null,
        ),
    ));

    if ($newClassId > 0 && function_exists('_notifyClassTeacher')) {
        _notifyClassTeacher($db, $newClassId, $row['student_name'], $id, '', $eventDate, true);
    }

    ob_end_clean();
    successResponse(array(
        'id' => $id,
        'status' => 'active',
        'class_id' => $newClassId,
        'from_status' => $from,
    ), 'Student reactivated and returned to the active list. Prior history is preserved.');
}

function studentLifecycleHistory($db) {
    requireRole(array('admin', 'teacher'));
    nsmsEnsureStudentLifecycleSchema($db);
    $id = isset($_GET['student_id']) ? (int)$_GET['student_id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
    if ($id < 1) { ob_end_clean(); errorResponse('Student ID required', 400); }
    $rows = $db->query(
        "SELECT e.*, u.full_name AS performed_by_name
           FROM student_lifecycle_events e
           LEFT JOIN users u ON u.id = e.performed_by
          WHERE e.student_id = :sid
          ORDER BY e.created_at DESC, e.id DESC",
        array(':sid' => $id)
    );
    ob_end_clean();
    successResponse($rows ?: array());
}

function studentStatusCounts($db) {
    requireRole(array('admin', 'teacher'));
    nsmsEnsureStudentLifecycleSchema($db);
    $rows = $db->query(
        "SELECT status, COUNT(*) AS cnt FROM students GROUP BY status"
    ) ?: array();
    $out = array(
        'active' => 0, 'transferred' => 0, 'withdrawn' => 0,
        'graduated' => 0, 'suspended' => 0, 'inactive' => 0, 'total' => 0
    );
    foreach ($rows as $r) {
        $st = $r['status'] ?: 'active';
        $c = (int)$r['cnt'];
        if (isset($out[$st])) $out[$st] = $c;
        $out['total'] += $c;
    }
    ob_end_clean();
    successResponse($out);
}

/* ─────────────────────────────────────────
   DELETE STUDENT (soft delete → withdrawn)
───────────────────────────────────────── */
function deleteStudent($db) {
    requireRole('admin');
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean();
        errorResponse('Method not allowed', 405);
    }
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id < 1) {
        $data = readBody();
        $id = isset($data['id']) ? (int)$data['id'] : 0;
    }
    if ($id < 1) {
        ob_end_clean();
        errorResponse('Student ID required');
    }

    // Prefer proper withdraw path if body provides reason; else soft-withdraw with audit
    $data = readBody();
    $reason = isset($data['reason']) ? trim(sanitize($data['reason'])) : 'Removed from active list by administrator';
    $result = nsmsChangeStudentStatus($db, $id, 'withdrawn', 'withdraw', array(
        'event_date' => date('Y-m-d'),
        'reason' => $reason,
        'remarks' => 'Soft delete via delete action — record retained',
    ));
    if (class_exists('SyncHooks')) {
        SyncHooks::afterWrite($db, 'students', (int)$id, 'DELETE', array(
            'status' => 'withdrawn',
        ));
    }
    ob_end_clean();
    successResponse($result, 'Student withdrawn from active list. Historical records are preserved.');
}

/* ─────────────────────────────────────────
   SEARCH STUDENTS
───────────────────────────────────────── */
function searchStudents($db) {
    $query = isset($_GET['q']) ? trim($_GET['q']) : '';
    if (empty($query)) {
        ob_end_clean();
        errorResponse('Search query required');
    }

    $t   = '%' . $query . '%';
    $sql = "SELECT s.id, s.student_name, s.photo_url,
                   c.class_name, c.class_color, s.status,
                   u.full_name AS parent_name, u.phone AS parent_phone
            FROM students s
            JOIN   classes c ON s.class_id = c.id
            LEFT JOIN parents p ON s.id = p.student_id
            LEFT JOIN users   u ON p.user_id = u.id
            WHERE (s.student_name LIKE :q OR u.full_name LIKE :q
                OR u.phone LIKE :q OR u.email LIKE :q)
            AND s.status = 'active'
            ORDER BY s.student_name ASC LIMIT 20";

    ob_end_clean();
    successResponse($db->query($sql, [':q' => $t]) ?: []);
}

/* ─────────────────────────────────────────
   NOTIFICATION HELPERS
   All helpers are non-fatal — a notification
   failure must never break the main response.
───────────────────────────────────────── */

/**
 * Notify the class teacher when a new student is enrolled.
 * $isTransfer = true generates a "transferred in" message instead of "enrolled".
 */
function _notifyClassTeacher($db, $classId, $studentName, $studentId, $gender, $enrollDate, $isTransfer = false) {
    try {
        $classRow = $db->queryOne(
            "SELECT teacher_id, class_name FROM classes
              WHERE id = :cid AND teacher_id IS NOT NULL",
            [':cid' => (int)$classId]
        );
        if (!$classRow) return; // no teacher assigned to this class yet

        $teacherUserId = (int)$classRow['teacher_id'];
        $className     = $classRow['class_name'];
        $pronoun       = (strtolower($gender) === 'female') ? 'She' : 'They';
        $dateStr       = date('d M Y', strtotime($enrollDate));
        $refKey        = 'new_student_' . (int)$studentId;

        if ($isTransfer) {
            $title   = '🔄 Student Transferred In: ' . $studentName;
            $message = $studentName . ' has been transferred into ' . $className
                     . ' as of ' . $dateStr . '. ' . $pronoun
                     . ' will appear in your attendance and class list.';
        } else {
            $title   = '🎒 New Student: ' . $studentName;
            $message = $studentName . ' has been enrolled in ' . $className
                     . ' as of ' . $dateStr . '. ' . $pronoun
                     . ' will appear in your attendance and class list.';
        }

        _notifyUser($db, $teacherUserId, 'new_student', $title, $message, $refKey);
    } catch (Exception $e) { /* non-fatal */ }
}

/**
 * Notify the class teacher when a student is transferred OUT of their class.
 */
function _notifyTransferOut($db, $classId, $studentName, $studentId) {
    try {
        $classRow = $db->queryOne(
            "SELECT teacher_id, class_name FROM classes
              WHERE id = :cid AND teacher_id IS NOT NULL",
            [':cid' => (int)$classId]
        );
        if (!$classRow) return;

        $teacherUserId = (int)$classRow['teacher_id'];
        $className     = $classRow['class_name'];
        // Use today-scoped key so this can fire again if the student is transferred back later
        $refKey        = 'transfer_out_' . (int)$studentId . '_' . date('Y-m-d');

        _notifyUser(
            $db, $teacherUserId,
            'system',
            '↩️ Student Transferred Out: ' . $studentName,
            $studentName . ' has been transferred out of ' . $className
            . '. They will no longer appear in your class list.',
            $refKey
        );
    } catch (Exception $e) { /* non-fatal */ }
}

/**
 * Core insert helper — shared by both notification functions above.
 * De-duplicates by reference_key, degrades gracefully if the column is missing.
 */
function _notifyUser($db, $userId, $type, $title, $message, $refKey) {
    try {
        $isDup = false;
        try {
            $ex = $db->query(
                "SELECT id FROM notifications
                  WHERE user_id = ? AND reference_key = ? LIMIT 1",
                [$userId, $refKey]
            );
            $isDup = (bool)$ex;
        } catch (Exception $e) {
            try {
                $ex = $db->query(
                    "SELECT id FROM notifications
                      WHERE user_id = ? AND type = ? AND title = ?
                        AND DATE(created_at) = CURDATE() LIMIT 1",
                    [$userId, $type, $title]
                );
                $isDup = (bool)$ex;
            } catch (Exception $e2) { /* proceed */ }
        }
        if ($isDup) return;

        try {
            $db->execute(
                "INSERT INTO notifications
                     (user_id, type, title, message, is_read, reference_key, created_at)
                 VALUES (?, ?, ?, ?, 0, ?, NOW())",
                [$userId, $type, $title, $message, $refKey]
            );
        } catch (Exception $e) {
            $db->execute(
                "INSERT INTO notifications
                     (user_id, type, title, message, is_read, created_at)
                 VALUES (?, ?, ?, ?, 0, NOW())",
                [$userId, $type, $title, $message]
            );
        }
    } catch (Exception $e) { /* non-fatal */ }
}
