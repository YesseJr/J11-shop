<?php
/**
 * Authentication API
 * Handles login, logout, session checks, notifications, and reminder generation.
 *
 * Actions (GET):
 *   login | logout | check | me
 *   notifications_count | notifications | mark_notifications_read
 *   generate_reminders
 */

ob_start();

header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';
require_once __DIR__ . '/../includes/sync/OfflineAuth.php';

applyApiHeaders();

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

// ── Session user (0 when not logged in) ──────────────────────────────────────
$sessionUserId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;

// ── Database ──────────────────────────────────────────────────────────────────
$db   = new Database();
$conn = $db->connect();

$mysqlOnline = (bool)$conn;
$action = isset($_GET['action']) ? $_GET['action'] : '';

// When MySQL is down, only a small set of auth actions may proceed (offline).
if (!$mysqlOnline) {
    $offlineAllowed = array('login', 'logout', 'check', 'me', 'csrf', 'session', 'notifications', 'notifications_count', 'mark_notifications_read');
    if (!in_array($action, $offlineAllowed, true)) {
        ob_end_clean();
        errorResponse('Database unavailable. You are offline — only login/session checks work until MySQL returns.', 503);
    }
    // Soft empty notifications while offline (no MySQL bell store)
    if ($action === 'notifications_count') {
        ob_end_clean();
        successResponse(array(
            'notifications' => 0,
            'messages' => 0,
            'total' => 0,
            'offline_mode' => true,
        ), 'Offline — no live notifications');
    }
    if ($action === 'notifications') {
        ob_end_clean();
        successResponse(array(), 'Offline — notifications unavailable');
    }
    if ($action === 'mark_notifications_read') {
        ob_end_clean();
        successResponse(null, 'Offline — nothing to mark');
    }
}

// =============================================================================
switch ($action) {
    case 'csrf':
        // Public: any visitor with a session can obtain a CSRF token
        ob_end_clean();
        successResponse(array('csrf_token' => ensureCsrfToken()));
        break;

// =============================================================================

    // ── LOGIN ─────────────────────────────────────────────────────────────────
    case 'login':
        handleLogin($db);
        break;

    // ── LOGOUT ────────────────────────────────────────────────────────────────
    case 'logout':
        handleLogout();
        break;

    case 'forgot_password':
        handleForgotPassword($db);
        break;

    case 'complete_password_reset':
        handleCompletePasswordReset($db);
        break;

    // ── SESSION CHECK ─────────────────────────────────────────────────────────
    case 'check':
        handleCheckSession();
        break;

    // ── CURRENT USER ─────────────────────────────────────────────────────────
    case 'me':
        handleGetCurrentUser($db);
        break;

    // ── NOTIFICATIONS COUNT ───────────────────────────────────────────────────
    // Returns split counts: messages (messages table) + alerts (pulse_alert_recipients
    // for admin/teacher, notifications table for parents) so NSMSBell can show badges.
    // Also returns pending_payments count for admin role.
    case 'notifications_count':
        requireAuth();
        $me      = $sessionUserId ?: myId();
        $myRole  = isset($_SESSION['role']) ? $_SESSION['role'] : '';

        $rMsg = $db->queryOne(
            "SELECT COUNT(*) AS c FROM messages
              WHERE recipient_id = :uid AND is_read = 0",
            [':uid' => $me]
        );
        $mc = $rMsg ? (int)$rMsg['c'] : 0;

        // Notifications badge — source differs by role:
        //   admin/teacher: pulse_alert_recipients (what their bell reads)
        //   parent:        notifications table (what their bell reads)
        $nc = 0;
        if (in_array($myRole, ['admin', 'teacher'])) {
            $rNotif = $db->queryOne(
                "SELECT COUNT(*) AS c FROM pulse_alert_recipients
                  WHERE user_id = :uid AND is_read = 0",
                [':uid' => $me]
            );
            $nc = $rNotif ? (int)$rNotif['c'] : 0;
        } else {
            // Parent: read from notifications table
            $rNotif = $db->queryOne(
                "SELECT COUNT(*) AS c FROM notifications
                  WHERE user_id = :uid AND is_read = 0",
                [':uid' => $me]
            );
            $nc = $rNotif ? (int)$rNotif['c'] : 0;
        }

        // Admin gets pending payment count so the sidebar badge can show it
        $pendingPayments = 0;
        if ($myRole === 'admin') {
            try {
                $rPend = $db->queryOne(
                    "SELECT COUNT(*) AS c FROM payment_transactions WHERE status='pending_verification'"
                );
                $pendingPayments = $rPend ? (int)$rPend['c'] : 0;
            } catch (Exception $e) { /* table may not exist */ }
        }

        ob_end_clean();
        successResponse([
            'messages'         => $mc,
            'notifications'    => $nc,
            'total'            => $mc + $nc,
            'pending_payments' => $pendingPayments,
        ]);
        break;

    // ── NOTIFICATIONS (items) ─────────────────────────────────────────────────
    // Returns the most recent 30 notification rows for the logged-in user.
    // Used by NSMSBell to render the Alerts tab with actual content.
    case 'notifications':
        requireAuth();
        $me     = $sessionUserId ?: myId();
        $myRole = isset($_SESSION['role']) ? $_SESSION['role'] : '';
        $items  = [];
        if (in_array($myRole, ['admin', 'teacher'])) {
            // Admin/teacher: serve from pulse_alert_recipients (their bell source)
            try {
                $items = $db->query(
                    "SELECT par.alert_id AS id,
                            'pulse_alert'  AS type,
                            pa.title,
                            pa.body        AS message,
                            pa.priority,
                            par.is_read,
                            pa.created_at
                       FROM pulse_alert_recipients par
                       JOIN pulse_alerts pa ON pa.id = par.alert_id
                      WHERE par.user_id = :uid
                      ORDER BY pa.created_at DESC
                      LIMIT 30",
                    [':uid' => $me]
                ) ?: [];
            } catch (Exception $e) {
                /* pulse_alerts table not yet created — return empty */
            }
        } else {
            // Parent: serve from notifications table (their bell source)
            try {
                $items = $db->query(
                    "SELECT id, type, title, message,
                            'medium' AS priority,
                            is_read, created_at
                       FROM notifications
                      WHERE user_id = :uid
                      ORDER BY created_at DESC
                      LIMIT 30",
                    [':uid' => $me]
                ) ?: [];
            } catch (Exception $e) { /* non-fatal */ }
        }

        ob_end_clean();
        successResponse($items);
        break;

    // ── MARK NOTIFICATIONS READ ───────────────────────────────────────────────
    // POST { "id": N } → mark single notification N as read
    // POST { "id": 0 } → mark ALL notifications as read for this user
    case 'mark_notifications_read':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('POST required', 405);
        }
        requireAuth();
        $me     = $sessionUserId ?: myId();
        $myRole = isset($_SESSION['role']) ? $_SESSION['role'] : '';
        $input  = json_decode(file_get_contents('php://input'), true);
        $nid    = isset($input['id']) ? (int)$input['id'] : 0;
        try {
            if (in_array($myRole, ['admin','teacher'])) {
                // Mark pulse_alert_recipients
                if ($nid > 0) {
                    $db->execute(
                        "UPDATE pulse_alert_recipients SET is_read = 1, read_at = NOW()
                          WHERE alert_id = :id AND user_id = :uid",
                        [':id' => $nid, ':uid' => $me]
                    );
                } else {
                    $db->execute(
                        "UPDATE pulse_alert_recipients SET is_read = 1, read_at = NOW()
                          WHERE user_id = :uid AND is_read = 0",
                        [':uid' => $me]
                    );
                }
            } else {
                // Mark notifications table for parents
                if ($nid > 0) {
                    $db->execute(
                        "UPDATE notifications SET is_read = 1, read_at = NOW()
                          WHERE id = :id AND user_id = :uid",
                        [':id' => $nid, ':uid' => $me]
                    );
                } else {
                    $db->execute(
                        "UPDATE notifications SET is_read = 1, read_at = NOW()
                          WHERE user_id = :uid AND is_read = 0",
                        [':uid' => $me]
                    );
                }
            }
        } catch (Exception $e) {
            /* non-fatal — table may not exist yet */
        }

        ob_end_clean();
        successResponse(['marked' => true]);
        break;

    // ── GENERATE REMINDERS ────────────────────────────────────────────────────
    // Auto-creates notifications for:
    //   1. Upcoming exams / assessments in calendar_events (≤ 14 days ahead)
    //   2. Students with 3+ consecutive absences (school-wide, admin view)
    //   3. Students with attendance < 75% in last 30 days (once per week)
    //   4. New student enrolments in the last 30 days
    //   5. Outstanding fee payments (students with balance > 0)
    //   6. Recent announcements not yet acknowledged
    //
    // De-duplication: uses reference_key on the notifications table.
    // Falls back to title+type+date check if the column does not exist yet.
    //
    // Add the column with:
    //   ALTER TABLE notifications
    //     ADD COLUMN reference_key VARCHAR(120) NULL DEFAULT NULL,
    //     ADD INDEX idx_notif_refkey (user_id, reference_key);
    //
    // NOTE: This case MUST remain before the default case — PHP's switch
    //       will never reach a case that follows default once default matches.
    case 'generate_reminders':
        requireAuth();
        $me      = $sessionUserId ?: myId();
        $today   = date('Y-m-d');
        $created = 0;

        // ── Helper closure: insert only if reference_key is not yet used ──────
        $insertReminder = function ($type, $title, $message, $refKey)
            use ($db, $me, &$created)
        {
            try {
                $isDup = false;

                // Prefer reference_key check; fall back if column missing
                try {
                    $ex    = $db->query(
                        "SELECT id FROM notifications
                          WHERE user_id = ? AND reference_key = ? LIMIT 1",
                        [$me, $refKey]
                    );
                    $isDup = (bool)$ex;
                } catch (Exception $e) {
                    try {
                        $ex    = $db->query(
                            "SELECT id FROM notifications
                              WHERE user_id = ? AND type = ? AND title = ?
                                AND DATE(created_at) = CURDATE() LIMIT 1",
                            [$me, $type, $title]
                        );
                        $isDup = (bool)$ex;
                    } catch (Exception $e2) {
                        /* cannot check — allow insert */
                    }
                }

                if ($isDup) return;

                // Insert with reference_key; fall back without it
                try {
                    $db->execute(
                        "INSERT INTO notifications
                             (user_id, type, title, message, is_read, reference_key, created_at)
                         VALUES (?, ?, ?, ?, 0, ?, NOW())",
                        [$me, $type, $title, $message, $refKey]
                    );
                } catch (Exception $e) {
                    $db->execute(
                        "INSERT INTO notifications
                             (user_id, type, title, message, is_read, created_at)
                         VALUES (?, ?, ?, ?, 0, NOW())",
                        [$me, $type, $title, $message]
                    );
                }
                $created++;

            } catch (Exception $e) {
                /* non-fatal */
            }
        };

        // ── 1. UPCOMING EXAM / ASSESSMENT REMINDERS ──────────────────────────
        // Fires for calendar_events with exam-like types within the next 14 days.
        try {
            $twoWeeksOut = date('Y-m-d', strtotime('+14 days'));
            $exams = $db->query(
                "SELECT id, title, event_date, description, event_type
                   FROM calendar_events
                  WHERE event_type IN ('exam','examination','test','assessment','exams')
                    AND event_date BETWEEN ? AND ?
                  ORDER BY event_date ASC",
                [$today, $twoWeeksOut]
            ) ?: [];

            foreach ($exams as $exam) {
                $daysLeft = (int)ceil(
                    (strtotime($exam['event_date']) - strtotime($today)) / 86400
                );
                $dayLabel = $daysLeft === 0 ? 'today'
                          : ($daysLeft === 1 ? 'tomorrow'
                          : 'in ' . $daysLeft . ' days');
                $dateStr  = date('D, d M Y', strtotime($exam['event_date']));
                $desc     = !empty($exam['description'])
                          ? ' — ' . $exam['description'] : '';

                $insertReminder(
                    'exam_reminder',
                    '📝 Exam ' . $dayLabel . ': ' . $exam['title'],
                    'Scheduled ' . $dayLabel . ' (' . $dateStr . ')' . $desc,
                    'exam_' . (int)$exam['id'] . '_' . $exam['event_date']
                );
            }
        } catch (Exception $e) {
            /* calendar_events table may differ — skip */
        }

        // ── 2. CONSECUTIVE ABSENCE ALERTS (school-wide) ──────────────────────
        // Flags any active student with 3+ consecutive absent records.
        try {
            $students = $db->query(
                "SELECT s.id, s.student_name, c.class_name
                   FROM students s
                   JOIN classes c ON c.id = s.class_id
                  WHERE s.status = 'active'
                  ORDER BY s.student_name ASC"
            ) ?: [];

            foreach ($students as $stu) {
                $stuId  = (int)$stu['id'];
                $recent = $db->query(
                    "SELECT status FROM attendance
                      WHERE student_id = ?
                      ORDER BY attendance_date DESC LIMIT 3",
                    [$stuId]
                ) ?: [];

                if (count($recent) === 3
                    && $recent[0]['status'] === 'absent'
                    && $recent[1]['status'] === 'absent'
                    && $recent[2]['status'] === 'absent'
                ) {
                    $insertReminder(
                        'attendance_issue',
                        '⚠️ Consecutive Absences: ' . $stu['student_name'],
                        $stu['student_name'] . ' (' . $stu['class_name'] . ')'
                        . ' has been absent for 3 or more consecutive school days.',
                        'att_consec_' . $stuId . '_' . $today
                    );
                }
            }
        } catch (Exception $e) {
            /* attendance / students table issue — skip */
        }

        // ── 3. LOW ATTENDANCE RATE (< 75% over last 30 days) ─────────────────
        // Fires at most once per student per ISO week.
        try {
            $students = $db->query(
                "SELECT s.id, s.student_name, c.class_name
                   FROM students s
                   JOIN classes c ON c.id = s.class_id
                  WHERE s.status = 'active'"
            ) ?: [];

            foreach ($students as $stu) {
                $stuId  = (int)$stu['id'];
                $refKey = 'att_low_' . $stuId . '_' . date('Y-W');

                // Skip if already sent this ISO week
                try {
                    $ex = $db->query(
                        "SELECT id FROM notifications
                          WHERE user_id = ? AND reference_key = ? LIMIT 1",
                        [$me, $refKey]
                    );
                    if ($ex) continue;
                } catch (Exception $e) {
                    /* reference_key column missing — proceed */
                }

                $attRow = $db->query(
                    "SELECT COUNT(*) AS total,
                            SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present_cnt
                       FROM attendance
                      WHERE student_id = ?
                        AND attendance_date >= DATE_SUB(?, INTERVAL 30 DAY)",
                    [$stuId, $today]
                );

                if ($attRow && (int)$attRow[0]['total'] >= 10) {
                    $total   = (int)$attRow[0]['total'];
                    $present = (int)$attRow[0]['present_cnt'];
                    $rate    = round(($present / $total) * 100);
                    if ($rate < 75) {
                        $insertReminder(
                            'attendance_issue',
                            '📉 Low Attendance: ' . $stu['student_name'],
                            $stu['student_name'] . ' (' . $stu['class_name'] . ')'
                            . ' has only ' . $rate . '% attendance over the last 30 days'
                            . ' (' . $present . '/' . $total . ' days).',
                            $refKey
                        );
                    }
                }
            }
        } catch (Exception $e) {
            /* attendance / students table issue — skip */
        }

        // ── 4. NEW STUDENT ENROLMENTS (last 30 days) ─────────────────────────
        // reference_key = 'new_student_{student_id}' — fires once per student.
        try {
            $newStudents = $db->query(
                "SELECT s.id, s.student_name, s.gender, s.enrollment_date, c.class_name
                   FROM students s
                   JOIN classes c ON c.id = s.class_id
                  WHERE s.status         = 'active'
                    AND s.enrollment_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                  ORDER BY s.enrollment_date DESC"
            ) ?: [];

            foreach ($newStudents as $ns) {
                $pronoun = (isset($ns['gender']) && strtolower($ns['gender']) === 'female')
                           ? 'She' : 'They';
                $dateStr = date('d M Y', strtotime($ns['enrollment_date']));

                $insertReminder(
                    'new_student',
                    '🎒 New Student: ' . $ns['student_name'],
                    $ns['student_name'] . ' has been enrolled in ' . $ns['class_name']
                    . ' as of ' . $dateStr . '. ' . $pronoun
                    . ' will appear in attendance and class lists.',
                    'new_student_' . (int)$ns['id']
                );
            }
        } catch (Exception $e) {
            /* students / classes table issue — skip */
        }

        // ── 5. OUTSTANDING FEE PAYMENTS ──────────────────────────────────────
        // Fires once per student per ISO week when their balance > 0.
        // Supports two common schema patterns:
        //   A) fees (student_id, amount_due, amount_paid)
        //   B) fee_payments (student_id, total_amount, paid_amount)
        try {
            $feeRows = [];
            try {
                // Pattern A
                $feeRows = $db->query(
                    "SELECT s.id, s.student_name, c.class_name,
                            (f.amount_due - COALESCE(f.amount_paid, 0)) AS balance
                       FROM students s
                       JOIN classes c ON c.id = s.class_id
                       JOIN fees f    ON f.student_id = s.id
                      WHERE s.status = 'active'
                        AND (f.amount_due - COALESCE(f.amount_paid, 0)) > 0"
                ) ?: [];
            } catch (Exception $e) {
                // Pattern B
                $feeRows = $db->query(
                    "SELECT s.id, s.student_name, c.class_name,
                            (fp.total_amount - COALESCE(fp.paid_amount, 0)) AS balance
                       FROM students s
                       JOIN classes c      ON c.id = s.class_id
                       JOIN fee_payments fp ON fp.student_id = s.id
                      WHERE s.status = 'active'
                        AND (fp.total_amount - COALESCE(fp.paid_amount, 0)) > 0"
                ) ?: [];
            }

            foreach ($feeRows as $fr) {
                $refKey = 'fee_outstanding_' . (int)$fr['id'] . '_' . date('Y-W');

                // Skip if already notified this ISO week
                try {
                    $ex = $db->query(
                        "SELECT id FROM notifications
                          WHERE user_id = ? AND reference_key = ? LIMIT 1",
                        [$me, $refKey]
                    );
                    if ($ex) continue;
                } catch (Exception $e) {
                    /* reference_key column missing — proceed */
                }

                $balance = number_format((float)$fr['balance'], 2);
                $insertReminder(
                    'fee_payment',
                    '💰 Outstanding Fee: ' . $fr['student_name'],
                    $fr['student_name'] . ' (' . $fr['class_name'] . ')'
                    . ' has an outstanding balance of ' . $balance . '.'
                    . ' Please follow up with the parent/guardian.',
                    $refKey
                );
            }
        } catch (Exception $e) {
            /* fees table not present or different schema — skip */
        }

        // ── 6. RECENT ANNOUNCEMENTS ───────────────────────────────────────────
        // Reminds the admin of their own announcements posted in the last 7 days.
        // reference_key = 'announcement_{id}' — fires once per announcement.
        try {
            $announcements = $db->query(
                "SELECT id, title, created_at
                   FROM announcements
                  WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                  ORDER BY created_at DESC
                  LIMIT 10"
            ) ?: [];

            foreach ($announcements as $ann) {
                $dateStr = date('d M Y', strtotime($ann['created_at']));
                $insertReminder(
                    'announcement',
                    '📢 Announcement: ' . $ann['title'],
                    'Posted on ' . $dateStr . '. Review and confirm it reached all intended recipients.',
                    'announcement_' . (int)$ann['id']
                );
            }
        } catch (Exception $e) {
            /* announcements table issue — skip */
        }

        ob_end_clean();
        successResponse(['generated' => $created]);
        break;

    // ── DEFAULT ───────────────────────────────────────────────────────────────
    // IMPORTANT: default must always be last. Any new case added above this
    // line is reachable; any case below it is dead code and will never execute.
    default:
        ob_end_clean();
        errorResponse('Invalid action', 400);
        break;

// =============================================================================
} // end switch
// =============================================================================


/**
 * Digits-only form of a phone string (for default-password matching).
 */
function nsmsPhoneDigits($phone) {
    return preg_replace('/\D+/', '', (string) $phone);
}

/**
 * Candidate temporary passwords for first-time activation (password_changed = 0).
 * Covers current and legacy defaults used when admin created the account.
 */
function nsmsTempPasswordCandidates($user, $typedPassword) {
    $cands = array();
    $add = function ($v) use (&$cands) {
        $v = (string) $v;
        if ($v !== '' && !in_array($v, $cands, true)) {
            $cands[] = $v;
        }
    };

    // Always try exactly what the user typed, and a digits-only form of it
    $add($typedPassword);
    $digitsTyped = nsmsPhoneDigits($typedPassword);
    if (strlen($digitsTyped) >= 6) {
        $add($digitsTyped);
    }

    $role  = isset($user['role']) ? $user['role'] : '';
    $phone = isset($user['phone']) ? trim((string) $user['phone']) : '';
    $pd    = $phone !== '' ? nsmsPhoneDigits($phone) : '';

    // If the typed value is clearly the same phone (last 9 digits match),
    // also try the phone string as stored in the DB — that is what older
    // installs hashed (with spaces / +255), so activation still works.
    if ($pd !== '' && $digitsTyped !== '' && strlen($digitsTyped) >= 9 && strlen($pd) >= 9) {
        if (substr($pd, -9) === substr($digitsTyped, -9)) {
            $add($phone);
            $add($pd);
        }
    } elseif ($pd !== '' && $digitsTyped !== '' && $pd === $digitsTyped) {
        $add($phone);
        $add($pd);
    }

    // Role defaults (and legacy parent default)
    if ($role === 'teacher') {
        $add('teacher123');
    }
    if ($role === 'parent') {
        $add('parent123');
        $add('Parent@nsms');
    }

    return $cands;
}

/**
 * Handle login (including first-time parent/teacher activation credentials).
 */
function handleLogin($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        errorResponse('Method not allowed', 405);
    }

    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        $data = $_POST;
    }

    if (!isset($data['email']) || !isset($data['password'])) {
        errorResponse('Email and password are required');
    }

    $email    = strtolower(trim(sanitize($data['email'])));
    $password = trim((string) $data['password']);

    if ($email === '' || $password === '') {
        errorResponse('Email and password are required');
    }
    if (function_exists('nsmsRateLimit')) {
        $ip = function_exists('nsmsClientIp') ? nsmsClientIp() : (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0');
        if (!nsmsRateLimit('login:' . $ip, 20, 900)) {
            errorResponse('Too many login attempts. Please try again in about 15 minutes.', 429);
        }
        if (!nsmsRateLimit('login-email:' . $email, 12, 900)) {
            errorResponse('Too many login attempts for this account. Please try again later.', 429);
        }
    }
    if (!isValidEmail($email)) {
        errorResponse('Invalid email format');
    }

    global $mysqlOnline;
    $user = null;
    if (!empty($mysqlOnline) && $db) {
        try {
            $user = $db->queryOne(
                "SELECT * FROM users WHERE LOWER(TRIM(email)) = :email LIMIT 1",
                array(':email' => $email)
            );
        } catch (Exception $e) {
            $user = null;
            $mysqlOnline = false;
        }
    }

    // Offline path: MySQL unavailable or unreachable
    if (!$user && (empty($mysqlOnline) || !$db || !$db->connect())) {
        $err = null;
        $offlineUser = class_exists('OfflineAuth') ? OfflineAuth::attemptLogin($email, $password, $err) : null;
        if (!$offlineUser) {
            errorResponse($err ?: 'Invalid email or password', 401);
        }
        OfflineAuth::establishSession($offlineUser);
        $safe = $offlineUser;
        unset($safe['password_hash']);
        successResponse(array(
            'user' => $safe,
            'session' => array(
                'user_id' => (int)$offlineUser['id'],
                'role' => $offlineUser['role'],
                'email' => $offlineUser['email'],
                'full_name' => $offlineUser['full_name'],
                'offline_mode' => true,
            ),
            'offline_mode' => true,
        ), 'Login successful (offline mode)');
        return;
    }

    if (!$user) {
        errorResponse('Invalid email or password', 401);
    }

    $status = isset($user['status']) ? strtolower(trim((string) $user['status'])) : 'active';
    if ($status !== '' && $status !== 'active') {
        errorResponse('This account is not active. Please contact the school administrator.', 403);
    }

    // Support both password_hash (current schema) and legacy `password` column
    $hash = '';
    if (!empty($user['password_hash'])) {
        $hash = (string) $user['password_hash'];
    } elseif (!empty($user['password'])) {
        $hash = (string) $user['password'];
    }

    $ok = ($hash !== '' && verifyPassword($password, $hash));

    $role = isset($user['role']) ? $user['role'] : '';
    $changed = 0;
    if (array_key_exists('password_changed', $user) && $user['password_changed'] !== null && $user['password_changed'] !== '') {
        $changed = (int) $user['password_changed'];
    }

    // Known temporary passwords (creation defaults + legacy)
    $isOfficialTemp = false;
    if ($role === 'teacher' && $password === 'teacher123') {
        $isOfficialTemp = true;
    }
    if ($role === 'parent' && ($password === 'parent123' || $password === 'Parent@nsms')) {
        $isOfficialTemp = true;
    }
    $pd = nsmsPhoneDigits(isset($user['phone']) ? $user['phone'] : '');
    $td = nsmsPhoneDigits($password);
    if (in_array($role, array('teacher', 'parent'), true) && $pd !== '' && $td !== '' && strlen($td) >= 6) {
        if ($pd === $td || (strlen($pd) >= 9 && strlen($td) >= 9 && substr($pd, -9) === substr($td, -9))) {
            $isOfficialTemp = true;
        }
    }

    // Try alternate forms against stored hash (phone formatting, etc.)
    if (!$ok && $hash !== '' && in_array($role, array('teacher', 'parent'), true)) {
        foreach (nsmsTempPasswordCandidates($user, $password) as $cand) {
            if (verifyPassword($cand, $hash)) {
                $ok = true;
                break;
            }
        }
    }

    // Activation recovery:
    //  - password_changed = 0 and user presents an official temp password → accept + rehash
    //  - password_changed = 1 but hash still IS a known temp password (stuck flag) → accept,
    //    rehash, and clear the flag so setup runs
    $hashIsStillTemp = false;
    if ($hash !== '' && in_array($role, array('teacher', 'parent'), true)) {
        foreach (array('teacher123', 'parent123', 'Parent@nsms', $pd) as $temp) {
            if ($temp !== '' && verifyPassword($temp, $hash)) {
                $hashIsStillTemp = true;
                break;
            }
        }
        if (!$hashIsStillTemp && $pd !== '' && isset($user['phone'])) {
            if (verifyPassword(trim((string) $user['phone']), $hash)) {
                $hashIsStillTemp = true;
            }
        }
    }

    $needsActivation = ($changed === 0) || $hashIsStillTemp;

    if (!$ok && $needsActivation && $isOfficialTemp && in_array($role, array('teacher', 'parent'), true)) {
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $upd = $db->execute(
            "UPDATE users SET password_hash = :h, password_changed = 0 WHERE id = :id",
            array(':h' => $newHash, ':id' => $user['id'])
        );
        // Legacy installs that only have a `password` column
        if ($upd === false) {
            $db->execute(
                "UPDATE users SET password = :h WHERE id = :id",
                array(':h' => $newHash, ':id' => $user['id'])
            );
            $db->execute(
                "UPDATE users SET password_changed = 0 WHERE id = :id",
                array(':id' => $user['id'])
            );
        }
        $ok = true;
        $changed = 0;
        $user['password_changed'] = 0;
    }

    if (!$ok) {
        errorResponse('Invalid email or password', 401);
    }

    $db->execute("UPDATE users SET last_login = NOW() WHERE id = :id", array(':id' => $user['id']));

    setUserSession($user);
    if (method_exists('Database', 'clearDownCache')) {
        Database::clearDownCache();
    }
    if (function_exists('logActivity')) {
        logActivity($db, $user['id'], 'LOGIN', 'User logged in');
    }

    // Cache hashed credentials for offline login BEFORE stripping secrets
    if (class_exists('OfflineAuth')) {
        OfflineAuth::cacheVerifiedUser($user);
    }
    if (isset($_SESSION)) {
        $_SESSION['offline_mode'] = false;
    }

    unset($user['password_hash'], $user['password']);
    $user['password_changed'] = (int) $changed;
    // If they logged in with an official temp password, force setup
    if ($isOfficialTemp && $needsActivation) {
        $user['password_changed'] = 0;
    }

    successResponse(array('user' => $user, 'session' => getCurrentUser(), 'offline_mode' => false), 'Login successful');
}


/**
 * Public self-service password reset for teachers and parents.
 * Always returns a generic success message (do not reveal whether email exists).
 */
function handleForgotPassword($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        errorResponse('Method not allowed', 405);
    }

    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        $data = $_POST;
    }

    $email = isset($data['email']) ? strtolower(trim(sanitize($data['email']))) : '';
    if (function_exists('nsmsRateLimit')) {
        $ip = function_exists('nsmsClientIp') ? nsmsClientIp() : (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0');
        if (!nsmsRateLimit('forgot:' . $ip, 8, 900)) {
            errorResponse('Too many password reset requests. Please try again later.', 429);
        }
        if ($email !== '' && !nsmsRateLimit('forgot-email:' . $email, 5, 3600)) {
            errorResponse('Too many password reset requests for this email. Please try again later.', 429);
        }
    }
    if ($email === '' || !isValidEmail($email)) {
        errorResponse('Please enter a valid email address');
    }

    $generic = 'If an account exists for that email, a password reset link has been sent. Check your inbox (and spam folder). The link expires in 1 hour.';

    $user = $db->queryOne(
        "SELECT id, email, full_name, role, phone, status FROM users WHERE LOWER(TRIM(email)) = :email LIMIT 1",
        array(':email' => $email)
    );

    if ($user && in_array($user['role'], array('teacher', 'parent'), true)) {
        $result = nsmsIssuePasswordResetLink($db, (int) $user['id'], 60);
        if (empty($result['ok'])) {
            error_log('forgot_password link failed for ' . $email . ': ' . (isset($result['error']) ? $result['error'] : ''));
        }
    }

    successResponse(null, $generic);
}

/**
 * Complete password reset using one-time token from email link.
 */
function handleCompletePasswordReset($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        errorResponse('Method not allowed', 405);
    }

    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        $data = $_POST;
    }

    $token = isset($data['token']) ? trim((string)$data['token']) : '';
    $pass  = isset($data['password']) ? (string)$data['password'] : '';
    $confirm = isset($data['confirm_password']) ? (string)$data['confirm_password'] : (isset($data['confirm']) ? (string)$data['confirm'] : '');

    if ($token === '') {
        errorResponse('Reset token is required');
    }
    if (function_exists('nsmsRateLimit')) {
        $ip = function_exists('nsmsClientIp') ? nsmsClientIp() : (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0');
        if (!nsmsRateLimit('reset:' . $ip, 10, 900)) {
            errorResponse('Too many reset attempts. Please try again later.', 429);
        }
    }
    if ($pass === '' || strlen($pass) < 8) {
        errorResponse('Password must be at least 8 characters');
    }
    if ($confirm !== '' && $pass !== $confirm) {
        errorResponse('Passwords do not match');
    }

    $result = nsmsConsumeResetToken($db, $token, $pass);
    if (empty($result['ok'])) {
        errorResponse(isset($result['error']) ? $result['error'] : 'Reset failed', 400);
    }

    // Force next offline enablement via a fresh online login with the new hash
    if (class_exists('OfflineAuth') && !empty($result['user']['id'])) {
        OfflineAuth::revoke((int)$result['user']['id']);
    }

    successResponse(array('user' => $result['user']), 'Password updated. You can sign in now.');
}

function handleLogout() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        errorResponse('Method not allowed', 405);
    }
    clearUserSession();
    successResponse(null, 'Logout successful');
}

/**
 * Check if session is active
 */
function handleCheckSession() {
    if (isLoggedIn()) {
        $u = getCurrentUser();
        if (is_array($u)) {
            $u['offline_mode'] = !empty($_SESSION['offline_mode']);
        }
        successResponse(array(
            'logged_in' => true,
            'user' => $u,
            'offline_mode' => !empty($_SESSION['offline_mode']),
        ));
    } else {
        jsonResponse(array('logged_in' => false, 'offline_mode' => false));
    }
}

/**
 * Get current user details
 */
function handleGetCurrentUser($db) {
    requireAuth();

    $userId = getCurrentUserId();
    global $mysqlOnline;

    // Offline session: return data from session / SQLite cache (no MySQL)
    if (empty($mysqlOnline) || !empty($_SESSION['offline_mode'])) {
        $user = array(
            'id' => $userId,
            'email' => isset($_SESSION['email']) ? $_SESSION['email'] : '',
            'role' => isset($_SESSION['role']) ? $_SESSION['role'] : '',
            'full_name' => isset($_SESSION['full_name']) ? $_SESSION['full_name'] : '',
            'phone' => null,
            'status' => 'active',
            'offline_mode' => true,
        );
        successResponse(array('user' => $user, 'offline_mode' => true));
        return;
    }

    $sql  = "SELECT id, email, role, full_name, phone, status, created_at, last_login
             FROM users WHERE id = :id LIMIT 1";
    $user = $db->queryOne($sql, [':id' => $userId]);

    if (!$user) {
        errorResponse('User not found', 404);
    }

    if ($user['role'] === 'parent') {
        $childrenSql     = "SELECT s.id, s.student_name, s.class_id, c.class_name, c.class_color
                            FROM students s
                            JOIN classes c ON s.class_id = c.id
                            JOIN parents p ON s.id = p.student_id
                            WHERE p.user_id = :user_id AND s.status = 'active'";
        $user['children'] = $db->query($childrenSql, [':user_id' => $userId]);
    }

    if ($user['role'] === 'teacher') {
        $classSql     = "SELECT id, class_name, class_color, capacity
                         FROM classes WHERE teacher_id = :user_id LIMIT 1";
        $class        = $db->queryOne($classSql, [':user_id' => $userId]);
        if ($class) {
            $user['class'] = $class;
        }
    }

    successResponse($user);
}
