<?php
/**
 * Teacher Students API
 * /nsms/api/teacher-students.php
 *
 * Read-only — returns only basic student info (NO fee / payment data).
 * PHP 7.2 compatible.
 *
 * Schema facts (confirmed from nsms_db):
 *   - Teacher's class resolved via: SELECT id FROM classes WHERE teacher_id = session_user_id
 *   - users table has NO class_id column
 *   - attendance column is `attendance_date` (NOT `date`)
 *   - attendance has UNIQUE KEY (student_id, attendance_date)
 *
 * Actions:
 *   GET ?action=list       — students in teacher's class + attendance stats (this year)
 *   GET ?action=get&id={n} — single student profile + attendance breakdown
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    exit(0);
}

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

if (function_exists('applyApiHeaders')) { applyApiHeaders(); }


requireRole(['admin', 'teacher']);

$db   = new Database();
$conn = $db->connect();

if (!$conn) {
    ob_end_clean();
    errorResponse('Database connection failed', 500);
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'list': listMyStudents($db); break;
    case 'get':  getStudentBasic($db); break;
    case 'my_classes': listMyClasses($db); break;
    default:
        ob_end_clean();
        errorResponse('Invalid action');
}

function listMyClasses($db) {
    $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
    if ($role === 'admin' && isset($_GET['teacher_id'])) {
        $userId = (int)$_GET['teacher_id'];
    }
    $ids = resolveTeacherClassIds($db, $userId);
    if (empty($ids)) {
        ob_end_clean();
        successResponse(array());
        return;
    }
    $ph = implode(',', array_fill(0, count($ids), '?'));
    // Database class uses named params typically - check
    $rows = array();
    foreach ($ids as $cid) {
        $r = $db->queryOne(
            "SELECT c.id, c.class_name, c.class_color, c.capacity,
                    (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id AND s.status = 'active') AS student_count
               FROM classes c WHERE c.id = :id",
            array(':id' => $cid)
        );
        if ($r) $rows[] = $r;
    }
    usort($rows, function ($a, $b) {
        return strcmp($a['class_name'], $b['class_name']);
    });
    ob_end_clean();
    successResponse($rows);
}


/* ─────────────────────────────────────────
   Multi-class teacher assignments
   - Primary: classes.teacher_id (homeroom, backward compatible)
   - Extra: teacher_class_assignments (many classes per teacher)
───────────────────────────────────────── */
function nsmsEnsureTeacherClassAssignments($db) {
    static $done = false;
    if ($done) return;
    try {
        $db->execute(
            "CREATE TABLE IF NOT EXISTS teacher_class_assignments (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                teacher_id INT NOT NULL,
                class_id INT NOT NULL,
                subject_id INT NULL,
                academic_year VARCHAR(20) NULL,
                assigned_date DATE NULL,
                status ENUM('active','inactive') NOT NULL DEFAULT 'active',
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_tca (teacher_id, class_id, subject_id),
                KEY idx_tca_teacher (teacher_id),
                KEY idx_tca_class (class_id)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Exception $e) {
        error_log('nsmsEnsureTeacherClassAssignments: ' . $e->getMessage());
    }
    $done = true;
}

function resolveTeacherClassIds($db, $userId = null) {
    nsmsEnsureTeacherClassAssignments($db);
    if ($userId === null) {
        $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
    }
    $userId = (int) $userId;
    if ($userId < 1) return array();

    $ids = array();
    // Homeroom / primary assignment
    $rows = $db->query(
        "SELECT id FROM classes WHERE teacher_id = :uid",
        array(':uid' => $userId)
    ) ?: array();
    foreach ($rows as $r) {
        $ids[(int)$r['id']] = true;
    }
    // Additional assignments
    try {
        $extra = $db->query(
            "SELECT class_id FROM teacher_class_assignments
              WHERE teacher_id = :uid AND status = 'active'",
            array(':uid' => $userId)
        ) ?: array();
        foreach ($extra as $r) {
            $ids[(int)$r['class_id']] = true;
        }
    } catch (Exception $e) {}

    return array_keys($ids);
}

function resolveClassId($db) {
    /* Frontend may pass class_id — must belong to this teacher (or admin) */
    $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
    if (isset($_GET['class_id']) && (int)$_GET['class_id'] > 0) {
        $cid = (int)$_GET['class_id'];
        if ($role === 'admin') return $cid;
        $allowed = resolveTeacherClassIds($db, $userId);
        if (in_array($cid, $allowed, true)) return $cid;
        return null;
    }
    $allowed = resolveTeacherClassIds($db, $userId);
    return !empty($allowed) ? (int)$allowed[0] : null;
}

/* ─────────────────────────────────────────
   ATTENDANCE SUB-QUERY  (current calendar year)
   Column: attendance_date  (NOT "date")
───────────────────────────────────────── */
function attSubQuery() {
    return "
        LEFT JOIN (
            SELECT
                student_id,
                COUNT(*)                                                      AS att_total,
                SUM(CASE WHEN status IN ('present','late') THEN 1 ELSE 0 END) AS att_present,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END)            AS att_absent,
                SUM(CASE WHEN status = 'late'   THEN 1 ELSE 0 END)            AS att_late
            FROM attendance
            WHERE YEAR(attendance_date) = YEAR(CURDATE())
            GROUP BY student_id
        ) att ON att.student_id = s.id
    ";
}

function computeAttRate(&$row) {
    $total   = isset($row['att_total'])   ? (int)$row['att_total']   : 0;
    $present = isset($row['att_present']) ? (int)$row['att_present'] : 0;

    $row['total_days']      = $total;
    $row['present_days']    = $present;
    $row['absent_days']     = isset($row['att_absent']) ? (int)$row['att_absent'] : 0;
    $row['late_days']       = isset($row['att_late'])   ? (int)$row['att_late']   : 0;
    $row['attendance_rate'] = $total > 0 ? round(($present / $total) * 100) : null;

    unset($row['att_total'], $row['att_present'], $row['att_absent'], $row['att_late']);
}

/* ─────────────────────────────────────────
   LIST — students in teacher's class
───────────────────────────────────────── */
function listMyStudents($db) {
    $classId = resolveClassId($db);

    if (!$classId) {
        ob_end_clean();
        errorResponse('No class is assigned to this teacher account.');
    }

    $search  = isset($_GET['q']) ? trim($_GET['q']) : '';
    $params  = [':cid' => $classId];

    $sql = "
        SELECT
            s.id,
            s.student_name,
            s.class_id,
            c.class_name,
            c.class_color,
            s.date_of_birth,
            s.gender,
            s.address,
            s.enrollment_date,
            s.status,
            s.photo_url,
            u.full_name    AS parent_name,
            u.phone        AS parent_phone,
            u.email        AS parent_email,
            p.relationship AS parent_relationship,
            COALESCE(att.att_total,   0) AS att_total,
            COALESCE(att.att_present, 0) AS att_present,
            COALESCE(att.att_absent,  0) AS att_absent,
            COALESCE(att.att_late,    0) AS att_late
        FROM      students s
        JOIN      classes  c ON c.id          = s.class_id
        LEFT JOIN parents  p ON p.student_id  = s.id
        LEFT JOIN users    u ON u.id          = p.user_id
    " . attSubQuery() . "
        WHERE s.class_id = :cid
          AND s.status   = 'active'
    ";

    if ($search !== '') {
        $t = '%' . $search . '%';
        $sql .= " AND (s.student_name LIKE :q1 OR u.full_name LIKE :q2 OR u.phone LIKE :q3)";
        $params[':q1'] = $t;
        $params[':q2'] = $t;
        $params[':q3'] = $t;
    }

    $sql .= " ORDER BY s.student_name ASC";

    $rows = $db->query($sql, $params) ?: [];
    foreach ($rows as &$row) { computeAttRate($row); }
    unset($row);

    $classRow = $db->queryOne(
        "SELECT class_name, class_color FROM classes WHERE id = :id",
        [':id' => $classId]
    );

    ob_end_clean();
    successResponse([
        'students'   => $rows,
        'class_id'   => $classId,
        'class_name' => $classRow ? $classRow['class_name'] : '',
        'total'      => count($rows),
    ]);
}

/* ─────────────────────────────────────────
   GET SINGLE STUDENT — basic profile + attendance
   NO fee / payment data.
───────────────────────────────────────── */
function getStudentBasic($db) {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) {
        ob_end_clean();
        errorResponse('Student ID required');
    }

    $classId = resolveClassId($db);
    $params  = [':id' => $id];

    $sql = "
        SELECT
            s.id,
            s.student_name,
            s.class_id,
            c.class_name,
            c.class_color,
            s.date_of_birth,
            s.gender,
            s.address,
            s.enrollment_date,
            s.status,
            s.photo_url,
            u.full_name    AS parent_name,
            u.phone        AS parent_phone,
            u.email        AS parent_email,
            p.relationship AS parent_relationship
        FROM      students s
        JOIN      classes  c ON c.id        = s.class_id
        LEFT JOIN parents  p ON p.student_id = s.id
        LEFT JOIN users    u ON u.id         = p.user_id
        WHERE s.id = :id
    ";

    if ($classId) {
        $sql .= " AND s.class_id = :cid";
        $params[':cid'] = $classId;
    }

    $student = $db->queryOne($sql, $params);
    if (!$student) {
        ob_end_clean();
        errorResponse('Student not found', 404);
    }

    /* Attendance stats — column: attendance_date */
    $att = $db->queryOne(
        "SELECT
             COUNT(*)                                              AS total,
             SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END)  AS present_days,
             SUM(CASE WHEN status = 'absent'  THEN 1 ELSE 0 END)  AS absent_days,
             SUM(CASE WHEN status = 'late'    THEN 1 ELSE 0 END)  AS late_days
         FROM attendance
         WHERE student_id = :id
           AND YEAR(attendance_date) = YEAR(CURDATE())",
        [':id' => $id]
    );

    $total   = $att ? (int)$att['total']        : 0;
    $present = $att ? (int)$att['present_days'] : 0;

    $student['attendance'] = [
        'total'        => $total,
        'present_days' => $present,
        'absent_days'  => $att ? (int)$att['absent_days'] : 0,
        'late_days'    => $att ? (int)$att['late_days']   : 0,
        'rate'         => $total > 0 ? round(($present / $total) * 100) : null,
    ];

    ob_end_clean();
    successResponse($student);
}
