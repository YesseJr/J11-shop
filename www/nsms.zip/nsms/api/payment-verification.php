<?php
/**
====================================
 * Author: Waython Yesse / J11 Technologies
 * Year: 2026
====================================
 * Payment Verification API  v2
 * Handles ALL fee types: one-time contributions AND installable School Fees.
 *
 * Rules enforced server-side:
 *   1. All one-time contributions (Registration, Stationery, Uniform, Meals, etc.)
 *      must be fully paid before any School Fee installment is accepted.
 *   2. School Fees may be paid in up to 10 installments.
 *   3. Transport is optional — always payable regardless of other balances.
 *   4. Each submission targets exactly one fee_type (+ installment_no for School Fees).
 *
 * Parent GET  : fee_summary, my_submissions, submission_detail
 * Parent POST : submit_payment, upload_proof
 * Admin  GET  : all_submissions, verification_stats, submission_detail
 * Admin  POST : approve_payment, reject_payment
 */

ob_start();
header('Content-Type: application/json');
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

applyApiHeaders();

requireAuth();

$db     = new Database();
$conn   = $db->connect();
if (!$conn) { ob_end_clean(); echo json_encode(['success'=>false,'error'=>'DB connection failed']); exit; }

$role   = getCurrentUserRole();
$userId = getCurrentUserId();
$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

/* upload dir */
$uploadDir = dirname(__DIR__) . '/publicuploads/payment_proofs/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

/* installable fee types (mirrors parent-finance.php) */
define('INSTALLABLE_FEES', ['School Fees', 'Transport']);
define('MAX_INSTALLMENTS', 10);

try {
    if ($method === 'GET') {
        switch ($action) {
            case 'fee_summary':       requireRole('parent'); handleFeeSummary($db, $userId);      break;
            case 'my_submissions':    requireRole('parent'); handleMySubmissions($db, $userId);   break;
            case 'submission_detail': handleGetDetail($db, $role, $userId);                       break;
            case 'all_submissions':   requireRole('admin');  handleAllSubmissions($db);            break;
            case 'verification_stats':requireRole('admin');  handleVerificationStats($db);         break;
            default: apiError('Invalid action');
        }
    } elseif ($method === 'POST') {
        $ct   = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
        $body = strpos($ct,'application/json') !== false
            ? (json_decode(file_get_contents('php://input'), true) ?: [])
            : $_POST;

        switch ($action) {
            case 'submit_payment':  requireRole('parent'); handleSubmitPayment($db, $userId, $body); break;
            case 'upload_proof':    requireRole('parent'); handleUploadProof($db, $userId, $uploadDir); break;
            case 'approve_payment': requireRole('admin');  handleApprovePayment($db, $userId, $body);  break;
            case 'reject_payment':  requireRole('admin');  handleRejectPayment($db, $userId, $body);   break;
            default: apiError('Invalid action');
        }
    } else {
        apiError('Method not allowed', 405);
    }
} catch (Throwable $e) {
    ob_end_clean();
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
    exit;
}
ob_end_flush();

/* ═══════════════════════════════════════════════════════
   HELPERS
═══════════════════════════════════════════════════════ */

function apiOk($data=null, $msg='OK') {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['success'=>true,'message'=>$msg,'data'=>$data]); exit;
}
function apiError($msg, $code=400) {
    ob_end_clean(); http_response_code($code); header('Content-Type: application/json');
    echo json_encode(['success'=>false,'error'=>$msg]); exit;
}
function rf($body, $field) {
    if (!isset($body[$field]) || trim((string)$body[$field])==='') apiError("Missing required field: $field");
    return trim((string)$body[$field]);
}
function parentOwnsStudent($db, $parentUserId, $studentId) {
    return !!$db->queryOne("SELECT id FROM parents WHERE user_id=? AND student_id=?", [$parentUserId, $studentId]);
}
function insertNotification($db, $userId, $title, $message, $type='payment') {
    try {
        $db->execute(
            "INSERT INTO notifications (user_id,title,message,type,is_read,created_at) VALUES (?,?,?,?,0,NOW())",
            [$userId,$title,$message,$type]
        );
    } catch (Exception $e) { error_log('Notif error: '.$e->getMessage()); }
}
function getAdminUserIds($db) {
    $rows = $db->query("SELECT id FROM users WHERE role='admin' AND status='active'");
    return $rows ? array_column($rows,'id') : [];
}
function getAcademicYear($db) {
    $r = $db->queryOne("SELECT academic_year FROM fee_structure GROUP BY academic_year ORDER BY COUNT(*) DESC, academic_year DESC LIMIT 1");
    if ($r && $r['academic_year']) return $r['academic_year'];
    $s = $db->queryOne("SELECT setting_value FROM school_settings WHERE setting_key='academic_year'");
    if ($s && $s['setting_value']) return $s['setting_value'];
    $y = (int)date('Y'); return $y.'/'.$y+1;
}
function yearRange($yr) {
    $p = explode('/',$yr); $y1=(int)$p[0]; return [$y1, count($p)>1?(int)$p[1]:$y1+1];
}
function activeDiscount($db, $studentId) {
    $r=$db->queryOne("SELECT discount_percent FROM student_discounts WHERE student_id=? AND effective_from<=CURDATE() AND (effective_to IS NULL OR effective_to>=CURDATE()) ORDER BY effective_from DESC LIMIT 1",[$studentId]);
    return $r ? (float)$r['discount_percent'] : 0;
}

/* ═══════════════════════════════════════════════════════
   CORE: BUILD FULL FEE SUMMARY FOR ONE STUDENT
   Returns every payable line with its status and any
   pending/submitted payment amounts already in the queue.
═══════════════════════════════════════════════════════ */

function buildFeeSummary($db, $studentId, $classId, $yr) {
    $discount = activeDiscount($db, $studentId);
    [$yr1,$yr2] = yearRange($yr);

    /* ── one-time fees from fee_structure ── */
    $fsRows = $db->query(
        "SELECT fee_type, amount FROM fee_structure
          WHERE academic_year=? AND fee_type NOT IN('School Fees','Transport')
            AND (class_id=? OR class_id IS NULL)
          ORDER BY class_id DESC",
        [$yr,$classId]
    ) ?: [];
    $oneTime = []; // fee_type => amount (deduped, class-specific wins)
    foreach ($fsRows as $r) {
        if (!isset($oneTime[$r['fee_type']])) $oneTime[$r['fee_type']] = (float)$r['amount'];
    }

    /* ── total confirmed payments (for allocation logic) ── */
    $totalPaid = (float)($db->queryOne(
        "SELECT COALESCE(SUM(amount),0) AS p FROM fee_payments WHERE student_id=? AND YEAR(payment_date) BETWEEN ? AND ? AND status='confirmed'",
        [$studentId,$yr1,$yr2]
    )['p'] ?? 0);

    /* ── pending submissions (not yet approved) ── */
    $pendingRows = $db->query(
        "SELECT fee_type, installment_no, SUM(amount) AS total
           FROM payment_submissions
          WHERE student_id=? AND status='pending_verification'
          GROUP BY fee_type, installment_no",
        [$studentId]
    ) ?: [];
    $pendingMap = []; // fee_type => [ installment_no => amount ] (0 = one-time)
    foreach ($pendingRows as $r) {
        $ft = $r['fee_type']; $ins = (int)($r['installment_no'] ?? 0);
        if (!isset($pendingMap[$ft])) $pendingMap[$ft] = [];
        $pendingMap[$ft][$ins] = (float)$r['total'];
    }

    /* ── transport assignment ── */
    $hasTransport = false;
    try {
        $hasTransport = !!$db->queryOne(
            "SELECT id FROM student_transport WHERE student_id=? AND academic_year=? AND status='active'",
            [$studentId,$yr]
        );
    } catch (Throwable $e) {}

    /* ── ensure installment rows exist (idempotent) ── */
    ensureInstallments($db, $studentId, $classId, $yr, $discount);

    /* ── load installments ── */
    $instRows = $db->query(
        "SELECT fee_type,installment_no,amount_due,amount_paid,status,paid_date
           FROM fee_installments
          WHERE student_id=? AND academic_year=?
          ORDER BY fee_type ASC, installment_no ASC",
        [$studentId,$yr]
    ) ?: [];
    $installments = []; // fee_type => [slots]
    foreach ($instRows as $r) {
        if ($r['fee_type']==='Transport' && !$hasTransport) continue;
        $installments[$r['fee_type']][] = [
            'no'          => (int)$r['installment_no'],
            'amount_due'  => (float)$r['amount_due'],
            'amount_paid' => (float)$r['amount_paid'],
            'status'      => $r['status'],
            'paid_date'   => $r['paid_date'],
            'pending'     => (float)($pendingMap[$r['fee_type']][(int)$r['installment_no']] ?? 0),
        ];
    }

    /* ── build one-time fee lines ── */
    $oneTimeLines = [];
    $oneTimePaidSoFar = 0; // allocation bucket
    $allOneTimeDone   = true;
    foreach ($oneTime as $ft => $due) {
        /* amount paid toward this one-time fee:
           we allocate totalPaid sequentially across one-time fees in order */
        $paid = min($due, max(0, $totalPaid - $oneTimePaidSoFar));
        $oneTimePaidSoFar += $paid;
        $balance  = max(0, $due - $paid);
        $pending  = (float)($pendingMap[$ft][0] ?? 0);
        $done     = ($balance <= 0);
        if (!$done) $allOneTimeDone = false;
        $oneTimeLines[] = [
            'fee_type'    => $ft,
            'amount_due'  => $due,
            'amount_paid' => $paid,
            'balance'     => $balance,
            'pending'     => $pending,
            'is_paid'     => $done,
            'installable' => false,
        ];
    }

    /* ── build installable lines ── */
    $installLines = [];
    foreach ($installments as $ft => $slots) {
        $ftDue  = array_sum(array_column($slots,'amount_due'));
        $ftPaid = array_sum(array_column($slots,'amount_paid'));
        $ftBal  = max(0, $ftDue - $ftPaid);
        $ftPend = array_sum(array_column($slots,'pending'));
        $canPay = ($ft==='Transport') || $allOneTimeDone;  // contributions first rule
        $installLines[] = [
            'fee_type'    => $ft,
            'amount_due'  => $ftDue,
            'amount_paid' => $ftPaid,
            'balance'     => $ftBal,
            'pending'     => $ftPend,
            'is_paid'     => ($ftBal <= 0),
            'installable' => true,
            'can_pay'     => $canPay,
            'slots'       => $slots,
        ];
    }

    /* ── grand totals ── */
    $grandDue  = array_sum(array_column($oneTimeLines,'amount_due'))
               + array_sum(array_column(array_filter($installLines, fn($l)=>$l['fee_type']!=='Transport'),'amount_due'));
    $grandPaid = $totalPaid;
    $grandBal  = max(0, $grandDue - $grandPaid);

    return [
        'student_id'       => (int)$studentId,
        'academic_year'    => $yr,
        'discount_pct'     => $discount,
        'one_time_lines'   => $oneTimeLines,
        'install_lines'    => $installLines,
        'all_one_time_done'=> $allOneTimeDone,
        'has_transport'    => $hasTransport,
        'grand_due'        => $grandDue,
        'grand_paid'       => $grandPaid,
        'grand_balance'    => $grandBal,
        'total_pending'    => array_sum(array_column($oneTimeLines,'pending'))
                           + array_sum(array_column($installLines,'pending')),
        'fully_paid'       => ($grandDue > 0 && $grandBal <= 0),
    ];
}

function ensureInstallments($db, $studentId, $classId, $yr, $discount) {
    $fees = $db->query(
        "SELECT fee_type, amount FROM fee_structure
          WHERE academic_year=? AND fee_type IN('School Fees','Transport')
            AND (class_id=? OR class_id IS NULL)
          ORDER BY class_id DESC",
        [$yr,$classId]
    ) ?: [];
    $seen = [];
    foreach ($fees as $f) {
        $ft = $f['fee_type'];
        if (isset($seen[$ft])) continue;
        $seen[$ft] = true;
        $base = round((float)$f['amount'] / MAX_INSTALLMENTS, 2);
        $amt  = $discount > 0 ? round($base*(1-$discount/100),2) : $base;
        for ($i=1; $i<=MAX_INSTALLMENTS; $i++) {
            $db->execute(
                "INSERT IGNORE INTO fee_installments (student_id,academic_year,fee_type,installment_no,amount_due) VALUES (?,?,?,?,?)",
                [$studentId,$yr,$ft,$i,$amt]
            );
        }
    }
}

/* ═══════════════════════════════════════════════════════
   PARENT: FEE SUMMARY  (all children)
═══════════════════════════════════════════════════════ */

function handleFeeSummary($db, $userId) {
    $children = $db->query(
        "SELECT s.id,s.student_name,c.id AS class_id,c.class_name
           FROM parents p
           JOIN students s ON s.id=p.student_id
           JOIN classes  c ON c.id=s.class_id
          WHERE p.user_id=? AND s.status='active'
          ORDER BY s.student_name",
        [$userId]
    ) ?: [];

    $yr  = getAcademicYear($db);
    $out = [];
    foreach ($children as $ch) {
        $summary = buildFeeSummary($db, $ch['id'], $ch['class_id'], $yr);
        $summary['student_name'] = $ch['student_name'];
        $summary['class_name']   = $ch['class_name'];
        $out[] = $summary;
    }
    apiOk($out);
}

/* ═══════════════════════════════════════════════════════
   PARENT: MY SUBMISSIONS
═══════════════════════════════════════════════════════ */

function handleMySubmissions($db, $userId) {
    $rows = $db->query(
        "SELECT ps.*,s.student_name,c.class_name
           FROM payment_submissions ps
           JOIN students s ON s.id=ps.student_id
           JOIN classes  c ON c.id=s.class_id
          WHERE ps.parent_id=?
          ORDER BY ps.created_at DESC LIMIT 100",
        [$userId]
    ) ?: [];
    apiOk($rows);
}

/* ═══════════════════════════════════════════════════════
   PARENT: SUBMIT PAYMENT
═══════════════════════════════════════════════════════ */

function handleSubmitPayment($db, $userId, $body) {
    $studentId  = (int)rf($body,'student_id');
    $feeType    = rf($body,'fee_type');
    $amount     = (float)rf($body,'amount');
    $method     = rf($body,'payment_method');
    $reference  = rf($body,'payment_reference');
    $payDate    = rf($body,'payment_date');
    $instNo     = isset($body['installment_no']) ? (int)$body['installment_no'] : null;
    $notes      = isset($body['notes']) ? trim($body['notes']) : null;

    if ($amount <= 0)                      apiError('Amount must be greater than 0');
    if (!parentOwnsStudent($db,$userId,$studentId)) apiError('Access denied to this student',403);

    $allowed = ['M-Pesa','Bank Transfer','Cash','Cheque','Other'];
    if (!in_array($method,$allowed)) apiError('Invalid payment method');

    /* enforce one-time-first rule for School Fees */
    $student = $db->queryOne("SELECT class_id FROM students WHERE id=?",[$studentId]);
    $yr      = getAcademicYear($db);
    $summary = buildFeeSummary($db, $studentId, $student['class_id'], $yr);

    if ($feeType === 'School Fees') {
        if (!$summary['all_one_time_done']) {
            apiError('All contribution fees (Registration, Stationery, Uniform, Meals, etc.) must be fully paid before making School Fee payments.');
        }
        if ($instNo === null || $instNo < 1 || $instNo > MAX_INSTALLMENTS) {
            apiError('A valid installment number (1–'.MAX_INSTALLMENTS.') is required for School Fee payments.');
        }
        /* check the target installment is actually unpaid */
        $sfLine = null;
        foreach ($summary['install_lines'] as $il) {
            if ($il['fee_type']==='School Fees') { $sfLine=$il; break; }
        }
        if ($sfLine) {
            $slot = null;
            foreach ($sfLine['slots'] as $s) { if ($s['no']===$instNo) { $slot=$s; break; } }
            if ($slot && $slot['status']==='paid') {
                apiError("Installment #$instNo is already paid.");
            }
        }
    }

    if (in_array($feeType, INSTALLABLE_FEES) && $feeType !== 'School Fees') {
        /* Transport installments are free to pay any time */
        if ($instNo === null || $instNo < 1 || $instNo > MAX_INSTALLMENTS) {
            apiError('A valid installment number is required for '.$feeType.' payments.');
        }
    }

    /* duplicate reference guard */
    $dup = $db->queryOne(
        "SELECT id FROM payment_submissions WHERE payment_reference=? AND student_id=? AND fee_type=?",
        [$reference,$studentId,$feeType]
    );
    if ($dup) apiError('A submission with this reference already exists for this student and fee type.');

    $insertId = $db->execute(
        "INSERT INTO payment_submissions
           (student_id,parent_id,fee_type,installment_no,amount,payment_reference,payment_method,payment_date,notes,status,created_at)
         VALUES (?,?,?,?,?,?,?,?,?,'pending_verification',NOW())",
        [$studentId,$userId,$feeType,$instNo,$amount,$reference,$method,$payDate,$notes]
    );
    if (!$insertId) apiError('Failed to save submission.');

    /* notify admins */
    $st = $db->queryOne("SELECT student_name FROM students WHERE id=?",[$studentId]);
    $pu = $db->queryOne("SELECT full_name FROM users WHERE id=?",[$userId]);
    $sName = $st['student_name'] ?? 'Student';
    $pName = $pu['full_name']    ?? 'Parent';
    $label = $feeType . ($instNo ? " (Instalment #$instNo)" : '');

    foreach (getAdminUserIds($db) as $aid) {
        insertNotification($db,$aid,"New Payment Submitted",
            "{$pName} submitted TSh ".number_format($amount,0)." for {$sName} — {$label}. Awaiting verification."
        );
    }

    apiOk(['submission_id'=>(int)$insertId],'Payment submitted successfully. Awaiting admin verification.');
}

/* ═══════════════════════════════════════════════════════
   PARENT: UPLOAD PROOF
═══════════════════════════════════════════════════════ */

function handleUploadProof($db, $userId, $uploadDir) {
    $subId = isset($_POST['submission_id']) ? (int)$_POST['submission_id'] : 0;
    if (!$subId) apiError('submission_id required');

    $sub = $db->queryOne("SELECT id,status FROM payment_submissions WHERE id=? AND parent_id=?",[$subId,$userId]);
    if (!$sub)                                     apiError('Submission not found',404);
    if ($sub['status']!=='pending_verification')   apiError('Cannot update proof — submission already reviewed');

    if (!isset($_FILES['proof']) || $_FILES['proof']['error']!==UPLOAD_ERR_OK) apiError('No valid file uploaded');

    $file    = $_FILES['proof'];
    $allowed = ['image/jpeg','image/png','image/gif','image/webp','application/pdf'];
    $extMap  = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','application/pdf'=>'pdf'];

    if ($file['size'] > 5*1024*1024) apiError('File too large (max 5MB)');
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo,$file['tmp_name']); finfo_close($finfo);
    if (!in_array($mime,$allowed)) apiError('Invalid file type. Use JPG, PNG, WEBP, GIF, or PDF');

    $fname = 'proof_'.$subId.'_'.time().'.'.$extMap[$mime];
    if (!move_uploaded_file($file['tmp_name'],$uploadDir.$fname)) apiError('File save failed — check permissions');

    $db->execute("UPDATE payment_submissions SET payment_proof=? WHERE id=?",['payment_proofs/'.$fname,$subId]);
    apiOk(['proof_path'=>'payment_proofs/'.$fname],'Proof uploaded.');
}

/* ═══════════════════════════════════════════════════════
   ADMIN: ALL SUBMISSIONS
═══════════════════════════════════════════════════════ */

function handleAllSubmissions($db) {
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $limit  = min((int)($_GET['limit']  ?? 50),100);
    $offset = max((int)($_GET['offset'] ?? 0),0);
    $valid  = ['pending_verification','received','rejected'];

    $where=[]; $params=[];
    if ($status && in_array($status,$valid)) { $where[]='ps.status=?'; $params[]=$status; }
    $wq = $where ? 'WHERE '.implode(' AND ',$where) : '';

    $total = (int)($db->queryOne("SELECT COUNT(*) AS c FROM payment_submissions ps $wq",$params)['c'] ?? 0);
    $params[]=$limit; $params[]=$offset;

    $rows = $db->query(
        "SELECT ps.*,s.student_name,c.class_name,
                u.full_name AS parent_name,u.phone AS parent_phone,
                v.full_name AS verified_by_name
           FROM payment_submissions ps
           JOIN students s ON s.id=ps.student_id
           JOIN classes  c ON c.id=s.class_id
           JOIN users    u ON u.id=ps.parent_id
           LEFT JOIN users v ON v.id=ps.verified_by
           $wq ORDER BY ps.created_at DESC LIMIT ? OFFSET ?",
        $params
    ) ?: [];

    apiOk(['submissions'=>$rows,'total'=>$total,'limit'=>$limit,'offset'=>$offset]);
}

/* ═══════════════════════════════════════════════════════
   ADMIN: VERIFICATION STATS
═══════════════════════════════════════════════════════ */

function handleVerificationStats($db) {
    $counts = $db->query("SELECT status,COUNT(*) AS c FROM payment_submissions GROUP BY status") ?: [];
    $stats  = ['pending_verification'=>0,'received'=>0,'rejected'=>0];
    foreach ($counts as $r) $stats[$r['status']] = (int)$r['c'];

    $recv   = $db->queryOne("SELECT COALESCE(SUM(amount),0) AS t FROM payment_submissions WHERE status='received'");
    $today  = $db->queryOne("SELECT COUNT(*) AS c FROM payment_submissions WHERE status='pending_verification' AND DATE(created_at)=CURDATE()");

    apiOk(['counts'=>$stats,'total_received'=>(float)($recv['t']??0),'new_today'=>(int)($today['c']??0)]);
}

/* ═══════════════════════════════════════════════════════
   SHARED: SUBMISSION DETAIL
═══════════════════════════════════════════════════════ */

function handleGetDetail($db, $role, $userId) {
    $id = (int)($_GET['submission_id'] ?? 0);
    if (!$id) apiError('submission_id required');
    $params=[$id]; $extra='';
    if ($role==='parent') { $extra='AND ps.parent_id=?'; $params[]=$userId; }

    $row = $db->queryOne(
        "SELECT ps.*,s.student_name,c.class_name,
                u.full_name AS parent_name,u.phone AS parent_phone,u.email AS parent_email,
                v.full_name AS verified_by_name
           FROM payment_submissions ps
           JOIN students s ON s.id=ps.student_id
           JOIN classes  c ON c.id=s.class_id
           JOIN users    u ON u.id=ps.parent_id
           LEFT JOIN users v ON v.id=ps.verified_by
          WHERE ps.id=? $extra",
        $params
    );
    if (!$row) apiError('Submission not found',404);
    apiOk($row);
}

/* ═══════════════════════════════════════════════════════
   ADMIN: APPROVE PAYMENT
   - Updates payment_submissions status
   - Inserts into fee_payments (ledger)
   - Updates fee_installments if installable fee
   - Updates student_fee_accounts balance
   - Notifies parent
═══════════════════════════════════════════════════════ */

function handleApprovePayment($db, $adminId, $body) {
    $subId = (int)rf($body,'submission_id');
    $sub   = $db->queryOne(
        "SELECT ps.*,s.student_name,s.class_id
           FROM payment_submissions ps JOIN students s ON s.id=ps.student_id
          WHERE ps.id=?",
        [$subId]
    );
    if (!$sub)                                        apiError('Submission not found',404);
    if ($sub['status']!=='pending_verification')      apiError('Only pending submissions can be approved');

    $conn = $db->connect();
    $conn->beginTransaction();
    try {
        /* 1. Update submission */
        $db->execute(
            "UPDATE payment_submissions SET status='received',verified_by=?,verified_at=NOW(),updated_at=NOW() WHERE id=?",
            [$adminId,$subId]
        );

        /* 2. Insert into fee_payments (ledger) */
        $receipt = 'RCP-'.strtoupper(substr(md5(uniqid()),0,8));
        $fpId = $db->execute(
            "INSERT INTO fee_payments (student_id,amount,payment_method,payment_date,receipt_number,reference_number,status,recorded_by,created_at)
             VALUES (?,?,?,?,?,?,'confirmed',?,NOW())",
            [$sub['student_id'],$sub['amount'],$sub['payment_method'],$sub['payment_date'],$receipt,$sub['payment_reference'],$adminId]
        );

        /* 3. Update fee_installments if applicable */
        $feeType  = $sub['fee_type'];
        $instNo   = $sub['installment_no'];
        if ($feeType && $instNo && in_array($feeType, INSTALLABLE_FEES)) {
            /* mark this installment slot as paid */
            $db->execute(
                "UPDATE fee_installments
                    SET amount_paid=amount_due, status='paid', payment_id=?, paid_date=?
                  WHERE student_id=? AND fee_type=? AND installment_no=? AND status!='paid'",
                [$fpId,$sub['payment_date'],$sub['student_id'],$feeType,$instNo]
            );
        }

        /* 4. Link receipt back to submission */
        $db->execute("UPDATE payment_submissions SET fee_payment_id=? WHERE id=?",[$fpId,$subId]);

        /* 5. Recalculate student_fee_accounts */
        $yr = getAcademicYear($db);
        [$yr1,$yr2] = yearRange($yr);
        $fs = $db->queryOne(
            "SELECT COALESCE(SUM(amount),0) AS t FROM fee_structure WHERE academic_year=? AND (class_id=? OR class_id IS NULL)",
            [$yr,$sub['class_id']]
        );
        $fp = $db->queryOne(
            "SELECT COALESCE(SUM(amount),0) AS t FROM fee_payments WHERE student_id=? AND YEAR(payment_date) BETWEEN ? AND ? AND status='confirmed'",
            [$sub['student_id'],$yr1,$yr2]
        );
        $totalFee  = (float)($fs['t']??0);
        $totalPaid = (float)($fp['t']??0);
        $db->execute(
            "INSERT INTO student_fee_accounts (student_id,total_fee,total_paid,balance) VALUES (?,?,?,?)
             ON DUPLICATE KEY UPDATE total_paid=VALUES(total_paid),balance=VALUES(balance),last_updated=NOW()",
            [$sub['student_id'],$totalFee,$totalPaid,max(0,$totalFee-$totalPaid)]
        );

        $conn->commit();

        /* 6. Notify parent */
        $label = $feeType . ($instNo ? " Instalment #$instNo" : '');
        insertNotification($db,$sub['parent_id'],"Payment Received ✓",
            "Your ".strtolower($label)." payment of TSh ".number_format($sub['amount'],0)
            ." for {$sub['student_name']} has been verified. Receipt: {$receipt}."
        );

        apiOk(['fee_payment_id'=>(int)$fpId,'receipt_number'=>$receipt],'Payment approved and account updated.');
    } catch (Exception $e) {
        $conn->rollBack();
        apiError('Approval failed: '.$e->getMessage(),500);
    }
}

/* ═══════════════════════════════════════════════════════
   ADMIN: REJECT PAYMENT
═══════════════════════════════════════════════════════ */

function handleRejectPayment($db, $adminId, $body) {
    $subId  = (int)rf($body,'submission_id');
    $reason = rf($body,'rejection_reason');

    $sub = $db->queryOne(
        "SELECT ps.*,s.student_name FROM payment_submissions ps JOIN students s ON s.id=ps.student_id WHERE ps.id=?",
        [$subId]
    );
    if (!$sub)                                   apiError('Submission not found',404);
    if ($sub['status']!=='pending_verification') apiError('Only pending submissions can be rejected');

    $db->execute(
        "UPDATE payment_submissions SET status='rejected',verified_by=?,verified_at=NOW(),rejection_reason=?,updated_at=NOW() WHERE id=?",
        [$adminId,$reason,$subId]
    );
    $label = ($sub['fee_type']??'Payment') . ($sub['installment_no'] ? " Instalment #{$sub['installment_no']}" : '');
    insertNotification($db,$sub['parent_id'],"Payment Submission Rejected",
        "Your {$label} submission of TSh ".number_format($sub['amount'],0)
        ." for {$sub['student_name']} was rejected. Reason: {$reason}."
    );
    apiOk(null,'Payment rejected and parent notified.');
}
