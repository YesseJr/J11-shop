<?php
/**
 * First Time Setup API
 * Creates the initial admin account
 * This file should be deleted after first admin is created
 */

header('Content-Type: application/json');
// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once '../includes/db.php';
require_once '../includes/helpers.php';

$db = new Database();
$conn = $db->connect();

if (!$conn) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'check':
        checkAdminExists($db);
        break;
    
    case 'create_admin':
        createFirstAdmin($db);
        break;
    
    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action']);
}

/**
 * Check if an admin account already exists
 */
function checkAdminExists($db) {
    $sql = "SELECT COUNT(*) as count FROM users WHERE role = 'admin' AND status = 'active'";
    $result = $db->queryOne($sql);
    
    $adminExists = ($result && $result['count'] > 0);
    
    echo json_encode([
        'admin_exists' => $adminExists,
        'count' => $result ? (int)$result['count'] : 0
    ]);
}

/**
 * Create the first admin account
 */
function createFirstAdmin($db) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }
    
    // Check if admin already exists
    $checkSql = "SELECT COUNT(*) as count FROM users WHERE role = 'admin'";
    $checkResult = $db->queryOne($checkSql);
    
    if ($checkResult && $checkResult['count'] > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Admin account already exists']);
        exit;
    }
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate input
    $errors = [];
    
    if (empty($data['full_name'])) {
        $errors[] = 'Full name is required';
    }
    
    if (empty($data['email'])) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    }
    
    if (empty($data['phone'])) {
        $errors[] = 'Phone number is required';
    }
    
    if (empty($data['password'])) {
        $errors[] = 'Password is required';
    } elseif (strlen($data['password']) < 6) {
        $errors[] = 'Password must be at least 6 characters';
    }
    
    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode(['error' => implode(', ', $errors)]);
        exit;
    }
    
    // Check if email already exists
    $emailCheckSql = "SELECT COUNT(*) as count FROM users WHERE email = :email";
    $emailCheck = $db->queryOne($emailCheckSql, [':email' => $data['email']]);
    
    if ($emailCheck && $emailCheck['count'] > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Email already registered']);
        exit;
    }
    
    // Sanitize input
    $fullName = htmlspecialchars(strip_tags(trim($data['full_name'])));
    $email = filter_var(trim($data['email']), FILTER_SANITIZE_EMAIL);
    $phone = htmlspecialchars(strip_tags(trim($data['phone'])));
    
    // Hash password
    $passwordHash = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // Insert admin user
    $sql = "INSERT INTO users (email, password_hash, role, full_name, phone, status, created_at) 
            VALUES (:email, :password_hash, 'admin', :full_name, :phone, 'active', NOW())";
    
    $params = [
        ':email' => $email,
        ':password_hash' => $passwordHash,
        ':full_name' => $fullName,
        ':phone' => $phone
    ];
    
    $userId = $db->execute($sql, $params);
    
    if ($userId) {
        // Log the creation
        error_log("First admin account created: {$email}");
        
        http_response_code(201);
        echo json_encode([
            'success' => true,
            'message' => 'Admin account created successfully',
            'data' => [
                'id' => $userId,
                'email' => $email,
                'full_name' => $fullName,
                'role' => 'admin'
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to create admin account']);
    }
}
