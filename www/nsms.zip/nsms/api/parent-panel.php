<?php
/**
 * Parent Panel API  —  PHP 7.2 compatible
 * Path: /nsms/api/parent-panel.php
 *
 * Actions (GET):  session | dashboard | get_profile | generate_notifications
 *                 notifications | notifications_count | get_emergency_contacts
 * Actions (POST): acknowledge_homework | update_profile | change_password
 *                 save_emergency_contact
 * Actions (DELETE): delete_emergency_contact
 */

ob_start();

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    exit(0);
}

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/helpers.php';

applyApiHeaders();

// ── Auth guard ─────────────────────────────────────────────────────────────────
if (!isLoggedIn() || $_SESSION['role'] !== 'parent') {
    ob_end_clean();
    echo json_encode(['success' => false, 'error' => 'unauthorized']);
    exit;
}

$sessionUserId = (int)$_SESSION['user_id'];

// ── DB ─────────────────────────────────────────────────────────────────────────
$db   = new Database();
$conn = $db->connect();

$action = isset($_GET['action']) ? $_GET['action'] : 'session';

if (!$conn) {
    if ($action === 'session') {
        $data = array(
            'id' => $sessionUserId,
            'full_name' => isset($_SESSION['full_name']) ? $_SESSION['full_name'] : '',
            'email' => isset($_SESSION['email']) ? $_SESSION['email'] : '',
            'phone' => isset($_SESSION['phone']) ? $_SESSION['phone'] : null,
            'photo_url' => null,
            'status' => 'active',
            'password_changed' => 1,
            'offline_mode' => true,
        );
        ob_end_clean();
        echo json_encode(array('success' => true, 'data' => $data, 'message' => 'Offline session'));
        exit;
    }
    ob_end_clean();
    echo json_encode(array('success' => false, 'error' => 'Database connection failed', 'offline' => true));
    exit;
}

// ─────────────────────────────────────────────────────────────────────────────

switch ($action) {

    // ── SESSION ───────────────────────────────────────────────────────────────
    case 'session':

        $rows = $db->query(
            "SELECT u.id, u.full_name, u.email, u.phone, u.photo_url,
                    u.status, u.last_login
             FROM users u
             WHERE u.id = ? AND u.role = 'parent'",
            [$sessionUserId]
        );

        if (!$rows) {
            ob_end_clean();
            errorResponse('Parent record not found', 404);
        }

        $parent = $rows[0];

        // ── password_changed — separate query in try-catch ────────────────────
        $parent['password_changed'] = 0;
        try {
            $pcRow = $db->query(
                "SELECT password_changed FROM users WHERE id = ?",
                [$sessionUserId]
            );
            if ($pcRow && array_key_exists('password_changed', $pcRow[0])) {
                $parent['password_changed'] = (int)$pcRow[0]['password_changed'];
            }
        } catch (Exception $e) {
            $parent['password_changed'] = 0;
        }

        // ── Children list ─────────────────────────────────────────────────────
        $children = $db->query(
            "SELECT s.id, s.student_name, s.class_id, s.photo_url, s.gender,
                    s.date_of_birth, s.enrollment_date,
                    c.class_name, c.class_color, p.relationship
             FROM parents p
             JOIN students s ON s.id = p.student_id
             JOIN classes  c ON c.id = s.class_id
             WHERE p.user_id = ? AND s.status = 'active'
             ORDER BY s.student_name ASC",
            [$sessionUserId]
        ) ?: [];

        $parent['children'] = $children;

        ob_end_clean();
        successResponse($parent);
        break;

    // ── DASHBOARD ─────────────────────────────────────────────────────────────
    case 'dashboard':
        $today = date('Y-m-d');

        // ── Day type ──────────────────────────────────────────────────────────
        $dayOfWeek = (int)date('N');
        $dayInfo   = ['type' => 'school_day', 'name' => null];

        if ($dayOfWeek >= 6) {
            $dayInfo = [
                'type' => 'weekend',
                'name' => $dayOfWeek === 6 ? 'Saturday' : 'Sunday',
            ];
        } else {
            try {
                $hRow = $db->query(
                    "SELECT title, event_type FROM calendar_events
                      WHERE event_date = ?
                        AND event_type IN ('public_holiday','school_holiday','holiday')
                      LIMIT 1",
                    [$today]
                );
                if ($hRow) {
                    $eType   = strtolower($hRow[0]['event_type']);
                    $dayInfo = [
                        'type' => ($eType === 'public_holiday') ? 'public_holiday' : 'school_holiday',
                        'name' => $hRow[0]['title'],
                    ];
                }
            } catch (Exception $e) { /* table not yet created */ }
        }

        // ── Fetch parent's children ───────────────────────────────────────────
        $children = $db->query(
            "SELECT s.id, s.student_name, s.class_id, s.photo_url, s.gender,
                    s.date_of_birth,
                    c.class_name, c.class_color, p.relationship
             FROM parents p
             JOIN students s ON s.id = p.student_id
             JOIN classes  c ON c.id = s.class_id
             WHERE p.user_id = ? AND s.status = 'active'
             ORDER BY s.student_name ASC",
            [$sessionUserId]
        ) ?: [];

        if (empty($children)) {
            ob_end_clean();
            successResponse([
                'children'        => [],
                'attendance_rate' => 0,
                'homework_today'  => 0,
                'unread_messages' => 0,
                'fee_status'      => 'n/a',
                'homework'        => [],
                'announcements'   => [],
                'day_info'        => $dayInfo,
            ]);
        }

        $childIds = array_map(function($c){ return (int)$c['id']; }, $children);
        $classIds = array_unique(array_map(function($c){ return (int)$c['class_id']; }, $children));

        // ── Per-child attendance stats ────────────────────────────────────────
        foreach ($children as &$child) {
            $stuId = (int)$child['id'];

            $attRow = $db->query(
                "SELECT COUNT(*) AS total,
                        SUM(CASE WHEN status = 'present' OR status = 'late' THEN 1 ELSE 0 END) AS present_cnt
                   FROM attendance
                  WHERE student_id = ?
                    AND attendance_date >= DATE_SUB(?, INTERVAL 30 DAY)
                    AND attendance_date <= ?",
                [$stuId, $today, $today]
            );
            $total   = $attRow ? (int)$attRow[0]['total']       : 0;
            $present = $attRow ? (int)$attRow[0]['present_cnt'] : 0;
            $child['attendance_rate'] = $total > 0 ? round($present / $total * 100) : 0;

            $todayAtt = $db->query(
                "SELECT status FROM attendance WHERE student_id = ? AND attendance_date = ?",
                [$stuId, $today]
            );
            $child['today_attendance'] = $todayAtt ? $todayAtt[0]['status'] : null;

            try {
                // Determine the next outstanding installment using the real ledger.
                // fee_installments.status can be stale for cash payments recorded
                // directly via finance.php, so we cross-check against fee_payments.
                $nextFee = $db->query(
                    "SELECT installment_no, amount_due, amount_paid, status
                       FROM fee_installments
                      WHERE student_id = ? AND status IN ('unpaid','partial')
                      ORDER BY installment_no ASC LIMIT 1",
                    [$stuId]
                );

                if ($nextFee) {
                    // Verify the installment is actually unpaid using fee_payments ledger.
                    // If total confirmed payments cover the full school-fee installment
                    // total, treat as no outstanding installment even if the row
                    // hasn't been marked 'paid' yet (cash payment path).
                    $child['next_installment'] = $nextFee[0];
                } else {
                    $child['next_installment'] = null;
                }
            } catch (Exception $e) {
                $child['next_installment'] = null;
            }
        }
        unset($child);

        $rates   = array_column($children, 'attendance_rate');
        $attRate = count($rates) > 0 ? (int)round(array_sum($rates) / count($rates)) : 0;

        // Re-index class ids for safe positional PDO binding
        $classIds = array_values(array_unique(array_map('intval', $classIds)));
        $classPlaceholders = implode(',', array_fill(0, count($classIds), '?'));

        // Window: 14 days overdue → any future due date (uploaded homework must appear)
        // Use CURDATE() in SQL to avoid driver/date-format mismatches on bound params.
        $homework = $db->query(
            "SELECT h.id, h.subject, h.description, h.due_date, h.class_id,
                    c.class_name
               FROM homework h
               JOIN classes c ON c.id = h.class_id
              WHERE h.class_id IN ($classPlaceholders)
                AND h.due_date >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
              ORDER BY
                  CASE
                      WHEN DATE(h.due_date) = CURDATE() THEN 0
                      WHEN DATE(h.due_date) < CURDATE() THEN 1
                      ELSE 2
                  END,
                  h.due_date ASC
              LIMIT 15",
            $classIds
        ) ?: [];

        foreach ($homework as &$hw) {
            // Normalize DATE/DATETIME from MySQL to Y-m-d for reliable compares
            $due = isset($hw['due_date']) ? substr((string)$hw['due_date'], 0, 10) : '';
            $hw['due_date'] = $due;

            if (isset($hw['subject'])) {
                $hw['subject'] = function_exists('decodeText')
                    ? decodeText($hw['subject'])
                    : html_entity_decode($hw['subject'], ENT_QUOTES, 'UTF-8');
            }
            if (isset($hw['description'])) {
                $hw['description'] = function_exists('decodeText')
                    ? decodeText($hw['description'])
                    : html_entity_decode($hw['description'], ENT_QUOTES, 'UTF-8');
            }

            $hw['acknowledged_by_students'] = [];
            foreach ($children as $child) {
                if ((int)$child['class_id'] === (int)$hw['class_id']) {
                    $ack = $db->query(
                        "SELECT id FROM homework_acknowledgements
                          WHERE homework_id = ? AND student_id = ?",
                        [(int)$hw['id'], (int)$child['id']]
                    );
                    if ($ack) {
                        $hw['acknowledged_by_students'][] = (int)$child['id'];
                    }
                }
            }

            if ($due === $today) {
                $hw['due_label'] = 'Due Today';
                $hw['hw_status'] = 'due_today';
            } elseif ($due !== '' && $due < $today) {
                $hw['due_label'] = 'Overdue';
                $hw['hw_status'] = 'overdue';
            } else {
                $hw['due_label'] = $due ? ('Due ' . date('d M', strtotime($due))) : '';
                $hw['hw_status'] = 'upcoming';
            }
        }
        unset($hw);

        // Card count = all active homework in the window (today + upcoming + overdue)
        // so parents see a non-zero number whenever assignments exist for their children.
        $homeworkToday = count($homework);

        // J11 Pulse badge = unread DMs + unread pulse alerts
        $unreadMessages = 0;
        try {
            $msgRow = $db->query(
                "SELECT COUNT(*) AS cnt FROM messages WHERE recipient_id = ? AND is_read = 0",
                [$sessionUserId]
            );
            $unreadMessages += $msgRow ? (int)$msgRow[0]['cnt'] : 0;
        } catch (Exception $e) { /* messages table may not exist */ }
        try {
            $pulseRow = $db->query(
                "SELECT COUNT(*) AS cnt
                   FROM pulse_alert_recipients par
                  WHERE par.user_id = ? AND par.is_read = 0",
                [$sessionUserId]
            );
            $unreadMessages += $pulseRow ? (int)$pulseRow[0]['cnt'] : 0;
        } catch (Exception $e) { /* pulse tables may not exist */ }

        // ── Fee status — authoritative source is fee_payments ledger vs fee_structure ──
        // Mirrors finance.php buildPaymentStatus() logic:
        //   expected = one-time fees × students + school-fee installment dues
        //   paid     = SUM(confirmed fee_payments) for academic year
        // This fixes two bugs:
        //   (a) fee_status='paid' on fresh accounts — fee_installments is empty so
        //       the old COUNT(unpaid) returns 0, wrongly implying everything is paid.
        //   (b) Cash payments recorded by admin via finance.php update fee_payments
        //       but may not always update fee_installments; reading fee_payments
        //       directly is always accurate regardless of payment channel.
        $feeStatus   = 'n/a'; // fallback when no fees configured
        $unpaidCount = 0;
        try {
            // Resolve academic year (same priority as finance.php getAcademicYear())
            $yrRow = $db->query(
                "SELECT academic_year, COUNT(*) AS cnt FROM fee_structure
                  GROUP BY academic_year ORDER BY cnt DESC, academic_year DESC LIMIT 1"
            );
            $academicYear = $yrRow ? $yrRow[0]['academic_year'] : null;
            if (!$academicYear) {
                $sRow = $db->query(
                    "SELECT setting_value FROM school_settings WHERE setting_key='academic_year'"
                );
                $academicYear = ($sRow && !empty($sRow[0]['setting_value']))
                    ? $sRow[0]['setting_value']
                    : (date('Y') . '/' . (date('Y') + 1));
            }

            // Both calendar years this academic year spans (e.g. 2025/2026 → 2025 & 2026)
            $yrParts = explode('/', $academicYear);
            $yrNum1  = (int)$yrParts[0];
            $yrNum2  = count($yrParts) > 1 ? (int)$yrParts[1] : $yrNum1 + 1;

            $childPlaceholders = implode(',', array_fill(0, count($childIds), '?'));

            // Total confirmed cash from fee_payments across all children this year
            $paidRow = $db->query(
                "SELECT COALESCE(SUM(amount), 0) AS total_paid
                   FROM fee_payments
                  WHERE student_id IN ($childPlaceholders)
                    AND YEAR(payment_date) BETWEEN ? AND ?
                    AND status = 'confirmed'",
                array_merge($childIds, [$yrNum1, $yrNum2])
            );
            $totalPaid = $paidRow ? (float)$paidRow[0]['total_paid'] : 0;

            // Total mandatory fees due across all children
            // One-time fees × number of children + school-fee installment dues
            $oneTimeRow = $db->query(
                "SELECT COALESCE(SUM(fs.amount), 0) AS total
                   FROM fee_structure fs
                  WHERE fs.academic_year = ?
                    AND fs.fee_type NOT IN ('School Fees', 'Transport')
                    AND fs.class_id IS NULL",
                [$academicYear]
            );
            $schoolWideOneTime = $oneTimeRow ? (float)$oneTimeRow[0]['total'] : 0;

            $totalExpected = 0;
            foreach ($children as $ch) {
                $cid = (int)$ch['class_id'];

                // Class-specific one-time fees
                $classOtRow = $db->query(
                    "SELECT COALESCE(SUM(amount), 0) AS total
                       FROM fee_structure
                      WHERE academic_year = ? AND class_id = ?
                        AND fee_type NOT IN ('School Fees', 'Transport')",
                    [$academicYear, $cid]
                );
                $classOneTime = $classOtRow ? (float)$classOtRow[0]['total'] : 0;
                $totalExpected += $schoolWideOneTime + $classOneTime;

                // School fees installment total (from fee_installments if rows exist,
                // otherwise from fee_structure ÷ 10 as the expected annual amount)
                try {
                    $instRow = $db->query(
                        "SELECT COALESCE(SUM(amount_due), 0) AS due
                           FROM fee_installments
                          WHERE student_id = ? AND academic_year = ?
                            AND fee_type = 'School Fees'",
                        [(int)$ch['id'], $academicYear]
                    );
                    $instDue = $instRow ? (float)$instRow[0]['due'] : 0;

                    if ($instDue <= 0) {
                        // Installment rows not seeded yet — use fee_structure annual amount
                        $sfRow = $db->query(
                            "SELECT COALESCE(MAX(amount), 0) AS amount
                               FROM fee_structure
                              WHERE academic_year = ? AND fee_type = 'School Fees'
                                AND (class_id = ? OR class_id IS NULL)
                              ORDER BY class_id DESC LIMIT 1",
                            [$academicYear, $cid]
                        );
                        $instDue = $sfRow ? (float)$sfRow[0]['amount'] : 0;
                    }
                    $totalExpected += $instDue;
                } catch (Exception $e) {
                    // fee_installments not yet created — fall back to fee_structure
                    $sfRow = $db->query(
                        "SELECT COALESCE(MAX(amount), 0) AS amount
                           FROM fee_structure
                          WHERE academic_year = ? AND fee_type = 'School Fees'
                            AND (class_id = ? OR class_id IS NULL)",
                        [$academicYear, $cid]
                    );
                    $totalExpected += $sfRow ? (float)$sfRow[0]['amount'] : 0;
                }
            }

            if ($totalExpected <= 0) {
                // No fees configured — cannot determine status
                $feeStatus = 'n/a';
            } elseif ($totalPaid >= $totalExpected) {
                $feeStatus   = 'paid';
                $unpaidCount = 0;
            } else {
                $feeStatus   = 'pending';
                $unpaidCount = 1; // non-zero signals pending; exact count not needed by UI
            }

        } catch (Exception $e) {
            // Any DB error — fall back to safe unknown state
            $feeStatus = 'n/a';
        }

        $announcements = $db->query(
            "SELECT a.id, a.title, a.content, a.is_urgent, a.created_at
               FROM announcements a
              WHERE a.target_audience IN ('all','parents')
              ORDER BY a.is_urgent DESC, a.created_at DESC
              LIMIT 5"
        ) ?: [];

        $recentReports = [];
        foreach ($children as $child) {
            $stuId = (int)$child['id'];
            $wr = $db->query(
                "SELECT id, week_number, report_date, teacher_comments
                   FROM weekly_reports WHERE student_id = ? ORDER BY report_date DESC LIMIT 1",
                [$stuId]
            );
            if ($wr) {
                $recentReports[] = [
                    'type'         => 'weekly',
                    'student_id'   => $stuId,
                    'student_name' => $child['student_name'],
                    'report_date'  => $wr[0]['report_date'],
                    'summary'      => $wr[0]['teacher_comments'],
                    'report_id'    => $wr[0]['id'],
                ];
            }
        }

        $calendarEvents = [];
        try {
            $calendarEvents = $db->query(
                "SELECT icon, type, title, date, `desc`
                   FROM school_calendar
                  WHERE date >= ? AND is_visible = 1
                  ORDER BY date ASC LIMIT 3",
                [$today]
            ) ?: [];
        } catch (Exception $e) { /* school_calendar may not exist */ }

        ob_end_clean();
        successResponse([
            'children'        => $children,
            'attendance_rate' => $attRate,
            'homework_today'  => $homeworkToday,
            'unread_messages' => $unreadMessages,
            'fee_status'      => $feeStatus,
            'unpaid_count'    => $unpaidCount,
            'homework'        => $homework,
            'announcements'   => $announcements,
            'recent_reports'  => $recentReports,
            'calendar_events' => $calendarEvents,
            'day_info'        => $dayInfo,
        ]);
        break;

    // ── NOTIFICATIONS COUNT ───────────────────────────────────────────────────
    // Returns unread counts for the bell: notifications tab + pulse alerts tab
    // + unread messages (used by navbar badge).
    case 'notifications_count':

        // Unread auto-generated notifications
        $notifUnread = 0;
        try {
            $nr = $db->query(
                "SELECT COUNT(*) AS cnt FROM notifications
                  WHERE user_id = ? AND is_read = 0",
                [$sessionUserId]
            );
            $notifUnread = $nr ? (int)$nr[0]['cnt'] : 0;
        } catch (Exception $e) { /* notifications table not yet created */ }

        // Unread J11 Pulse alerts targeted at this parent
        $pulseUnread = 0;
        try {
            $pr = $db->query(
                "SELECT COUNT(*) AS cnt
                   FROM pulse_alert_recipients par
                   JOIN pulse_alerts pa ON pa.id = par.alert_id
                  WHERE par.user_id = ? AND par.is_read = 0",
                [$sessionUserId]
            );
            $pulseUnread = $pr ? (int)$pr[0]['cnt'] : 0;
        } catch (Exception $e) { /* pulse tables not yet created */ }

        // Unread messages (for navbar badge)
        $msgUnread = 0;
        try {
            $mr = $db->query(
                "SELECT COUNT(*) AS cnt FROM messages WHERE recipient_id = ? AND is_read = 0",
                [$sessionUserId]
            );
            $msgUnread = $mr ? (int)$mr[0]['cnt'] : 0;
        } catch (Exception $e) { /* messages table not yet created */ }

        ob_end_clean();
        successResponse([
            'notifications' => $notifUnread,
            'pulse'         => $pulseUnread,
            'msgs'          => $msgUnread,
            'total'         => $notifUnread + $pulseUnread,
        ]);
        break;

    // ── NOTIFICATIONS LIST ────────────────────────────────────────────────────
    // Returns paginated notifications + pulse alerts for the bell dropdown.
    case 'notifications':

        $limit  = 20;

        // Auto-generated notifications
        $notifs = [];
        try {
            $notifs = $db->query(
                "SELECT id, title, message, type, is_read, created_at
                   FROM notifications
                  WHERE user_id = ?
                  ORDER BY created_at DESC
                  LIMIT ?",
                [$sessionUserId, $limit]
            ) ?: [];

            foreach ($notifs as &$n) {
                $n['is_read'] = (bool)$n['is_read'];
                $n['source']  = 'notification';
            }
            unset($n);
        } catch (Exception $e) { /* notifications table not yet created */ }

        // Pulse alerts
        $pulseAlerts = [];
        try {
            $pulseAlerts = $db->query(
                "SELECT pa.id,
                        pa.title,
                        pa.body AS message,
                        pa.priority AS type,
                        par.is_read,
                        pa.created_at
                   FROM pulse_alert_recipients par
                   JOIN pulse_alerts pa ON pa.id = par.alert_id
                  WHERE par.user_id = ?
                  ORDER BY pa.created_at DESC
                  LIMIT ?",
                [$sessionUserId, $limit]
            ) ?: [];

            foreach ($pulseAlerts as &$p) {
                $p['is_read'] = (bool)$p['is_read'];
                $p['source']  = 'pulse';
            }
            unset($p);
        } catch (Exception $e) { /* pulse tables not yet created */ }

        ob_end_clean();
        successResponse([
            'notifications' => $notifs,
            'pulse'         => $pulseAlerts,
        ]);
        break;

    // ── MARK NOTIFICATIONS READ ───────────────────────────────────────────────
    case 'mark_notifications_read':
    $input  = json_decode(file_get_contents('php://input'), true) ?: [];
    $source = isset($input['source']) ? $input['source'] : 'notification';
    $id     = isset($input['id'])     ? (int)$input['id'] : 0;

    try {
        if ($source === 'pulse') {
            $sql    = $id > 0
                ? "UPDATE pulse_alert_recipients SET is_read = 1, read_at = NOW() WHERE user_id = ? AND alert_id = ? AND is_read = 0"
                : "UPDATE pulse_alert_recipients SET is_read = 1, read_at = NOW() WHERE user_id = ? AND is_read = 0";
            $params = $id > 0 ? [$sessionUserId, $id] : [$sessionUserId];
        } else {
            $sql    = $id > 0
                ? "UPDATE notifications SET is_read = 1 WHERE user_id = ? AND id = ? AND is_read = 0"
                : "UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0";
            $params = $id > 0 ? [$sessionUserId, $id] : [$sessionUserId];
        }
        $db->execute($sql, $params);
    } catch (Exception $e) { /* tables not yet created */ }

    ob_end_clean();
    successResponse(['marked' => true]);
    break;

    // ── ACKNOWLEDGE HOMEWORK ──────────────────────────────────────────────────
    case 'acknowledge_homework':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('POST required', 405);
        }

        $input      = json_decode(file_get_contents('php://input'), true) ?: [];
        $homeworkId = isset($input['homework_id']) ? (int)$input['homework_id'] : 0;
        $studentId  = isset($input['student_id'])  ? (int)$input['student_id']  : 0;

        if (!$homeworkId || !$studentId) {
            ob_end_clean();
            errorResponse('homework_id and student_id required', 400);
        }

        $verify = $db->query(
            "SELECT id FROM parents WHERE user_id = ? AND student_id = ?",
            [$sessionUserId, $studentId]
        );
        if (!$verify) {
            ob_end_clean();
            errorResponse('Unauthorized: student does not belong to this parent', 403);
        }

        $hwCheck = $db->query(
            "SELECT h.id FROM homework h
               JOIN students s ON s.class_id = h.class_id
              WHERE h.id = ? AND s.id = ?",
            [$homeworkId, $studentId]
        );
        if (!$hwCheck) {
            ob_end_clean();
            errorResponse('Homework not found for this student', 404);
        }

        $existing = $db->query(
            "SELECT id FROM homework_acknowledgements WHERE homework_id = ? AND student_id = ?",
            [$homeworkId, $studentId]
        );
        if ($existing) {
            ob_end_clean();
            successResponse(['already_acknowledged' => true]);
        }

        $ok = $db->execute(
            "INSERT IGNORE INTO homework_acknowledgements (homework_id, student_id, parent_id, acknowledged_at)
             VALUES (?, ?, ?, NOW())",
            [$homeworkId, $studentId, $sessionUserId]
        );

        ob_end_clean();
        if ($ok) {
            successResponse(['acknowledged' => true]);
        } else {
            errorResponse('Failed to save acknowledgment');
        }
        break;

    // ── GET PROFILE ───────────────────────────────────────────────────────────
    case 'get_profile':
        $rows = $db->query(
            "SELECT u.id, u.full_name, u.email, u.phone, u.photo_url, u.status, u.created_at
               FROM users u
              WHERE u.id = ? AND u.role = 'parent'",
            [$sessionUserId]
        );
        if (!$rows) {
            ob_end_clean();
            errorResponse('Profile not found', 404);
        }
        $profile = $rows[0];

        $profile['children'] = $db->query(
            "SELECT s.id, s.student_name, c.class_name, p.relationship
               FROM parents p
               JOIN students s ON s.id = p.student_id
               JOIN classes  c ON c.id = s.class_id
              WHERE p.user_id = ? AND s.status = 'active'",
            [$sessionUserId]
        ) ?: [];

        ob_end_clean();
        successResponse($profile);
        break;

    // ── UPDATE PROFILE ────────────────────────────────────────────────────────
    case 'update_profile':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('POST required', 405);
        }

        $input    = json_decode(file_get_contents('php://input'), true) ?: [];
        $fullName = isset($input['full_name']) ? trim($input['full_name']) : '';
        $phone    = isset($input['phone'])     ? trim($input['phone'])     : '';

        if (!$fullName) {
            ob_end_clean();
            errorResponse('full_name required', 400);
        }

        $ok = $db->execute(
            "UPDATE users SET full_name = ?, phone = ? WHERE id = ? AND role = 'parent'",
            [$fullName, $phone, $sessionUserId]
        );

        ob_end_clean();
        if ($ok) {
            successResponse(['updated' => true]);
        } else {
            errorResponse('Update failed');
        }
        break;

        // ── UPLOAD PHOTO ──────────────────────────────────────────────────────────
    case 'upload_photo':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('POST required', 405);
        }

        if (empty($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
            ob_end_clean();
            errorResponse('No valid file uploaded', 400);
        }

        $file     = $_FILES['photo'];
        $maxBytes = 5 * 1024 * 1024; // 5 MB

        if ($file['size'] > $maxBytes) {
            ob_end_clean();
            errorResponse('Image must be under 5 MB', 400);
        }

        // Validate MIME type from actual file contents (not browser-supplied type)
        $finfo    = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($file['tmp_name']);
        $allowed  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'];

        if (!isset($allowed[$mimeType])) {
            ob_end_clean();
            errorResponse('Only JPEG, PNG, GIF, or WebP images are allowed', 400);
        }

        // Build a unique filename: parent_{id}_{timestamp}.{ext}
        $ext      = $allowed[$mimeType];
        $filename = 'parent_' . $sessionUserId . '_' . time() . '.' . $ext;

        // Resolve upload directory relative to this file's location
        // Adjust this path to wherever NSMS stores user photos
        $uploadDir = dirname(__DIR__) . '/uploads/photos/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $destPath = $uploadDir . $filename;
        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            ob_end_clean();
            errorResponse('Failed to save uploaded file', 500);
        }

        // Delete old photo file if it was a locally-stored avatar
        $oldRow = $db->query(
            "SELECT photo_url FROM users WHERE id = ?",
            [$sessionUserId]
        );
        if ($oldRow && !empty($oldRow[0]['photo_url'])) {
            $oldUrl = $oldRow[0]['photo_url'];
            // Only delete if it's a local upload (not an external URL)
            if (strpos($oldUrl, '/uploads/photos/') !== false) {
                $oldFile = $uploadDir . basename(parse_url($oldUrl, PHP_URL_PATH));
                if (file_exists($oldFile)) {
                    @unlink($oldFile);
                }
            }
        }

        // Store the web-accessible URL in the database
        $photoUrl = '/nsms/uploads/photos/' . $filename;

        $ok = $db->execute(
            "UPDATE users SET photo_url = ? WHERE id = ? AND role = 'parent'",
            [$photoUrl, $sessionUserId]
        );

        ob_end_clean();
        if ($ok) {
            successResponse(['photo_url' => $photoUrl]);
        } else {
            errorResponse('Failed to update photo in database');
        }
        break;

    // ── SETUP PASSWORD (first-time activation) ────────────────────────────────
    case 'setup_password':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean(); errorResponse('POST required', 405);
        }

        $input   = json_decode(file_get_contents('php://input'), true) ?: [];
        $newPass = isset($input['new_password'])     ? trim($input['new_password'])     : '';
        $confirm = isset($input['confirm_password']) ? trim($input['confirm_password']) : '';

        if (strlen($newPass) < 8) {
            ob_end_clean(); errorResponse('Password must be at least 8 characters', 400);
        }
        if ($newPass !== $confirm) {
            ob_end_clean(); errorResponse('Passwords do not match', 400);
        }

        $guardRow = null;
        try {
            $guardRow = $db->query(
                "SELECT password_changed FROM users WHERE id = ? AND role = 'parent'",
                [$sessionUserId]
            );
        } catch (Exception $e) { /* column missing — allow setup to proceed */ }

        if ($guardRow && isset($guardRow[0]['password_changed'])
                      && (int)$guardRow[0]['password_changed'] === 1) {
            ob_end_clean();
            errorResponse('Account is already activated. Use the profile settings to change your password.', 403);
        }

        $hash = password_hash($newPass, PASSWORD_BCRYPT);

        $db->execute(
            "UPDATE users SET password_hash = :hash WHERE id = :id AND role = 'parent'",
            [':hash' => $hash, ':id' => $sessionUserId]
        );

        try {
            $db->execute(
                "UPDATE users SET password_changed = 1 WHERE id = :id",
                [':id' => $sessionUserId]
            );
        } catch (Exception $e) { /* column not yet created — non-fatal */ }

        notifyAccountActivated($db, $sessionUserId);

        ob_end_clean();
        successResponse(['message' => 'Password set. Please log in again.']);
        break;

    // ── CHANGE PASSWORD ───────────────────────────────────────────────────────
    case 'change_password':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('POST required', 405);
        }

        $input   = json_decode(file_get_contents('php://input'), true) ?: [];
        $current = isset($input['current']) ? $input['current'] : '';
        $newPw   = isset($input['new'])     ? $input['new']     : '';
        $confirm = isset($input['confirm']) ? $input['confirm'] : '';

        if (!$current || !$newPw || !$confirm) {
            ob_end_clean();
            errorResponse('All password fields required', 400);
        }
        if ($newPw !== $confirm) {
            ob_end_clean();
            errorResponse('New passwords do not match', 400);
        }
        if (strlen($newPw) < 6) {
            ob_end_clean();
            errorResponse('Password must be at least 6 characters', 400);
        }

        $row = $db->query(
            "SELECT password_hash FROM users WHERE id = ?",
            [$sessionUserId]
        );
        if (!$row || !password_verify($current, $row[0]['password_hash'])) {
            ob_end_clean();
            errorResponse('Current password is incorrect', 400);
        }

        $newHash = password_hash($newPw, PASSWORD_DEFAULT);
        $ok = $db->execute(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            [$newHash, $sessionUserId]
        );

        ob_end_clean();
        if ($ok) {
            successResponse(['changed' => true]);
        } else {
            errorResponse('Failed to update password');
        }
        break;

    // ── GENERATE NOTIFICATIONS ────────────────────────────────────────────────
    case 'generate_notifications':

        $today   = date('Y-m-d');
        $created = 0;

        $children = $db->query(
            "SELECT s.id, s.student_name, c.class_name
               FROM parents p
               JOIN students s ON s.id = p.student_id
               JOIN classes  c ON c.id = s.class_id
              WHERE p.user_id = ? AND s.status = 'active'",
            [$sessionUserId]
        ) ?: [];

        $insertNotif = function($type, $title, $message, $refKey)
            use ($db, $sessionUserId, &$created) {
            try {
                $ex = $db->query(
                    "SELECT id FROM notifications WHERE user_id = ? AND reference_key = ? LIMIT 1",
                    [$sessionUserId, $refKey]
                );
                if ($ex) return;
            } catch (Exception $e) { return; }

            $ok = $db->execute(
                "INSERT INTO notifications (user_id, title, message, type, reference_key)
                 VALUES (?, ?, ?, ?, ?)",
                [$sessionUserId, $title, $message, $type, $refKey]
            );
            if ($ok) $created++;
        };

        foreach ($children as $child) {
            $stuId   = (int)$child['id'];
            $stuName = $child['student_name'];

            $att = $db->query(
                "SELECT status FROM attendance WHERE student_id = ? AND attendance_date = ?",
                [$stuId, $today]
            );
            if ($att && $att[0]['status'] === 'absent') {
                $insertNotif(
                    'attendance',
                    '⚠️ Absent Today: ' . $stuName,
                    $stuName . ' was marked absent in school today (' . date('d M Y') . ').',
                    'absent_' . $stuId . '_' . $today
                );
            }

            $refKey  = 'att_low_parent_' . $stuId . '_' . date('Y-W');
            $attRow  = $db->query(
                "SELECT COUNT(*) AS total,
                        SUM(CASE WHEN status='present' OR status='late' THEN 1 ELSE 0 END) AS present_cnt
                   FROM attendance
                  WHERE student_id = ? AND attendance_date >= DATE_SUB(?, INTERVAL 30 DAY)",
                [$stuId, $today]
            );
            if ($attRow && (int)$attRow[0]['total'] >= 10) {
                $total   = (int)$attRow[0]['total'];
                $present = (int)$attRow[0]['present_cnt'];
                $rate    = round(($present / $total) * 100);
                if ($rate < 75) {
                    $insertNotif(
                        'attendance',
                        '📉 Low Attendance: ' . $stuName,
                        $stuName . ' has only ' . $rate . '% attendance over the last 30 days. '
                        . 'Please ensure regular school attendance.',
                        $refKey
                    );
                }
            }

            try {
                $hwList = $db->query(
                    "SELECT h.id, h.subject FROM homework h
                       JOIN students s ON s.class_id = h.class_id
                      WHERE s.id = ? AND h.due_date = ?",
                    [$stuId, $today]
                ) ?: [];

                foreach ($hwList as $hw) {
                    $hwId = (int)$hw['id'];
                    $ack  = $db->query(
                        "SELECT id FROM homework_acknowledgements WHERE homework_id = ? AND student_id = ?",
                        [$hwId, $stuId]
                    );
                    if (!$ack) {
                        $insertNotif(
                            'homework',
                            '📚 Homework Due Today: ' . $hw['subject'],
                            $stuName . ' has ' . $hw['subject'] . ' homework due today that has not yet been acknowledged.',
                            'hw_due_' . $hwId . '_' . $stuId . '_' . $today
                        );
                    }
                }
            } catch (Exception $e) { /* homework_acknowledgements not yet created */ }

            try {
                $refKey  = 'fee_unpaid_' . $stuId . '_' . date('Y-m');
                $feeRow  = $db->query(
                    "SELECT installment_no, amount_due FROM fee_installments
                      WHERE student_id = ? AND status IN ('unpaid','partial')
                      ORDER BY installment_no ASC LIMIT 1",
                    [$stuId]
                );
                if ($feeRow) {
                    $installNo = (int)$feeRow[0]['installment_no'];
                    $amount    = number_format((float)$feeRow[0]['amount_due']);
                    $insertNotif(
                        'fee',
                        '💰 Pending Fee: ' . $stuName,
                        'Installment #' . $installNo . ' of TSh ' . $amount
                        . ' for ' . $stuName . ' is still outstanding.',
                        $refKey
                    );
                }
            } catch (Exception $e) { /* fee_installments table not yet created */ }
        }

        ob_end_clean();
        successResponse(['generated' => $created]);
        break;

    // ── EMERGENCY CONTACTS ────────────────────────────────────────────────────
    case 'get_emergency_contacts':
        ensureEmergencyContactsTable($db);

        $studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
        if (!$studentId) {
            ob_end_clean();
            errorResponse('student_id required', 400);
        }

        $owns = $db->query(
            "SELECT id FROM parents WHERE student_id = ? AND user_id = ? LIMIT 1",
            [$studentId, $sessionUserId]
        );
        if (!$owns) {
            ob_end_clean();
            errorResponse('Not authorized for this student', 403);
        }

        $rows = $db->query(
            "SELECT id, full_name, relationship, phone, alt_phone, notes
               FROM student_emergency_contacts
              WHERE student_id = ?
              ORDER BY id ASC",
            [$studentId]
        ) ?: [];

        ob_end_clean();
        successResponse($rows);
        break;

    case 'save_emergency_contact':
        ensureEmergencyContactsTable($db);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            ob_end_clean();
            errorResponse('POST required', 405);
        }

        $input      = json_decode(file_get_contents('php://input'), true) ?: [];
        $studentId  = isset($input['student_id']) ? (int)$input['student_id'] : 0;
        $contactId  = isset($input['id']) && $input['id'] ? (int)$input['id'] : null;
        $fullName   = isset($input['full_name'])    ? trim($input['full_name'])    : '';
        $relation   = isset($input['relationship']) ? trim($input['relationship']) : '';
        $phone      = isset($input['phone'])        ? trim($input['phone'])       : '';
        $altPhone   = isset($input['alt_phone'])    ? trim($input['alt_phone'])   : '';
        $notes      = isset($input['notes'])        ? trim($input['notes'])      : '';

        if (!$studentId) { ob_end_clean(); errorResponse('student_id required', 400); }
        if (!$fullName)  { ob_end_clean(); errorResponse('Contact name is required', 400); }
        if (!$relation)  { ob_end_clean(); errorResponse('Relationship is required', 400); }
        if (!$phone)     { ob_end_clean(); errorResponse('Phone number is required', 400); }

        $owns = $db->query(
            "SELECT id FROM parents WHERE student_id = ? AND user_id = ? LIMIT 1",
            [$studentId, $sessionUserId]
        );
        if (!$owns) {
            ob_end_clean();
            errorResponse('Not authorized for this student', 403);
        }

        if ($contactId) {
            // Confirm this contact actually belongs to this parent's child before editing it
            $existing = $db->query(
                "SELECT id FROM student_emergency_contacts WHERE id = ? AND student_id = ?",
                [$contactId, $studentId]
            );
            if (!$existing) {
                ob_end_clean();
                errorResponse('Contact not found', 404);
            }

            $ok = $db->execute(
                "UPDATE student_emergency_contacts
                    SET full_name = ?, relationship = ?, phone = ?, alt_phone = ?, notes = ?
                  WHERE id = ?",
                [$fullName, $relation, $phone, $altPhone ?: null, $notes ?: null, $contactId]
            );
            ob_end_clean();
            // execute() returns false only on a genuine SQL error — a rowCount of 0
            // (nothing actually changed) is not a failure, so only false counts here.
            if ($ok === false) {
                errorResponse('Failed to update contact');
            }
            successResponse(['id' => $contactId], 'Emergency contact updated');
        } else {
            $newId = $db->execute(
                "INSERT INTO student_emergency_contacts (student_id, full_name, relationship, phone, alt_phone, notes)
                 VALUES (?, ?, ?, ?, ?, ?)",
                [$studentId, $fullName, $relation, $phone, $altPhone ?: null, $notes ?: null]
            );
            ob_end_clean();
            if ($newId === false) {
                errorResponse('Failed to save contact');
            }
            successResponse(['id' => (int)$newId], 'Emergency contact added');
        }
        break;

    case 'delete_emergency_contact':
        ensureEmergencyContactsTable($db);
        if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
            ob_end_clean();
            errorResponse('DELETE required', 405);
        }

        $contactId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if (!$contactId) {
            ob_end_clean();
            errorResponse('id required', 400);
        }

        // Ownership check via the parents link, so one parent can never delete
        // another family's emergency contact just by guessing an id.
        $owns = $db->query(
            "SELECT ec.id
               FROM student_emergency_contacts ec
               JOIN parents p ON p.student_id = ec.student_id
              WHERE ec.id = ? AND p.user_id = ?
              LIMIT 1",
            [$contactId, $sessionUserId]
        );
        if (!$owns) {
            ob_end_clean();
            errorResponse('Not authorized', 403);
        }

        $ok = $db->execute("DELETE FROM student_emergency_contacts WHERE id = ?", [$contactId]);
        ob_end_clean();
        if ($ok === false) {
            errorResponse('Failed to delete contact');
        }
        successResponse(['deleted' => true], 'Emergency contact removed');
        break;

    // ── SIGN OUT ──────────────────────────────────────────────────────────────
    case 'signout':
        session_destroy();
        ob_end_clean();
        successResponse(['signed_out' => true]);
        break;

    default:
        ob_end_clean();
        errorResponse('Unknown action', 400);
}

/**
 * Email a short welcome note the moment an account finishes first-login
 * setup (password_changed flips 0 → 1). Best-effort — never blocks the
 * password change itself if the email fails.
 */
function notifyAccountActivated($db, $userId) {
    try {
        $user = $db->queryOne("SELECT email, full_name FROM users WHERE id = ?", [$userId]);
        if (!$user || empty($user['email'])) return;

        $subject = 'Your NSMS Parent Account is Now Active';
        $body =
            '<p>Dear ' . htmlspecialchars($user['full_name']) . ',</p>' .
            '<p>Your parent account has been successfully activated. You can now log in with your new password ' .
            'to view your child\'s attendance, reports, messages, and fee payments.</p>' .
            '<p style="color:#888;font-size:12px;">If you did not make this change, please contact the school office immediately.</p>';
        sendEmail($user['email'], $subject, $body);
    } catch (Exception $e) {
        error_log('notifyAccountActivated error: ' . $e->getMessage());
    }
}

/**
 * The student_emergency_contacts table is new — create it on first use
 * rather than requiring a manual migration (same self-healing approach
 * used for school_gallery in api/settings.php).
 */
function ensureEmergencyContactsTable($db) {
    $db->execute(
        "CREATE TABLE IF NOT EXISTS student_emergency_contacts (
            id int UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id int NOT NULL,
            full_name varchar(100) NOT NULL,
            relationship varchar(50) NOT NULL,
            phone varchar(20) NOT NULL,
            alt_phone varchar(20) DEFAULT NULL,
            notes varchar(255) DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY student_id (student_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
}