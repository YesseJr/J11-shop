# SPA / component roadmap

## Current (safe)

- Pages are **precompiled** to `public/js/built/pages/*.js` (no Babel in the browser).
- Shared chrome lives in `public/includes/js/*-shared.js` → built to `public/js/built/*-shared.js`.
- Optional entry: `public/spa.html#dashboard` routes into the existing compiled admin pages.
- Source helpers: `public/js/src/components/AppShell.js`, `public/js/src/spa-router.js`.

## Why not a full SPA rewrite in one step

Replacing 30+ multi-thousand-line screens with a single React tree would risk finance, attendance, and Pulse regressions. The offline build already removed the worst production issue (in-browser Babel).

## Next increments (when ready)

1. Move page bodies from HTML inline history into `public/js/src/pages/*.jsx`.
2. Point `scripts/build-frontend.mjs` at `src/` only.
3. Replace `spa.html` redirect with in-place `import()` of page modules.
4. Add React Router (or keep the tiny hash router) once two portals are migrated.

Until then, **keep using** `/nsms/public/admin|teacher|parent/*.html` as the primary URLs.

## Admin shell (current)

`/nsms/public/spa.html` is a **single React tree** for admin chrome (top nav + hash router). Page bodies load in an iframe from the existing compiled admin HTML modules. That gives:

- One component tree for navigation/shell
- Zero rewrite risk for finance/students/teachers logic
- A path to later replace the iframe with `import()` of built page modules

Direct URLs (`/admin/dashboard.html` etc.) remain fully supported.
