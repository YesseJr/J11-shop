# Production configuration (SITE_URL + Brevo)

Password-reset and welcome emails must use a **public absolute URL**.

## Required

```bash
export NSMS_SITE_URL=https://your-domain.com/nsms
export NSMS_BREVO_API_KEY=xkeysib-your-real-key
export NSMS_MAIL_SENDER_EMAIL=noreply@your-domain.com
export NSMS_MAIL_SENDER_NAME="Your School Name"
```

Or copy `includes/mail_config.example.php` → `includes/mail_config.php` and set:

```php
define('SITE_URL', 'https://your-domain.com/nsms');
define('BREVO_API_KEY', 'xkeysib-...');
define('MAIL_SENDER_EMAIL', 'noreply@your-domain.com');
define('MAIL_SENDER_NAME', 'Your School Name');
```

`includes/config.php` loads env first, then `mail_config.php`.

## Verify

1. Request a password reset for a test parent.
2. Open the email link — host must be **your domain**, not `localhost`.
3. Brevo dashboard → SMTP & API → check delivery / rejects.

## Apache / PHP-FPM

Set env in the vhost or pool, e.g.:

```apache
SetEnv NSMS_SITE_URL https://your-domain.com/nsms
```
