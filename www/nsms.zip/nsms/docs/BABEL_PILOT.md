# Babel-in-browser → build pilot

## Why
Many `public/**/*.html` pages load React + Babel in the browser. Slow and fragile on older devices.

## Pilot target
`public/parent/dashboard.html` — high traffic, clear components.

## Approach
1. Scaffold Vite + React in `frontend/`
2. Move ParentDashboard into `frontend/src/parent/dashboard/`
3. Build into `public/parent/dashboard/` static assets
4. Keep API URLs `/nsms/api/...` unchanged
5. Keep global `public/js/csrf.js`

## Success criteria
- Dashboard loads without `babel.min.js`
- Same API behaviour
- Bundle reasonable for a dashboard page

## Non-goals for pilot
- Rewriting all admin/teacher pages
- Changing PHP APIs
