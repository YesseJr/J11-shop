# Specific objectives — gap close (email, no SMS)

## Already in product (verified)

| Objective | Capability |
|-----------|------------|
| 1 Registration | Admin students + photos + parents |
| 2 Diary | Teacher homework + parent daily diary |
| 3 Progress reports | Teacher reports → publish/approve; parent reports + **Print / Save PDF** |
| 4 Attendance | Teacher mark + **email** on first absence (+ in-app notification) |
| 5 Fees | Pay + verify + receipts + **send_fee_reminders** (email) from finance |
| 6 Communication | J11 Pulse + bell + report/absence **email** |
| 7 Handbook | Admin regulations + **parent Handbook** page (searchable) |

## Email (not SMS)

- Absence: `teacher-attendance.php` → `notifyParentsOfAbsence` (email + notifications table)
- Report published: `teacher-reports.php` → `notifyParentsReportPublished`
- Fee balance: `finance.php?action=send_fee_reminders` (admin finance UI)

## Parent handbook

- Page: `/nsms/public/parent/handbook.html`
- Data: `settings.php?action=get_regulations` + `get_calendar` (public)
- Sidebar: **School Handbook**

## Still optional later

- Native FCM push
- SMS gateway
- Dedicated PDF binary generator (browser Print/PDF is used today)
