# Finance source of truth (design)

## Problem
Two parallel models still exist:
1. **Ledger:** `fee_payments` — cash/admin recorded payments
2. **Gateway / transactions:** `payment_transactions`, `payment_items`, legacy tables
3. **Schedule:** `fee_installments`, `fee_structure`

Parent and admin status can disagree when installments are not updated after cash payments.

## Decision (recommended)
**Authoritative balance = fee_structure expected − SUM(confirmed fee_payments)** for the academic year.

| Concern | Source |
|--------|--------|
| What is owed (catalog) | `fee_structure` by class + one-time fees |
| What was paid | `fee_payments` where status = confirmed/paid |
| Installment UX only | `fee_installments` derived/synced from ledger, not authoritative |
| Online gateway attempts | `payment_transactions` until confirmed, then write `fee_payments` |

## Migration outline (backup first)
1. Snapshot DB
2. For each student + year: expected from structure, paid from `fee_payments`
3. Rebuild or mark `fee_installments` to match remaining balance
4. Gate parent paid/pending through one PHP helper
5. Deprecate transaction tables for status badges
6. Keep gateway tables for audit of online attempts

## Implementation order
1. Single helper `getStudentFeeStatus($db, $studentId, $year)` for admin + parent
2. Point parent-panel + finance APIs at that helper
3. Optional nightly job to sync installment rows
4. Remove dual UI paths once verified

## Risk
Merging tables in place can double-count or wipe history. Prefer **read-path unification** before any destructive schema merge.
