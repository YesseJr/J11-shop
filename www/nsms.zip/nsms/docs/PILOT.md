# One-week pilot checklist

**Scope:** 1 class, 1 teacher, 5–10 parents, 1 admin.

| Day | Activity | Pass? |
|-----|----------|-------|
| 1 | Admin accounts + class roster + parent links | |
| 1 | Each parent activates / logs in | |
| 2 | Teacher posts homework / diary | |
| 2 | Parents open Daily Diary | |
| 3 | Mark 1–2 absences → email + bell | |
| 4 | Publish one weekly/midterm report → parent email | |
| 4 | Parent Print/Save PDF | |
| 5 | Parent submits fee proof → admin verifies | |
| 6 | Admin fee reminder (if balances) | |
| 6 | Parent opens School Handbook | |
| 7 | J11 Pulse message teacher ↔ parent | |
| 7 | Collect 5 feedback notes (confusion points only) | |

**Do not** add features mid-pilot unless login or payment is broken.
