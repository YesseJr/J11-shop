# Upload hardening

## What changed
- `includes/helpers.php` adds `nsmsStoreUpload()`:
  - size limit
  - extension allow-list
  - blocks obvious script / double-extension names
  - verifies MIME with `finfo` when available
  - random stored filenames (`bin2hex(random_bytes(16))`)
  - file mode `0644`
- Legacy `uploadFile()` still works and calls the new helper.
- `.htaccess` under `uploads/`, `public/uploads/`, and `publicuploads/` denies execution of PHP and common script types (Apache).

## Deploy notes
1. Ensure upload dirs exist and are writable by the web user (not world-writable if you can avoid it).
2. On **Nginx**, `.htaccess` is ignored — deny scripts explicitly, e.g.:

```nginx
location ^~ /nsms/uploads/ {
    location ~* \.(php|phtml|phar|cgi)$ { deny all; }
}
location ^~ /nsms/public/uploads/ {
    location ~* \.(php|phtml|phar|cgi)$ { deny all; }
}
location ^~ /nsms/publicuploads/ {
    location ~* \.(php|phtml|phar|cgi)$ { deny all; }
}
```

3. Prefer calling `nsmsStoreUpload()` from new API code instead of raw `move_uploaded_file`.
