# Deploy checklist (quality gates that actually run)

## Before upload
- [ ] `npm run build`
- [ ] `npm run smoke`
- [ ] PHP: `find api includes -name '*.php' | xargs -n1 php -l`

## Server env (required for reset email)
```bash
export NSMS_SITE_URL=https://YOUR-DOMAIN/nsms
export NSMS_BREVO_API_KEY=xkeysib-...
export NSMS_MAIL_SENDER_EMAIL=noreply@YOUR-DOMAIN
export NSMS_MAIL_SENDER_NAME="School Name"
```
Or fill `includes/mail_config.php` from the example.

## After deploy
1. `GET /nsms/api/health.php?public=1` → `"status":"ok"`
2. Admin login → `GET /nsms/api/health.php` → review `checks` + `metrics`
3. One forgot-password test on a spare account
4. `GET /nsms/api/finance.php?action=ledger_reconcile&limit=20`
5. Hard-refresh browsers (Ctrl+Shift+R)

## CI
Push to GitHub so `.github/workflows/ci.yml` runs. If Actions are disabled, treat the “Before upload” commands as mandatory manual CI.

## Fee promote (optional, insert-only)
```http
POST /nsms/api/finance.php?action=ledger_promote&limit=100
```
Copies missing verified gateway rows into `fee_payments`. Never deletes.
