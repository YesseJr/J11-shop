# NSMS Offline-First Architecture

## Principle

Existing MySQL-backed APIs and UI **remain the primary online path**.  
This layer adds:

1. Local **SQLite** (`data/nsms_local.sqlite`) for offline queue + priority entity cache  
2. **Record-level** sync API (`api/sync.php`) with UUID + op_id idempotency  
3. **Change log** on MySQL for incremental pull  
4. UI **Online / Offline / Syncing** indicator  

**No full database dump/replace** is used.

## Status

Foundation (Phase 3) is implemented. Gradual integration of each module into the outbox (Phase 4) is intentional so nothing regresses.

## Priority offline entities

- students, classes, users, attendance, homework, fee_payments, notifications, school_settings

## API

| Action | Method | Auth | Purpose |
|--------|--------|------|---------|
| `health` | GET | No | Connectivity probe |
| `status` | GET | Yes | Local + server stats |
| `push` | POST | Yes | Upload batch of ops |
| `pull` | POST/GET | Yes | Download changes since cursor |
| `run` | POST | Yes | Full local push+pull |
| `register_device` | POST | Yes | Device UUID registry |
| `sessions` | GET | Admin | Sync session log |
| `conflicts` | GET | Admin | Conflict list |

### Push body

```json
{
  "device_uuid": "...",
  "operations": [
    {
      "op_id": "uuid-of-this-op",
      "entity_type": "students",
      "record_uuid": "uuid-of-record",
      "operation": "CREATE",
      "payload": { "student_name": "…", "status": "active" }
    }
  ]
}
```

Retrying the same `op_id` does **not** create duplicates.

## Environment

```
NSMS_OFFLINE_MODE=0
NSMS_SQLITE_PATH=/path/to/nsms_local.sqlite
NSMS_REMOTE_SYNC_URL=https://your-server/nsms
NSMS_SYNC_BATCH_SIZE=100
NSMS_SYNC_CONFLICT_STRATEGY=last_write_wins
```

## Admin UI

`/nsms/public/admin/sync.html`

## Future desktop (NSMS.exe)

Local PHP + SQLite already live under `data/`. A desktop wrapper can point document root at `public/` without changing this design.

## What was NOT done yet (by design)

- Rewriting every existing API to dual-write SQLite (would risk regressions)
- Packaging `.exe`
- Full conflict UI for every field

Next integration step: wrap selected write endpoints (e.g. attendance mark) to enqueue sync_queue when offline mode is enabled.


## Phase 4 — Module wiring (implemented)

`SyncHooks::afterWrite()` is called after successful MySQL mutations for:

- Students (create / update / withdraw / lifecycle)
- Attendance (save)
- Homework (create)
- Classes (add / update)
- Fee payments (on admin approval)

Each write:

1. Ensures a stable `uuid` on the MySQL row
2. Appends to `sync_change_log` (for other devices to **pull**)
3. Mirrors into local SQLite when available

**Automatic client sync:** `nsms-sync-status.js` probes health every ~45s and, when online with pending outbox items, runs `action=run`. On browser `online` event, it also triggers a sync after 2s.

Security remains: session auth + CSRF on mutating sync API calls. No DB credentials are exposed to the browser.


## Offline authentication

### How it works

1. User logs in **online** successfully → bcrypt/`password_hash` is stored in SQLite `offline_users` (never plaintext).
2. Accounts with `password_changed = 0` (must activate) are **not** cached.
3. When MySQL is down, `auth.php?action=login` verifies the password against the SQLite hash only.
4. Session is established with `offline_mode = true`.
5. Password reset **revokes** the offline cache until the user logs in online again.

### How to test

1. Start Laragon fully. Log in once as admin/teacher/parent (activated account).
2. Confirm offline cache: check `nsms/data/nsms_local.sqlite` table `offline_users` (or Sync panel later).
3. **Stop MySQL only** (keep Apache/PHP running).
4. Log in with the same email/password → should succeed with message **Login successful (offline mode)**.
5. Start MySQL again → next login is normal online and refreshes the cache.

### Security

- Rate limiting still applies offline.
- No plaintext passwords in SQLite.
- Inactive accounts not cached.
- Activation-required accounts cannot go offline until activated online.

## Offline-First Admin (Phase B)

### Local SQLite holds
- students, classes, teachers_cache, attendance
- fee_payments_local (cash & warmed payments)
- activity_log_local
- offline_users (auth)
- sync_queue (outbox)

### Offline writes (queue → MySQL on reconnect)
- Student create/update
- Teacher create/update  
- Cash payment record
- Attendance marks

### Idempotency
Each queued op has `op_id` UUID; `sync_processed_ops` prevents duplicates on push.

### Prepare offline (online)
Admin → Synchronization → **Prepare offline logins** warms users, roster, teachers, settings, payments into SQLite.
