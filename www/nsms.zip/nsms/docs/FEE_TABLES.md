# Fee / payment tables (do not drop yet)

NSMS currently has two parallel payment histories:

| Table | Role |
|-------|------|
| `fee_payments` | Legacy / admin ledger-style fee records |
| `payment_transactions` (+ `payment_items`) | Parent portal / gateway verification flow |

**Do not** merge or drop either table until a migration has been validated on a full production dump.

Recommended future steps:
1. Export both tables and reconcile student balances.
2. Point parent UI and admin finance at one write path.
3. Keep the other as read-only archive for one term.
4. Only then deprecate the archive table.

Until then both stay in place so balances and history are not broken.

## Read-only reconciliation API

```
GET /nsms/api/finance.php?action=ledger_reconcile&limit=50
```

Admin-only. Returns per-student totals from `fee_payments` and `payment_transactions`, and a `combined` value using **MAX** of the two (avoids double-counting until migration).

Helpers: `includes/fee_ledger.php` (`nsmsLedgerStudentPaid`, `nsmsLedgerReconcileSummary`).

## Promote missing gateway rows (insert-only)

```http
POST /nsms/api/finance.php?action=ledger_promote&limit=100
```

Admin-only. For verified/received `payment_transactions` without a matching `fee_payments` receipt/reference, inserts ledger rows and links `payment_items.fee_payment_id` when possible. **Never deletes.**

New gateway approvals already write `fee_payments` at approve time; promote is for historical gaps only.
