# NSMS Live QA Checklist

Run on your real stack after deploying. Prefer a hard refresh (Ctrl+Shift+R) so vendor scripts load.

## Setup
- [ ] Import SQL dump; set `NSMS_DB_*` env if not defaults
- [ ] Upload dirs writable: `uploads/`, `public/uploads/`, `publicuploads/`
- [ ] Open `/nsms/public/index.html` — landing loads
- [ ] DevTools → Network: React/Babel load from `/nsms/public/js/vendor/` (not unpkg)
- [ ] CSRF: any mutating POST sends `X-CSRF-Token`

## Console smoke (all roles)
Open DevTools → Console. For each page: no red errors, `#root` not empty.

### Admin (after login)
- [ ] Dashboard
- [ ] Students
- [ ] Teachers
- [ ] Finance
- [ ] Analytics
- [ ] J11 Pulse (`admin-pulse.html`)
- [ ] Settings
- [ ] Promotions (if used)
- [ ] Reports

### Teacher
- [ ] Dashboard
- [ ] Attendance
- [ ] Gradebook
- [ ] Homework
- [ ] My class
- [ ] Reports
- [ ] J11 Pulse (`teacher-pulse.html`)

### Parent
- [ ] Dashboard
- [ ] Attendance
- [ ] Fee payments / Pay fees
- [ ] Reports
- [ ] Daily diary
- [ ] J11 Pulse (`parent-pulse.html`)

## Feature checks

### Admin
- [ ] Dashboard stats load
- [ ] Settings → school name / phone / email save
- [ ] Settings → logo upload
- [ ] Settings → gallery image upload
- [ ] Settings → fee structure save for a class
- [ ] Students: list, add/edit
- [ ] Teachers: list, add/edit, photo if used
- [ ] Finance: record payment; status matches parent view

### Teacher
- [ ] Login / first-time password change → setup.html
- [ ] Attendance mark for today
- [ ] Post homework; special chars in subject display correctly
- [ ] Gradebook entry saves
- [ ] Pulse send message / file

### Parent
- [ ] Login / activation
- [ ] Dashboard homework / diary cards
- [ ] Fee status matches admin ledger
- [ ] Pulse badge and thread open

## Security smoke
- [ ] Logged-out POST to a protected API → 401/403
- [ ] POST without CSRF header → `csrf_failed` (when CSRF on)
- [ ] Upload a `.php` renamed as image to gallery/profile → rejected
- [ ] Apache: request to `/nsms/uploads/something.php` denied if present
- [ ] (Nginx) script deny rules applied per `docs/UPLOADS_HARDENING.md`

## Frontend pins
Local vendor copies (see `public/js/vendor/VERSIONS.txt`):
- React 18.3.1
- ReactDOM 18.3.1
- @babel/standalone 7.22.20

## Rollback CSRF (emergency)
```bash
# Windows
set NSMS_CSRF=0
# Linux/macOS
export NSMS_CSRF=0
```
