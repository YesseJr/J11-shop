# Strengthening package (implemented)

## Security
- Rate limits: login (IP + email), forgot-password, reset token use, fee reminders (3/hour/admin)
- CSRF still enforced on mutating APIs (`NSMS_CSRF=1`)
- Rate-limit state under `uploads/.rate_limit/` (web-denied)

## UX
- Parent **Fee Payments** sidebar → `pay-fees.html`
- Legacy `fee-payments.html` redirects to pay-fees
- Fee reminder emails include portal pay link when `NSMS_SITE_URL` is set

## Ops docs
- `docs/DEPLOY.md` — production config + smoke test
- `docs/PILOT.md` — one-week pilot
- `docs/OBJECTIVES_GAP_CLOSE.md` — objectives mapping

## Handbook icons
Prefer icon **names** in Admin → Regulations (`book`, `clipboard`, `alert-triangle`) so parent handbook shows SVGs, not emoji.

## Still manual
- Pilot with real families
- Live `SITE_URL` + Brevo verification
- Daily DB backup on the server
