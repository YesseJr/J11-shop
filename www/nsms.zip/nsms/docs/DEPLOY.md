# NSMS production deploy checklist

## 1. Environment

Set on the server (Apache/Nginx env, or a non-web-root file loaded by PHP):

```bash
NSMS_SITE_URL=https://your-school-domain.com/nsms
NSMS_BREVO_API_KEY=xkeysib-...
NSMS_MAIL_SENDER_EMAIL=noreply@your-school-domain.com
NSMS_MAIL_SENDER_NAME=School Name NSMS
NSMS_CSRF=1
```

`NSMS_SITE_URL` must be **public https** (not `http://localhost/...`). Reset and activation emails use it.

## 2. Database

- Import / migrate schema
- Create admin user
- Backup: `mysqldump -u… -p… nsms > backup-$(date +%F).sql`

## 3. Web server

- Document root points at project correctly (`/nsms/public` routes work)
- `uploads/` and `publicuploads/` not executable as PHP (`.htaccess` deny)
- HTTPS certificate valid

## 4. Frontend

```bash
cd /path/to/nsms && npm install && npm run build
```

## 5. Verify

```text
GET /nsms/api/health.php?public=1
GET /nsms/api/health.php   (as admin session)
```

Expect: database ok, site_url looks_public true, brevo api_key_present, frontend build present.

## 6. Smoke test

1. Admin login  
2. Create parent → activation email / temp password  
3. Parent activate → change password  
4. Teacher mark absence → parent email  
5. Parent pay fee → admin verify  
6. Publish report → parent email + Reports → Print/PDF  
7. Parent Handbook opens  

## 7. Backups

Daily mysqldump + weekly copy off-server. Test restore once.
