/**
 * NSMS offline speed layer
 * - Probes MySQL health with a short timeout
 * - Caps fetch waits on non-critical APIs
 * - NEVER aborts auth/session endpoints (prevents instant logout)
 */
(function (window) {
  'use strict';
  if (window.__NSMS_OFFLINE_FAST) return;
  window.__NSMS_OFFLINE_FAST = true;

  window.NSMS_MYSQL_ONLINE = null;

  var HEALTH = '/nsms/api/sync.php?action=health';
  var DEFAULT_MS = 6000;

  function isCriticalAuthUrl(url) {
    if (!url) return false;
    url = String(url);
    if (url.indexOf('/nsms/api/auth.php') !== -1) return true;
    if (url.indexOf('action=session') !== -1) return true;
    if (url.indexOf('action=login') !== -1) return true;
    if (url.indexOf('action=check') !== -1) return true;
    if (url.indexOf('action=me') !== -1) return true;
    if (url.indexOf('action=csrf') !== -1) return true;
    // Mutations must not be aborted mid-flight (offline SQLite can be slow on first write)
    if (url.indexOf('action=create') !== -1) return true;
    if (url.indexOf('action=update') !== -1) return true;
    if (url.indexOf('action=add_') !== -1) return true;
    if (url.indexOf('action=record') !== -1) return true;
    if (url.indexOf('action=save') !== -1) return true;
    if (url.indexOf('action=run') !== -1) return true;
    return false;
  }

  function timeoutSignal(ms) {
    if (typeof AbortSignal !== 'undefined' && typeof AbortSignal.timeout === 'function') {
      try { return AbortSignal.timeout(ms); } catch (e) {}
    }
    if (typeof AbortController === 'undefined') return undefined;
    var c = new AbortController();
    setTimeout(function () { try { c.abort(); } catch (e) {} }, ms);
    return c.signal;
  }

  function probe() {
    var signal = timeoutSignal(2500);
    return fetch(HEALTH, { credentials: 'same-origin', cache: 'no-store', signal: signal })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        var online = !!(j && j.data && j.data.database);
        window.NSMS_MYSQL_ONLINE = online;
        try {
          window.dispatchEvent(new CustomEvent('nsms-mysql-status', { detail: { online: online } }));
        } catch (e) {}
        return online;
      })
      .catch(function () {
        window.NSMS_MYSQL_ONLINE = false;
        try {
          window.dispatchEvent(new CustomEvent('nsms-mysql-status', { detail: { online: false } }));
        } catch (e) {}
        return false;
      });
  }

  var orig = window.fetch;
  window.fetch = function (input, init) {
    init = init || {};
    var url = typeof input === 'string' ? input : (input && input.url) || '';
    var isApi = url.indexOf('/nsms/api/') !== -1;
    var critical = isCriticalAuthUrl(url);

    // Never attach abort timeout to auth/session — logout bugs
    if (isApi && !init.signal && !critical) {
      // Offline: allow more time (MySQL fail-fast + SQLite). Online: 6s default.
      var ms = window.NSMS_MYSQL_ONLINE === false ? 12000 : DEFAULT_MS;
      init.signal = timeoutSignal(ms);
    }

    return orig.call(window, input, init);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { probe(); });
  } else {
    probe();
  }
  setInterval(probe, 30000);

  window.NSMS_OFFLINE_FAST = { probe: probe };
})(window);
