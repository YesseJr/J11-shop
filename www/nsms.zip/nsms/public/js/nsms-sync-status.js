/**
 * NSMS network + sync status indicator
 * Lightweight probe against /nsms/api/sync.php?action=health
 * Does not break pages if the script fails to load.
 */
(function () {
  var API = '/nsms/api/sync.php';
  var state = { online: null, pending: 0, failed: 0, last: '', syncing: false };

  function ensureStyles() {
    if (document.getElementById('nsms-sync-styles')) return;
    var s = document.createElement('style');
    s.id = 'nsms-sync-styles';
    s.textContent =
      '.nsms-sync-pill{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;' +
      'font-size:11px;font-weight:700;border:1px solid #E2E8F0;background:#fff;color:#475569;cursor:pointer;' +
      'font-family:inherit;line-height:1.2;white-space:nowrap;max-width:160px}' +
      '.nsms-sync-pill .dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;background:#94A3B8}' +
      '.nsms-sync-pill.online .dot{background:#10B981}' +
      '.nsms-sync-pill.offline .dot{background:#EF4444}' +
      '.nsms-sync-pill.syncing .dot{background:#F59E0B;animation:nsmsPulse 1s infinite}' +
      '.nsms-sync-pill.error .dot{background:#F97316}' +
      '@keyframes nsmsPulse{0%,100%{opacity:1}50%{opacity:.35}}' +
      '.nsms-sync-panel{position:absolute;right:0;top:calc(100% + 8px);width:280px;background:#fff;' +
      'border:1px solid #E2E8F0;border-radius:12px;box-shadow:0 12px 40px rgba(15,23,42,.12);padding:14px;' +
      'z-index:1200;font-size:12.5px;color:#334155;display:none}' +
      '.nsms-sync-panel.open{display:block}' +
      '.nsms-sync-panel h4{margin:0 0 8px;font-size:13px;font-weight:800;color:#0F172A}' +
      '.nsms-sync-panel .row{display:flex;justify-content:space-between;gap:8px;padding:4px 0;border-bottom:1px solid #F1F5F9}' +
      '.nsms-sync-panel .row:last-child{border-bottom:none}' +
      '.nsms-sync-panel .muted{color:#94A3B8}' +
      '.nsms-sync-panel button.sync-now{margin-top:10px;width:100%;padding:8px;border-radius:8px;border:none;' +
      'background:#1D5C42;color:#fff;font-weight:700;font-size:12.5px;cursor:pointer;font-family:inherit}' +
      '.nsms-sync-panel button.sync-now:disabled{opacity:.6;cursor:not-allowed}' +
      '.nsms-sync-wrap{position:relative;display:inline-flex;align-items:center;margin-right:6px}';
    document.head.appendChild(s);
  }

  function label() {
    if (state.syncing) return 'Syncing…';
    if (state.online === false) return 'Offline';
    if (state.failed > 0) return 'Sync error';
    if (state.pending > 0) return 'Pending ' + state.pending;
    if (state.online) return 'Online';
    return 'Checking…';
  }

  function cssClass() {
    if (state.syncing) return 'syncing';
    if (state.online === false) return 'offline';
    if (state.failed > 0) return 'error';
    if (state.online) return 'online';
    return '';
  }

  function render() {
    var btn = document.getElementById('nsms-sync-btn');
    if (!btn) return;
    btn.className = 'nsms-sync-pill ' + cssClass();
    btn.innerHTML = '<span class="dot"></span><span>' + label() + '</span>';
    var panel = document.getElementById('nsms-sync-panel');
    if (!panel) return;
    panel.innerHTML =
      '<h4>Connection & Sync</h4>' +
      '<div class="row"><span class="muted">Connection</span><strong>' +
      (state.online ? 'Online' : state.online === false ? 'Offline' : '…') +
      '</strong></div>' +
      '<div class="row"><span class="muted">Pending changes</span><strong>' + state.pending + '</strong></div>' +
      '<div class="row"><span class="muted">Failed</span><strong>' + state.failed + '</strong></div>' +
      '<div class="row"><span class="muted">Last sync</span><strong>' +
      (state.last ? state.last : '—') +
      '</strong></div>' +
      (state.lastMsg ? '<div class="row"><span class="muted">Result</span><strong style="font-size:11px">' + state.lastMsg + '</strong></div>' : '') +
      '<button type="button" class="sync-now" id="nsms-sync-now"' +
      (state.syncing ? ' disabled' : '') +
      '>Synchronize Now</button>';
    var now = document.getElementById('nsms-sync-now');
    if (now) now.onclick = function (e) { e.stopPropagation(); runSync(); };
  }

  function mount() {
    ensureStyles();
    if (document.getElementById('nsms-sync-wrap')) return;
    var host =
      document.querySelector('.nav-right') ||
      document.querySelector('.nsms-nav') ||
      null;
    if (!host) return;
    var wrap = document.createElement('div');
    wrap.id = 'nsms-sync-wrap';
    wrap.className = 'nsms-sync-wrap';
    wrap.innerHTML =
      '<button type="button" id="nsms-sync-btn" class="nsms-sync-pill" title="Sync status"></button>' +
      '<div id="nsms-sync-panel" class="nsms-sync-panel"></div>';
    if (host.classList.contains('nav-right')) {
      host.insertBefore(wrap, host.firstChild);
    } else {
      host.appendChild(wrap);
    }
    var btn = document.getElementById('nsms-sync-btn');
    var panel = document.getElementById('nsms-sync-panel');
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      panel.classList.toggle('open');
    });
    document.addEventListener('click', function () {
      panel.classList.remove('open');
    });
    render();
  }

  function probeHealth() {
    return fetch(API + '?action=health', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        // success can be true even when MySQL is down (degraded) — use database flag
        if (!j) { state.online = false; return; }
        if (j.data && typeof j.data.database !== 'undefined') {
          state.online = !!j.data.database;
        } else {
          state.online = !!(j.success && j.message !== 'Database unavailable');
        }
      })
      .catch(function () {
        state.online = false;
      });
  }

  function probeStatus() {
    return fetch(API + '?action=status', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j && j.success && j.data) {
          state.online = !!j.data.online;
          state.pending = j.data.pending || 0;
          state.failed = j.data.failed || 0;
          state.last = j.data.last_sync_at || '';
        }
      })
      .catch(function () { /* keep previous */ });
  }

  function runSync() {
    if (state.syncing) return;
    state.syncing = true;
    state.lastMsg = 'Syncing…';
    render();
    var headers = { 'Content-Type': 'application/json', Accept: 'application/json' };
    var doFetch = function () {
      return fetch(API + '?action=run', {
        method: 'POST',
        credentials: 'same-origin',
        headers: headers,
        body: '{}'
      });
    };
    var chain = (window.NSMS_CSRF && window.NSMS_CSRF.getToken)
      ? window.NSMS_CSRF.getToken().then(function (token) {
          if (token) headers['X-CSRF-Token'] = token;
          return doFetch();
        })
      : doFetch();
    chain
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j && j.success && j.data) {
          state.online = true;
          var up = j.data.uploaded || 0;
          var fail = j.data.failed || 0;
          state.pending = typeof j.data.pending === 'number' ? j.data.pending : state.pending;
          state.failed = fail;
          state.last = new Date().toISOString();
          state.lastMsg = 'Synced: ' + up + ' uploaded' + (fail ? (', ' + fail + ' failed') : '');
          if (fail && j.data.results) console.warn('NSMS sync failures', j.data.results);
        } else {
          state.lastMsg = (j && j.error) ? ('Sync error: ' + j.error) : 'Sync failed';
          console.warn('NSMS sync', j);
        }
        return probeStatus();
      })
      .catch(function (e) {
        state.lastMsg = 'Sync network error';
        console.warn(e);
      })
      .finally(function () {
        state.syncing = false;
        render();
      });
  }

  function autoSyncIfNeeded() {
    if (!state.online || state.syncing) return;
    if ((state.pending || 0) < 1) return;
    // Automatic, quiet sync when pending local changes exist
    runSync();
  }

  function tick() {
    probeHealth()
      .then(function () {
        if (state.online) return probeStatus().then(autoSyncIfNeeded);
      })
      .finally(render);
  }

  function boot() {
    mount();
    tick();
    // Gentle polling — not every second
    setInterval(tick, 45000);
    window.addEventListener('online', function () {
      tick();
      setTimeout(function () {
        if (state.online) runSync();
      }, 2000);
    });
    window.addEventListener('offline', function () {
      state.online = false;
      render();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    setTimeout(boot, 50);
  }

  window.NSMSSync = { refresh: tick, run: runSync, getState: function () { return state; } };
})();
