/* ═══════════════════════════════════════════════════════════════
   NSMS SHARED COMPONENTS  —  nsms/public/js/nsms-shared.js
   Merged from: nsms-shared.js (v1) + nsms-shared00.js (v2)

   Requires: React, ReactDOM loaded before this file.
   Exposes globals (var): NSMSNavbar, NSMSSidebar, NSMSProfileModal

   ── Migration note (v2 → v3) ──────────────────────────────────
   • "Messages" sidebar entry (key: 'messages') restored back to
     "J11 Pulse" (key: 'pulse', admin-pulse.html).
     Update any page passing activePage='messages' → activePage='pulse'.
   • NSMSBell now calls auth.php?action=generate_reminders on mount
     and on the slow timer — same pattern as TcBell — so the Alerts
     tab and badge are seeded correctly.  Requires the matching
     generate_reminders case in auth.php (see note below).
   • NSMSBell is tabbed (Messages + Alerts), with live polling,
     per-alert mark-as-read, and a bell-pulse animation.
   • NSMSSidebar now hover-expands; collapsed by default.
═══════════════════════════════════════════════════════════════ */

/* ── Avatar helpers ── */
var NSMS_AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2'];
var nsmsAvColor = function (n) {
  return n ? NSMS_AV_COLORS[n.charCodeAt(0) % NSMS_AV_COLORS.length] : '#94A3B8';
};
var nsmsInitials = function (n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
};

/* ── Sidebar items (all pages) ──
   NOTE: 'payment_verification' is the admin queue for reviewing
   parent-submitted gateway transactions (approve/reject), separate
   from the broader 'finance' reporting/ledger page. */
var NSMS_SIDEBAR_ITEMS = [{
  key: 'dashboard',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "home",
    size: 20
  }),
  label: 'Dashboard',
  href: '/nsms/public/admin/dashboard.html'
}, {
  key: 'students',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "users",
    size: 20
  }),
  label: 'Students',
  href: '/nsms/public/admin/students.html'
}, {
  key: 'promotions',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "graduation-cap",
    size: 20
  }),
  label: 'Promotions',
  href: '/nsms/public/admin/promotions.html'
}, {
  key: 'teachers',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "teacher",
    size: 20
  }),
  label: 'Teachers',
  href: '/nsms/public/admin/teachers.html'
}, {
  key: 'finance',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "dollar",
    size: 20
  }),
  label: 'Finance',
  href: '/nsms/public/admin/finance.html'
}, {
  key: 'payment_verification',
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 20
  }),
  label: 'Verify Payments',
  href: '/nsms/public/admin/payment-verification.html'
}, {
  key: 'analytics',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "chart",
    size: 20
  }),
  label: 'Analytics',
  href: '/nsms/public/admin/analytics.html'
}, {
  key: 'reports',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "clipboard",
    size: 20
  }),
  label: 'Reports',
  href: '/nsms/public/admin/admin-reports.html'
}, {
  key: 'pulse',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "zap",
    size: 20
  }),
  label: 'J11 Pulse',
  href: '/nsms/public/admin/admin-pulse.html'
}, {
  key: 'settings',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 20
  }),
  label: 'Settings',
  href: '/nsms/public/admin/settings.html'
}];

/* ── Navbar quick-links (right-aligned, 4 items only) ── */
var NSMS_NAV_LINKS = [{
  key: 'dashboard',
  label: 'Home',
  href: '/nsms/public/admin/dashboard.html'
}, {
  key: 'students',
  label: 'Manage Students',
  href: '/nsms/public/admin/students.html'
}, {
  key: 'teachers',
  label: 'Manage Teachers',
  href: '/nsms/public/admin/teachers.html'
}, {
  key: 'finance',
  label: 'Finance',
  href: '/nsms/public/admin/finance.html'
}];

/* ── School logo — renders custom image if available, else SVG fallback ── */
function SchoolLogoMark(props) {
  var logoUrl = props.logoUrl || '';
  if (logoUrl) {
    return /*#__PURE__*/React.createElement("img", {
      src: logoUrl,
      alt: "School Logo",
      style: {
        width: '100%',
        height: '100%',
        objectFit: 'contain',
        borderRadius: '6px',
        display: 'block'
      },
      onError: function (e) {
        e.target.style.display = 'none';
      }
    });
  }
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 21h18M5 21V7l7-4 7 4v14",
    stroke: "rgba(255,255,255,.7)",
    strokeWidth: "1.5",
    strokeLinejoin: "round"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "10",
    y: "14",
    width: "4",
    height: "7",
    rx: ".5",
    fill: "rgba(255,255,255,.9)"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "6.5",
    y: "9.5",
    width: "3",
    height: "3",
    rx: ".5",
    fill: "rgba(255,255,255,.8)"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14.5",
    y: "9.5",
    width: "3",
    height: "3",
    rx: ".5",
    fill: "rgba(255,255,255,.8)"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "3.2",
    x2: "12",
    y2: "1",
    stroke: "rgba(255,255,255,.7)",
    strokeWidth: "1.2"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "12,1 15,2.2 12,3.4",
    fill: "rgba(255,255,255,.9)"
  }));
}
/* Alias — keeps any existing page that calls <SchoolLogo /> working */
function SchoolLogo() {
  return /*#__PURE__*/React.createElement(SchoolLogoMark, {
    logoUrl: ""
  });
}

/* ── Module-level logo cache — one fetch per page load, shared by all components ── */
var _nsmsLogoCache = {
  loaded: false,
  url: (function () {
    try { return localStorage.getItem('nsms_school_logo') || ''; } catch (e) { return ''; }
  })()
};
var _nsmsLogoWaiters = [];
function _nsmsLoadLogo(cb) {
  if (_nsmsLogoCache.loaded) {
    cb(_nsmsLogoCache.url);
    return;
  }
  _nsmsLogoWaiters.push(cb);
  if (_nsmsLogoWaiters.length > 1) return; /* fetch already in-flight */
  fetch('/nsms/api/settings.php?action=get_public').then(function (r) {
    return r.json();
  }).then(function (d) {
    if (d.success && d.data) _nsmsLogoCache.url = d.data.school_logo || '';
    try {
      if (_nsmsLogoCache.url) localStorage.setItem('nsms_school_logo', _nsmsLogoCache.url);
      else localStorage.removeItem('nsms_school_logo');
    } catch (e) {}
  }).catch(function () {}).finally(function () {
    _nsmsLogoCache.loaded = true;
    var waiters = _nsmsLogoWaiters.slice();
    _nsmsLogoWaiters = [];
    waiters.forEach(function (fn) {
      fn(_nsmsLogoCache.url);
    });
  });
}

/* ═══════════════════════════════════════════════════════════════
   PROFILE MODAL
═══════════════════════════════════════════════════════════════ */
function NSMSProfileModal({
  open,
  onClose
}) {
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useRef = React.useRef;
  var profileState = useState(null);
  var profile = profileState[0];
  var setProfile = profileState[1];
  var loadingState = useState(true);
  var loadingPf = loadingState[0];
  var setLoadingPf = loadingState[1];
  var savingState = useState(false);
  var saving = savingState[0];
  var setSaving = savingState[1];
  var alertState = useState(null);
  var alert = alertState[0];
  var setAlert = alertState[1];
  var editState = useState(false);
  var editMode = editState[0];
  var setEditMode = editState[1];
  var showPwState = useState(false);
  var showPw = showPwState[0];
  var setShowPw = showPwState[1];
  var previewState = useState(null);
  var preview = previewState[0];
  var setPreview = previewState[1];
  var photoErrState = useState(false);
  var photoErr = photoErrState[0];
  var setPhotoErr = photoErrState[1];
  var uploadingState = useState(false);
  var uploading = uploadingState[0];
  var setUploading = uploadingState[1];
  var formState = useState({
    full_name: '',
    email: '',
    phone: ''
  });
  var form = formState[0];
  var setForm = formState[1];
  var pwState = useState({
    current: '',
    newPw: '',
    confirm: ''
  });
  var pw = pwState[0];
  var setPw = pwState[1];
  var fileRef = useRef(null);
  useEffect(function () {
    if (!open) return;
    setLoadingPf(true);
    setAlert(null);
    setEditMode(false);
    setShowPw(false);
    setPreview(null);
    setPhotoErr(false);
    setPw({
      current: '',
      newPw: '',
      confirm: ''
    });
    fetch('/nsms/api/admin_profile.php?action=get').then(function (r) {
      var status = r.status;
      return r.text().then(function (txt) {
        try {
          return JSON.parse(txt);
        } catch (e) {
          throw new Error('HTTP ' + status + ' — server returned: ' + txt.substring(0, 300));
        }
      });
    }).then(function (d) {
      if (d.success) {
        setProfile(d.data);
        setForm({
          full_name: d.data.full_name || '',
          email: d.data.email || '',
          phone: d.data.phone || ''
        });
      } else {
        setAlert({
          type: 'error',
          msg: d.error || 'Failed to load profile'
        });
      }
    }).catch(function (err) {
      setAlert({
        type: 'error',
        msg: err.message || 'Network error loading profile.'
      });
    }).finally(function () {
      setLoadingPf(false);
    });
  }, [open]);

  /* Close on Escape */
  useEffect(function () {
    if (!open) return;
    var onKey = function (e) {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return function () {
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);
  if (!open) return null;
  var user = profile;
  var hasPhoto = user && user.photo_url && !photoErr;
  var displayPreview = preview || (hasPhoto ? user.photo_url : null);

  /* ── Photo select → preview ── */
  function handleFileChange(e) {
    var file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setAlert({
        type: 'error',
        msg: 'Image must be under 5 MB.'
      });
      return;
    }
    var reader = new FileReader();
    reader.onload = function (ev) {
      setPreview(ev.target.result);
    };
    reader.readAsDataURL(file);
  }

  /* ── Upload selected photo ── */
  function handleUploadPhoto() {
    var file = fileRef.current && fileRef.current.files[0];
    if (!file) {
      fileRef.current && fileRef.current.click();
      return;
    }
    setUploading(true);
    setAlert(null);
    var fd = new FormData();
    fd.append('action', 'upload_photo');
    fd.append('photo', file);
    fetch('/nsms/api/admin_profile.php', {
      method: 'POST',
      body: fd
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setAlert({
          type: 'success',
          msg: 'Profile photo updated.'
        });
        setPhotoErr(false);
        setProfile(function (prev) {
          return Object.assign({}, prev, {
            photo_url: d.data && d.data.photo_url || prev.photo_url
          });
        });
        setPreview(null);
      } else {
        setAlert({
          type: 'error',
          msg: d.error || 'Photo upload failed.'
        });
      }
    }).catch(function () {
      setAlert({
        type: 'error',
        msg: 'Network error uploading photo.'
      });
    }).finally(function () {
      setUploading(false);
    });
  }

  /* ── Save profile fields ── */
  function handleSave() {
    if (!form.full_name.trim()) {
      setAlert({
        type: 'error',
        msg: 'Full name is required.'
      });
      return;
    }
    if (!form.email.trim()) {
      setAlert({
        type: 'error',
        msg: 'Email is required.'
      });
      return;
    }
    var body = {
      action: 'update_profile',
      full_name: form.full_name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim()
    };
    if (showPw) {
      if (!pw.current) {
        setAlert({
          type: 'error',
          msg: 'Enter your current password.'
        });
        return;
      }
      if (!pw.newPw) {
        setAlert({
          type: 'error',
          msg: 'Enter a new password.'
        });
        return;
      }
      if (pw.newPw.length < 6) {
        setAlert({
          type: 'error',
          msg: 'New password must be at least 6 characters.'
        });
        return;
      }
      if (pw.newPw !== pw.confirm) {
        setAlert({
          type: 'error',
          msg: 'New passwords do not match.'
        });
        return;
      }
      body.change_password = true;
      body.current_password = pw.current;
      body.new_password = pw.newPw;
    }
    setSaving(true);
    setAlert(null);
    fetch('/nsms/api/admin_profile.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setAlert({
          type: 'success',
          msg: 'Profile saved successfully.'
        });
        setProfile(function (p) {
          return Object.assign({}, p, {
            full_name: form.full_name,
            email: form.email,
            phone: form.phone
          });
        });
        setEditMode(false);
        setShowPw(false);
        setPw({
          current: '',
          newPw: '',
          confirm: ''
        });
      } else {
        setAlert({
          type: 'error',
          msg: d.error || 'Save failed.'
        });
      }
    }).catch(function () {
      setAlert({
        type: 'error',
        msg: 'Network error saving profile.'
      });
    }).finally(function () {
      setSaving(false);
    });
  }
  function setF(k, v) {
    setForm(function (f) {
      var n = Object.assign({}, f);
      n[k] = v;
      return n;
    });
  }
  function setP(k, v) {
    setPw(function (p) {
      var n = Object.assign({}, p);
      n[k] = v;
      return n;
    });
  }

  /* ── Modal has its own spinner for loading state ── */
  var loadSpinner = /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '60px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }));
  return /*#__PURE__*/React.createElement("div", {
    className: "pf-overlay",
    onClick: function (e) {
      if (e.target === e.currentTarget) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-modal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pf-header-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC64",
    size: 18
  }), " My Profile"), /*#__PURE__*/React.createElement("button", {
    className: "pf-close",
    onClick: onClose,
    title: "Close"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pf-body"
  }, loadingPf ? loadSpinner : /*#__PURE__*/React.createElement(React.Fragment, null, alert && /*#__PURE__*/React.createElement("div", {
    className: 'pf-alert ' + (alert.type === 'success' ? 'pf-alert-success' : 'pf-alert-error')
  }, /*#__PURE__*/React.createElement("span", null, alert.type === 'success' ? /*#__PURE__*/React.createElement(Icon, {
    name: "check-circle",
    size: 16
  }) : /*#__PURE__*/React.createElement(Icon, {
    name: "alert-triangle",
    size: 16
  })), /*#__PURE__*/React.createElement("span", null, alert.msg)), /*#__PURE__*/React.createElement("div", {
    className: "pf-photo-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-photo-ring"
  }, displayPreview ? /*#__PURE__*/React.createElement("img", {
    className: "pf-photo",
    src: displayPreview,
    alt: "Profile",
    onError: function () {
      setPhotoErr(true);
    }
  }) : /*#__PURE__*/React.createElement("div", {
    className: "pf-photo-initials",
    style: {
      background: user ? nsmsAvColor(user.full_name) : '#94A3B8'
    }
  }, user ? nsmsInitials(user.full_name) : '?'), /*#__PURE__*/React.createElement("button", {
    className: "pf-photo-btn",
    title: "Change photo",
    onClick: function () {
      fileRef.current && fileRef.current.click();
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF7",
    size: 18
  }))), /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    accept: "image/*",
    style: {
      display: 'none'
    },
    onChange: handleFileChange
  }), user && /*#__PURE__*/React.createElement("div", {
    className: "pf-role-badge"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDEE1\uFE0F",
    size: 18
  }), " ", user.role || 'Admin'), /*#__PURE__*/React.createElement("div", {
    className: "pf-photo-change-text"
  }, preview ? /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("button", {
    onClick: handleUploadPhoto,
    disabled: uploading,
    style: {
      color: '#10B981'
    }
  }, uploading ? 'Uploading…' : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 6,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 16
  }), " Save this photo")), ' · ', /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      setPreview(null);
      if (fileRef.current) fileRef.current.value = '';
    }
  }, "Cancel")) : /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      fileRef.current && fileRef.current.click();
    }
  }, "Click to change photo"), ' (JPG / PNG, max 3 MB)'))), /*#__PURE__*/React.createElement("div", {
    className: "pf-sep"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--text-mid)',
      textTransform: 'uppercase',
      letterSpacing: '.5px'
    }
  }, "Personal Information"), !editMode && /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      setEditMode(true);
      setAlert(null);
    },
    style: {
      border: 'none',
      background: 'var(--blue-light)',
      color: 'var(--blue)',
      padding: '5px 12px',
      borderRadius: 7,
      fontSize: 12,
      fontWeight: 700,
      cursor: 'pointer',
      fontFamily: 'var(--font)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  }), " Edit")), /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Full Name"), editMode ? /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    value: form.full_name,
    onChange: function (e) {
      setF('full_name', e.target.value);
    },
    placeholder: "Your full name"
  }) : /*#__PURE__*/React.createElement("div", {
    className: "pf-input-ro"
  }, user ? user.full_name : '—')), /*#__PURE__*/React.createElement("div", {
    className: "pf-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Email Address"), editMode ? /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    type: "email",
    value: form.email,
    onChange: function (e) {
      setF('email', e.target.value);
    },
    placeholder: "admin@school.com"
  }) : /*#__PURE__*/React.createElement("div", {
    className: "pf-input-ro"
  }, user ? user.email : '—')), /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Phone Number"), editMode ? /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    type: "tel",
    value: form.phone,
    onChange: function (e) {
      setF('phone', e.target.value);
    },
    placeholder: "+255 7xx xxx xxx"
  }) : /*#__PURE__*/React.createElement("div", {
    className: "pf-input-ro"
  }, user && user.phone ? user.phone : '—'))), /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Username"), /*#__PURE__*/React.createElement("div", {
    className: "pf-input-ro"
  }, user ? user.username || user.email || '—' : '—')), editMode && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "pf-sep"
  }), /*#__PURE__*/React.createElement("div", {
    className: "pf-pw-toggle",
    onClick: function () {
      setShowPw(function (v) {
        return !v;
      });
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: 'pf-pw-toggle-icon' + (showPw ? ' checked' : '')
  }, showPw ? /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 14
  }) : null), /*#__PURE__*/React.createElement("span", {
    className: "pf-pw-toggle-label"
  }, "Change password")), showPw && /*#__PURE__*/React.createElement("div", {
    className: "pf-pw-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Current Password"), /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    type: "password",
    value: pw.current,
    onChange: function (e) {
      setP('current', e.target.value);
    },
    placeholder: "Enter current password"
  })), /*#__PURE__*/React.createElement("div", {
    className: "pf-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "New Password"), /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    type: "password",
    value: pw.newPw,
    onChange: function (e) {
      setP('newPw', e.target.value);
    },
    placeholder: "Min. 6 characters"
  })), /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Confirm Password"), /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    type: "password",
    value: pw.confirm,
    onChange: function (e) {
      setP('confirm', e.target.value);
    },
    placeholder: "Repeat new password"
  }))))))), /*#__PURE__*/React.createElement("div", {
    className: "pf-footer"
  }, editMode ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("button", {
    className: "pf-btn-cancel",
    onClick: function () {
      setEditMode(false);
      setAlert(null);
      setShowPw(false);
      setPw({
        current: '',
        newPw: '',
        confirm: ''
      });
      if (profile) setForm({
        full_name: profile.full_name || '',
        email: profile.email || '',
        phone: profile.phone || ''
      });
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "pf-btn-save",
    onClick: handleSave,
    disabled: saving
  }, saving ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14,
      height: 14,
      border: '2px solid rgba(255,255,255,.4)',
      borderTopColor: 'white',
      borderRadius: '50%',
      animation: 'nsmspin .7s linear infinite',
      display: 'inline-block'
    }
  }), ' ', "Saving\u2026") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 6,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "save",
    size: 16
  }), " Save Changes"))) : /*#__PURE__*/React.createElement("button", {
    className: "pf-btn-cancel",
    onClick: onClose
  }, "Close"))));
}

/* ═══════════════════════════════════════════════════════════════
   LIVE DATE + CLOCK  (centre of navbar)
═══════════════════════════════════════════════════════════════ */
function NavClock() {
  var useState = React.useState;
  var useEffect = React.useEffect;
  var tickSt = useState(new Date());
  var now = tickSt[0];
  var setNow = tickSt[1];
  useEffect(function () {
    var timer = setInterval(function () {
      setNow(new Date());
    }, 1000);
    return function () {
      clearInterval(timer);
    };
  }, []);

  /* Ordinal suffix: 1st, 2nd, 3rd, 4th … */
  function ordinal(n) {
    var s = ['th', 'st', 'nd', 'rd'];
    var v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
  }
  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  var dateStr = ordinal(now.getDate()) + ' ' + MONTHS[now.getMonth()] + ' ' + now.getFullYear();
  var hh = String(now.getHours()).padStart(2, '0');
  var mm = String(now.getMinutes()).padStart(2, '0');
  var ss = String(now.getSeconds()).padStart(2, '0');
  var timeStr = hh + ':' + mm + ':' + ss;
  return /*#__PURE__*/React.createElement("div", {
    className: "nav-center"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-date-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-date-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "nav-date-text"
  }, dateStr)), /*#__PURE__*/React.createElement("div", {
    className: "nav-center-sep"
  }), /*#__PURE__*/React.createElement("div", {
    className: "nav-time-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-time-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD50",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "nav-time-text"
  }, timeStr)));
}

/* ── One-time keyframe injection for bell animation ── */
(function () {
  if (document.getElementById('nsms-bell-kf')) return;
  var s = document.createElement('style');
  s.id = 'nsms-bell-kf';
  s.textContent = ['@keyframes nsmsBellPulse {', '  0%   { transform: rotate(0deg)   scale(1);    }', '  15%  { transform: rotate(-18deg) scale(1.18); }', '  30%  { transform: rotate(14deg)  scale(1.18); }', '  45%  { transform: rotate(-10deg) scale(1.12); }', '  60%  { transform: rotate(8deg)   scale(1.08); }', '  75%  { transform: rotate(-4deg)  scale(1.04); }', '  100% { transform: rotate(0deg)   scale(1);    }', '}'].join('\n');
  document.head.appendChild(s);
})();

/* ── Admin bell sync constants (tune here) ── */
var NSMS_BELL_POLL_MS = 10000; /* badge + silent list refresh  — 10 s  */
var NSMS_REMINDER_MS = 300000; /* re-check for any new system events   — 5 min */

function NSMSBell() {
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useRef = React.useRef;

  /* ── state ── */
  var countsSt = useState({
    msgs: 0,
    alerts: 0
  });
  var counts = countsSt[0];
  var setCounts = countsSt[1];
  var openSt = useState(false);
  var open = openSt[0];
  var setOpen = openSt[1];
  var tabSt = useState('alerts');
  var activeTab = tabSt[0];
  var setActiveTab = tabSt[1];
  var alertsSt = useState([]);
  var alerts = alertsSt[0];
  var setAlerts = alertsSt[1];
  var alLoadSt = useState(false);
  var alLoading = alLoadSt[0];
  var setAlLoading = alLoadSt[1];
  var prevTotalRef = useRef(-1);
  var pulseSt = useState(false);
  var isPulsing = pulseSt[0];
  var setIsPulsing = pulseSt[1];
  var panelRef = useRef(null);
  /* Single pulse source: only prevTotalRef (in fetchCounts) drives the bell animation.
     prevAlertsRef removed — having two independent pulse trackers caused double-ring
     on every new alert (once via fetchCounts total, once via the old silentRefresh path). */

  /* ── helpers ── */
  function timeAgo(ts) {
    if (!ts) return '';
    var d = new Date(ts.replace(' ', 'T'));
    var diff = Math.floor((Date.now() - d.getTime()) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    return Math.floor(diff / 86400) + 'd ago';
  }
  function alertIcon(type) {
    var MAP = {
      class_assignment: 'school',
      subject_assignment: 'book',
      new_student: 'backpack',
      admin_message: 'mail',
      teacher_message: 'message',
      parent_message: 'family',
      fee_payment: 'dollar',
      payment: 'dollar',
      system: 'settings',
      announcement: 'megaphone',
      exam_reminder: 'edit',
      homework_deadline: 'pencil',
      attendance_issue: 'alert-triangle',
      info: 'megaphone',
      pulse_alert: 'bell'
    };
    var n = MAP[type] || 'megaphone';
    return typeof Icon === 'function' ? React.createElement(Icon, {
      name: n,
      size: 18
    }) : null;
  }
  function alertColors(type, unread) {
    if (!unread) return {
      bg: '#FAFBFC',
      border: '#F1F5F9',
      iconBg: '#F1F5F9'
    };
    var T = {
      class_assignment: {
        bg: '#EFF6FF',
        border: '#BFDBFE',
        iconBg: '#DBEAFE'
      },
      subject_assignment: {
        bg: '#F5F3FF',
        border: '#DDD6FE',
        iconBg: '#EDE9FE'
      },
      new_student: {
        bg: '#F0FDF4',
        border: '#BBF7D0',
        iconBg: '#DCFCE7'
      },
      fee_payment: {
        bg: '#F0FDF4',
        border: '#BBF7D0',
        iconBg: '#DCFCE7'
      },
      payment: {
        bg: '#F0FDF4',
        border: '#BBF7D0',
        iconBg: '#DCFCE7'
      },
      exam_reminder: {
        bg: '#FFF7ED',
        border: '#FED7AA',
        iconBg: '#FFEDD5'
      },
      homework_deadline: {
        bg: '#FFFBEB',
        border: '#FDE68A',
        iconBg: '#FEF3C7'
      },
      attendance_issue: {
        bg: '#FFF1F2',
        border: '#FECDD3',
        iconBg: '#FFE4E6'
      },
      announcement: {
        bg: '#F0F9FF',
        border: '#BAE6FD',
        iconBg: '#E0F2FE'
      },
      teacher_message: {
        bg: '#F0F9FF',
        border: '#BAE6FD',
        iconBg: '#E0F2FE'
      },
      parent_message: {
        bg: '#F5F3FF',
        border: '#DDD6FE',
        iconBg: '#EDE9FE'
      },
      pulse_alert: {
        bg: '#FFF7ED',
        border: '#FED7AA',
        iconBg: '#FFEDD5'
      }
    };
    return T[type] || {
      bg: '#FFFBEB',
      border: '#FDE68A',
      iconBg: '#FEF3C7'
    };
  }

  /* ── API ── */
  function fetchCounts() {
    fetch('/nsms/api/auth.php?action=notifications_count').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) return;
      var nm = d.data.messages || 0;
      var na = d.data.notifications || 0;
      var pp = d.data.pending_payments || 0;
      var tot = nm + na;
      if (tot > prevTotalRef.current && prevTotalRef.current !== -1) {
        setIsPulsing(true);
        setTimeout(function () {
          setIsPulsing(false);
        }, 820);
      }
      prevTotalRef.current = tot;
      setCounts({
        msgs: nm,
        alerts: na,
        pendingPayments: pp
      });
    }).catch(function () {});
  }

  /* Full fetch: shows shimmer, used on first open. */
  function fetchAlerts() {
    setAlLoading(true);
    fetch('/nsms/api/auth.php?action=notifications').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        var raw = d.data || [];
        setAlerts(raw);
        var unread = raw.filter(function (a) {
          return !a.is_read || a.is_read == 0;
        }).length;
        setCounts(function (c) {
          return Object.assign({}, c, {
            alerts: unread
          });
        });
        fetchCounts();
      }
    }).catch(function () {}).finally(function () {
      setAlLoading(false);
    });
  }

  /* Silent refresh: no shimmer — runs on fast tick (panel open or closed). */
  function silentRefresh() {
    fetch('/nsms/api/auth.php?action=notifications').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) return;
      var raw = d.data || [];
      setAlerts(raw);
      var unread = raw.filter(function (a) {
        return !a.is_read || a.is_read == 0;
      }).length;
      setCounts(function (c) {
        return Object.assign({}, c, {
          alerts: unread
        });
      });
    }).catch(function () {});
  }
  function markRead(id) {
    fetch('/nsms/api/auth.php?action=mark_notifications_read', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        id: id
      })
    }).then(function () {
      setAlerts(function (prev) {
        return prev.map(function (a) {
          return id === 0 || a.id === id ? Object.assign({}, a, {
            is_read: 1
          }) : a;
        });
      });
      setCounts(function (c) {
        var newAlerts = id === 0 ? 0 : Math.max(0, c.alerts - 1);
        return Object.assign({}, c, {
          alerts: newAlerts
        });
      });
    }).catch(function () {});
  }

  /* ── effects ── */
  useEffect(function () {
    prevTotalRef.current = -1;
    fetchCounts();
    silentRefresh(); // init alert badge from list on mount

    /* fastT — refresh message count + alert list every BELL_POLL_MS */
    var fastT = setInterval(function () {
      fetchCounts();
      silentRefresh();
    }, NSMS_BELL_POLL_MS);
    /* slowT — sync counts every 5 min */
    var slowT = setInterval(function () {
      fetchCounts();
    }, NSMS_REMINDER_MS);
    return function () {
      clearInterval(fastT);
      clearInterval(slowT);
    };
  }, []);
  useEffect(function () {
    if (!open) return;
    fetchAlerts();
    // Fast tick already runs silentRefresh every NSMS_BELL_POLL_MS,
    // so no extra interval needed here — just wire up outside-click close.
    var close = function (e) {
      if (panelRef.current && !panelRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', close);
    return function () {
      document.removeEventListener('mousedown', close);
    };
  }, [open]);
  var total = counts.msgs + counts.alerts;
  var badgeNum = total > 99 ? '99+' : total;

  /* ── render ── */
  return /*#__PURE__*/React.createElement("div", {
    ref: panelRef,
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      setOpen(function (o) {
        return !o;
      });
    },
    style: {
      position: 'relative',
      width: 40,
      height: 40,
      borderRadius: 9,
      border: 'none',
      background: open ? 'var(--blue-light)' : 'none',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 20,
      transition: 'background .15s',
      flexShrink: 0
    },
    title: "Notifications"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      transformOrigin: '50% 10%',
      animation: isPulsing ? 'nsmsBellPulse .82s ease' : 'none'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  })), total > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      right: 3,
      minWidth: 16,
      height: 16,
      borderRadius: 8,
      background: '#EF4444',
      color: 'white',
      fontSize: 9,
      fontWeight: 800,
      lineHeight: '16px',
      textAlign: 'center',
      padding: '0 3px',
      border: '1.5px solid white',
      fontFamily: 'var(--font)'
    }
  }, badgeNum)), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(var(--nav-h) + 4px)',
      right: 0,
      background: 'white',
      border: '1px solid var(--border)',
      borderRadius: 14,
      boxShadow: '0 12px 40px rgba(0,0,0,.15)',
      width: 330,
      overflow: 'hidden',
      zIndex: 1100,
      animation: 'navDrop .18s ease'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'linear-gradient(135deg,#2563EB,#1E40AF)',
      padding: '14px 16px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'white'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  }), " Notifications"), total > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'rgba(255,255,255,.22)',
      color: 'white',
      fontSize: 11,
      fontWeight: 700,
      padding: '2px 8px',
      borderRadius: 20
    }
  }, total, " unread")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4
    }
  }, [{
    id: 'messages',
    label: 'Messages',
    badge: counts.msgs
  }, {
    id: 'alerts',
    label: 'Alerts',
    badge: counts.alerts
  }].map(function (tab) {
    var isActive = activeTab === tab.id;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.id,
      onClick: function () {
        setActiveTab(tab.id);
      },
      style: {
        flex: 1,
        padding: '8px 6px',
        borderRadius: '8px 8px 0 0',
        border: 'none',
        cursor: 'pointer',
        fontSize: 12.5,
        fontWeight: 700,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 5,
        background: isActive ? 'white' : 'rgba(255,255,255,.16)',
        color: isActive ? '#1E40AF' : 'rgba(255,255,255,.88)',
        transition: 'all .15s',
        fontFamily: 'var(--font)'
      }
    }, tab.label, tab.badge > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        background: isActive ? '#EF4444' : 'rgba(255,255,255,.28)',
        color: 'white',
        fontSize: 10,
        fontWeight: 800,
        padding: '1px 5px',
        borderRadius: 10,
        minWidth: 16,
        textAlign: 'center'
      }
    }, tab.badge));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 360,
      overflowY: 'auto'
    }
  }, activeTab === 'messages' && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 10px'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/admin/admin-pulse.html",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '13px 14px',
      borderRadius: 11,
      background: counts.msgs > 0 ? '#F0F9FF' : '#FAFBFC',
      border: counts.msgs > 0 ? '1.5px solid #BFDBFE' : '1.5px solid #F1F5F9',
      color: 'var(--text-mid)',
      textDecoration: 'none',
      transition: 'background .15s'
    },
    onMouseOver: function (e) {
      e.currentTarget.style.background = '#EFF6FF';
    },
    onMouseOut: function (e) {
      e.currentTarget.style.background = counts.msgs > 0 ? '#F0F9FF' : '#FAFBFC';
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCAC",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      fontWeight: 700,
      color: 'var(--text-dark)'
    }
  }, "Messages"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, counts.msgs > 0 ? counts.msgs + ' unread message' + (counts.msgs > 1 ? 's' : '') : 'No unread messages')), counts.msgs > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      background: '#2563EB',
      color: 'white',
      fontSize: 12,
      fontWeight: 800,
      padding: '3px 10px',
      borderRadius: 20
    }
  }, counts.msgs)), counts.msgs === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '18px 0 10px',
      color: 'var(--text-muted)',
      fontSize: 12.5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 26,
      marginBottom: 5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), "All messages read")), activeTab === 'alerts' && /*#__PURE__*/React.createElement("div", null, alLoading ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 12px',
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        height: 60,
        borderRadius: 10,
        background: 'linear-gradient(90deg,#F1F5F9 25%,#E9EEF3 50%,#F1F5F9 75%)',
        backgroundSize: '200% 100%',
        animation: 'shim 1.4s infinite'
      }
    });
  })) : alerts.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '32px 0',
      color: 'var(--text-muted)',
      fontSize: 12.5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 28,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCED",
    size: 18
  })), "No system alerts") : /*#__PURE__*/React.createElement(React.Fragment, null, counts.alerts > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      padding: '8px 14px 2px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      markRead(0);
    },
    style: {
      border: 'none',
      background: 'none',
      color: 'var(--blue)',
      fontSize: 11.5,
      fontWeight: 700,
      cursor: 'pointer',
      fontFamily: 'var(--font)',
      padding: '2px 6px',
      borderRadius: 5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " Mark all read")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 10px 10px'
    }
  }, alerts.map(function (al) {
    var unread = !al.is_read || al.is_read == 0;
    var clr = alertColors(al.type, unread);
    return /*#__PURE__*/React.createElement("div", {
      key: al.id,
      style: {
        display: 'flex',
        gap: 10,
        padding: '11px 12px',
        borderRadius: 11,
        marginBottom: 7,
        background: clr.bg,
        border: '1.5px solid ' + clr.border,
        transition: 'background .15s, border-color .15s'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 34,
        height: 34,
        borderRadius: 9,
        flexShrink: 0,
        background: clr.iconBg,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 17
      }
    }, alertIcon(al.type)), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: unread ? 700 : 600,
        color: 'var(--text-dark)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, al.title || 'System Alert'), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-soft)',
        marginTop: 2,
        lineHeight: 1.4,
        display: '-webkit-box',
        WebkitLineClamp: 2,
        WebkitBoxOrient: 'vertical',
        overflow: 'hidden'
      }
    }, al.message), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10.5,
        color: 'var(--text-muted)',
        marginTop: 5
      }
    }, timeAgo(al.created_at))), unread && /*#__PURE__*/React.createElement("button", {
      onClick: function () {
        markRead(al.id);
      },
      title: "Mark as read",
      style: {
        border: 'none',
        background: 'none',
        cursor: 'pointer',
        padding: '2px 4px',
        color: '#94A3B8',
        fontSize: 14,
        alignSelf: 'flex-start',
        flexShrink: 0,
        fontFamily: 'var(--font)',
        lineHeight: 1
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2715",
      size: 18
    })));
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border)',
      padding: '8px 10px',
      background: '#FAFBFC'
    }
  }, activeTab === 'messages' ? /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/admin/admin-pulse.html",
    style: {
      display: 'block',
      textAlign: 'center',
      padding: '8px',
      borderRadius: 7,
      color: 'var(--blue)',
      fontSize: 12,
      fontWeight: 700,
      textDecoration: 'none',
      transition: 'background .15s'
    },
    onMouseOver: function (e) {
      e.currentTarget.style.background = 'var(--blue-light)';
    },
    onMouseOut: function (e) {
      e.currentTarget.style.background = 'none';
    }
  }, "Open J11 Pulse \u2192") : counts.alerts > 0 ? /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      markRead(0);
    },
    style: {
      display: 'block',
      width: '100%',
      textAlign: 'center',
      padding: '8px',
      borderRadius: 7,
      border: 'none',
      background: 'none',
      color: 'var(--blue)',
      fontSize: 12,
      fontWeight: 700,
      cursor: 'pointer',
      transition: 'background .15s',
      fontFamily: 'var(--font)'
    },
    onMouseOver: function (e) {
      e.currentTarget.style.background = 'var(--blue-light)';
    },
    onMouseOut: function (e) {
      e.currentTarget.style.background = 'none';
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " Mark all alerts as read") : /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '6px 0',
      color: 'var(--text-muted)',
      fontSize: 12,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " All caught up"))));
}

/* ═══════════════════════════════════════════════════════════════
   NAVBAR
   Layout:  [toggle] [brand] | [links — left] [clock — center] [admin — right]
═══════════════════════════════════════════════════════════════ */
function NSMSNavbar(props) {
  var activePage = props.activePage;
  var onLogout = props.onLogout;
  var sidebarOpen = props.sidebarOpen;
  var setSidebarOpen = props.setSidebarOpen;
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useRef = React.useRef;
  var infoSt = useState(null);
  var info = infoSt[0];
  var setInfo = infoSt[1];
  var loadSt = useState(true);
  var loading = loadSt[0];
  var setLoading = loadSt[1];
  var ddSt = useState(false);
  var ddOpen = ddSt[0];
  var setDdOpen = ddSt[1];
  var errSt = useState(false);
  var imgErr = errSt[0];
  var setImgErr = errSt[1];
  var pfSt = useState(false);
  var pfOpen = pfSt[0];
  var setPfOpen = pfSt[1];
  var logoSt = useState('');
  var logoUrl = logoSt[0];
  var setLogoUrl = logoSt[1];
  var ddRef = useRef(null);
  useEffect(function () {
    fetch('/nsms/api/navbar.php').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setInfo(d.data);
    }).catch(function () {}).finally(function () {
      setLoading(false);
    });
  }, []);

  /* Fetch logo from settings.php (same source as the public landing page) */
  useEffect(function () {
    _nsmsLoadLogo(function (url) {
      setLogoUrl(url);
    });
  }, []);
  useEffect(function () {
    if (!ddOpen) return;
    var close = function (e) {
      if (ddRef.current && !ddRef.current.contains(e.target)) setDdOpen(false);
    };
    document.addEventListener('mousedown', close);
    return function () {
      document.removeEventListener('mousedown', close);
    };
  }, [ddOpen]);
  var go = function (href) {
    window.location.href = href;
  };
  var user = info ? info.user : null;
  var hasPhoto = user && user.photo_url && !imgErr;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("nav", {
    className: "nsms-nav"
  }, /*#__PURE__*/React.createElement("button", {
    className: "nav-toggle",
    onClick: function () {
      setSidebarOpen(function (o) {
        return !o;
      });
    },
    title: "Toggle sidebar"
  }, sidebarOpen ? /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 18
  }) : /*#__PURE__*/React.createElement(Icon, {
    name: "menu",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "nav-brand"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-logo"
  }, /*#__PURE__*/React.createElement(SchoolLogoMark, {
    logoUrl: logoUrl || info && info.logo_url || ''
  })), /*#__PURE__*/React.createElement("div", {
    className: "nav-school-name"
  }, loading ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nav-shimmer",
    style: {
      height: 13,
      width: 120,
      marginBottom: 4
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "nav-shimmer",
    style: {
      height: 9,
      width: 72
    }
  })) : /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nav-school-title"
  }, info ? info.school_name : 'Nursery School'), /*#__PURE__*/React.createElement("div", {
    className: "nav-school-sub"
  }, "Admin Panel")))), /*#__PURE__*/React.createElement("div", {
    className: "nav-links"
  }, NSMS_NAV_LINKS.map(function (item) {
    return /*#__PURE__*/React.createElement("button", {
      key: item.key,
      className: 'nav-link' + (activePage === item.key ? ' active' : ''),
      onClick: function () {
        go(item.href);
      }
    }, item.label);
  })), /*#__PURE__*/React.createElement(NavClock, null), /*#__PURE__*/React.createElement("div", {
    className: "nav-right",
    style: {
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(NSMSBell, null), /*#__PURE__*/React.createElement("div", {
    className: "nav-divider"
  }), /*#__PURE__*/React.createElement("div", {
    ref: ddRef,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: 'nav-user-btn' + (ddOpen ? ' open' : ''),
    onClick: function () {
      setDdOpen(function (o) {
        return !o;
      });
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-avatar",
    style: {
      background: user ? nsmsAvColor(user.full_name) : '#E2E8F0'
    }
  }, hasPhoto ? /*#__PURE__*/React.createElement("img", {
    src: user.photo_url,
    alt: "",
    onError: function () {
      setImgErr(true);
    }
  }) : user ? nsmsInitials(user.full_name) : '?'), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nav-user-name"
  }, loading ? '…' : user ? user.full_name.split(' ')[0] : 'Admin'), /*#__PURE__*/React.createElement("div", {
    className: "nav-user-role"
  }, user ? user.role : 'admin')), /*#__PURE__*/React.createElement("span", {
    className: "nav-chevron"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u25BE",
    size: 18
  }))), ddOpen && /*#__PURE__*/React.createElement("div", {
    className: "nav-dd"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-av",
    style: {
      background: user ? nsmsAvColor(user.full_name) : 'rgba(255,255,255,.2)'
    }
  }, hasPhoto ? /*#__PURE__*/React.createElement("img", {
    src: user.photo_url,
    alt: ""
  }) : user ? nsmsInitials(user.full_name) : '?'), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-name"
  }, user ? user.full_name : 'Administrator'), /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-email"
  }, user ? user.email : ''), /*#__PURE__*/React.createElement("span", {
    className: "nav-dd-role"
  }, user ? user.role : 'admin'))), /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-body"
  }, /*#__PURE__*/React.createElement("button", {
    className: "nav-dd-item",
    onClick: function () {
      setDdOpen(false);
      go('/nsms/public/admin/admin-pulse.html');
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nav-dd-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  })), ' ', "J11 Pulse"), /*#__PURE__*/React.createElement("button", {
    className: "nav-dd-item",
    onClick: function () {
      setDdOpen(false);
      go('/nsms/public/admin/settings.html');
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nav-dd-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2699\uFE0F",
    size: 18
  })), ' ', "Settings"), /*#__PURE__*/React.createElement("button", {
    className: "nav-dd-item",
    onClick: function () {
      setDdOpen(false);
      setPfOpen(true);
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nav-dd-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC64",
    size: 18
  })), ' ', "My Profile"), /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-sep"
  }), /*#__PURE__*/React.createElement("button", {
    className: "nav-dd-item danger",
    onClick: function () {
      setDdOpen(false);
      if (onLogout) onLogout();
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nav-dd-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "logout",
    size: 18
  })), ' ', "Sign Out")))))), /*#__PURE__*/React.createElement(NSMSProfileModal, {
    open: pfOpen,
    onClose: function () {
      setPfOpen(false);
    }
  }));
}

/* ═══════════════════════════════════════════════════════════════
   SIDEBAR
   • Collapsed by default (pass sidebarOpen=false from each page)
   • Hover → temporarily expands; mouse-leave → collapses after 180 ms
   • ☰ / ✕ toggle in navbar → pins expanded / unpin (sidebarOpen prop)
═══════════════════════════════════════════════════════════════ */
function NSMSSidebar(props) {
  var activePage = props.activePage;
  var sidebarOpen = props.sidebarOpen; /* true = pinned open by toggle */
  var pendingPayments = props.pendingPayments || 0; /* badge count from bell */
  var go = function (href) {
    window.location.href = href;
  };
  var useState = React.useState;
  var useRef = React.useRef;
  var hoverSt = useState(false);
  var isHovered = hoverSt[0];
  var setIsHovered = hoverSt[1];
  var leaveTimer = useRef(null);
  function handleEnter() {
    if (leaveTimer.current) {
      clearTimeout(leaveTimer.current);
      leaveTimer.current = null;
    }
    setIsHovered(true);
  }
  function handleLeave() {
    leaveTimer.current = setTimeout(function () {
      setIsHovered(false);
    }, 180);
  }
  var isExpanded = sidebarOpen || isHovered;
  return /*#__PURE__*/React.createElement("aside", {
    className: 'nsms-sidebar' + (isExpanded ? '' : ' collapsed'),
    onMouseEnter: handleEnter,
    onMouseLeave: handleLeave
  }, NSMS_SIDEBAR_ITEMS.map(function (item) {
    var hasBadge = item.key === 'payment_verification' && pendingPayments > 0;
    return /*#__PURE__*/React.createElement("button", {
      key: item.key,
      className: 'sb-item' + (activePage === item.key ? ' active' : ''),
      "data-tip": item.label,
      onClick: function () {
        go(item.href);
      },
      style: {
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "sb-icon"
    }, item.icon), /*#__PURE__*/React.createElement("span", {
      className: "sb-label"
    }, item.label), hasBadge && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: '6px',
        right: '8px',
        minWidth: '17px',
        height: '17px',
        borderRadius: '9px',
        background: '#EF4444',
        color: 'white',
        fontSize: '10px',
        fontWeight: '800',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 4px',
        lineHeight: '17px',
        boxShadow: '0 1px 4px rgba(239,68,68,.4)'
      }
    }, pendingPayments > 99 ? '99+' : pendingPayments));
  }), /*#__PURE__*/React.createElement("div", {
    className: "sb-spacer"
  }));
}