(function(){if(document.getElementById('nsms-offline-dash-css'))return;var s=document.createElement('style');s.id='nsms-offline-dash-css';s.textContent='.offline-banner{background:linear-gradient(135deg,#EFF6FF,#F0FDF4);border:1px solid #93C5FD;border-left:4px solid #2563EB;border-radius:12px;padding:14px 16px;margin-bottom:16px;color:#1E3A5F}.offline-banner-title{display:flex;align-items:center;gap:8px;font-weight:800;font-size:13.5px;margin-bottom:4px;color:#1D4ED8}.offline-dot{width:8px;height:8px;border-radius:50%;background:#F59E0B;box-shadow:0 0 0 3px rgba(245,158,11,.25);flex-shrink:0}.offline-banner-text{margin:0;font-size:12.5px;line-height:1.5;color:#334155;font-weight:500}.err-banner{background:#FEF2F2;border:1px solid #FECACA;border-left:4px solid #EF4444;border-radius:12px;padding:12px 14px;margin-bottom:12px;color:#991B1B;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px}';(document.head||document.documentElement).appendChild(s);})();

const {
  useState,
  useEffect,
  useRef,
  useCallback
} = React;

/* ─────────────────────────────────────────────────────
   FEE HELPERS (unchanged logic from original)
───────────────────────────────────────────────────── */
function computeFeePct(item) {
  if (item.collection_rate != null) {
    const r = Number(item.collection_rate);
    return Math.min(100, Math.max(0, Math.round(r <= 1 ? r * 100 : r)));
  }
  const collected = Number(item.collected_amount ?? item.collected_fees ?? item.collected ?? 0);
  const total = Number(item.expected_amount ?? item.total_amount ?? item.total_fees ?? item.total ?? 0);
  if (total > 0) return Math.min(100, Math.max(0, Math.round(collected / total * 100)));
  return 0;
}
function fmtMoney(v) {
  v = Number(v);
  if (isNaN(v) || v === 0) return '—';
  if (v >= 1_000_000) return `TSh ${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `TSh ${(v / 1_000).toFixed(0)}K`;
  return `TSh ${v.toLocaleString()}`;
}
function formatTime(timestamp) {
  if (!timestamp) return '—';
  const normalized = /^\d{4}-\d{2}-\d{2}$/.test(timestamp) ? timestamp + ' 00:00:00' : timestamp;
  const date = new Date(normalized.replace(' ', 'T'));
  if (isNaN(date.getTime())) return timestamp;
  const now = new Date();
  const diffMins = Math.floor((now - date) / 60000);
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffMins < 1440) {
    const h = Math.floor(diffMins / 60);
    return `${h}h ago`;
  }
  const d = Math.floor(diffMins / 1440);
  if (d < 7) return `${d}d ago`;
  return date.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short'
  });
}

/* ─────────────────────────────────────────────────────
   MINI SVG RING for fee rate
───────────────────────────────────────────────────── */
function FeeRing({
  pct
}) {
  const r = 22,
    circ = 2 * Math.PI * r;
  const dash = circ - pct / 100 * circ;
  const color = pct >= 75 ? '#10B981' : pct >= 40 ? '#F59E0B' : '#EF4444';
  const bg = pct >= 75 ? '#DCFCE7' : pct >= 40 ? '#FEF3C7' : '#FEE2E2';
  return /*#__PURE__*/React.createElement("div", {
    className: "fee-ring-wrap"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "56",
    height: "56",
    viewBox: "0 0 56 56"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "28",
    cy: "28",
    r: r,
    fill: "none",
    stroke: bg,
    strokeWidth: "5"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "28",
    cy: "28",
    r: r,
    fill: "none",
    stroke: color,
    strokeWidth: "5",
    strokeLinecap: "round",
    strokeDasharray: circ,
    strokeDashoffset: dash,
    style: {
      transform: 'rotate(-90deg)',
      transformOrigin: '28px 28px',
      transition: 'stroke-dashoffset .8s ease'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "fee-ring-pct",
    style: {
      color
    }
  }, pct, "%"));
}

/* ─────────────────────────────────────────────────────
   MAIN DASHBOARD
───────────────────────────────────────────────────── */
function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [finance, setFinance] = useState(null); // finance.php overview
  const [activity, setActivity] = useState([]);
  const [feeByClass, setFeeByClass] = useState([]);
  const [trends, setTrends] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [errors, setErrors] = useState([]);
  const [offlineMode, setOfflineMode] = useState(false);
  const [offlineNote, setOfflineNote] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  const today = new Date().toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
  const loadData = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);else setLoading(true);
    const errs = [];
    try {
      /* ── Fetch all 5 endpoints in parallel ──
         Key fix: finance.php?action=overview is the authoritative fee
         source. analytics.php overview is kept for student/teacher/
         attendance stats, but fee_collection_rate comes from finance.php
         which uses the same buildPaymentStatus() logic as the Finance page. */
      const [analyticsRes, financeRes, activityRes, feeClassRes, trendsRes] = await Promise.allSettled([fetch('/nsms/api/analytics.php?action=overview',{signal:AbortSignal.timeout?AbortSignal.timeout(8000):undefined}), fetch('/nsms/api/finance.php?action=overview',{signal:AbortSignal.timeout?AbortSignal.timeout(8000):undefined}), fetch('/nsms/api/analytics.php?action=recent_activity',{signal:AbortSignal.timeout?AbortSignal.timeout(8000):undefined}), fetch('/nsms/api/finance.php?action=fee_by_class',{signal:AbortSignal.timeout?AbortSignal.timeout(8000):undefined}), fetch('/nsms/api/analytics.php?action=enrollment_trends',{signal:AbortSignal.timeout?AbortSignal.timeout(8000):undefined})]);
      const safeJson = async settled => {
        if (settled.status === 'rejected') return null;
        try {
          return await settled.value.json();
        } catch {
          return null;
        }
      };
      const [analyticsData, financeData, activityData, feeClassData, trendsData] = await Promise.all([analyticsRes, financeRes, activityRes, feeClassRes, trendsRes].map(safeJson));
      let offline = false;
      if (analyticsData?.success) {
        setStats(analyticsData.data);
        if (analyticsData.data && analyticsData.data.offline_mode) offline = true;
      } else if (analyticsData?.error) {
        errs.push('School statistics could not be loaded.');
      }
      if (financeData?.success) {
        setFinance(financeData.data);
        if (financeData.data && financeData.data.offline_mode) offline = true;
      } else if (financeData?.error && !offline) {
        errs.push('Financial overview could not be loaded.');
      }
      setOfflineMode(offline);
      setOfflineNote(offline
        ? 'You are working offline. Numbers below come from the local cache on this device. Student and teacher counts are available here; full payment ledgers update when the server is back. Any offline changes will sync automatically.'
        : '');
      if (activityData?.success) setActivity(activityData.data ?? []);
      if (feeClassData?.success) setFeeByClass(feeClassData.data ?? []);
      if (trendsData?.success) setTrends(trendsData.data ?? []);
    } catch (err) {
      errs.push('Network error: ' + err.message);
    } finally {
      setErrors(errs);
      setLoading(false);
      setRefreshing(false);
    }
  }, []);
  useEffect(() => {
    loadData();
  }, [loadData]);
  const handleLogout = async () => {
    try {
      await fetch('/nsms/api/auth.php?action=logout', {
        method: 'POST'
      });
    } catch {}
    window.location.href = '/nsms/public/index.html';
  };

  /* ── Single source of truth: analytics overview (same online + offline) ── */
  const feeRate = (() => {
    if (stats?.fee_collection_rate != null && stats.fee_collection_rate !== '') {
      const r = Number(stats.fee_collection_rate);
      if (!isNaN(r)) return Math.min(100, Math.max(0, Math.round(r <= 1 ? r * 100 : r)));
    }
    if (feeByClass.length > 0) {
      let totalDue = 0,
        totalPaid = 0;
      feeByClass.forEach(cls => {
        totalDue += Number(cls.expected_amount ?? cls.total_amount ?? 0);
        totalPaid += Number(cls.collected_amount ?? cls.total_paid ?? 0);
      });
      if (totalDue > 0) return Math.min(100, Math.round(totalPaid / totalDue * 100));
    }
    return null;
  })();
  const collectedAmount = (() => {
    if (stats?.collected_amount != null && Number(stats.collected_amount) > 0) {
      return Number(stats.collected_amount);
    }
    if (feeByClass.length > 0) {
      return feeByClass.reduce((s, c) => s + Number(c.collected_amount ?? c.total_paid ?? 0), 0);
    }
    return finance?.total_revenue ?? null;
  })();
  const expectedAmount = (() => {
    if (stats?.expected_revenue != null && Number(stats.expected_revenue) > 0) {
      return Number(stats.expected_revenue);
    }
    if (feeByClass.length > 0) {
      return feeByClass.reduce((s, c) => s + Number(c.expected_amount ?? c.total_amount ?? 0), 0);
    }
    return null;
  })();

  /* ────────── SKELETONS ────────── */
  if (loading) {
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NSMSNavbar, {
      activePage: "dashboard",
      onLogout: handleLogout,
      sidebarOpen: sidebarOpen,
      setSidebarOpen: setSidebarOpen
    }), /*#__PURE__*/React.createElement(NSMSSidebar, {
      activePage: "dashboard",
      sidebarOpen: sidebarOpen
    }), /*#__PURE__*/React.createElement("main", {
      className: "nsms-main",
      style: {
        marginLeft: sidebarOpen ? '220px' : '64px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "page-header"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sk-line",
      style: {
        width: 220,
        height: 26,
        marginBottom: 8
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sk-line",
      style: {
        width: 160,
        height: 13
      }
    }))), /*#__PURE__*/React.createElement("div", {
      className: "stats-grid"
    }, ['blue', 'green', 'purple', 'orange'].map(c => /*#__PURE__*/React.createElement("div", {
      key: c,
      className: "sk-card",
      style: {
        borderLeft: `4px solid #E2E8F0`
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sk-line",
      style: {
        width: 38,
        height: 38,
        borderRadius: 9,
        marginBottom: 0
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sk-line",
      style: {
        width: 50,
        height: 20,
        borderRadius: 20,
        marginBottom: 0
      }
    })), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sk-line",
      style: {
        width: '55%',
        height: 26,
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sk-line",
      style: {
        width: '70%',
        height: 13,
        marginBottom: 5
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sk-line",
      style: {
        width: '45%',
        height: 11
      }
    })))), /*#__PURE__*/React.createElement("div", {
      className: "section-grid"
    }, [1, 2].map(i => /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "sk-card"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        marginBottom: 18,
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sk-line",
      style: {
        width: 26,
        height: 26,
        borderRadius: 6,
        marginBottom: 0
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sk-line",
      style: {
        width: 140,
        height: 14,
        marginBottom: 0
      }
    })), [1, 2, 3, 4].map(j => /*#__PURE__*/React.createElement("div", {
      key: j,
      className: "shimmer sk-line",
      style: {
        height: 30,
        marginBottom: 14
      }
    })))))));
  }

  /* ────────── MAIN RENDER ────────── */
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NSMSNavbar, {
    activePage: "dashboard",
    onLogout: handleLogout,
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement(NSMSSidebar, {
    activePage: "dashboard",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("main", {
    className: "nsms-main",
    style: {
      marginLeft: sidebarOpen ? '220px' : '64px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    className: "page-title"
  }, "Admin Dashboard"), /*#__PURE__*/React.createElement("p", {
    className: "page-subtitle"
  }, "School Overview & Analytics")), /*#__PURE__*/React.createElement("div", {
    className: "page-header-right"
  }, /*#__PURE__*/React.createElement("span", {
    className: "date-badge"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  }), " ", today), /*#__PURE__*/React.createElement("button", {
    className: `refresh-btn${refreshing ? ' spinning' : ''}`,
    onClick: () => loadData(true),
    disabled: refreshing
  }, /*#__PURE__*/React.createElement("span", null, "\u27F3"), refreshing ? 'Refreshing…' : 'Refresh'))), (offlineMode ? /*#__PURE__*/React.createElement("div", {
    className: "offline-banner",
    role: "status"
  }, /*#__PURE__*/React.createElement("div", {
    className: "offline-banner-title"
  }, /*#__PURE__*/React.createElement("span", {
    className: "offline-dot",
    "aria-hidden": true
  }), " Offline mode — using data on this device"), /*#__PURE__*/React.createElement("p", {
    className: "offline-banner-text"
  }, offlineNote)) : null), errors.map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "err-banner"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", e)), /*#__PURE__*/React.createElement("div", {
    className: "stats-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-card blue"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), stats?.students_this_month != null && /*#__PURE__*/React.createElement("span", {
    className: "stat-trend up"
  }, "\u2191 ", stats.students_this_month, " new")), /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, stats?.total_students ?? '—'), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Total Students"), /*#__PURE__*/React.createElement("div", {
    className: "stat-subtitle"
  }, "Active enrolments")), /*#__PURE__*/React.createElement("div", {
    className: "stat-card green"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC68\u200D\uD83C\uDFEB",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "stat-trend flat"
  }, "All active")), /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, stats?.total_teachers ?? '—'), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Teachers"), /*#__PURE__*/React.createElement("div", {
    className: "stat-subtitle"
  }, "Active staff members")), /*#__PURE__*/React.createElement("div", {
    className: "stat-card purple"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), stats?.avg_attendance != null && /*#__PURE__*/React.createElement("span", {
    className: `stat-trend ${Number(stats.avg_attendance) >= 75 ? 'up' : 'down'}`
  }, Number(stats.avg_attendance) >= 75 ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 16
  }), "Good") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0",
    size: 16
  }), "Low"))), /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, stats?.avg_attendance ?? '—', "%"), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Avg Attendance"), /*#__PURE__*/React.createElement("div", {
    className: "stat-subtitle"
  }, "Last 30 days")), /*#__PURE__*/React.createElement("div", {
    className: "stat-card orange"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB0",
    size: 18
  })), feeRate != null && /*#__PURE__*/React.createElement("span", {
    className: `stat-trend ${feeRate >= 75 ? 'up' : feeRate >= 40 ? 'flat' : 'down'}`
  }, feeRate >= 75 ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 16
  }), "On track") : feeRate >= 40 ? '~ Partial' : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0",
    size: 16
  }), "Low"))), /*#__PURE__*/React.createElement("div", {
    className: "fee-rate-inner"
  }, feeRate != null ? /*#__PURE__*/React.createElement(FeeRing, {
    pct: feeRate
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 28,
      fontWeight: 800,
      color: '#D97706'
    }
  }, "\u2014"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Fee Collection Rate"), /*#__PURE__*/React.createElement("div", {
    className: "stat-subtitle",
    style: {
      marginTop: 3
    }
  }, collectedAmount != null ? fmtMoney(collectedAmount) + ' collected' : 'Academic year'), expectedAmount != null && /*#__PURE__*/React.createElement("div", {
    className: "stat-subtitle"
  }, "of ", fmtMoney(expectedAmount), " expected"))))), /*#__PURE__*/React.createElement("div", {
    className: "section-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-header-left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "section-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC8",
    size: 18
  })), /*#__PURE__*/React.createElement("h2", {
    className: "section-title"
  }, "Enrollment Trends")), trends.length > 0 && /*#__PURE__*/React.createElement("span", {
    className: "section-badge"
  }, "Last ", trends.length, " months")), trends.length > 0 ? (() => {
    const maxCount = Math.max(...trends.map(t => Number(t.count)), 1);
    const vbW = 500,
      chartH = 140,
      padL = 8,
      padR = 8,
      padT = 20;
    const n = trends.length;
    const slot = (vbW - padL - padR) / n;
    const barW = Math.min(slot * 0.48, 38);
    return /*#__PURE__*/React.createElement("div", {
      className: "chart-wrap"
    }, /*#__PURE__*/React.createElement("svg", {
      width: "100%",
      viewBox: `0 0 ${vbW} ${chartH + padT + 36}`,
      preserveAspectRatio: "xMidYMid meet"
    }, [0.25, 0.5, 0.75, 1].map(f => /*#__PURE__*/React.createElement("line", {
      key: f,
      x1: padL,
      y1: padT + chartH * (1 - f),
      x2: vbW - padR,
      y2: padT + chartH * (1 - f),
      stroke: "#F1F5F9",
      strokeWidth: "1"
    })), trends.map((t, i) => {
      const count = Number(t.count);
      const barH = Math.max(count / maxCount * chartH, 4);
      const cx = padL + slot * i + slot / 2;
      const x = cx - barW / 2;
      const y = padT + chartH - barH;
      const isMax = count === maxCount;
      return /*#__PURE__*/React.createElement("g", {
        key: i
      }, /*#__PURE__*/React.createElement("rect", {
        x: x,
        y: y,
        width: barW,
        height: barH,
        rx: "4",
        fill: isMax ? '#1D4ED8' : '#3B82F6',
        opacity: isMax ? 1 : .7
      }), count > 0 && /*#__PURE__*/React.createElement("text", {
        x: cx,
        y: y - 5,
        textAnchor: "middle",
        fontSize: "11",
        fill: "#1E293B",
        fontWeight: "700"
      }, count), /*#__PURE__*/React.createElement("text", {
        x: cx,
        y: padT + chartH + 16,
        textAnchor: "middle",
        fontSize: "11",
        fill: "#94A3B8"
      }, t.month_name));
    })));
  })() : /*#__PURE__*/React.createElement("div", {
    className: "empty-state"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty-state-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  })), "No enrollment data for the last 6 months")), /*#__PURE__*/React.createElement("div", {
    className: "section-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-header-left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "section-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB0",
    size: 18
  })), /*#__PURE__*/React.createElement("h2", {
    className: "section-title"
  }, "Fee Collection by Class")), feeByClass.length > 0 && /*#__PURE__*/React.createElement("span", {
    className: "section-badge"
  }, feeByClass.length, " classes")), feeByClass.length > 0 ? feeByClass.map((cls, i) => {
    const pct = computeFeePct(cls);
    const tier = pct >= 75 ? 'high' : pct >= 40 ? 'mid' : 'low';
    const collected = Number(cls.collected_amount ?? cls.total_paid ?? 0);
    const expected = Number(cls.expected_amount ?? cls.total_amount ?? 0);
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "fee-class-item"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "fee-class-name"
    }, cls.name), expected > 0 && /*#__PURE__*/React.createElement("div", {
      className: "fee-class-amount"
    }, fmtMoney(collected), " / ", fmtMoney(expected))), /*#__PURE__*/React.createElement("div", {
      className: "fee-bar-wrap"
    }, /*#__PURE__*/React.createElement("div", {
      className: "fee-progress-bar"
    }, /*#__PURE__*/React.createElement("div", {
      className: `fee-progress-fill ${tier}`,
      style: {
        width: `${pct}%`
      }
    }))), /*#__PURE__*/React.createElement("div", {
      className: `fee-percentage ${tier}`
    }, pct, "%"));
  }) : /*#__PURE__*/React.createElement("div", {
    className: "empty-state"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty-state-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  })), "No fee data available"))), /*#__PURE__*/React.createElement("div", {
    className: "lower-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "activity-card",
    style: {
      marginBottom: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-header-left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "section-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD50",
    size: 18
  })), /*#__PURE__*/React.createElement("h2", {
    className: "section-title"
  }, "Recent Activity"))), /*#__PURE__*/React.createElement("div", {
    className: "activity-list"
  }, activity.length > 0 ? activity.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "activity-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: `activity-icon ${item.type || 'enrollment'}`
  }, renderIcon(item.icon, 20)), /*#__PURE__*/React.createElement("div", {
    className: "activity-content"
  }, /*#__PURE__*/React.createElement("div", {
    className: "activity-title"
  }, item.title), /*#__PURE__*/React.createElement("div", {
    className: "activity-desc"
  }, item.description)), /*#__PURE__*/React.createElement("div", {
    className: "activity-time"
  }, formatTime(item.timestamp)))) : /*#__PURE__*/React.createElement("div", {
    className: "empty-state"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty-state-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD50",
    size: 18
  })), "No recent activity"))), /*#__PURE__*/React.createElement("div", {
    className: "section-card",
    style: {
      paddingBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-header-left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "section-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  })), /*#__PURE__*/React.createElement("h2", {
    className: "section-title"
  }, "Finance Snapshot")), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/admin/finance.html",
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: '#2563EB',
      textDecoration: 'none'
    }
  }, "View all \u2192")), finance ? (() => {
    const rows = [{
      label: 'Revenue (this month)',
      value: fmtMoney(finance.total_revenue),
      color: '#059669'
    }, {
      label: 'Expenses (this month)',
      value: fmtMoney(finance.total_expenses),
      color: '#DC2626'
    }, {
      label: 'Net profit',
      value: fmtMoney(finance.net_profit),
      color: Number(finance.net_profit) >= 0 ? '#059669' : '#DC2626'
    }, {
      label: 'Pending collections',
      value: finance.pending_count != null ? `${finance.pending_count} students` : '—',
      color: '#D97706'
    }, {
      label: 'Pending amount',
      value: fmtMoney(finance.pending_amount),
      color: '#D97706'
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 0
      }
    }, rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '10px 0',
        borderBottom: i < rows.length - 1 ? '1px solid #F1F5F9' : 'none'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12.5,
        fontWeight: 600,
        color: 'var(--text-mid)'
      }
    }, r.label), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 800,
        color: r.color
      }
    }, r.value))));
  })() : /*#__PURE__*/React.createElement("div", {
    className: "empty-state"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty-state-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB8",
    size: 18
  })), "Finance data unavailable"))), /*#__PURE__*/React.createElement("div", {
    className: "quick-actions"
  }, /*#__PURE__*/React.createElement("div", {
    className: "qa-heading"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  }), " Quick Access"), /*#__PURE__*/React.createElement("div", {
    className: "qa-grid"
  }, [{
    href: '/nsms/public/admin/students.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDC65",
      size: 20
    }),
    label: 'Students',
    sub: 'Enrol & manage'
  }, {
    href: '/nsms/public/admin/teachers.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDC68\u200D\uD83C\uDFEB",
      size: 16
    }),
    label: 'Teachers',
    sub: 'Staff directory'
  }, {
    href: '/nsms/public/admin/finance.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCB0",
      size: 20
    }),
    label: 'Finance',
    sub: 'Fees & payments'
  }, {
    href: '/nsms/public/admin/analytics.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCA",
      size: 20
    }),
    label: 'Analytics',
    sub: 'School-wide stats'
  }, {
    href: '/nsms/public/admin/admin-pulse.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u26A1",
      size: 20
    }),
    label: 'J11 Pulse',
    sub: 'Messages & alerts'
  }, {
    href: '/nsms/public/admin/settings.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2699",
      size: 16
    }),
    label: 'Settings',
    sub: 'Configuration'
  }].map((a, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: a.href,
    className: "qa-btn"
  }, /*#__PURE__*/React.createElement("span", {
    className: "qa-icon"
  }, renderIcon(a.icon, 20)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "qa-label"
  }, a.label), /*#__PURE__*/React.createElement("div", {
    className: "qa-sub"
  }, a.sub))))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(AdminDashboard, null));