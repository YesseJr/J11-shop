const {
  useState,
  useEffect,
  useRef
} = React;

/* ── helpers ── */
const COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#06B6D4'];
const bgColor = name => name ? COLORS[name.charCodeAt(0) % COLORS.length] : '#94A3B8';
const initials = name => name ? name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : '?';
function fmtDate(v) {
  if (!v) return '—';
  const d = new Date((v + '').replace(' ', 'T'));
  return isNaN(d) ? v : d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}
function calcAge(dob) {
  if (!dob) return null;
  const b = new Date(dob),
    n = new Date();
  let a = n.getFullYear() - b.getFullYear();
  if (n.getMonth() < b.getMonth() || n.getMonth() === b.getMonth() && n.getDate() < b.getDate()) a--;
  return a;
}
function fmtMoney(v) {
  if (!v && v !== 0) return '—';
  return 'TSh ' + Number(v).toLocaleString();
}

// Installment number → month name (Jun & Dec = school holidays)
// 1→Jan 2→Feb 3→Mar 4→Apr 5→May 6→Jul 7→Aug 8→Sep 9→Oct 10→Nov
const INST_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'];
const instMonth = no => INST_MONTHS[+no - 1] || String(no);

function statusLabel(st) {
  var map = {
    active: 'Active',
    transferred: 'Transferred',
    withdrawn: 'Withdrawn',
    graduated: 'Graduated',
    suspended: 'Suspended',
    inactive: 'Inactive'
  };
  if (!st) return '—';
  return map[st] || (String(st).charAt(0).toUpperCase() + String(st).slice(1));
}

/* ── Avatar ── */
function Avatar({
  student,
  size
}) {
  size = size || 38;
  const [err, setErr] = useState(false);
  const hasPhoto = student.photo_url && !err;
  return /*#__PURE__*/React.createElement("div", {
    className: "student-avatar",
    style: {
      width: size,
      height: size,
      background: hasPhoto ? '#CBD5E1' : bgColor(student.student_name)
    }
  }, hasPhoto ? /*#__PURE__*/React.createElement("img", {
    src: student.photo_url,
    alt: "",
    onError: () => setErr(true)
  }) : initials(student.student_name));
}

/* ════════════════════════════════════════
VIEW MODAL  – fetches full data on open
including fee payment status
════════════════════════════════════════ */
function ViewModal({
  studentId,
  onClose,
  onEdit
}) {
  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [imgErr, setImgErr] = useState(false);
  useEffect(() => {
    setLoading(true);
    fetch('/nsms/api/students.php?action=get&id=' + studentId).then(r => r.json()).then(d => {
      if (d.success) setStudent(d.data);else console.error('getStudent failed:', d.error);
    }).catch(e => console.error('ViewModal fetch error:', e)).finally(() => setLoading(false));
  }, [studentId]);
  const hasPhoto = student && student.photo_url && !imgErr;
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    style: {
      maxWidth: 500
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-header"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "modal-title"
  }, "Student Profile"), /*#__PURE__*/React.createElement("button", {
    className: "modal-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "modal-body"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    className: "loading",
    style: {
      padding: '40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading profile\u2026")) : !student ? /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      color: '#94A3B8',
      padding: '32px'
    }
  }, "Could not load student data.") : (() => {
    const age = calcAge(student.date_of_birth);
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "view-photo-wrap"
    }, hasPhoto ? /*#__PURE__*/React.createElement("img", {
      src: student.photo_url,
      className: "view-photo",
      alt: student.student_name,
      onError: () => setImgErr(true)
    }) : /*#__PURE__*/React.createElement("div", {
      className: "view-initials",
      style: {
        background: bgColor(student.student_name)
      }
    }, initials(student.student_name))), /*#__PURE__*/React.createElement("div", {
      className: "view-name"
    }, student.student_name), /*#__PURE__*/React.createElement("div", {
      className: "view-class"
    }, /*#__PURE__*/React.createElement("span", {
      className: "class-badge",
      style: {
        background: student.class_color || '#2563EB'
      }
    }, student.class_name)), /*#__PURE__*/React.createElement("div", {
      className: "section-label"
    }, "Personal Information"), /*#__PURE__*/React.createElement("div", {
      className: "detail-grid"
    }, /*#__PURE__*/React.createElement("div", {
      className: "detail-field"
    }, /*#__PURE__*/React.createElement("label", null, "Date of Birth"), /*#__PURE__*/React.createElement("p", null, fmtDate(student.date_of_birth), age !== null ? ` · ${age} yrs` : '')), /*#__PURE__*/React.createElement("div", {
      className: "detail-field"
    }, /*#__PURE__*/React.createElement("label", null, "Gender"), /*#__PURE__*/React.createElement("p", null, student.gender || '—')), /*#__PURE__*/React.createElement("div", {
      className: "detail-field"
    }, /*#__PURE__*/React.createElement("label", null, "Enrollment Date"), /*#__PURE__*/React.createElement("p", null, fmtDate(student.enrollment_date))), /*#__PURE__*/React.createElement("div", {
      className: "detail-field"
    }, /*#__PURE__*/React.createElement("label", null, "Status"), /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement("span", {
      className: `status-badge status-${student.status}`
    }, statusLabel(student.status)))), student.address && /*#__PURE__*/React.createElement("div", {
      className: "detail-field span2"
    }, /*#__PURE__*/React.createElement("label", null, "Address"), /*#__PURE__*/React.createElement("p", null, student.address))), /*#__PURE__*/React.createElement("div", {
      className: "section-label"
    }, "Parent / Guardian"), /*#__PURE__*/React.createElement("div", {
      className: "detail-grid"
    }, /*#__PURE__*/React.createElement("div", {
      className: "detail-field"
    }, /*#__PURE__*/React.createElement("label", null, "Name"), /*#__PURE__*/React.createElement("p", null, student.parent_name || /*#__PURE__*/React.createElement("span", {
      className: "muted"
    }, "Not provided"))), /*#__PURE__*/React.createElement("div", {
      className: "detail-field"
    }, /*#__PURE__*/React.createElement("label", null, "Relationship"), /*#__PURE__*/React.createElement("p", null, student.parent_relationship || /*#__PURE__*/React.createElement("span", {
      className: "muted"
    }, "\u2014"))), /*#__PURE__*/React.createElement("div", {
      className: "detail-field"
    }, /*#__PURE__*/React.createElement("label", null, "Phone"), /*#__PURE__*/React.createElement("p", null, student.parent_phone ? /*#__PURE__*/React.createElement("a", {
      href: `tel:${student.parent_phone}`
    }, student.parent_phone) : /*#__PURE__*/React.createElement("span", {
      className: "muted"
    }, "\u2014"))), /*#__PURE__*/React.createElement("div", {
      className: "detail-field"
    }, /*#__PURE__*/React.createElement("label", null, "Email"), /*#__PURE__*/React.createElement("p", null, student.parent_email && !student.parent_email.includes('@nsms.local') ? /*#__PURE__*/React.createElement("a", {
      href: `mailto:${student.parent_email}`
    }, student.parent_email) : /*#__PURE__*/React.createElement("span", {
      className: "muted"
    }, "\u2014")))), /*#__PURE__*/React.createElement("div", {
      className: "section-label"
    }, "Fee Payment Status"), (() => {
      const fees = student.fees;
      if (!fees) return /*#__PURE__*/React.createElement("p", {
        className: "fee-no-data"
      }, "No fee data available.");
      const lp = fees.last_payment;

      // Chip helper
      const chip = (paid, due, count, total) => {
        if (!due && !total) return {
          cls: 'fee-chip-na',
          label: 'N/A'
        };
        if (total !== undefined) {
          // installment mode
          if (count === total) return {
            cls: 'fee-chip-paid',
            label: `${count}/${total} Paid`
          };
          if (count > 0) return {
            cls: 'fee-chip-partial',
            label: `${count}/${total} Paid`
          };
          return {
            cls: 'fee-chip-unpaid',
            label: 'Unpaid'
          };
        }
        // amount mode (other fees)
        if (due <= 0) return {
          cls: 'fee-chip-na',
          label: 'N/A'
        };
        if (paid >= due) return {
          cls: 'fee-chip-paid',
          label: 'Paid'
        };
        if (paid > 0) return {
          cls: 'fee-chip-partial',
          label: 'Partial'
        };
        return {
          cls: 'fee-chip-unpaid',
          label: 'Unpaid'
        };
      };

      // Mini bar helper
      const barCls = pct => pct >= 100 ? 'fee-fill-green' : pct > 0 ? 'fee-fill-amber' : 'fee-fill-red';
      const pct = (paid, due) => due > 0 ? Math.min(100, Math.round(paid / due * 100)) : 0;

      // ── Other fees ──
      const oth = fees.other || {};
      const othPct = pct(oth.total_paid, oth.total_due);
      const othChip = chip(oth.total_paid, oth.total_due);

      // ── School Fees ──
      const sf = fees.school_fees || {};
      const sfInst = sf.installments || [];
      const sfTotal = sfInst.length || 10;
      const sfPct = pct(sf.total_paid, sf.total_due);
      const sfChip = chip(null, null, sf.paid_count || 0, sfTotal);

      // ── Transport ──
      const tr = fees.transport || {};
      const trInst = tr.installments || [];
      const trTotal = trInst.length || 10;
      const trPct = pct(tr.total_paid, tr.total_due);
      const trChip = tr.configured ? chip(null, null, tr.paid_count || 0, trTotal) : {
        cls: 'fee-chip-na',
        label: 'Not enrolled'
      };
      return /*#__PURE__*/React.createElement("div", {
        className: "fee-card"
      }, /*#__PURE__*/React.createElement("div", {
        className: "fee-row"
      }, /*#__PURE__*/React.createElement("div", {
        className: "fee-row-header"
      }, /*#__PURE__*/React.createElement("span", {
        className: "fee-row-title"
      }, /*#__PURE__*/React.createElement("span", {
        className: "fee-row-icon"
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83C\uDFF7\uFE0F",
        size: 18
      })), ' ', "Other Fees"), /*#__PURE__*/React.createElement("span", {
        className: `fee-chip ${othChip.cls}`
      }, othChip.label)), oth.configured ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
        className: "fee-item-list"
      }, (oth.items || []).map((item, i) => /*#__PURE__*/React.createElement("div", {
        key: i,
        className: "fee-item-row"
      }, /*#__PURE__*/React.createElement("span", {
        className: "fee-item-name"
      }, item.name), /*#__PURE__*/React.createElement("div", {
        className: "fee-item-right"
      }, /*#__PURE__*/React.createElement("span", {
        className: "fee-item-amt"
      }, fmtMoney(item.amount)), /*#__PURE__*/React.createElement("div", {
        className: oth.total_paid >= oth.total_due && oth.total_due > 0 ? 'fee-dot-paid' : 'fee-dot-unpaid',
        title: oth.total_paid >= oth.total_due ? 'Paid' : 'Unpaid'
      }))))), /*#__PURE__*/React.createElement("div", {
        className: "fee-mini-bar"
      }, /*#__PURE__*/React.createElement("div", {
        className: `fee-mini-fill ${barCls(othPct)}`,
        style: {
          width: othPct + '%'
        }
      })), /*#__PURE__*/React.createElement("div", {
        className: "fee-totals"
      }, /*#__PURE__*/React.createElement("span", null, "Paid:", ' ', /*#__PURE__*/React.createElement("strong", null, fmtMoney(oth.total_paid))), /*#__PURE__*/React.createElement("span", null, "Due:", ' ', /*#__PURE__*/React.createElement("strong", null, fmtMoney(oth.total_due))))) : /*#__PURE__*/React.createElement("p", {
        className: "fee-no-data"
      }, "No one-time fees configured for this class.")), /*#__PURE__*/React.createElement("div", {
        className: "fee-row"
      }, /*#__PURE__*/React.createElement("div", {
        className: "fee-row-header"
      }, /*#__PURE__*/React.createElement("span", {
        className: "fee-row-title"
      }, /*#__PURE__*/React.createElement("span", {
        className: "fee-row-icon"
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83C\uDFEB",
        size: 18
      })), ' ', "School Fees"), /*#__PURE__*/React.createElement("span", {
        className: `fee-chip ${sfChip.cls}`
      }, sfChip.label)), sf.configured ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
        className: "inst-pills"
      }, sfInst.map(inst => /*#__PURE__*/React.createElement("div", {
        key: inst.no,
        className: `inst-pill inst-pill-${inst.status}`,
        title: `${inst.month_name || instMonth(inst.no)}: ${inst.status} — ${fmtMoney(inst.amount_paid)} / ${fmtMoney(inst.amount_due)}`
      }, inst.month_name || instMonth(inst.no)))), /*#__PURE__*/React.createElement("div", {
        className: "fee-mini-bar"
      }, /*#__PURE__*/React.createElement("div", {
        className: `fee-mini-fill ${barCls(sfPct)}`,
        style: {
          width: sfPct + '%'
        }
      })), /*#__PURE__*/React.createElement("div", {
        className: "fee-totals"
      }, /*#__PURE__*/React.createElement("span", null, "Paid:", ' ', /*#__PURE__*/React.createElement("strong", null, fmtMoney(sf.total_paid))), /*#__PURE__*/React.createElement("span", null, "Due:", ' ', /*#__PURE__*/React.createElement("strong", null, fmtMoney(sf.total_due))))) : /*#__PURE__*/React.createElement("p", {
        className: "fee-no-data"
      }, "No installment records yet \u2014 payment will generate them.")), /*#__PURE__*/React.createElement("div", {
        className: "fee-row"
      }, /*#__PURE__*/React.createElement("div", {
        className: "fee-row-header"
      }, /*#__PURE__*/React.createElement("span", {
        className: "fee-row-title"
      }, /*#__PURE__*/React.createElement("span", {
        className: "fee-row-icon"
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDE8C",
        size: 18
      })), ' ', "Transport"), /*#__PURE__*/React.createElement("span", {
        className: `fee-chip ${trChip.cls}`
      }, trChip.label)), tr.configured && trInst.length > 0 ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
        className: "inst-pills"
      }, trInst.map(inst => /*#__PURE__*/React.createElement("div", {
        key: inst.no,
        className: `inst-pill inst-pill-${inst.status}`,
        title: `${inst.month_name || instMonth(inst.no)}: ${inst.status} — ${fmtMoney(inst.amount_paid)} / ${fmtMoney(inst.amount_due)}`
      }, inst.month_name || instMonth(inst.no)))), /*#__PURE__*/React.createElement("div", {
        className: "fee-mini-bar"
      }, /*#__PURE__*/React.createElement("div", {
        className: `fee-mini-fill ${barCls(trPct)}`,
        style: {
          width: trPct + '%'
        }
      })), /*#__PURE__*/React.createElement("div", {
        className: "fee-totals"
      }, /*#__PURE__*/React.createElement("span", null, "Paid:", ' ', /*#__PURE__*/React.createElement("strong", null, fmtMoney(tr.total_paid))), /*#__PURE__*/React.createElement("span", null, "Due:", ' ', /*#__PURE__*/React.createElement("strong", null, fmtMoney(tr.total_due))))) : tr.configured ? /*#__PURE__*/React.createElement("p", {
        className: "fee-no-data"
      }, "Transport enrolled \u2014 no installment records yet.") : /*#__PURE__*/React.createElement("p", {
        className: "fee-no-data"
      }, "Student is not enrolled in the transport programme.")), lp && /*#__PURE__*/React.createElement("div", {
        className: "fee-footer"
      }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDCB3",
        size: 18
      })), /*#__PURE__*/React.createElement("span", null, "Last payment:"), /*#__PURE__*/React.createElement("span", {
        className: "fee-footer-amt"
      }, fmtMoney(lp.amount)), /*#__PURE__*/React.createElement("span", null, "via", ' ', lp.method), /*#__PURE__*/React.createElement("span", {
        style: {
          marginLeft: 'auto',
          color: '#94A3B8'
        }
      }, fmtDate(lp.date))), fees.total_paid === 0 && /*#__PURE__*/React.createElement("div", {
        style: {
          padding: '10px 16px',
          background: '#FFF1F2',
          borderTop: '1px solid #FECDD3',
          fontSize: '12px',
          color: '#9F1239'
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u26A0\uFE0F",
        size: 18
      }), " No payments recorded for this student yet."));
    })());
  })()), /*#__PURE__*/React.createElement("div", {
    className: "modal-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-cancel",
    onClick: onClose
  }, "Close"), student && /*#__PURE__*/React.createElement("button", {
    className: "btn-submit",
    onClick: () => {
      onClose();
      onEdit(student);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  }), " Edit Student"))));
}

/* ════════════════════════════════════════
ADD / EDIT FORM MODAL
════════════════════════════════════════ */
function FormModal({
  mode,
  student,
  classes,
  onClose,
  onSave
}) {
  const isEdit = mode === 'edit';
  const [form, setForm] = useState({
    student_name: student?.student_name || '',
    class_id: student?.class_id || '',
    date_of_birth: student?.date_of_birth || '',
    gender: student?.gender || 'Male',
    address: student?.address || '',
    enrollment_date: student?.enrollment_date || new Date().toISOString().split('T')[0],
    parent_name: student?.parent_name || '',
    parent_phone: student?.parent_phone || '',
    parent_email: student?.parent_email && !student.parent_email.includes('@nsms.local') ? student.parent_email : '',
    parent_relationship: student?.parent_relationship || 'Guardian'
  });
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(student?.photo_url || null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState({});
  const fileRef = useRef();
  const set = (k, v) => {
    setForm(p => ({
      ...p,
      [k]: v
    }));
    setFieldErrors(p => {
      if (!p[k]) return p;
      const n = { ...p };
      delete n[k];
      return n;
    });
  };
  const onPhotoChange = e => {
    const f = e.target.files[0];
    if (!f) return;
    setPhotoFile(f);
    setPhotoPreview(URL.createObjectURL(f));
  };

  const nameOk = v => /^[\p{L}\p{M}][\p{L}\p{M}\s'.\-]*$/u.test((v || '').trim()) && (v || '').trim().length >= 2;
  const phoneOk = v => {
    if (!(v || '').trim()) return true;
    const raw = v.trim();
    if (/[A-Za-z]/.test(raw) || /[@#$%*={}\[\]<>\\]/.test(raw)) return false;
    if (!/^\+?[0-9\s\-().]+$/.test(raw)) return false;
    if ((raw.match(/\+/g) || []).length > 1 || (raw.indexOf('+') > 0)) return false;
    const digits = raw.replace(/\D+/g, '');
    return digits.length >= 9 && digits.length <= 15;
  };
  const emailOk = v => {
    if (!(v || '').trim()) return true;
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());
  };
  const calcAgeParts = (dob, asOf) => {
    if (!dob) return null;
    const b = new Date(dob + 'T00:00:00');
    const r = asOf ? new Date(asOf + 'T00:00:00') : new Date();
    r.setHours(0, 0, 0, 0);
    if (isNaN(b.getTime()) || b > r) return null;
    let years = r.getFullYear() - b.getFullYear();
    let months = r.getMonth() - b.getMonth();
    if (r.getDate() < b.getDate()) months -= 1;
    if (months < 0) { years -= 1; months += 12; }
    return { years, months };
  };
  const selectedClass = (classes || []).find(c => String(c.id) === String(form.class_id));
  const minAge = selectedClass && selectedClass.minimum_age != null && selectedClass.minimum_age !== ''
    ? parseInt(selectedClass.minimum_age, 10) : 0;
  const ageParts = calcAgeParts(form.date_of_birth, form.enrollment_date || undefined);
  const ageMeets = !minAge || !ageParts ? null : ageParts.years >= minAge;

  const validateForm = () => {
    const errs = {};
    if (!form.student_name.trim()) errs.student_name = 'Student name is required';
    else if (!nameOk(form.student_name)) errs.student_name = 'Student name may only contain letters and common name characters';
    if (!form.class_id) errs.class_id = 'Please select a valid class';
    if (!form.date_of_birth) errs.date_of_birth = 'Date of birth is required';
    else {
      const d = new Date(form.date_of_birth + 'T00:00:00');
      const today = new Date(); today.setHours(0,0,0,0);
      if (isNaN(d.getTime())) errs.date_of_birth = 'Date of birth must be a valid date';
      else if (d > today) errs.date_of_birth = 'Date of birth cannot be in the future';
    }
    if (!form.gender) errs.gender = 'Please select a valid gender';
    if (!form.enrollment_date) errs.enrollment_date = 'Enrollment date is required';
    if (form.parent_name && !nameOk(form.parent_name)) errs.parent_name = 'Parent name may only contain letters and common name characters';
    if (form.parent_phone && !phoneOk(form.parent_phone)) errs.parent_phone = 'Phone number must contain a valid phone number';
    if (form.parent_email && !emailOk(form.parent_email)) errs.parent_email = 'Please enter a valid email address';
    if (minAge > 0 && ageParts && ageParts.years < minAge) {
      errs.date_of_birth = `This student does not meet the minimum age requirement for ${selectedClass.class_name}. The minimum required age is ${minAge} years.`;
    }
    setFieldErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    if (!validateForm()) {
      setError('Please fix the highlighted fields');
      return;
    }
    setSaving(true);
    try {
      const url = isEdit ? '/nsms/api/students.php?action=update' : '/nsms/api/students.php?action=create';

      // Always use FormData/POST — simpler and works for both photo and no-photo
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => {
        if (v !== '') fd.append(k, v);
      });
      if (isEdit) fd.append('id', student.id);
      if (photoFile) fd.append('photo', photoFile);
      if (window.NSMS_CSRF && window.NSMS_CSRF.getToken) {
        try {
          const token = await window.NSMS_CSRF.getToken();
          if (token) {
            fd.append('csrf_token', token);
            fd.append('_csrf', token);
          }
        } catch (e) {}
      }
      const response = await fetch(url, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' }
      });
      let data = null;
      const text = await response.text();
      try {
        data = text ? JSON.parse(text) : null;
      } catch (parseErr) {
        console.error('Student save non-JSON response', text && text.slice(0, 400));
        setError(window.NSMS_MYSQL_ONLINE === false
          ? 'Could not save offline. Try again, or run Prepare offline logins while online first.'
          : 'Server returned an unexpected response. Please try again.');
        return;
      }
      if (data && data.success) {
        onSave(data.data && data.data.photo_warning ? data.data.photo_warning : (data.message || null));
      } else {
        setError((data && data.error) || 'Server returned an error');
      }
    } catch (err) {
      console.error(err);
      setError(window.NSMS_MYSQL_ONLINE === false
        ? 'Offline save failed. Wait a moment and try again (first offline save can take a few seconds).'
        : 'Network error — check your connection and try again.');
    } finally {
      setSaving(false);
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-header"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "modal-title"
  }, isEdit ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 16
  }), "Edit Student") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 16
  }), "Add New Student")), /*#__PURE__*/React.createElement("button", {
    className: "modal-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))), /*#__PURE__*/React.createElement("form", {
    onSubmit: handleSubmit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-body"
  }, error && /*#__PURE__*/React.createElement("div", {
    className: "form-error"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", error), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Student Photo"), /*#__PURE__*/React.createElement("div", {
    className: "photo-upload",
    onClick: () => fileRef.current.click()
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    style: {
      display: 'none'
    },
    accept: "image/jpeg,image/png,image/gif,image/webp",
    onChange: onPhotoChange
  }), photoPreview ? /*#__PURE__*/React.createElement("img", {
    src: photoPreview,
    className: "photo-preview",
    alt: "preview"
  }) : /*#__PURE__*/React.createElement("div", {
    className: "photo-placeholder"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF7",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "photo-hint"
  }, photoPreview ? 'Click to change photo' : 'Click to upload a photo', /*#__PURE__*/React.createElement("small", null, "JPG \xB7 PNG \xB7 WEBP \xA0\xB7\xA0 max 5 MB")))), /*#__PURE__*/React.createElement("div", {
    className: "section-label"
  }, "Student Details"), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Full Name", ' ', /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    placeholder: "e.g. Amina Hassan",
    value: form.student_name,
    onChange: e => set('student_name', e.target.value),
    required: true
  })), /*#__PURE__*/React.createElement("div", {
    className: "form-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Class", ' ', /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("select", {
    className: "form-select",
    value: form.class_id,
    onChange: e => set('class_id', e.target.value),
    required: true
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "\u2014 Select \u2014"), classes.map((c, i) => /*#__PURE__*/React.createElement("option", {
    key: i,
    value: c.id || i + 1
  }, c.class_name)))), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Gender", ' ', /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("select", {
    className: "form-select",
    value: form.gender,
    onChange: e => set('gender', e.target.value),
    required: true
  }, /*#__PURE__*/React.createElement("option", {
    value: "Male"
  }, "Male"), /*#__PURE__*/React.createElement("option", {
    value: "Female"
  }, "Female")))), /*#__PURE__*/React.createElement("div", {
    className: "form-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Date of Birth", ' ', /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "form-input",
    value: form.date_of_birth,
    onChange: e => set('date_of_birth', e.target.value),
    required: true,
    max: new Date().toISOString().split('T')[0]
  }), (minAge > 0 || ageParts) && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      padding: '10px 12px',
      borderRadius: 10,
      background: ageMeets === false ? '#FEF2F2' : '#F0FDF4',
      border: '1px solid ' + (ageMeets === false ? '#FECACA' : '#BBF7D0'),
      fontSize: 12.5,
      color: ageMeets === false ? '#991B1B' : '#166534',
      lineHeight: 1.45
    }
  }, minAge > 0 && /*#__PURE__*/React.createElement("div", null, "Selected class minimum age: ", /*#__PURE__*/React.createElement("strong", null, minAge, " years")), ageParts && /*#__PURE__*/React.createElement("div", null, "Student age: ", /*#__PURE__*/React.createElement("strong", null, ageParts.years, " years", ageParts.months ? ', ' + ageParts.months + ' months' : '')), ageMeets === false && /*#__PURE__*/React.createElement("div", {
    style: { marginTop: 4, fontWeight: 600 }
  }, "Student does not meet the minimum age requirement."), ageMeets === true && minAge > 0 && /*#__PURE__*/React.createElement("div", {
    style: { marginTop: 4, fontWeight: 600 }
  }, "Student meets the minimum age requirement."), fieldErrors.date_of_birth && /*#__PURE__*/React.createElement("div", {
    style: { marginTop: 4 }
  }, fieldErrors.date_of_birth))), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Enrollment Date", ' ', /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "form-input",
    value: form.enrollment_date,
    onChange: e => set('enrollment_date', e.target.value),
    required: true
  }))), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Home Address"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    placeholder: "Street / area (optional)",
    value: form.address,
    onChange: e => set('address', e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    className: "section-label"
  }, "Parent / Guardian"), /*#__PURE__*/React.createElement("div", {
    className: "form-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Full Name"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    placeholder: "Parent or guardian name",
    value: form.parent_name,
    onChange: e => set('parent_name', e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Relationship"), /*#__PURE__*/React.createElement("select", {
    className: "form-select",
    value: form.parent_relationship,
    onChange: e => set('parent_relationship', e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: "Guardian"
  }, "Guardian"), /*#__PURE__*/React.createElement("option", {
    value: "Father"
  }, "Father"), /*#__PURE__*/React.createElement("option", {
    value: "Mother"
  }, "Mother"), /*#__PURE__*/React.createElement("option", {
    value: "Other"
  }, "Other")))), /*#__PURE__*/React.createElement("div", {
    className: "form-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Phone Number"), /*#__PURE__*/React.createElement("input", {
    type: "tel",
    className: "form-input",
    placeholder: "+255 7xx xxx xxx",
    value: form.parent_phone,
    onChange: e => set('parent_phone', e.target.value),
    inputMode: "tel",
    autoComplete: "tel",
    placeholder: "+255712345678"
  }), fieldErrors.parent_phone && /*#__PURE__*/React.createElement("div", {
    style: { color: '#b91c1c', fontSize: 12, marginTop: 4 }
  }, fieldErrors.parent_phone)), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Email Address"), /*#__PURE__*/React.createElement("input", {
    type: "email",
    className: "form-input",
    placeholder: "parent@email.com",
    value: form.parent_email,
    onChange: e => set('parent_email', e.target.value),
    autoComplete: "email"
  }), fieldErrors.parent_email && /*#__PURE__*/React.createElement("div", {
    style: { color: '#b91c1c', fontSize: 12, marginTop: 4 }
  }, fieldErrors.parent_email))), /*#__PURE__*/React.createElement("div", {
    className: "parent-note"
  }, /*#__PURE__*/React.createElement("span", {
    className: "parent-note-icon"
  }, "\u2139\uFE0F"), /*#__PURE__*/React.createElement("span", null, "A parent account will be created automatically and set as", /*#__PURE__*/React.createElement("strong", null, " inactive"), ". The parent can activate it later through the parent portal."))), /*#__PURE__*/React.createElement("div", {
    className: "modal-footer"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn-cancel",
    onClick: onClose,
    disabled: saving
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "btn-submit",
    disabled: saving
  }, saving ? 'Saving…' : isEdit ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCBE",
    size: 16
  }), "Save Changes") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 16
  }), "Add Student"))))));
}


function LifecycleModal({ student, action, classes, onClose, onDone }) {
  const [form, setForm] = useState({
    transfer_date: new Date().toISOString().slice(0, 10),
    leave_date: new Date().toISOString().slice(0, 10),
    reactivation_date: new Date().toISOString().slice(0, 10),
    destination: '',
    reason: '',
    remarks: '',
    authorized_by: '',
    class_id: student && student.class_id ? student.class_id : ''
  });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k, v) => setForm(p => Object.assign({}, p, { [k]: v }));
  const titles = {
    transfer: 'Transfer Student',
    withdraw: 'Withdraw / Leave School',
    reactivate: 'Reactivate Student',
    graduate: 'Graduate Student',
    suspend: 'Suspend Student'
  };
  const confirms = {
    transfer: 'Confirm Transfer',
    withdraw: 'Confirm Withdrawal',
    reactivate: 'Reactivate',
    graduate: 'Confirm Graduation',
    suspend: 'Confirm Suspension'
  };
  const hints = {
    transfer: 'This removes the student from the active list and marks them as Transferred. Attendance, fees, and reports stay in the system.',
    withdraw: 'This removes the student from the active list and marks them as Withdrawn. All historical records are preserved.',
    reactivate: 'Returns this student to the active roll. Previous history is kept intact.',
    graduate: 'Marks the student as Graduated. Records remain available under Graduated.',
    suspend: 'Temporarily removes the student from normal active operations. History is preserved.'
  };
  const submit = async () => {
    setErr('');
    if (action === 'transfer' && !String(form.destination || '').trim()) {
      setErr('Destination school / institution is required.');
      return;
    }
    if (action === 'withdraw' && !String(form.reason || '').trim()) {
      setErr('Reason for leaving is required.');
      return;
    }
    setBusy(true);
    try {
      const body = Object.assign({ student_id: student.id, id: student.id }, form);
      const r = await fetch('/nsms/api/students.php?action=' + action, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(body)
      });
      const d = await r.json();
      if (!d.success) {
        setErr(d.error || 'Request failed');
        setBusy(false);
        return;
      }
      onDone(d.message || 'Saved');
    } catch (e) {
      setErr('Network error. Please try again.');
      setBusy(false);
    }
  };
  const field = (label, children) => /*#__PURE__*/React.createElement("div", {
    className: "form-group",
    style: { marginBottom: 14 }
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label",
    style: { display: 'block', fontSize: 13, fontWeight: 600, color: '#334155', marginBottom: 6 }
  }, label), children);
  const inputStyle = {
    width: '100%',
    border: '1px solid #e2e8f0',
    borderRadius: 10,
    padding: '10px 12px',
    fontSize: 14,
    background: '#fff',
    color: '#0f172a',
    boxSizing: 'border-box'
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(15, 23, 42, 0.55)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 10000,
      padding: 16
    },
    onClick: e => e.target === e.currentTarget && !busy && onClose()
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    role: "dialog",
    "aria-modal": "true",
    style: {
      background: '#ffffff',
      borderRadius: 14,
      width: '100%',
      maxWidth: 520,
      maxHeight: '92vh',
      display: 'flex',
      flexDirection: 'column',
      boxShadow: '0 25px 70px rgba(0,0,0,0.28)',
      overflow: 'hidden',
      position: 'relative',
      zIndex: 10001
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-header",
    style: {
      padding: '18px 22px',
      borderBottom: '1px solid #e2e8f0',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "modal-title",
    style: { margin: 0, fontSize: 18, fontWeight: 700, color: '#0f172a' }
  }, titles[action] || 'Student status'), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "modal-close",
    onClick: onClose,
    disabled: busy,
    "aria-label": "Close",
    style: {
      background: 'none',
      border: 'none',
      fontSize: 22,
      cursor: 'pointer',
      color: '#94a3b8',
      width: 32,
      height: 32,
      borderRadius: 6
    }
  }, "\u00d7")), /*#__PURE__*/React.createElement("div", {
    className: "modal-body",
    style: {
      padding: '20px 22px',
      overflowY: 'auto',
      flex: 1,
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#F8FAFC',
      border: '1px solid #E2E8F0',
      borderRadius: 10,
      padding: '12px 14px',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 14, color: '#0f172a', marginBottom: 4 }
  }, "Student: ", /*#__PURE__*/React.createElement("strong", null, student.student_name), " \u00b7 Status: ", /*#__PURE__*/React.createElement("strong", null, statusLabel(student.status))), /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 13, color: '#64748b', lineHeight: 1.45 }
  }, hints[action] || '')), action === 'transfer' && /*#__PURE__*/React.createElement(React.Fragment, null, field('Transfer date *', /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "form-input",
    style: inputStyle,
    value: form.transfer_date,
    onChange: e => set('transfer_date', e.target.value)
  })), field('Destination school / institution *', /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    style: inputStyle,
    value: form.destination,
    onChange: e => set('destination', e.target.value),
    placeholder: "e.g. Green Valley Primary School"
  })), field('Reason (optional)', /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    style: inputStyle,
    value: form.reason,
    onChange: e => set('reason', e.target.value),
    placeholder: "Why is the student transferring?"
  }))), action === 'withdraw' && /*#__PURE__*/React.createElement(React.Fragment, null, field('Date of leaving *', /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "form-input",
    style: inputStyle,
    value: form.leave_date,
    onChange: e => set('leave_date', e.target.value)
  })), field('Reason for leaving *', /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    style: inputStyle,
    value: form.reason,
    onChange: e => set('reason', e.target.value),
    placeholder: "Required — why is the student leaving?"
  })), field('Optional destination', /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    style: inputStyle,
    value: form.destination,
    onChange: e => set('destination', e.target.value),
    placeholder: "School or place they are going (optional)"
  }))), action === 'reactivate' && /*#__PURE__*/React.createElement(React.Fragment, null, field('Reactivation date', /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "form-input",
    style: inputStyle,
    value: form.reactivation_date,
    onChange: e => set('reactivation_date', e.target.value)
  })), field('Class', /*#__PURE__*/React.createElement("select", {
    className: "form-select",
    style: inputStyle,
    value: form.class_id,
    onChange: e => set('class_id', e.target.value)
  }, /*#__PURE__*/React.createElement("option", { value: "" }, "Keep current class"), (classes || []).map(c => /*#__PURE__*/React.createElement("option", {
    key: c.id,
    value: c.id
  }, c.class_name)))), field('Reason / remarks', /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    style: inputStyle,
    value: form.reason,
    onChange: e => set('reason', e.target.value)
  }))), (action === 'graduate' || action === 'suspend') && field(action === 'suspend' ? 'Reason *' : 'Notes', /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    style: inputStyle,
    value: form.reason,
    onChange: e => set('reason', e.target.value)
  })), field('Authorized by', /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "form-input",
    style: inputStyle,
    value: form.authorized_by,
    onChange: e => set('authorized_by', e.target.value),
    placeholder: "Name of authorizing staff"
  })), field('Remarks', /*#__PURE__*/React.createElement("textarea", {
    className: "form-input",
    style: Object.assign({}, inputStyle, { minHeight: 72, resize: 'vertical' }),
    rows: 2,
    value: form.remarks,
    onChange: e => set('remarks', e.target.value)
  })), err ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#b91c1c',
      background: '#FEF2F2',
      border: '1px solid #FECACA',
      borderRadius: 8,
      padding: '10px 12px',
      fontSize: 13,
      marginTop: 4
    }
  }, err) : null), /*#__PURE__*/React.createElement("div", {
    className: "modal-footer",
    style: {
      padding: '14px 22px',
      borderTop: '1px solid #e2e8f0',
      display: 'flex',
      gap: 10,
      justifyContent: 'flex-end',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn-cancel",
    onClick: onClose,
    disabled: busy,
    style: {
      padding: '10px 16px',
      borderRadius: 10,
      border: '1px solid #e2e8f0',
      background: '#fff',
      cursor: 'pointer',
      fontWeight: 600
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn-primary",
    onClick: submit,
    disabled: busy,
    style: {
      padding: '10px 16px',
      borderRadius: 10,
      border: 'none',
      background: action === 'withdraw' ? '#b91c1c' : '#1D5C42',
      color: '#fff',
      cursor: 'pointer',
      fontWeight: 700
    }
  }, busy ? 'Saving\u2026' : confirms[action] || 'Confirm'))));
}



/* ════════════════════════════════════════
MAIN PAGE
════════════════════════════════════════ */
function StudentsPage() {
  const [students, setStudents] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState((() => {
    try {
      const p = new URLSearchParams(window.location.search).get('status');
      const allowed = ['active', 'former', 'transferred', 'withdrawn', 'graduated', 'suspended', 'all'];
      if (p && allowed.indexOf(p) >= 0) return p;
    } catch (e) {}
    return 'active';
  })());
  const [statusCounts, setStatusCounts] = useState(null);
  const [lifeModal, setLifeModal] = useState(null); // { student, action: transfer|withdraw|reactivate|graduate|suspend }
  const sidebarActive = 'students';
  const viewTitle = ({
    active: 'Active Students',
    former: 'Former Students',
    transferred: 'Transferred Students',
    withdrawn: 'Withdrawn Students',
    graduated: 'Graduated Students',
    suspended: 'Suspended Students',
    all: 'All Students'
  })[statusFilter] || 'Students';
  const viewHint = ({
    active: 'Currently enrolled. Transfer or withdraw keeps full history.',
    former: 'Transferred, withdrawn, and graduated — not on the active roll.',
    transferred: 'Left for another school. Records retained.',
    withdrawn: 'Left the school. Records retained.',
    graduated: 'Completed the programme. Records retained.',
    suspended: 'Temporarily not attending.',
    all: 'Every student record, any status.'
  })[statusFilter] || '';

  // viewStudentId: just the ID — ViewModal fetches full data itself
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewStudentId, setViewStudentId] = useState(null);
  const [formModal, setFormModal] = useState(null); // null | { mode, student }
  const [toast, setToast] = useState(null);
  useEffect(() => {
    loadStudents();
    loadClasses();
    loadStatusCounts();
    try {
      const url = new URL(window.location.href);
      if (statusFilter && statusFilter !== 'active') url.searchParams.set('status', statusFilter);
      else url.searchParams.delete('status');
      window.history.replaceState({}, '', url.pathname + url.search + url.hash);
    } catch (e) {}
  }, [statusFilter]);
  useEffect(() => {
    applyFilter();
  }, [search, classFilter, students]);
  const loadStatusCounts = async () => {
    try {
      const r = await fetch('/nsms/api/students.php?action=status_counts');
      const d = await r.json();
      if (d.success) setStatusCounts(d.data);
    } catch (e) {}
  };
  const loadStudents = async () => {
    setLoading(true);
    setStudents([]); // avoid showing previous status while loading
    try {
      const st = statusFilter || 'active';
      const r = await fetch('/nsms/api/students.php?action=list&status=' + encodeURIComponent(st));
      const d = await r.json();
      if (d.success) setStudents(Array.isArray(d.data) ? d.data : []);
      else setStudents([]);
    } catch (e) {
      console.error('loadStudents:', e);
      setStudents([]);
    } finally {
      setLoading(false);
    }
  };
  const loadClasses = async () => {
    try {
      // Prefer settings get_classes (includes minimum_age for age validation)
      let r = await fetch('/nsms/api/settings.php?action=get_classes');
      let d = await r.json();
      if (d.success && Array.isArray(d.data) && d.data.length) {
        setClasses(d.data);
        return;
      }
      r = await fetch('/nsms/api/analytics.php?action=class_distribution');
      d = await r.json();
      if (d.success) setClasses(d.data || []);
    } catch (e) {
      console.error('loadClasses:', e);
    }
  };
  const applyFilter = async () => {
    let f = students;
    if (search) {
      const q = search.toLowerCase();
      f = f.filter(s => s.student_name.toLowerCase().includes(q) || s.parent_name && s.parent_name.toLowerCase().includes(q) || s.parent_phone && s.parent_phone.includes(q));
    }
    if (classFilter !== 'all') {
      f = f.filter(s => s.class_name === classFilter);
    }
    setFiltered(f);
  };
  const showToast = async (msg, type) => {
    setToast({
      msg,
      type: type || 'success'
    });
    setTimeout(() => setToast(null), 3500);
  };
  const handleLogout = async () => {
    try {
      await fetch('/nsms/api/auth.php?action=logout', {
        method: 'POST'
      });
    } catch (e) {}
    window.location.href = '/nsms/public/index.html';
  };
  const openAdd = async () => setFormModal({
    mode: 'add',
    student: null
  });
  const openEdit = s => setFormModal({
    mode: 'edit',
    student: s
  });
  const closeForm = async () => setFormModal(null);
  const resetParentPassword = s => {
    if (!s || !s.parent_user_id) {
      showToast('No parent account linked to this student', 'error');
      return;
    }
    const label = s.parent_name || s.parent_email || 'this parent';
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Reset password?', message: 'Reset password for ' + label + '?\n\nThey will receive a temporary password by email and must activate again. Student records are not affected.', confirmLabel: 'Reset password', variant: 'warn' }) : Promise.resolve(false)))) return;
    fetch('/nsms/api/students.php?action=reset_parent_password', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        user_id: s.parent_user_id,
        student_id: s.id
      })
    }).then(r => r.json()).then(d => {
      if (d.success) {
        let msg = d.message || 'Parent password reset';
        if (d.data && d.data.reset_url && !d.data.email_sent) {
          msg += ' Link: ' + d.data.reset_url;
        } else if (d.data && d.data.temp_password && !d.data.email_sent) {
          msg += ' Temporary password: ' + d.data.temp_password;
        }
        showToast(msg, 'success');
      } else {
        showToast(d.error || 'Reset failed', 'error');
      }
    }).catch(() => showToast('Network error', 'error'));
  };
  const onSaved = photoWarning => {
    closeForm();
    loadStudents();
    showToast('Student saved successfully', 'success');
    if (photoWarning) {
      setTimeout(() => showToast(/*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u26A0\uFE0F",
        size: 16
      }), "Photo: ") + photoWarning, 'warning'), 500);
    }
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NSMSNavbar, {
    activePage: sidebarActive,
    onLogout: handleLogout,
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement(NSMSSidebar, {
    activePage: sidebarActive,
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "nsms-main",
    style: {
      marginLeft: sidebarOpen ? '220px' : '64px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-title-section"
  }, /*#__PURE__*/React.createElement("h1", null, "Student Management"), /*#__PURE__*/React.createElement("p", {
    className: "page-subtitle"
  }, loading ? 'Loading…' : `${students.length} student${students.length !== 1 ? 's' : ''} enrolled`)), /*#__PURE__*/React.createElement("button", {
    className: "add-btn",
    onClick: openAdd
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 18
  }), " Add New Student")), /*#__PURE__*//*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 18,
      fontWeight: 700,
      color: '#0f172a'
    }
  }, viewTitle), viewHint ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 0',
      fontSize: 13,
      color: '#64748b'
    }
  }, viewHint) : null), /*#__PURE__*/React.createElement("div", {
    className: "status-pills",
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8,
      marginBottom: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: '#64748b',
      marginRight: 4
    }
  }, "Show:"), [['active', 'Active'], ['former', 'Former (all)'], ['transferred', 'Transferred'], ['withdrawn', 'Withdrawn'], ['graduated', 'Graduated'], ['suspended', 'Suspended'], ['all', 'All']].map(function (pair) {
    var key = pair[0];
    var label = pair[1];
    var on = statusFilter === key;
    var count = statusCounts && (key === 'former' ? (statusCounts.transferred || 0) + (statusCounts.withdrawn || 0) + (statusCounts.graduated || 0) : key === 'all' ? statusCounts.total : statusCounts[key]);
    return /*#__PURE__*/React.createElement("button", {
      key: key,
      type: "button",
      onClick: function () {
        return setStatusFilter(key);
      },
      style: {
        border: on ? '1px solid #1D5C42' : '1px solid #e2e8f0',
        background: on ? '#EAF7F1' : '#fff',
        color: on ? '#1D5C42' : '#475569',
        borderRadius: 999,
        padding: '6px 12px',
        fontSize: 12,
        fontWeight: on ? 700 : 500,
        cursor: 'pointer'
      }
    }, label, count != null ? ' (' + count + ')' : '');
  })), React.createElement("div", {
    className: "filters-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "search-box"
  }, /*#__PURE__*/React.createElement("span", {
    className: "search-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    type: "text",
    placeholder: "Search by name, parent or phone\u2026",
    value: search,
    onChange: e => setSearch(e.target.value)
  })), /*#__PURE__*/React.createElement("select", {
    className: "filter-select",
    value: statusFilter,
    onChange: e => setStatusFilter(e.target.value),
    title: "Student lifecycle status"
  }, /*#__PURE__*/React.createElement("option", { value: "active" }, "Active"), /*#__PURE__*/React.createElement("option", { value: "former" }, "Former students"), /*#__PURE__*/React.createElement("option", { value: "transferred" }, "Transferred"), /*#__PURE__*/React.createElement("option", { value: "withdrawn" }, "Withdrawn"), /*#__PURE__*/React.createElement("option", { value: "graduated" }, "Graduated"), /*#__PURE__*/React.createElement("option", { value: "suspended" }, "Suspended"), /*#__PURE__*/React.createElement("option", { value: "all" }, "All statuses")), /*#__PURE__*/React.createElement("select", {
    className: "filter-select",
    value: classFilter,
    onChange: e => setClassFilter(e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: "all"
  }, "All Classes"), classes.map((c, i) => /*#__PURE__*/React.createElement("option", {
    key: i,
    value: c.class_name
  }, c.class_name)))), /*#__PURE__*/React.createElement("div", {
    className: "table-container"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    className: "loading"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading students\u2026")) : filtered.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty-state"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, (function () {
    if (search || classFilter !== 'all') return 'No students match your search or filter.';
    if (statusFilter === 'active') return 'No active students yet. Click "Add New Student" to get started.';
    if (statusFilter === 'former') return 'No former students yet. Transfer, withdraw, or graduate a student to see them here.';
    if (statusFilter === 'transferred') return 'No transferred students. Use Transfer on an active student to move them here.';
    if (statusFilter === 'withdrawn') return 'No withdrawn students yet.';
    if (statusFilter === 'graduated') return 'No graduated students yet.';
    if (statusFilter === 'suspended') return 'No suspended students.';
    return 'No students found for this filter.';
  })())) : /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Student"), /*#__PURE__*/React.createElement("th", null, "Class"), /*#__PURE__*/React.createElement("th", null, "Parent / Guardian"), /*#__PURE__*/React.createElement("th", null, "Phone"), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: '80px',
      textAlign: 'center'
    }
  }, "Actions"))), /*#__PURE__*/React.createElement("tbody", null, filtered.map(s => /*#__PURE__*/React.createElement("tr", {
    key: s.id
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "student-info"
  }, /*#__PURE__*/React.createElement(Avatar, {
    student: s
  }), /*#__PURE__*/React.createElement("span", {
    className: "student-name"
  }, s.student_name))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "class-badge",
    style: {
      background: s.class_color || '#2563EB'
    }
  }, s.class_name)), /*#__PURE__*/React.createElement("td", null, s.parent_name ? /*#__PURE__*/React.createElement("span", null, s.parent_name, s.parent_relationship ? /*#__PURE__*/React.createElement("small", {
    style: {
      color: '#64748B'
    }
  }, ' ', "\xB7", ' ', s.parent_relationship) : null) : /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "\u2014")), /*#__PURE__*/React.createElement("td", null, s.parent_phone || /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "\u2014")), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: `status-badge status-${s.status}`
  }, statusLabel(s.status))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    className: "action-icons",
    style: {
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "icon-btn icon-btn-view",
    title: "View details",
    onClick: () => setViewStudentId(s.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC41",
    size: 18
  })), /*#__PURE__*/React.createElement("button", {
    className: "icon-btn icon-btn-edit",
    title: "Edit student",
    onClick: () => openEdit(s)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  })), (s.status === 'active' || !s.status) && /*#__PURE__*/React.createElement("button", {
    className: "icon-btn",
    title: "Transfer student",
    onClick: () => setLifeModal({ student: s, action: 'transfer' })
  }, "\u2192"), (s.status === 'active' || !s.status) && /*#__PURE__*/React.createElement("button", {
    className: "icon-btn",
    title: "Withdraw / leave school",
    onClick: () => setLifeModal({ student: s, action: 'withdraw' })
  }, "\u2715"), s.status && s.status !== 'active' && /*#__PURE__*/React.createElement("button", {
    className: "icon-btn",
    title: "Reactivate student",
    onClick: () => setLifeModal({ student: s, action: 'reactivate' })
  }, "\u21A9"), s.parent_user_id ? /*#__PURE__*/React.createElement("button", {
    className: "icon-btn",
    title: "Reset parent password",
    style: {
      color: '#D97706'
    },
    onClick: () => resetParentPassword(s)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD11",
    size: 18
  })) : null)))))))), viewStudentId && /*#__PURE__*/React.createElement(ViewModal, {
    studentId: viewStudentId,
    onClose: () => setViewStudentId(null),
    onEdit: s => {
      setViewStudentId(null);
      openEdit(s);
    }
  }), lifeModal && /*#__PURE__*/React.createElement(LifecycleModal, {
    student: lifeModal.student,
    action: lifeModal.action,
    classes: classes,
    onClose: () => setLifeModal(null),
    onDone: async msg => {
      setLifeModal(null);
      showToast(msg || 'Updated', 'success');
      await loadStudents();
      loadStatusCounts();
    }
  }), formModal && /*#__PURE__*/React.createElement(FormModal, {
    mode: formModal.mode,
    student: formModal.student,
    classes: classes,
    onClose: closeForm,
    onSave: onSaved
  }), toast && /*#__PURE__*/React.createElement("div", {
    className: `toast toast-${toast.type}`
  }, toast.msg));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(StudentsPage, null));