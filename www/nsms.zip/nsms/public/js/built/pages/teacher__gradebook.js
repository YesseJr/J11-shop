function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState,
  useEffect,
  useCallback
} = React;

/* ── Type config ── */
const TYPE_CFG = {
  daily: {
    label: 'Daily',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCC5",
      size: 20
    }),
    pillCls: 'daily',
    badgeCls: 'tb-daily',
    periodOptions: null
  },
  weekly: {
    label: 'Weekly',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDDD3",
      size: 20
    }),
    pillCls: 'weekly',
    badgeCls: 'tb-weekly',
    periodOptions: Array.from({
      length: 20
    }, (_, i) => `Week ${i + 1}`)
  },
  midterm: {
    label: 'Mid-term',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCA",
      size: 20
    }),
    pillCls: 'midterm',
    badgeCls: 'tb-midterm',
    periodOptions: ['Midterm 1', 'Midterm 2']
  },
  terminal: {
    label: 'Terminal',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF93",
      size: 20
    }),
    pillCls: 'terminal',
    badgeCls: 'tb-terminal',
    periodOptions: null
  } // auto = term
};

/* ── Helpers ── */
const AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2'];
const avColor = n => n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
const initials = n => n ? n.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) : '?';
function pctToGrade(pct) {
  if (pct === null || pct === undefined || pct === '') return null;
  const p = parseFloat(pct);
  if (p >= 90) return 'A';
  if (p >= 75) return 'B';
  if (p >= 60) return 'C';
  if (p >= 50) return 'D';
  if (p >= 40) return 'E';
  return 'F';
}
function scoreToGrade(score, max = 100) {
  return pctToGrade(max > 0 ? parseFloat(score) / parseFloat(max) * 100 : null);
}
function gradeClass(g) {
  return {
    A: 'gp-a',
    B: 'gp-b',
    C: 'gp-c',
    D: 'gp-d',
    E: 'gp-e',
    F: 'gp-f'
  }[g] || 'gp-none';
}
function scoreInputClass(g) {
  return {
    A: 'sc-a',
    B: 'sc-b',
    C: 'sc-c',
    D: 'sc-d',
    E: 'sc-e',
    F: 'sc-f'
  }[g] || '';
}
function perfClass(l) {
  return {
    'Excellent': 'pl-excellent',
    'Very Good': 'pl-very-good',
    'Good': 'pl-good',
    'Average': 'pl-average',
    'Below Average': 'pl-below',
    'Poor': 'pl-poor'
  }[l] || '';
}
function formatDateLabel(iso) {
  if (!iso) return '';
  const d = new Date(iso + 'T12:00:00');
  return d.toLocaleDateString('en-GB', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}
async function api(params, method = 'GET', body = null) {
  const url = '/nsms/api/gradebook.php' + (method === 'GET' ? '?' + new URLSearchParams(params) : '');
  const opts = {
    method,
    headers: {
      'Content-Type': 'application/json'
    }
  };
  if (method === 'POST' && body) opts.body = JSON.stringify(body);
  const r = await fetch(url, opts);
  const text = await r.text();
  try {
    return JSON.parse(text);
  } catch {
    const s = text.indexOf('{');
    if (s > 0) {
      try {
        return JSON.parse(text.slice(s));
      } catch {}
    }
    throw new Error('Server error: ' + text.slice(0, 200));
  }
}

/* ── Components ── */
function Alert({
  type,
  msg,
  onClose
}) {
  if (!msg) return null;
  const icon = type === 'success' ? '✅' : type === 'info' ? 'ℹ️' : /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0",
    size: 16
  });
  return /*#__PURE__*/React.createElement("div", {
    className: `alert alert-${type}`
  }, /*#__PURE__*/React.createElement("span", null, icon), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, msg), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'inherit',
      fontSize: 16
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  })));
}
function SAv({
  student,
  size = 34
}) {
  const [err, setErr] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "s-av",
    style: {
      width: size,
      height: size,
      background: avColor(student.student_name || student.name)
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      zIndex: 1,
      fontSize: size * .35
    }
  }, initials(student.student_name || student.name)), student.photo_url && !err && /*#__PURE__*/React.createElement("img", {
    src: student.photo_url,
    alt: "",
    onError: () => setErr(true)
  }));
}
function TypeBadge({
  type
}) {
  const cfg = TYPE_CFG[type] || {
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCC",
      size: 20
    }),
    label: type,
    badgeCls: 'tb-daily'
  };
  return /*#__PURE__*/React.createElement("span", {
    className: `type-badge ${cfg.badgeCls}`
  }, cfg.icon, " ", cfg.label);
}

/* Period picker inside Create modal */
function PeriodPicker({
  type,
  term,
  periodLabel,
  setPeriodLabel,
  assessmentDate,
  setAssessmentDate
}) {
  useEffect(() => {
    if (type === 'terminal' && term) setPeriodLabel(term);
  }, [type, term]);
  if (type === 'terminal') {
    return /*#__PURE__*/React.createElement("div", {
      className: "form-field"
    }, /*#__PURE__*/React.createElement("label", {
      className: "form-label"
    }, "Period"), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '9px 13px',
        border: '2px solid var(--border)',
        borderRadius: 8,
        background: '#F8FAFC',
        fontSize: 13,
        color: 'var(--text-soft)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF93",
      size: 18
    }), " ", term || '—', " ", /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11
      }
    }, "(auto-set to term)")));
  }
  if (type === 'midterm') {
    return /*#__PURE__*/React.createElement("div", {
      className: "form-field"
    }, /*#__PURE__*/React.createElement("label", {
      className: "form-label"
    }, "Period *"), /*#__PURE__*/React.createElement("select", {
      className: "form-input",
      value: periodLabel,
      onChange: e => setPeriodLabel(e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: ""
    }, "\u2014 Select \u2014"), /*#__PURE__*/React.createElement("option", {
      value: "Midterm 1"
    }, "Mid-term 1"), /*#__PURE__*/React.createElement("option", {
      value: "Midterm 2"
    }, "Mid-term 2")));
  }
  if (type === 'weekly') {
    return /*#__PURE__*/React.createElement("div", {
      className: "form-field"
    }, /*#__PURE__*/React.createElement("label", {
      className: "form-label"
    }, "Week *"), /*#__PURE__*/React.createElement("select", {
      className: "form-input",
      value: periodLabel,
      onChange: e => setPeriodLabel(e.target.value)
    }, /*#__PURE__*/React.createElement("option", {
      value: ""
    }, "\u2014 Select Week \u2014"), Array.from({
      length: 20
    }, (_, i) => `Week ${i + 1}`).map(w => /*#__PURE__*/React.createElement("option", {
      key: w,
      value: w
    }, w))));
  }
  // daily
  return /*#__PURE__*/React.createElement("div", {
    className: "form-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Date *"), /*#__PURE__*/React.createElement("input", {
    className: "form-input",
    type: "date",
    value: assessmentDate,
    onChange: e => {
      const iso = e.target.value;
      setAssessmentDate(iso);
      setPeriodLabel(iso ? formatDateLabel(iso) : '');
    }
  }), periodLabel && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--blue)',
      marginTop: 4
    }
  }, "Period label: ", /*#__PURE__*/React.createElement("b", null, periodLabel)));
}

/* ════════════════════════════════
   CREATE ASSESSMENT MODAL
════════════════════════════════ */
function CreateAssessmentModal({
  open,
  onClose,
  subjects,
  terms,
  academicYear,
  onCreated
}) {
  const EMPTY = {
    title: '',
    subject_id: '',
    assessment_type: 'daily',
    period_label: '',
    assessment_date: '',
    term: '',
    academic_year: '',
    max_score: '100'
  };
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [alert, setAlert] = useState(null);
  useEffect(() => {
    if (open) {
      setForm(f => ({
        ...f,
        term: terms[0] || '',
        academic_year: academicYear || ''
      }));
      setAlert(null);
    }
  }, [open]);
  function setF(k, v) {
    setForm(f => ({
      ...f,
      [k]: v
    }));
  }
  function setPeriodLabel(v) {
    setF('period_label', v);
  }
  function setAssessmentDate(v) {
    setF('assessment_date', v);
  }
  async function handleCreate() {
    if (!form.title.trim()) {
      setAlert({
        type: 'error',
        msg: 'Title is required.'
      });
      return;
    }
    if (!form.subject_id) {
      setAlert({
        type: 'error',
        msg: 'Select a subject.'
      });
      return;
    }
    if (!form.period_label) {
      setAlert({
        type: 'error',
        msg: 'Select a period.'
      });
      return;
    }
    if (!form.term) {
      setAlert({
        type: 'error',
        msg: 'Select a term.'
      });
      return;
    }
    setSaving(true);
    setAlert(null);
    try {
      const d = await api({}, 'POST', {
        action: 'create_assessment',
        ...form,
        subject_id: parseInt(form.subject_id),
        max_score: parseFloat(form.max_score),
        assessment_date: form.assessment_date || null
      });
      if (d.success) {
        onCreated && onCreated();
        onClose();
      } else setAlert({
        type: 'error',
        msg: d.error || 'Failed to create.'
      });
    } catch (e) {
      setAlert({
        type: 'error',
        msg: e.message || 'Network error.'
      });
    } finally {
      setSaving(false);
    }
  }
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: e => e.target === e.currentTarget && onClose()
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "modal-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 18
  }), " New Assessment"), /*#__PURE__*/React.createElement("button", {
    className: "modal-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "modal-body"
  }, alert && /*#__PURE__*/React.createElement(Alert, _extends({}, alert, {
    onClose: () => setAlert(null)
  })), /*#__PURE__*/React.createElement("div", {
    className: "form-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Title *"), /*#__PURE__*/React.createElement("input", {
    className: "form-input",
    value: form.title,
    onChange: e => setF('title', e.target.value),
    placeholder: "e.g. Week 3 Mathematics Exercise"
  })), /*#__PURE__*/React.createElement("div", {
    className: "form-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Subject *"), /*#__PURE__*/React.createElement("select", {
    className: "form-input",
    value: form.subject_id,
    onChange: e => setF('subject_id', e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "\u2014 Select \u2014"), subjects.map(s => /*#__PURE__*/React.createElement("option", {
    key: s.id,
    value: s.id
  }, s.subject_name)))), /*#__PURE__*/React.createElement("div", {
    className: "form-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Type *"), /*#__PURE__*/React.createElement("select", {
    className: "form-input",
    value: form.assessment_type,
    onChange: e => {
      setF('assessment_type', e.target.value);
      setF('period_label', '');
      setF('assessment_date', '');
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "daily"
  }, "Daily"), /*#__PURE__*/React.createElement("option", {
    value: "weekly"
  }, "Weekly"), /*#__PURE__*/React.createElement("option", {
    value: "midterm"
  }, "Mid-term"), /*#__PURE__*/React.createElement("option", {
    value: "terminal"
  }, "Terminal")))), /*#__PURE__*/React.createElement("div", {
    className: "form-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Term *"), /*#__PURE__*/React.createElement("select", {
    className: "form-input",
    value: form.term,
    onChange: e => setF('term', e.target.value)
  }, terms.map(t => /*#__PURE__*/React.createElement("option", {
    key: t,
    value: t
  }, t)))), /*#__PURE__*/React.createElement("div", {
    className: "form-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Max Score *"), /*#__PURE__*/React.createElement("input", {
    className: "form-input",
    type: "number",
    min: "1",
    max: "1000",
    value: form.max_score,
    onChange: e => setF('max_score', e.target.value)
  }))), /*#__PURE__*/React.createElement(PeriodPicker, {
    type: form.assessment_type,
    term: form.term,
    periodLabel: form.period_label,
    setPeriodLabel: setPeriodLabel,
    assessmentDate: form.assessment_date,
    setAssessmentDate: setAssessmentDate
  }), /*#__PURE__*/React.createElement("div", {
    className: "alert alert-info",
    style: {
      marginBottom: 0
    }
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCA1",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "Grade slots are auto-created for all active students in your class."))), /*#__PURE__*/React.createElement("div", {
    className: "modal-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-primary btn-ghost",
    onClick: onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "btn-primary",
    onClick: handleCreate,
    disabled: saving
  }, saving ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "spinner",
    style: {
      width: 14,
      height: 14,
      border: '2px solid rgba(255,255,255,.4)',
      borderTopColor: 'white'
    }
  }), " Creating\u2026") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 16
  }), "Create")))));
}

/* ════════════════════════════════
   GRADE ENTRY MODAL
════════════════════════════════ */
function GradeEntryModal({
  open,
  onClose,
  assessmentId,
  onSaved
}) {
  const [data, setData] = useState(null);
  const [grades, setGrades] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [alert, setAlert] = useState(null);
  useEffect(() => {
    if (!open || !assessmentId) return;
    setLoading(true);
    setAlert(null);
    api({
      action: 'assessment_grades',
      assessment_id: assessmentId
    }).then(d => {
      if (d.success) {
        setData(d.data);
        const init = {};
        (d.data.grades || []).forEach(g => {
          init[g.student_id] = {
            score: g.score !== null ? String(g.score) : '',
            remarks: g.remarks || ''
          };
        });
        setGrades(init);
      } else setAlert({
        type: 'error',
        msg: d.error || 'Failed to load.'
      });
    }).catch(e => setAlert({
      type: 'error',
      msg: e.message || 'Network error.'
    })).finally(() => setLoading(false));
  }, [open, assessmentId]);
  async function updateGrade(sid, field, val) {
    setGrades(g => ({
      ...g,
      [sid]: {
        ...(g[sid] || {}),
        [field]: val
      }
    }));
  }
  async function handleSave() {
    if (!data) return;
    setSaving(true);
    setAlert(null);
    const gradesArr = async (data.grades || []).map(g => ({
      student_id: g.student_id,
      score: grades[g.student_id]?.score !== '' ? grades[g.student_id]?.score : null,
      remarks: grades[g.student_id]?.remarks || ''
    }));
    try {
      const d = await api({}, 'POST', {
        action: 'save_grades',
        assessment_id: assessmentId,
        grades: gradesArr
      });
      if (d.success) {
        setAlert({
          type: 'success',
          msg: 'Grades saved.'
        });
        onSaved && onSaved();
      } else setAlert({
        type: 'error',
        msg: d.error || 'Failed to save.'
      });
    } catch (e) {
      setAlert({
        type: 'error',
        msg: e.message || 'Network error.'
      });
    } finally {
      setSaving(false);
    }
  }
  async function handlePublish() {
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Publish assessment?', message: 'Publish this assessment? Scores will be locked and included in student progress.', confirmLabel: 'Publish', variant: 'warn' }) : Promise.resolve(false)))) return;
    setPublishing(true);
    setAlert(null);
    await handleSave();
    try {
      const d = await api({}, 'POST', {
        action: 'publish_assessment',
        assessment_id: assessmentId
      });
      if (d.success) {
        setAlert({
          type: 'success',
          msg: /*#__PURE__*/React.createElement("span", {
            style: {
              display: "inline-flex",
              alignItems: "center",
              gap: 6
            }
          }, /*#__PURE__*/React.createElement(Icon, {
            emoji: "\u2705",
            size: 16
          }), "Published! Student performances updated.")
        });
        if (data) setData(prev => ({
          ...prev,
          assessment: {
            ...prev.assessment,
            is_published: 1
          }
        }));
        onSaved && onSaved();
      } else setAlert({
        type: 'error',
        msg: d.error || 'Publish failed.'
      });
    } catch (e) {
      setAlert({
        type: 'error',
        msg: e.message || 'Network error.'
      });
    } finally {
      setPublishing(false);
    }
  }
  if (!open) return null;
  const asm = data?.assessment;
  const isPublished = asm && parseInt(asm.is_published) === 1;
  const maxScore = asm ? parseFloat(asm.max_score) : 100;
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: e => e.target === e.currentTarget && onClose()
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal modal-lg"
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "modal-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  }), " ", asm ? asm.title : 'Grade Entry'), asm && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-soft)',
      marginTop: 3,
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(TypeBadge, {
    type: asm.assessment_type
  }), /*#__PURE__*/React.createElement("span", {
    className: "period-chip",
    style: {
      background: '#F1F5F9'
    }
  }, asm.period_label), /*#__PURE__*/React.createElement("span", null, "Max: ", /*#__PURE__*/React.createElement("b", null, asm.max_score)), /*#__PURE__*/React.createElement("span", {
    className: `pub-badge ${isPublished ? 'pub-yes' : 'pub-draft'}`
  }, isPublished ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 16
  }), "Published") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDD",
    size: 16
  }), "Draft")))), /*#__PURE__*/React.createElement("button", {
    className: "modal-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "modal-body",
    style: {
      padding: 0
    }
  }, alert && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 20px'
    }
  }, /*#__PURE__*/React.createElement(Alert, _extends({}, alert, {
    onClose: () => setAlert(null)
  }))), loading ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading\u2026")) : /*#__PURE__*/React.createElement("div", {
    className: "grade-table-wrap"
  }, /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "#"), /*#__PURE__*/React.createElement("th", null, "Student"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'center'
    }
  }, "Score / ", maxScore), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'center'
    }
  }, "Grade"), /*#__PURE__*/React.createElement("th", null, "Remarks"))), /*#__PURE__*/React.createElement("tbody", null, (data?.grades || []).map((g, i) => {
    const entry = grades[g.student_id] || {
      score: '',
      remarks: ''
    };
    const grade = isPublished ? pctToGrade(g.score !== null ? g.score / maxScore * 100 : null) : scoreToGrade(entry.score !== '' ? entry.score : null, maxScore);
    return /*#__PURE__*/React.createElement("tr", {
      key: g.student_id
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        color: 'var(--text-muted)',
        fontSize: 12
      }
    }, i + 1), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "s-cell"
    }, /*#__PURE__*/React.createElement(SAv, {
      student: g
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 600
      }
    }, g.student_name))), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: 'center'
      }
    }, isPublished ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700
      }
    }, g.score !== null ? `${g.score} / ${maxScore}` : '—') : /*#__PURE__*/React.createElement("input", {
      type: "number",
      min: "0",
      max: maxScore,
      step: "0.5",
      className: `score-input ${scoreInputClass(grade)}`,
      value: entry.score,
      placeholder: "\u2014",
      onChange: e => updateGrade(g.student_id, 'score', e.target.value)
    })), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: `grade-pill ${gradeClass(grade)}`
    }, grade || '—')), /*#__PURE__*/React.createElement("td", null, isPublished ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12.5,
        color: 'var(--text-soft)'
      }
    }, g.remarks || '—') : /*#__PURE__*/React.createElement("input", {
      type: "text",
      className: "remarks-input",
      value: entry.remarks,
      placeholder: "Optional\u2026",
      onChange: e => updateGrade(g.student_id, 'remarks', e.target.value)
    })));
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "modal-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-primary btn-ghost",
    onClick: onClose
  }, "Close"), !isPublished && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("button", {
    className: "btn-primary",
    onClick: handleSave,
    disabled: saving || loading
  }, saving ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCBE",
    size: 16
  }), "Saving\u2026") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCBE",
    size: 16
  }), "Save Grades")), /*#__PURE__*/React.createElement("button", {
    className: "btn-primary btn-success",
    onClick: handlePublish,
    disabled: publishing || saving || loading
  }, publishing ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE4",
    size: 16
  }), "Publishing\u2026") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE4",
    size: 16
  }), "Publish"))))));
}

/* ════════════════════════════════
   TAB 1: ASSESSMENTS
════════════════════════════════ */
function TabAssessments({
  subjects,
  terms,
  academicYear,
  classId
}) {
  const [assessments, setAssessments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [alert, setAlert] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [gradingId, setGradingId] = useState(null);
  const [filterType, setFilterType] = useState('');
  const [filterTerm, setFilterTerm] = useState('');

  // Sync filterTerm when terms list arrives (was undefined on first render)
  useEffect(() => {
    if (terms.length > 0 && !filterTerm) setFilterTerm(terms[0]);
  }, [terms]);
  const TYPE_FILTERS = [{
    key: '',
    label: 'All',
    pillCls: 'all'
  }, {
    key: 'daily',
    label: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCC5",
      size: 16
    }), "Daily"),
    pillCls: 'daily'
  }, {
    key: 'weekly',
    label: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDDD3",
      size: 16
    }), "Weekly"),
    pillCls: 'weekly'
  }, {
    key: 'midterm',
    label: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCA",
      size: 16
    }), "Mid-term"),
    pillCls: 'midterm'
  }, {
    key: 'terminal',
    label: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF93",
      size: 16
    }), "Terminal"),
    pillCls: 'terminal'
  }];
  const load = useCallback(() => {
    setLoading(true);
    const params = {
      action: 'assessments'
    };
    if (filterType) params.type = filterType;
    if (filterTerm) params.term = filterTerm;
    if (academicYear) params.academic_year = academicYear;
    api(params).then(d => {
      if (d.success) setAssessments(d.data.assessments || []);else setAlert({
        type: 'error',
        msg: d.error || 'Failed to load.'
      });
    }).catch(e => setAlert({
      type: 'error',
      msg: e.message
    })).finally(() => setLoading(false));
  }, [filterType, filterTerm, academicYear]);
  useEffect(() => {
    load();
  }, [load]);
  async function handleDelete(id) {
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Delete assessment?', message: 'Delete this assessment and all its grades?', confirmLabel: 'Delete', variant: 'danger' }) : Promise.resolve(false)))) return;
    try {
      const d = await api({}, 'POST', {
        action: 'delete_assessment',
        id
      });
      if (d.success) {
        setAlert({
          type: 'success',
          msg: 'Deleted.'
        });
        load();
      } else setAlert({
        type: 'error',
        msg: d.error || 'Delete failed.'
      });
    } catch (e) {
      setAlert({
        type: 'error',
        msg: e.message
      });
    }
  }
  return /*#__PURE__*/React.createElement("div", null, alert && /*#__PURE__*/React.createElement(Alert, _extends({}, alert, {
    onClose: () => setAlert(null)
  })), /*#__PURE__*/React.createElement("div", {
    className: "type-filter"
  }, TYPE_FILTERS.map(f => /*#__PURE__*/React.createElement("button", {
    key: f.key,
    className: `tf-pill ${f.pillCls} ${filterType === f.key ? 'active' : ''}`,
    onClick: () => setFilterType(f.key)
  }, f.label))), /*#__PURE__*/React.createElement("div", {
    className: "controls-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ctrl-label"
  }, "Term:"), /*#__PURE__*/React.createElement("select", {
    className: "ctrl-select",
    value: filterTerm,
    onChange: e => setFilterTerm(e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "All Terms"), terms.map(t => /*#__PURE__*/React.createElement("option", {
    key: t,
    value: t
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    className: "btn-primary",
    onClick: () => setShowCreate(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 18
  }), " New Assessment")), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  }), " Assessments"), /*#__PURE__*/React.createElement("div", {
    className: "card-sub"
  }, assessments.length, " found"))), loading ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading\u2026")) : assessments.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 48
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "No assessments yet."), /*#__PURE__*/React.createElement("button", {
    className: "btn-primary",
    onClick: () => setShowCreate(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 18
  }), " Create First")) : /*#__PURE__*/React.createElement("div", null, assessments.map(a => {
    const gradedPct = a.total_students > 0 ? Math.round(a.graded_count / a.total_students * 100) : 0;
    const isPublished = parseInt(a.is_published) === 1;
    return /*#__PURE__*/React.createElement("div", {
      key: a.id,
      className: "asm-row"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "asm-title"
    }, a.title), /*#__PURE__*/React.createElement("div", {
      className: "asm-meta"
    }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCDA",
      size: 18
    }), " ", a.subject_name), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCC5",
      size: 18
    }), " ", a.term, " \xB7 ", a.academic_year))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement(TypeBadge, {
      type: a.assessment_type
    }), /*#__PURE__*/React.createElement("span", {
      className: "period-chip",
      style: {
        background: '#F1F5F9',
        color: 'var(--text-mid)'
      }
    }, a.period_label)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "prog-text"
    }, a.graded_count, "/", a.total_students, " graded"), /*#__PURE__*/React.createElement("div", {
      className: "prog-bar"
    }, /*#__PURE__*/React.createElement("div", {
      className: "prog-fill",
      style: {
        width: `${gradedPct}%`
      }
    }))), /*#__PURE__*/React.createElement("span", {
      className: `pub-badge ${isPublished ? 'pub-yes' : 'pub-draft'}`
    }, isPublished ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2705",
      size: 16
    }), "Published") : /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCDD",
      size: 16
    }), "Draft")), /*#__PURE__*/React.createElement("button", {
      className: "btn-primary",
      style: {
        fontSize: 12.5,
        padding: '6px 14px'
      },
      onClick: () => setGradingId(a.id)
    }, isPublished ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDC41",
      size: 16
    }), "View") : /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u270F\uFE0F",
      size: 16
    }), "Grade")), !isPublished && /*#__PURE__*/React.createElement("button", {
      className: "btn-primary btn-danger",
      style: {
        fontSize: 12,
        padding: '6px 10px'
      },
      onClick: () => handleDelete(a.id)
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDDD1",
      size: 18
    })));
  }))), /*#__PURE__*/React.createElement(CreateAssessmentModal, {
    open: showCreate,
    onClose: () => setShowCreate(false),
    subjects: subjects,
    terms: terms,
    academicYear: academicYear,
    onCreated: load
  }), /*#__PURE__*/React.createElement(GradeEntryModal, {
    open: !!gradingId,
    onClose: () => setGradingId(null),
    assessmentId: gradingId,
    onSaved: load
  }));
}

/* ════════════════════════════════
   TAB 2: CLASS OVERVIEW
════════════════════════════════ */
function TabClassOverview({
  subjects,
  terms,
  academicYear
}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [term, setTerm] = useState('');

  // Sync when terms arrive
  useEffect(() => {
    if (terms.length > 0 && !term) setTerm(terms[0]);
  }, [terms]);
  useEffect(() => {
    if (!term || !academicYear) return;
    setLoading(true);
    api({
      action: 'class_overview',
      term,
      academic_year: academicYear
    }).then(d => {
      if (d.success) setData(d.data);
    }).catch(() => {}).finally(() => setLoading(false));
  }, [term, academicYear]);
  if (loading) return /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading overview\u2026"));
  if (!data) return null;
  const perfLookup = {};
  (data.performances || []).forEach(p => {
    if (!perfLookup[p.student_id]) perfLookup[p.student_id] = {};
    perfLookup[p.student_id][p.subject_id] = p;
  });
  const activeSubIds = new Set((data.performances || []).map(p => p.subject_id));
  const activeSubs = subjects.filter(s => activeSubIds.has(s.id));
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "controls-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ctrl-label"
  }, "Term:"), /*#__PURE__*/React.createElement("select", {
    className: "ctrl-select",
    value: term,
    onChange: e => setTerm(e.target.value)
  }, terms.map(t => /*#__PURE__*/React.createElement("option", {
    key: t,
    value: t
  }, t))), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-soft)'
    }
  }, data.students.length, " students \xB7 ", activeSubs.length, " subjects")), data.students.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 48
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "No students in class yet.")) : activeSubs.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 48
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "No published grades for ", term, " yet."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-muted)'
    }
  }, "Enter and publish assessments first.")) : /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  }), " Class Overview \u2014 ", term, " \xB7 ", academicYear)), /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: 'auto'
    }
  }, /*#__PURE__*/React.createElement("table", {
    className: "overview-sticky"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      minWidth: 160
    }
  }, "Student"), activeSubs.map(s => /*#__PURE__*/React.createElement("th", {
    key: s.id,
    style: {
      textAlign: 'center',
      minWidth: 90
    }
  }, s.subject_code)), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'center',
      minWidth: 80
    }
  }, "Avg"))), /*#__PURE__*/React.createElement("tbody", null, data.students.map(st => {
    const perfs = perfLookup[st.id] || {};
    const vals = Object.values(perfs).map(p => parseFloat(p.average_score)).filter(v => !isNaN(v));
    const overall = vals.length > 0 ? (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) : null;
    const overallGrade = overall ? pctToGrade(parseFloat(overall)) : null;
    return /*#__PURE__*/React.createElement("tr", {
      key: st.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "s-cell"
    }, /*#__PURE__*/React.createElement(SAv, {
      student: st,
      size: 30
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 600,
        fontSize: 13
      }
    }, st.student_name))), activeSubs.map(s => {
      const p = perfs[s.id];
      const g = p?.grade_letter;
      return /*#__PURE__*/React.createElement("td", {
        key: s.id,
        style: {
          textAlign: 'center'
        }
      }, p ? /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 2
        }
      }, /*#__PURE__*/React.createElement("span", {
        className: `grade-pill ${gradeClass(g)}`,
        style: {
          width: 30,
          height: 30,
          fontSize: 12
        }
      }, g), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 10.5,
          color: 'var(--text-muted)'
        }
      }, p.average_score, "%")) : /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-muted)',
          fontSize: 12
        }
      }, "\u2014"));
    }), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: 'center',
        fontWeight: 800
      }
    }, overall ? /*#__PURE__*/React.createElement("span", {
      className: `grade-pill ${gradeClass(overallGrade)}`,
      style: {
        width: 32,
        height: 32
      }
    }, overallGrade) : '—'));
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 20px',
      borderTop: '1px solid var(--border)',
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap'
    }
  }, ['A', 'B', 'C', 'D', 'E', 'F'].map(g => /*#__PURE__*/React.createElement("div", {
    key: g,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: `grade-pill ${gradeClass(g)}`,
    style: {
      width: 24,
      height: 24,
      fontSize: 11
    }
  }, g), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5,
      color: 'var(--text-muted)'
    }
  }, g === 'A' ? '90–100%' : g === 'B' ? '75–89%' : g === 'C' ? '60–74%' : g === 'D' ? '50–59%' : g === 'E' ? '40–49%' : '0–39%'))))));
}

/* ════════════════════════════════
   TAB 3: STUDENT PROGRESS
════════════════════════════════ */
function TabStudentProgress({
  classId,
  terms,
  academicYear
}) {
  const [students, setStudents] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [progress, setProgress] = useState(null);
  const [loading, setLoading] = useState(false);
  const [studLoad, setStudLoad] = useState(true);
  const [term, setTerm] = useState('');
  const [alert, setAlert] = useState(null);

  // Sync when terms arrive
  useEffect(() => {
    if (terms.length > 0 && !term) setTerm(terms[0]);
  }, [terms]);
  useEffect(() => {
    fetch('/nsms/api/teacher-students.php?action=list').then(r => r.json()).then(d => {
      if (d.success) setStudents(d.data.students || []);
    }).catch(() => {}).finally(() => setStudLoad(false));
  }, []);
  useEffect(() => {
    if (!selectedId || !term || !academicYear) return;
    setLoading(true);
    setProgress(null);
    setAlert(null);
    api({
      action: 'student_progress',
      student_id: selectedId,
      term,
      academic_year: academicYear
    }).then(d => {
      if (d.success) setProgress(d.data);else setAlert({
        type: 'error',
        msg: d.error
      });
    }).catch(e => setAlert({
      type: 'error',
      msg: e.message
    })).finally(() => setLoading(false));
  }, [selectedId, term, academicYear]);
  const assessmentsBySubject = {};
  if (progress) {
    (progress.assessments || []).forEach(a => {
      if (!assessmentsBySubject[a.subject_id]) assessmentsBySubject[a.subject_id] = [];
      assessmentsBySubject[a.subject_id].push(a);
    });
  }
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "controls-row",
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ctrl-label"
  }, "Term:"), /*#__PURE__*/React.createElement("select", {
    className: "ctrl-select",
    value: term,
    onChange: e => setTerm(e.target.value)
  }, terms.map(t => /*#__PURE__*/React.createElement("option", {
    key: t,
    value: t
  }, t)))), /*#__PURE__*/React.createElement("div", {
    className: "split-layout",
    style: {
      gap: 18,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "student-sidebar card",
    style: {
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 14px',
      borderBottom: '1px solid var(--border)',
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--text-muted)',
      textTransform: 'uppercase',
      letterSpacing: '.04em'
    }
  }, "Students"), studLoad ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      height: 13
    }
  })) : students.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.id,
    className: `stu-row ${selectedId === s.id ? 'selected' : ''}`,
    onClick: () => setSelectedId(s.id)
  }, /*#__PURE__*/React.createElement(SAv, {
    student: s,
    size: 30
  }), /*#__PURE__*/React.createElement("span", {
    className: "sname"
  }, s.student_name)))), /*#__PURE__*/React.createElement("div", {
    className: "split-content"
  }, alert && /*#__PURE__*/React.createElement(Alert, _extends({}, alert, {
    onClose: () => setAlert(null)
  })), !selectedId ? /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      background: 'white',
      borderRadius: 12,
      border: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 48
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC48",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "Select a student")) : loading ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading\u2026")) : !progress ? null : progress.subject_performances.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      background: 'white',
      borderRadius: 12,
      border: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 48
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "No published grades for ", term, " yet.")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, progress.subject_performances.map(sp => {
    const assArr = assessmentsBySubject[sp.subject_id] || [];
    // Group by type for this subject
    const byType = {};
    assArr.forEach(a => {
      if (!byType[a.assessment_type]) byType[a.assessment_type] = [];
      byType[a.assessment_type].push(a);
    });
    return /*#__PURE__*/React.createElement("div", {
      key: sp.subject_id,
      className: "card"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '14px 18px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 12,
        borderBottom: '1px solid var(--border)'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 700,
        fontSize: 14,
        color: 'var(--text-dark)'
      }
    }, sp.subject_name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-muted)',
        marginTop: 2
      }
    }, sp.subject_code)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "big-grade"
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: sp.grade_letter === 'A' ? '#059669' : sp.grade_letter === 'B' ? '#2563EB' : sp.grade_letter === 'C' ? '#D97706' : sp.grade_letter ? '#EF4444' : 'var(--text-muted)'
      }
    }, sp.grade_letter || '—'), /*#__PURE__*/React.createElement("span", {
      className: "big-score"
    }, sp.average_score !== null ? `${sp.average_score}%` : 'No data')), sp.performance_level && /*#__PURE__*/React.createElement("span", {
      className: `perf-badge ${perfClass(sp.performance_level)}`
    }, sp.performance_level))), Object.keys(byType).length > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '12px 18px'
      }
    }, Object.entries(byType).map(([type, arr]) => /*#__PURE__*/React.createElement("div", {
      key: type,
      style: {
        marginBottom: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 6
      }
    }, /*#__PURE__*/React.createElement(TypeBadge, {
      type: type
    })), arr.map(a => /*#__PURE__*/React.createElement("div", {
      key: a.assessment_id,
      className: "mini-asm"
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-muted)',
        minWidth: 80
      }
    }, a.period_label), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontSize: 12,
        color: 'var(--text-mid)'
      }
    }, a.title), a.score !== null ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700,
        fontSize: 12.5
      }
    }, a.score, "/", a.max_score), /*#__PURE__*/React.createElement("span", {
      className: `grade-pill ${gradeClass(scoreToGrade(a.score, a.max_score))}`,
      style: {
        width: 26,
        height: 26,
        fontSize: 11
      }
    }, scoreToGrade(a.score, a.max_score))) : /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)',
        fontStyle: 'italic'
      }
    }, "not graded")))))));
  })))));
}

/* ════════════════════════════════
   ROOT APP
════════════════════════════════ */
function GradebookApp() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('assessments');
  const [subjects, setSubjects] = useState([]);
  const [terms, setTerms] = useState([]);
  const [academicYear, setAcademicYear] = useState('');
  const [classId, setClassId] = useState(null);
  const [bootLoading, setBootLoading] = useState(true);
  useEffect(() => {
    Promise.all([api({
      action: 'subjects'
    }), api({
      action: 'terms'
    })]).then(([sd, td]) => {
      if (sd.success) {
        setSubjects(sd.data.subjects || []);
        setClassId(sd.data.class_id || null);
      }
      if (td.success) {
        setTerms(td.data.terms || ['Term 1', 'Term 2']);
        setAcademicYear(td.data.academic_year || '');
      }
    }).catch(() => {}).finally(() => setBootLoading(false));
  }, []);
  const TABS = [{
    key: 'assessments',
    label: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCB",
      size: 16
    }), "Assessments")
  }, {
    key: 'overview',
    label: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCA",
      size: 16
    }), "Class Overview")
  }, {
    key: 'progress',
    label: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDC64",
      size: 16
    }), "Student Progress")
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(TeacherNavbar, {
    activePage: "gradebook",
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(TeacherSidebar, {
    activePage: "gradebook",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: `main-area ${sidebarOpen ? '' : 'collapsed'}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-title-wrap"
  }, /*#__PURE__*/React.createElement("h1", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCD2",
    size: 18
  }), " Gradebook"), /*#__PURE__*/React.createElement("div", {
    className: "page-sub"
  }, bootLoading ? 'Loading…' : `${subjects.length} subjects · ${academicYear}`))), bootLoading ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading gradebook\u2026")) : subjects.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      background: 'white',
      borderRadius: 14,
      border: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 52
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: 16
    }
  }, "No subjects assigned yet"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      textAlign: 'center',
      maxWidth: 340
    }
  }, "Ask the administrator to assign subjects to your account.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-tabs"
  }, TABS.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.key,
    className: `gb-tab ${activeTab === t.key ? 'active' : ''}`,
    onClick: () => setActiveTab(t.key)
  }, t.label))), activeTab === 'assessments' && /*#__PURE__*/React.createElement(TabAssessments, {
    subjects: subjects,
    terms: terms,
    academicYear: academicYear,
    classId: classId
  }), activeTab === 'overview' && /*#__PURE__*/React.createElement(TabClassOverview, {
    subjects: subjects,
    terms: terms,
    academicYear: academicYear
  }), activeTab === 'progress' && /*#__PURE__*/React.createElement(TabStudentProgress, {
    classId: classId,
    terms: terms,
    academicYear: academicYear
  }))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(GradebookApp, null));