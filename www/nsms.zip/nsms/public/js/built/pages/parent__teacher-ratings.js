const { useState, useEffect, useCallback } = React;

function StarPick(props) {
  var value = props.value || 0;
  var onChange = props.onChange;
  var stars = [1, 2, 3, 4, 5];
  return React.createElement('div', { className: 'stars', role: 'radiogroup', 'aria-label': 'Rating' },
    stars.map(function (n) {
      return React.createElement('button', {
        type: 'button',
        key: n,
        className: 'star-btn' + (n <= value ? ' on' : ''),
        onClick: function () { onChange(n); },
        'aria-label': n + ' star' + (n > 1 ? 's' : '')
      }, React.createElement('svg', { viewBox: '0 0 24 24' },
        React.createElement('path', { d: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z' })
      ));
    })
  );
}

function TeacherCard(props) {
  var t = props.teacher;
  var onSaved = props.onSaved;
  var existing = t.my_review;
  var [rating, setRating] = useState(existing ? Math.round(parseFloat(existing.rating)) : 0);
  var [comment, setComment] = useState(existing && existing.comment ? existing.comment : '');
  var [busy, setBusy] = useState(false);
  var [msg, setMsg] = useState('');
  var [err, setErr] = useState('');

  useEffect(function () {
    setRating(existing ? Math.round(parseFloat(existing.rating)) : 0);
    setComment(existing && existing.comment ? existing.comment : '');
  }, [t.id, existing && existing.rating, existing && existing.comment]);

  var initials = (t.full_name || '?').split(' ').map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
  var photo = t.photo_url ? (t.photo_url.indexOf('/') === 0 ? t.photo_url : '/nsms/' + t.photo_url) : null;

  var submit = async function () {
    setErr('');
    setMsg('');
    if (!rating) { setErr('Please select a star rating.'); return; }
    if (!comment || comment.trim().length < 10) { setErr('Please write at least 10 characters.'); return; }
    setBusy(true);
    try {
      var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
      try {
        if (window.NSMS && window.NSMS.getCsrfToken) headers['X-CSRF-Token'] = await window.NSMS.getCsrfToken();
        else if (window.getCsrfToken) headers['X-CSRF-Token'] = await window.getCsrfToken();
      } catch (e) {}
      var r = await fetch('/nsms/api/teacher-ratings.php?action=submit', {
        method: 'POST',
        credentials: 'same-origin',
        headers: headers,
        body: JSON.stringify({ teacher_id: t.id, rating: rating, comment: comment.trim() })
      });
      var d = await r.json();
      if (d.success) {
        setMsg(d.message || 'Saved.');
        if (typeof onSaved === 'function') onSaved();
      } else setErr(d.error || 'Could not save review');
    } catch (e) {
      setErr('Network error');
    }
    setBusy(false);
  };

  return React.createElement('div', { className: 't-card' },
    React.createElement('div', { className: 'av' },
      photo ? React.createElement('img', { src: photo, alt: '' }) : initials
    ),
    React.createElement('div', { className: 't-meta' },
      React.createElement('div', { className: 't-name' }, t.full_name || 'Teacher'),
      t.class_name ? React.createElement('div', { className: 't-class' }, 'Class: ' + t.class_name) : null,
      t.avg_rating != null
        ? React.createElement('div', { className: 't-class' }, 'Average: ' + t.avg_rating + ' / 5 (' + (t.rating_count || 0) + ' reviews)')
        : React.createElement('div', { className: 't-class' }, 'No public reviews yet'),
      React.createElement(StarPick, { value: rating, onChange: setRating }),
      React.createElement('textarea', {
        placeholder: 'Share your experience with this teacher (visible on the school website)…',
        value: comment,
        onChange: function (e) { setComment(e.target.value); },
        maxLength: 1000
      }),
      React.createElement('div', { className: 'hint' }, 'Reviews appear on the public landing page. Be respectful and constructive.'),
      err ? React.createElement('div', { className: 'err', style: { marginTop: 10 } }, err) : null,
      msg ? React.createElement('div', { className: 'ok', style: { marginTop: 10 } }, msg) : null,
      existing ? React.createElement('div', { className: 'pub' }, 'You already rated this teacher — submitting again updates your review.') : null,
      React.createElement('div', { style: { marginTop: 12 } },
        React.createElement('button', {
          type: 'button',
          className: 'btn btn-p',
          disabled: busy,
          onClick: submit
        }, busy ? 'Saving…' : (existing ? 'Update review' : 'Submit review'))
      )
    )
  );
}

function RatingsPage() {
  var [sidebarOpen, setSidebarOpen] = useState(false);
  var [loading, setLoading] = useState(true);
  var [teachers, setTeachers] = useState([]);
  var [err, setErr] = useState('');

  var load = useCallback(function () {
    setLoading(true);
    fetch('/nsms/api/teacher-ratings.php?action=my_teachers', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d.success) setTeachers(Array.isArray(d.data) ? d.data : []);
        else setErr(d.error || 'Failed to load teachers');
      })
      .catch(function () { setErr('Network error'); })
      .finally(function () { setLoading(false); });
  }, []);

  useEffect(function () { load(); }, [load]);

  return React.createElement(React.Fragment, null,
    React.createElement(ParentNavbar, { activePage: 'teacher_ratings', sidebarOpen: sidebarOpen, setSidebarOpen: setSidebarOpen }),
    React.createElement(ParentSidebar, { activePage: 'teacher_ratings', sidebarOpen: sidebarOpen }),
    React.createElement('div', { className: 'page-body' + (sidebarOpen ? ' expanded' : '') },
      React.createElement('div', { className: 'ph' },
        React.createElement('h1', null, 'Rate Teachers'),
        React.createElement('div', { className: 'ph-sub' },
          'Rate only the class teacher of your child\'s class. Your review can appear on the public school website.'
        )
      ),
      err ? React.createElement('div', { className: 'err' }, err) : null,
      loading
        ? React.createElement('div', { className: 'sw' }, React.createElement('div', { className: 'spinner' }))
        : (teachers.length === 0
            ? React.createElement('div', { className: 'empty' }, 'No class teacher is assigned for your child yet. Once the school assigns a class teacher, you can rate them here.')
            : teachers.map(function (t) {
                return React.createElement(TeacherCard, { key: t.id, teacher: t, onSaved: load });
              })
          )
    )
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(RatingsPage));
