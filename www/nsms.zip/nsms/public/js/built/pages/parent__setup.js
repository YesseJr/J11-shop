function renderIcon(v, size) {
  size = size || 18;
  if (v == null || v === '') return null;
  if (typeof v === 'object') return v;
  if (typeof Icon === 'function') {
    return React.createElement(Icon, {
      emoji: String(v),
      size: size,
      name: window.NSMS_EMOJI_MAP && window.NSMS_EMOJI_MAP[v] || undefined
    });
  }
  return null;
}
var useState = React.useState;
var useEffect = React.useEffect;
var useRef = React.useRef;

// ── Password strength calculator ──────────────────────────────────────────────
function calcStrength(pw) {
  if (!pw) return 0;
  var score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return Math.min(Math.floor(score / 1.25), 4);
}
var strengthLabels = ['', 'Weak', 'Fair', 'Good', 'Strong'];
var strengthColors = ['', '#EF4444', '#F59E0B', '#3B82F6', '#10B981'];

// ── Main component ────────────────────────────────────────────────────────────
function SetupPage() {
  var schoolS = useState({
    school_name: 'NSMS',
    school_tagline: 'Management System'
  });
  var schoolInfo = schoolS[0];
  var setSchoolInfo = schoolS[1];
  var parentS = useState(null);
  var parent = parentS[0];
  var setParent = parentS[1];
  var newPwS = useState('');
  var newPw = newPwS[0];
  var setNewPw = newPwS[1];
  var confirmS = useState('');
  var confirm = confirmS[0];
  var setConfirm = confirmS[1];
  var showNS = useState(false);
  var showN = showNS[0];
  var setShowN = showNS[1];
  var showCS = useState(false);
  var showC = showCS[0];
  var setShowC = showCS[1];
  var loadingS = useState(true);
  var loading = loadingS[0];
  var setLoading = loadingS[1];
  var savingS = useState(false);
  var saving = savingS[0];
  var setSaving = savingS[1];
  var alertS = useState(null);
  var alert = alertS[0];
  var setAlert = alertS[1];
  var doneS = useState(false);
  var done = doneS[0];
  var setDone = doneS[1];
  var strength = calcStrength(newPw);

  // Check requirements
  var reqs = [{
    id: 'len',
    label: 'At least 8 characters',
    met: newPw.length >= 8
  }, {
    id: 'case',
    label: 'Uppercase and lowercase letters',
    met: /[A-Z]/.test(newPw) && /[a-z]/.test(newPw)
  }, {
    id: 'num',
    label: 'At least one number',
    met: /[0-9]/.test(newPw)
  }, {
    id: 'match',
    label: 'Passwords match',
    met: confirm.length > 0 && newPw === confirm
  }];
  var allMet = reqs.every(function (r) {
    return r.met;
  });

  // Fetch school info + verify parent session
  useEffect(function () {
    fetch('/nsms/api/settings.php?action=get_public').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success && d.data) setSchoolInfo(d.data);
    }).catch(function () {});
    fetch('/nsms/api/parent-panel.php?action=session').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) {
        // Not logged in or not a parent
        window.location.href = '/nsms/public/index.html?login=1';
        return;
      }
      if (d.data && d.data.password_changed == 1) {
        // Already activated — go to parent dashboard
        window.location.href = '/nsms/public/parent/dashboard.html';
        return;
      }
      setParent(d.data);
    }).catch(function () {
      window.location.href = '/nsms/public/index.html?login=1';
    }).finally(function () {
      setLoading(false);
    });
  }, []);

  // Redirect to login after success
  useEffect(function () {
    if (!done) return;
    var timer = setTimeout(function () {
      window.location.href = '/nsms/public/index.html?login=1';
    }, 3000);
    return function () {
      clearTimeout(timer);
    };
  }, [done]);
  function handleSubmit() {
    setAlert(null);
    if (!allMet) {
      setAlert({
        type: 'error',
        msg: 'Please meet all password requirements before continuing.'
      });
      return;
    }
    setSaving(true);
    fetch('/nsms/api/parent-panel.php?action=setup_password', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        new_password: newPw,
        confirm_password: confirm
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setDone(true);
      } else {
        setAlert({
          type: 'error',
          msg: d.error || 'Something went wrong. Please try again.'
        });
      }
    }).catch(function () {
      setAlert({
        type: 'error',
        msg: 'Network error. Please try again.'
      });
    }).finally(function () {
      setSaving(false);
    });
  }
  if (loading) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 40,
        height: 40,
        borderRadius: '50%',
        border: '3px solid #E2E8F0',
        borderTopColor: '#2563EB',
        animation: 'spin .7s linear infinite',
        margin: '0 auto 14px'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: '#64748B',
        fontFamily: 'Plus Jakarta Sans, sans-serif'
      }
    }, "Verifying your account\u2026")));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-top"
  }, /*#__PURE__*/React.createElement("div", {
    className: "logo-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "logo-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "logo-text"
  }, /*#__PURE__*/React.createElement("div", {
    className: "school-name"
  }, schoolInfo.school_name || 'Our School'), /*#__PURE__*/React.createElement("div", {
    className: "school-sub"
  }, schoolInfo.school_tagline || 'Management System'))), !done ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h1", null, "Welcome, ", parent ? parent.full_name.split(' ')[0] : 'Parent', "! ", /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC4B",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "Before you continue, you need to create your personal password to activate your parent account.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h1", null, "You're all set!"), /*#__PURE__*/React.createElement("p", null, "Your account is now active. You'll be redirected to the login page shortly."))), /*#__PURE__*/React.createElement("div", {
    className: "card-body"
  }, !done && /*#__PURE__*/React.createElement("div", {
    className: "steps"
  }, /*#__PURE__*/React.createElement("div", {
    className: "step"
  }, /*#__PURE__*/React.createElement("div", {
    className: "step-dot done"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "step-label"
  }, "Logged In")), /*#__PURE__*/React.createElement("div", {
    className: "step-line done"
  }), /*#__PURE__*/React.createElement("div", {
    className: "step"
  }, /*#__PURE__*/React.createElement("div", {
    className: "step-dot active"
  }, "2"), /*#__PURE__*/React.createElement("span", {
    className: "step-label active"
  }, "Activate Account")), /*#__PURE__*/React.createElement("div", {
    className: "step-line"
  }), /*#__PURE__*/React.createElement("div", {
    className: "step"
  }, /*#__PURE__*/React.createElement("div", {
    className: "step-dot pending"
  }, "3"), /*#__PURE__*/React.createElement("span", {
    className: "step-label"
  }, "Dashboard"))), alert && /*#__PURE__*/React.createElement("div", {
    className: 'alert alert-' + alert.type
  }, /*#__PURE__*/React.createElement("span", {
    className: "alert-icon"
  }, alert.type === 'error' ? /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0",
    size: 16
  }) : '✅'), /*#__PURE__*/React.createElement("span", null, alert.msg)), done ? /*#__PURE__*/React.createElement("div", {
    className: "success-screen"
  }, /*#__PURE__*/React.createElement("div", {
    className: "success-icon-wrap"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), /*#__PURE__*/React.createElement("h2", null, "Account Activated!"), /*#__PURE__*/React.createElement("p", null, "You can now log in with your new password.", /*#__PURE__*/React.createElement("br", null), "Redirecting to the login page\u2026"), /*#__PURE__*/React.createElement("div", {
    className: "redirect-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "redirect-fill"
  })), /*#__PURE__*/React.createElement("div", {
    className: "redirect-note"
  }, "Redirecting in 3 seconds\u2026")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "New Password"), /*#__PURE__*/React.createElement("div", {
    className: "input-wrap"
  }, /*#__PURE__*/React.createElement("input", {
    className: 'form-input' + (newPw && !reqs[0].met ? ' err' : newPw && reqs[0].met ? ' ok' : ''),
    type: showN ? 'text' : 'password',
    value: newPw,
    onChange: function (e) {
      setNewPw(e.target.value);
      setAlert(null);
    },
    placeholder: "Create your password"
  }), /*#__PURE__*/React.createElement("button", {
    className: "eye-btn",
    onClick: function () {
      setShowN(!showN);
    }
  }, showN ? typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '🙈',
    size: 16
  }) : null : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '👁',
    size: 16
  }) : null)), newPw.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: 'strength-row strength-' + strength
  }, /*#__PURE__*/React.createElement("div", {
    className: "strength-bars"
  }, /*#__PURE__*/React.createElement("div", {
    className: "strength-bar"
  }), /*#__PURE__*/React.createElement("div", {
    className: "strength-bar"
  }), /*#__PURE__*/React.createElement("div", {
    className: "strength-bar"
  }), /*#__PURE__*/React.createElement("div", {
    className: "strength-bar"
  })), /*#__PURE__*/React.createElement("span", {
    className: "strength-label",
    style: {
      color: strengthColors[strength] || '#94A3B8'
    }
  }, strengthLabels[strength] || '')), /*#__PURE__*/React.createElement("div", {
    className: "req-list"
  }, reqs.slice(0, 3).map(function (r) {
    return /*#__PURE__*/React.createElement("div", {
      key: r.id,
      className: 'req-item' + (r.met ? ' met' : '')
    }, /*#__PURE__*/React.createElement("div", {
      className: "req-dot"
    }), /*#__PURE__*/React.createElement("span", null, r.label));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Confirm Password"), /*#__PURE__*/React.createElement("div", {
    className: "input-wrap"
  }, /*#__PURE__*/React.createElement("input", {
    className: 'form-input' + (confirm && !reqs[3].met ? ' err' : confirm && reqs[3].met ? ' ok' : ''),
    type: showC ? 'text' : 'password',
    value: confirm,
    onChange: function (e) {
      setConfirm(e.target.value);
      setAlert(null);
    },
    placeholder: "Re-enter your new password"
  }), /*#__PURE__*/React.createElement("button", {
    className: "eye-btn",
    onClick: function () {
      setShowC(!showC);
    }
  }, showC ? typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '🙈',
    size: 16
  }) : null : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '👁',
    size: 16
  }) : null)), confirm.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: 'req-item' + (reqs[3].met ? ' met' : ''),
    style: {
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "req-dot"
  }), /*#__PURE__*/React.createElement("span", null, reqs[3].label))), /*#__PURE__*/React.createElement("button", {
    className: "submit-btn",
    onClick: handleSubmit,
    disabled: saving || !allMet
  }, saving ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "spin"
  }), "Saving\u2026") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD10",
    size: 18
  }), " Activate My Account")))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(SetupPage, null));