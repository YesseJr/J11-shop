var useState = React.useState;
var useEffect = React.useEffect;
var useRef = React.useRef;
var API = '/nsms/api/admin-messages.php';

/* ─── Helpers ─── */
var AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2', '#DB2777'];
function avColor(n) {
  return n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
}
function initials(n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
}
function fmtBytes(b) {
  if (b < 1024) return b + 'B';
  if (b < 1048576) return (b / 1024).toFixed(1) + 'KB';
  return (b / 1048576).toFixed(1) + 'MB';
}
function fmtConvTime(iso) {
  if (!iso) return '';
  var d = new Date(iso),
    now = new Date();
  if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
  var yest = new Date(now);
  yest.setDate(now.getDate() - 1);
  if (d.toDateString() === yest.toDateString()) return 'Yesterday';
  if (d.getFullYear() === now.getFullYear()) return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short'
  });
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}
function fmtMsgTime(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  var t = d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
  return d.toDateString() === new Date().toDateString() ? t : fmtConvTime(iso) + ', ' + t;
}
function dateSepLabel(iso) {
  if (!iso) return '';
  var d = new Date(iso),
    now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today';
  var yest = new Date(now);
  yest.setDate(now.getDate() - 1);
  if (d.toDateString() === yest.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long'
  });
}
function sameDay(a, b) {
  return new Date(a).toDateString() === new Date(b).toDateString();
}
function fileIcon(mime) {
  if (!mime) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📄',
    size: 18
  }) : null;
  if (mime.startsWith('image/')) return /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDDBC",
    size: 16
  });
  if (mime === 'application/pdf') return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📕',
    size: 18
  }) : null;
  if (mime.includes('word')) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📝',
    size: 18
  }) : null;
  if (mime.includes('excel') || mime.includes('spreadsheet')) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📊',
    size: 18
  }) : null;
  return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📎',
    size: 18
  }) : null;
}
function isImage(mime) {
  return mime && mime.startsWith('image/');
}

/* ─── Contact Avatar ─── */
function CAvatar(props) {
  var contact = props.contact,
    size = props.size || 42,
    isOnline = props.isOnline;
  return /*#__PURE__*/React.createElement("div", {
    className: "av-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "c-avatar",
    style: {
      width: size,
      height: size,
      background: avColor(contact.full_name || contact.contact_name),
      fontSize: Math.round(size * .35)
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, initials(contact.full_name || contact.contact_name || '?')), (contact.photo_url || contact.contact_photo) && /*#__PURE__*/React.createElement("img", {
    src: contact.photo_url || contact.contact_photo,
    alt: "",
    onError: function (e) {
      e.currentTarget.style.display = 'none';
    }
  })), isOnline && /*#__PURE__*/React.createElement("div", {
    className: "online-dot"
  }));
}

/* ─── File bubble contents ─── */
function FileBubble(props) {
  var f = props.file,
    isMine = props.isMine,
    onImg = props.onImg;
  if (isImage(f.mime_type)) {
    return /*#__PURE__*/React.createElement("img", {
      className: "img-preview",
      src: f.url,
      alt: f.original_name,
      onClick: function () {
        onImg(f.url);
      },
      onError: function (e) {
        e.currentTarget.style.display = 'none';
      }
    });
  }
  return /*#__PURE__*/React.createElement("a", {
    className: "file-card",
    href: f.url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "file-icon"
  }, fileIcon(f.mime_type)), /*#__PURE__*/React.createElement("div", {
    className: "file-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "file-name"
  }, f.original_name), /*#__PURE__*/React.createElement("div", {
    className: "file-size"
  }, fmtBytes(f.file_size))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      opacity: .6
    }
  }, "\u2193"));
}

/* ─── Shimmer ─── */
function ShimmerConvs() {
  return /*#__PURE__*/React.createElement(React.Fragment, null, [1, 2, 3, 4].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 11,
        padding: '13px 16px',
        borderBottom: '1px solid #F1F5F9'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 42,
        height: 42,
        borderRadius: '50%'
      },
      className: "shimmer"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "sh shimmer",
      style: {
        width: '55%',
        marginBottom: 7
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "sh shimmer",
      style: {
        width: '80%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "sh shimmer",
      style: {
        width: '65%',
        height: 11
      }
    })));
  }));
}

/* ════════════════════════════════════════════
   NEW MESSAGE MODAL
════════════════════════════════════════════ */
function NewMessageModal(props) {
  var contacts = props.contacts,
    onClose = props.onClose,
    onSent = props.onSent;
  var recipSt = useState('');
  var recipId = recipSt[0];
  var setRecipId = recipSt[1];
  var subjSt = useState('');
  var subject = subjSt[0];
  var setSubject = subjSt[1];
  var bodySt = useState('');
  var body = bodySt[0];
  var setBody = bodySt[1];
  var sendSt = useState(false);
  var sending = sendSt[0];
  var setSending = sendSt[1];
  var errSt = useState('');
  var err = errSt[0];
  var setErr = errSt[1];
  function handleSend() {
    if (!recipId) {
      setErr('Please select a recipient.');
      return;
    }
    if (!body.trim()) {
      setErr('Please enter a message.');
      return;
    }
    setSending(true);
    setErr('');
    fetch(API + '?action=send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        recipient_id: parseInt(recipId),
        subject: subject.trim(),
        message: body.trim()
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        onSent(parseInt(recipId));
        onClose();
      } else setErr(d.error || 'Failed to send.');
    }).catch(function () {
      setErr('Network error.');
    }).finally(function () {
      setSending(false);
    });
  }

  /* Group contacts by role_group */
  var groups = {};
  contacts.forEach(function (c) {
    var g = c.role_group || (c.role === 'admin' ? 'Administration' : c.role === 'teacher' ? 'Teachers' : 'Parents');
    if (!groups[g]) groups[g] = [];
    groups[g].push(c);
  });
  var groupOrder = ['Administration', 'Teachers', 'Parents'];
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: function (e) {
      if (e.target === e.currentTarget) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "modal-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2709\uFE0F",
    size: 18
  }), " New Message"), /*#__PURE__*/React.createElement("button", {
    className: "modal-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "modal-body"
  }, err && /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FEF2F2',
      border: '1.5px solid #FCA5A5',
      borderRadius: 8,
      padding: '10px 14px',
      color: '#991B1B',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", err), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "To ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("div", {
    className: "select-wrap"
  }, /*#__PURE__*/React.createElement("select", {
    className: "field-select",
    value: recipId,
    onChange: function (e) {
      setRecipId(e.target.value);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Select recipient\u2026"), groupOrder.filter(function (g) {
    return groups[g] && groups[g].length > 0;
  }).map(function (g) {
    return /*#__PURE__*/React.createElement("optgroup", {
      key: g,
      label: g
    }, groups[g].map(function (c) {
      var label = c.full_name;
      if (c.student_name) label += ' (Parent of ' + c.student_name + ')';
      if (c.class_name) label += ' — ' + c.class_name;
      return /*#__PURE__*/React.createElement("option", {
        key: c.id,
        value: c.id
      }, label);
    }));
  })))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Subject"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "field-input",
    placeholder: "Message subject (optional)\u2026",
    value: subject,
    onChange: function (e) {
      setSubject(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Message ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "field-textarea",
    placeholder: "Type your message here\u2026",
    value: body,
    onChange: function (e) {
      setBody(e.target.value);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "modal-foot"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-cancel",
    onClick: onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "btn-primary",
    onClick: handleSend,
    disabled: sending
  }, sending ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "btn-spinner"
  }), "Sending\u2026") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2709\uFE0F",
    size: 18
  }), " Send Message")))));
}

/* ════════════════════════════════════════════
   MAIN PAGE
════════════════════════════════════════════ */
function AdminMessagesPage() {
  var sbSt = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  var sidebarOpen = sbSt[0];
  var setSidebarOpen = sbSt[1];
  var myIdSt = useState(null);
  var myId = myIdSt[0];
  var setMyId = myIdSt[1];
  var convsSt = useState([]);
  var convs = convsSt[0];
  var setConvs = convsSt[1];
  var contactsSt = useState([]);
  var contacts = contactsSt[0];
  var setContacts = contactsSt[1];
  var activeSt = useState(null);
  var activeId = activeSt[0];
  var setActiveId = activeSt[1];
  var threadSt = useState([]);
  var thread = threadSt[0];
  var setThread = threadSt[1];
  var loadConvSt = useState(true);
  var loadConvs = loadConvSt[0];
  var setLoadConvs = loadConvSt[1];
  var loadThrdSt = useState(false);
  var loadThread = loadThrdSt[0];
  var setLoadThread = loadThrdSt[1];
  var composeSt = useState('');
  var compose = composeSt[0];
  var setCompose = composeSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  var searchSt = useState('');
  var search = searchSt[0];
  var setSearch = searchSt[1];
  var newMsgSt = useState(false);
  var showNewMsg = newMsgSt[0];
  var setShowNewMsg = newMsgSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];
  var onlineSt = useState(false);
  var contactOnline = onlineSt[0];
  var setContactOnline = onlineSt[1];
  var typingSt = useState(false);
  var contactTyping = typingSt[0];
  var setContactTyping = typingSt[1];
  var pendFileSt = useState(null);
  var pendFile = pendFileSt[0];
  var setPendFile = pendFileSt[1];
  var lightboxSt = useState(null);
  var lightbox = lightboxSt[0];
  var setLightbox = lightboxSt[1];
  var messagesEndRef = useRef(null);
  var pollRef = useRef(null);
  var typingTimer = useRef(null);
  var typingSentAt = useRef(0);
  var fileInputRef = useRef(null);
  var lastMsgId = useRef(0);
  var heartbeatRef = useRef(null);

  /* Active contact object */
  var activeContact = contacts.find(function (c) {
    return c.id === activeId;
  }) || convs.find(function (c) {
    return c.contact_id === activeId;
  }) || {};

  /* ── Initial load ── */
  useEffect(function () {
    /* Get admin user id from session */
    fetch('/nsms/api/navbar.php').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success && d.data && d.data.user) setMyId(d.data.user.id || null);
    }).catch(function () {});
    Promise.all([fetch(API + '?action=conversations').then(function (r) {
      return r.json();
    }), fetch(API + '?action=contacts').then(function (r) {
      return r.json();
    })]).then(function (res) {
      if (res[0].success) setConvs(res[0].data || []);
      if (res[1].success) setContacts(res[1].data || []);
    }).catch(function () {}).finally(function () {
      setLoadConvs(false);
    });

    /* Heartbeat every 30s */
    heartbeatRef.current = setInterval(function () {
      fetch(API + '?action=heartbeat', {
        method: 'POST'
      }).catch(function () {});
    }, 30000);
    return function () {
      clearInterval(heartbeatRef.current);
    };
  }, []);

  /* ── Load thread when active changes ── */
  useEffect(function () {
    if (!activeId) return;
    setLoadThread(true);
    setThread([]);
    setContactOnline(false);
    setContactTyping(false);
    fetch(API + '?action=thread&contact_id=' + activeId).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        var msgs = d.data.messages || [];
        setThread(msgs);
        setContactOnline(!!d.data.contact_online);
        if (msgs.length > 0) lastMsgId.current = msgs[msgs.length - 1].id;
        fetch(API + '?action=mark_read&contact_id=' + activeId, {
          method: 'POST'
        }).catch(function () {});
        setConvs(function (prev) {
          return prev.map(function (c) {
            return c.contact_id === activeId ? Object.assign({}, c, {
              unread_count: 0
            }) : c;
          });
        });
      }
    }).catch(function () {}).finally(function () {
      setLoadThread(false);
    });
  }, [activeId]);

  /* ── Scroll to bottom when thread updates ── */
  useEffect(function () {
    if (messagesEndRef.current) messagesEndRef.current.scrollIntoView({
      behavior: 'smooth'
    });
  }, [thread]);

  /* ── Poll: incremental thread updates every 4s ── */
  useEffect(function () {
    if (!activeId) return;
    pollRef.current = setInterval(function () {
      fetch(API + '?action=thread_updates&contact_id=' + activeId + '&since_id=' + lastMsgId.current).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (!d.success) return;
        /* Online/typing status */
        setContactOnline(!!d.data.contact_online);
        setContactTyping(!!d.data.contact_typing);
        /* New messages */
        var newMsgs = d.data.new_messages || [];
        if (newMsgs.length > 0) {
          lastMsgId.current = newMsgs[newMsgs.length - 1].id;
          setThread(function (prev) {
            return prev.concat(newMsgs);
          });
          /* Mark as read + clear badge */
          fetch(API + '?action=mark_read&contact_id=' + activeId, {
            method: 'POST'
          }).catch(function () {});
          setConvs(function (prev) {
            return prev.map(function (c) {
              return c.contact_id === activeId ? Object.assign({}, c, {
                unread_count: 0
              }) : c;
            });
          });
          /* Refresh conv list preview */
          fetch(API + '?action=conversations').then(function (r) {
            return r.json();
          }).then(function (r2) {
            if (r2.success) setConvs(function (prev) {
              return (r2.data || []).map(function (c) {
                return c.contact_id === activeId ? Object.assign({}, c, {
                  unread_count: 0
                }) : c;
              });
            });
          }).catch(function () {});
        }
      }).catch(function () {});
    }, 4000);
    return function () {
      clearInterval(pollRef.current);
    };
  }, [activeId]);

  /* ── Toast auto-dismiss ── */
  useEffect(function () {
    if (!toast) return;
    var t = setTimeout(function () {
      setToast(null);
    }, 3000);
    return function () {
      clearTimeout(t);
    };
  }, [toast]);

  /* ── Send text message ── */
  function handleSend() {
    if (pendFile) {
      handleSendFile();
      return;
    }
    if (!compose.trim() || !activeId) return;
    var text = compose.trim();
    setSending(true);
    fetch(API + '?action=send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        recipient_id: activeId,
        subject: '',
        message: text
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setCompose('');
        var nm = Object.assign({}, d.data || {
          id: Date.now(),
          sender_id: myId,
          recipient_id: activeId,
          message: text,
          subject: '',
          is_read: 0,
          has_file: 0,
          files: [],
          created_at: new Date().toISOString()
        });
        if (nm.id > lastMsgId.current) lastMsgId.current = nm.id;
        setThread(function (prev) {
          return prev.concat([nm]);
        });
        _updateConvPreview(text, nm.created_at);
      } else {
        setToast({
          type: 'error',
          msg: d.error || 'Failed to send.'
        });
      }
    }).catch(function () {
      setToast({
        type: 'error',
        msg: 'Network error.'
      });
    }).finally(function () {
      setSending(false);
    });
  }

  /* ── Send file ── */
  function handleSendFile() {
    if (!pendFile || !activeId) return;
    setSending(true);
    var fd = new FormData();
    fd.append('recipient_id', activeId);
    fd.append('message', compose.trim());
    fd.append('subject', '');
    fd.append('attachment', pendFile);
    fetch(API + '?action=send_file', {
      method: 'POST',
      body: fd
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setCompose('');
        setPendFile(null);
        var nm = d.data;
        if (nm && nm.id > lastMsgId.current) lastMsgId.current = nm.id;
        setThread(function (prev) {
          return prev.concat([nm]);
        });
        _updateConvPreview('📎 ' + pendFile.name, nm.created_at || new Date().toISOString());
      } else {
        setToast({
          type: 'error',
          msg: d.error || 'Failed to send file.'
        });
      }
    }).catch(function () {
      setToast({
        type: 'error',
        msg: 'Network error.'
      });
    }).finally(function () {
      setSending(false);
    });
  }
  function _updateConvPreview(text, ts) {
    setConvs(function (prev) {
      if (prev.find(function (c) {
        return c.contact_id === activeId;
      })) {
        return prev.map(function (c) {
          return c.contact_id === activeId ? Object.assign({}, c, {
            last_message: text,
            last_at: ts
          }) : c;
        });
      }
      return prev;
    });
  }

  /* Enter = send (Shift+Enter = newline) */
  function onComposeKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  /* Typing indicator — debounced POST every 3s max while typing */
  function onComposeChange(e) {
    setCompose(e.target.value);
    if (!activeId) return;
    var now = Date.now();
    if (now - typingSentAt.current > 3000) {
      typingSentAt.current = now;
      fetch(API + '?action=set_typing&contact_id=' + activeId, {
        method: 'POST'
      }).catch(function () {});
    }
  }

  /* File picker */
  function onFileChange(e) {
    var f = e.target.files[0];
    if (!f) return;
    var maxSize = 10 * 1024 * 1024;
    if (f.size > maxSize) {
      setToast({
        type: 'error',
        msg: 'File too large (max 10 MB)'
      });
      return;
    }
    setPendFile(f);
    e.target.value = '';
  }

  /* After sending from New Message modal */
  function onNewMsgSent(contactId) {
    setToast({
      type: 'success',
      msg: /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u2713",
        size: 16
      }), "Message sent!")
    });
    fetch(API + '?action=conversations').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setConvs(d.data || []);
    }).catch(function () {});
    setActiveId(contactId);
  }
  var filteredConvs = search ? convs.filter(function (c) {
    var q = search.toLowerCase();
    return (c.contact_name || '').toLowerCase().includes(q) || (c.last_message || '').toLowerCase().includes(q) || (c.role_label || '').toLowerCase().includes(q);
  }) : convs;
  var totalUnread = convs.reduce(function (sum, c) {
    return sum + (c.unread_count || 0);
  }, 0);

  /* Determine status string for thread header */
  function statusText() {
    if (contactTyping) return null; /* handled separately */
    if (contactOnline) return 'Online now';
    return null;
  }
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NSMSNavbar, {
    activePage: "messages",
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen,
    onLogout: function () {
      fetch('/nsms/api/auth.php?action=logout', {
        method: 'POST'
      }).finally(function () {
        window.location.href = '/nsms/public/index.html';
      });
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(NSMSSidebar, {
    activePage: "messages",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (sidebarOpen ? '' : ' collapsed')
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    className: "page-title"
  }, "Messages", totalUnread > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 10,
      fontSize: 14,
      fontWeight: 700,
      background: '#EF4444',
      color: 'white',
      padding: '2px 9px',
      borderRadius: 20,
      verticalAlign: 'middle'
    }
  }, totalUnread)), /*#__PURE__*/React.createElement("p", {
    className: "page-sub"
  }, "Communicate with teachers, parents and staff")), /*#__PURE__*/React.createElement("button", {
    className: "btn-new-msg",
    onClick: function () {
      setShowNewMsg(true);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2709\uFE0F",
    size: 18
  }), " New Message")), /*#__PURE__*/React.createElement("div", {
    className: "chat-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "conv-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "conv-search-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "conv-search"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    type: "text",
    placeholder: "Search messages\u2026",
    value: search,
    onChange: function (e) {
      setSearch(e.target.value);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "conv-list"
  }, loadConvs ? /*#__PURE__*/React.createElement(ShimmerConvs, null) : filteredConvs.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty-convs"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCAC",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, search ? 'No conversations match.' : 'No messages yet. Start a new conversation!')) : filteredConvs.map(function (conv) {
    var isActive = conv.contact_id === activeId;
    var hasUnread = conv.unread_count > 0;
    return /*#__PURE__*/React.createElement("div", {
      key: conv.contact_id,
      className: 'conv-item' + (isActive ? ' active' : '') + (hasUnread ? ' unread' : ''),
      onClick: function () {
        setActiveId(conv.contact_id);
      }
    }, /*#__PURE__*/React.createElement(CAvatar, {
      contact: {
        full_name: conv.contact_name,
        contact_photo: conv.contact_photo
      },
      size: 42,
      isOnline: conv.is_online
    }), /*#__PURE__*/React.createElement("div", {
      className: "conv-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "conv-top"
    }, /*#__PURE__*/React.createElement("span", {
      className: "conv-name"
    }, conv.contact_name), /*#__PURE__*/React.createElement("span", {
      className: "conv-time"
    }, fmtConvTime(conv.last_at))), /*#__PURE__*/React.createElement("div", {
      className: "conv-role"
    }, conv.role_label || conv.contact_role), /*#__PURE__*/React.createElement("div", {
      className: "conv-preview"
    }, conv.last_message || '—')), hasUnread && /*#__PURE__*/React.createElement("div", {
      className: "unread-dot"
    }));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "thread-panel"
  }, !activeId ? /*#__PURE__*/React.createElement("div", {
    className: "empty-thread"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCAC",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "Select a conversation to start messaging")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "thread-head"
  }, /*#__PURE__*/React.createElement(CAvatar, {
    contact: activeContact,
    size: 44,
    isOnline: contactOnline
  }), /*#__PURE__*/React.createElement("div", {
    className: "thread-head-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thread-contact-name"
  }, activeContact.contact_name || activeContact.full_name || '—'), contactTyping ? /*#__PURE__*/React.createElement("div", {
    className: "thread-status typing"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270D\uFE0F",
    size: 18
  }), " typing\u2026") : contactOnline ? /*#__PURE__*/React.createElement("div", {
    className: "thread-status online"
  }, " Online") : /*#__PURE__*/React.createElement("div", {
    className: "thread-status offline"
  }, activeContact.role_label || activeContact.contact_role || ''))), /*#__PURE__*/React.createElement("div", {
    className: "messages-area"
  }, loadThread ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        justifyContent: i % 2 === 0 ? 'flex-end' : 'flex-start'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: '55%',
        height: 68,
        borderRadius: 12
      },
      className: "shimmer"
    }));
  })) : thread.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      color: 'var(--text-muted)',
      fontSize: 13,
      marginTop: 32
    }
  }, "No messages yet. Say hello! ", /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC4B",
    size: 18
  })) : thread.map(function (msg, idx) {
    var isMine = msg.sender_id === myId;
    var showSep = idx === 0 || !sameDay(thread[idx - 1].created_at, msg.created_at);
    var isRead = msg.is_read == 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: msg.id || idx
    }, showSep && /*#__PURE__*/React.createElement("div", {
      className: "date-sep"
    }, dateSepLabel(msg.created_at)), /*#__PURE__*/React.createElement("div", {
      className: 'msg-row ' + (isMine ? 'mine' : 'theirs')
    }, msg.message && /*#__PURE__*/React.createElement("div", {
      className: "msg-bubble"
    }, msg.message), msg.files && msg.files.map(function (f, fi) {
      return /*#__PURE__*/React.createElement(FileBubble, {
        key: fi,
        file: f,
        isMine: isMine,
        onImg: function (url) {
          setLightbox(url);
        }
      });
    }), /*#__PURE__*/React.createElement("div", {
      className: "msg-meta"
    }, /*#__PURE__*/React.createElement("span", {
      className: "msg-time"
    }, fmtMsgTime(msg.created_at)), isMine && /*#__PURE__*/React.createElement("span", {
      className: 'msg-receipt' + (isRead ? ' read' : '')
    }, isRead ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 16
    }), /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 18
    })) : '✓'))));
  }), /*#__PURE__*/React.createElement("div", {
    ref: messagesEndRef
  })), /*#__PURE__*/React.createElement("div", {
    className: "compose-wrap"
  }, pendFile && /*#__PURE__*/React.createElement("div", {
    className: "file-preview-bar"
  }, isImage(pendFile.type) ? /*#__PURE__*/React.createElement("img", {
    className: "fp-img",
    src: URL.createObjectURL(pendFile),
    alt: ""
  }) : /*#__PURE__*/React.createElement("span", {
    className: "fp-icon"
  }, fileIcon(pendFile.type)), /*#__PURE__*/React.createElement("span", {
    className: "fp-name"
  }, pendFile.name), /*#__PURE__*/React.createElement("span", {
    className: "fp-size"
  }, fmtBytes(pendFile.size)), /*#__PURE__*/React.createElement("button", {
    className: "fp-remove",
    onClick: function () {
      setPendFile(null);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "compose-area"
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileInputRef,
    type: "file",
    style: {
      display: 'none'
    },
    accept: "image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt",
    onChange: onFileChange
  }), /*#__PURE__*/React.createElement("button", {
    className: "compose-attach",
    title: "Attach file",
    onClick: function () {
      fileInputRef.current && fileInputRef.current.click();
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCE",
    size: 18
  })), /*#__PURE__*/React.createElement("textarea", {
    className: "compose-input",
    placeholder: pendFile ? 'Add a caption (optional)…' : 'Type your message… (Enter to send, Shift+Enter for new line)',
    value: compose,
    onChange: onComposeChange,
    onKeyDown: onComposeKey,
    rows: 1
  }), /*#__PURE__*/React.createElement("button", {
    className: "btn-send",
    onClick: handleSend,
    disabled: sending || !compose.trim() && !pendFile
  }, sending ? '…' : 'Send ▶')))))))), showNewMsg && /*#__PURE__*/React.createElement(NewMessageModal, {
    contacts: contacts,
    onClose: function () {
      setShowNewMsg(false);
    },
    onSent: onNewMsgSent
  }), lightbox && /*#__PURE__*/React.createElement("div", {
    className: "lightbox",
    onClick: function () {
      setLightbox(null);
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: lightbox,
    alt: "Preview",
    onClick: function (e) {
      e.stopPropagation();
    }
  })), toast && /*#__PURE__*/React.createElement("div", {
    className: 'toast toast-' + toast.type
  }, toast.msg));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(AdminMessagesPage, null));