(function () {
    if (window.__nsmsSettingsOfflineLock) return;
    window.__nsmsSettingsOfflineLock = function () {
        try {
            var root = document.getElementById('root') || document.body;
            root.classList.add('nsms-settings-offline');
            if (!document.getElementById('nsms-settings-offline-css')) {
                var s = document.createElement('style');
                s.id = 'nsms-settings-offline-css';
                s.textContent = [
                    '.nsms-settings-offline input, .nsms-settings-offline textarea, .nsms-settings-offline select { background:#F1F5F9!important; cursor:not-allowed!important; pointer-events:none!important; opacity:.95; }',
                    '.nsms-settings-offline .btn-update, .nsms-settings-offline .btn-add-class, .nsms-settings-offline .btn-save-class, .nsms-settings-offline .btn-edit-class, .nsms-settings-offline .btn-delete-class, .nsms-settings-offline .fs-btn, .nsms-settings-offline button.btn-add-class { opacity:.55!important; pointer-events:none!important; cursor:not-allowed!important; }',
                    '.nsms-settings-offline .toggle-switch { opacity:.6; pointer-events:none!important; }',
                    '#nsms-settings-offline-banner { background:linear-gradient(135deg,#EFF6FF,#F0F9FF); border:1px solid #93C5FD; border-left:4px solid #2563EB; border-radius:12px; padding:14px 16px; margin:0 0 18px; color:#1E3A5F; font-size:13.5px; font-weight:600; display:flex; align-items:center; gap:10px; }',
                ].join('');
                document.head.appendChild(s);
            }
            if (!document.getElementById('nsms-settings-offline-banner')) {
                var b = document.createElement('div');
                b.id = 'nsms-settings-offline-banner';
                b.innerHTML =
                    '<span style="width:8px;height:8px;border-radius:50%;background:#F59E0B;box-shadow:0 0 0 3px rgba(245,158,11,.25);flex-shrink:0"></span><span>Offline mode — showing saved school information, logo, calendar and gallery as <strong>read-only</strong>. Connect to the server to edit.</span>';
                var header =
                    document.querySelector('.page-header') ||
                    document.querySelector('.settings-grid');
                if (header && header.parentNode)
                    header.parentNode.insertBefore(b, header.nextSibling);
                else if (root.firstChild) root.insertBefore(b, root.firstChild);
            }
            // Disable logo / calendar / gallery action buttons by text
            root.querySelectorAll('button').forEach(function (btn) {
                var t = (btn.textContent || '').toLowerCase();
                if (
                    /replace|use url|upload|add event|add image|save|edit schedule|add new class|add subject/.test(
                        t,
                    )
                ) {
                    btn.disabled = true;
                    btn.style.opacity = '0.55';
                    btn.style.pointerEvents = 'none';
                    btn.title = 'Connect to edit';
                }
            });
        } catch (e) {}
    };
})();

const { useState, useEffect, useRef, useCallback } = React;

/* ═══════════════════════════════════════════════
   CLASSES MANAGEMENT COMPONENT
═══════════════════════════════════════════════ */
function ClassesCard({ showAlert }) {
    const [classes, setClasses] = useState([]);
    const [classesLoading, setClassesLoading] = useState(true);
    const [classBusy, setClassBusy] = useState(false);
    const [formMode, setFormMode] = useState(null);
    const [classForm, setClassForm] = useState({
        class_name: '',
        capacity: '',
        sort_order: '',
        minimum_age: '',
    });
    const [confirmDelete, setConfirmDelete] = useState(null);
    const [cardError, setCardError] = useState('');
    useEffect(() => {
        loadClasses();
    }, []);
    const loadClasses = async () => {
        setClassesLoading(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=get_classes',
            );
            const text = await res.text();
            let data = null;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error('[get_classes] bad JSON:', text.slice(0, 300));
            }
            if (!data) {
                setCardError('Failed to load classes — bad server response');
                return;
            }
            if (data.success) setClasses(data.data || []);
            else setCardError(data.error || 'Failed to load classes');
        } catch (err) {
            console.error('[loadClasses]', err);
            setCardError('Network error loading classes');
        } finally {
            setClassesLoading(false);
        }
    };
    const openAddForm = () => {
        setClassForm({
            class_name: '',
            capacity: '',
            sort_order: '',
            minimum_age: '',
        });
        setFormMode('add');
        setConfirmDelete(null);
        setCardError('');
    };
    const openEditForm = (cls) => {
        setClassForm({
            class_name: cls.class_name,
            capacity: cls.capacity ?? '',
            sort_order: cls.sort_order ?? '',
            minimum_age:
                cls.minimum_age != null && cls.minimum_age !== ''
                    ? String(cls.minimum_age)
                    : '',
        });
        setFormMode(cls.id);
        setConfirmDelete(null);
        setCardError('');
    };
    const closeForm = () => {
        setFormMode(null);
        setClassForm({
            class_name: '',
            capacity: '',
            sort_order: '',
            minimum_age: '',
        });
        setCardError('');
    };
    const handleSaveClass = async () => {
        if (!classForm.class_name.trim()) {
            setCardError('Class name cannot be empty');
            return;
        }
        setClassBusy(true);
        setCardError('');
        const isEdit = formMode !== 'add';
        try {
            if (classForm.minimum_age !== '' && classForm.minimum_age != null) {
                const ma = parseInt(classForm.minimum_age, 10);
                if (isNaN(ma) || ma < 0 || ma > 25) {
                    setCardError(
                        'Minimum age must be a number between 0 and 25',
                    );
                    setClassBusy(false);
                    return;
                }
            }
            const payload = {
                class_name: classForm.class_name.trim(),
                capacity: classForm.capacity !== '' ? classForm.capacity : null,
                sort_order:
                    classForm.sort_order !== ''
                        ? parseInt(classForm.sort_order)
                        : null,
                minimum_age:
                    classForm.minimum_age === '' ||
                    classForm.minimum_age == null
                        ? null
                        : parseInt(classForm.minimum_age, 10),
                ...(isEdit
                    ? {
                          id: formMode,
                      }
                    : {}),
            };
            const res = await fetch(
                `/nsms/api/settings.php?action=${isEdit ? 'update_class' : 'add_class'}`,
                {
                    method: isEdit ? 'PUT' : 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payload),
                },
            );
            const text = await res.text();
            let data = null;
            try {
                data = JSON.parse(text);
            } catch (e) {
                /* fall through */
            }
            if (!data) {
                setCardError('Bad server response — check browser console');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    isEdit
                        ? /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Class updated!',
                          )
                        : /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Class added!',
                          ),
                );
                closeForm();
                loadClasses();
            } else {
                setCardError(data.error || 'Failed to save class');
            }
        } catch (err) {
            console.error('[saveClass]', err);
            setCardError('Network error — check browser console');
        } finally {
            setClassBusy(false);
        }
    };
    const handleDeleteClass = async (id) => {
        setClassBusy(true);
        setCardError('');
        try {
            const res = await fetch(
                `/nsms/api/settings.php?action=delete_class&id=${id}`,
                {
                    method: 'DELETE',
                },
            );
            const text = await res.text();
            let data = null;
            try {
                data = JSON.parse(text);
            } catch (e) {
                /* fall through */
            }
            setConfirmDelete(null);
            if (!data) {
                setCardError('Bad server response — check browser console');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\u2705',
                            size: 16,
                        }),
                        'Class deleted successfully',
                    ),
                );
                loadClasses();
            } else {
                setCardError(data.error || 'Failed to delete class');
            }
        } catch (err) {
            console.error('[deleteClass]', err);
            setConfirmDelete(null);
            setCardError('Network error — check browser console');
        } finally {
            setClassBusy(false);
        }
    };
    return /*#__PURE__*/ React.createElement(
        'div',
        {
            className: 'classes-card',
        },
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'classes-header',
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'classes-header-left',
                },
                /*#__PURE__*/ React.createElement(
                    'span',
                    {
                        className: 'settings-icon',
                    },
                    /*#__PURE__*/ React.createElement(Icon, {
                        emoji: '\uD83C\uDFEB',
                        size: 18,
                    }),
                ),
                /*#__PURE__*/ React.createElement(
                    'h2',
                    {
                        className: 'settings-title',
                    },
                    'Class Management',
                ),
            ),
            /*#__PURE__*/ React.createElement(
                'button',
                {
                    className: 'btn-add-class',
                    onClick: openAddForm,
                    disabled: classBusy || formMode !== null,
                },
                /*#__PURE__*/ React.createElement(Icon, {
                    emoji: '\uFF0B',
                    size: 18,
                }),
                ' Add New Class',
            ),
        ),
        cardError &&
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    style: {
                        background: '#FEF2F2',
                        border: '1px solid #FCA5A5',
                        color: '#B91C1C',
                        padding: '10px 14px',
                        borderRadius: 8,
                        marginBottom: 14,
                        fontSize: 13,
                        fontWeight: 500,
                    },
                },
                /*#__PURE__*/ React.createElement(Icon, {
                    emoji: '\u274C',
                    size: 18,
                }),
                ' ',
                cardError,
            ),
        formMode !== null &&
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'class-form-box',
                },
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-title',
                    },
                    formMode === 'add' ? 'Add New Class' : 'Edit Class',
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        style: {
                            display: 'grid',
                            gridTemplateColumns: '2fr 1fr 1fr',
                            gap: 12,
                            marginBottom: 14,
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Class Name *',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'text',
                            placeholder: 'e.g. Baby Class, Pre-Primary 1\u2026',
                            value: classForm.class_name,
                            onChange: (e) =>
                                setClassForm({
                                    ...classForm,
                                    class_name: e.target.value,
                                }),
                            disabled: classBusy,
                            autoFocus: true,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Capacity (optional)',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'number',
                            placeholder: 'e.g. 30',
                            min: '1',
                            value: classForm.capacity,
                            onChange: (e) =>
                                setClassForm({
                                    ...classForm,
                                    capacity: e.target.value,
                                }),
                            disabled: classBusy,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Minimum Age (years)',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'number',
                            placeholder: 'e.g. 3',
                            min: '0',
                            max: '25',
                            inputMode: 'numeric',
                            value: classForm.minimum_age,
                            onChange: (e) =>
                                setClassForm({
                                    ...classForm,
                                    minimum_age: e.target.value,
                                }),
                            disabled: classBusy,
                        }),
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                style: {
                                    fontSize: 11,
                                    color: '#94A3B8',
                                    marginTop: 3,
                                },
                            },
                            'Leave empty for no age restriction. Enforced on student registration.',
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Class Order *',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'number',
                            placeholder: 'auto',
                            min: '1',
                            value: classForm.sort_order,
                            onChange: (e) =>
                                setClassForm({
                                    ...classForm,
                                    sort_order: e.target.value,
                                }),
                            disabled: classBusy,
                        }),
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                style: {
                                    fontSize: 11,
                                    color: '#94A3B8',
                                    marginTop: 3,
                                },
                            },
                            '1 = youngest \xB7 highest = graduating',
                        ),
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-actions',
                    },
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-save-class',
                            onClick: handleSaveClass,
                            disabled: classBusy,
                        },
                        classBusy
                            ? 'Saving…'
                            : formMode === 'add'
                              ? 'Save Class'
                              : 'Update Class',
                    ),
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-cancel-class',
                            onClick: closeForm,
                            disabled: classBusy,
                        },
                        'Cancel',
                    ),
                ),
            ),
        classesLoading
            ? /*#__PURE__*/ React.createElement(
                  'div',
                  {
                      className: 'classes-loading',
                  },
                  /*#__PURE__*/ React.createElement('span', {
                      className: 'mini-spinner',
                  }),
                  'Loading classes\u2026',
              )
            : classes.length === 0
              ? /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'classes-empty',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-icon',
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\uD83D\uDCDA',
                            size: 18,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-text',
                        },
                        'No classes yet. Click "Add New Class" to get started.',
                    ),
                )
              : /*#__PURE__*/ React.createElement(
                    'table',
                    {
                        className: 'classes-table',
                    },
                    /*#__PURE__*/ React.createElement(
                        'thead',
                        null,
                        /*#__PURE__*/ React.createElement(
                            'tr',
                            null,
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Order',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Class Name',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Capacity',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Min. Age',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Actions',
                            ),
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'tbody',
                        null,
                        (() => {
                            const maxOrder =
                                classes.length > 0
                                    ? Math.max(
                                          ...classes.map(
                                              (c) =>
                                                  parseInt(c.sort_order) || 0,
                                          ),
                                      )
                                    : -1;
                            return classes.map((cls) =>
                                confirmDelete === cls.id
                                    ? /*#__PURE__*/ React.createElement(
                                          'tr',
                                          {
                                              key: cls.id,
                                              className: 'delete-confirm-row',
                                          },
                                          /*#__PURE__*/ React.createElement(
                                              'td',
                                              {
                                                  colSpan: 4,
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  'div',
                                                  {
                                                      className:
                                                          'delete-confirm-content',
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      'span',
                                                      {
                                                          className:
                                                              'delete-confirm-text',
                                                      },
                                                      /*#__PURE__*/ React.createElement(
                                                          Icon,
                                                          {
                                                              emoji: '\u26A0\uFE0F',
                                                              size: 18,
                                                          },
                                                      ),
                                                      ' Delete "',
                                                      cls.class_name,
                                                      '"? This cannot be undone.',
                                                  ),
                                                  /*#__PURE__*/ React.createElement(
                                                      'div',
                                                      {
                                                          className:
                                                              'delete-confirm-actions',
                                                      },
                                                      /*#__PURE__*/ React.createElement(
                                                          'button',
                                                          {
                                                              className:
                                                                  'btn-confirm-delete',
                                                              onClick: () =>
                                                                  handleDeleteClass(
                                                                      cls.id,
                                                                  ),
                                                              disabled:
                                                                  classBusy,
                                                          },
                                                          classBusy
                                                              ? 'Deleting…'
                                                              : 'Yes, Delete',
                                                      ),
                                                      /*#__PURE__*/ React.createElement(
                                                          'button',
                                                          {
                                                              className:
                                                                  'btn-cancel-delete',
                                                              onClick: () =>
                                                                  setConfirmDelete(
                                                                      null,
                                                                  ),
                                                              disabled:
                                                                  classBusy,
                                                          },
                                                          'Cancel',
                                                      ),
                                                  ),
                                              ),
                                          ),
                                      )
                                    : /*#__PURE__*/ React.createElement(
                                          'tr',
                                          {
                                              key: cls.id,
                                          },
                                          /*#__PURE__*/ React.createElement(
                                              'td',
                                              {
                                                  style: {
                                                      textAlign: 'center',
                                                  },
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  'span',
                                                  {
                                                      style: {
                                                          display:
                                                              'inline-flex',
                                                          alignItems: 'center',
                                                          justifyContent:
                                                              'center',
                                                          width: 28,
                                                          height: 28,
                                                          borderRadius: '50%',
                                                          background: '#EFF6FF',
                                                          color: '#2563EB',
                                                          fontSize: 13,
                                                          fontWeight: 700,
                                                      },
                                                  },
                                                  cls.sort_order || '—',
                                              ),
                                          ),
                                          /*#__PURE__*/ React.createElement(
                                              'td',
                                              null,
                                              /*#__PURE__*/ React.createElement(
                                                  'span',
                                                  {
                                                      className:
                                                          'class-name-badge',
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      'span',
                                                      {
                                                          className:
                                                              'class-dot',
                                                      },
                                                  ),
                                                  cls.class_name,
                                              ),
                                              parseInt(cls.sort_order) ===
                                                  maxOrder &&
                                                  maxOrder > 0 &&
                                                  /*#__PURE__*/ React.createElement(
                                                      'span',
                                                      {
                                                          style: {
                                                              marginLeft: 8,
                                                              fontSize: 11,
                                                              fontWeight: 700,
                                                              background:
                                                                  '#FEFCE8',
                                                              color: '#D97706',
                                                              border: '1px solid #FDE68A',
                                                              padding:
                                                                  '2px 8px',
                                                              borderRadius: 20,
                                                          },
                                                      },
                                                      /*#__PURE__*/ React.createElement(
                                                          Icon,
                                                          {
                                                              emoji: '\uD83C\uDF93',
                                                              size: 18,
                                                          },
                                                      ),
                                                      ' Graduating Class',
                                                  ),
                                          ),
                                          /*#__PURE__*/ React.createElement(
                                              'td',
                                              null,
                                              cls.capacity
                                                  ? /*#__PURE__*/ React.createElement(
                                                        'span',
                                                        {
                                                            className:
                                                                'capacity-pill',
                                                        },
                                                        cls.capacity,
                                                        ' students',
                                                    )
                                                  : /*#__PURE__*/ React.createElement(
                                                        'span',
                                                        {
                                                            className:
                                                                'capacity-none',
                                                        },
                                                        '\u2014',
                                                    ),
                                          ),
                                          /*#__PURE__*/ React.createElement(
                                              'td',
                                              null,
                                              cls.minimum_age != null &&
                                                  cls.minimum_age !== ''
                                                  ? /*#__PURE__*/ React.createElement(
                                                        'span',
                                                        {
                                                            className:
                                                                'capacity-pill',
                                                            title: 'Minimum admission age',
                                                        },
                                                        cls.minimum_age,
                                                        ' yrs',
                                                    )
                                                  : /*#__PURE__*/ React.createElement(
                                                        'span',
                                                        {
                                                            className:
                                                                'capacity-none',
                                                        },
                                                        '\u2014',
                                                    ),
                                          ),
                                          /*#__PURE__*/ React.createElement(
                                              'td',
                                              null,
                                              /*#__PURE__*/ React.createElement(
                                                  'div',
                                                  {
                                                      className:
                                                          'class-actions',
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      'button',
                                                      {
                                                          className:
                                                              'btn-edit-class',
                                                          onClick: () =>
                                                              openEditForm(cls),
                                                          disabled:
                                                              classBusy ||
                                                              formMode !== null,
                                                      },
                                                      /*#__PURE__*/ React.createElement(
                                                          Icon,
                                                          {
                                                              emoji: '\u270F\uFE0F',
                                                              size: 18,
                                                          },
                                                      ),
                                                      ' Edit',
                                                  ),
                                                  /*#__PURE__*/ React.createElement(
                                                      'button',
                                                      {
                                                          className:
                                                              'btn-delete-class',
                                                          onClick: () => {
                                                              setConfirmDelete(
                                                                  cls.id,
                                                              );
                                                              setFormMode(null);
                                                          },
                                                          disabled:
                                                              classBusy ||
                                                              formMode !== null,
                                                      },
                                                      /*#__PURE__*/ React.createElement(
                                                          Icon,
                                                          {
                                                              emoji: '\uD83D\uDDD1',
                                                              size: 18,
                                                          },
                                                      ),
                                                      ' Delete',
                                                  ),
                                              ),
                                          ),
                                      ),
                            );
                        })(),
                    ),
                ),
    );
}

/* ═══════════════════════════════════════════════
   SUBJECTS MANAGEMENT COMPONENT
═══════════════════════════════════════════════ */
function SubjectsCard({ showAlert }) {
    const [subjects, setSubjects] = useState([]);
    const [subjectsLoading, setSubjectsLoading] = useState(true);
    const [subjectBusy, setSubjectBusy] = useState(false);
    const [formMode, setFormMode] = useState(null);
    const [subjectForm, setSubjectForm] = useState({
        subject_name: '',
    });
    const [confirmDelete, setConfirmDelete] = useState(null);
    const [cardError, setCardError] = useState('');
    useEffect(() => {
        loadSubjects();
    }, []);
    const loadSubjects = async () => {
        setSubjectsLoading(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=get_subjects',
            );
            const text = await res.text();
            let data = null;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error('[get_subjects] bad JSON:', text.slice(0, 300));
            }
            if (!data) {
                setCardError('Failed to load subjects — bad server response');
                return;
            }
            if (data.success) setSubjects(data.data || []);
            else setCardError(data.error || 'Failed to load subjects');
        } catch (err) {
            console.error('[loadSubjects]', err);
            setCardError('Network error loading subjects');
        } finally {
            setSubjectsLoading(false);
        }
    };
    const openAddForm = () => {
        setSubjectForm({
            subject_name: '',
        });
        setFormMode('add');
        setConfirmDelete(null);
        setCardError('');
    };
    const openEditForm = (s) => {
        setSubjectForm({
            subject_name: s.subject_name,
        });
        setFormMode(s.id);
        setConfirmDelete(null);
        setCardError('');
    };
    const closeForm = () => {
        setFormMode(null);
        setSubjectForm({
            subject_name: '',
        });
        setCardError('');
    };
    const handleSaveSubject = async () => {
        if (!subjectForm.subject_name.trim()) {
            setCardError('Subject name cannot be empty');
            return;
        }
        setSubjectBusy(true);
        setCardError('');
        const isEdit = formMode !== 'add';
        try {
            const payload = {
                subject_name: subjectForm.subject_name.trim(),
                ...(isEdit
                    ? {
                          id: formMode,
                      }
                    : {}),
            };
            const res = await fetch(
                `/nsms/api/settings.php?action=${isEdit ? 'update_subject' : 'add_subject'}`,
                {
                    method: isEdit ? 'PUT' : 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payload),
                },
            );
            const text = await res.text();
            let data = null;
            try {
                data = JSON.parse(text);
            } catch (e) {
                /* fall through */
            }
            if (!data) {
                setCardError('Bad server response — check browser console');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    isEdit
                        ? /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Subject updated!',
                          )
                        : /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Subject added!',
                          ),
                );
                closeForm();
                loadSubjects();
            } else {
                setCardError(data.error || 'Failed to save subject');
            }
        } catch (err) {
            console.error('[saveSubject]', err);
            setCardError('Network error — check browser console');
        } finally {
            setSubjectBusy(false);
        }
    };
    const handleDeleteSubject = async (id) => {
        setSubjectBusy(true);
        setCardError('');
        try {
            const res = await fetch(
                `/nsms/api/settings.php?action=delete_subject&id=${id}`,
                {
                    method: 'DELETE',
                },
            );
            const text = await res.text();
            let data = null;
            try {
                data = JSON.parse(text);
            } catch (e) {
                /* fall through */
            }
            setConfirmDelete(null);
            if (!data) {
                setCardError('Bad server response — check browser console');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\u2705',
                            size: 16,
                        }),
                        'Subject deleted successfully',
                    ),
                );
                loadSubjects();
            } else {
                setCardError(data.error || 'Failed to delete subject');
            }
        } catch (err) {
            console.error('[deleteSubject]', err);
            setConfirmDelete(null);
            setCardError('Network error — check browser console');
        } finally {
            setSubjectBusy(false);
        }
    };
    return /*#__PURE__*/ React.createElement(
        'div',
        {
            className: 'classes-card',
        },
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'classes-header',
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'classes-header-left',
                },
                /*#__PURE__*/ React.createElement(
                    'span',
                    {
                        className: 'settings-icon',
                    },
                    /*#__PURE__*/ React.createElement(Icon, {
                        emoji: '\uD83D\uDCD6',
                        size: 18,
                    }),
                ),
                /*#__PURE__*/ React.createElement(
                    'h2',
                    {
                        className: 'settings-title',
                    },
                    'Subject Management',
                ),
            ),
            /*#__PURE__*/ React.createElement(
                'button',
                {
                    className: 'btn-add-class',
                    onClick: openAddForm,
                    disabled: subjectBusy || formMode !== null,
                },
                /*#__PURE__*/ React.createElement(Icon, {
                    emoji: '\uFF0B',
                    size: 18,
                }),
                ' Add New Subject',
            ),
        ),
        cardError &&
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    style: {
                        background: '#FEF2F2',
                        border: '1px solid #FCA5A5',
                        color: '#B91C1C',
                        padding: '10px 14px',
                        borderRadius: 8,
                        marginBottom: 14,
                        fontSize: 13,
                        fontWeight: 500,
                    },
                },
                /*#__PURE__*/ React.createElement(Icon, {
                    emoji: '\u274C',
                    size: 18,
                }),
                ' ',
                cardError,
            ),
        formMode !== null &&
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'class-form-box',
                },
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-title',
                    },
                    formMode === 'add' ? 'Add New Subject' : 'Edit Subject',
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-row-single',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Subject Name *',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'text',
                            placeholder:
                                'e.g. Mathematics, English, Science\u2026',
                            value: subjectForm.subject_name,
                            onChange: (e) =>
                                setSubjectForm({
                                    subject_name: e.target.value,
                                }),
                            disabled: subjectBusy,
                            autoFocus: true,
                        }),
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-actions',
                    },
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-save-class',
                            onClick: handleSaveSubject,
                            disabled: subjectBusy,
                        },
                        subjectBusy
                            ? 'Saving…'
                            : formMode === 'add'
                              ? 'Save Subject'
                              : 'Update Subject',
                    ),
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-cancel-class',
                            onClick: closeForm,
                            disabled: subjectBusy,
                        },
                        'Cancel',
                    ),
                ),
            ),
        subjectsLoading
            ? /*#__PURE__*/ React.createElement(
                  'div',
                  {
                      className: 'classes-loading',
                  },
                  /*#__PURE__*/ React.createElement('span', {
                      className: 'mini-spinner',
                  }),
                  'Loading subjects\u2026',
              )
            : subjects.length === 0
              ? /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'classes-empty',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-icon',
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\uD83D\uDCDD',
                            size: 18,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-text',
                        },
                        'No subjects yet. Click "Add New Subject" to get started.',
                    ),
                )
              : /*#__PURE__*/ React.createElement(
                    'table',
                    {
                        className: 'classes-table',
                    },
                    /*#__PURE__*/ React.createElement(
                        'thead',
                        null,
                        /*#__PURE__*/ React.createElement(
                            'tr',
                            null,
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Subject Name',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Actions',
                            ),
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'tbody',
                        null,
                        subjects.map((s) =>
                            confirmDelete === s.id
                                ? /*#__PURE__*/ React.createElement(
                                      'tr',
                                      {
                                          key: s.id,
                                          className: 'delete-confirm-row',
                                      },
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              colSpan: 2,
                                          },
                                          /*#__PURE__*/ React.createElement(
                                              'div',
                                              {
                                                  className:
                                                      'delete-confirm-content',
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  'span',
                                                  {
                                                      className:
                                                          'delete-confirm-text',
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      Icon,
                                                      {
                                                          emoji: '\u26A0\uFE0F',
                                                          size: 18,
                                                      },
                                                  ),
                                                  ' Delete "',
                                                  s.subject_name,
                                                  '"? This cannot be undone.',
                                              ),
                                              /*#__PURE__*/ React.createElement(
                                                  'div',
                                                  {
                                                      className:
                                                          'delete-confirm-actions',
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      'button',
                                                      {
                                                          className:
                                                              'btn-confirm-delete',
                                                          onClick: () =>
                                                              handleDeleteSubject(
                                                                  s.id,
                                                              ),
                                                          disabled: subjectBusy,
                                                      },
                                                      subjectBusy
                                                          ? 'Deleting…'
                                                          : 'Yes, Delete',
                                                  ),
                                                  /*#__PURE__*/ React.createElement(
                                                      'button',
                                                      {
                                                          className:
                                                              'btn-cancel-delete',
                                                          onClick: () =>
                                                              setConfirmDelete(
                                                                  null,
                                                              ),
                                                          disabled: subjectBusy,
                                                      },
                                                      'Cancel',
                                                  ),
                                              ),
                                          ),
                                      ),
                                  )
                                : /*#__PURE__*/ React.createElement(
                                      'tr',
                                      {
                                          key: s.id,
                                      },
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          null,
                                          /*#__PURE__*/ React.createElement(
                                              'span',
                                              {
                                                  className: 'class-name-badge',
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  'span',
                                                  {
                                                      className: 'class-dot',
                                                      style: {
                                                          background: '#8B5CF6',
                                                      },
                                                  },
                                              ),
                                              s.subject_name,
                                          ),
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          null,
                                          /*#__PURE__*/ React.createElement(
                                              'div',
                                              {
                                                  className: 'class-actions',
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  'button',
                                                  {
                                                      className:
                                                          'btn-edit-class',
                                                      onClick: () =>
                                                          openEditForm(s),
                                                      disabled:
                                                          subjectBusy ||
                                                          formMode !== null,
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      Icon,
                                                      {
                                                          emoji: '\u270F\uFE0F',
                                                          size: 18,
                                                      },
                                                  ),
                                                  ' Edit',
                                              ),
                                              /*#__PURE__*/ React.createElement(
                                                  'button',
                                                  {
                                                      className:
                                                          'btn-delete-class',
                                                      onClick: () => {
                                                          setConfirmDelete(
                                                              s.id,
                                                          );
                                                          setFormMode(null);
                                                      },
                                                      disabled:
                                                          subjectBusy ||
                                                          formMode !== null,
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      Icon,
                                                      {
                                                          emoji: '\uD83D\uDDD1',
                                                          size: 18,
                                                      },
                                                  ),
                                                  ' Delete',
                                              ),
                                          ),
                                      ),
                                  ),
                        ),
                    ),
                ),
    );
}

/* ═══════════════════════════════════════════════
   FEE STRUCTURE COMPONENT
═══════════════════════════════════════════════ */
const SW_FEE_TYPES = [
    'Registration Fee',
    'Stationery',
    'Uniform',
    'Meals',
    'Transport',
];
const CLASS_FEE_TYPE = 'School Fees';
function FeeStructureTab() {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState('');
    const [editing, setEditing] = useState(undefined);
    const [editFees, setEditFees] = useState([]);
    const [saving, setSaving] = useState(false);
    const [msg, setMsg] = useState('');
    const load = useCallback(() => {
        setLoading(true);
        setErr('');
        apiFetch('/nsms/api/settings.php?action=fee_structure_all')
            .then((d) => {
                if (d.success) setData(d.data);
                else setErr(d.error || 'Failed');
            })
            .finally(() => setLoading(false));
    }, []);
    useEffect(() => {
        load();
    }, [load]);
    const startEdit = (cid) => {
        const key = cid === null ? 'school_wide' : cid;
        const existing = data.fee_map[key] || [];
        const feeTypes = cid === null ? SW_FEE_TYPES : [CLASS_FEE_TYPE];
        const fees = feeTypes.map((ft) => {
            const f = existing.find((e) => e.fee_type === ft);
            return {
                fee_type: ft,
                amount: f ? f.amount : '',
            };
        });
        setEditFees(fees);
        setEditing(cid);
        setMsg('');
    };
    const setAmt = (i, v) =>
        setEditFees((p) =>
            p.map((f, idx) =>
                idx === i
                    ? {
                          ...f,
                          amount: v,
                      }
                    : f,
            ),
        );
    const save = async () => {
        setSaving(true);
        setMsg('');
        const fees = editFees
            .filter((f) => f.amount !== '' && Number(f.amount) > 0)
            .map((f) => ({
                fee_type: f.fee_type,
                amount: Number(f.amount),
            }));
        const d = await apiPost(
            '/nsms/api/settings.php?action=save_fee_structure',
            {
                class_id: editing,
                fees,
                academic_year: data.academic_year,
            },
        );
        setSaving(false);
        if (d.success) {
            setMsg('Saved!');
            setEditing(undefined);
            load();
        } else setMsg('⚠️ ' + (d.error || 'Failed'));
    };
    if (loading)
        return /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'fs-sw',
            },
            /*#__PURE__*/ React.createElement('div', {
                className: 'fs-spinner',
            }),
            /*#__PURE__*/ React.createElement(
                'span',
                null,
                'Loading fee structure\u2026',
            ),
        );
    if (err)
        return /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'fs-err',
            },
            /*#__PURE__*/ React.createElement(Icon, {
                emoji: '\u26A0\uFE0F',
                size: 18,
            }),
            ' ',
            err,
        );
    if (!data) return null;

    // Build groups — assign palette colours by index since DB doesn't store class_color
    const groups = [
        {
            label: 'School-wide Fees',
            sub: 'Apply to all classes · Paid upfront in full',
            classId: null,
            color: '#8B5CF6',
            feeTypes: SW_FEE_TYPES,
        },
        ...(data.classes || []).map((c, idx) => ({
            label: c.class_name,
            sub: 'School Fees only · Split into 10 monthly installments',
            classId: c.id,
            color: classColor(idx),
            feeTypes: [CLASS_FEE_TYPE],
        })),
    ];
    return /*#__PURE__*/ React.createElement(
        'div',
        null,
        /*#__PURE__*/ React.createElement(
            'div',
            {
                style: {
                    background: '#EFF6FF',
                    border: '1px solid #BFDBFE',
                    borderRadius: 10,
                    padding: '12px 16px',
                    marginBottom: 16,
                    fontSize: 13,
                    color: '#1E40AF',
                },
            },
            /*#__PURE__*/ React.createElement(
                'strong',
                null,
                'Fee structure rules:',
            ),
            ' School-wide fees apply to all students and are paid upfront. Each class has its own ',
            /*#__PURE__*/ React.createElement('strong', null, 'School Fees'),
            ' split into 10 installments. Transport is optional \u2014 assign per-student in the Finance module.',
        ),
        msg &&
            editing === undefined &&
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'fs-ok',
                },
                /*#__PURE__*/ React.createElement(Icon, {
                    emoji: '\u2705',
                    size: 18,
                }),
                ' ',
                msg,
            ),
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'fsgrid',
            },
            groups.map((g) => {
                const key = g.classId === null ? 'school_wide' : g.classId;
                const fees = (data.fee_map[key] || []).filter((f) =>
                    g.feeTypes.includes(f.fee_type),
                );
                const total = fees.reduce((s, f) => s + f.amount, 0);
                const isEd = editing === g.classId;
                return /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        key: String(key),
                        className: 'fs-card',
                        style: {
                            borderTop: `4px solid ${g.color}`,
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'fs-ch',
                        },
                        /*#__PURE__*/ React.createElement(
                            'div',
                            null,
                            /*#__PURE__*/ React.createElement(
                                'div',
                                {
                                    style: {
                                        fontWeight: 700,
                                        fontSize: 15,
                                        color: '#1E293B',
                                    },
                                },
                                g.label,
                            ),
                            /*#__PURE__*/ React.createElement(
                                'div',
                                {
                                    style: {
                                        fontSize: 12,
                                        color: '#94A3B8',
                                        marginTop: 2,
                                    },
                                },
                                g.sub,
                            ),
                        ),
                        !isEd &&
                            /*#__PURE__*/ React.createElement(
                                'button',
                                {
                                    className: 'fs-btn fs-btn-sm fs-btn-out',
                                    onClick: () => startEdit(g.classId),
                                },
                                /*#__PURE__*/ React.createElement(Icon, {
                                    emoji: '\u270F\uFE0F',
                                    size: 18,
                                }),
                                ' Edit',
                            ),
                    ),
                    isEd
                        ? /*#__PURE__*/ React.createElement(
                              'div',
                              null,
                              editFees.map((f, i) =>
                                  /*#__PURE__*/ React.createElement(
                                      'div',
                                      {
                                          key: i,
                                          style: {
                                              marginBottom: 10,
                                          },
                                      },
                                      /*#__PURE__*/ React.createElement(
                                          'div',
                                          {
                                              style: {
                                                  fontSize: 12,
                                                  fontWeight: 600,
                                                  color: '#475569',
                                                  marginBottom: 4,
                                              },
                                          },
                                          f.fee_type,
                                          f.fee_type === 'School Fees' &&
                                              /*#__PURE__*/ React.createElement(
                                                  'span',
                                                  {
                                                      style: {
                                                          color: '#94A3B8',
                                                          fontWeight: 400,
                                                      },
                                                  },
                                                  ' \u2014 annual total (\xF710 per installment)',
                                              ),
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'div',
                                          {
                                              style: {
                                                  position: 'relative',
                                              },
                                          },
                                          /*#__PURE__*/ React.createElement(
                                              'span',
                                              {
                                                  style: {
                                                      position: 'absolute',
                                                      left: 10,
                                                      top: '50%',
                                                      transform:
                                                          'translateY(-50%)',
                                                      fontSize: 12,
                                                      color: '#94A3B8',
                                                  },
                                              },
                                              'TSh',
                                          ),
                                          /*#__PURE__*/ React.createElement(
                                              'input',
                                              {
                                                  type: 'number',
                                                  min: '0',
                                                  className: 'fs-fi',
                                                  style: {
                                                      paddingLeft: 38,
                                                      fontSize: 14,
                                                  },
                                                  placeholder: '0',
                                                  value: f.amount,
                                                  onChange: (e) =>
                                                      setAmt(i, e.target.value),
                                              },
                                          ),
                                      ),
                                      f.fee_type === 'School Fees' &&
                                          f.amount &&
                                          Number(f.amount) > 0 &&
                                          /*#__PURE__*/ React.createElement(
                                              'div',
                                              {
                                                  style: {
                                                      fontSize: 12,
                                                      color: '#10B981',
                                                      marginTop: 3,
                                                  },
                                              },
                                              '= ',
                                              fmtF(Number(f.amount) / 10),
                                              ' per installment',
                                          ),
                                  ),
                              ),
                              msg &&
                                  /*#__PURE__*/ React.createElement(
                                      'div',
                                      {
                                          style: {
                                              fontSize: 13,
                                              marginBottom: 6,
                                              color:
                                                  String(msg).indexOf('⚠') ===
                                                      0 ||
                                                  String(msg).indexOf('⚠️') ===
                                                      0
                                                      ? '#B91C1C'
                                                      : '#166534',
                                          },
                                      },
                                      msg,
                                  ),
                              /*#__PURE__*/ React.createElement(
                                  'div',
                                  {
                                      style: {
                                          display: 'flex',
                                          gap: 8,
                                          marginTop: 6,
                                      },
                                  },
                                  /*#__PURE__*/ React.createElement(
                                      'button',
                                      {
                                          className:
                                              'fs-btn fs-btn-sm fs-btn-out',
                                          style: {
                                              flex: 1,
                                          },
                                          onClick: () => setEditing(undefined),
                                          disabled: saving,
                                      },
                                      'Cancel',
                                  ),
                                  /*#__PURE__*/ React.createElement(
                                      'button',
                                      {
                                          className:
                                              'fs-btn fs-btn-sm fs-btn-blue',
                                          style: {
                                              flex: 1,
                                          },
                                          onClick: save,
                                          disabled: saving,
                                      },
                                      saving
                                          ? 'Saving…'
                                          : /*#__PURE__*/ React.createElement(
                                                'span',
                                                {
                                                    style: {
                                                        display: 'inline-flex',
                                                        alignItems: 'center',
                                                        gap: 6,
                                                    },
                                                },
                                                /*#__PURE__*/ React.createElement(
                                                    Icon,
                                                    {
                                                        emoji: '\uD83D\uDCBE',
                                                        size: 16,
                                                    },
                                                ),
                                                'Save',
                                            ),
                                  ),
                              ),
                          )
                        : fees.length > 0
                          ? /*#__PURE__*/ React.createElement(
                                'div',
                                null,
                                fees.map((f, i) =>
                                    /*#__PURE__*/ React.createElement(
                                        'div',
                                        {
                                            key: i,
                                            style: {
                                                padding: '6px 0',
                                                borderBottom:
                                                    '1px solid #F1F5F9',
                                                fontSize: 13,
                                            },
                                        },
                                        /*#__PURE__*/ React.createElement(
                                            'div',
                                            {
                                                style: {
                                                    display: 'flex',
                                                    justifyContent:
                                                        'space-between',
                                                },
                                            },
                                            /*#__PURE__*/ React.createElement(
                                                'span',
                                                {
                                                    style: {
                                                        color: '#475569',
                                                    },
                                                },
                                                f.fee_type,
                                            ),
                                            /*#__PURE__*/ React.createElement(
                                                'span',
                                                {
                                                    style: {
                                                        fontWeight: 700,
                                                        color: '#1E293B',
                                                    },
                                                },
                                                fmtF(f.amount),
                                            ),
                                        ),
                                        f.fee_type === 'School Fees' &&
                                            /*#__PURE__*/ React.createElement(
                                                'div',
                                                {
                                                    style: {
                                                        fontSize: 11,
                                                        color: '#94A3B8',
                                                        marginTop: 2,
                                                    },
                                                },
                                                fmtF(f.amount / 10),
                                                ' ',
                                                /*#__PURE__*/ React.createElement(
                                                    Icon,
                                                    {
                                                        emoji: '\xD7',
                                                        size: 18,
                                                    },
                                                ),
                                                ' 10 installments',
                                            ),
                                    ),
                                ),
                                fees.length > 1 &&
                                    /*#__PURE__*/ React.createElement(
                                        'div',
                                        {
                                            style: {
                                                display: 'flex',
                                                justifyContent: 'space-between',
                                                padding: '8px 0 0',
                                            },
                                        },
                                        /*#__PURE__*/ React.createElement(
                                            'span',
                                            {
                                                style: {
                                                    fontSize: 13,
                                                    fontWeight: 700,
                                                    color: '#64748B',
                                                },
                                            },
                                            'TOTAL',
                                        ),
                                        /*#__PURE__*/ React.createElement(
                                            'span',
                                            {
                                                style: {
                                                    fontSize: 15,
                                                    fontWeight: 700,
                                                    color: g.color,
                                                },
                                            },
                                            fmtF(total),
                                        ),
                                    ),
                            )
                          : /*#__PURE__*/ React.createElement(
                                'div',
                                {
                                    style: {
                                        fontSize: 13,
                                        color: '#94A3B8',
                                        padding: '8px 0',
                                        textAlign: 'center',
                                    },
                                },
                                'No fees set. ',
                                /*#__PURE__*/ React.createElement(
                                    'span',
                                    {
                                        style: {
                                            color: '#2563EB',
                                            cursor: 'pointer',
                                        },
                                        onClick: () => startEdit(g.classId),
                                    },
                                    'Click Edit \u2192',
                                ),
                            ),
                );
            }),
        ),
        /*#__PURE__*/ React.createElement(
            'div',
            {
                style: {
                    fontSize: 12,
                    color: '#94A3B8',
                    marginTop: 12,
                },
            },
            'Academic Year: ',
            /*#__PURE__*/ React.createElement(
                'strong',
                null,
                data.academic_year,
            ),
        ),
    );
}

/* ═══════════════════════════════════════════════
   MAIN SETTINGS PAGE
═══════════════════════════════════════════════ */
function SettingsPage() {
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [alert, setAlert] = useState({
        show: false,
        type: '',
        message: '',
    });
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [settings, setSettings] = useState({
        school_name: '',
        school_address: '',
        school_phone: '',
        school_email: '',
        established_year: '',
        email_notifications: 'true',
        sms_notifications: 'true',
    });

    // Security: old_password added before new_password
    const [passwordData, setPasswordData] = useState({
        old_password: '',
        new_password: '',
        confirm_password: '',
    });
    useEffect(() => {
        loadSettings();
    }, []);
    const showAlert = (type, message) => {
        setAlert({
            show: true,
            type,
            message,
        });
        setTimeout(
            () =>
                setAlert({
                    show: false,
                    type: '',
                    message: '',
                }),
            5000,
        );
    };
    const safeJson = async (res, label) => {
        const text = await res.text();
        try {
            return JSON.parse(text);
        } catch (e) {
            console.error(`[${label}] invalid JSON:`, text);
            return null;
        }
    };
    const loadSettings = async () => {
        try {
            const res = await fetch('/nsms/api/settings.php?action=get');
            const data = await safeJson(res, 'get_settings');
            if (!data) {
                showAlert('error', 'Server returned invalid response');
                return;
            }
            if (data.success) {
                setSettings((prev) => ({
                    ...prev,
                    ...data.data,
                }));
                if (
                    data.offline_mode ||
                    (data.data && data.data.offline_mode)
                ) {
                    if (window.__nsmsSettingsOfflineLock)
                        window.__nsmsSettingsOfflineLock();
                    try {
                        document
                            .querySelectorAll(
                                '.settings-card input, .settings-card textarea, .settings-card select',
                            )
                            .forEach(function (el) {
                                el.setAttribute('readonly', 'readonly');
                                el.setAttribute('disabled', 'disabled');
                                el.style.background = '#F1F5F9';
                                el.style.cursor = 'not-allowed';
                            });
                        document
                            .querySelectorAll(
                                '.settings-card .btn-update, .settings-card button.btn-update',
                            )
                            .forEach(function (btn) {
                                btn.setAttribute('disabled', 'disabled');
                                btn.title = 'Connect to edit settings';
                            });
                        if (
                            !document.getElementById(
                                'nsms-settings-offline-banner',
                            )
                        ) {
                            var b = document.createElement('div');
                            b.id = 'nsms-settings-offline-banner';
                            b.style.cssText =
                                'background:#EFF6FF;border:1px solid #93C5FD;border-left:4px solid #2563EB;border-radius:10px;padding:12px 14px;margin:0 0 16px;color:#1E3A5F;font-size:13px;font-weight:600';
                            b.textContent =
                                'Offline — showing last saved school information (read-only). Connect to edit.';
                            var root =
                                document.querySelector('.settings-grid') ||
                                document.querySelector('#root');
                            if (root && root.parentNode)
                                root.parentNode.insertBefore(b, root);
                            else if (root)
                                root.insertBefore(b, root.firstChild);
                        }
                    } catch (e) {}
                }
            } else showAlert('error', data.error || 'Failed to load settings');
        } catch (err) {
            console.error('loadSettings:', err);
            showAlert('error', 'Failed to connect to server');
        } finally {
            setLoading(false);
        }
    };
    const handleSave = async () => {
        setSaving(true);
        try {
            const res = await fetch('/nsms/api/settings.php?action=update', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(settings),
            });
            const data = await safeJson(res, 'update_settings');
            if (!data) {
                showAlert(
                    'error',
                    'Server returned invalid response. Check console.',
                );
                setSaving(false);
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\u2705',
                            size: 16,
                        }),
                        'Settings saved successfully!',
                    ),
                );
                setTimeout(() => window.location.reload(), 1500);
            } else {
                showAlert('error', data.error || 'Failed to save settings');
                setSaving(false);
            }
        } catch (err) {
            console.error('handleSave:', err);
            showAlert('error', 'Network error. Please try again.');
            setSaving(false);
        }
    };
    const handlePasswordChange = async (e) => {
        e.preventDefault();

        // Validate old password is provided
        if (!passwordData.old_password) {
            showAlert('error', 'Please enter your current password');
            return;
        }
        if (!passwordData.new_password || !passwordData.confirm_password) {
            showAlert('error', 'Please fill in both new password fields');
            return;
        }
        if (passwordData.new_password.length < 6) {
            showAlert('error', 'New password must be at least 6 characters');
            return;
        }
        if (passwordData.new_password !== passwordData.confirm_password) {
            showAlert('error', 'New passwords do not match');
            return;
        }
        setSaving(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=change_password',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        old_password: passwordData.old_password,
                        new_password: passwordData.new_password,
                    }),
                },
            );
            const data = await safeJson(res, 'change_password');
            if (!data) {
                showAlert(
                    'error',
                    'Server returned invalid response. Check console.',
                );
                setSaving(false);
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\u2705',
                            size: 16,
                        }),
                        'Password changed successfully!',
                    ),
                );
                setPasswordData({
                    old_password: '',
                    new_password: '',
                    confirm_password: '',
                });
            } else {
                showAlert('error', data.error || 'Failed to change password');
            }
        } catch (err) {
            console.error('handlePasswordChange:', err);
            showAlert('error', 'Network error. Please try again.');
        } finally {
            setSaving(false);
        }
    };
    const handleLogout = async () => {
        try {
            await fetch('/nsms/api/auth.php?action=logout', {
                method: 'POST',
            });
        } catch (err) {
            console.error('Logout error:', err);
        } finally {
            window.location.href = '/nsms/public/index.html';
        }
    };
    if (loading) {
        return /*#__PURE__*/ React.createElement(
            'div',
            null,
            /*#__PURE__*/ React.createElement(NSMSNavbar, {
                activePage: 'settings',
                onLogout: handleLogout,
                sidebarOpen: sidebarOpen,
                setSidebarOpen: setSidebarOpen,
            }),
            /*#__PURE__*/ React.createElement(NSMSSidebar, {
                activePage: 'settings',
                sidebarOpen: sidebarOpen,
            }),
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'nsms-main',
                    style: {
                        marginLeft: sidebarOpen ? '220px' : '64px',
                    },
                },
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'loading',
                    },
                    /*#__PURE__*/ React.createElement('div', {
                        className: 'loading-spinner',
                    }),
                    /*#__PURE__*/ React.createElement(
                        'p',
                        {
                            style: {
                                marginTop: '20px',
                            },
                        },
                        'Loading settings\u2026',
                    ),
                ),
            ),
        );
    }
    return /*#__PURE__*/ React.createElement(
        'div',
        null,
        /*#__PURE__*/ React.createElement(NSMSNavbar, {
            activePage: 'settings',
            onLogout: handleLogout,
            sidebarOpen: sidebarOpen,
            setSidebarOpen: setSidebarOpen,
        }),
        /*#__PURE__*/ React.createElement(NSMSSidebar, {
            activePage: 'settings',
            sidebarOpen: sidebarOpen,
        }),
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'nsms-main',
                style: {
                    marginLeft: sidebarOpen ? '220px' : '64px',
                },
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'page-header',
                },
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'page-title-section',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            style: {
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '6px',
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'h1',
                            {
                                style: {
                                    margin: 0,
                                    fontSize: 26,
                                    fontWeight: 800,
                                    letterSpacing: '-0.02em',
                                    color: '#0F172A',
                                },
                            },
                            'System Settings',
                        ),
                        /*#__PURE__*/ React.createElement(
                            'p',
                            {
                                className: 'page-subtitle',
                                style: {
                                    margin: 0,
                                    paddingBottom: 10,
                                    color: '#64748B',
                                    fontSize: 14,
                                    fontWeight: 500,
                                    maxWidth: 560,
                                    lineHeight: 1.5,
                                },
                            },
                            'School profile, notifications, branding, and academic configuration.',
                        ),
                    ),
                ),
            ),
            alert.show &&
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: `alert alert-${alert.type}`,
                    },
                    /*#__PURE__*/ React.createElement(
                        'strong',
                        null,
                        alert.type === 'success' &&
                            /*#__PURE__*/ React.createElement(Icon, {
                                name: 'check-circle',
                                size: 16,
                            }),
                        alert.type === 'error' &&
                            /*#__PURE__*/ React.createElement(Icon, {
                                name: 'x-circle',
                                size: 16,
                            }),
                        alert.type === 'info' && 'ℹ️',
                    ),
                    /*#__PURE__*/ React.createElement(
                        'span',
                        null,
                        alert.message,
                    ),
                ),
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'settings-grid',
                },
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'settings-card',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'settings-header',
                        },
                        /*#__PURE__*/ React.createElement(
                            'span',
                            {
                                className: 'settings-icon',
                            },
                            /*#__PURE__*/ React.createElement(Icon, {
                                emoji: '\uD83C\uDFEB',
                                size: 18,
                            }),
                        ),
                        /*#__PURE__*/ React.createElement(
                            'h2',
                            {
                                className: 'settings-title',
                            },
                            'School Information',
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'School Name *',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            type: 'text',
                            className: 'form-input',
                            value: settings.school_name,
                            onChange: (e) =>
                                setSettings({
                                    ...settings,
                                    school_name: e.target.value,
                                }),
                            placeholder: 'Enter school name',
                            disabled: saving,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Address',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            type: 'text',
                            className: 'form-input',
                            value: settings.school_address,
                            onChange: (e) =>
                                setSettings({
                                    ...settings,
                                    school_address: e.target.value,
                                }),
                            placeholder: 'Enter school address',
                            disabled: saving,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Phone Number',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            type: 'tel',
                            className: 'form-input',
                            value: settings.school_phone,
                            onChange: (e) =>
                                setSettings({
                                    ...settings,
                                    school_phone: e.target.value,
                                }),
                            placeholder: '+255 XXX XXX XXX',
                            disabled: saving,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Email',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            type: 'email',
                            className: 'form-input',
                            value: settings.school_email,
                            onChange: (e) =>
                                setSettings({
                                    ...settings,
                                    school_email: e.target.value,
                                }),
                            placeholder: 'info@school.com',
                            disabled: saving,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Established Year (Years of Excellence)',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            type: 'number',
                            className: 'form-input',
                            min: '1900',
                            max: String(new Date().getFullYear()),
                            value: settings.established_year || '',
                            onChange: (e) =>
                                setSettings({
                                    ...settings,
                                    established_year: e.target.value,
                                }),
                            placeholder: 'e.g. 2019',
                            disabled: saving,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'p',
                        {
                            style: {
                                fontSize: 12,
                                color: '#64748b',
                                marginTop: -6,
                                marginBottom: 14,
                            },
                        },
                        'Used on the public landing page. Years of Excellence = current year − established year.',
                    ),
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-update',
                            onClick: handleSave,
                            disabled: saving,
                        },
                        saving ? 'Saving…' : 'Save School Information',
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'settings-card',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'settings-header',
                        },
                        /*#__PURE__*/ React.createElement(
                            'span',
                            {
                                className: 'settings-icon',
                            },
                            /*#__PURE__*/ React.createElement(Icon, {
                                emoji: '\uD83D\uDD14',
                                size: 18,
                            }),
                        ),
                        /*#__PURE__*/ React.createElement(
                            'h2',
                            {
                                className: 'settings-title',
                            },
                            'Notification Settings',
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'toggle-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                className: 'toggle-info',
                            },
                            /*#__PURE__*/ React.createElement(
                                'div',
                                {
                                    className: 'toggle-label',
                                },
                                'Email Notifications',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'div',
                                {
                                    className: 'toggle-subtitle',
                                },
                                'Receive updates via email',
                            ),
                        ),
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                className: `toggle-switch ${settings.email_notifications === 'true' ? 'active' : ''}`,
                                onClick: () =>
                                    !saving &&
                                    setSettings({
                                        ...settings,
                                        email_notifications:
                                            settings.email_notifications ===
                                            'true'
                                                ? 'false'
                                                : 'true',
                                    }),
                            },
                            /*#__PURE__*/ React.createElement('div', {
                                className: 'toggle-slider',
                            }),
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'toggle-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                className: 'toggle-info',
                            },
                            /*#__PURE__*/ React.createElement(
                                'div',
                                {
                                    className: 'toggle-label',
                                },
                                'SMS Notifications',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'div',
                                {
                                    className: 'toggle-subtitle',
                                },
                                'Receive updates via SMS',
                            ),
                        ),
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                className: `toggle-switch ${settings.sms_notifications === 'true' ? 'active' : ''}`,
                                onClick: () =>
                                    !saving &&
                                    setSettings({
                                        ...settings,
                                        sms_notifications:
                                            settings.sms_notifications ===
                                            'true'
                                                ? 'false'
                                                : 'true',
                                    }),
                            },
                            /*#__PURE__*/ React.createElement('div', {
                                className: 'toggle-slider',
                            }),
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-update',
                            onClick: handleSave,
                            disabled: saving,
                        },
                        saving ? 'Saving…' : 'Save Notification Settings',
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'settings-card',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'settings-header',
                        },
                        /*#__PURE__*/ React.createElement(
                            'span',
                            {
                                className: 'settings-icon',
                            },
                            /*#__PURE__*/ React.createElement(Icon, {
                                emoji: '\uD83D\uDD12',
                                size: 18,
                            }),
                        ),
                        /*#__PURE__*/ React.createElement(
                            'h2',
                            {
                                className: 'settings-title',
                            },
                            'Security Settings',
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Current Password',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            type: 'password',
                            className: 'form-input',
                            value: passwordData.old_password,
                            onChange: (e) =>
                                setPasswordData({
                                    ...passwordData,
                                    old_password: e.target.value,
                                }),
                            placeholder: 'Enter current password',
                            disabled: saving,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'New Password',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            type: 'password',
                            className: 'form-input',
                            value: passwordData.new_password,
                            onChange: (e) =>
                                setPasswordData({
                                    ...passwordData,
                                    new_password: e.target.value,
                                }),
                            placeholder: 'Minimum 6 characters',
                            disabled: saving,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Confirm New Password',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            type: 'password',
                            className: 'form-input',
                            value: passwordData.confirm_password,
                            onChange: (e) =>
                                setPasswordData({
                                    ...passwordData,
                                    confirm_password: e.target.value,
                                }),
                            placeholder: 'Re-enter new password',
                            disabled: saving,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-update',
                            onClick: handlePasswordChange,
                            disabled: saving,
                        },
                        saving ? 'Changing…' : 'Change Password',
                    ),
                ),
            ),
            /*#__PURE__*/ React.createElement(ClassesCard, {
                showAlert: showAlert,
            }),
            /*#__PURE__*/ React.createElement(AcademicScheduleCard, {
                showAlert: showAlert,
            }),
            /*#__PURE__*/ React.createElement(SubjectsCard, {
                showAlert: showAlert,
            }),
            /*#__PURE__*/ React.createElement(LogoCard, {
                showAlert: showAlert,
            }),
            /*#__PURE__*/ React.createElement(AboutCard, {
                showAlert: showAlert,
            }),
            /*#__PURE__*/ React.createElement(RegulationsCard, {
                showAlert: showAlert,
            }),
            /*#__PURE__*/ React.createElement(CalendarCard, {
                showAlert: showAlert,
            }),
            /*#__PURE__*/ React.createElement(GalleryCard, {
                showAlert: showAlert,
            }),
        ),
    );
}

/* ═══════════════════════════════════════════════
   LOGO MANAGEMENT COMPONENT
═══════════════════════════════════════════════ */
function LogoCard({ showAlert }) {
    const [logoUrl, setLogoUrl] = useState('');
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [urlInput, setUrlInput] = useState('');
    const [tab, setTab] = useState('current'); // 'current' | 'upload' | 'url'
    const fileRef = useRef(null);
    useEffect(() => {
        loadLogo();
    }, []);
    const loadLogo = async () => {
        setLoading(true);
        try {
            const res = await fetch('/nsms/api/settings.php?action=get_logo');
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                return;
            }
            if (data.success) {
                if (data.offline_mode && window.__nsmsSettingsOfflineLock)
                    window.__nsmsSettingsOfflineLock();
                const u = data.data.url || data.data.logo_url || '';
                setLogoUrl(u);
                try {
                    if (u) localStorage.setItem('nsms_school_logo', u);
                    else localStorage.removeItem('nsms_school_logo');
                } catch (e) {}
            }
        } catch (e) {
        } finally {
            setLoading(false);
        }
    };
    const handleFileUpload = async () => {
        if (!fileRef.current?.files?.[0]) {
            showAlert('error', 'Please select a file first');
            return;
        }
        setBusy(true);
        const fd = new FormData();
        fd.append('logo', fileRef.current.files[0]);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=upload_logo',
                {
                    method: 'POST',
                    body: fd,
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\u2705',
                            size: 16,
                        }),
                        'Logo uploaded!',
                    ),
                );
                setLogoUrl(data.data.url);
                try {
                    if (data.data.url)
                        localStorage.setItem('nsms_school_logo', data.data.url);
                    else localStorage.removeItem('nsms_school_logo');
                } catch (e) {}
                setTab('current');
                fileRef.current.value = '';
            } else showAlert('error', data.error || 'Upload failed');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const handleUrlSave = async () => {
        if (!urlInput.trim()) {
            showAlert('error', 'Please enter a URL');
            return;
        }
        setBusy(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=upload_logo',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        url: urlInput.trim(),
                    }),
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\u2705',
                            size: 16,
                        }),
                        'Logo URL saved!',
                    ),
                );
                setLogoUrl(data.data.url);
                try {
                    if (data.data.url)
                        localStorage.setItem('nsms_school_logo', data.data.url);
                    else localStorage.removeItem('nsms_school_logo');
                } catch (e) {}
                setTab('current');
                setUrlInput('');
            } else showAlert('error', data.error || 'Failed to save URL');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const handleDelete = async () => {
        if (
            !(await (window.NSMS && window.NSMS.confirm
                ? window.NSMS.confirm({
                      title: 'Remove logo?',
                      message: 'Remove the current school logo?',
                      confirmLabel: 'Remove',
                      variant: 'danger',
                  })
                : Promise.resolve(false)))
        )
            return;
        setBusy(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=delete_logo',
                {
                    method: 'DELETE',
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\uD83D\uDDD1\uFE0F',
                            size: 16,
                        }),
                        'Logo removed',
                    ),
                );
                setLogoUrl('');
                try {
                    localStorage.removeItem('nsms_school_logo');
                } catch (e) {}
            } else showAlert('error', data.error || 'Failed to delete logo');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const tabStyle = (t) => ({
        padding: '6px 18px',
        border: 'none',
        borderRadius: '6px',
        fontSize: '13px',
        fontWeight: 600,
        cursor: 'pointer',
        fontFamily: 'inherit',
        background: tab === t ? '#1E293B' : '#F1F5F9',
        color: tab === t ? 'white' : '#64748B',
        transition: 'all .2s',
    });
    return /*#__PURE__*/ React.createElement(
        'div',
        {
            className: 'classes-card',
        },
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'classes-header',
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'classes-header-left',
                },
                /*#__PURE__*/ React.createElement(
                    'span',
                    {
                        className: 'settings-icon',
                    },
                    /*#__PURE__*/ React.createElement(Icon, {
                        emoji: '\uD83D\uDDBC\uFE0F',
                        size: 18,
                    }),
                ),
                /*#__PURE__*/ React.createElement(
                    'h2',
                    {
                        className: 'settings-title',
                    },
                    'School Logo',
                ),
            ),
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    style: {
                        display: 'flex',
                        gap: '6px',
                    },
                },
                /*#__PURE__*/ React.createElement(
                    'button',
                    {
                        style: tabStyle('current'),
                        onClick: () => setTab('current'),
                    },
                    'Current',
                ),
                /*#__PURE__*/ React.createElement(
                    'button',
                    {
                        style: tabStyle('upload'),
                        onClick: () => setTab('upload'),
                    },
                    'Upload File',
                ),
                /*#__PURE__*/ React.createElement(
                    'button',
                    {
                        style: tabStyle('url'),
                        onClick: () => setTab('url'),
                    },
                    'Use URL',
                ),
            ),
        ),
        loading
            ? /*#__PURE__*/ React.createElement(
                  'div',
                  {
                      className: 'classes-loading',
                  },
                  /*#__PURE__*/ React.createElement('span', {
                      className: 'mini-spinner',
                  }),
                  'Loading\u2026',
              )
            : tab === 'current'
              ? /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        style: {
                            display: 'flex',
                            alignItems: 'center',
                            gap: '24px',
                            padding: '8px 0',
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            style: {
                                width: 120,
                                height: 120,
                                borderRadius: 12,
                                border: '2px dashed #E2E8F0',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                background: '#F8FAFC',
                                overflow: 'hidden',
                                flexShrink: 0,
                            },
                        },
                        logoUrl
                            ? /*#__PURE__*/ React.createElement('img', {
                                  src: logoUrl,
                                  alt: 'School Logo',
                                  style: {
                                      width: '100%',
                                      height: '100%',
                                      objectFit: 'contain',
                                  },
                              })
                            : /*#__PURE__*/ React.createElement(
                                  'span',
                                  {
                                      style: {
                                          fontSize: 48,
                                      },
                                  },
                                  /*#__PURE__*/ React.createElement(Icon, {
                                      emoji: '\uD83C\uDFEB',
                                      size: 18,
                                  }),
                              ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        null,
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                style: {
                                    fontSize: 14,
                                    fontWeight: 600,
                                    color: '#1E293B',
                                    marginBottom: 6,
                                },
                            },
                            logoUrl
                                ? 'Current School Logo'
                                : 'No logo set — using default icon',
                        ),
                        logoUrl &&
                            /*#__PURE__*/ React.createElement(
                                'div',
                                {
                                    style: {
                                        fontSize: 12,
                                        color: '#64748B',
                                        marginBottom: 12,
                                        wordBreak: 'break-all',
                                    },
                                },
                                logoUrl,
                            ),
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                style: {
                                    display: 'flex',
                                    gap: 8,
                                },
                            },
                            /*#__PURE__*/ React.createElement(
                                'button',
                                {
                                    className: 'btn-add-class',
                                    onClick: () => setTab('upload'),
                                },
                                /*#__PURE__*/ React.createElement(Icon, {
                                    emoji: '\u2B06',
                                    size: 18,
                                }),
                                ' Replace',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'button',
                                {
                                    className: 'btn-add-class',
                                    onClick: () => setTab('url'),
                                    style: {
                                        background: '#7C3AED',
                                    },
                                },
                                /*#__PURE__*/ React.createElement(Icon, {
                                    emoji: '\uD83D\uDD17',
                                    size: 18,
                                }),
                                ' Use URL',
                            ),
                            logoUrl &&
                                /*#__PURE__*/ React.createElement(
                                    'button',
                                    {
                                        onClick: handleDelete,
                                        disabled: busy,
                                        style: {
                                            padding: '8px 16px',
                                            background: '#FEF2F2',
                                            color: '#EF4444',
                                            border: 'none',
                                            borderRadius: 8,
                                            fontSize: 13,
                                            fontWeight: 600,
                                            cursor: 'pointer',
                                            fontFamily: 'inherit',
                                        },
                                    },
                                    busy
                                        ? 'Removing…'
                                        : /*#__PURE__*/ React.createElement(
                                              'span',
                                              {
                                                  style: {
                                                      display: 'inline-flex',
                                                      alignItems: 'center',
                                                      gap: 6,
                                                  },
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  Icon,
                                                  {
                                                      emoji: '\uD83D\uDDD1\uFE0F',
                                                      size: 16,
                                                  },
                                              ),
                                              'Remove',
                                          ),
                                ),
                        ),
                    ),
                )
              : tab === 'upload'
                ? /*#__PURE__*/ React.createElement(
                      'div',
                      null,
                      /*#__PURE__*/ React.createElement(
                          'div',
                          {
                              className: 'form-group',
                          },
                          /*#__PURE__*/ React.createElement(
                              'label',
                              {
                                  className: 'form-label',
                              },
                              'Select Image File',
                          ),
                          /*#__PURE__*/ React.createElement('input', {
                              type: 'file',
                              accept: 'image/*',
                              ref: fileRef,
                              className: 'form-input',
                              disabled: busy,
                          }),
                          /*#__PURE__*/ React.createElement(
                              'p',
                              {
                                  style: {
                                      fontSize: 12,
                                      color: '#94A3B8',
                                      marginTop: 4,
                                  },
                              },
                              'Accepted: JPEG, PNG, GIF, WEBP, SVG \u2014 Max 5 MB',
                          ),
                      ),
                      /*#__PURE__*/ React.createElement(
                          'div',
                          {
                              style: {
                                  display: 'flex',
                                  gap: 8,
                              },
                          },
                          /*#__PURE__*/ React.createElement(
                              'button',
                              {
                                  className: 'btn-add-class',
                                  onClick: handleFileUpload,
                                  disabled: busy,
                              },
                              busy
                                  ? 'Uploading…'
                                  : /*#__PURE__*/ React.createElement(
                                        'span',
                                        {
                                            style: {
                                                display: 'inline-flex',
                                                alignItems: 'center',
                                                gap: 6,
                                            },
                                        },
                                        /*#__PURE__*/ React.createElement(
                                            Icon,
                                            {
                                                emoji: '\u2B06',
                                                size: 16,
                                            },
                                        ),
                                        'Upload Logo',
                                    ),
                          ),
                          /*#__PURE__*/ React.createElement(
                              'button',
                              {
                                  className: 'btn-cancel-class',
                                  onClick: () => setTab('current'),
                              },
                              'Cancel',
                          ),
                      ),
                  )
                : /*#__PURE__*/ React.createElement(
                      'div',
                      null,
                      /*#__PURE__*/ React.createElement(
                          'div',
                          {
                              className: 'form-group',
                          },
                          /*#__PURE__*/ React.createElement(
                              'label',
                              {
                                  className: 'form-label',
                              },
                              'Image URL',
                          ),
                          /*#__PURE__*/ React.createElement('input', {
                              type: 'url',
                              className: 'form-input',
                              placeholder: 'https://example.com/logo.png',
                              value: urlInput,
                              onChange: (e) => setUrlInput(e.target.value),
                              disabled: busy,
                          }),
                          urlInput &&
                              /*#__PURE__*/ React.createElement(
                                  'div',
                                  {
                                      style: {
                                          marginTop: 10,
                                      },
                                  },
                                  /*#__PURE__*/ React.createElement('img', {
                                      src: urlInput,
                                      alt: 'Preview',
                                      onError: (e) =>
                                          (e.target.style.display = 'none'),
                                      style: {
                                          maxHeight: 80,
                                          maxWidth: 200,
                                          objectFit: 'contain',
                                          border: '1px solid #E2E8F0',
                                          borderRadius: 8,
                                          padding: 4,
                                      },
                                  }),
                              ),
                      ),
                      /*#__PURE__*/ React.createElement(
                          'div',
                          {
                              style: {
                                  display: 'flex',
                                  gap: 8,
                              },
                          },
                          /*#__PURE__*/ React.createElement(
                              'button',
                              {
                                  className: 'btn-add-class',
                                  onClick: handleUrlSave,
                                  disabled: busy,
                              },
                              busy
                                  ? 'Saving…'
                                  : /*#__PURE__*/ React.createElement(
                                        'span',
                                        {
                                            style: {
                                                display: 'inline-flex',
                                                alignItems: 'center',
                                                gap: 6,
                                            },
                                        },
                                        /*#__PURE__*/ React.createElement(
                                            Icon,
                                            {
                                                emoji: '\uD83D\uDCBE',
                                                size: 16,
                                            },
                                        ),
                                        'Save URL',
                                    ),
                          ),
                          /*#__PURE__*/ React.createElement(
                              'button',
                              {
                                  className: 'btn-cancel-class',
                                  onClick: () => setTab('current'),
                              },
                              'Cancel',
                          ),
                      ),
                  ),
    );
}

/* ═══════════════════════════════════════════════
   ABOUT: MISSION & VISION COMPONENT
   View mode shows saved text with Edit / Clear buttons.
   Editing opens an inline textarea per field.
═══════════════════════════════════════════════ */
function AboutCard({ showAlert }) {
    const [mission, setMission] = useState('');
    const [vision, setVision] = useState('');
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [editField, setEditField] = useState(null); // null | 'mission' | 'vision'
    const [editVal, setEditVal] = useState('');
    useEffect(() => {
        (async () => {
            try {
                const res = await fetch('/nsms/api/settings.php?action=get');
                const text = await res.text();
                let data;
                try {
                    data = JSON.parse(text);
                } catch (e) {
                    return;
                }
                if (data.success && data.data) {
                    setMission(data.data.school_mission || '');
                    setVision(data.data.school_vision || '');
                }
            } catch (e) {
            } finally {
                setLoading(false);
            }
        })();
    }, []);
    const openEdit = (field) => {
        setEditField(field);
        setEditVal(field === 'mission' ? mission : vision);
    };
    const cancelEdit = async () => {
        setEditField(null);
        setEditVal('');
    };
    const handleSave = async () => {
        setBusy(true);
        const payload =
            editField === 'mission'
                ? {
                      school_mission: editVal,
                  }
                : {
                      school_vision: editVal,
                  };
        try {
            const res = await fetch('/nsms/api/settings.php?action=update', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                if (editField === 'mission') setMission(editVal);
                else setVision(editVal);
                showAlert(
                    'success',
                    editField === 'mission'
                        ? /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Mission saved!',
                          )
                        : /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Vision saved!',
                          ),
                );
                cancelEdit();
            } else showAlert('error', data.error || 'Failed to save');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const handleClear = async (field) => {
        if (
            !(await (window.NSMS && window.NSMS.confirm
                ? window.NSMS.confirm({
                      title: 'Confirm action',
                      message: `Clear the school ${field}? It will be removed from the public website.`,
                      confirmLabel: 'Yes, continue',
                      variant: 'danger',
                  })
                : Promise.resolve(false)))
        )
            return;
        setBusy(true);
        const payload =
            field === 'mission'
                ? {
                      school_mission: '',
                  }
                : {
                      school_vision: '',
                  };
        try {
            const res = await fetch('/nsms/api/settings.php?action=update', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                if (field === 'mission') setMission('');
                else setVision('');
                showAlert(
                    'success',
                    `🗑️ ${field.charAt(0).toUpperCase() + field.slice(1)} cleared`,
                );
            } else showAlert('error', data.error || 'Failed to clear');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const renderField = (field, icon, label, value) => {
        const isEditing = editField === field;
        return /*#__PURE__*/ React.createElement(
            'div',
            {
                style: {
                    background: '#F8FAFC',
                    border: '1px solid #E2E8F0',
                    borderRadius: 10,
                    padding: 18,
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 12,
                },
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    style: {
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: 8,
                    },
                },
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        style: {
                            fontSize: 15,
                            fontWeight: 700,
                            color: '#1E293B',
                        },
                    },
                    icon,
                    ' ',
                    label,
                ),
                !isEditing &&
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            style: {
                                display: 'flex',
                                gap: 6,
                                flexShrink: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'button',
                            {
                                className: 'btn-edit-class',
                                onClick: () => openEdit(field),
                                disabled: busy || editField !== null,
                            },
                            /*#__PURE__*/ React.createElement(Icon, {
                                emoji: '\u270F\uFE0F',
                                size: 18,
                            }),
                            ' Edit',
                        ),
                        value &&
                            /*#__PURE__*/ React.createElement(
                                'button',
                                {
                                    className: 'btn-delete-class',
                                    onClick: () => handleClear(field),
                                    disabled: busy || editField !== null,
                                },
                                /*#__PURE__*/ React.createElement(Icon, {
                                    emoji: '\uD83D\uDDD1',
                                    size: 18,
                                }),
                                ' Clear',
                            ),
                    ),
            ),
            isEditing
                ? /*#__PURE__*/ React.createElement(
                      'div',
                      null,
                      /*#__PURE__*/ React.createElement('textarea', {
                          className: 'form-input',
                          rows: 5,
                          placeholder: `Describe the school's ${field}…`,
                          value: editVal,
                          onChange: (e) => setEditVal(e.target.value),
                          disabled: busy,
                          style: {
                              resize: 'vertical',
                              lineHeight: 1.7,
                              marginBottom: 10,
                          },
                          autoFocus: true,
                      }),
                      /*#__PURE__*/ React.createElement(
                          'div',
                          {
                              className: 'class-form-actions',
                              style: {
                                  marginTop: 0,
                              },
                          },
                          /*#__PURE__*/ React.createElement(
                              'button',
                              {
                                  className: 'btn-save-class',
                                  onClick: handleSave,
                                  disabled: busy,
                              },
                              busy ? 'Saving…' : `💾 Save ${label}`,
                          ),
                          /*#__PURE__*/ React.createElement(
                              'button',
                              {
                                  className: 'btn-cancel-class',
                                  onClick: cancelEdit,
                                  disabled: busy,
                              },
                              'Cancel',
                          ),
                      ),
                  )
                : value
                  ? /*#__PURE__*/ React.createElement(
                        'div',
                        null,
                        /*#__PURE__*/ React.createElement(
                            'p',
                            {
                                style: {
                                    fontSize: 14,
                                    color: '#334155',
                                    lineHeight: 1.75,
                                    margin: 0,
                                    whiteSpace: 'pre-wrap',
                                },
                            },
                            value,
                        ),
                        /*#__PURE__*/ React.createElement(
                            'p',
                            {
                                style: {
                                    fontSize: 11,
                                    color: '#94A3B8',
                                    marginTop: 10,
                                    marginBottom: 0,
                                },
                            },
                            'Shown on the public About section of the website.',
                        ),
                    )
                  : /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            style: {
                                textAlign: 'center',
                                padding: '20px 0',
                                color: '#94A3B8',
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                style: {
                                    fontSize: 32,
                                    marginBottom: 8,
                                },
                            },
                            icon,
                        ),
                        /*#__PURE__*/ React.createElement(
                            'div',
                            {
                                style: {
                                    fontSize: 13,
                                    marginBottom: 12,
                                },
                            },
                            'No ',
                            label.toLowerCase(),
                            ' set yet.',
                        ),
                        /*#__PURE__*/ React.createElement(
                            'button',
                            {
                                className: 'btn-add-class',
                                style: {
                                    fontSize: 12,
                                    padding: '6px 16px',
                                },
                                onClick: () => openEdit(field),
                                disabled: editField !== null,
                            },
                            /*#__PURE__*/ React.createElement(Icon, {
                                emoji: '\uFF0B',
                                size: 18,
                            }),
                            ' Add ',
                            label,
                        ),
                    ),
        );
    };
    return /*#__PURE__*/ React.createElement(
        'div',
        {
            className: 'classes-card',
        },
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'classes-header',
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'classes-header-left',
                },
                /*#__PURE__*/ React.createElement(
                    'span',
                    {
                        className: 'settings-icon',
                    },
                    /*#__PURE__*/ React.createElement(Icon, {
                        emoji: '\uD83C\uDFAF',
                        size: 18,
                    }),
                ),
                /*#__PURE__*/ React.createElement(
                    'h2',
                    {
                        className: 'settings-title',
                    },
                    'About \u2014 Mission & Vision',
                ),
            ),
        ),
        loading
            ? /*#__PURE__*/ React.createElement(
                  'div',
                  {
                      className: 'classes-loading',
                  },
                  /*#__PURE__*/ React.createElement('span', {
                      className: 'mini-spinner',
                  }),
                  'Loading\u2026',
              )
            : /*#__PURE__*/ React.createElement(
                  'div',
                  {
                      style: {
                          display: 'grid',
                          gridTemplateColumns: '1fr 1fr',
                          gap: 16,
                      },
                  },
                  renderField(
                      'mission',
                      /*#__PURE__*/ React.createElement(Icon, {
                          name: 'lightbulb',
                          size: 18,
                      }),
                      'Our Mission',
                      mission,
                  ),
                  renderField(
                      'vision',
                      /*#__PURE__*/ React.createElement(Icon, {
                          name: 'telescope',
                          size: 18,
                      }),
                      'Our Vision',
                      vision,
                  ),
              ),
    );
}

/* ═══════════════════════════════════════════════
   REGULATIONS MANAGEMENT COMPONENT
═══════════════════════════════════════════════ */
function RegulationsCard({ showAlert }) {
    const RULE_ICONS = [
        '📌',
        '🕖',
        '👗',
        '🍎',
        '📵',
        '🤝',
        '🚗',
        '💊',
        '📢',
        /*#__PURE__*/ React.createElement(Icon, {
            emoji: '\uD83D\uDEE1',
            size: 16,
        }),
        '📋',
        /*#__PURE__*/ React.createElement(Icon, {
            emoji: '\u270F',
            size: 16,
        }),
        '🔑',
        '🌿',
        '🎒',
    ];
    const [rules, setRules] = useState([]);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [form, setForm] = useState(null); // null | { id, icon, title, text } | 'add'
    const [confirmDel, setConfirmDel] = useState(null);
    useEffect(() => {
        loadRules();
    }, []);
    const loadRules = async () => {
        setLoading(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=get_regulations',
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                return;
            }
            if (data.success) setRules(data.data || []);
        } catch (e) {
        } finally {
            setLoading(false);
        }
    };
    const openAdd = () => {
        setForm({
            id: null,
            icon: /*#__PURE__*/ React.createElement(Icon, {
                emoji: '\uD83D\uDCCC',
                size: 20,
            }),
            title: '',
            text: '',
        });
        setConfirmDel(null);
    };
    const openEdit = (r) => {
        setForm({
            id: r.id,
            icon: r.icon || '📌',
            title: r.title,
            text: r.text || '',
        });
        setConfirmDel(null);
    };
    const closeForm = () => setForm(null);
    const handleSave = async () => {
        if (!form.title.trim()) {
            showAlert('error', 'Title is required');
            return;
        }
        setBusy(true);
        try {
            const payload = {
                id: form.id || null,
                icon: form.icon,
                title: form.title.trim(),
                text: form.text.trim(),
                is_visible: 1,
            };
            const res = await fetch(
                '/nsms/api/settings.php?action=save_regulations',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payload),
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    form.id
                        ? /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Rule updated!',
                          )
                        : /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Rule added!',
                          ),
                );
                closeForm();
                await loadRules();
            } else showAlert('error', data.error || 'Failed to save rule');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const handleDelete = async (id) => {
        setBusy(true);
        try {
            const res = await fetch(
                `/nsms/api/settings.php?action=delete_regulation&id=${id}`,
                {
                    method: 'DELETE',
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\uD83D\uDDD1\uFE0F',
                            size: 16,
                        }),
                        'Rule deleted',
                    ),
                );
                setConfirmDel(null);
                await loadRules();
            } else showAlert('error', data.error || 'Failed to delete');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    return /*#__PURE__*/ React.createElement(
        'div',
        {
            className: 'classes-card',
        },
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'classes-header',
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'classes-header-left',
                },
                /*#__PURE__*/ React.createElement(
                    'span',
                    {
                        className: 'settings-icon',
                    },
                    /*#__PURE__*/ React.createElement(Icon, {
                        emoji: '\uD83D\uDCDC',
                        size: 18,
                    }),
                ),
                /*#__PURE__*/ React.createElement(
                    'h2',
                    {
                        className: 'settings-title',
                    },
                    'School Rules & Regulations',
                ),
            ),
            /*#__PURE__*/ React.createElement(
                'button',
                {
                    className: 'btn-add-class',
                    onClick: openAdd,
                    disabled: busy || form !== null,
                },
                /*#__PURE__*/ React.createElement(Icon, {
                    emoji: '\uFF0B',
                    size: 18,
                }),
                ' Add Rule',
            ),
        ),
        form !== null &&
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'class-form-box',
                },
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-title',
                    },
                    form.id ? 'Edit Rule' : 'Add New Rule',
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        style: {
                            marginBottom: 12,
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'label',
                        {
                            className: 'form-label',
                        },
                        'Icon',
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            style: {
                                display: 'flex',
                                flexWrap: 'wrap',
                                gap: 6,
                                marginTop: 4,
                            },
                        },
                        RULE_ICONS.map((ic) =>
                            /*#__PURE__*/ React.createElement(
                                'button',
                                {
                                    key: ic,
                                    onClick: () =>
                                        setForm({
                                            ...form,
                                            icon: ic,
                                        }),
                                    disabled: busy,
                                    style: {
                                        fontSize: 18,
                                        width: 36,
                                        height: 36,
                                        border: `2px solid ${form.icon === ic ? '#2563EB' : '#E2E8F0'}`,
                                        borderRadius: 8,
                                        cursor: 'pointer',
                                        background:
                                            form.icon === ic
                                                ? '#EFF6FF'
                                                : 'white',
                                    },
                                },
                                ic,
                            ),
                        ),
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-row',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Title *',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'text',
                            placeholder: 'e.g. School Uniform',
                            value: form.title,
                            onChange: (e) =>
                                setForm({
                                    ...form,
                                    title: e.target.value,
                                }),
                            disabled: busy,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Description',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'text',
                            placeholder: 'Brief explanation of the rule',
                            value: form.text,
                            onChange: (e) =>
                                setForm({
                                    ...form,
                                    text: e.target.value,
                                }),
                            disabled: busy,
                        }),
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-actions',
                    },
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-save-class',
                            onClick: handleSave,
                            disabled: busy,
                        },
                        busy
                            ? 'Saving…'
                            : form.id
                              ? 'Update Rule'
                              : 'Save Rule',
                    ),
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-cancel-class',
                            onClick: closeForm,
                            disabled: busy,
                        },
                        'Cancel',
                    ),
                ),
            ),
        loading
            ? /*#__PURE__*/ React.createElement(
                  'div',
                  {
                      className: 'classes-loading',
                  },
                  /*#__PURE__*/ React.createElement('span', {
                      className: 'mini-spinner',
                  }),
                  'Loading rules\u2026',
              )
            : rules.length === 0
              ? /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'classes-empty',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-icon',
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\uD83D\uDCDC',
                            size: 18,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-text',
                        },
                        'No rules yet. Click "Add Rule" to get started.',
                    ),
                )
              : /*#__PURE__*/ React.createElement(
                    'table',
                    {
                        className: 'classes-table',
                    },
                    /*#__PURE__*/ React.createElement(
                        'thead',
                        null,
                        /*#__PURE__*/ React.createElement(
                            'tr',
                            null,
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Icon',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Title',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Description',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Actions',
                            ),
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'tbody',
                        null,
                        rules.map((r) =>
                            confirmDel === r.id
                                ? /*#__PURE__*/ React.createElement(
                                      'tr',
                                      {
                                          key: r.id,
                                          className: 'delete-confirm-row',
                                      },
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              colSpan: 4,
                                          },
                                          /*#__PURE__*/ React.createElement(
                                              'div',
                                              {
                                                  className:
                                                      'delete-confirm-content',
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  'span',
                                                  {
                                                      className:
                                                          'delete-confirm-text',
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      Icon,
                                                      {
                                                          emoji: '\u26A0\uFE0F',
                                                          size: 18,
                                                      },
                                                  ),
                                                  ' Delete "',
                                                  r.title,
                                                  '"? This cannot be undone.',
                                              ),
                                              /*#__PURE__*/ React.createElement(
                                                  'div',
                                                  {
                                                      className:
                                                          'delete-confirm-actions',
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      'button',
                                                      {
                                                          className:
                                                              'btn-confirm-delete',
                                                          onClick: () =>
                                                              handleDelete(
                                                                  r.id,
                                                              ),
                                                          disabled: busy,
                                                      },
                                                      busy
                                                          ? 'Deleting…'
                                                          : 'Yes, Delete',
                                                  ),
                                                  /*#__PURE__*/ React.createElement(
                                                      'button',
                                                      {
                                                          className:
                                                              'btn-cancel-delete',
                                                          onClick: () =>
                                                              setConfirmDel(
                                                                  null,
                                                              ),
                                                      },
                                                      'Cancel',
                                                  ),
                                              ),
                                          ),
                                      ),
                                  )
                                : /*#__PURE__*/ React.createElement(
                                      'tr',
                                      {
                                          key: r.id,
                                      },
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              style: {
                                                  fontSize: 22,
                                              },
                                          },
                                          renderIcon(r.icon, 20),
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              style: {
                                                  fontWeight: 600,
                                              },
                                          },
                                          r.title,
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              style: {
                                                  color: '#64748B',
                                                  maxWidth: 320,
                                                  overflow: 'hidden',
                                                  textOverflow: 'ellipsis',
                                                  whiteSpace: 'nowrap',
                                              },
                                          },
                                          r.text,
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          null,
                                          /*#__PURE__*/ React.createElement(
                                              'div',
                                              {
                                                  className: 'class-actions',
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  'button',
                                                  {
                                                      className:
                                                          'btn-edit-class',
                                                      onClick: () =>
                                                          openEdit(r),
                                                      disabled:
                                                          busy || form !== null,
                                                  },
                                                  'Edit',
                                              ),
                                              /*#__PURE__*/ React.createElement(
                                                  'button',
                                                  {
                                                      className:
                                                          'btn-delete-class',
                                                      onClick: () =>
                                                          setConfirmDel(r.id),
                                                      disabled:
                                                          busy || form !== null,
                                                  },
                                                  'Delete',
                                              ),
                                          ),
                                      ),
                                  ),
                        ),
                    ),
                ),
    );
}

/* ═══════════════════════════════════════════════
   ACADEMIC YEAR SCHEDULE COMPONENT
   Stores structured term/exam/graduation dates.
   Reads/writes via get_academic_schedule & save_academic_schedule.
═══════════════════════════════════════════════ */
function AcademicScheduleCard({ showAlert }) {
    const EMPTY = {
        acad_term1_start: '',
        acad_term1_end: '',
        acad_term1_exam_start: '',
        acad_term1_exam_end: '',
        acad_term2_start: '',
        acad_term2_end: '',
        acad_term2_exam_start: '',
        acad_term2_exam_end: '',
        acad_graduation_date: '',
    };
    const [schedule, setSchedule] = useState(EMPTY);
    const [draft, setDraft] = useState(EMPTY);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [editing, setEditing] = useState(false);
    useEffect(() => {
        loadSchedule();
    }, []);
    const loadSchedule = async () => {
        setLoading(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=get_academic_schedule',
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                return;
            }
            if (data.success) {
                setSchedule(data.data || EMPTY);
            }
        } catch (e) {
        } finally {
            setLoading(false);
        }
    };
    const startEdit = () => {
        setDraft({
            ...schedule,
        });
        setEditing(true);
    };
    const cancelEdit = () => {
        setEditing(false);
    };
    const handleSave = async () => {
        setSaving(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=save_academic_schedule',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(draft),
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                setSchedule({
                    ...draft,
                });
                setEditing(false);
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\u2705',
                            size: 16,
                        }),
                        'Academic schedule saved!',
                    ),
                );
            } else {
                showAlert('error', data.error || 'Failed to save schedule');
            }
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setSaving(false);
        }
    };
    const set = (key, val) =>
        setDraft((p) => ({
            ...p,
            [key]: val,
        }));

    /* ── tiny helpers ── */
    const fmtDate = (d) => {
        if (!d) return null;
        const parts = d.split('-');
        if (parts.length !== 3) return d;
        const months = [
            'Jan',
            'Feb',
            'Mar',
            'Apr',
            'May',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Oct',
            'Nov',
            'Dec',
        ];
        return `${parseInt(parts[2])} ${months[parseInt(parts[1]) - 1]} ${parts[0]}`;
    };
    const ViewRange = ({ s, e }) =>
        s || e
            ? /*#__PURE__*/ React.createElement(
                  'span',
                  {
                      style: {
                          color: '#1E293B',
                          fontWeight: 500,
                      },
                  },
                  fmtDate(s) || '?',
                  ' \u2192 ',
                  fmtDate(e) || '?',
              )
            : /*#__PURE__*/ React.createElement(
                  'span',
                  {
                      style: {
                          color: '#94A3B8',
                          fontStyle: 'italic',
                      },
                  },
                  'Not set',
              );
    const ViewSingle = ({ v }) =>
        v
            ? /*#__PURE__*/ React.createElement(
                  'span',
                  {
                      style: {
                          color: '#1E293B',
                          fontWeight: 500,
                      },
                  },
                  fmtDate(v),
              )
            : /*#__PURE__*/ React.createElement(
                  'span',
                  {
                      style: {
                          color: '#94A3B8',
                          fontStyle: 'italic',
                      },
                  },
                  'Not set',
              );
    const FieldRow = ({ label, startKey, endKey }) =>
        /*#__PURE__*/ React.createElement(
            'div',
            {
                style: {
                    marginBottom: 12,
                },
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    style: {
                        fontSize: 12,
                        fontWeight: 600,
                        color: '#64748B',
                        marginBottom: 5,
                    },
                },
                label,
            ),
            editing
                ? /*#__PURE__*/ React.createElement(
                      'div',
                      {
                          style: {
                              display: 'grid',
                              gridTemplateColumns: '1fr 1fr',
                              gap: 8,
                          },
                      },
                      /*#__PURE__*/ React.createElement(
                          'div',
                          null,
                          /*#__PURE__*/ React.createElement(
                              'div',
                              {
                                  style: {
                                      fontSize: 11,
                                      color: '#94A3B8',
                                      marginBottom: 3,
                                  },
                              },
                              'Start',
                          ),
                          /*#__PURE__*/ React.createElement('input', {
                              type: 'date',
                              className: 'form-input',
                              value: draft[startKey] || '',
                              onChange: (e) => set(startKey, e.target.value),
                              disabled: saving,
                              style: {
                                  fontSize: 13,
                              },
                          }),
                      ),
                      /*#__PURE__*/ React.createElement(
                          'div',
                          null,
                          /*#__PURE__*/ React.createElement(
                              'div',
                              {
                                  style: {
                                      fontSize: 11,
                                      color: '#94A3B8',
                                      marginBottom: 3,
                                  },
                              },
                              'End',
                          ),
                          /*#__PURE__*/ React.createElement('input', {
                              type: 'date',
                              className: 'form-input',
                              value: draft[endKey] || '',
                              onChange: (e) => set(endKey, e.target.value),
                              disabled: saving,
                              style: {
                                  fontSize: 13,
                              },
                          }),
                      ),
                  )
                : /*#__PURE__*/ React.createElement(
                      'div',
                      {
                          style: {
                              background: 'white',
                              padding: '8px 12px',
                              borderRadius: 7,
                              border: '1px solid #E2E8F0',
                              fontSize: 13,
                          },
                      },
                      /*#__PURE__*/ React.createElement(ViewRange, {
                          s: schedule[startKey],
                          e: schedule[endKey],
                      }),
                  ),
        );
    const SingleRow = ({ label, fieldKey }) =>
        /*#__PURE__*/ React.createElement(
            'div',
            {
                style: {
                    marginBottom: 4,
                },
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    style: {
                        fontSize: 12,
                        fontWeight: 600,
                        color: '#64748B',
                        marginBottom: 5,
                    },
                },
                label,
            ),
            editing
                ? /*#__PURE__*/ React.createElement('input', {
                      type: 'date',
                      className: 'form-input',
                      value: draft[fieldKey] || '',
                      onChange: (e) => set(fieldKey, e.target.value),
                      disabled: saving,
                      style: {
                          fontSize: 13,
                          maxWidth: 220,
                      },
                  })
                : /*#__PURE__*/ React.createElement(
                      'div',
                      {
                          style: {
                              background: 'white',
                              padding: '8px 12px',
                              borderRadius: 7,
                              border: '1px solid #FDE68A',
                              fontSize: 13,
                              display: 'inline-block',
                              minWidth: 180,
                          },
                      },
                      /*#__PURE__*/ React.createElement(ViewSingle, {
                          v: schedule[fieldKey],
                      }),
                  ),
        );
    const PanelTitle = ({ emoji, label, color }) =>
        /*#__PURE__*/ React.createElement(
            'div',
            {
                style: {
                    display: 'flex',
                    alignItems: 'center',
                    gap: 8,
                    fontSize: 13,
                    fontWeight: 700,
                    color: color,
                    marginBottom: 14,
                    paddingBottom: 8,
                    borderBottom: `2px solid ${color}33`,
                },
            },
            emoji,
            ' ',
            label,
        );
    const ExamSubTitle = () =>
        /*#__PURE__*/ React.createElement(
            'div',
            {
                style: {
                    fontSize: 11,
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: 0.7,
                    color: '#EF4444',
                    marginTop: 14,
                    marginBottom: 8,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 5,
                },
            },
            /*#__PURE__*/ React.createElement(Icon, {
                emoji: '\u270F\uFE0F',
                size: 18,
            }),
            ' Terminal Examinations',
        );
    return /*#__PURE__*/ React.createElement(
        'div',
        {
            className: 'classes-card',
        },
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'classes-header',
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'classes-header-left',
                },
                /*#__PURE__*/ React.createElement(
                    'span',
                    {
                        className: 'settings-icon',
                    },
                    /*#__PURE__*/ React.createElement(Icon, {
                        emoji: '\uD83D\uDCC6',
                        size: 18,
                    }),
                ),
                /*#__PURE__*/ React.createElement(
                    'h2',
                    {
                        className: 'settings-title',
                    },
                    'Academic Year Schedule',
                ),
            ),
            !editing
                ? /*#__PURE__*/ React.createElement(
                      'button',
                      {
                          className: 'btn-add-class',
                          onClick: startEdit,
                          disabled: loading,
                      },
                      /*#__PURE__*/ React.createElement(Icon, {
                          emoji: '\u270F\uFE0F',
                          size: 18,
                      }),
                      ' Edit Schedule',
                  )
                : /*#__PURE__*/ React.createElement(
                      'div',
                      {
                          style: {
                              display: 'flex',
                              gap: 8,
                          },
                      },
                      /*#__PURE__*/ React.createElement(
                          'button',
                          {
                              onClick: handleSave,
                              disabled: saving,
                              style: {
                                  padding: '8px 20px',
                                  background: '#2563EB',
                                  color: 'white',
                                  border: 'none',
                                  borderRadius: 8,
                                  fontSize: 13,
                                  fontWeight: 600,
                                  cursor: 'pointer',
                                  fontFamily: 'inherit',
                              },
                          },
                          saving
                              ? 'Saving…'
                              : /*#__PURE__*/ React.createElement(
                                    'span',
                                    {
                                        style: {
                                            display: 'inline-flex',
                                            alignItems: 'center',
                                            gap: 6,
                                        },
                                    },
                                    /*#__PURE__*/ React.createElement(Icon, {
                                        emoji: '\uD83D\uDCBE',
                                        size: 16,
                                    }),
                                    'Save Schedule',
                                ),
                      ),
                      /*#__PURE__*/ React.createElement(
                          'button',
                          {
                              className: 'btn-cancel-class',
                              onClick: cancelEdit,
                              disabled: saving,
                          },
                          'Cancel',
                      ),
                  ),
        ),
        /*#__PURE__*/ React.createElement(
            'div',
            {
                style: {
                    background: '#EFF6FF',
                    border: '1px solid #BFDBFE',
                    borderRadius: 8,
                    padding: '10px 14px',
                    marginBottom: 20,
                    fontSize: 13,
                    color: '#1E40AF',
                    lineHeight: 1.5,
                },
            },
            /*#__PURE__*/ React.createElement(Icon, {
                emoji: '\uD83D\uDCCC',
                size: 18,
            }),
            ' These dates drive the student lifecycle \u2014 term progress, terminal examination records, and the graduating class ceremony are all anchored to this schedule.',
        ),
        loading
            ? /*#__PURE__*/ React.createElement(
                  'div',
                  {
                      className: 'classes-loading',
                  },
                  /*#__PURE__*/ React.createElement('span', {
                      className: 'mini-spinner',
                  }),
                  'Loading schedule\u2026',
              )
            : /*#__PURE__*/ React.createElement(
                  'div',
                  null,
                  /*#__PURE__*/ React.createElement(
                      'div',
                      {
                          style: {
                              display: 'grid',
                              gridTemplateColumns: '1fr 1fr',
                              gap: 16,
                              marginBottom: 16,
                          },
                      },
                      /*#__PURE__*/ React.createElement(
                          'div',
                          {
                              style: {
                                  background: '#F8FAFC',
                                  borderRadius: 10,
                                  padding: 16,
                                  border: '1px solid #E2E8F0',
                              },
                          },
                          /*#__PURE__*/ React.createElement(PanelTitle, {
                              emoji: '\uD83D\uDCDA',
                              label: 'Term 1',
                              color: '#2563EB',
                          }),
                          /*#__PURE__*/ React.createElement(FieldRow, {
                              label: 'Term Period',
                              startKey: 'acad_term1_start',
                              endKey: 'acad_term1_end',
                          }),
                          /*#__PURE__*/ React.createElement(ExamSubTitle, null),
                          /*#__PURE__*/ React.createElement(FieldRow, {
                              label: 'Exam Period',
                              startKey: 'acad_term1_exam_start',
                              endKey: 'acad_term1_exam_end',
                          }),
                      ),
                      /*#__PURE__*/ React.createElement(
                          'div',
                          {
                              style: {
                                  background: '#F8FAFC',
                                  borderRadius: 10,
                                  padding: 16,
                                  border: '1px solid #E2E8F0',
                              },
                          },
                          /*#__PURE__*/ React.createElement(PanelTitle, {
                              emoji: '\uD83D\uDCDA',
                              label: 'Term 2',
                              color: '#10B981',
                          }),
                          /*#__PURE__*/ React.createElement(FieldRow, {
                              label: 'Term Period',
                              startKey: 'acad_term2_start',
                              endKey: 'acad_term2_end',
                          }),
                          /*#__PURE__*/ React.createElement(ExamSubTitle, null),
                          /*#__PURE__*/ React.createElement(FieldRow, {
                              label: 'Exam Period',
                              startKey: 'acad_term2_exam_start',
                              endKey: 'acad_term2_exam_end',
                          }),
                      ),
                  ),
                  /*#__PURE__*/ React.createElement(
                      'div',
                      {
                          style: {
                              background: '#FEFCE8',
                              borderRadius: 10,
                              padding: 16,
                              border: '1px solid #FDE68A',
                              borderLeft: '4px solid #F59E0B',
                          },
                      },
                      /*#__PURE__*/ React.createElement(PanelTitle, {
                          emoji: '\uD83C\uDF93',
                          label: 'Graduation Ceremony',
                          color: '#D97706',
                      }),
                      /*#__PURE__*/ React.createElement(SingleRow, {
                          label: 'Ceremony Date',
                          fieldKey: 'acad_graduation_date',
                      }),
                      /*#__PURE__*/ React.createElement(
                          'div',
                          {
                              style: {
                                  fontSize: 12,
                                  color: '#92400E',
                                  marginTop: 8,
                              },
                          },
                          'This is the ceremony date for the graduating (top) class of the current academic year.',
                      ),
                  ),
              ),
    );
}

/* ═══════════════════════════════════════════════
   SCHOOL CALENDAR MANAGEMENT COMPONENT
═══════════════════════════════════════════════ */
function CalendarCard({ showAlert }) {
    const EVENT_TYPES = ['term', 'holiday', 'event', 'exam'];
    const TYPE_COLORS = {
        term: '#2563EB',
        holiday: '#10B981',
        event: '#F59E0B',
        exam: '#EF4444',
    };
    const DEFAULT_ICONS = {
        term: '📚',
        holiday: '🌴',
        event: '🎉',
        exam: '✏️',
    };
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [form, setForm] = useState(null);
    const [confirmDel, setConfirmDel] = useState(null);
    useEffect(() => {
        loadEvents();
    }, []);
    const loadEvents = async () => {
        setLoading(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=get_calendar',
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                return;
            }
            if (data.success) setEvents(data.data || []);
        } catch (e) {
        } finally {
            setLoading(false);
        }
    };
    const openAdd = () => {
        setForm({
            id: null,
            icon: /*#__PURE__*/ React.createElement(Icon, {
                emoji: '\uD83D\uDCC5',
                size: 20,
            }),
            type: 'event',
            title: '',
            date: '',
            desc: '',
            is_visible: 1,
        });
        setConfirmDel(null);
    };
    const openEdit = (e) => {
        setForm({
            id: e.id,
            icon: e.icon,
            type: e.type,
            title: e.title,
            date: e.date,
            desc: e.desc || '',
            is_visible: 1,
        });
        setConfirmDel(null);
    };
    const closeForm = () => setForm(null);
    const handleSave = async () => {
        if (!form.title.trim()) {
            showAlert('error', 'Title is required');
            return;
        }
        if (!form.date) {
            showAlert('error', 'Date is required');
            return;
        }
        setBusy(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=save_calendar',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(form),
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    form.id
                        ? /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Event updated!',
                          )
                        : /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Event added!',
                          ),
                );
                closeForm();
                await loadEvents();
            } else showAlert('error', data.error || 'Failed to save event');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const handleDelete = async (id) => {
        setBusy(true);
        try {
            const res = await fetch(
                `/nsms/api/settings.php?action=delete_calendar&id=${id}`,
                {
                    method: 'DELETE',
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\uD83D\uDDD1\uFE0F',
                            size: 16,
                        }),
                        'Event deleted',
                    ),
                );
                setConfirmDel(null);
                await loadEvents();
            } else showAlert('error', data.error || 'Failed to delete');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const typeBadge = (type) =>
        /*#__PURE__*/ React.createElement(
            'span',
            {
                style: {
                    display: 'inline-block',
                    padding: '2px 10px',
                    borderRadius: 20,
                    fontSize: 11,
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: 0.4,
                    background: TYPE_COLORS[type] + '22',
                    color: TYPE_COLORS[type],
                },
            },
            type,
        );
    return /*#__PURE__*/ React.createElement(
        'div',
        {
            className: 'classes-card',
        },
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'classes-header',
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'classes-header-left',
                },
                /*#__PURE__*/ React.createElement(
                    'span',
                    {
                        className: 'settings-icon',
                    },
                    /*#__PURE__*/ React.createElement(Icon, {
                        emoji: '\uD83D\uDCC5',
                        size: 18,
                    }),
                ),
                /*#__PURE__*/ React.createElement(
                    'h2',
                    {
                        className: 'settings-title',
                    },
                    'School Calendar',
                ),
            ),
            /*#__PURE__*/ React.createElement(
                'button',
                {
                    className: 'btn-add-class',
                    onClick: openAdd,
                    disabled: busy || form !== null,
                },
                /*#__PURE__*/ React.createElement(Icon, {
                    emoji: '\uFF0B',
                    size: 18,
                }),
                ' Add Event',
            ),
        ),
        form !== null &&
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'class-form-box',
                },
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-title',
                    },
                    form.id ? 'Edit Calendar Event' : 'Add New Calendar Event',
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-row',
                        style: {
                            marginBottom: 12,
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Title *',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'text',
                            placeholder: 'e.g. Term 1 Begins',
                            value: form.title,
                            onChange: (e) =>
                                setForm({
                                    ...form,
                                    title: e.target.value,
                                }),
                            disabled: busy,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Date *',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'date',
                            value: form.date,
                            onChange: (e) =>
                                setForm({
                                    ...form,
                                    date: e.target.value,
                                }),
                            disabled: busy,
                        }),
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-row',
                        style: {
                            marginBottom: 12,
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Type',
                        ),
                        /*#__PURE__*/ React.createElement(
                            'select',
                            {
                                className: 'form-input',
                                value: form.type,
                                onChange: (e) =>
                                    setForm({
                                        ...form,
                                        type: e.target.value,
                                        icon:
                                            DEFAULT_ICONS[e.target.value] ||
                                            form.icon,
                                    }),
                                disabled: busy,
                            },
                            EVENT_TYPES.map((t) =>
                                /*#__PURE__*/ React.createElement(
                                    'option',
                                    {
                                        key: t,
                                        value: t,
                                    },
                                    t.charAt(0).toUpperCase() + t.slice(1),
                                ),
                            ),
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Icon (emoji)',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'text',
                            maxLength: 4,
                            placeholder: '\uD83D\uDCC5',
                            value: form.icon,
                            onChange: (e) =>
                                setForm({
                                    ...form,
                                    icon: e.target.value,
                                }),
                            disabled: busy,
                        }),
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'form-group',
                        style: {
                            marginBottom: 0,
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'label',
                        {
                            className: 'form-label',
                        },
                        'Description',
                    ),
                    /*#__PURE__*/ React.createElement('input', {
                        className: 'form-input',
                        type: 'text',
                        placeholder: 'Brief description of the event',
                        value: form.desc,
                        onChange: (e) =>
                            setForm({
                                ...form,
                                desc: e.target.value,
                            }),
                        disabled: busy,
                    }),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-actions',
                    },
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-save-class',
                            onClick: handleSave,
                            disabled: busy,
                        },
                        busy
                            ? 'Saving…'
                            : form.id
                              ? 'Update Event'
                              : 'Save Event',
                    ),
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-cancel-class',
                            onClick: closeForm,
                            disabled: busy,
                        },
                        'Cancel',
                    ),
                ),
            ),
        loading
            ? /*#__PURE__*/ React.createElement(
                  'div',
                  {
                      className: 'classes-loading',
                  },
                  /*#__PURE__*/ React.createElement('span', {
                      className: 'mini-spinner',
                  }),
                  'Loading events\u2026',
              )
            : events.length === 0
              ? /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'classes-empty',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-icon',
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\uD83D\uDCC5',
                            size: 18,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-text',
                        },
                        'No calendar events yet. Click "Add Event" to start.',
                    ),
                )
              : /*#__PURE__*/ React.createElement(
                    'table',
                    {
                        className: 'classes-table',
                    },
                    /*#__PURE__*/ React.createElement(
                        'thead',
                        null,
                        /*#__PURE__*/ React.createElement(
                            'tr',
                            null,
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Date',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Icon',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Title',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Type',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Description',
                            ),
                            /*#__PURE__*/ React.createElement(
                                'th',
                                null,
                                'Actions',
                            ),
                        ),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'tbody',
                        null,
                        events.map((ev) =>
                            confirmDel === ev.id
                                ? /*#__PURE__*/ React.createElement(
                                      'tr',
                                      {
                                          key: ev.id,
                                          className: 'delete-confirm-row',
                                      },
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              colSpan: 6,
                                          },
                                          /*#__PURE__*/ React.createElement(
                                              'div',
                                              {
                                                  className:
                                                      'delete-confirm-content',
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  'span',
                                                  {
                                                      className:
                                                          'delete-confirm-text',
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      Icon,
                                                      {
                                                          emoji: '\u26A0\uFE0F',
                                                          size: 18,
                                                      },
                                                  ),
                                                  ' Delete "',
                                                  ev.title,
                                                  '"?',
                                              ),
                                              /*#__PURE__*/ React.createElement(
                                                  'div',
                                                  {
                                                      className:
                                                          'delete-confirm-actions',
                                                  },
                                                  /*#__PURE__*/ React.createElement(
                                                      'button',
                                                      {
                                                          className:
                                                              'btn-confirm-delete',
                                                          onClick: () =>
                                                              handleDelete(
                                                                  ev.id,
                                                              ),
                                                          disabled: busy,
                                                      },
                                                      busy
                                                          ? 'Deleting…'
                                                          : 'Yes, Delete',
                                                  ),
                                                  /*#__PURE__*/ React.createElement(
                                                      'button',
                                                      {
                                                          className:
                                                              'btn-cancel-delete',
                                                          onClick: () =>
                                                              setConfirmDel(
                                                                  null,
                                                              ),
                                                      },
                                                      'Cancel',
                                                  ),
                                              ),
                                          ),
                                      ),
                                  )
                                : /*#__PURE__*/ React.createElement(
                                      'tr',
                                      {
                                          key: ev.id,
                                      },
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              style: {
                                                  fontFamily: 'monospace',
                                                  fontSize: 13,
                                                  whiteSpace: 'nowrap',
                                              },
                                          },
                                          ev.date,
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              style: {
                                                  fontSize: 20,
                                              },
                                          },
                                          renderIcon(ev.icon, 20),
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              style: {
                                                  fontWeight: 600,
                                              },
                                          },
                                          ev.title,
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          null,
                                          typeBadge(ev.type),
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          {
                                              style: {
                                                  color: '#64748B',
                                                  maxWidth: 260,
                                                  overflow: 'hidden',
                                                  textOverflow: 'ellipsis',
                                                  whiteSpace: 'nowrap',
                                              },
                                          },
                                          ev.desc,
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'td',
                                          null,
                                          /*#__PURE__*/ React.createElement(
                                              'div',
                                              {
                                                  className: 'class-actions',
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  'button',
                                                  {
                                                      className:
                                                          'btn-edit-class',
                                                      onClick: () =>
                                                          openEdit(ev),
                                                      disabled:
                                                          busy || form !== null,
                                                  },
                                                  'Edit',
                                              ),
                                              /*#__PURE__*/ React.createElement(
                                                  'button',
                                                  {
                                                      className:
                                                          'btn-delete-class',
                                                      onClick: () =>
                                                          setConfirmDel(ev.id),
                                                      disabled:
                                                          busy || form !== null,
                                                  },
                                                  'Delete',
                                              ),
                                          ),
                                      ),
                                  ),
                        ),
                    ),
                ),
    );
}

/* ═══════════════════════════════════════════════
   GALLERY MANAGEMENT COMPONENT
═══════════════════════════════════════════════ */
function GalleryCard({ showAlert }) {
    const [images, setImages] = useState([]);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [form, setForm] = useState(null);
    const [confirmDel, setConfirmDel] = useState(null);
    const [srcMode, setSrcMode] = useState('file'); // 'file' | 'url'
    const [uploading, setUploading] = useState(false);
    const fileRef = useRef(null);
    useEffect(() => {
        loadGallery();
    }, []);
    const loadGallery = async () => {
        setLoading(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=get_gallery',
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                return;
            }
            if (data.success) setImages(data.data || []);
        } catch (e) {
        } finally {
            setLoading(false);
        }
    };
    const blankForm = () => ({
        id: null,
        url: '',
        caption: '',
        date: new Date().toISOString().slice(0, 10),
        sort_order: 0,
        is_visible: 1,
    });
    const openAdd = () => {
        setForm(blankForm());
        setSrcMode('file');
        setConfirmDel(null);
    };
    const openEdit = (img) => {
        setForm({
            id: img.id,
            url: img.url,
            caption: img.caption || '',
            date: img.date || '',
            sort_order: img.sort_order ?? 0,
            is_visible: 1,
        });
        setSrcMode('url'); // edit always shows URL tab (the URL is already set)
        setConfirmDel(null);
    };
    const closeForm = () => {
        setForm(null);
        setSrcMode('file');
        if (fileRef.current) fileRef.current.value = '';
    };

    /* Upload file → get URL back → put it in form.url */
    const handleFileUpload = async () => {
        if (!fileRef.current?.files?.[0]) {
            showAlert('error', 'Please select an image file first');
            return;
        }
        setUploading(true);
        const fd = new FormData();
        fd.append('image', fileRef.current.files[0]);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=upload_gallery_image',
                {
                    method: 'POST',
                    body: fd,
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                setForm((prev) => ({
                    ...prev,
                    url: data.data.url,
                }));
                fileRef.current.value = '';
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\u2705',
                            size: 16,
                        }),
                        'Image uploaded! Add a caption and save.',
                    ),
                );
            } else showAlert('error', data.error || 'Upload failed');
        } catch (e) {
            showAlert('error', 'Network error during upload');
        } finally {
            setUploading(false);
        }
    };
    const handleSave = async () => {
        if (!form.url.trim()) {
            showAlert('error', 'Please upload an image or provide a URL');
            return;
        }
        setBusy(true);
        try {
            const res = await fetch(
                '/nsms/api/settings.php?action=save_gallery',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(form),
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    form.id
                        ? /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Image updated!',
                          )
                        : /*#__PURE__*/ React.createElement(
                              'span',
                              {
                                  style: {
                                      display: 'inline-flex',
                                      alignItems: 'center',
                                      gap: 6,
                                  },
                              },
                              /*#__PURE__*/ React.createElement(Icon, {
                                  emoji: '\u2705',
                                  size: 16,
                              }),
                              'Image added!',
                          ),
                );
                closeForm();
                await loadGallery();
            } else showAlert('error', data.error || 'Failed to save image');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const handleDelete = async (id) => {
        setBusy(true);
        try {
            const res = await fetch(
                `/nsms/api/settings.php?action=delete_gallery_item&id=${id}`,
                {
                    method: 'DELETE',
                },
            );
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                showAlert('error', 'Bad server response');
                return;
            }
            if (data.success) {
                showAlert(
                    'success',
                    /*#__PURE__*/ React.createElement(
                        'span',
                        {
                            style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                            },
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\uD83D\uDDD1\uFE0F',
                            size: 16,
                        }),
                        'Image deleted',
                    ),
                );
                setConfirmDel(null);
                await loadGallery();
            } else showAlert('error', data.error || 'Failed to delete');
        } catch (e) {
            showAlert('error', 'Network error');
        } finally {
            setBusy(false);
        }
    };
    const srcTabStyle = (t) => ({
        padding: '6px 16px',
        border: 'none',
        borderRadius: 6,
        fontSize: 13,
        fontWeight: 600,
        cursor: 'pointer',
        fontFamily: 'inherit',
        transition: 'all .15s',
        background: srcMode === t ? '#1E293B' : '#F1F5F9',
        color: srcMode === t ? 'white' : '#64748B',
    });
    return /*#__PURE__*/ React.createElement(
        'div',
        {
            className: 'classes-card',
        },
        /*#__PURE__*/ React.createElement(
            'div',
            {
                className: 'classes-header',
            },
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'classes-header-left',
                },
                /*#__PURE__*/ React.createElement(
                    'span',
                    {
                        className: 'settings-icon',
                    },
                    /*#__PURE__*/ React.createElement(Icon, {
                        emoji: '\uD83D\uDDBC\uFE0F',
                        size: 18,
                    }),
                ),
                /*#__PURE__*/ React.createElement(
                    'h2',
                    {
                        className: 'settings-title',
                    },
                    'Gallery Management',
                ),
            ),
            /*#__PURE__*/ React.createElement(
                'button',
                {
                    className: 'btn-add-class',
                    onClick: openAdd,
                    disabled: busy || uploading || form !== null,
                },
                /*#__PURE__*/ React.createElement(Icon, {
                    emoji: '\uFF0B',
                    size: 18,
                }),
                ' Add Image',
            ),
        ),
        form !== null &&
            /*#__PURE__*/ React.createElement(
                'div',
                {
                    className: 'class-form-box',
                },
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-title',
                    },
                    form.id ? 'Edit Gallery Image' : 'Add New Gallery Image',
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'form-group',
                        style: {
                            marginBottom: 14,
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'label',
                        {
                            className: 'form-label',
                        },
                        'Image Source',
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            style: {
                                display: 'flex',
                                gap: 6,
                                marginBottom: 12,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'button',
                            {
                                style: srcTabStyle('file'),
                                onClick: () => setSrcMode('file'),
                                disabled: busy,
                            },
                            /*#__PURE__*/ React.createElement(Icon, {
                                emoji: '\uD83D\uDCC2',
                                size: 18,
                            }),
                            ' Upload from Device',
                        ),
                        /*#__PURE__*/ React.createElement(
                            'button',
                            {
                                style: srcTabStyle('url'),
                                onClick: () => setSrcMode('url'),
                                disabled: busy,
                            },
                            /*#__PURE__*/ React.createElement(Icon, {
                                emoji: '\uD83D\uDD17',
                                size: 18,
                            }),
                            ' Enter URL',
                        ),
                    ),
                    srcMode === 'file'
                        ? /*#__PURE__*/ React.createElement(
                              'div',
                              {
                                  style: {
                                      background: '#F8FAFC',
                                      border: '2px dashed #CBD5E1',
                                      borderRadius: 8,
                                      padding: 16,
                                  },
                              },
                              /*#__PURE__*/ React.createElement('input', {
                                  type: 'file',
                                  accept: 'image/jpeg,image/png,image/gif,image/webp',
                                  ref: fileRef,
                                  className: 'form-input',
                                  disabled: uploading || busy,
                                  style: {
                                      marginBottom: 8,
                                  },
                              }),
                              /*#__PURE__*/ React.createElement(
                                  'p',
                                  {
                                      style: {
                                          fontSize: 12,
                                          color: '#94A3B8',
                                          marginBottom: 10,
                                      },
                                  },
                                  'JPEG \xB7 PNG \xB7 GIF \xB7 WEBP \u2014 max 5 MB. Saved to ',
                                  /*#__PURE__*/ React.createElement(
                                      'code',
                                      {
                                          style: {
                                              fontSize: 11,
                                          },
                                      },
                                      '/nsms/publicuploads/gallery/',
                                  ),
                              ),
                              /*#__PURE__*/ React.createElement(
                                  'button',
                                  {
                                      className: 'btn-add-class',
                                      onClick: handleFileUpload,
                                      disabled: uploading || busy,
                                      style: {
                                          fontSize: 13,
                                          padding: '7px 18px',
                                      },
                                  },
                                  uploading
                                      ? /*#__PURE__*/ React.createElement(
                                            'span',
                                            {
                                                style: {
                                                    display: 'inline-flex',
                                                    alignItems: 'center',
                                                    gap: 6,
                                                },
                                            },
                                            /*#__PURE__*/ React.createElement(
                                                Icon,
                                                {
                                                    emoji: '\u2B06',
                                                    size: 16,
                                                },
                                            ),
                                            'Uploading\u2026',
                                        )
                                      : /*#__PURE__*/ React.createElement(
                                            'span',
                                            {
                                                style: {
                                                    display: 'inline-flex',
                                                    alignItems: 'center',
                                                    gap: 6,
                                                },
                                            },
                                            /*#__PURE__*/ React.createElement(
                                                Icon,
                                                {
                                                    emoji: '\u2B06',
                                                    size: 16,
                                                },
                                            ),
                                            'Upload Image',
                                        ),
                              ),
                          )
                        : /*#__PURE__*/ React.createElement('input', {
                              className: 'form-input',
                              type: 'url',
                              placeholder: 'https://example.com/photo.jpg',
                              value: form.url,
                              onChange: (e) =>
                                  setForm({
                                      ...form,
                                      url: e.target.value,
                                  }),
                              disabled: busy,
                          }),
                    form.url
                        ? /*#__PURE__*/ React.createElement(
                              'div',
                              {
                                  style: {
                                      display: 'flex',
                                      alignItems: 'center',
                                      gap: 12,
                                      marginTop: 10,
                                      background: '#F0FDF4',
                                      border: '1px solid #86EFAC',
                                      borderRadius: 8,
                                      padding: '8px 12px',
                                  },
                              },
                              /*#__PURE__*/ React.createElement('img', {
                                  src: form.url,
                                  alt: 'Preview',
                                  onError: (e) => {
                                      e.target.style.display = 'none';
                                  },
                                  style: {
                                      width: 64,
                                      height: 64,
                                      objectFit: 'cover',
                                      borderRadius: 6,
                                      border: '1px solid #E2E8F0',
                                      flexShrink: 0,
                                  },
                              }),
                              /*#__PURE__*/ React.createElement(
                                  'div',
                                  null,
                                  /*#__PURE__*/ React.createElement(
                                      'div',
                                      {
                                          style: {
                                              fontSize: 12,
                                              fontWeight: 600,
                                              color: '#166534',
                                              marginBottom: 2,
                                          },
                                      },
                                      /*#__PURE__*/ React.createElement(Icon, {
                                          emoji: '\u2705',
                                          size: 18,
                                      }),
                                      ' Image ready',
                                  ),
                                  /*#__PURE__*/ React.createElement(
                                      'div',
                                      {
                                          style: {
                                              fontSize: 11,
                                              color: '#64748B',
                                              wordBreak: 'break-all',
                                          },
                                      },
                                      form.url,
                                  ),
                              ),
                          )
                        : srcMode === 'file'
                          ? /*#__PURE__*/ React.createElement(
                                'div',
                                {
                                    style: {
                                        marginTop: 8,
                                        fontSize: 12,
                                        color: '#94A3B8',
                                    },
                                },
                                'Select a file and click "Upload Image" \u2014 then fill in the details below and save.',
                            )
                          : null,
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-row',
                        style: {
                            marginBottom: 12,
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Caption',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'text',
                            placeholder: 'e.g. Annual Sports Day 2025',
                            value: form.caption,
                            onChange: (e) =>
                                setForm({
                                    ...form,
                                    caption: e.target.value,
                                }),
                            disabled: busy,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Date',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'date',
                            value: form.date,
                            onChange: (e) =>
                                setForm({
                                    ...form,
                                    date: e.target.value,
                                }),
                            disabled: busy,
                        }),
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-row',
                        style: {
                            marginBottom: 0,
                        },
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                            },
                        },
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                className: 'form-label',
                            },
                            'Sort Order (lower = first)',
                        ),
                        /*#__PURE__*/ React.createElement('input', {
                            className: 'form-input',
                            type: 'number',
                            min: '0',
                            value: form.sort_order,
                            onChange: (e) =>
                                setForm({
                                    ...form,
                                    sort_order: parseInt(e.target.value) || 0,
                                }),
                            disabled: busy,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'form-group',
                            style: {
                                marginBottom: 0,
                                display: 'flex',
                                alignItems: 'center',
                                gap: 10,
                                paddingTop: 24,
                            },
                        },
                        /*#__PURE__*/ React.createElement('input', {
                            type: 'checkbox',
                            id: 'gal-vis',
                            checked: form.is_visible === 1,
                            onChange: (e) =>
                                setForm({
                                    ...form,
                                    is_visible: e.target.checked ? 1 : 0,
                                }),
                            disabled: busy,
                            style: {
                                width: 16,
                                height: 16,
                                cursor: 'pointer',
                            },
                        }),
                        /*#__PURE__*/ React.createElement(
                            'label',
                            {
                                htmlFor: 'gal-vis',
                                style: {
                                    fontSize: 14,
                                    fontWeight: 600,
                                    color: '#334155',
                                    cursor: 'pointer',
                                },
                            },
                            'Visible on public website',
                        ),
                    ),
                ),
                /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'class-form-actions',
                    },
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-save-class',
                            onClick: handleSave,
                            disabled: busy || uploading || !form.url.trim(),
                        },
                        busy
                            ? 'Saving…'
                            : form.id
                              ? 'Update Image'
                              : 'Save Image',
                    ),
                    /*#__PURE__*/ React.createElement(
                        'button',
                        {
                            className: 'btn-cancel-class',
                            onClick: closeForm,
                            disabled: busy || uploading,
                        },
                        'Cancel',
                    ),
                ),
            ),
        loading
            ? /*#__PURE__*/ React.createElement(
                  'div',
                  {
                      className: 'classes-loading',
                  },
                  /*#__PURE__*/ React.createElement('span', {
                      className: 'mini-spinner',
                  }),
                  'Loading gallery\u2026',
              )
            : images.length === 0
              ? /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        className: 'classes-empty',
                    },
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-icon',
                        },
                        /*#__PURE__*/ React.createElement(Icon, {
                            emoji: '\uD83D\uDDBC\uFE0F',
                            size: 18,
                        }),
                    ),
                    /*#__PURE__*/ React.createElement(
                        'div',
                        {
                            className: 'classes-empty-text',
                        },
                        'No gallery images yet. Click "Add Image" to get started.',
                    ),
                )
              : /*#__PURE__*/ React.createElement(
                    'div',
                    {
                        style: {
                            display: 'grid',
                            gridTemplateColumns:
                                'repeat(auto-fill,minmax(220px,1fr))',
                            gap: 14,
                        },
                    },
                    images.map((img) =>
                        confirmDel === img.id
                            ? /*#__PURE__*/ React.createElement(
                                  'div',
                                  {
                                      key: img.id,
                                      style: {
                                          background: '#FEF2F2',
                                          borderRadius: 10,
                                          padding: 14,
                                          border: '1px solid #FCA5A5',
                                      },
                                  },
                                  /*#__PURE__*/ React.createElement(
                                      'p',
                                      {
                                          style: {
                                              fontSize: 13,
                                              fontWeight: 600,
                                              color: '#991B1B',
                                              marginBottom: 10,
                                          },
                                      },
                                      /*#__PURE__*/ React.createElement(Icon, {
                                          emoji: '\u26A0\uFE0F',
                                          size: 18,
                                      }),
                                      ' Delete this image?',
                                  ),
                                  /*#__PURE__*/ React.createElement(
                                      'div',
                                      {
                                          style: {
                                              display: 'flex',
                                              gap: 8,
                                          },
                                      },
                                      /*#__PURE__*/ React.createElement(
                                          'button',
                                          {
                                              className: 'btn-confirm-delete',
                                              onClick: () =>
                                                  handleDelete(img.id),
                                              disabled: busy,
                                          },
                                          busy ? 'Deleting…' : 'Yes, Delete',
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'button',
                                          {
                                              className: 'btn-cancel-delete',
                                              onClick: () =>
                                                  setConfirmDel(null),
                                          },
                                          'Cancel',
                                      ),
                                  ),
                              )
                            : /*#__PURE__*/ React.createElement(
                                  'div',
                                  {
                                      key: img.id,
                                      style: {
                                          background: 'white',
                                          border: '1px solid #E2E8F0',
                                          borderRadius: 10,
                                          overflow: 'hidden',
                                          boxShadow:
                                              '0 1px 3px rgba(0,0,0,.06)',
                                      },
                                  },
                                  /*#__PURE__*/ React.createElement(
                                      'div',
                                      {
                                          style: {
                                              height: 120,
                                              background: '#F8FAFC',
                                              overflow: 'hidden',
                                          },
                                      },
                                      /*#__PURE__*/ React.createElement('img', {
                                          src: img.url,
                                          alt: img.caption,
                                          onError: (e) => {
                                              e.target.style.display = 'none';
                                          },
                                          style: {
                                              width: '100%',
                                              height: '100%',
                                              objectFit: 'cover',
                                              display: 'block',
                                          },
                                      }),
                                  ),
                                  /*#__PURE__*/ React.createElement(
                                      'div',
                                      {
                                          style: {
                                              padding: '10px 12px',
                                          },
                                      },
                                      /*#__PURE__*/ React.createElement(
                                          'div',
                                          {
                                              style: {
                                                  fontSize: 13,
                                                  fontWeight: 600,
                                                  color: '#1E293B',
                                                  marginBottom: 2,
                                                  overflow: 'hidden',
                                                  textOverflow: 'ellipsis',
                                                  whiteSpace: 'nowrap',
                                              },
                                          },
                                          img.caption || '(No caption)',
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'div',
                                          {
                                              style: {
                                                  fontSize: 11,
                                                  color: '#94A3B8',
                                                  marginBottom: 10,
                                              },
                                          },
                                          img.date,
                                          img.is_visible ? '' : ' · Hidden',
                                      ),
                                      /*#__PURE__*/ React.createElement(
                                          'div',
                                          {
                                              style: {
                                                  display: 'flex',
                                                  gap: 6,
                                              },
                                          },
                                          /*#__PURE__*/ React.createElement(
                                              'button',
                                              {
                                                  className: 'btn-edit-class',
                                                  style: {
                                                      flex: 1,
                                                  },
                                                  onClick: () => openEdit(img),
                                                  disabled:
                                                      busy || form !== null,
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  Icon,
                                                  {
                                                      emoji: '\u270F\uFE0F',
                                                      size: 18,
                                                  },
                                              ),
                                              ' Edit',
                                          ),
                                          /*#__PURE__*/ React.createElement(
                                              'button',
                                              {
                                                  className: 'btn-delete-class',
                                                  onClick: () =>
                                                      setConfirmDel(img.id),
                                                  disabled:
                                                      busy || form !== null,
                                              },
                                              /*#__PURE__*/ React.createElement(
                                                  Icon,
                                                  {
                                                      emoji: '\uD83D\uDDD1',
                                                      size: 18,
                                                  },
                                              ),
                                              ' Delete',
                                          ),
                                      ),
                                  ),
                              ),
                    ),
                ),
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/ React.createElement(SettingsPage, null));
