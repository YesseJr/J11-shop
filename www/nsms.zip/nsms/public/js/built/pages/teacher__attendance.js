/* ══════════════════════════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════════════════════════ */
var AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2', '#DB2777'];
function avColor(n) {
  return n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
}
function initials(n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
}
function todayStr() {
  var d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function formatDisplayDate(s) {
  if (!s) return '';
  return new Date(s + 'T00:00:00').toLocaleDateString('en-GB', {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
}
function formatTime(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  return d.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit'
  });
}
function isWeekend(ds) {
  var d = new Date(ds + 'T00:00:00').getDay();
  return d === 0 || d === 6;
}

/* ══════════════════════════════════════════════════════════════════════════
   CARD AVATAR (marking tab)
══════════════════════════════════════════════════════════════════════════ */
function CardAvatar(props) {
  var s = props.student;
  var size = props.size || 48;
  var fs = props.fs || 17;
  return /*#__PURE__*/React.createElement("div", {
    className: "card-avatar",
    style: {
      width: size,
      height: size,
      background: avColor(s.student_name),
      fontSize: fs
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, initials(s.student_name)), s.photo_url && /*#__PURE__*/React.createElement("img", {
    src: s.photo_url,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      borderRadius: '50%',
      zIndex: 2
    },
    onError: function (e) {
      e.currentTarget.style.display = 'none';
    }
  }));
}

/* ══════════════════════════════════════════════════════════════════════════
   MINI AVATAR (history tab)
══════════════════════════════════════════════════════════════════════════ */
function MiniAv(props) {
  var s = props.s;
  return /*#__PURE__*/React.createElement("div", {
    className: "mini-av",
    style: {
      background: avColor(s.student_name)
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, initials(s.student_name)), s.photo_url && /*#__PURE__*/React.createElement("img", {
    src: s.photo_url,
    alt: "",
    onError: function (e) {
      e.currentTarget.style.display = 'none';
    }
  }));
}

/* ══════════════════════════════════════════════════════════════════════════
   DATE PICKER BADGE  (shared — used in both tabs)
   Props:
     date         – YYYY-MM-DD string currently selected
     onSelect     – fn(dateStr | null, reason | null)
     blockedDates – string[] of blocked YYYY-MM-DD dates
     disabled     – when true, badge is display-only (no picker opens)
══════════════════════════════════════════════════════════════════════════ */
function DatePickerBadge(props) {
  var date = props.date;
  var onSelect = props.onSelect;
  var blockedDates = props.blockedDates || [];
  var disabled = props.disabled || false;
  var isToday = date === todayStr();
  var inputRef = React.useRef(null);

  /* Open native date picker programmatically — reliable across browsers */
  function openPicker() {
    if (disabled || !inputRef.current) return;
    try {
      inputRef.current.showPicker(); /* Chrome / Firefox modern */
    } catch (e) {
      inputRef.current.click(); /* Safari / older fallback */
    }
  }
  function handleChange(e) {
    var nd = e.target.value;
    if (!nd) return;
    if (nd > todayStr()) {
      onSelect(null, 'future');
      return;
    }
    if (isWeekend(nd)) {
      onSelect(null, 'weekend');
      return;
    }
    if (blockedDates.indexOf(nd) !== -1) {
      onSelect(null, 'holiday');
      return;
    }
    onSelect(nd, null);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "date-picker-wrapper",
    title: disabled ? '' : 'Click to change date'
  }, /*#__PURE__*/React.createElement("div", {
    className: "date-badge",
    onClick: openPicker,
    style: disabled ? {
      opacity: 0.65,
      cursor: 'default'
    } : {}
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, formatDisplayDate(date)), isToday ? /*#__PURE__*/React.createElement("span", {
    className: "db-tag-today"
  }, "Today") : /*#__PURE__*/React.createElement("span", {
    className: "db-tag-past"
  }, "Past"), !disabled && /*#__PURE__*/React.createElement("span", {
    className: "db-arrow"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u25BE",
    size: 18
  }))), !disabled && /*#__PURE__*/React.createElement("input", {
    ref: inputRef,
    type: "date",
    className: "date-input-hidden",
    value: date,
    max: todayStr(),
    onChange: handleChange
  }));
}

/* ══════════════════════════════════════════════════════════════════════════
   STUDENT CARD (marking tab)
══════════════════════════════════════════════════════════════════════════ */
function StudentCard(props) {
  var student = props.student;
  var status = props.status;
  var lateMin = props.lateMin;
  var onChange = props.onChange;
  var onLateMin = props.onLateMin;
  var isSig = status === 'late' && lateMin !== null && lateMin !== undefined && lateMin >= 30;
  function mark(val) {
    onChange(student.id, status === val ? null : val);
  }
  function handleLateInput(e) {
    var raw = e.target.value;
    if (raw === '' || raw === null) {
      onLateMin(student.id, null);
      return;
    }
    var n = parseInt(raw, 10);
    if (!isNaN(n) && n >= 0 && n <= 180) onLateMin(student.id, n);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: 'student-card' + (status ? ' status-' + status : '') + (isSig ? ' late-significant' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-top"
  }, /*#__PURE__*/React.createElement(CardAvatar, {
    student: student
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "card-name"
  }, student.student_name), /*#__PURE__*/React.createElement("div", {
    className: "card-class"
  }, student.class_name || 'Class'))), /*#__PURE__*/React.createElement("div", {
    className: "status-btns"
  }, /*#__PURE__*/React.createElement("button", {
    className: 'status-btn sbtn-present' + (status === 'present' ? ' active' : ''),
    onClick: function () {
      mark('present');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " Present"), /*#__PURE__*/React.createElement("button", {
    className: 'status-btn sbtn-absent' + (status === 'absent' ? ' active' : ''),
    onClick: function () {
      mark('absent');
    }
  }, "\u2717 Absent"), /*#__PURE__*/React.createElement("button", {
    className: 'status-btn sbtn-late' + (status === 'late' ? ' active' : ''),
    onClick: function () {
      mark('late');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  }), " Late")), status === 'late' && /*#__PURE__*/React.createElement("div", {
    className: "late-min-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "late-min-label"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F1",
    size: 18
  }), " Mins late:"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    min: "1",
    max: "180",
    className: "late-min-input",
    value: lateMin !== null && lateMin !== undefined ? lateMin : '',
    onChange: handleLateInput,
    placeholder: "\u2014"
  }), /*#__PURE__*/React.createElement("span", {
    className: "late-min-unit"
  }, "min"), isSig && /*#__PURE__*/React.createElement("span", {
    className: "late-warn-chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0",
    size: 18
  }), " Significant")));
}

/* ══════════════════════════════════════════════════════════════════════════
   SHIMMER GRID (marking tab loading)
══════════════════════════════════════════════════════════════════════════ */
function ShimmerGrid() {
  return /*#__PURE__*/React.createElement("div", {
    className: "cards-grid"
  }, [1, 2, 3, 4, 5, 6].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "shimmer-card"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 48,
        height: 48,
        borderRadius: '50%'
      },
      className: "shimmer"
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        height: 14,
        width: 110,
        borderRadius: 6,
        marginBottom: 5
      },
      className: "shimmer"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 11,
        width: 70,
        borderRadius: 6
      },
      className: "shimmer"
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 6
      }
    }, [1, 2, 3].map(function (j) {
      return /*#__PURE__*/React.createElement("div", {
        key: j,
        style: {
          flex: 1,
          height: 32,
          borderRadius: 8
        },
        className: "shimmer"
      });
    })));
  }));
}

/* ══════════════════════════════════════════════════════════════════════════
   HISTORY GROUP CARD
   Renders one status column (present / absent / late) in the history tab.
══════════════════════════════════════════════════════════════════════════ */
function HistGroup(props) {
  var type = props.type; /* 'present' | 'absent' | 'late' */
  var entries = props.entries;
  var cfg = {
    present: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u2705",
        size: 20
      }),
      title: 'Present',
      cls: 'hg-present'
    },
    absent: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u274C",
        size: 20
      }),
      title: 'Absent',
      cls: 'hg-absent'
    },
    late: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u23F0",
        size: 20
      }),
      title: 'Late',
      cls: 'hg-late'
    }
  }[type];
  return /*#__PURE__*/React.createElement("div", {
    className: 'hist-group ' + cfg.cls
  }, /*#__PURE__*/React.createElement("div", {
    className: "hg-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hg-icon"
  }, cfg.icon), /*#__PURE__*/React.createElement("span", {
    className: "hg-title"
  }, cfg.title), /*#__PURE__*/React.createElement("span", {
    className: "hg-count"
  }, entries.length)), /*#__PURE__*/React.createElement("div", {
    className: "hg-body"
  }, entries.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "hg-empty"
  }, "\u2014") : entries.map(function (e) {
    var lm = e.late_minutes;
    var chipCls = lm === null ? 'late-chip late-chip-none' : lm >= 30 ? 'late-chip late-chip-sig' : 'late-chip late-chip-normal';
    var chipTxt = lm === null ? 'Time not recorded' : lm + ' min late';
    return /*#__PURE__*/React.createElement("div", {
      key: e.student_id,
      className: "hg-row"
    }, /*#__PURE__*/React.createElement(MiniAv, {
      s: e
    }), /*#__PURE__*/React.createElement("span", {
      className: "hg-name"
    }, e.student_name), type === 'late' && /*#__PURE__*/React.createElement("span", {
      className: chipCls
    }, chipTxt));
  })));
}

/* ══════════════════════════════════════════════════════════════════════════
   HISTORY SHIMMER (history tab loading)
══════════════════════════════════════════════════════════════════════════ */
function HistShimmer() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginBottom: 24
    }
  }, [1, 2, 3, 4].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        flex: 1,
        height: 56,
        borderRadius: 10
      },
      className: "shimmer"
    });
  })), /*#__PURE__*/React.createElement("div", {
    className: "hist-groups"
  }, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        background: 'white',
        borderRadius: 14,
        boxShadow: 'var(--sh-sm)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '14px 16px',
        borderBottom: '1px solid var(--border)',
        display: 'flex',
        gap: 8,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 20,
        height: 20,
        borderRadius: 4
      },
      className: "shimmer"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 60,
        height: 13
      },
      className: "sh shimmer"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        marginLeft: 'auto',
        width: 24,
        height: 18,
        borderRadius: 20
      },
      className: "shimmer"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '8px 0'
      }
    }, [1, 2, 3, 4].map(function (j) {
      return /*#__PURE__*/React.createElement("div", {
        key: j,
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          padding: '8px 16px'
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          width: 32,
          height: 32,
          borderRadius: '50%'
        },
        className: "shimmer"
      }), /*#__PURE__*/React.createElement("div", {
        style: {
          flex: 1,
          height: 12
        },
        className: "sh shimmer"
      }));
    })));
  })));
}

/* ══════════════════════════════════════════════════════════════════════════
   HISTORY CONTENT
   Rendered only when histData.has_records is true. Receives the full
   histData object and the currently selected histDate string.
══════════════════════════════════════════════════════════════════════════ */
function HistoryContent(props) {
  var d = props.histData;
  var histDate = props.histDate;

  /* ── counts ── */
  var pCount = d.present.length;
  var aCount = d.absent.length;
  var lCount = d.late.length;
  var total = d.total;
  var attended = pCount + lCount;

  /* ── rates ── */
  var attRate = d.att_rate; /* already computed server-side */
  var puncRate = attended > 0 ? (pCount / attended * 100).toFixed(1) : null;
  var absRate = total > 0 ? (aCount / total * 100).toFixed(1) : '0.0';
  var lateRate = total > 0 ? (lCount / total * 100).toFixed(1) : '0.0';

  /* ── late-time analysis ── */
  var lateWithTimes = d.late.filter(function (e) {
    return e.late_minutes !== null;
  });
  var avgLate = lateWithTimes.length > 0 ? Math.round(lateWithTimes.reduce(function (s, e) {
    return s + e.late_minutes;
  }, 0) / lateWithTimes.length) : null;
  var maxLate = lateWithTimes.length > 0 ? Math.max.apply(null, lateWithTimes.map(function (e) {
    return e.late_minutes;
  })) : null;
  var sigLate = d.late.filter(function (e) {
    return e.late_minutes !== null && e.late_minutes >= 30;
  }).length;
  var hasInsights = lCount > 0;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "hist-metrics"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hm-card hm-att"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hm-label"
  }, "Attendance Rate"), /*#__PURE__*/React.createElement("div", {
    className: "hm-value"
  }, attRate, "%"), /*#__PURE__*/React.createElement("div", {
    className: "hm-sub"
  }, attended, " of ", total, " student", total !== 1 ? 's' : '', " attended"), /*#__PURE__*/React.createElement("div", {
    className: "hm-bar-track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hm-bar-fill",
    style: {
      width: Math.min(parseFloat(attRate), 100) + '%'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "hm-card hm-punc"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hm-label"
  }, "Punctuality Rate"), /*#__PURE__*/React.createElement("div", {
    className: "hm-value"
  }, puncRate !== null ? puncRate + '%' : '—'), /*#__PURE__*/React.createElement("div", {
    className: "hm-sub"
  }, pCount, " on-time of ", attended, " who attended"), /*#__PURE__*/React.createElement("div", {
    className: "hm-bar-track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hm-bar-fill",
    style: {
      width: (puncRate !== null ? Math.min(parseFloat(puncRate), 100) : 0) + '%'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "hm-card hm-abs"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hm-label"
  }, "Absence Rate"), /*#__PURE__*/React.createElement("div", {
    className: "hm-value"
  }, absRate, "%"), /*#__PURE__*/React.createElement("div", {
    className: "hm-sub"
  }, aCount, " student", aCount !== 1 ? 's' : '', " absent today"), /*#__PURE__*/React.createElement("div", {
    className: "hm-bar-track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hm-bar-fill",
    style: {
      width: Math.min(parseFloat(absRate), 100) + '%'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "hm-card hm-late-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hm-label"
  }, "Late Arrivals"), /*#__PURE__*/React.createElement("div", {
    className: "hm-value"
  }, lateRate, "%"), /*#__PURE__*/React.createElement("div", {
    className: "hm-sub"
  }, lCount, " student", lCount !== 1 ? 's' : '', " arrived late"), /*#__PURE__*/React.createElement("div", {
    className: "hm-bar-track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hm-bar-fill",
    style: {
      width: Math.min(parseFloat(lateRate), 100) + '%'
    }
  })))), hasInsights && /*#__PURE__*/React.createElement("div", {
    className: "hist-late-insight"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hli-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F0",
    size: 18
  }), " Late Arrival Insights"), /*#__PURE__*/React.createElement("div", {
    className: "hli-stats"
  }, avgLate !== null ? /*#__PURE__*/React.createElement("div", {
    className: "hli-stat"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hli-num"
  }, avgLate, " min"), /*#__PURE__*/React.createElement("span", {
    className: "hli-lbl"
  }, "Average late time")) : null, avgLate !== null && maxLate !== null && avgLate !== maxLate && /*#__PURE__*/React.createElement("div", {
    className: "hli-divider"
  }), maxLate !== null && avgLate !== maxLate ? /*#__PURE__*/React.createElement("div", {
    className: "hli-stat"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hli-num"
  }, maxLate, " min"), /*#__PURE__*/React.createElement("span", {
    className: "hli-lbl"
  }, "Latest arrival")) : null, sigLate > 0 && /*#__PURE__*/React.createElement("div", {
    className: "hli-divider"
  }), sigLate > 0 && /*#__PURE__*/React.createElement("div", {
    className: "hli-stat"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hli-num hli-warn"
  }, sigLate), /*#__PURE__*/React.createElement("span", {
    className: "hli-lbl"
  }, "Significant (\u2265 30 min)")), lateWithTimes.length === 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      color: '#92400E',
      fontStyle: 'italic'
    }
  }, "No late times were recorded for this day."))), d.unmarked && d.unmarked.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "hist-unmarked"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hist-unmarked-title"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), d.unmarked.length, " student", d.unmarked.length !== 1 ? 's were' : ' was', " not marked on this day"), /*#__PURE__*/React.createElement("div", {
    className: "hist-unmarked-names"
  }, d.unmarked.map(function (e) {
    return /*#__PURE__*/React.createElement("span", {
      key: e.student_id,
      className: "unmarked-chip"
    }, e.student_name);
  }))), /*#__PURE__*/React.createElement("div", {
    className: "hist-groups"
  }, /*#__PURE__*/React.createElement(HistGroup, {
    type: "present",
    entries: d.present
  }), /*#__PURE__*/React.createElement(HistGroup, {
    type: "absent",
    entries: d.absent
  }), /*#__PURE__*/React.createElement(HistGroup, {
    type: "late",
    entries: d.late
  })), d.marked_at && /*#__PURE__*/React.createElement("div", {
    className: "hist-footer"
  }, "Attendance marked at ", formatTime(d.marked_at), d.marked_by_name ? ' by ' + d.marked_by_name : '', ' · ' + formatDisplayDate(histDate)));
}

/* ══════════════════════════════════════════════════════════════════════════
   HISTORY TAB CONTENT
══════════════════════════════════════════════════════════════════════════ */
function HistoryTab(props) {
  var blockedDates = props.blockedDates || [];
  var classInfo = props.classInfo;
  var useState = React.useState;
  var useEffect = React.useEffect;

  /* histLoad starts true so the shimmer shows immediately on tab switch */
  var dateSt = useState(todayStr());
  var histDate = dateSt[0];
  var setHistDate = dateSt[1];
  var loadSt = useState(true);
  var histLoad = loadSt[0];
  var setHistLoad = loadSt[1];
  var dataSt = useState(null);
  var histData = dataSt[0];
  var setHistData = dataSt[1];

  /*
   * Fetch history whenever histDate changes.
   * No class_id needed in the URL — resolveClassId() on the server
   * falls back to the teacher's session, exactly like the Mark tab does.
   */
  useEffect(function () {
    setHistLoad(true);
    setHistData(null);
    fetch('/nsms/api/teacher-attendance.php?action=get_history&date=' + histDate).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setHistData(d.data);
      } else {
        props.showToast('error', d.error || 'Failed to load history.');
      }
    }).catch(function () {
      props.showToast('error', 'Network error loading history.');
    }).finally(function () {
      setHistLoad(false);
    });
  }, [histDate]);
  function handleDateSelect(nd, reason) {
    if (!nd) {
      if (reason === 'future') props.showToast('error', /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDCC5",
        size: 16
      }), "Cannot view future dates."));
      if (reason === 'weekend') props.showToast('error', /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDCC5",
        size: 16
      }), "Weekends are not school days."));
      if (reason === 'holiday') props.showToast('error', /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83C\uDFEB",
        size: 16
      }), "That date is a holiday or school break."));
      return;
    }
    setHistDate(nd);
  }
  var className = classInfo && classInfo.class_name ? classInfo.class_name : '';
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "hist-toolbar"
  }, /*#__PURE__*/React.createElement(DatePickerBadge, {
    date: histDate,
    onSelect: handleDateSelect,
    blockedDates: blockedDates
  }), className && /*#__PURE__*/React.createElement("span", {
    className: "hist-class-label"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  }), " ", className)), histLoad ? /*#__PURE__*/React.createElement(HistShimmer, null) : !histData ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 36
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "Select a date to view attendance.")) : !histData.has_records ? /*#__PURE__*/React.createElement("div", {
    className: "hist-empty"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hist-empty-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "hist-empty-title"
  }, "No attendance recorded"), /*#__PURE__*/React.createElement("div", {
    className: "hist-empty-sub"
  }, "No attendance was marked for ", /*#__PURE__*/React.createElement("strong", null, formatDisplayDate(histDate)), ".", /*#__PURE__*/React.createElement("br", null), "Switch to the Mark tab to record it.")) : /*#__PURE__*/React.createElement(HistoryContent, {
    histData: histData,
    histDate: histDate
  }));
}

/* ══════════════════════════════════════════════════════════════════════════
   MAIN PAGE
══════════════════════════════════════════════════════════════════════════ */
function AttendancePage() {
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useRef = React.useRef;

  /* Shared state */
  var sbSt = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  var sidebarOpen = sbSt[0];
  var setSidebarOpen = sbSt[1];
  var tabSt = useState('mark');
  var activeTab = tabSt[0];
  var setActiveTab = tabSt[1];
  var classSt = useState(null);
  var classInfo = classSt[0];
  var setClassInfo = classSt[1];
  var bdSt = useState([]);
  var blockedDates = bdSt[0];
  var setBlockedDates = bdSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];

  /* Mark-tab state */
  var studSt = useState([]);
  var students = studSt[0];
  var setStudents = studSt[1];
  var attSt = useState({});
  var attendance = attSt[0];
  var setAttendance = attSt[1];
  var lmSt = useState({});
  var lateMinutes = lmSt[0];
  var setLateMinutes = lmSt[1];
  var loadSt = useState(true);
  var loading = loadSt[0];
  var setLoading = loadSt[1];
  var savingSt = useState(false);
  var saving = savingSt[0];
  var setSaving = savingSt[1];
  var savedSt = useState(false);
  var alreadySaved = savedSt[0];
  var setAlreadySaved = savedSt[1];
  var dateSt = useState(todayStr());
  var date = dateSt[0];
  var setDate = dateSt[1];
  var wasOnTodayRef = useRef(true);

  /* ── Effect 1: boot — fetch holidays, start day-change detector ── */
  useEffect(function () {
    var yr = new Date().getFullYear();
    fetch('/nsms/api/teacher-attendance.php?action=get_holidays&year=' + yr).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success && d.data && d.data.blocked_dates) setBlockedDates(d.data.blocked_dates);
    }).catch(function () {});
    var lastToday = todayStr();
    var iv = setInterval(function () {
      var nt = todayStr();
      if (nt !== lastToday) {
        lastToday = nt;
        if (wasOnTodayRef.current) {
          setDate(nt);
          setToast({
            type: 'info',
            msg: /*#__PURE__*/React.createElement("span", {
              style: {
                display: "inline-flex",
                alignItems: "center",
                gap: 6
              }
            }, /*#__PURE__*/React.createElement(Icon, {
              emoji: "\uD83C\uDF05",
              size: 16
            }), " New school day! Ready for today\u2019s attendance.")
          });
        }
      }
    }, 30000);
    return function () {
      clearInterval(iv);
    };
  }, []);

  /* ── Effect 2: load attendance for mark tab whenever date changes ── */
  useEffect(function () {
    wasOnTodayRef.current = date === todayStr();
    setLoading(true);
    setAttendance({});
    setLateMinutes({});
    setAlreadySaved(false);
    setStudents([]);
    fetch('/nsms/api/teacher-profile.php?action=get').then(function (r) {
      return r.json();
    }).then(function (d) {
      var cid = d.success && d.data && d.data.class_id ? d.data.class_id : null;
      var url = '/nsms/api/teacher-attendance.php?action=get_today&date=' + date;
      if (cid) url += '&class_id=' + cid;
      return fetch(url);
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        var studs = d.data.students || [];
        setStudents(studs);
        var am = {};
        var lm = {};
        studs.forEach(function (s) {
          if (s.attendance_status) am[s.id] = s.attendance_status;
          if (s.late_minutes !== null && s.late_minutes !== undefined) lm[s.id] = s.late_minutes;
        });
        setAttendance(am);
        setLateMinutes(lm);
        setAlreadySaved(d.data.already_saved || false);
        if (d.data.class_name) setClassInfo({
          class_name: d.data.class_name
        });
      } else {
        showToast('error', d.error || 'Failed to load attendance data.');
      }
    }).catch(function () {
      showToast('error', 'Network error loading attendance.');
    }).finally(function () {
      setLoading(false);
    });
  }, [date]);

  /* Toast auto-dismiss */
  useEffect(function () {
    if (!toast) return;
    var t = setTimeout(function () {
      setToast(null);
    }, 4000);
    return function () {
      clearTimeout(t);
    };
  }, [toast]);
  function showToast(type, msg) {
    setToast({
      type: type,
      msg: msg
    });
  }
  function handleDateSelect(nd, reason) {
    if (!nd) {
      if (reason === 'future') showToast('error', /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDCC5",
        size: 16
      }), "Cannot record attendance for future dates."));
      if (reason === 'weekend') showToast('error', /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDCC5",
        size: 16
      }), "Weekends are not school days."));
      if (reason === 'holiday') showToast('error', /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83C\uDFEB",
        size: 16
      }), "This date is a holiday or school break."));
      return;
    }
    setDate(nd);
  }
  function handleMark(sid, status) {
    setAttendance(function (prev) {
      var next = Object.assign({}, prev);
      if (status === null) delete next[sid];else next[sid] = status;
      return next;
    });
    if (status !== 'late') {
      setLateMinutes(function (prev) {
        var next = Object.assign({}, prev);
        delete next[sid];
        return next;
      });
    }
  }
  function handleLateMin(sid, minutes) {
    setLateMinutes(function (prev) {
      var next = Object.assign({}, prev);
      if (minutes === null || minutes === undefined || minutes === '') delete next[sid];else next[sid] = minutes;
      return next;
    });
  }
  function markAllPresent() {
    var map = {};
    students.forEach(function (s) {
      map[s.id] = 'present';
    });
    setAttendance(map);
    setLateMinutes({});
  }
  function saveAttendance() {
    var unmarked = students.filter(function (s) {
      return !attendance[s.id];
    });
    if (unmarked.length > 0) {
      showToast('error', unmarked.length + ' student(s) not yet marked.');
      return;
    }
    var records = students.map(function (s) {
      var rec = {
        student_id: s.id,
        status: attendance[s.id]
      };
      if (attendance[s.id] === 'late') {
        var lm = lateMinutes[s.id];
        rec.late_minutes = lm !== undefined && lm !== null && lm !== '' ? lm : null;
      }
      return rec;
    });
    setSaving(true);
    fetch('/nsms/api/teacher-attendance.php?action=save', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        date: date,
        records: records
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setAlreadySaved(true);
        showToast('success', 'Attendance saved for ' + d.data.saved + ' students.');
      } else {
        showToast('error', d.error || 'Failed to save attendance.');
      }
    }).catch(function () {
      showToast('error', 'Network error. Please try again.');
    }).finally(function () {
      setSaving(false);
    });
  }

  /* Derived */
  var presentCount = students.filter(function (s) {
    return attendance[s.id] === 'present';
  }).length;
  var absentCount = students.filter(function (s) {
    return attendance[s.id] === 'absent';
  }).length;
  var lateCount = students.filter(function (s) {
    return attendance[s.id] === 'late';
  }).length;
  var totalCount = students.length;
  var attendedCount = presentCount + lateCount;
  var attRate = totalCount > 0 ? (attendedCount / totalCount * 100).toFixed(1) : '0.0';
  function pct(n) {
    return totalCount > 0 ? (n / totalCount * 100).toFixed(1) + '%' : '0%';
  }
  var className = classInfo && classInfo.class_name ? classInfo.class_name : students[0] && students[0].class_name ? students[0].class_name : 'My Class';
  var allMarked = totalCount > 0 && students.every(function (s) {
    return !!attendance[s.id];
  });
  var isToday = date === todayStr();
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TeacherNavbar, {
    activePage: "attendance",
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(TeacherSidebar, {
    activePage: "attendance",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (sidebarOpen ? '' : ' collapsed')
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "page-title"
  }, "Attendance"), /*#__PURE__*/React.createElement("div", {
    className: "header-right"
  }, !loading && className && /*#__PURE__*/React.createElement("div", {
    className: "class-pill"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  }), " ", className))), /*#__PURE__*/React.createElement("div", {
    className: "tab-bar"
  }, /*#__PURE__*/React.createElement("button", {
    className: 'tab-btn' + (activeTab === 'mark' ? ' active' : ''),
    onClick: function () {
      setActiveTab('mark');
    }
  }, "\u270F\uFE0F Mark Attendance", !loading && totalCount > 0 && /*#__PURE__*/React.createElement("span", {
    className: "tab-badge"
  }, totalCount)), /*#__PURE__*/React.createElement("button", {
    className: 'tab-btn' + (activeTab === 'history' ? ' active' : ''),
    onClick: function () {
      setActiveTab('history');
    }
  }, "\uD83D\uDCC5 Attendance History")), activeTab === 'mark' && /*#__PURE__*/React.createElement("div", null, alreadySaved && !loading && /*#__PURE__*/React.createElement("div", {
    className: "banner banner-saved"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), isToday ? 'Attendance for today has already been recorded. Changes will update the existing record.' : 'Attendance for ' + formatDisplayDate(date) + ' has been recorded. Save again to update.'), !alreadySaved && !loading && !isToday && totalCount > 0 && /*#__PURE__*/React.createElement("div", {
    className: "banner banner-past"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), "No attendance has been recorded yet for ", formatDisplayDate(date), "."), !loading && /*#__PURE__*/React.createElement("div", {
    className: "sub-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sub-left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sub-title"
  }, className), /*#__PURE__*/React.createElement(DatePickerBadge, {
    date: date,
    onSelect: handleDateSelect,
    blockedDates: blockedDates
  }), totalCount > 0 && /*#__PURE__*/React.createElement("span", {
    className: "sub-count"
  }, "\u2014 ", totalCount, " Students")), /*#__PURE__*/React.createElement("div", {
    className: "sub-actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-mark-all",
    onClick: markAllPresent,
    disabled: saving || totalCount === 0
  }, "\u2713 Mark All Present"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-save",
    onClick: saveAttendance,
    disabled: saving || totalCount === 0
  }, saving ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: 14,
      height: 14,
      border: '2px solid rgba(255,255,255,.4)',
      borderTopColor: 'white',
      borderRadius: '50%',
      animation: 'spin .6s linear infinite'
    }
  }), " Saving\u2026") : alreadySaved ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCBE",
    size: 16
  }), "Update Attendance") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCBE",
    size: 16
  }), "Save Attendance")))), loading ? /*#__PURE__*/React.createElement(ShimmerGrid, null) : students.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 48
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "No students found in your class.")) : /*#__PURE__*/React.createElement("div", {
    className: "cards-grid"
  }, students.map(function (s) {
    return /*#__PURE__*/React.createElement(StudentCard, {
      key: s.id,
      student: s,
      status: attendance[s.id] || null,
      lateMin: lateMinutes[s.id] !== undefined ? lateMinutes[s.id] : null,
      onChange: handleMark,
      onLateMin: handleLateMin
    });
  })), !loading && totalCount > 0 && !allMarked && /*#__PURE__*/React.createElement("div", {
    className: "progress-notice"
  }, totalCount - presentCount - absentCount - lateCount, " student(s) not yet marked"), !loading && totalCount > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "summary-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "summary-card sc-present"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-label"
  }, "Present"), /*#__PURE__*/React.createElement("div", {
    className: "sc-number"
  }, presentCount), /*#__PURE__*/React.createElement("div", {
    className: "sc-sub"
  }, pct(presentCount))), /*#__PURE__*/React.createElement("div", {
    className: "summary-card sc-absent"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-label"
  }, "Absent"), /*#__PURE__*/React.createElement("div", {
    className: "sc-number"
  }, absentCount), /*#__PURE__*/React.createElement("div", {
    className: "sc-sub"
  }, pct(absentCount))), /*#__PURE__*/React.createElement("div", {
    className: "summary-card sc-late"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-label"
  }, "Late"), /*#__PURE__*/React.createElement("div", {
    className: "sc-number"
  }, lateCount), /*#__PURE__*/React.createElement("div", {
    className: "sc-sub"
  }, pct(lateCount)), /*#__PURE__*/React.createElement("div", {
    className: "sc-note"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2605",
    size: 18
  }), " Counted as present"))), /*#__PURE__*/React.createElement("div", {
    className: "att-rate-bar"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "att-rate-label"
  }, "Attendance Rate"), /*#__PURE__*/React.createElement("span", {
    className: "att-rate-note"
  }, "Present + Late \xF7 Total \xB7 Late arrivals count as attended"), /*#__PURE__*/React.createElement("span", {
    className: "att-rate-value"
  }, attRate, "%")))), activeTab === 'history' && /*#__PURE__*/React.createElement(HistoryTab, {
    blockedDates: blockedDates,
    classInfo: classInfo,
    showToast: showToast,
    toastState: toastSt
  })))), toast && /*#__PURE__*/React.createElement("div", {
    className: 'toast toast-' + toast.type
  }, toast.msg));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(AttendancePage, null));