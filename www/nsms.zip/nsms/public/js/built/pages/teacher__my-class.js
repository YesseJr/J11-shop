/* ══════════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════════ */
var AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2', '#DB2777'];
function avColor(n) {
  return n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
}
function initials(n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
}
function getPerf(rate) {
  if (rate === null || rate === undefined) return {
    label: '—',
    color: '#94A3B8'
  };
  if (rate >= 90) return {
    label: 'Excellent',
    color: '#059669'
  };
  if (rate >= 80) return {
    label: 'Very Good',
    color: '#0891B2'
  };
  if (rate >= 70) return {
    label: 'Good',
    color: '#D97706'
  };
  if (rate >= 60) return {
    label: 'Fair',
    color: '#F59E0B'
  };
  return {
    label: 'Needs Attention',
    color: '#EF4444'
  };
}
function attColor(rate) {
  if (rate === null || rate === undefined) return null;
  if (rate >= 90) return 'att-high';
  if (rate >= 70) return 'att-mid';
  return 'att-low';
}
function formatDate(d) {
  if (!d) return '—';
  var dt = new Date(d);
  return dt.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}
function calcAge(dob) {
  if (!dob) return null;
  var today = new Date();
  var birth = new Date(dob);
  var age = today.getFullYear() - birth.getFullYear();
  if (today.getMonth() < birth.getMonth() || today.getMonth() === birth.getMonth() && today.getDate() < birth.getDate()) age--;
  return age;
}

/* ── Avatar component ── */
function SAvatar(props) {
  var student = props.student;
  var size = props.size || 38;
  var fs = props.fs || 13;
  return /*#__PURE__*/React.createElement("div", {
    className: "s-avatar",
    style: {
      width: size,
      height: size,
      background: avColor(student.student_name),
      fontSize: fs
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, initials(student.student_name)), student.photo_url && /*#__PURE__*/React.createElement("img", {
    src: student.photo_url,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      borderRadius: '50%',
      zIndex: 2
    },
    onError: function (e) {
      e.currentTarget.style.display = 'none';
    }
  }));
}

/* ══════════════════════════════════════════════════════════
   VIEW MODAL  — basic info only, NO fee data
══════════════════════════════════════════════════════════ */
function ViewModal(props) {
  var studentId = props.studentId;
  var onClose = props.onClose;
  var useState = React.useState;
  var useEffect = React.useEffect;
  var dataSt = useState(null);
  var data = dataSt[0];
  var setData = dataSt[1];
  var loadSt = useState(true);
  var loading = loadSt[0];
  var setLoading = loadSt[1];
  var errSt = useState(null);
  var err = errSt[0];
  var setErr = errSt[1];
  useEffect(function () {
    if (!studentId) return;
    setLoading(true);
    setErr(null);
    setData(null);
    fetch('/nsms/api/teacher-students.php?action=get&id=' + studentId).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setData(d.data);else setErr(d.error || 'Failed to load student details.');
    }).catch(function () {
      setErr('Network error. Please try again.');
    }).finally(function () {
      setLoading(false);
    });
  }, [studentId]);

  /* Close on overlay click */
  function onOverlayClick(e) {
    if (e.target === e.currentTarget) onClose();
  }
  var att = data && data.attendance ? data.attendance : null;
  var perf = getPerf(att ? att.rate : null);
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: onOverlayClick
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    role: "dialog",
    "aria-modal": "true"
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "modal-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC64",
    size: 18
  }), " Student Profile"), /*#__PURE__*/React.createElement("button", {
    className: "modal-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "modal-body"
  }, loading && /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      padding: '40px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading student details\u2026")), !loading && err && /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      padding: '40px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 36
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      color: '#EF4444'
    }
  }, err)), !loading && data && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "modal-hero"
  }, /*#__PURE__*/React.createElement(SAvatar, {
    student: data,
    size: 76,
    fs: 26
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "hero-name"
  }, data.student_name), /*#__PURE__*/React.createElement("span", {
    className: "hero-class",
    style: {
      background: data.class_color || '#2563EB'
    }
  }, data.class_name), att && att.rate !== null && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6,
      fontSize: 12.5,
      fontWeight: 600
    },
    className: 'att-val ' + attColor(att.rate)
  }, att.rate, "% Attendance \xA0", /*#__PURE__*/React.createElement("span", {
    style: {
      color: perf.color
    }
  }, "\xB7 ", perf.label)))), /*#__PURE__*/React.createElement("div", {
    className: "info-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF92",
    size: 18
  }), " Student Information"), /*#__PURE__*/React.createElement("div", {
    className: "info-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "info-label"
  }, "Date of Birth"), /*#__PURE__*/React.createElement("span", {
    className: "info-value"
  }, formatDate(data.date_of_birth), calcAge(data.date_of_birth) !== null && /*#__PURE__*/React.createElement("small", {
    style: {
      color: '#64748B',
      fontWeight: 500
    }
  }, " (", calcAge(data.date_of_birth), " yrs)"))), /*#__PURE__*/React.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "info-label"
  }, "Gender"), /*#__PURE__*/React.createElement("span", {
    className: "info-value"
  }, data.gender || /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "\u2014"))), /*#__PURE__*/React.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "info-label"
  }, "Enrollment Date"), /*#__PURE__*/React.createElement("span", {
    className: "info-value"
  }, formatDate(data.enrollment_date))), /*#__PURE__*/React.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "info-label"
  }, "Status"), /*#__PURE__*/React.createElement("span", {
    className: "info-value"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'status-badge ' + (data.status === 'active' ? 'sb-active' : 'sb-inactive')
  }, data.status === 'active' ? 'Active' : data.status))), data.address && /*#__PURE__*/React.createElement("div", {
    className: "info-item",
    style: {
      gridColumn: '1/-1'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "info-label"
  }, "Address"), /*#__PURE__*/React.createElement("span", {
    className: "info-value"
  }, data.address)))), /*#__PURE__*/React.createElement("div", {
    className: "info-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67",
    size: 18
  }), " Parent / Guardian"), data.parent_name ? /*#__PURE__*/React.createElement("div", {
    className: "info-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "info-label"
  }, "Name"), /*#__PURE__*/React.createElement("span", {
    className: "info-value"
  }, data.parent_name)), /*#__PURE__*/React.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "info-label"
  }, "Relationship"), /*#__PURE__*/React.createElement("span", {
    className: "info-value"
  }, data.parent_relationship || '—')), /*#__PURE__*/React.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "info-label"
  }, "Phone"), /*#__PURE__*/React.createElement("span", {
    className: "info-value"
  }, data.parent_phone ? /*#__PURE__*/React.createElement("a", {
    href: 'tel:' + data.parent_phone,
    style: {
      color: 'var(--blue)',
      textDecoration: 'none'
    }
  }, data.parent_phone) : /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "\u2014"))), /*#__PURE__*/React.createElement("div", {
    className: "info-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "info-label"
  }, "Email"), /*#__PURE__*/React.createElement("span", {
    className: "info-value"
  }, data.parent_email ? /*#__PURE__*/React.createElement("a", {
    href: 'mailto:' + data.parent_email,
    style: {
      color: 'var(--blue)',
      textDecoration: 'none',
      fontSize: 12.5
    }
  }, data.parent_email) : /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "\u2014")))) : /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13.5,
      color: 'var(--text-soft)',
      fontStyle: 'italic'
    }
  }, "No parent / guardian information on record.")), /*#__PURE__*/React.createElement("div", {
    className: "info-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  }), " Attendance \u2014 This Year"), att && att.total > 0 ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "att-stats"
  }, /*#__PURE__*/React.createElement("div", {
    className: "att-stat as-total"
  }, /*#__PURE__*/React.createElement("div", {
    className: "att-stat-val"
  }, att.total), /*#__PURE__*/React.createElement("div", {
    className: "att-stat-lbl"
  }, "Days")), /*#__PURE__*/React.createElement("div", {
    className: "att-stat as-present"
  }, /*#__PURE__*/React.createElement("div", {
    className: "att-stat-val"
  }, att.present_days), /*#__PURE__*/React.createElement("div", {
    className: "att-stat-lbl"
  }, "Present")), /*#__PURE__*/React.createElement("div", {
    className: "att-stat as-absent"
  }, /*#__PURE__*/React.createElement("div", {
    className: "att-stat-val"
  }, att.absent_days), /*#__PURE__*/React.createElement("div", {
    className: "att-stat-lbl"
  }, "Absent")), /*#__PURE__*/React.createElement("div", {
    className: "att-stat as-late"
  }, /*#__PURE__*/React.createElement("div", {
    className: "att-stat-val"
  }, att.late_days), /*#__PURE__*/React.createElement("div", {
    className: "att-stat-lbl"
  }, "Late"))), att.rate !== null && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "rate-label"
  }, /*#__PURE__*/React.createElement("span", {
    className: "rate-label-text"
  }, "Attendance Rate"), /*#__PURE__*/React.createElement("span", {
    className: "rate-label-value",
    style: {
      color: perf.color
    }
  }, att.rate, "%")), /*#__PURE__*/React.createElement("div", {
    className: "rate-bar-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rate-bar-fill",
    style: {
      width: att.rate + '%',
      background: att.rate >= 90 ? '#059669' : att.rate >= 70 ? '#D97706' : '#EF4444'
    }
  })))) : /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13.5,
      color: 'var(--text-soft)',
      fontStyle: 'italic'
    }
  }, "No attendance records yet for this year.")))), /*#__PURE__*/React.createElement("div", {
    className: "modal-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "view-btn",
    onClick: onClose,
    style: {
      background: '#F1F5F9',
      color: 'var(--text-dark)',
      padding: '8px 22px'
    }
  }, "Close"))));
}

/* ══════════════════════════════════════════════════════════
   SHIMMER ROWS
══════════════════════════════════════════════════════════ */
function ShimmerRows() {
  return /*#__PURE__*/React.createElement(React.Fragment, null, [1, 2, 3, 4, 5, 6].map(function (i) {
    return /*#__PURE__*/React.createElement("tr", {
      key: i
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "student-cell"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sh-circle shimmer"
    }), /*#__PURE__*/React.createElement("div", {
      className: "sh-block shimmer",
      style: {
        width: 120
      }
    }))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "sh-block shimmer",
      style: {
        width: 90
      }
    })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "sh-block shimmer",
      style: {
        width: 110
      }
    })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "sh-block shimmer",
      style: {
        width: 42
      }
    })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "sh-block shimmer",
      style: {
        width: 70
      }
    })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "sh-block shimmer",
      style: {
        width: 50
      }
    })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "sh-block shimmer",
      style: {
        width: 56,
        height: 28,
        borderRadius: 7
      }
    })));
  }));
}

/* ══════════════════════════════════════════════════════════
   MAIN PAGE
══════════════════════════════════════════════════════════ */
function MyClassPage() {
  var useState = React.useState;
  var useEffect = React.useEffect;
  var sbSt = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  var sidebarOpen = sbSt[0];
  var setSidebarOpen = sbSt[1];
  var studSt = useState([]);
  var students = studSt[0];
  var setStudents = studSt[1];
  var loadSt = useState(true);
  var loading = loadSt[0];
  var setLoading = loadSt[1];
  var errSt = useState(null);
  var pageErr = errSt[0];
  var setPageErr = errSt[1];
  var classSt = useState(null);
  var classInfo = classSt[0];
  var setClassInfo = classSt[1];
  var myClassesSt = useState([]);
  var myClasses = myClassesSt[0];
  var setMyClasses = myClassesSt[1];
  var selectedClassSt = useState('');
  var selectedClassId = selectedClassSt[0];
  var setSelectedClassId = selectedClassSt[1];
  var searchSt = useState('');
  var search = searchSt[0];
  var setSearch = searchSt[1];
  var viewSt = useState(null);
  var viewId = viewSt[0];
  var setViewId = viewSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];

  /* ── Fetch teacher profile → class_id → students ── */
  useEffect(function () {
    fetch('/nsms/api/teacher-profile.php?action=get').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success && d.data) {
        var cid = d.data.class_id || null;
        var cname = d.data.class_name || '';
        if (cid) setClassInfo({
          class_id: cid,
          class_name: cname
        });
        var url = '/nsms/api/teacher-students.php?action=list';
        if (cid) url += '&class_id=' + cid;
        return fetch(url);
      }
      /* Profile failed — try students API anyway, it will use session */
      return fetch('/nsms/api/teacher-students.php?action=my_classes').then(function (r) { return r.json(); }).then(function (mc) {
        if (mc.success && mc.data && mc.data.length) {
          setMyClasses(mc.data);
          if (!selectedClassId && mc.data[0]) setSelectedClassId(String(mc.data[0].id));
        }
      }).catch(function () {});
      return fetch('/nsms/api/teacher-students.php?action=list');
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setStudents(d.data.students || []);
        if (d.data.class_id && !classInfo) {
          setClassInfo(function (ci) {
            return ci || {
              class_id: d.data.class_id,
              class_name: ''
            };
          });
        }
      } else {
        setPageErr(d.error || 'Failed to load students.');
      }
    }).catch(function () {
      setPageErr('Network error. Please check your connection.');
    }).finally(function () {
      setLoading(false);
    });
  }, []);
  useEffect(function () {
    if (!selectedClassId) return;
    setLoading(true);
    fetch('/nsms/api/teacher-students.php?action=list&class_id=' + selectedClassId).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setStudents(d.data.students || []);
        setClassInfo({
          class_id: d.data.class_id,
          class_name: d.data.class_name || ''
        });
      }
    }).finally(function () {
      setLoading(false);
    });
  }, [selectedClassId]);

  /* ── Auto-dismiss toast ── */
  useEffect(function () {
    if (!toast) return;
    var t = setTimeout(function () {
      setToast(null);
    }, 3500);
    return function () {
      clearTimeout(t);
    };
  }, [toast]);

  /* ── Filter ── */
  var filtered = search ? students.filter(function (s) {
    var q = search.toLowerCase();
    return s.student_name.toLowerCase().includes(q) || s.parent_name && s.parent_name.toLowerCase().includes(q) || s.parent_phone && s.parent_phone.includes(q);
  }) : students;
  var className = classInfo && classInfo.class_name ? classInfo.class_name : students[0] && students[0].class_name ? students[0].class_name : 'My Class';
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TeacherNavbar, {
    activePage: "my_class",
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(TeacherSidebar, {
    activePage: "my_class",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (sidebarOpen ? '' : ' collapsed')
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-title-wrap"
  }, (myClasses && myClasses.length > 1) && /*#__PURE__*/React.createElement("div", {
    style: { marginBottom: 12 }
  }, /*#__PURE__*/React.createElement("label", {
    style: { fontSize: 12, fontWeight: 600, marginRight: 8 }
  }, "My Classes"), /*#__PURE__*/React.createElement("select", {
    className: "filter-select",
    value: selectedClassId,
    onChange: function (e) {
      setSelectedClassId(e.target.value);
    }
  }, (myClasses || []).map(function (c) {
    return /*#__PURE__*/React.createElement("option", {
      key: c.id,
      value: String(c.id)
    }, c.class_name + (c.student_count != null ? ' (' + c.student_count + ')' : ''));
  }))), /*#__PURE__*/React.createElement("h1", null, loading ? 'My Class' : className + (students.length ? ' — ' + students.length + ' Students' : '')), /*#__PURE__*/React.createElement("p", {
    className: "page-sub"
  }, "Complete student roster and management")), /*#__PURE__*/React.createElement("div", {
    className: "header-actions"
  }, /*#__PURE__*/React.createElement("div", {
    className: "search-wrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "search-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    type: "text",
    placeholder: "Search students\u2026",
    value: search,
    onChange: function (e) {
      setSearch(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("button", {
    className: "view-btn",
    style: {
      padding: '9px 18px',
      fontSize: 13.5,
      whiteSpace: 'nowrap'
    },
    onClick: function () {
      window.location.href = '/nsms/public/teacher/attendance.html';
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " Mark Attendance"))), pageErr && !loading && /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FEF2F2',
      border: '1.5px solid #FCA5A5',
      borderRadius: 10,
      padding: '14px 18px',
      color: '#991B1B',
      fontSize: 13.5,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", pageErr), /*#__PURE__*/React.createElement("div", {
    className: "table-card"
  }, !loading && !pageErr && filtered.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, search ? 'No students match your search.' : 'No students found in your class.')) : /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Student Name"), /*#__PURE__*/React.createElement("th", null, "Parent / Guardian"), /*#__PURE__*/React.createElement("th", null, "Phone"), /*#__PURE__*/React.createElement("th", null, "Attendance"), /*#__PURE__*/React.createElement("th", null, "Performance"), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'center',
      width: '90px'
    }
  }, "Actions"))), /*#__PURE__*/React.createElement("tbody", null, loading ? /*#__PURE__*/React.createElement(ShimmerRows, null) : filtered.map(function (s) {
    var rate = s.attendance_rate;
    var perf = getPerf(rate);
    var statusClass = s.status === 'active' ? rate !== null && rate < 70 ? 'sb-attention' : 'sb-active' : 'sb-inactive';
    var statusLabel = s.status === 'active' ? rate !== null && rate < 70 ? 'Attention Needed' : 'Active' : s.status;
    return /*#__PURE__*/React.createElement("tr", {
      key: s.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "student-cell"
    }, /*#__PURE__*/React.createElement(SAvatar, {
      student: s
    }), /*#__PURE__*/React.createElement("span", {
      className: "s-name"
    }, s.student_name))), /*#__PURE__*/React.createElement("td", null, s.parent_name ? /*#__PURE__*/React.createElement("span", null, s.parent_name, s.parent_relationship && /*#__PURE__*/React.createElement("small", {
      style: {
        color: '#94A3B8'
      }
    }, " \xB7 ", s.parent_relationship)) : /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#94A3B8',
        fontStyle: 'italic'
      }
    }, "\u2014")), /*#__PURE__*/React.createElement("td", {
      style: {
        color: '#475569'
      }
    }, s.parent_phone || /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#94A3B8',
        fontStyle: 'italic'
      }
    }, "\u2014")), /*#__PURE__*/React.createElement("td", null, rate !== null ? /*#__PURE__*/React.createElement("span", {
      className: 'att-val ' + attColor(rate)
    }, rate, "%") : /*#__PURE__*/React.createElement("span", {
      className: "att-none"
    }, "\u2014")), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: "perf-badge",
      style: {
        color: perf.color
      }
    }, perf.label)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: 'status-badge ' + statusClass
    }, statusLabel)), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "view-btn",
      onClick: function () {
        setViewId(s.id);
      }
    }, "View")));
  }))))))), viewId && /*#__PURE__*/React.createElement(ViewModal, {
    studentId: viewId,
    onClose: function () {
      setViewId(null);
    }
  }), toast && /*#__PURE__*/React.createElement("div", {
    className: 'toast toast-' + toast.type
  }, toast.msg));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(MyClassPage, null));