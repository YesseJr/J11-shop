var useState = React.useState;
var useEffect = React.useEffect;
var AV_COLORS = ['#7C3AED', '#2563EB', '#10B981', '#F59E0B', '#EF4444', '#0891B2', '#DB2777'];
function avColor(n) {
  return n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
}
function initials(n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
}
function Av(props) {
  var n = props.name || '';
  var src = props.src;
  var sz = props.size || 34;
  return /*#__PURE__*/React.createElement("div", {
    className: "av",
    style: {
      width: sz,
      height: sz,
      background: avColor(n),
      fontSize: sz * 0.35
    }
  }, src && /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: n,
    onError: function (e) {
      e.currentTarget.style.display = 'none';
    }
  }), initials(n));
}
var TYPE_META = {
  terminal: {
    label: 'Terminal',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF93",
      size: 20
    }),
    cls: 'terminal'
  },
  midterm: {
    label: 'Mid-Term',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCA",
      size: 20
    }),
    cls: 'midterm'
  },
  weekly: {
    label: 'Weekly',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCC5",
      size: 20
    }),
    cls: 'weekly'
  },
  daily: {
    label: 'Daily',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCDD",
      size: 20
    }),
    cls: 'daily'
  }
};
function typeInfo(t) {
  return TYPE_META[t] || {
    label: t || 'Report',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCB",
      size: 20
    }),
    cls: 'weekly'
  };
}
function fmtDate(iso) {
  if (!iso) return '—';
  var d = new Date(iso.replace(' ', 'T'));
  return isNaN(d) ? iso : d.toLocaleDateString('en-US', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}

/* ─────────── Main App ─────────── */
function AdminReports() {
  var collapsedSt = useState(false);
  var collapsed = collapsedSt[0];
  var setCollapsed = collapsedSt[1];
  var classesSt = useState([]);
  var classes = classesSt[0];
  var setClasses = classesSt[1];
  var selClassSt = useState(null);
  var selClass = selClassSt[0];
  var setSelClass = selClassSt[1];
  var studentsSt = useState([]);
  var students = studentsSt[0];
  var setStudents = studentsSt[1];
  var selStudentSt = useState(null);
  var selStudent = selStudentSt[0];
  var setSelStudent = selStudentSt[1];
  var reportsSt = useState([]);
  var reports = reportsSt[0];
  var setReports = reportsSt[1];
  var reportCountsSt = useState({});
  var reportCounts = reportCountsSt[0];
  var setReportCounts = reportCountsSt[1];
  var filterTypeSt = useState('all');
  var filterType = filterTypeSt[0];
  var setFilterType = filterTypeSt[1];
  var filterStatusSt = useState('all');
  var filterStatus = filterStatusSt[0];
  var setFilterStatus = filterStatusSt[1];
  var loadingClassesSt = useState(true);
  var loadingClasses = loadingClassesSt[0];
  var setLoadingClasses = loadingClassesSt[1];
  var loadingStudentsSt = useState(false);
  var loadingStudents = loadingStudentsSt[0];
  var setLoadingStudents = loadingStudentsSt[1];
  var loadingReportsSt = useState(false);
  var loadingReports = loadingReportsSt[0];
  var setLoadingReports = loadingReportsSt[1];
  var searchSt = useState('');
  var search = searchSt[0];
  var setSearch = searchSt[1];
  var totalStatsSt = useState({
    total: 0,
    published: 0,
    drafts: 0,
    students: 0
  });
  var totalStats = totalStatsSt[0];
  var setTotalStats = totalStatsSt[1];
  var pendingSt = useState([]);
  var pending = pendingSt[0];
  var setPending = pendingSt[1];
  var loadingPendingSt = useState(true);
  var loadingPending = loadingPendingSt[0];
  var setLoadingPending = loadingPendingSt[1];
  var expandedIdSt = useState(null);
  var expandedId = expandedIdSt[0];
  var setExpandedId = expandedIdSt[1];
  var expandedDataSt = useState(null);
  var expandedData = expandedDataSt[0];
  var setExpandedData = expandedDataSt[1];
  var loadingDetailSt = useState(false);
  var loadingDetail = loadingDetailSt[0];
  var setLoadingDetail = loadingDetailSt[1];
  var actingSt = useState(false);
  var acting = actingSt[0];
  var setActing = actingSt[1];
  var rejectNoteSt = useState('');
  var rejectNote = rejectNoteSt[0];
  var setRejectNote = rejectNoteSt[1];
  var showRejectBoxSt = useState(false);
  var showRejectBox = showRejectBoxSt[0];
  var setShowRejectBox = showRejectBoxSt[1];
  async function loadPending() {
    setLoadingPending(true);
    fetch('/nsms/api/teacher-reports.php?action=review_queue').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setPending(d.data.reports || []);
    }).catch(function () {}).finally(function () {
      setLoadingPending(false);
    });
  }
  useEffect(function () {
    loadPending();
  }, []);
  async function toggleExpand(reportId) {
    if (expandedId === reportId) {
      setExpandedId(null);
      setExpandedData(null);
      setShowRejectBox(false);
      return;
    }
    setExpandedId(reportId);
    setExpandedData(null);
    setShowRejectBox(false);
    setRejectNote('');
    setLoadingDetail(true);
    fetch('/nsms/api/teacher-reports.php?action=existing_report&id=' + reportId).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setExpandedData(d.data);
    }).catch(function () {}).finally(function () {
      setLoadingDetail(false);
    });
  }
  async function approvePending(reportId) {
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Publish report?', message: 'Approve this report? It will be published and the parent notified immediately.', confirmLabel: 'Approve & publish', variant: 'warn' }) : Promise.resolve(false)))) return;
    setActing(true);
    fetch('/nsms/api/teacher-reports.php?action=approve_report', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        action: 'approve_report',
        report_id: reportId
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setExpandedId(null);
        setExpandedData(null);
        loadPending();
        if (selStudent) selectStudent(selStudent);
      } else alert(d.error || 'Failed to approve.');
    }).catch(function () {
      alert('Network error.');
    }).finally(function () {
      setActing(false);
    });
  }
  function rejectPending(reportId) {
    if (!rejectNote.trim()) {
      alert('Please explain what needs to change.');
      return;
    }
    setActing(true);
    fetch('/nsms/api/teacher-reports.php?action=reject_report', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        action: 'reject_report',
        report_id: reportId,
        note: rejectNote.trim()
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setExpandedId(null);
        setExpandedData(null);
        setShowRejectBox(false);
        setRejectNote('');
        loadPending();
      } else alert(d.error || 'Failed to send back.');
    }).catch(function () {
      alert('Network error.');
    }).finally(function () {
      setActing(false);
    });
  }
  useEffect(function () {
    fetch('/nsms/api/analytics.php?action=class_distribution').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success && d.data) {
        setClasses(d.data);
      }
      setLoadingClasses(false);
    }).catch(function () {
      setLoadingClasses(false);
    });
    fetch('/nsms/api/analytics.php?action=overview').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success && d.data) setTotalStats({
        total: d.data.total_students || 0,
        published: 0,
        drafts: 0,
        students: d.data.total_students || 0
      });
    });
  }, []);
  function selectClass(cls) {
    setSelClass(cls);
    setSelStudent(null);
    setReports([]);
    setSearch('');
    setLoadingStudents(true);
    fetch('/nsms/api/teacher-reports.php?action=students&class_id=' + cls.id).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        var studs = d.data.students || d.students || [];
        setStudents(studs);
        // Load report counts per student
        var counts = {};
        var remaining = studs.length;
        if (!remaining) {
          setLoadingStudents(false);
          return;
        }
        studs.forEach(function (s) {
          fetch('/nsms/api/teacher-reports.php?action=report_list&student_id=' + s.id).then(function (r) {
            return r.json();
          }).then(function (rd) {
            counts[s.id] = rd.success && rd.data && rd.data.reports ? rd.data.reports.length : 0;
            remaining--;
            if (remaining <= 0) {
              setReportCounts(Object.assign({}, counts));
              setLoadingStudents(false);
            }
          }).catch(function () {
            remaining--;
            if (remaining <= 0) {
              setReportCounts(Object.assign({}, counts));
              setLoadingStudents(false);
            }
          });
        });
      } else {
        setLoadingStudents(false);
      }
    }).catch(function () {
      setLoadingStudents(false);
    });
  }
  async function selectStudent(student) {
    setSelStudent(student);
    setReports([]);
    setFilterType('all');
    setFilterStatus('all');
    setLoadingReports(true);
    fetch('/nsms/api/teacher-reports.php?action=report_list&student_id=' + student.id).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success && d.data) {
        setReports(d.data.reports || []);
      }
      setLoadingReports(false);
    }).catch(function () {
      setLoadingReports(false);
    });
  }
  var viewIdSt = useState(null);
  var viewId = viewIdSt[0];
  var setViewId = viewIdSt[1];
  var viewDataSt = useState(null);
  var viewData = viewDataSt[0];
  var setViewData = viewDataSt[1];
  var viewLoadingSt = useState(false);
  var viewLoading = viewLoadingSt[0];
  var setViewLoading = viewLoadingSt[1];
  var viewRejectBoxSt = useState(false);
  var viewRejectBox = viewRejectBoxSt[0];
  var setViewRejectBox = viewRejectBoxSt[1];
  var viewRejectNoteSt = useState('');
  var viewRejectNote = viewRejectNoteSt[0];
  var setViewRejectNote = viewRejectNoteSt[1];
  async function openReport(rpt) {
    setViewId(rpt.id);
    setViewData(null);
    setViewRejectBox(false);
    setViewRejectNote('');
    setViewLoading(true);
    fetch('/nsms/api/teacher-reports.php?action=existing_report&id=' + rpt.id).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setViewData(d.data);
    }).catch(function () {}).finally(function () {
      setViewLoading(false);
    });
  }
  async function closeViewer() {
    setViewId(null);
    setViewData(null);
    setViewRejectBox(false);
    setViewRejectNote('');
  }
  async function viewerApprove() {
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Publish report?', message: 'Approve this report? It will be published and the parent notified immediately.', confirmLabel: 'Approve & publish', variant: 'warn' }) : Promise.resolve(false)))) return;
    setActing(true);
    fetch('/nsms/api/teacher-reports.php?action=approve_report', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        action: 'approve_report',
        report_id: viewId
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        closeViewer();
        loadPending();
        if (selStudent) selectStudent(selStudent);
      } else alert(d.error || 'Failed to approve.');
    }).catch(function () {
      alert('Network error.');
    }).finally(function () {
      setActing(false);
    });
  }
  function viewerReject() {
    if (!viewRejectNote.trim()) {
      alert('Please explain what needs to change.');
      return;
    }
    setActing(true);
    fetch('/nsms/api/teacher-reports.php?action=reject_report', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        action: 'reject_report',
        report_id: viewId,
        note: viewRejectNote.trim()
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        closeViewer();
        loadPending();
        if (selStudent) selectStudent(selStudent);
      } else alert(d.error || 'Failed to send back.');
    }).catch(function () {
      alert('Network error.');
    }).finally(function () {
      setActing(false);
    });
  }
  var filteredStudents = students.filter(function (s) {
    return !search || s.student_name.toLowerCase().includes(search.toLowerCase());
  });
  var filteredReports = reports.filter(function (r) {
    if (filterType !== 'all' && r.report_type !== filterType) return false;
    if (filterStatus === 'published' && !r.is_published) return false;
    if (filterStatus === 'draft' && r.is_published) return false;
    return true;
  });
  var totalReports = reports.length;
  var publishedCount = reports.filter(function (r) {
    return r.is_published;
  }).length;
  var draftCount = reports.filter(function (r) {
    return !r.is_published;
  }).length;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NSMSNavbar, {
    activePage: "reports",
    onToggleSidebar: function () {
      setCollapsed(function (c) {
        return !c;
      });
    }
  }), /*#__PURE__*/React.createElement(NSMSSidebar, {
    items: NSMS_SIDEBAR_ITEMS,
    activePage: "reports",
    collapsed: collapsed
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (collapsed ? ' collapsed' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "rp-shell"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rp-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rp-brand"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rp-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "rp-logo"
  }, "School Reports"), /*#__PURE__*/React.createElement("div", {
    className: "rp-tagline"
  }, "Academic performance across all classes")))), !loadingPending && pending.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "review-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "review-panel-head"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "review-panel-title"
  }, "Awaiting Your Review"), /*#__PURE__*/React.createElement("span", {
    className: "review-count"
  }, pending.length)), /*#__PURE__*/React.createElement("div", {
    className: "review-list"
  }, pending.map(function (p) {
    var ti = typeInfo(p.report_type);
    var isOpen = expandedId === p.id;
    return /*#__PURE__*/React.createElement("div", {
      key: p.id
    }, /*#__PURE__*/React.createElement("div", {
      className: "review-row"
    }, /*#__PURE__*/React.createElement("div", {
      className: "review-row-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "review-row-name"
    }, ti.icon, ' ', p.student_name, ' ', "\u2014", ' ', ti.label, ' ', "(", p.period_label, ")"), /*#__PURE__*/React.createElement("div", {
      className: "review-row-meta"
    }, p.class_name || '—', ' ', "\xB7 Submitted by", ' ', p.teacher_name || '—', ' ', "\xB7", ' ', fmtDate(p.submitted_at))), /*#__PURE__*/React.createElement("button", {
      className: "review-btn expand",
      onClick: function () {
        toggleExpand(p.id);
      }
    }, isOpen ? 'Hide' : 'Review')), isOpen && /*#__PURE__*/React.createElement("div", {
      className: "review-detail"
    }, loadingDetail ? /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        padding: '12px 0',
        color: 'var(--text-muted)',
        fontSize: 13
      }
    }, "Loading\u2026") : expandedData ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "review-detail-grid"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "review-detail-label"
    }, "Teacher Comments"), /*#__PURE__*/React.createElement("div", {
      className: "review-detail-val"
    }, expandedData.report.teacher_comments || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "review-detail-label"
    }, "Recommendations"), /*#__PURE__*/React.createElement("div", {
      className: "review-detail-val"
    }, expandedData.report.recommendations || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "review-detail-label"
    }, "Conduct"), /*#__PURE__*/React.createElement("div", {
      className: "review-detail-val"
    }, expandedData.report.conduct || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "review-detail-label"
    }, "Promotion Status"), /*#__PURE__*/React.createElement("div", {
      className: "review-detail-val"
    }, expandedData.report.promotion_status || '—'))), expandedData.report.subject_data && Object.keys(expandedData.report.subject_data).length > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "review-detail-label",
      style: {
        marginBottom: 8
      }
    }, "Subject Grades"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexWrap: 'wrap',
        gap: 8
      }
    }, Object.entries(expandedData.report.subject_data).map(function (entry) {
      var subj = entry[0],
        sd = entry[1];
      return /*#__PURE__*/React.createElement("span", {
        key: subj,
        style: {
          fontSize: 12,
          padding: '4px 10px',
          borderRadius: 6,
          background: '#EEF2FF',
          color: '#4338CA',
          fontWeight: 600
        }
      }, subj, ":", ' ', sd.grade_letter || sd.average_score || '—');
    }))), /*#__PURE__*/React.createElement("div", {
      className: "review-actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "review-btn review-btn-approve",
      disabled: acting,
      onClick: function () {
        approvePending(p.id);
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2705",
      size: 18
    }), "Approve & Publish"), /*#__PURE__*/React.createElement("button", {
      className: "review-btn review-btn-reject",
      disabled: acting,
      onClick: function () {
        setShowRejectBox(!showRejectBox);
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u270F\uFE0F",
      size: 18
    }), "Send Back for Changes")), showRejectBox && /*#__PURE__*/React.createElement("div", {
      className: "review-note-box"
    }, /*#__PURE__*/React.createElement("textarea", {
      placeholder: "Explain what needs to change before this can go to the parent\u2026",
      value: rejectNote,
      onChange: function (e) {
        setRejectNote(e.target.value);
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8,
        display: 'flex',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "review-btn review-btn-reject",
      disabled: acting,
      onClick: function () {
        rejectPending(p.id);
      }
    }, acting ? 'Sending…' : 'Send Back'), /*#__PURE__*/React.createElement("button", {
      className: "review-btn expand",
      onClick: function () {
        setShowRejectBox(false);
      }
    }, "Cancel")))) : /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--text-muted)'
      }
    }, "Could not load this report.")));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "stat-strip"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ss-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ss-icon violet"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ss-val"
  }, classes.length), /*#__PURE__*/React.createElement("div", {
    className: "ss-lbl"
  }, "Classes"))), /*#__PURE__*/React.createElement("div", {
    className: "ss-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ss-icon blue"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ss-val"
  }, totalStats.students), /*#__PURE__*/React.createElement("div", {
    className: "ss-lbl"
  }, "Students"))), selStudent && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "ss-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ss-icon violet"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ss-val"
  }, totalReports), /*#__PURE__*/React.createElement("div", {
    className: "ss-lbl"
  }, "Total Reports"))), /*#__PURE__*/React.createElement("div", {
    className: "ss-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ss-icon green"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ss-val"
  }, publishedCount), /*#__PURE__*/React.createElement("div", {
    className: "ss-lbl"
  }, "Published"))), /*#__PURE__*/React.createElement("div", {
    className: "ss-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ss-icon amber"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ss-val"
  }, draftCount), /*#__PURE__*/React.createElement("div", {
    className: "ss-lbl"
  }, "Drafts"))))), /*#__PURE__*/React.createElement("div", {
    className: "three-col"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cp-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cp-title"
  }, "Classes")), /*#__PURE__*/React.createElement("div", {
    className: "cp-list"
  }, loadingClasses && [1, 2, 3, 4].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        padding: '11px 13px',
        borderBottom: '1px solid #F8FAFC'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        height: 12,
        borderRadius: 6,
        width: '70%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        height: 10,
        borderRadius: 6,
        width: '40%'
      }
    }));
  }), !loadingClasses && classes.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "panel-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "No classes found")), !loadingClasses && classes.map(function (cls) {
    return /*#__PURE__*/React.createElement("div", {
      key: cls.class_id || cls.id,
      className: 'cli' + (selClass && (selClass.class_id || selClass.id) === (cls.class_id || cls.id) ? ' active' : ''),
      onClick: function () {
        selectClass({
          id: cls.class_id || cls.id,
          name: cls.class_name,
          color: cls.class_color
        });
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "cli-dot",
      style: {
        background: cls.class_color || '#7C3AED'
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "cli-name"
    }, cls.class_name), /*#__PURE__*/React.createElement("span", {
      className: "cli-cnt"
    }, cls.student_count || cls.cnt || 0));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "sp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sp-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sp-title"
  }, selClass ? selClass.name : 'Select a Class'), filteredStudents.length > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--text-muted)',
      background: '#F1F5F9',
      padding: '1px 7px',
      borderRadius: 9
    }
  }, filteredStudents.length)), students.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "sp-search"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ssi"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search students\u2026",
    value: search,
    onChange: function (e) {
      setSearch(e.target.value);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "sp-list"
  }, !selClass && /*#__PURE__*/React.createElement("div", {
    className: "panel-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC48",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "Pick a class to see students")), selClass && loadingStudents && [1, 2, 3, 4, 5].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        padding: '10px 13px',
        borderBottom: '1px solid #F8FAFC',
        display: 'flex',
        alignItems: 'center',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        width: 34,
        height: 34,
        borderRadius: '50%',
        flexShrink: 0
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        height: 11,
        borderRadius: 5,
        width: '70%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        height: 10,
        borderRadius: 5,
        width: '40%'
      }
    })));
  }), !loadingStudents && selClass && filteredStudents.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "panel-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF92",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "No students in this class")), !loadingStudents && filteredStudents.map(function (s) {
    return /*#__PURE__*/React.createElement("div", {
      key: s.id,
      className: 'sti' + (selStudent && selStudent.id === s.id ? ' active' : ''),
      onClick: function () {
        selectStudent(s);
      }
    }, /*#__PURE__*/React.createElement(Av, {
      name: s.student_name,
      src: s.photo_url,
      size: 34
    }), /*#__PURE__*/React.createElement("div", {
      className: "sti-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "sti-name"
    }, s.student_name), /*#__PURE__*/React.createElement("div", {
      className: "sti-meta"
    }, s.gender || '—')), reportCounts[s.id] > 0 && /*#__PURE__*/React.createElement("span", {
      className: "rpcount"
    }, reportCounts[s.id]));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "rl"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rl-head"
  }, selStudent ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Av, {
    name: selStudent.student_name,
    src: selStudent.photo_url,
    size: 34
  }), /*#__PURE__*/React.createElement("div", {
    className: "rl-name"
  }, selStudent.student_name, "'s Reports")) : /*#__PURE__*/React.createElement("div", {
    className: "rl-name",
    style: {
      color: 'var(--text-muted)',
      fontWeight: 600
    }
  }, "Reports")), selStudent && /*#__PURE__*/React.createElement("div", {
    className: "rl-filters"
  }, ['all', 'terminal', 'midterm', 'weekly', 'daily'].map(function (t) {
    return /*#__PURE__*/React.createElement("button", {
      key: t,
      className: 'fchip' + (filterType === t ? ' active' : ''),
      onClick: function () {
        setFilterType(t);
      }
    }, t === 'all' ? 'All Types' : typeInfo(t).icon + ' ' + typeInfo(t).label);
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      background: 'var(--border)',
      margin: '0 4px'
    }
  }), ['all', 'published', 'draft'].map(function (s) {
    return /*#__PURE__*/React.createElement("button", {
      key: s,
      className: 'fchip' + (filterStatus === s ? ' active' : ''),
      onClick: function () {
        setFilterStatus(s);
      }
    }, s === 'all' ? 'Any Status' : s === 'published' ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2705",
      size: 16
    }), "Published") : /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u270F\uFE0F",
      size: 16
    }), "Drafts"));
  })), /*#__PURE__*/React.createElement("div", {
    className: "rl-body"
  }, !selStudent && /*#__PURE__*/React.createElement("div", {
    className: "panel-empty",
    style: {
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, "\uD83D\uDCCB"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-dark)'
    }
  }, "Select a student to view their reports"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "Choose a class, then a student")), selStudent && loadingReports && [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        border: '1.5px solid var(--border)',
        borderRadius: 12,
        padding: '16px 18px',
        marginBottom: 10,
        display: 'flex',
        gap: 14,
        alignItems: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        width: 40,
        height: 40,
        borderRadius: 10,
        flexShrink: 0
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        height: 13,
        borderRadius: 6,
        width: '45%',
        marginBottom: 8
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        height: 11,
        borderRadius: 6,
        width: '65%',
        marginBottom: 10
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        height: 22,
        borderRadius: 6,
        width: '25%'
      }
    })));
  }), !loadingReports && selStudent && filteredReports.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "panel-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, "\uD83D\uDDC2\uFE0F"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-dark)'
    }
  }, "No reports match this filter"), /*#__PURE__*/React.createElement("span", null, "Try changing the type or status filter")), !loadingReports && filteredReports.map(function (rpt) {
    var ti = typeInfo(rpt.report_type);
    return /*#__PURE__*/React.createElement("div", {
      key: rpt.id,
      className: "rcard",
      onClick: function () {
        openReport(rpt);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: 'rcard-icon ' + ti.cls
    }, ti.icon), /*#__PURE__*/React.createElement("div", {
      className: "rcard-body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "rcard-title"
    }, rpt.period_label || ti.label + ' Report'), /*#__PURE__*/React.createElement("div", {
      className: "rcard-meta"
    }, /*#__PURE__*/React.createElement("span", null, "\uD83D\uDCC5", ' ', rpt.term || '—'), /*#__PURE__*/React.createElement("span", null, "\uD83D\uDCC6", ' ', rpt.academic_year || '—'), /*#__PURE__*/React.createElement("span", null, "\uD83D\uDD50", ' ', fmtDate(rpt.created_at))), /*#__PURE__*/React.createElement("div", {
      className: "rcard-foot"
    }, rpt.is_published ? /*#__PURE__*/React.createElement("span", {
      className: "status-pill published"
    }, "\u2705 Published") : rpt.review_status === 'pending' ? /*#__PURE__*/React.createElement("span", {
      className: "status-pill awaiting"
    }, "\u23F3 Awaiting Review") : rpt.review_status === 'rejected' ? /*#__PURE__*/React.createElement("span", {
      className: "status-pill rejected"
    }, "\u270F\uFE0F Sent Back") : /*#__PURE__*/React.createElement("span", {
      className: "status-pill draft"
    }, "\u270F\uFE0F Draft"), /*#__PURE__*/React.createElement("button", {
      className: "view-btn",
      onClick: function (e) {
        e.stopPropagation();
        openReport(rpt);
      }
    }, "View \u2192"))));
  }))))))), viewId && /*#__PURE__*/React.createElement("div", {
    className: "rv-overlay",
    onClick: function (e) {
      if (e.target === e.currentTarget) closeViewer();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "rv-modal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rv-head"
  }, viewData && /*#__PURE__*/React.createElement(Av, {
    name: viewData.student ? viewData.student.student_name : '',
    src: viewData.student ? viewData.student.photo_url : null,
    size: 40
  }), /*#__PURE__*/React.createElement("div", {
    className: "rv-head-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rv-head-name"
  }, viewData && viewData.student ? viewData.student.student_name : 'Loading…'), /*#__PURE__*/React.createElement("div", {
    className: "rv-head-meta"
  }, viewData && /*#__PURE__*/React.createElement(React.Fragment, null, typeInfo(viewData.report.report_type).icon, ' ', typeInfo(viewData.report.report_type).label, ' ', "\xB7", ' ', viewData.report.period_label, ' ', "\xB7 ", viewData.report.term, ' ', viewData.report.academic_year))), /*#__PURE__*/React.createElement("button", {
    className: "rv-close",
    onClick: closeViewer
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "rv-body"
  }, viewLoading ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 0',
      color: 'var(--text-muted)'
    }
  }, "Loading\u2026") : !viewData ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 0',
      color: 'var(--text-muted)'
    }
  }, "Could not load this report.") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "rv-section"
  }, viewData.report.is_published ? /*#__PURE__*/React.createElement("span", {
    className: "status-pill published"
  }, "\u2705 Published") : viewData.report.review_status === 'pending' ? /*#__PURE__*/React.createElement("span", {
    className: "status-pill awaiting"
  }, "\u23F3 Awaiting Review") : viewData.report.review_status === 'rejected' ? /*#__PURE__*/React.createElement("span", {
    className: "status-pill rejected"
  }, "\u270F\uFE0F Sent Back") : /*#__PURE__*/React.createElement("span", {
    className: "status-pill draft"
  }, "\u270F\uFE0F Draft")), viewData.report.review_status === 'rejected' && viewData.report.review_note && /*#__PURE__*/React.createElement("div", {
    className: "rv-section",
    style: {
      background: '#FEF2F2',
      border: '1px solid #FECACA',
      borderRadius: 8,
      padding: '10px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "rv-label",
    style: {
      color: '#991B1B'
    }
  }, "Sent back with this note"), /*#__PURE__*/React.createElement("div", {
    className: "rv-val",
    style: {
      color: '#991B1B'
    }
  }, viewData.report.review_note)), /*#__PURE__*/React.createElement("div", {
    className: "rv-section rv-grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "rv-label"
  }, "Teacher Comments"), /*#__PURE__*/React.createElement("div", {
    className: "rv-val"
  }, viewData.report.teacher_comments || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "rv-label"
  }, "Recommendations"), /*#__PURE__*/React.createElement("div", {
    className: "rv-val"
  }, viewData.report.recommendations || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "rv-label"
  }, "Conduct"), /*#__PURE__*/React.createElement("div", {
    className: "rv-val"
  }, viewData.report.conduct || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "rv-label"
  }, "Punctuality"), /*#__PURE__*/React.createElement("div", {
    className: "rv-val"
  }, viewData.report.punctuality || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "rv-label"
  }, "Neatness"), /*#__PURE__*/React.createElement("div", {
    className: "rv-val"
  }, viewData.report.neatness || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "rv-label"
  }, "Class Participation"), /*#__PURE__*/React.createElement("div", {
    className: "rv-val"
  }, viewData.report.class_participation || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "rv-label"
  }, "Social Skills"), /*#__PURE__*/React.createElement("div", {
    className: "rv-val"
  }, viewData.report.social_skills || '—')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "rv-label"
  }, "Promotion Status"), /*#__PURE__*/React.createElement("div", {
    className: "rv-val"
  }, viewData.report.promotion_status || '—'))), viewData.report.subject_data && Object.keys(viewData.report.subject_data).length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "rv-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rv-label",
    style: {
      marginBottom: 6
    }
  }, "Subject Grades"), Object.entries(viewData.report.subject_data).map(function (entry) {
    var subj = entry[0],
      sd = entry[1];
    return /*#__PURE__*/React.createElement("div", {
      className: "rv-subject-row",
      key: subj
    }, /*#__PURE__*/React.createElement("span", null, subj), /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700
      }
    }, sd.grade_letter || '—', ' ', sd.average_score ? '(' + sd.average_score + '%)' : ''));
  })))), viewData && viewData.report.review_status === 'pending' && /*#__PURE__*/React.createElement("div", {
    className: "rv-footer",
    style: {
      flexDirection: 'column',
      alignItems: 'stretch'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "review-btn review-btn-approve",
    style: {
      flex: 1
    },
    disabled: acting,
    onClick: viewerApprove
  }, "\u2705 Approve & Publish"), /*#__PURE__*/React.createElement("button", {
    className: "review-btn review-btn-reject",
    style: {
      flex: 1
    },
    disabled: acting,
    onClick: function () {
      setViewRejectBox(!viewRejectBox);
    }
  }, "\u270F\uFE0F Send Back")), viewRejectBox && /*#__PURE__*/React.createElement("div", {
    className: "review-note-box"
  }, /*#__PURE__*/React.createElement("textarea", {
    placeholder: "Explain what needs to change before this can go to the parent\u2026",
    value: viewRejectNote,
    onChange: function (e) {
      setViewRejectNote(e.target.value);
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "review-btn review-btn-reject",
    disabled: acting,
    onClick: viewerReject
  }, acting ? 'Sending…' : 'Send Back'), /*#__PURE__*/React.createElement("button", {
    className: "review-btn expand",
    onClick: function () {
      setViewRejectBox(false);
    }
  }, "Cancel")))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(AdminReports, null));