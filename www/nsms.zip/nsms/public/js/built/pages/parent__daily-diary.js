/* ════════════════════════════════════════════════════════════
   DAILY DIARY PAGE — NSMS Parent Panel
   • Fetches children linked to the logged-in parent
   • Lists homework for the selected child's class
   • Filter tabs: All / Pending / Acknowledged
   • Acknowledge button with optimistic UI update
════════════════════════════════════════════════════════════ */

const {
  useState,
  useEffect,
  useRef
} = React;

/* ── API helpers ── */
async function api(params) {
  const url = '/nsms/api/parent-daily-diary.php?' + new URLSearchParams(params);
  const r = await fetch(url);
  const text = await r.text();
  try {
    return JSON.parse(text);
  } catch {
    console.error('[NSMS] API parse error for', url, '→', text.slice(0, 300));
    return {
      success: false,
      error: 'Server returned an unexpected response.'
    };
  }
}
async function apiPost(action, body) {
  const r = await fetch(`/nsms/api/parent-daily-diary.php?action=${action}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  const text = await r.text();
  try {
    return JSON.parse(text);
  } catch {
    console.error('[NSMS] apiPost parse error →', text.slice(0, 300));
    return {
      success: false,
      error: 'Server returned an unexpected response.'
    };
  }
}

/* ── Subject badge class resolver ── */
function subjClass(subject) {
  const known = ['mathematics', 'math', 'english', 'arts', 'art', 'science', 'social', 'kiswahili', 'swahili', 'music', 'pe', 'religion'];
  const key = (subject || '').toLowerCase().replace(/[^a-z]/g, '');
  return 'subj-badge subj-' + (known.includes(key) ? key : 'other');
}

/* ── Due-date urgency: today or overdue ── */
function isDueUrgent(dueLabel) {
  return dueLabel === 'Today' || dueLabel === 'Yesterday';
}

/* ════════════════════════════════════════════════════════════
   SKELETON
════════════════════════════════════════════════════════════ */
function Skeleton() {
  return /*#__PURE__*/React.createElement(React.Fragment, null, [1, 2, 3].map(n => /*#__PURE__*/React.createElement("div", {
    key: n,
    className: "sk-row"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 7,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      width: 88,
      height: 22
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      width: 110,
      height: 22
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      width: 80,
      height: 22
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      width: '65%',
      height: 17,
      marginBottom: 8
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      width: 130,
      height: 13
    }
  }))));
}

/* ════════════════════════════════════════════════════════════
   CHILD SELECTOR
════════════════════════════════════════════════════════════ */
function ChildSelector({
  children,
  selectedChild,
  setSelectedChild
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const onOut = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', onOut);
    return () => document.removeEventListener('mousedown', onOut);
  }, [open]);
  if (!selectedChild) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "child-sel",
    ref: ref
  }, /*#__PURE__*/React.createElement("button", {
    className: "child-sel-btn",
    onClick: () => {
      if (children.length > 1) setOpen(o => !o);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "child-av"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC66",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "child-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "child-name"
  }, selectedChild.student_name), selectedChild.class_name && /*#__PURE__*/React.createElement("div", {
    className: "child-class"
  }, selectedChild.class_name)), children.length > 1 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)'
    }
  }, open ? '▴' : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '▾',
    size: 16
  }) : null)), open && children.length > 1 && /*#__PURE__*/React.createElement("div", {
    className: "child-dd"
  }, children.map(child => /*#__PURE__*/React.createElement("button", {
    key: child.id,
    className: `child-dd-item ${selectedChild.id === child.id ? 'sel' : ''}`,
    onClick: () => {
      setSelectedChild(child);
      setOpen(false);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "child-av"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC66",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "child-name"
  }, child.student_name), child.class_name && /*#__PURE__*/React.createElement("div", {
    className: "child-class"
  }, child.class_name)), selectedChild.id === child.id && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      color: 'var(--blue)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }))))));
}

/* ════════════════════════════════════════════════════════════
   HOMEWORK ROW
════════════════════════════════════════════════════════════ */
function HomeworkRow({
  hw,
  studentId,
  onAck,
  ackingId,
  onCommentPosted
}) {
  const isAck = hw.acknowledged;
  const urgent = !isAck && isDueUrgent(hw.due_label);
  const [showComment, setShowComment] = useState(false);
  const [comment, setComment] = useState('');
  const [sending, setSending] = useState(false);
  const [comments, setComments] = useState([]);
  const [loadingC, setLoadingC] = useState(false);
  const [localMsg, setLocalMsg] = useState(null);

  const att = hw.attachment_url || hw.attachment || '';
  const attName = att ? String(att).split('/').pop() : '';
  const isImage = att && /\.(jpe?g|png|gif|webp)$/i.test(att);

  const loadComments = async () => {
    if (!hw.id) return;
    setLoadingC(true);
    try {
      const q = 'action=list_comments&homework_id=' + hw.id + (studentId ? '&student_id=' + studentId : '');
      const r = await fetch('/nsms/api/parent-daily-diary.php?' + q, { credentials: 'same-origin' });
      const d = await r.json();
      if (d.success) setComments(d.data || []);
    } catch (e) {}
    setLoadingC(false);
  };

  useEffect(function () {
    if (hw.has_teacher_reply) {
      setShowComment(true);
      loadComments();
    }
  }, [hw.id, hw.has_teacher_reply, hw.teacher_reply_at]);

  const sendComment = async () => {
    const text = (comment || '').trim();
    if (text.length < 2) {
      setLocalMsg({ type: 'error', text: 'Please write a short comment.' });
      return;
    }
    setSending(true);
    setLocalMsg(null);
    try {
      const d = await apiPost('comment', {
        homework_id: hw.id,
        student_id: studentId,
        comment: text
      });
      if (d.success) {
        setComment('');
        setLocalMsg({ type: 'ok', text: d.message || 'Comment sent to the teacher.' });
        loadComments();
        if (onCommentPosted) onCommentPosted(d);
      } else {
        setLocalMsg({ type: 'error', text: d.error || 'Could not send comment.' });
      }
    } catch (e) {
      setLocalMsg({ type: 'error', text: 'Network error. Please try again.' });
    }
    setSending(false);
  };

  return /*#__PURE__*/React.createElement("div", {
    className: `hw-row${isAck ? ' is-acked' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-meta"
  }, /*#__PURE__*/React.createElement("span", {
    className: subjClass(hw.subject)
  }, hw.subject), /*#__PURE__*/React.createElement("span", {
    className: "hw-date"
  }, "Posted: ", /*#__PURE__*/React.createElement("b", null, hw.posted_label)), /*#__PURE__*/React.createElement("span", {
    className: "hw-date-sep"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: `hw-date${urgent ? ' hw-due-urgent' : ''}`
  }, "Due: ", /*#__PURE__*/React.createElement("b", null, hw.due_label)), isAck ? /*#__PURE__*/React.createElement("span", {
    className: "status-badge status-acked"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " Acknowledged") : /*#__PURE__*/React.createElement("span", {
    className: "status-badge status-pending"
  }, "Pending")), /*#__PURE__*/React.createElement("div", {
    className: "hw-desc"
  }, hw.description), att ? /*#__PURE__*/React.createElement("div", {
    className: "hw-attachment",
    style: {
      marginTop: 10,
      padding: 12,
      background: '#F8FAFC',
      border: '1px solid #E2E8F0',
      borderRadius: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 8 }
  }, "Attachment"), isImage ? /*#__PURE__*/React.createElement("a", {
    href: att,
    target: "_blank",
    rel: "noopener noreferrer"
  }, /*#__PURE__*/React.createElement("img", {
    src: att,
    alt: attName || 'Homework attachment',
    style: {
      maxWidth: '100%',
      maxHeight: 220,
      borderRadius: 8,
      display: 'block',
      objectFit: 'contain',
      background: '#fff'
    }
  })) : /*#__PURE__*/React.createElement("a", {
    href: att,
    target: "_blank",
    rel: "noopener noreferrer",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      color: '#1D5C42',
      fontWeight: 600,
      fontSize: 14,
      textDecoration: 'none'
    }
  }, "\uD83D\uDCCE ", attName || 'View / download attachment')) : null, /*#__PURE__*/React.createElement("div", {
    className: "hw-posted"
  }, "Posted by: ", hw.posted_by_name), (hw.has_teacher_reply && hw.teacher_reply) ? /*#__PURE__*/React.createElement("div", {
    className: "hw-teacher-reply",
    style: {
      marginTop: 12,
      padding: '12px 14px',
      background: '#EAF7F1',
      border: '1px solid #c6e9d6',
      borderRadius: 10,
      color: '#14532d'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 800,
      textTransform: 'uppercase',
      letterSpacing: '0.04em',
      marginBottom: 6,
      color: '#166534'
    }
  }, "Teacher replied"), /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 14, lineHeight: 1.5 }
  }, hw.teacher_reply), hw.teacher_reply_at ? /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 11, color: '#64748b', marginTop: 6 }
  }, hw.teacher_reply_at) : null) : null, /*#__PURE__*/React.createElement("div", {
    style: { marginTop: 12, display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }
  }, !isAck && /*#__PURE__*/React.createElement("button", {
    className: "btn-ack",
    disabled: ackingId === hw.id,
    onClick: () => onAck(hw.id)
  }, ackingId === hw.id ? '\u2026' : /*#__PURE__*/React.createElement("span", {
    style: { display: 'inline-flex', alignItems: 'center', gap: 6 }
  }, /*#__PURE__*/React.createElement(Icon, { emoji: "\u2713", size: 16 }), "Acknowledge")), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn-ack",
    style: {
      background: showComment ? '#1D5C42' : '#fff',
      color: showComment ? '#fff' : '#1D5C42',
      border: '1px solid #1D5C42'
    },
    onClick: () => {
      const next = !showComment;
      setShowComment(next);
      if (next) loadComments();
    }
  }, showComment ? 'Hide feedback' : (hw.has_teacher_reply ? 'View conversation' : 'Leave feedback'))), showComment && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      padding: 12,
      border: '1px solid #E2E8F0',
      borderRadius: 10,
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: { display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6, color: '#334155' }
  }, "Your comment for the teacher"), /*#__PURE__*/React.createElement("textarea", {
    value: comment,
    onChange: e => setComment(e.target.value),
    rows: 3,
    placeholder: "e.g. We completed the worksheet. Could you clarify question 3?",
    style: {
      width: '100%',
      boxSizing: 'border-box',
      border: '1px solid #E2E8F0',
      borderRadius: 8,
      padding: 10,
      fontSize: 14,
      resize: 'vertical'
    }
  }), localMsg && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      fontSize: 13,
      color: localMsg.type === 'ok' ? '#166534' : '#b91c1c',
      fontWeight: 600
    }
  }, localMsg.text), /*#__PURE__*/React.createElement("div", {
    style: { marginTop: 8, display: 'flex', justifyContent: 'flex-end' }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn-ack",
    disabled: sending,
    onClick: sendComment
  }, sending ? 'Sending\u2026' : 'Send to teacher')), /*#__PURE__*/React.createElement("div", {
    style: { marginTop: 14 }
  }, /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 12, fontWeight: 700, color: '#64748b', marginBottom: 6 }
  }, "Your previous comments"), loadingC ? /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 13, color: '#94a3b8' }
  }, "Loading\u2026") : comments.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 13, color: '#94a3b8' }
  }, "No comments yet.") : comments.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    style: {
      padding: '8px 10px',
      marginBottom: 6,
      background: '#F8FAFC',
      borderRadius: 8,
      fontSize: 13,
      color: '#334155'
    }
  }, /*#__PURE__*/React.createElement("div", null, c.comment), c.teacher_reply ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      padding: '8px 10px',
      background: '#EAF7F1',
      borderRadius: 6,
      fontSize: 13,
      color: '#14532d'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: { fontWeight: 700, fontSize: 11, marginBottom: 4 }
  }, "Teacher reply"), c.teacher_reply) : null, /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 11, color: '#94a3b8', marginTop: 4 }
  }, c.created_at)))))));
}

/* ════════════════════════════════════════════════════════════
   ROOT APP
════════════════════════════════════════════════════════════ */
function DailyDiaryApp() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [children, setChildren] = useState([]);
  const [selectedChild, setSelectedChild] = useState(null);
  const [unreadMsg, setUnreadMsg] = useState(0);
  const [homework, setHomework] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(false);
  const [bootLoading, setBootLoading] = useState(true);
  const [error, setError] = useState('');
  const [ackingId, setAckingId] = useState(null);

  /* ── Boot: children + unread count in parallel ── */
  useEffect(() => {
    Promise.all([api({
      action: 'get_children'
    }), fetch('/nsms/api/parent-panel.php?action=notifications_count').then(r => r.json())]).then(([cd, nd]) => {
      if (cd.success && cd.data?.length > 0) {
        setChildren(cd.data);
        setSelectedChild(cd.data[0]);
      }
      if (nd.success && nd.data) setUnreadMsg(nd.data.msgs || 0);
    }).catch(() => {}).finally(() => setBootLoading(false));
  }, []);

  /* ── Reload homework when child or filter changes ── */
  useEffect(() => {
    if (!selectedChild) return;

    /* Guard: id must be a valid positive integer.
     * If it's undefined/null/0 the backend will silently return empty —
     * log a warning here so the dev sees it in the console.          */
    const studentId = parseInt(selectedChild.id, 10);
    if (!studentId || studentId <= 0) {
      console.warn('[NSMS] selectedChild.id is not a valid integer:', selectedChild.id, 'Full selectedChild object:', selectedChild, '\nCheck parent-shared.js — ParentNavbar may be calling setSelectedChild() ' + 'with data from a different API whose student objects have a different shape.');
      setHomework([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError('');
    api({
      action: 'list',
      student_id: studentId,
      filter
    }).then(d => {
      if (d.success) setHomework((d.data && d.data.homework) || []);else {
        setError(d.error || 'Failed to load homework.');
        setHomework([]);
      }
    }).catch(() => {
      setError('Network error. Please try again.');
      setHomework([]);
    }).finally(() => setLoading(false));
  }, [selectedChild, filter]);

  /* ── Acknowledge ── */
  const handleAck = async homeworkId => {
    if (!selectedChild) return;
    const studentId = parseInt(selectedChild.id, 10);
    if (!studentId || studentId <= 0) return;
    setAckingId(homeworkId);
    try {
      const d = await apiPost('acknowledge', {
        homework_id: homeworkId,
        student_id: studentId
      });
      if (d.success) {
        setHomework(prev => prev.map(hw => hw.id === homeworkId ? {
          ...hw,
          acknowledged: true
        } : hw));
      } else {
        alert(d.error || 'Acknowledge failed. Please try again.');
      }
    } catch {
      alert('Network error. Please try again.');
    } finally {
      setAckingId(null);
    }
  };

  /* ── Derived counts ── */
  const pendingCount = homework.filter(h => !h.acknowledged).length;
  const ackedCount = homework.filter(h => h.acknowledged).length;
  const TABS = [{
    key: 'all',
    label: `All (${homework.length})`
  }, {
    key: 'pending',
    label: `Pending (${pendingCount})`
  }, {
    key: 'acknowledged',
    label: `Acknowledged (${ackedCount})`
  }];
  const childName = selectedChild?.student_name ?? '';
  const childClass = selectedChild?.class_name ?? '';
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ParentNavbar, {
    activePage: "daily_diary",
    sidebarOpen: sidebarOpen,
    setSidebar: setSidebarOpen,
    unreadMsg: unreadMsg,
    children: children,
    selectedChild: selectedChild,
    setSelectedChild: setSelectedChild
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(ParentSidebar, {
    activePage: "daily_diary",
    sidebarOpen: sidebarOpen,
    unreadMsg: unreadMsg
  }), /*#__PURE__*/React.createElement("div", {
    className: `main-area ${sidebarOpen ? '' : 'collapsed'}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-title-wrap"
  }, /*#__PURE__*/React.createElement("h1", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  }), " Daily Diary", childName ? ` — ${childName}` : ''), /*#__PURE__*/React.createElement("div", {
    className: "page-sub"
  }, bootLoading ? 'Loading…' : childClass ? `View all homework and daily activities · ${childClass}` : 'View all homework and daily activities')), /*#__PURE__*/React.createElement("div", {
    className: "header-actions"
  }, /*#__PURE__*/React.createElement(ChildSelector, {
    children: children,
    selectedChild: selectedChild,
    setSelectedChild: setSelectedChild
  }))), error && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-error"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), " ", error), bootLoading ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading diary\u2026"))

  /* ── No children linked ── */ : children.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      background: 'white',
      borderRadius: 14,
      border: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 52
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67",
    size: 18
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: 16
    }
  }, "No children linked to your account"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: 'var(--text-soft)',
      textAlign: 'center',
      maxWidth: 340
    }
  }, "Contact the school administrator to link your children to your parent account.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-tabs"
  }, TABS.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.key,
    className: `gb-tab ${filter === t.key ? 'active' : ''}`,
    onClick: () => setFilter(t.key)
  }, t.label))), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, "All Homework"), !loading && /*#__PURE__*/React.createElement("div", {
    className: "card-sub"
  }, homework.length, " assignment", homework.length !== 1 ? 's' : '', " \xB7 ", pendingCount, " pending")), !loading && homework.length > 0 && /*#__PURE__*/React.createElement("span", {
    className: "count-pill"
  }, filter === 'all' ? homework.length : filter === 'pending' ? pendingCount : ackedCount, " shown")), /*#__PURE__*/React.createElement("div", {
    className: "hw-list"
  }, loading ? /*#__PURE__*/React.createElement(Skeleton, null) : homework.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 48
    }
  }, filter === 'pending' ? '✅' : filter === 'acknowledged' ? typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📋',
    size: 16
  }) : null : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📖',
    size: 16
  }) : null), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: 15
    }
  }, filter === 'pending' ? 'No pending homework!' : filter === 'acknowledged' ? 'No acknowledged homework yet' : 'No homework assigned yet'), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      textAlign: 'center',
      maxWidth: 320
    }
  }, filter === 'pending' ? 'All homework has been acknowledged — great job! 🎉' : filter === 'acknowledged' ? 'Homework you acknowledge will appear here.' : 'Homework posted by the teacher will appear here.')) : homework.map(hw => /*#__PURE__*/React.createElement(HomeworkRow, {
    key: hw.id,
    hw: hw,
    studentId: selectedChild && selectedChild.id,
    onAck: handleAck,
    ackingId: ackingId
  })))))))));
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/React.createElement(DailyDiaryApp, null));