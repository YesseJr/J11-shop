const {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo
} = React;

/* ═══════════════════════════════════════════
CONSTANTS & FORMATTERS
═══════════════════════════════════════════ */
const API = '/nsms/api/parent-finance.php';
const fmtF = v => 'TSh ' + (Number(v) || 0).toLocaleString('en-TZ', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 0
});
const fmtD = v => {
  if (!v) return '—';
  const d = new Date((v + '').replace(' ', 'T'));
  return isNaN(d) ? v : d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
};
const pct = (a, b) => b > 0 ? Math.round(a / b * 100) : 0;
const MDISP = {
  Cash: 'Cash',
  'M-Pesa': 'M-Pesa',
  'Bank Transfer': 'Bank Transfer',
  Cheque: 'Cheque 📄',
  'Tigo Pesa': 'Tigo Pesa 📱',
  'Airtel Money': 'Airtel Money 📱',
  HaloPesa: 'HaloPesa 📱',
  'Mixx by Yas': 'Mixx by Yas 📱',
  Visa: 'Visa 💳',
  Mastercard: 'Mastercard 💳'
};
const mDisp = m => {
  if (!m) return m;
  if (m.startsWith('Scholarship')) return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 16
  }), "Scholarship");
  return MDISP[m] || m;
};
const mBadge = m => {
  if (!m) return 'xgr';
  if (m === 'Cash') return 'xg';
  if (m === 'M-Pesa') return 'xb';
  if (m === 'Bank Transfer') return 'xy';
  if (m === 'Cheque') return 'xgr';
  if (m.startsWith('Scholarship')) return 'xp';
  if (['Tigo Pesa', 'Airtel Money', 'HaloPesa', 'Mixx by Yas'].includes(m)) return 'xb';
  if (['Visa', 'Mastercard'].includes(m)) return 'xv';
  return 'xgr';
};
const FEE_ICONS = {
  'School Fees': '📚',
  Transport: '🚌',
  Registration: '📝',
  Stationery: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F",
    size: 16
  }),
  Meals: '🍱',
  Uniform: '👕',
  Activity: '🎨'
};
const feeIcon = t => FEE_ICONS[t] || '💰';

/* ═══════════════════════════════════════════
API HELPER
═══════════════════════════════════════════ */
async function apiFetch(action, params = {}) {
  try {
    const qs = new URLSearchParams({
      action,
      ...params
    }).toString();
    const r = await fetch(`${API}?${qs}`, {
      credentials: 'include'
    });
    if (r.status === 401) {
      window.location.href = '/nsms/public/parent/index.html';
      return null;
    }
    const raw = await r.text();
    try {
      return JSON.parse(raw);
    } catch (e) {
      return {
        success: false,
        error: 'Server returned non-JSON: ' + raw.slice(0, 200)
      };
    }
  } catch (e) {
    return {
      success: false,
      error: 'Network error: ' + e.message
    };
  }
}

/* ═══════════════════════════════════════════
RECEIPT PRINTER
Same high-quality receipt as the admin panel —
parents print directly to PDF/paper.
═══════════════════════════════════════════ */
async function printReceipt(paymentId, setReceiptLoading) {
  if (setReceiptLoading) setReceiptLoading(paymentId);
  const d = await apiFetch('payment_receipt', {
    payment_id: paymentId
  });
  if (setReceiptLoading) setReceiptLoading(null);
  if (!d || !d.success) {
    alert('Could not load receipt: ' + (d?.error || 'Unknown error'));
    return;
  }
  const {
    payment: p,
    linked_installments: linst,
    status: st,
    settings: s,
    generated_at
  } = d.data;
  const fL = fmtF;
  const dL = fmtD;
  const mD = m => {
    const mp = {
      Cash: 'Cash',
      'M-Pesa': 'M-Pesa',
      'Bank Transfer': 'Bank Transfer',
      Cheque: 'Cheque'
    };
    return mp[m] || m;
  };
  const dotBg = x => x.status === 'paid' ? '#10B981' : x.amount_due === 0 ? '#A78BFA' : x.status === 'partial' ? '#F59E0B' : '#E2E8F0';
  const dotFg = x => x.status === 'unpaid' && x.amount_due > 0 ? '#94A3B8' : '#fff';
  const totalFees = st ? st.grand_total + (st.transport_assigned ? st.transport_total : 0) : p.amount;
  const sfSlots = st && st.installments && st.installments['School Fees'] ? st.installments['School Fees'] : [];
  const tpSlots = st && st.installments && st.installments['Transport'] ? st.installments['Transport'] : [];
  const allocHtml = linst && linst.length > 0 ? `
<div class="sl">Fee Installments Updated by This Payment</div>
<table><thead><tr><th>Fee Type</th><th style="text-align:center">Inst.#</th><th>Status</th><th class="right">Amount Paid</th><th class="right">Total Due</th></tr></thead><tbody>
${linst.map(i => `<tr><td>${i.fee_type}</td><td style="text-align:center">${i.installment_no || '—'}</td>
<td><span style="font-weight:700;color:${i.status === 'paid' ? '#10B981' : i.status === 'partial' ? '#D97706' : '#94A3B8'}">${i.status.toUpperCase()}</span></td>
<td class="right" style="font-weight:700;color:#10B981">${fL(i.amount_paid)}</td>
<td class="right" style="color:#64748B">${fL(i.amount_due)}</td></tr>`).join('')}
</tbody></table>` : '';
  const sfDots = sfSlots.length > 0 ? `
<div class="sl">School Fees — Installment Progress (${sfSlots.filter(x => x.status === 'paid' || x.amount_due === 0).length}/${sfSlots.length} complete)</div>
<div class="idots">${sfSlots.map(x => `<div class="idot" title="Inst.${x.no}: ${x.status} — ${fL(x.amount_paid)}/${fL(x.amount_due)}" style="background:${dotBg(x)};color:${dotFg(x)}">${x.no}</div>`).join('')}</div>
<div style="font-size:9px;color:#94A3B8;margin-top:3px;"><Icon emoji="🟢" size={18} /> Paid &nbsp;🟡 Partial &nbsp;🟣 Discounted &nbsp;⚪ Unpaid</div>` : '';
  const tpDots = tpSlots.length > 0 ? `
<div class="sl" style="margin-top:10px;">Transport Installments (${tpSlots.filter(x => x.status === 'paid' || x.amount_due === 0).length}/${tpSlots.length} complete)</div>
<div class="idots">${tpSlots.map(x => `<div class="idot" title="Transport Inst.${x.no}: ${x.status}" style="background:${dotBg(x)};color:${dotFg(x)}">${x.no}</div>`).join('')}</div>` : '';
  const discBanner = st && st.discount_pct > 0 ? `
<div style="margin-top:8px;background:#EDE9FE;border:1px solid #C4B5FD;border-radius:5px;padding:6px 10px;font-size:11px;color:#5B21B6;">
  🏷️ <strong>${st.discount_pct}% School Fees discount</strong> is active for this student.
</div>` : '';
  const schBanner = st && st.scholarship_total > 0 ? `
<div style="margin-top:6px;background:#EDE9FE;border:1px solid #C4B5FD;border-radius:5px;padding:6px 10px;font-size:11px;color:#5B21B6;">
  🎓 <strong>${fL(st.scholarship_total)}</strong> covered by scholarship programme.
</div>` : '';
  const summaryHtml = st ? `
<div class="sl">Account Summary — ${st.academic_year}</div>
<div class="sg">
  <div class="sc" style="border-left:3px solid #475569">
    <div class="scl">Total Fees</div><div class="scv" style="color:#1E293B">${fL(totalFees)}</div>
  </div>
  <div class="sc" style="border-left:3px solid #10B981">
    <div class="scl">Paid to Date</div><div class="scv" style="color:#10B981">${fL(st.total_paid)}</div>
  </div>
  <div class="sc" style="border-left:3px solid ${st.balance_owed > 0 ? '#EF4444' : '#10B981'}">
    <div class="scl">${st.balance_owed > 0 ? 'Outstanding' : 'Cleared'}</div>
    <div class="scv" style="color:${st.balance_owed > 0 ? '#EF4444' : '#10B981'}">${fL(st.balance_owed)}</div>
  </div>
</div>
${sfDots}${tpDots}${discBanner}${schBanner}` : '';
  const w = window.open('', '_blank');
  w.document.write(`<!DOCTYPE html><html><head>
<meta charset="UTF-8"><title>Receipt ${p.receipt_number}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Times New Roman',serif;font-size:13px;color:#1a1a1a;background:#fff;}
.page{width:148mm;min-height:210mm;padding:14mm 16mm;margin:0 auto;}
@media print{.page{padding:10mm 14mm;}.np{display:none!important;}}
.rh{display:flex;align-items:center;justify-content:space-between;padding-bottom:10px;border-bottom:3px solid #1E3A8A;margin-bottom:8px;}
.lb{width:62px;height:62px;border:1px solid #CBD5E1;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:22px;background:#EFF6FF;flex-shrink:0;overflow:hidden;}
.lb img{width:100%;height:100%;object-fit:contain;}
.hc{text-align:center;flex:1;padding:0 12px;}
.sn{font-size:17px;font-weight:700;color:#1E3A8A;}
.rt{font-size:11px;color:#475569;margin-top:2px;}
.rtitle{font-size:12px;font-weight:700;color:#1E293B;margin-top:7px;text-transform:uppercase;letter-spacing:.6px;}
.rbar{background:#1E3A8A;color:#fff;padding:7px 14px;border-radius:4px;margin:10px 0;display:flex;justify-content:space-between;align-items:center;}
.rnum{font-size:15px;font-weight:700;letter-spacing:1.5px;font-family:monospace;}
.stb{padding:2px 9px;border-radius:4px;font-size:10px;font-weight:700;}
.stc{background:#D1FAE5;color:#065F46;}.stp{background:#FEF3C7;color:#92400E;}
.amt{background:#F0FDF4;border:2px solid #86EFAC;border-radius:8px;padding:13px 16px;text-align:center;margin:10px 0;}
.aml{font-size:10px;color:#4ADE80;font-weight:700;text-transform:uppercase;letter-spacing:.5px;}
.amv{font-size:28px;font-weight:700;color:#166534;}
.amm{font-size:12px;color:#166534;margin-top:3px;}
.tc{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin:10px 0;}
.inf{margin-bottom:6px;}
.il{font-size:9px;color:#94A3B8;font-weight:700;text-transform:uppercase;letter-spacing:.4px;}
.iv{font-size:12px;color:#1E293B;font-weight:600;margin-top:1px;}
.sl{font-size:9px;font-weight:700;color:#94A3B8;text-transform:uppercase;letter-spacing:.6px;border-bottom:1px solid #E2E8F0;padding-bottom:3px;margin:12px 0 6px;}
table{width:100%;border-collapse:collapse;font-size:11px;margin:6px 0;}
th{background:#1E3A8A;color:#fff;padding:4px 8px;text-align:left;font-size:10px;}
td{padding:5px 8px;border-bottom:1px solid #E2E8F0;}
tr:nth-child(even) td{background:#F8FAFC;}
.right{text-align:right;}
.sg{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin:6px 0;}
.sc{border:1px solid #E2E8F0;border-radius:5px;padding:7px 9px;text-align:center;}
.scl{font-size:9px;color:#94A3B8;text-transform:uppercase;font-weight:700;letter-spacing:.3px;}
.scv{font-size:13px;font-weight:700;margin-top:2px;}
.idots{display:flex;gap:4px;flex-wrap:wrap;margin:5px 0;}
.idot{width:22px;height:22px;border-radius:50%;font-size:10px;font-weight:700;display:flex;align-items:center;justify-content:center;border:1px solid rgba(0,0,0,.08);}
.sig{margin-top:22px;padding-top:10px;border-top:2px solid #E2E8F0;display:flex;justify-content:space-between;font-size:11px;color:#475569;}
.sb{text-align:center;width:130px;}
.sbl{border-top:1px solid #1a1a1a;margin:26px auto 3px;width:110px;}
.pb{background:#1E3A8A;color:#fff;padding:8px 16px;text-align:center;position:sticky;top:0;z-index:100;}
.pb button{background:#fff;color:#1E3A8A;border:none;padding:5px 14px;border-radius:4px;font-size:13px;font-weight:700;cursor:pointer;margin:0 4px;}
</style></head><body>
<div class="pb np"><strong>Fee Payment Receipt</strong>
<button onclick="window.print()"><Icon emoji="🖨️" size={18} /> Print / PDF</button>
<button onclick="window.close()"><Icon emoji="✕" size={18} /> Close</button></div>
<div class="page">
<div class="rh">
<div class="lb"><img src="/nsms/public/uploads/logos/Tanzania.png" onerror="this.parentElement.innerHTML='🏫'"/></div>
<div class="hc">
<div class="sn">${s.school_name || 'Nursery School'}</div>
<div class="rt">United Republic of Tanzania</div>
<div class="rtitle">Official Fee Payment Receipt</div>
</div>
<div class="lb" style="background:#fff;"><img src="/nsms/public/uploads/logos/logo.png" onerror="this.parentElement.innerHTML='🇹🇿'"/></div>
</div>
<div class="rbar">
<div>
  <div style="font-size:9px;opacity:.65;letter-spacing:.6px;">RECEIPT NUMBER</div>
  <div class="rnum">${p.receipt_number}</div>
</div>
<div style="text-align:center">
  <div style="font-size:9px;opacity:.65;letter-spacing:.6px;">PAYMENT DATE</div>
  <div style="font-weight:600;font-size:12px;">${dL(p.payment_date)}</div>
</div>
<div style="text-align:right">
  <span class="stb ${p.status === 'confirmed' ? 'stc' : 'stp'}">${(p.status || '').toUpperCase()}</span>
</div>
</div>
<div class="amt">
<div class="aml">Amount Received</div>
<div class="amv">${fL(p.amount)}</div>
<div class="amm">via ${mD(p.payment_method)}${p.reference_number ? ' · Ref: ' + p.reference_number : ''}</div>
</div>
<div class="tc">
<div>
<div class="sl">Student Details</div>
<div class="inf"><div class="il">Student Name</div><div class="iv">${p.student_name}</div></div>
<div class="inf"><div class="il">Class</div><div class="iv">${p.class_name}</div></div>
<div class="inf"><div class="il">Parent / Guardian</div><div class="iv">${p.parent_name || '—'}</div></div>
${p.parent_relationship ? `<div class="inf"><div class="il">Relationship</div><div class="iv">${p.parent_relationship}</div></div>` : ''}
</div>
<div>
<div class="sl">Payment Details</div>
<div class="inf"><div class="il">Payment Method</div><div class="iv">${mD(p.payment_method)}</div></div>
<div class="inf"><div class="il">Date Paid</div><div class="iv">${dL(p.payment_date)}</div></div>
${p.reference_number ? `<div class="inf"><div class="il">Reference / Control No.</div><div class="iv" style="font-family:monospace;font-size:12px;">${p.reference_number}</div></div>` : ''}
<div class="inf"><div class="il">Academic Year</div><div class="iv">${st ? st.academic_year : '—'}</div></div>
<div class="inf"><div class="il">Processed By</div><div class="iv">${p.recorded_by_name || 'School Finance Office'}</div></div>
</div>
</div>
${allocHtml}
${summaryHtml}
<div class="sig">
<div class="sb"><div class="sbl"></div><div><b>Finance Officer</b></div></div>
<div style="text-align:center;font-size:9px;color:#94A3B8;align-self:flex-end;">
  Generated ${new Date((generated_at || '').replace(' ', 'T')).toLocaleString('en-GB')}<br/>NSMS — ${p.receipt_number}
</div>
<div class="sb"><div class="sbl"></div><div><b>Parent / Guardian</b></div></div>
</div>
</div></body></html>`);
  w.document.close();
}

/* ═══════════════════════════════════════════
INSTALLMENT DOTS COMPONENT
═══════════════════════════════════════════ */
function InstDots({
  slots,
  label
}) {
  if (!slots || !slots.length) return null;
  const paid = slots.filter(s => s.status === 'paid' || s.amount_due === 0).length;
  return /*#__PURE__*/React.createElement("div", {
    className: "inst-wrap"
  }, label && /*#__PURE__*/React.createElement("div", {
    className: "inst-label"
  }, label, " \u2014 ", paid, "/", slots.length, " installments complete"), /*#__PURE__*/React.createElement("div", {
    className: "idots"
  }, slots.map(s => {
    const isPaid = s.status === 'paid';
    const isPartial = s.status === 'partial';
    const isZero = s.amount_due === 0;
    const bg = isPaid ? '#10B981' : isZero ? '#A78BFA' : isPartial ? '#F59E0B' : '#E2E8F0';
    const color = s.status === 'unpaid' && s.amount_due > 0 ? '#94A3B8' : '#fff';
    const border = isPaid ? 'transparent' : isZero ? 'transparent' : 'var(--border)';
    return /*#__PURE__*/React.createElement("div", {
      key: s.no,
      className: "idot",
      title: `Installment ${s.no}: ${s.status} — Paid ${fmtF(s.amount_paid)} of ${fmtF(s.amount_due)}${s.paid_date ? ' on ' + fmtD(s.paid_date) : ''}`,
      style: {
        background: bg,
        color,
        borderColor: border
      }
    }, s.no);
  })), /*#__PURE__*/React.createElement("div", {
    className: "idot-legend"
  }, /*#__PURE__*/React.createElement("span", {
    className: "idot-leg-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "idot-swatch",
    style: {
      background: '#10B981'
    }
  }), "Paid"), /*#__PURE__*/React.createElement("span", {
    className: "idot-leg-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "idot-swatch",
    style: {
      background: '#F59E0B'
    }
  }), "Partial"), /*#__PURE__*/React.createElement("span", {
    className: "idot-leg-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "idot-swatch",
    style: {
      background: '#A78BFA'
    }
  }), "Discounted"), /*#__PURE__*/React.createElement("span", {
    className: "idot-leg-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "idot-swatch",
    style: {
      background: '#E2E8F0'
    }
  }), "Unpaid")));
}

/* ═══════════════════════════════════════════
OVERVIEW CARDS
═══════════════════════════════════════════ */
function OverviewCards({
  st
}) {
  if (!st) return null;
  const prog = pct(st.total_paid, st.grand_total);
  const balColor = st.balance_owed === 0 ? 'success' : st.balance_owed < st.grand_total * 0.3 ? 'amber' : 'amber';
  return /*#__PURE__*/React.createElement("div", {
    className: "ov-cards"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc blue"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "ovc-label"
  }, "Total Term Fee"), /*#__PURE__*/React.createElement("div", {
    className: "ovc-value"
  }, fmtF(st.grand_total)), /*#__PURE__*/React.createElement("div", {
    className: "ovc-sub"
  }, "Academic Year ", st.academic_year), st.discount_pct > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      background: 'rgba(255,255,255,.2)',
      borderRadius: 6,
      padding: '3px 8px',
      fontSize: 11,
      fontWeight: 700,
      display: 'inline-block'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFF7\uFE0F",
    size: 18
  }), " ", st.discount_pct, "% discount applied")), /*#__PURE__*/React.createElement("div", {
    className: "ovc green"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "ovc-label"
  }, "Amount Paid"), /*#__PURE__*/React.createElement("div", {
    className: "ovc-value"
  }, fmtF(st.total_paid)), /*#__PURE__*/React.createElement("div", {
    className: "ovc-sub"
  }, prog, "% of total fees"), /*#__PURE__*/React.createElement("div", {
    className: "ovc-progress"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc-progress-fill",
    style: {
      width: prog + '%'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: `ovc ${st.balance_owed === 0 ? 'success' : balColor}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc-icon"
  }, st.balance_owed === 0 ? typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: null,
    size: 16
  }) : null : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '⏳',
    size: 16
  }) : null), /*#__PURE__*/React.createElement("div", {
    className: "ovc-label"
  }, "Balance Remaining"), /*#__PURE__*/React.createElement("div", {
    className: "ovc-value"
  }, fmtF(st.balance_owed)), /*#__PURE__*/React.createElement("div", {
    className: "ovc-sub"
  }, st.balance_owed === 0 ? 'All fees cleared ✓' : st.next_installment ? `Next: Installment ${st.next_installment.no} — ${fmtF(st.next_installment.amount_due)}` : 'Outstanding balance')));
}

/* ═══════════════════════════════════════════
SUMMARY TAB
═══════════════════════════════════════════ */
function SummaryTab({
  st,
  feeStr
}) {
  const [showPmDetails, setShowPmDetails] = useState(null);
  if (!st) return /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading\u2026"));
  if (st.no_fees_configured) {
    return /*#__PURE__*/React.createElement("div", {
      className: "no-fees"
    }, /*#__PURE__*/React.createElement("div", {
      className: "no-fees-icon"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCB",
      size: 18
    })), /*#__PURE__*/React.createElement("div", {
      className: "no-fees-title"
    }, "No Fees Configured"), /*#__PURE__*/React.createElement("div", {
      className: "no-fees-sub"
    }, "Fee structure for ", st.academic_year, " has not been set up yet. Please contact the school office."));
  }
  const sfSlots = st.installments && st.installments['School Fees'] ? st.installments['School Fees'] : [];
  const tpSlots = st.installments && st.installments['Transport'] ? st.installments['Transport'] : [];
  const oneTimeFees = Object.entries(st.one_time_fees || {});
  const totalPaid = st.total_paid || 0;

  /* Figure out which one-time fees are covered sequentially */
  let budgetLeft = totalPaid;
  const oneTimeFeeStatus = oneTimeFees.map(([ft, amt]) => {
    const covered = Math.min(amt, Math.max(0, budgetLeft));
    budgetLeft = Math.max(0, budgetLeft - amt);
    const isPaid = covered >= amt;
    const isPartial = covered > 0 && !isPaid;
    return {
      ft,
      amt,
      covered,
      isPaid,
      isPartial
    };
  });
  return /*#__PURE__*/React.createElement("div", null, st.fully_paid && /*#__PURE__*/React.createElement("div", {
    className: "paid-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "paid-banner-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF89",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "paid-banner-title"
  }, "All Fees Paid for ", st.academic_year), /*#__PURE__*/React.createElement("div", {
    className: "paid-banner-sub"
  }, "Your child's account is fully cleared. Thank you!"))), st.scholarship_total > 0 && /*#__PURE__*/React.createElement("div", {
    className: "info-banner",
    style: {
      marginBottom: 16,
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, "\uD83C\uDF93 ", /*#__PURE__*/React.createElement("strong", null, fmtF(st.scholarship_total)), ' ', "has been covered by scholarship programme for", ' ', st.academic_year, "."), /*#__PURE__*/React.createElement("div", {
    className: "twocol"
  }, /*#__PURE__*/React.createElement("div", null, oneTimeFees.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ct"
  }, "One-Time Fees"), /*#__PURE__*/React.createElement("div", {
    className: "ct-sub"
  }, "Registration, stationery and other charges")), /*#__PURE__*/React.createElement("span", {
    className: "bx xb",
    style: {
      fontSize: 11
    }
  }, fmtF(st.one_time_total), " total")), oneTimeFeeStatus.map(({
    ft,
    amt,
    covered,
    isPaid,
    isPartial
  }) => /*#__PURE__*/React.createElement("div", {
    key: ft,
    className: "fee-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fee-icon",
    style: {
      background: isPaid ? '#D1FAE5' : isPartial ? '#FEF3C7' : '#F1F5F9'
    }
  }, feeIcon(ft)), /*#__PURE__*/React.createElement("div", {
    className: "fee-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fee-name"
  }, ft), isPartial && /*#__PURE__*/React.createElement("div", {
    className: "fee-meta"
  }, "Partially paid:", ' ', fmtF(covered), ' ', "of ", fmtF(amt)), isPaid && /*#__PURE__*/React.createElement("div", {
    className: "fee-meta",
    style: {
      color: '#10B981'
    }
  }, "Fully paid \u2713"), !isPaid && !isPartial && /*#__PURE__*/React.createElement("div", {
    className: "fee-meta",
    style: {
      color: '#EF4444'
    }
  }, "Unpaid")), /*#__PURE__*/React.createElement("div", {
    className: "fee-bar-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fee-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fee-bar-fill",
    style: {
      width: pct(covered, amt) + '%',
      background: isPaid ? '#10B981' : isPartial ? '#F59E0B' : '#E2E8F0'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "fee-amt"
  }, fmtF(amt)), /*#__PURE__*/React.createElement("div", {
    className: "fee-status"
  }, isPaid ? /*#__PURE__*/React.createElement("span", {
    className: "bx xg",
    style: {
      fontSize: 11
    }
  }, "Paid") : isPartial ? /*#__PURE__*/React.createElement("span", {
    className: "bx xy",
    style: {
      fontSize: 11
    }
  }, "Partial") : /*#__PURE__*/React.createElement("span", {
    className: "bx xr",
    style: {
      fontSize: 11
    }
  }, "Unpaid"))))), sfSlots.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ct"
  }, "\uD83D\uDCDA School Fees Installments"), /*#__PURE__*/React.createElement("div", {
    className: "ct-sub"
  }, st.install_paid_count || 0, ' ', "of", ' ', st.install_total_count || sfSlots.length, ' ', "installments complete")), /*#__PURE__*/React.createElement("span", {
    className: "bx xb",
    style: {
      fontSize: 11
    }
  }, fmtF(st.install_total), " total")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginBottom: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#F0FDF4',
      border: '1px solid #86EFAC',
      borderRadius: 8,
      padding: '8px 14px',
      flex: 1,
      minWidth: 100,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#065F46',
      fontWeight: 700,
      marginBottom: 2
    }
  }, "PAID"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 800,
      color: '#10B981'
    }
  }, fmtF(st.install_paid))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FFF7ED',
      border: '1px solid #FDE68A',
      borderRadius: 8,
      padding: '8px 14px',
      flex: 1,
      minWidth: 100,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#92400E',
      fontWeight: 700,
      marginBottom: 2
    }
  }, "REMAINING"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 800,
      color: '#D97706'
    }
  }, fmtF(st.install_total - st.install_paid))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#F8FAFC',
      border: '1px solid #E2E8F0',
      borderRadius: 8,
      padding: '8px 14px',
      flex: 1,
      minWidth: 100,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#475569',
      fontWeight: 700,
      marginBottom: 2
    }
  }, "PER INSTALL."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 800,
      color: '#1E293B'
    }
  }, sfSlots.length > 0 ? fmtF(sfSlots[0].amount_due) : '—'))), /*#__PURE__*/React.createElement(InstDots, {
    slots: sfSlots,
    label: "Monthly Progress"
  }), st.next_installment && !st.mandatory_complete && /*#__PURE__*/React.createElement("div", {
    className: "warn-banner",
    style: {
      marginTop: 14,
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, "\u23F0", ' ', /*#__PURE__*/React.createElement("strong", null, "Next payment:"), "\xA0Installment #", st.next_installment.no, " \u2014", ' ', fmtF(st.next_installment.amount_due), ". Use M-Pesa or Bank Transfer below.")), st.transport_assigned && tpSlots.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ct"
  }, "\uD83D\uDE8C Transport Fees"), /*#__PURE__*/React.createElement("div", {
    className: "ct-sub"
  }, "School bus service \u2014 10 monthly installments")), /*#__PURE__*/React.createElement("span", {
    className: `bx ${st.transport_complete ? 'xg' : 'xy'}`,
    style: {
      fontSize: 11
    }
  }, st.transport_complete ? 'Fully Paid' : 'In Progress')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginBottom: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 90,
      background: '#EFF6FF',
      border: '1px solid #BFDBFE',
      borderRadius: 8,
      padding: '8px 12px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#1D4ED8',
      fontWeight: 700
    }
  }, "TOTAL"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 800,
      color: '#1E40AF'
    }
  }, fmtF(st.transport_total))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 90,
      background: '#F0FDF4',
      border: '1px solid #86EFAC',
      borderRadius: 8,
      padding: '8px 12px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#065F46',
      fontWeight: 700
    }
  }, "PAID"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 800,
      color: '#10B981'
    }
  }, fmtF(st.transport_paid))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 90,
      background: '#FFF7ED',
      border: '1px solid #FDE68A',
      borderRadius: 8,
      padding: '8px 12px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#92400E',
      fontWeight: 700
    }
  }, "REMAINING"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 800,
      color: '#D97706'
    }
  }, fmtF(st.transport_total - st.transport_paid)))), /*#__PURE__*/React.createElement(InstDots, {
    slots: tpSlots,
    label: "Transport Installment Progress"
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct",
    style: {
      marginBottom: 14
    }
  }, "Account Summary"), [['Academic Year', st.academic_year, '#2563EB'], ['Total Fees', fmtF(st.grand_total), '#1E293B'], ['Amount Paid', fmtF(st.total_paid), '#10B981'], ['Balance Owed', fmtF(st.balance_owed), st.balance_owed > 0 ? '#EF4444' : '#10B981'], ...(st.transport_assigned ? [['Transport (optional)', fmtF(st.transport_total), '#6366F1']] : []), ...(st.discount_pct > 0 ? [[`Discount Applied`, st.discount_pct + '%', '#5B21B6']] : []), ...(st.scholarship_total > 0 ? [['Scholarship Covered', fmtF(st.scholarship_total), '#5B21B6']] : [])].map(([l, v, c]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      padding: '7px 0',
      borderBottom: '1px solid #F8FAFC',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: '#64748B'
    }
  }, l), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: c
    }
  }, v))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      height: 8,
      background: '#E2E8F0',
      borderRadius: 4,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      borderRadius: 4,
      background: 'linear-gradient(90deg,#10B981,#059669)',
      width: pct(st.total_paid, st.grand_total) + '%',
      transition: 'width .5s ease'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      fontSize: 11,
      color: '#94A3B8',
      marginTop: 4
    }
  }, pct(st.total_paid, st.grand_total), "% paid")), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 14,
      flexWrap: 'wrap',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct"
  }, "How to Pay"), /*#__PURE__*/React.createElement("button", {
    className: "btn bb no-print",
    style: {
      fontSize: 12,
      padding: '7px 12px'
    },
    onClick: () => window.location.href = '/nsms/public/parent/pay-fees.html'
  }, "\uD83D\uDCB3 Pay Online Now")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#64748B',
      marginBottom: 12,
      lineHeight: 1.6
    }
  }, "Pay instantly via mobile money or card using the button above, or follow the manual instructions below."), /*#__PURE__*/React.createElement("div", {
    className: "pm-grid"
  }, [{
    id: 'mpesa',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCF1",
      size: 18
    }),
    bg: '#D1FAE5',
    name: 'M-Pesa',
    desc: 'Pay via mobile money',
    details: [['Business No.', '123456'], ['Account', 'NSMS-FEES'], ['Paybill', 'Available 24/7']]
  }, {
    id: 'bank',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDFE6",
      size: 18
    }),
    bg: '#DBEAFE',
    name: 'Bank Transfer',
    desc: 'Pay via bank',
    details: [['Bank', 'CRDB Bank'], ['Account No.', '0150XXXXXXXX'], ['Branch', 'Main Branch']]
  }].map(pm => /*#__PURE__*/React.createElement("div", {
    key: pm.id
  }, /*#__PURE__*/React.createElement("div", {
    className: "pm-card",
    onClick: () => setShowPmDetails(showPmDetails === pm.id ? null : pm.id)
  }, /*#__PURE__*/React.createElement("div", {
    className: "pm-icon-wrap",
    style: {
      background: pm.bg
    }
  }, pm.icon), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "pm-name"
  }, pm.name), /*#__PURE__*/React.createElement("div", {
    className: "pm-desc"
  }, pm.desc)), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      color: '#94A3B8',
      fontSize: 18
    }
  }, showPmDetails === pm.id ? '▲' : '▼')), showPmDetails === pm.id && /*#__PURE__*/React.createElement("div", {
    className: "pm-details"
  }, pm.details.map(([l, v]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    className: "pm-details-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pm-details-label"
  }, l), /*#__PURE__*/React.createElement("span", {
    className: "pm-details-val"
  }, v))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      fontSize: 12,
      color: '#94A3B8',
      lineHeight: 1.6
    }
  }, "After payment, contact the school finance office with your receipt to have it recorded. Keep all receipts safe.")), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      background: '#F8FAFC',
      border: '1px solid #E2E8F0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct",
    style: {
      marginBottom: 10,
      fontSize: 14
    }
  }, "\uD83D\uDCDE Finance Office"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#64748B',
      lineHeight: 1.7
    }
  }, "For payment queries or to update records, contact the school finance office.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("strong", {
    style: {
      color: '#1E293B'
    }
  }, "Mon\u2013Fri, 8:00 AM \u2013 4:00 PM"))))));
}

/* ═══════════════════════════════════════════
PAYMENTS TAB
═══════════════════════════════════════════ */
function PaymentsTab({
  studentId
}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [receiptLoading, setReceiptLoading] = useState(null);
  const [expandedRow, setExpandedRow] = useState(null);
  useEffect(() => {
    if (!studentId) return;
    setLoading(true);
    setErr('');
    apiFetch('child_payments', {
      student_id: studentId,
      limit: 100
    }).then(d => {
      if (d && d.success) setData(d.data);else setErr(d?.error || 'Failed to load payments');
      setLoading(false);
    });
  }, [studentId]);
  if (loading) return /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading payment history\u2026"));
  if (err) return /*#__PURE__*/React.createElement("div", {
    className: "err-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " Error"), /*#__PURE__*/React.createElement("div", {
    className: "err-msg"
  }, err));
  const payments = data?.payments || [];
  if (!payments.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "card"
    }, /*#__PURE__*/React.createElement("div", {
      className: "empty"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 36,
        marginBottom: 12
      }
    }, "\uD83E\uDDFE"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 600,
        color: '#64748B',
        marginBottom: 6
      }
    }, "No Payments Yet"), /*#__PURE__*/React.createElement("div", null, "No payment records found for this student.")));
  }
  const total = data?.total || 0;
  const confirmed = payments.filter(p => p.status === 'confirmed');
  const totalAmount = confirmed.reduce((s, p) => s + p.amount, 0);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginBottom: 18,
      flexWrap: 'wrap'
    }
  }, [['Total Payments', payments.length, '#475569', /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  })], ['Confirmed', confirmed.length, '#10B981', /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })], ['Total Received', fmtF(totalAmount), '#2563EB', /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB0",
    size: 18
  })]].map(([l, v, c, ic]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      background: '#fff',
      border: '1px solid #E2E8F0',
      borderRadius: 10,
      padding: '12px 18px',
      flex: '1 1 140px',
      minWidth: 140
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      marginBottom: 4
    }
  }, ic), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 800,
      color: c
    }
  }, v), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#64748B',
      marginTop: 2
    }
  }, l)))), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ct"
  }, "Payment History"), /*#__PURE__*/React.createElement("div", {
    className: "ct-sub"
  }, total, " total record", total !== 1 ? 's' : '')), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#94A3B8'
    }
  }, "Click a row to see allocation details")), /*#__PURE__*/React.createElement("div", {
    className: "tw"
  }, /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Date"), /*#__PURE__*/React.createElement("th", null, "Amount"), /*#__PURE__*/React.createElement("th", null, "Method"), /*#__PURE__*/React.createElement("th", null, "Receipt #"), /*#__PURE__*/React.createElement("th", null, "Reference"), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Actions"))), /*#__PURE__*/React.createElement("tbody", null, payments.map(pay => /*#__PURE__*/React.createElement(React.Fragment, {
    key: pay.id
  }, /*#__PURE__*/React.createElement("tr", {
    style: {
      cursor: 'pointer'
    },
    onClick: () => setExpandedRow(expandedRow === pay.id ? null : pay.id)
  }, /*#__PURE__*/React.createElement("td", null, fmtD(pay.payment_date)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("strong", null, fmtF(pay.amount))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: `bx ${mBadge(pay.payment_method)}`
  }, mDisp(pay.payment_method))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("code", {
    style: {
      fontSize: 12,
      background: '#F1F5F9',
      padding: '2px 6px',
      borderRadius: 4
    }
  }, pay.receipt_number || '—')), /*#__PURE__*/React.createElement("td", {
    style: {
      color: '#64748B',
      fontSize: 12
    }
  }, pay.reference_number || '—'), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: `bx ${pay.status === 'confirmed' ? 'xg' : 'xy'}`
  }, pay.status === 'confirmed' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 16
  }), "Confirmed") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F3",
    size: 16
  }), "Pending"))), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right'
    }
  }, pay.status === 'confirmed' && /*#__PURE__*/React.createElement("button", {
    className: "btn bo bsm no-print",
    disabled: receiptLoading === pay.id,
    onClick: e => {
      e.stopPropagation();
      printReceipt(pay.id, setReceiptLoading);
    }
  }, receiptLoading === pay.id ? '…' : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDDA8\uFE0F",
    size: 16
  }), "Receipt")))), expandedRow === pay.id && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    colSpan: 7,
    style: {
      background: '#F8FAFC',
      padding: '12px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: '#64748B',
      marginBottom: 6,
      textTransform: 'uppercase',
      letterSpacing: '.4px'
    }
  }, "Payment Allocation"), pay.allocations && pay.allocations.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, pay.allocations.map((a, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: '#fff',
      border: '1px solid #E2E8F0',
      borderRadius: 7,
      padding: '6px 10px',
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: '#1E293B'
    }
  }, a.fee_type), a.installment_no && /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#94A3B8'
    }
  }, ' ', "\xB7 Inst.", a.installment_no), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 6,
      fontWeight: 700,
      color: '#10B981'
    }
  }, fmtF(a.amount_paid))))) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: '#94A3B8'
    }
  }, "No installment details available for this payment."), pay.recorded_by && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      fontSize: 12,
      color: '#94A3B8'
    }
  }, "Recorded by:", ' ', pay.recorded_by)))))))), total > payments.length && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '14px 0 0',
      fontSize: 13,
      color: '#94A3B8'
    }
  }, "Showing ", payments.length, " of ", total, ' ', "payments")));
}

/* ═══════════════════════════════════════════
FEE STRUCTURE TAB
═══════════════════════════════════════════ */
function FeeStructureTab({
  studentId,
  st
}) {
  const [fees, setFees] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  useEffect(() => {
    if (!studentId) return;
    setLoading(true);
    setErr('');
    apiFetch('fee_structure', {
      student_id: studentId
    }).then(d => {
      if (d && d.success) setFees(d.data);else setErr(d?.error || 'Failed to load fee structure');
      setLoading(false);
    });
  }, [studentId]);
  if (loading) return /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading fee structure\u2026"));
  if (err) return /*#__PURE__*/React.createElement("div", {
    className: "err-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " Error"), /*#__PURE__*/React.createElement("div", {
    className: "err-msg"
  }, err));
  const list = fees?.fees || [];
  if (!list.length) return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, "No fee structure configured for this class yet."));
  const grandTotal = list.filter(f => !f.is_optional).reduce((s, f) => s + f.amount, 0);
  const optionalTotal = list.filter(f => f.is_optional).reduce((s, f) => s + f.amount, 0);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "twocol"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ct"
  }, "Fee Structure \u2014", ' ', fees?.academic_year), /*#__PURE__*/React.createElement("div", {
    className: "ct-sub"
  }, "All fees applicable to your child's class"))), /*#__PURE__*/React.createElement("div", {
    className: "tw"
  }, /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Fee Type"), /*#__PURE__*/React.createElement("th", null, "Frequency"), /*#__PURE__*/React.createElement("th", null, "Installments"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Annual Amount"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Per Installment"), /*#__PURE__*/React.createElement("th", null, "Type"))), /*#__PURE__*/React.createElement("tbody", null, list.map(f => /*#__PURE__*/React.createElement("tr", {
    key: f.fee_type
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16
    }
  }, feeIcon(f.fee_type)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600
    }
  }, f.fee_type), f.description && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#94A3B8',
      marginTop: 1
    }
  }, f.description)))), /*#__PURE__*/React.createElement("td", {
    style: {
      color: '#64748B'
    }
  }, f.installable ? 'Monthly (10 months)' : 'One-Time'), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center',
      color: '#64748B'
    }
  }, f.installments), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      fontWeight: 700
    }
  }, fmtF(f.amount)), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      color: '#64748B'
    }
  }, f.installable ? fmtF(f.amount / f.installments) : '—'), /*#__PURE__*/React.createElement("td", null, f.is_optional ? /*#__PURE__*/React.createElement("span", {
    className: "bx xgr",
    style: {
      fontSize: 11
    }
  }, "Optional") : /*#__PURE__*/React.createElement("span", {
    className: "bx xb",
    style: {
      fontSize: 11
    }
  }, "Required")))), /*#__PURE__*/React.createElement("tr", {
    style: {
      background: '#F8FAFC',
      fontWeight: 700
    }
  }, /*#__PURE__*/React.createElement("td", {
    colSpan: 3
  }, "Mandatory Fees Total"), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      color: '#1E293B'
    }
  }, fmtF(grandTotal)), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null)), optionalTotal > 0 && /*#__PURE__*/React.createElement("tr", {
    style: {
      background: '#F8FAFC'
    }
  }, /*#__PURE__*/React.createElement("td", {
    colSpan: 3,
    style: {
      color: '#64748B'
    }
  }, "Optional Fees Total"), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      color: '#64748B'
    }
  }, fmtF(optionalTotal)), /*#__PURE__*/React.createElement("td", null), /*#__PURE__*/React.createElement("td", null))))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct",
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  }), " Fee Notes"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#64748B',
      lineHeight: 1.8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10,
      paddingBottom: 10,
      borderBottom: '1px solid #F1F5F9'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: '#1E293B'
    }
  }, "One-Time Fees"), /*#__PURE__*/React.createElement("br", null), "Paid once per academic year \u2014 Registration, Stationery, Meals, etc."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10,
      paddingBottom: 10,
      borderBottom: '1px solid #F1F5F9'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: '#1E293B'
    }
  }, "Installment Fees"), /*#__PURE__*/React.createElement("br", null), "School Fees and Transport are split into 10 monthly installments. Pay at least 10% of one installment per payment."), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: '#1E293B'
    }
  }, "Discounts"), /*#__PURE__*/React.createElement("br", null), st && st.discount_pct > 0 ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#5B21B6'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " A", ' ', /*#__PURE__*/React.createElement("strong", null, st.discount_pct, "%"), ' ', "discount is currently active on your child's School Fees.") : 'Contact the school office to inquire about scholarship or discount programmes.'))), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      background: '#EFF6FF',
      border: '1px solid #BFDBFE'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ct",
    style: {
      marginBottom: 10,
      fontSize: 14,
      color: '#1D4ED8'
    }
  }, "\u2139\uFE0F About Your Fees"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#1E40AF',
      lineHeight: 1.7
    }
  }, "Academic Year:", ' ', /*#__PURE__*/React.createElement("strong", null, fees?.academic_year), /*#__PURE__*/React.createElement("br", null), "Class Total (mandatory):", ' ', /*#__PURE__*/React.createElement("strong", null, fmtF(grandTotal)), /*#__PURE__*/React.createElement("br", null), st && st.balance_owed === 0 ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#065F46'
    }
  }, "\u2705 Your account is fully cleared.") : st ? /*#__PURE__*/React.createElement("span", null, "Outstanding:", ' ', /*#__PURE__*/React.createElement("strong", {
    style: {
      color: '#D97706'
    }
  }, fmtF(st.balance_owed))) : null)))));
}

/* ═══════════════════════════════════════════
MAIN PAGE
═══════════════════════════════════════════ */
function ParentFinancePage() {
  const [children, setChildren] = useState([]);
  const [selId, setSelId] = useState(null);
  const [childrenLoading, setChildrenLoading] = useState(true);
  const [childrenErr, setChildrenErr] = useState('');
  const [status, setStatus] = useState(null);
  const [statusLoading, setStatusLoading] = useState(false);
  const [statusErr, setStatusErr] = useState('');
  const [tab, setTab] = useState('summary');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [unreadMsg, setUnreadMsg] = useState(0);

  // Load children on mount
  useEffect(() => {
    setChildrenLoading(true);
    setChildrenErr('');
    Promise.all([apiFetch('my_children'), fetch('/nsms/api/parent-panel.php?action=notifications_count', {
      credentials: 'include'
    }).then(r => r.ok ? r.json() : null).catch(() => null)]).then(([cd, nd]) => {
      if (cd && cd.success) {
        setChildren(cd.data || []);
        if (cd.data && cd.data.length > 0) setSelId(cd.data[0].id);
      } else {
        setChildrenErr(cd?.error || 'Failed to load children');
      }
      if (nd && nd.success && nd.data) setUnreadMsg(nd.data.msgs || 0);
      setChildrenLoading(false);
    });
  }, []);

  // Load payment status when selected child changes
  useEffect(() => {
    if (!selId) return;
    setStatus(null);
    setStatusErr('');
    setStatusLoading(true);
    apiFetch('child_payment_status', {
      student_id: selId
    }).then(d => {
      if (d && d.success) setStatus(d.data);else setStatusErr(d?.error || 'Failed to load payment status');
      setStatusLoading(false);
    });
  }, [selId]);
  const selChild = children.find(c => c.id === selId) || null;
  const TABS = [['summary', /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 16
  }), "Summary")], ['payments', /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83E\uDDFE",
    size: 16
  }), "Payments")], ['fees', /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFF7\uFE0F",
    size: 16
  }), "Fee Structure")]];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ParentNavbar, {
    activePage: "fee_payments",
    sidebarOpen: sidebarOpen,
    setSidebar: setSidebarOpen,
    unreadMsg: unreadMsg,
    children: children,
    selectedChild: selChild,
    setSelectedChild: c => {
      setSelId(c.id);
      setTab('summary');
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(ParentSidebar, {
    activePage: "fee_payments",
    sidebarOpen: sidebarOpen,
    unreadMsg: unreadMsg
  }), /*#__PURE__*/React.createElement("div", {
    className: `main-area ${sidebarOpen ? '' : 'collapsed'}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, childrenLoading ? /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading your account\u2026")) : childrenErr ? /*#__PURE__*/React.createElement("div", {
    className: "err-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-title"
  }, "\u26A0\uFE0F Could not load account"), /*#__PURE__*/React.createElement("div", {
    className: "err-msg"
  }, childrenErr)) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "ph"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", null, "Fee Payments", selChild ? ` — ${selChild.student_name}` : ''), /*#__PURE__*/React.createElement("p", {
    className: "ph-sub"
  }, "View your child's fee payment history and account status"), status && /*#__PURE__*/React.createElement("div", {
    className: "ph-badge"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  }), ' ', status.academic_year)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bb no-print",
    style: {
      fontSize: 14,
      padding: '10px 18px'
    },
    onClick: () => window.location.href = '/nsms/public/parent/pay-fees.html'
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB3",
    size: 18
  }), " Pay Online Now"), selChild && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "bx",
    style: {
      background: selChild.class_color || '#DBEAFE',
      color: '#1E293B',
      fontSize: 13,
      fontWeight: 700,
      padding: '6px 12px',
      borderRadius: 8
    }
  }, selChild.class_name), status && status.fully_paid && /*#__PURE__*/React.createElement("span", {
    className: "bx xg",
    style: {
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " Fully Paid")))), selChild && selChild.status === 'graduated' && /*#__PURE__*/React.createElement("div", {
    className: "grad-notice"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), ' ', /*#__PURE__*/React.createElement("b", null, selChild.student_name), ' ', "has graduated. Their fee history and any remaining balance are still available below."), children.length > 1 && /*#__PURE__*/React.createElement("div", {
    className: "ssel no-print"
  }, children.map(c => /*#__PURE__*/React.createElement("button", {
    key: c.id,
    className: `ssel-btn${selId === c.id ? ' active' : ''}`,
    onClick: () => {
      setSelId(c.id);
      setTab('summary');
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ssel-dot",
    style: {
      background: c.class_color || '#BFDBFE'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", null, c.student_name, c.status === 'graduated' && /*#__PURE__*/React.createElement("span", {
    className: "grad-tag"
  }, ' ', /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), "Graduated")), /*#__PURE__*/React.createElement("div", {
    className: "ssel-class"
  }, c.class_name)), c.total_paid > 0 && /*#__PURE__*/React.createElement("span", {
    className: "ssel-paid-badge"
  }, fmtF(c.total_paid))))), statusLoading ? /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading payment status\u2026")) : statusErr ? /*#__PURE__*/React.createElement("div", {
    className: "err-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " Error loading payment status"), /*#__PURE__*/React.createElement("div", {
    className: "err-msg"
  }, statusErr)) : status ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(OverviewCards, {
    st: status
  }), /*#__PURE__*/React.createElement("div", {
    className: "info-bar no-print"
  }, /*#__PURE__*/React.createElement("div", {
    className: "info-chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  }), " ", /*#__PURE__*/React.createElement("span", null, "Year"), ' ', status.academic_year), /*#__PURE__*/React.createElement("div", {
    className: "info-chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  }), ' ', /*#__PURE__*/React.createElement("span", null, "Class"), ' ', status.class_name || '—'), status.discount_pct > 0 && /*#__PURE__*/React.createElement("div", {
    className: "info-chip disc-chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFF7\uFE0F",
    size: 18
  }), ' ', status.discount_pct, "% Discount Active"), status.scholarship_total > 0 && /*#__PURE__*/React.createElement("div", {
    className: "info-chip sch-chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), ' ', fmtF(status.scholarship_total), ' ', "Scholarship"), status.transport_assigned && /*#__PURE__*/React.createElement("div", {
    className: "info-chip",
    style: {
      borderColor: '#818CF8',
      background: '#EEF2FF',
      color: '#3730A3'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDE8C",
    size: 18
  }), " Transport Enrolled"), status.fully_paid && /*#__PURE__*/React.createElement("div", {
    className: "info-chip paid-chip"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " Fully Paid")), /*#__PURE__*/React.createElement("div", {
    className: "tabs no-print"
  }, TABS.map(([k, l]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    className: `tab${tab === k ? ' on' : ''}`,
    onClick: () => setTab(k)
  }, l))), tab === 'summary' && /*#__PURE__*/React.createElement(SummaryTab, {
    st: status,
    studentId: selId
  }), tab === 'payments' && /*#__PURE__*/React.createElement(PaymentsTab, {
    studentId: selId
  }), tab === 'fees' && /*#__PURE__*/React.createElement(FeeStructureTab, {
    studentId: selId,
    st: status
  })) : selId && !statusLoading ? /*#__PURE__*/React.createElement("div", {
    className: "info-banner"
  }, "Select your child above to view their fee status.") : null, !childrenLoading && children.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "no-fees"
  }, /*#__PURE__*/React.createElement("div", {
    className: "no-fees-icon"
  }, "\uD83D\uDC76"), /*#__PURE__*/React.createElement("div", {
    className: "no-fees-title"
  }, "No Children Linked"), /*#__PURE__*/React.createElement("div", {
    className: "no-fees-sub"
  }, "No students are linked to your account. Contact the school office to link your child.")))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(ParentFinancePage, null));