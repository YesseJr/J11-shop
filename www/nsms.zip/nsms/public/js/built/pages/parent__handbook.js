const { useState, useEffect } = React;

function HandbookPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [regs, setRegs] = useState([]);
  const [events, setEvents] = useState([]);
  const [school, setSchool] = useState(null);
  const [q, setQ] = useState('');
  const [err, setErr] = useState('');

  useEffect(function () {
    Promise.all([
      fetch('/nsms/api/settings.php?action=get_regulations').then(function (r) { return r.json(); }),
      fetch('/nsms/api/settings.php?action=get_calendar').then(function (r) { return r.json(); }),
      fetch('/nsms/api/settings.php?action=get_public').then(function (r) { return r.json(); })
    ]).then(function (results) {
      var regData = results[0];
      var calData = results[1];
      var pubData = results[2];
      if (regData && regData.success) {
        var items = (regData.data && regData.data.items) || regData.data || [];
        setRegs(Array.isArray(items) ? items.filter(function (x) {
          return x.is_visible == null || x.is_visible == 1 || x.is_visible === true;
        }) : []);
      }
      if (calData && calData.success) {
        var ev = (calData.data && (calData.data.events || calData.data.items)) || calData.data || [];
        setEvents(Array.isArray(ev) ? ev : []);
      }
      if (pubData && pubData.success) setSchool(pubData.data || null);
    }).catch(function () {
      setErr('Could not load handbook content.');
    }).finally(function () {
      setLoading(false);
    });
  }, []);

  var filtered = regs.filter(function (r) {
    if (!q.trim()) return true;
    var s = q.toLowerCase();
    return ((r.title || '').toLowerCase().indexOf(s) >= 0) || ((r.text || '').toLowerCase().indexOf(s) >= 0);
  });

  function regIcon(r) {
    if (typeof Icon === 'function') {
      return React.createElement(Icon, { emoji: r.icon || 'clipboard', name: r.icon && window.NSMS_ICONS && window.NSMS_ICONS[r.icon] ? r.icon : undefined, size: 20 });
    }
    return null;
  }

  return React.createElement(React.Fragment, null,
    React.createElement(ParentNavbar, {
      activePage: 'handbook',
      sidebarOpen: sidebarOpen,
      setSidebarOpen: setSidebarOpen
    }),
    React.createElement(ParentSidebar, {
      activePage: 'handbook',
      sidebarOpen: sidebarOpen
    }),
    React.createElement('div', {
      className: 'page-body' + (sidebarOpen ? ' expanded' : '')
    },
      React.createElement('div', { className: 'ph' },
        React.createElement('h1', null, 'School Handbook'),
        React.createElement('div', { className: 'ph-sub' },
          (school && school.school_name ? school.school_name + ' — ' : '') +
          'Rules, policies, and important school information'
        )
      ),
      err && React.createElement('div', { style: { color: '#B91C1C', marginBottom: 16 } }, err),
      loading
        ? React.createElement('div', { className: 'sw' }, React.createElement('div', { className: 'spinner' }))
        : React.createElement('div', { className: 'hb-grid' },
            React.createElement('div', null,
              React.createElement('div', { className: 'card' },
                React.createElement('h2', null,
                  typeof Icon === 'function' ? React.createElement(Icon, { name: 'book', size: 18 }) : null,
                  ' Policies & regulations'
                ),
                React.createElement('input', {
                  className: 'search',
                  placeholder: 'Search handbook…',
                  value: q,
                  onChange: function (e) { setQ(e.target.value); }
                }),
                filtered.length === 0
                  ? React.createElement('div', { className: 'empty' }, 'No policies published yet. Check back soon.')
                  : filtered.map(function (r, i) {
                      return React.createElement('div', { className: 'reg-item', key: r.id || i },
                        React.createElement('div', { className: 'reg-icon' }, regIcon(r)),
                        React.createElement('div', null,
                          React.createElement('div', { className: 'reg-title' }, r.title || 'Policy'),
                          React.createElement('div', { className: 'reg-text' }, r.text || '')
                        )
                      );
                    })
              )
            ),
            React.createElement('div', null,
              React.createElement('div', { className: 'card' },
                React.createElement('h2', null,
                  typeof Icon === 'function' ? React.createElement(Icon, { name: 'calendar', size: 18 }) : null,
                  ' School calendar'
                ),
                events.length === 0
                  ? React.createElement('div', { className: 'empty' }, 'No upcoming events listed.')
                  : events.slice(0, 12).map(function (ev, i) {
                      return React.createElement('div', { className: 'cal-item', key: ev.id || i },
                        React.createElement('div', { className: 'cal-date' },
                          typeof Icon === 'function'
                            ? React.createElement(Icon, { emoji: ev.icon || 'calendar', size: 14 })
                            : null,
                          ' ',
                          ev.date || ev.event_date || ev.start_date || ''
                        ),
                        React.createElement('div', { style: { fontWeight: 600 } }, ev.title || ev.name || 'Event'),
                        (ev.desc || ev.description || ev.text)
                          ? React.createElement('div', { style: { color: '#64748B', marginTop: 2 } }, ev.desc || ev.description || ev.text)
                          : null
                      );
                    })
              ),
              React.createElement('div', { className: 'card' },
                React.createElement('h2', null, 'Need help?'),
                React.createElement('p', { style: { fontSize: 13, color: '#64748B', lineHeight: 1.55 } },
                  'Questions about school rules or fees can be sent through J11 Pulse, or contact the school office using the details on the public school website.'
                )
              )
            )
          )
    )
  );
}

var root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(HandbookPage));
