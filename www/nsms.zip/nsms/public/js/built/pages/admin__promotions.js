var useState = React.useState;
var useEffect = React.useEffect;
var AV_COLORS = ['#D97706', '#2563EB', '#10B981', '#7C3AED', '#EF4444', '#0891B2', '#DB2777'];
function avColor(n) {
  return n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
}
function initials(n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
}
function Av(props) {
  var n = props.name || '';
  return /*#__PURE__*/React.createElement("div", {
    className: "stu-av",
    style: {
      background: avColor(n)
    }
  }, props.src && /*#__PURE__*/React.createElement("img", {
    src: props.src,
    alt: n,
    onError: function (e) {
      e.currentTarget.style.display = 'none';
    }
  }), initials(n));
}
function currentAcademicYear() {
  var m = new Date().getMonth() + 1; // 1-12
  var y = new Date().getFullYear();
  return m >= 9 ? y + '/' + (y + 1) : y - 1 + '/' + y;
}
function PromotionsPage() {
  var collapsedSt = useState(false);
  var collapsed = collapsedSt[0];
  var setCollapsed = collapsedSt[1];
  var tabSt = useState('transition');
  var tab = tabSt[0];
  var setTab = tabSt[1];
  var yearSt = useState(currentAcademicYear());
  var year = yearSt[0];
  var setYear = yearSt[1];
  var yearInputSt = useState(currentAcademicYear());
  var yearInput = yearInputSt[0];
  var setYearInput = yearInputSt[1];
  var classesSt = useState([]);
  var classes = classesSt[0];
  var setClasses = classesSt[1];
  var loadingSt = useState(true);
  var loading = loadingSt[0];
  var setLoading = loadingSt[1];
  var decisionsSt = useState({});
  var decisions = decisionsSt[0];
  var setDecisions = decisionsSt[1];
  var executingSt = useState(false);
  var executing = executingSt[0];
  var setExecuting = executingSt[1];
  var resultSt = useState(null);
  var result = resultSt[0];
  var setResult = resultSt[1];
  var gradYearsSt = useState([]);
  var gradYears = gradYearsSt[0];
  var setGradYears = gradYearsSt[1];
  var gradFilterSt = useState('');
  var gradFilter = gradFilterSt[0];
  var setGradFilter = gradFilterSt[1];
  var gradListSt = useState([]);
  var gradList = gradListSt[0];
  var setGradList = gradListSt[1];
  var gradLoadingSt = useState(true);
  var gradLoading = gradLoadingSt[0];
  var setGradLoading = gradLoadingSt[1];
  var gdOpenIdSt = useState(null);
  var gdOpenId = gdOpenIdSt[0];
  var setGdOpenId = gdOpenIdSt[1];
  var gdDataSt = useState(null);
  var gdData = gdDataSt[0];
  var setGdData = gdDataSt[1];
  var gdLoadingSt = useState(false);
  var gdLoading = gdLoadingSt[0];
  var setGdLoading = gdLoadingSt[1];
  var payOpenSt = useState(false);
  var payOpen = payOpenSt[0];
  var setPayOpen = payOpenSt[1];
  var payAmountSt = useState('');
  var payAmount = payAmountSt[0];
  var setPayAmount = payAmountSt[1];
  var payMethodSt = useState('Cash');
  var payMethod = payMethodSt[0];
  var setPayMethod = payMethodSt[1];
  var payDateSt = useState(new Date().toISOString().slice(0, 10));
  var payDate = payDateSt[0];
  var setPayDate = payDateSt[1];
  var payRefSt = useState('');
  var payRef = payRefSt[0];
  var setPayRef = payRefSt[1];
  var paySubmittingSt = useState(false);
  var paySubmitting = paySubmittingSt[0];
  var setPaySubmitting = paySubmittingSt[1];
  var payMsgSt = useState(null);
  var payMsg = payMsgSt[0];
  var setPayMsg = payMsgSt[1];
  function loadGraduateDetail(studentId) {
    setGdData(null);
    setGdLoading(true);
    fetch('/nsms/api/promotions.php?action=graduate_detail&student_id=' + studentId).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setGdData(d.data);
    }).catch(function () {}).finally(function () {
      setGdLoading(false);
    });
  }
  function openGraduateDetail(studentId) {
    setGdOpenId(studentId);
    setPayOpen(false);
    setPayAmount('');
    setPayMethod('Cash');
    setPayRef('');
    setPayMsg(null);
    loadGraduateDetail(studentId);
  }
  function closeGraduateDetail() {
    setGdOpenId(null);
    setGdData(null);
    setPayOpen(false);
  }
  function submitPayment() {
    var n = parseFloat(payAmount);
    if (isNaN(n) || n <= 0) {
      setPayMsg({
        type: 'error',
        msg: 'Enter a valid amount.'
      });
      return;
    }
    setPaySubmitting(true);
    setPayMsg(null);
    fetch('/nsms/api/finance.php?action=record_payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        student_id: gdOpenId,
        amount: n,
        payment_method: payMethod,
        payment_date: payDate,
        reference_number: payRef || undefined
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setPayMsg({
          type: 'success',
          msg: 'Payment recorded successfully.'
        });
        setPayAmount('');
        setPayRef('');
        setPayOpen(false);
        loadGraduateDetail(gdOpenId); // refresh detail with new balance, keeps payMsg intact
        loadGraduates(); // refresh the fee dot on the tile
      } else {
        setPayMsg({
          type: 'error',
          msg: d.error || 'Failed to record payment.'
        });
      }
    }).catch(function () {
      setPayMsg({
        type: 'error',
        msg: 'Network error.'
      });
    }).finally(function () {
      setPaySubmitting(false);
    });
  }
  async function fmtTSh(n) {
    return 'TSh ' + Math.round(n || 0).toLocaleString();
  }
  async function loadPreview() {
    setLoading(true);
    setResult(null);
    fetch('/nsms/api/promotions.php?action=preview&academic_year=' + encodeURIComponent(year)).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setClasses(d.data.classes || []);
        var initDecisions = {};
        (d.data.classes || []).forEach(function (c) {
          c.students.forEach(function (s) {
            initDecisions[s.id] = s.recommended_decision;
          });
        });
        setDecisions(initDecisions);
      }
    }).catch(function () {}).finally(function () {
      setLoading(false);
    });
  }
  async function loadGraduates() {
    setGradLoading(true);
    fetch('/nsms/api/promotions.php?action=graduates_list' + (gradFilter ? '&year=' + encodeURIComponent(gradFilter) : '')).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setGradList(d.data.graduates || []);
        setGradYears(d.data.years || []);
      }
    }).catch(function () {}).finally(function () {
      setGradLoading(false);
    });
  }
  useEffect(function () {
    loadPreview();
  }, [year]);
  useEffect(function () {
    if (tab === 'graduates') loadGraduates();
  }, [tab, gradFilter]);
  async function setDecision(studentId, val) {
    setDecisions(function (d) {
      var n = Object.assign({}, d);
      n[studentId] = val;
      return n;
    });
  }
  async function applyRecommendedToClass(cls) {
    setDecisions(function (d) {
      var n = Object.assign({}, d);
      cls.students.forEach(function (s) {
        n[s.id] = s.recommended_decision;
      });
      return n;
    });
  }
  var totalAdvance = 0,
    totalRepeat = 0,
    totalStudents = 0;
  classes.forEach(function (c) {
    c.students.forEach(function (s) {
      totalStudents++;
      if (decisions[s.id] === 'advance') totalAdvance++;else totalRepeat++;
    });
  });
  async function executeTransition() {
    var graduatingCount = 0;
    classes.forEach(function (c) {
      if (c.is_graduating_class) {
        c.students.forEach(function (s) {
          if (decisions[s.id] === 'advance') graduatingCount++;
        });
      }
    });
    var msg = 'Run the end-of-year transition for ' + year + '?\n\n' + totalAdvance + ' student(s) will advance' + (graduatingCount ? ' (including ' + graduatingCount + ' graduating)' : '') + '.\n' + totalRepeat + ' student(s) will repeat their current class.\n\n' + "This will move students between classes immediately and cannot be undone with a click — please confirm you've reviewed every row.";
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ message: msg, variant: 'warn' }) : Promise.resolve(false)))) return;
    setExecuting(true);
    var payload = {
      academic_year: year,
      decisions: Object.keys(decisions).map(function (sid) {
        return {
          student_id: parseInt(sid, 10),
          decision: decisions[sid]
        };
      })
    };
    fetch('/nsms/api/promotions.php?action=execute', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setResult(d.data);
        loadPreview();
      } else alert(d.error || 'Failed to execute transition.');
    }).catch(function () {
      alert('Network error.');
    }).finally(function () {
      setExecuting(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NSMSNavbar, {
    activePage: "promotions",
    onToggleSidebar: function () {
      setCollapsed(function (c) {
        return !c;
      });
    }
  }), /*#__PURE__*/React.createElement(NSMSSidebar, {
    items: NSMS_SIDEBAR_ITEMS,
    activePage: "promotions",
    collapsed: collapsed
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (collapsed ? ' collapsed' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "shell"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pg-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pg-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "pg-title"
  }, "Promotions & Graduation"), /*#__PURE__*/React.createElement("div", {
    className: "pg-tagline"
  }, "End-of-year class transitions"))), /*#__PURE__*/React.createElement("div", {
    className: "tabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: 'tab-btn' + (tab === 'transition' ? ' active' : ''),
    onClick: function () {
      setTab('transition');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD04",
    size: 18
  }), " Run Transition"), /*#__PURE__*/React.createElement("button", {
    className: 'tab-btn' + (tab === 'graduates' ? ' active' : ''),
    onClick: function () {
      setTab('graduates');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), " Graduates Archive")), tab === 'transition' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "yr-row"
  }, /*#__PURE__*/React.createElement("label", null, "Academic Year:"), /*#__PURE__*/React.createElement("input", {
    className: "yr-input",
    value: yearInput,
    placeholder: "2025/2026",
    onChange: function (e) {
      setYearInput(e.target.value);
    },
    onKeyDown: function (e) {
      if (e.key === 'Enter') setYear(yearInput);
    }
  }), /*#__PURE__*/React.createElement("button", {
    className: "reload-btn",
    onClick: function () {
      setYear(yearInput);
    }
  }, "Load")), result && /*#__PURE__*/React.createElement("div", {
    className: "result-banner"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " Transition complete \u2014", ' ', /*#__PURE__*/React.createElement("b", null, result.advanced), ' ', "advanced,", ' ', /*#__PURE__*/React.createElement("b", null, result.graduated), ' ', "graduated,", ' ', /*#__PURE__*/React.createElement("b", null, result.repeated), ' ', "repeated", result.skipped && result.skipped.length > 0 ? ', ' + result.skipped.length + ' skipped (see server log)' : '', "."), loading ? /*#__PURE__*/React.createElement("div", {
    className: "spin"
  }) : classes.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "panel-empty"
  }, "No classes configured yet.") : /*#__PURE__*/React.createElement(React.Fragment, null, classes.map(function (cls) {
    return /*#__PURE__*/React.createElement("div", {
      className: 'class-card' + (cls.is_graduating_class ? ' graduating' : ''),
      key: cls.class_id
    }, /*#__PURE__*/React.createElement("div", {
      className: "class-head"
    }, /*#__PURE__*/React.createElement("div", {
      className: "class-dot",
      style: {
        background: cls.class_color
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "class-name"
    }, cls.class_name), cls.is_graduating_class && /*#__PURE__*/React.createElement("span", {
      className: "grad-badge"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF93",
      size: 18
    }), "GRADUATING CLASS"), /*#__PURE__*/React.createElement("span", {
      className: "class-count"
    }, cls.students.length, ' ', "student", cls.students.length !== 1 ? 's' : ''), cls.students.length > 0 && /*#__PURE__*/React.createElement("button", {
      className: "bulk-btn",
      onClick: function () {
        applyRecommendedToClass(cls);
      }
    }, "Apply Teacher's Recommendation to All")), cls.students.length === 0 ? /*#__PURE__*/React.createElement("div", {
      className: "panel-empty"
    }, "No active students in this class.") : cls.students.map(function (s) {
      var badgeCls = s.promotion_status ? s.promotion_status.replace(' ', '-') : 'none';
      var dec = decisions[s.id] || 'repeat';
      return /*#__PURE__*/React.createElement("div", {
        className: "stu-row",
        key: s.id
      }, /*#__PURE__*/React.createElement(Av, {
        name: s.student_name,
        src: s.photo_url
      }), /*#__PURE__*/React.createElement("span", {
        className: "stu-name"
      }, s.student_name), /*#__PURE__*/React.createElement("span", {
        className: 'promo-badge ' + badgeCls
      }, s.has_terminal_report ? s.promotion_status : 'No terminal report'), /*#__PURE__*/React.createElement("div", {
        className: "decision-toggle"
      }, /*#__PURE__*/React.createElement("button", {
        className: dec === 'advance' ? 'sel-advance' : '',
        onClick: function () {
          setDecision(s.id, 'advance');
        }
      }, cls.is_graduating_class ? /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83C\uDF93",
        size: 16
      }), "Graduate") : /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u2B06\uFE0F",
        size: 16
      }), "Advance")), /*#__PURE__*/React.createElement("button", {
        className: dec === 'repeat' ? 'sel-repeat' : '',
        onClick: function () {
          setDecision(s.id, 'repeat');
        }
      }, "\uD83D\uDD01 Repeat")));
    }));
  }), /*#__PURE__*/React.createElement("div", {
    className: "exec-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "exec-summary"
  }, /*#__PURE__*/React.createElement("b", null, totalStudents), ' ', "students reviewed \u2014", ' ', /*#__PURE__*/React.createElement("b", null, totalAdvance), ' ', "to advance/graduate,", ' ', /*#__PURE__*/React.createElement("b", null, totalRepeat), ' ', "to repeat."), /*#__PURE__*/React.createElement("button", {
    className: "exec-btn",
    disabled: executing || totalStudents === 0,
    onClick: executeTransition
  }, executing ? 'Processing…' : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 16
  }), "Execute Transition"))))), tab === 'graduates' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "yr-row"
  }, /*#__PURE__*/React.createElement("label", null, "Filter by year:"), /*#__PURE__*/React.createElement("select", {
    className: "yr-input",
    value: gradFilter,
    onChange: function (e) {
      setGradFilter(e.target.value);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "All years"), gradYears.map(function (y) {
    return /*#__PURE__*/React.createElement("option", {
      key: y,
      value: y
    }, y);
  }))), gradLoading ? /*#__PURE__*/React.createElement("div", {
    className: "spin"
  }) : gradList.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "panel-empty"
  }, "No graduates recorded yet.") : /*#__PURE__*/React.createElement("div", {
    className: "grad-grid"
  }, gradList.map(function (g) {
    var hasDebt = g.fee_status && g.fee_status.has_debt;
    return /*#__PURE__*/React.createElement("div", {
      className: "grad-tile",
      key: g.id,
      onClick: function () {
        openGraduateDetail(g.student_id);
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: 'fee-dot ' + (hasDebt ? 'debt' : 'paid'),
      title: hasDebt ? 'Outstanding balance' : 'Fees fully paid'
    }), /*#__PURE__*/React.createElement(Av, {
      name: g.student_name,
      src: g.photo_url
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "grad-tile-name"
    }, g.student_name), /*#__PURE__*/React.createElement("div", {
      className: "grad-tile-meta"
    }, "\uD83C\uDF93", ' ', g.graduation_year, ' ', "\xB7 from", ' ', g.final_class_name || '—')));
  })))))), gdOpenId && /*#__PURE__*/React.createElement("div", {
    className: "gd-overlay",
    onClick: function (e) {
      if (e.target === e.currentTarget) closeGraduateDetail();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gd-modal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gd-head"
  }, gdData && gdData.student && /*#__PURE__*/React.createElement(Av, {
    name: gdData.student.student_name,
    src: gdData.student.photo_url,
    size: 56
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "gd-head-name"
  }, gdData && gdData.student ? gdData.student.student_name : 'Loading…'), /*#__PURE__*/React.createElement("div", {
    className: "gd-head-meta"
  }, gdData && /*#__PURE__*/React.createElement(React.Fragment, null, "\uD83C\uDF93 Graduated", ' ', gdData.graduate.graduation_year, ' ', "\xB7 from", ' ', gdData.graduate.final_class_name || '—', gdData.enrolled_span && /*#__PURE__*/React.createElement(React.Fragment, null, ' ', "\xB7 enrolled", ' ', gdData.enrolled_span.years, "y", ' ', gdData.enrolled_span.months, "m")))), /*#__PURE__*/React.createElement("button", {
    className: "gd-close",
    onClick: closeGraduateDetail
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "gd-body"
  }, gdLoading ? /*#__PURE__*/React.createElement("div", {
    className: "spin"
  }) : !gdData ? /*#__PURE__*/React.createElement("div", {
    className: "panel-empty"
  }, "Could not load this graduate's details.") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "gd-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gd-label"
  }, "Fee Status (", gdData.graduate.graduation_year, ")"), /*#__PURE__*/React.createElement("div", {
    className: 'fee-card ' + (gdData.fee_status.has_debt ? 'debt' : 'paid')
  }, /*#__PURE__*/React.createElement("div", {
    className: "fee-card-icon"
  }, gdData.fee_status.has_debt ? typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '🔴',
    size: 16
  }) : null : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '🟢',
    size: 16
  }) : null), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "fee-card-title"
  }, gdData.fee_status.has_debt ? 'Outstanding balance: ' + fmtTSh(gdData.fee_status.balance) : 'Fees fully paid'), /*#__PURE__*/React.createElement("div", {
    className: "fee-card-sub"
  }, fmtTSh(gdData.fee_status.total_paid), ' ', "paid of", ' ', fmtTSh(gdData.fee_status.grand_total), ' ', "total"))), payMsg && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      padding: '9px 14px',
      borderRadius: 8,
      fontSize: 12.5,
      fontWeight: 600,
      background: payMsg.type === 'error' ? '#FEF2F2' : '#F0FDF4',
      color: payMsg.type === 'error' ? '#B91C1C' : '#166534'
    }
  }, payMsg.msg), gdData.fee_status.has_debt && !payOpen && /*#__PURE__*/React.createElement("button", {
    className: "bulk-btn",
    style: {
      marginTop: 10
    },
    onClick: function () {
      setPayOpen(true);
      setPayAmount(String(gdData.fee_status.balance));
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB0",
    size: 18
  }), " Record Payment"), payOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      padding: 14,
      background: '#FAFBFC',
      border: '1px solid var(--border)',
      borderRadius: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--text-soft)',
      display: 'block',
      marginBottom: 4
    }
  }, "Amount (TSh)"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    min: "1",
    className: "yr-input",
    style: {
      width: '100%'
    },
    value: payAmount,
    onChange: function (e) {
      setPayAmount(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--text-soft)',
      display: 'block',
      marginBottom: 4
    }
  }, "Method"), /*#__PURE__*/React.createElement("select", {
    className: "yr-input",
    style: {
      width: '100%'
    },
    value: payMethod,
    onChange: function (e) {
      setPayMethod(e.target.value);
    }
  }, /*#__PURE__*/React.createElement("option", null, "Cash"), /*#__PURE__*/React.createElement("option", null, "M-Pesa"), /*#__PURE__*/React.createElement("option", null, "Bank Transfer"), /*#__PURE__*/React.createElement("option", null, "Cheque"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--text-soft)',
      display: 'block',
      marginBottom: 4
    }
  }, "Date"), /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "yr-input",
    style: {
      width: '100%'
    },
    value: payDate,
    onChange: function (e) {
      setPayDate(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--text-soft)',
      display: 'block',
      marginBottom: 4
    }
  }, "Reference (optional)"), /*#__PURE__*/React.createElement("input", {
    className: "yr-input",
    style: {
      width: '100%'
    },
    value: payRef,
    onChange: function (e) {
      setPayRef(e.target.value);
    },
    placeholder: "Receipt / transaction #"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "exec-btn",
    style: {
      padding: '8px 18px',
      fontSize: 12.5
    },
    disabled: paySubmitting,
    onClick: submitPayment
  }, paySubmitting ? 'Saving…' : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 16
  }), "Save Payment")), /*#__PURE__*/React.createElement("button", {
    className: "reload-btn",
    onClick: function () {
      setPayOpen(false);
      setPayMsg(null);
    }
  }, "Cancel")))), /*#__PURE__*/React.createElement("div", {
    className: "gd-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gd-label"
  }, "Parent / Guardian Contacts"), gdData.guardians.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "No guardian on record.") : gdData.guardians.map(function (g, i) {
    return /*#__PURE__*/React.createElement("div", {
      className: "guardian-row",
      key: i
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "guardian-name"
    }, g.full_name), /*#__PURE__*/React.createElement("div", {
      className: "guardian-meta"
    }, g.relationship || 'Guardian')), /*#__PURE__*/React.createElement("div", {
      className: "guardian-meta",
      style: {
        textAlign: 'right'
      }
    }, g.phone && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCF1",
      size: 18
    }), ' ', g.phone), g.email && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2709\uFE0F",
      size: 18
    }), ' ', g.email)));
  })), gdData.final_report && /*#__PURE__*/React.createElement("div", {
    className: "gd-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gd-label"
  }, "Final Terminal Report"), /*#__PURE__*/React.createElement("div", {
    className: "final-report-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rv-val"
  }, /*#__PURE__*/React.createElement("b", null, "Comments:"), ' ', gdData.final_report.teacher_comments || '—'), /*#__PURE__*/React.createElement("div", {
    className: "rv-val",
    style: {
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("b", null, "Recommendations:"), ' ', gdData.final_report.recommendations || '—'), /*#__PURE__*/React.createElement("div", {
    className: "rv-val",
    style: {
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("b", null, "Promotion Status:"), ' ', gdData.final_report.promotion_status || '—'))), gdData.student && gdData.student.date_of_birth && /*#__PURE__*/React.createElement("div", {
    className: "gd-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gd-label"
  }, "Other Details"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-soft)'
    }
  }, gdData.student.gender, ", born", ' ', gdData.student.date_of_birth, gdData.student.address && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("br", null), gdData.student.address))))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(PromotionsPage, null));