/* ════════════════════════════════════════════════════════════════
   ATTENDANCE PAGE  —  NSMS Parent Panel
   attendance.html → /nsms/api/parent-attendance.php
   Layout: ParentNavbar + ParentSidebar (from parent-shared.js)
════════════════════════════════════════════════════════════════ */

const {
  useState,
  useEffect,
  useRef,
  useCallback
} = React;
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DOW_LABELS = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const TODAY = new Date().toISOString().slice(0, 10);

/* ── API helper ── */
async function apiGet(params) {
  const url = '/nsms/api/parent-attendance.php?' + new URLSearchParams(params);
  const r = await fetch(url, {
    credentials: 'include'
  });
  const text = await r.text();
  try {
    return JSON.parse(text);
  } catch {
    return {
      success: false,
      error: 'Unexpected server response.'
    };
  }
}

/* ── Boot data: children + unread count come from session + notifications_count ── */
async function fetchBootData() {
  const [sessionRes, notifRes] = await Promise.allSettled([fetch('/nsms/api/parent-panel.php?action=session', {
    credentials: 'include'
  }).then(r => r.text()).then(t => JSON.parse(t)), fetch('/nsms/api/parent-panel.php?action=notifications_count', {
    credentials: 'include'
  }).then(r => r.text()).then(t => JSON.parse(t))]);
  const session = sessionRes.status === 'fulfilled' ? sessionRes.value : {
    success: false
  };
  const notif = notifRes.status === 'fulfilled' ? notifRes.value : {
    success: false
  };
  return {
    session,
    notif
  };
}

/* ════════════════════════════════════════════════════════════════
   CHILD SELECTOR
════════════════════════════════════════════════════════════════ */
function ChildSelector({
  students,
  selectedChild,
  setSelectedChild
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const onOut = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', onOut);
    return () => document.removeEventListener('mousedown', onOut);
  }, [open]);
  if (!selectedChild) return null;

  /* Avatar helper */
  const av = child => {
    if (child.photo_url) {
      return /*#__PURE__*/React.createElement("div", {
        className: "child-av"
      }, /*#__PURE__*/React.createElement("img", {
        src: child.photo_url,
        alt: ""
      }));
    }
    const initials = child.student_name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
    const bg = ['#10B981', '#2563EB', '#F59E0B', '#8B5CF6', '#EF4444'][child.student_name.charCodeAt(0) % 5];
    return /*#__PURE__*/React.createElement("div", {
      className: "child-av",
      style: {
        background: bg,
        color: '#fff',
        fontSize: 11,
        fontWeight: 700
      }
    }, initials);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "child-sel",
    ref: ref
  }, /*#__PURE__*/React.createElement("button", {
    className: "child-sel-btn",
    onClick: () => {
      if (students.length > 1) setOpen(o => !o);
    }
  }, av(selectedChild), /*#__PURE__*/React.createElement("div", {
    className: "child-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "child-name"
  }, selectedChild.student_name), selectedChild.class_name && /*#__PURE__*/React.createElement("div", {
    className: "child-class"
  }, selectedChild.class_name)), students.length > 1 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--text-soft)',
      marginLeft: 4
    }
  }, open ? '▴' : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '▾',
    size: 16
  }) : null)), open && students.length > 1 && /*#__PURE__*/React.createElement("div", {
    className: "child-dd"
  }, students.map(child => /*#__PURE__*/React.createElement("button", {
    key: child.id,
    className: `child-dd-item ${selectedChild.id === child.id ? 'sel' : ''}`,
    onClick: () => {
      setSelectedChild(child);
      setOpen(false);
    }
  }, av(child), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "child-name"
  }, child.student_name), child.class_name && /*#__PURE__*/React.createElement("div", {
    className: "child-class"
  }, child.class_name)), selectedChild.id === child.id && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      color: 'var(--blue)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }))))));
}

/* ════════════════════════════════════════════════════════════════
   STAT CARD
════════════════════════════════════════════════════════════════ */
function StatCard({
  label,
  value,
  barPct,
  color,
  noteIcon,
  note,
  noteType,
  loading
}) {
  if (loading) {
    return /*#__PURE__*/React.createElement("div", {
      className: "stat-card-sk"
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        width: 80,
        height: 12,
        marginBottom: 12
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        width: 60,
        height: 36,
        marginBottom: 12
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        width: '100%',
        height: 6,
        marginBottom: 8,
        borderRadius: 3
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer",
      style: {
        width: 100,
        height: 12
      }
    }));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: `stat-card ${color}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, value !== null && value !== undefined ? value : '—'), /*#__PURE__*/React.createElement("div", {
    className: "stat-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-bar-fill",
    style: {
      width: (barPct || 0) + '%'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: `stat-note${noteType ? ' ' + noteType : ''}`
  }, noteIcon && /*#__PURE__*/React.createElement("span", null, noteIcon), note));
}

/* ════════════════════════════════════════════════════════════════
   DAY POPOVER — vivid card, centred, with blurred backdrop
════════════════════════════════════════════════════════════════ */
function DayPopover({
  record,
  onClose
}) {
  const ref = useRef(null);
  const [pos, setPos] = useState({
    x: -999,
    y: -999
  });

  /* Centre in viewport once mounted */
  useEffect(() => {
    if (!ref.current) return;
    const {
      width: w,
      height: h
    } = ref.current.getBoundingClientRect();
    setPos({
      x: Math.round((window.innerWidth - w) / 2),
      y: Math.round((window.innerHeight - h) / 2.2 + window.scrollY)
    });
  }, []);

  /* Keyboard dismiss */
  useEffect(() => {
    const fn = e => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', fn);
    return () => document.removeEventListener('keydown', fn);
  }, []);
  const META = {
    present: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u2705",
        size: 20
      }),
      label: 'Present',
      band: 'present'
    },
    absent: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u274C",
        size: 20
      }),
      label: 'Absent',
      band: 'absent'
    },
    late: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u23F0",
        size: 20
      }),
      label: 'Arrived Late',
      band: 'late'
    }
  };
  const m = META[record.status] || {
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCB",
      size: 20
    }),
    label: record.status,
    band: ''
  };
  const d = new Date(record.date + 'T00:00:00');
  const weekday = d.toLocaleDateString('en-GB', {
    weekday: 'long'
  });
  const dateStr = d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
  const markedAt = record.marked_at ? new Date(record.marked_at).toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit'
  }) : null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "pop-backdrop",
    onClick: onClose
  }), /*#__PURE__*/React.createElement("div", {
    className: "day-popover-wrap",
    style: {
      left: pos.x,
      top: pos.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "day-popover",
    ref: ref
  }, /*#__PURE__*/React.createElement("div", {
    className: `pop-header ${m.band}`
  }, /*#__PURE__*/React.createElement("span", {
    className: "pop-big-icon"
  }, m.icon), /*#__PURE__*/React.createElement("div", {
    className: "pop-header-text"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pop-status-label"
  }, m.label), /*#__PURE__*/React.createElement("div", {
    className: "pop-weekday"
  }, weekday)), /*#__PURE__*/React.createElement("button", {
    className: "pop-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pop-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pop-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pop-row-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "pop-row-lbl"
  }, "Date"), /*#__PURE__*/React.createElement("div", {
    className: "pop-row-val"
  }, dateStr))), record.status === 'late' && /*#__PURE__*/React.createElement("div", {
    className: "pop-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pop-row-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F1\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "pop-row-lbl"
  }, "Late by"), /*#__PURE__*/React.createElement("div", {
    className: "pop-row-val"
  }, record.late_minutes ? `${record.late_minutes} minute${record.late_minutes !== 1 ? 's' : ''}` : 'Duration not recorded'))), /*#__PURE__*/React.createElement("div", {
    className: "pop-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pop-row-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDD",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "pop-row-lbl"
  }, "Teacher's note"), /*#__PURE__*/React.createElement("div", {
    className: `pop-row-val${record.notes ? '' : ' soft'}`
  }, record.notes || 'No note recorded'))), markedAt && /*#__PURE__*/React.createElement("div", {
    className: "pop-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pop-row-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD50",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "pop-row-lbl"
  }, "Recorded at"), /*#__PURE__*/React.createElement("div", {
    className: "pop-row-val"
  }, markedAt)))))));
}

/* ════════════════════════════════════════════════════════════════
   CALENDAR
════════════════════════════════════════════════════════════════ */
function AttCalendar({
  year,
  month,
  records,
  loading,
  onPrev,
  onNext,
  canNext
}) {
  const [popover, setPopover] = useState(null);

  /* Build record map */
  const recMap = {};
  (records || []).forEach(r => {
    recMap[r.date] = r;
  });

  /* First day of month (0=Sun…6=Sat) */
  const firstDow = new Date(year, month - 1, 1).getDay();
  const daysInMonth = new Date(year, month, 0).getDate();

  /* Build cells: blanks + days */
  const cells = [];
  for (let i = 0; i < firstDow; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) {
    const ds = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    cells.push(recMap[ds] || {
      date: ds,
      status: null,
      is_weekend: false,
      is_holiday: false,
      is_future: false
    });
  }
  function cellClass(rec) {
    if (!rec) return 'cal-day empty';
    if (rec.is_weekend) return 'cal-day weekend' + (rec.date === TODAY ? ' today' : '');
    if (rec.is_holiday) return 'cal-day holiday' + (rec.date === TODAY ? ' today' : '');
    if (rec.is_future) return 'cal-day future';
    if (rec.status === 'present') return 'cal-day present' + (rec.date === TODAY ? ' today' : '');
    if (rec.status === 'absent') return 'cal-day absent' + (rec.date === TODAY ? ' today' : '');
    if (rec.status === 'late') return 'cal-day late' + (rec.date === TODAY ? ' today' : '');
    return 'cal-day unmarked' + (rec.date === TODAY ? ' today' : '');
  }
  function handleDayClick(rec) {
    if (!rec || rec.is_weekend || rec.is_holiday || rec.is_future || !rec.status) return;
    setPopover({
      record: rec
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "cal-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-title"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, MONTHS[month - 1], " ", year, " Attendance")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "cal-month-label"
  }, MONTHS[month - 1], " ", year), /*#__PURE__*/React.createElement("div", {
    className: "cal-nav"
  }, /*#__PURE__*/React.createElement("button", {
    className: "cal-nav-btn",
    onClick: onPrev,
    title: "Previous month"
  }, "\u2190"), /*#__PURE__*/React.createElement("button", {
    className: "cal-nav-btn",
    onClick: onNext,
    disabled: !canNext,
    title: "Next month"
  }, "\u2192")))), loading ? /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      padding: '40px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13
    }
  }, "Loading attendance\u2026")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "cal-dow-row"
  }, DOW_LABELS.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: d,
    className: `cal-dow${i === 0 || i === 6 ? ' weekend' : ''}`
  }, d))), /*#__PURE__*/React.createElement("div", {
    className: "cal-grid-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-grid"
  }, cells.map((rec, idx) => /*#__PURE__*/React.createElement("div", {
    key: idx,
    className: cellClass(rec),
    onClick: () => handleDayClick(rec)
  }, rec && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "cal-day-num"
  }, parseInt(rec.date.slice(8))), rec.is_holiday && /*#__PURE__*/React.createElement("span", {
    className: "cal-day-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF8C",
    size: 18
  })), rec.status === 'late' && /*#__PURE__*/React.createElement("div", {
    className: "late-dot"
  })))))), /*#__PURE__*/React.createElement("div", {
    className: "cal-legend"
  }, /*#__PURE__*/React.createElement("div", {
    className: "legend-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "legend-swatch present"
  }), " Present"), /*#__PURE__*/React.createElement("div", {
    className: "legend-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "legend-swatch absent"
  }), " Absent"), /*#__PURE__*/React.createElement("div", {
    className: "legend-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "legend-swatch late"
  }), " Late"), /*#__PURE__*/React.createElement("div", {
    className: "legend-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "legend-swatch holiday"
  }), " Holiday"), /*#__PURE__*/React.createElement("div", {
    className: "legend-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "legend-swatch unmarked"
  }), " Not Recorded"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      fontSize: 12,
      color: 'var(--text-soft)',
      fontWeight: 600
    }
  }, "Tap a day for details"))), popover && /*#__PURE__*/React.createElement(DayPopover, {
    record: popover.record,
    onClose: () => setPopover(null)
  }));
}

/* ════════════════════════════════════════════════════════════════
   WEEKLY BREAKDOWN TABLE — with week-selector navigation
   Props: records, year, month, onPrevMonth, onNextMonth
════════════════════════════════════════════════════════════════ */
function WeeklyBreakdown({
  records,
  year,
  month,
  onPrevMonth,
  onNextMonth
}) {
  /* Build weeks map from ALL records passed in */
  function buildWeeks(recs) {
    const map = {};
    (recs || []).forEach(r => {
      if (r.is_weekend || r.is_holiday || !r.status) return;
      const d = new Date(r.date + 'T00:00:00');
      const dayOfWeek = (d.getDay() + 6) % 7; /* 0=Mon */
      const mon = new Date(d);
      mon.setDate(d.getDate() - dayOfWeek);
      const key = mon.toISOString().slice(0, 10);
      if (!map[key]) map[key] = {
        key,
        present: 0,
        absent: 0,
        late: 0,
        total: 0,
        days: []
      };
      map[key].total++;
      map[key].days.push(r);
      if (r.status === 'present') map[key].present++;else if (r.status === 'absent') map[key].absent++;else if (r.status === 'late') map[key].late++;
    });
    return Object.values(map).sort((a, b) => a.key < b.key ? -1 : 1);
  }
  const weeks = buildWeeks(records);

  /* Default selected week = most recent week with data, else last week key */
  function todayWeekKey() {
    const d = new Date();
    const dow = (d.getDay() + 6) % 7;
    const mon = new Date(d);
    mon.setDate(d.getDate() - dow);
    return mon.toISOString().slice(0, 10);
  }
  const [selWeekKey, setSelWeekKey] = useState(() => {
    const tw = todayWeekKey();
    /* Use today's week if it exists in data, else most recent */
    return tw;
  });

  /* When month changes, reset selection to most recent week in new data */
  useEffect(() => {
    if (weeks.length === 0) return;
    const tw = todayWeekKey();
    const found = weeks.find(w => w.key === tw);
    setSelWeekKey(found ? tw : weeks[weeks.length - 1].key);
  }, [year, month]);

  /* Current week data (may be empty if no school days) */
  const selWeek = weeks.find(w => w.key === selWeekKey) || null;
  const selIdx = weeks.findIndex(w => w.key === selWeekKey);
  function weekLabel(key) {
    const d = new Date(key + 'T00:00:00');
    const end = new Date(d);
    end.setDate(d.getDate() + 4);
    const fmt = dt => dt.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short'
    });
    return `${fmt(d)} – ${fmt(end)}`;
  }
  function ratePillClass(attended, total) {
    if (total === 0) return 'rate-pill ok';
    const pct = attended / total * 100;
    if (pct >= 90) return 'rate-pill good';
    if (pct >= 70) return 'rate-pill ok';
    return 'rate-pill bad';
  }

  /* Navigation */
  function goPrev() {
    if (selIdx > 0) {
      setSelWeekKey(weeks[selIdx - 1].key);
    } else {
      /* At first week of this month — go to previous month */
      onPrevMonth && onPrevMonth();
    }
  }
  function goNext() {
    if (selIdx < weeks.length - 1) {
      setSelWeekKey(weeks[selIdx + 1].key);
    } else {
      /* At last week of this month — go to next month if allowed */
      onNextMonth && onNextMonth();
    }
  }

  /* Is next allowed? Only if we can go forward in the current month OR onNextMonth is available */
  const today = new Date();
  const isCurrentMonth = year === today.getFullYear() && month === today.getMonth() + 1;
  const canGoNext = selIdx < weeks.length - 1 || !isCurrentMonth;
  if (weeks.length === 0) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "breakdown-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "breakdown-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "breakdown-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  }), " Weekly Breakdown"), /*#__PURE__*/React.createElement("div", {
    className: "breakdown-sub"
  }, MONTHS[month - 1], " ", year)), /*#__PURE__*/React.createElement("div", {
    className: "wk-nav"
  }, /*#__PURE__*/React.createElement("button", {
    className: "wk-nav-btn",
    onClick: goPrev,
    title: "Previous week"
  }, "\u2190"), /*#__PURE__*/React.createElement("span", {
    className: "wk-label"
  }, selWeek ? weekLabel(selWeek.key) : weekLabel(selWeekKey)), /*#__PURE__*/React.createElement("button", {
    className: "wk-nav-btn",
    onClick: goNext,
    disabled: !canGoNext,
    title: "Next week"
  }, "\u2192"))), /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: 'auto'
    }
  }, selWeek ? /*#__PURE__*/React.createElement("table", {
    className: "bd-table"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Day"), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", null, "Late (min)"), /*#__PURE__*/React.createElement("th", null, "Notes"))), /*#__PURE__*/React.createElement("tbody", null, selWeek.days.map(r => {
    const d = new Date(r.date + 'T00:00:00');
    const dayName = d.toLocaleDateString('en-GB', {
      weekday: 'long',
      day: 'numeric',
      month: 'short'
    });
    return /*#__PURE__*/React.createElement("tr", {
      key: r.date
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        fontWeight: 600,
        fontSize: 13
      }
    }, dayName), /*#__PURE__*/React.createElement("td", null, r.status === 'present' && /*#__PURE__*/React.createElement("span", {
      className: "rate-pill good"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2705",
      size: 18
    }), " Present"), r.status === 'absent' && /*#__PURE__*/React.createElement("span", {
      className: "rate-pill bad"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u274C",
      size: 18
    }), " Absent"), r.status === 'late' && /*#__PURE__*/React.createElement("span", {
      className: "rate-pill ok"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u23F0",
      size: 18
    }), " Late")), /*#__PURE__*/React.createElement("td", {
      className: r.late_minutes ? 'late-cell' : ''
    }, r.late_minutes ? r.late_minutes + ' min' : '—'), /*#__PURE__*/React.createElement("td", {
      style: {
        color: 'var(--text-soft)',
        fontStyle: 'italic',
        fontSize: 12
      }
    }, r.notes || '—'));
  })), /*#__PURE__*/React.createElement("tfoot", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      borderTop: '2px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      fontWeight: 700,
      fontSize: 12,
      color: 'var(--text-soft)',
      paddingTop: 10
    }
  }, "Week summary"), /*#__PURE__*/React.createElement("td", {
    colSpan: 3
  }, (() => {
    const attended = selWeek.present + selWeek.late;
    const rate = selWeek.total > 0 ? Math.round(attended / selWeek.total * 100) : null;
    return /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: 'var(--text-dark)'
      }
    }, "Attended ", attended, "/", selWeek.total, " days", selWeek.late > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#92400E',
        marginLeft: 8,
        fontWeight: 600,
        fontSize: 12
      }
    }, "(", selWeek.late, " late)"), rate !== null && /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 10
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: ratePillClass(attended, selWeek.total)
    }, rate, "%")));
  })())))) : /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 20px',
      textAlign: 'center',
      color: 'var(--text-soft)',
      fontSize: 13
    }
  }, "No school days recorded for this week.")));
}

/* ════════════════════════════════════════════════════════════════
   MAIN APP
════════════════════════════════════════════════════════════════ */
function AttendanceApp() {
  /* ── Sidebar / navbar state ── */
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [unreadMsg, setUnreadMsg] = useState(0);

  /* ── Children data ── */
  const [students, setStudents] = useState([]);
  const [selectedChild, setSelectedChild] = useState(null);
  const [bootLoading, setBootLoading] = useState(true);
  const [bootErr, setBootErr] = useState('');

  /* ── Month navigation ── */
  const nowDate = new Date();
  const [viewYear, setViewYear] = useState(nowDate.getFullYear());
  const [viewMonth, setViewMonth] = useState(nowDate.getMonth() + 1);

  /* ── Attendance data ── */
  const [attData, setAttData] = useState(null); /* { records, summary } */
  const [attLoading, setAttLoading] = useState(false);
  const [attErr, setAttErr] = useState('');

  /* ── Yearly stats (for stat cards) ── */
  const [yearStats, setYearStats] = useState(null);
  const [yearStLoading, setYearStLoading] = useState(false);

  /* Boot: session gives children + notifications_count gives unread */
  useEffect(() => {
    (async () => {
      try {
        const {
          session,
          notif
        } = await fetchBootData();
        if (!session.success) {
          if (session.error === 'unauthorized') {
            window.location.href = '/nsms/public/index.html';
            return;
          }
          setBootErr(session.error || 'Failed to load session.');
          return;
        }
        const kids = session.data && session.data.children ? session.data.children : [];
        setStudents(kids);
        if (kids.length > 0) setSelectedChild(kids[0]);
        if (notif.success && notif.data) setUnreadMsg(notif.data.msgs || 0);
      } catch (e) {
        setBootErr('Network error. Please check your connection.');
      } finally {
        setBootLoading(false);
      }
    })();
  }, []);

  /* ── Load attendance whenever child or month changes ── */
  useEffect(() => {
    if (!selectedChild) return;
    setAttLoading(true);
    setAttErr('');
    setAttData(null);
    (async () => {
      try {
        const res = await apiGet({
          action: 'get_attendance',
          student_id: selectedChild.id,
          year: viewYear,
          month: viewMonth
        });
        if (!res.success) {
          setAttErr(res.error || 'Failed to load attendance.');
          return;
        }
        setAttData(res.data || res);
      } catch (e) {
        setAttErr('Network error loading attendance.');
      } finally {
        setAttLoading(false);
      }
    })();
  }, [selectedChild, viewYear, viewMonth]);

  /* ── Load yearly stats when child changes ── */
  useEffect(() => {
    if (!selectedChild) return;
    setYearStLoading(true);
    setYearStats(null);
    (async () => {
      try {
        const res = await apiGet({
          action: 'get_yearly_stats',
          student_id: selectedChild.id,
          year: nowDate.getFullYear()
        });
        if (res.success) setYearStats(res.data || res);
      } catch (e) {} finally {
        setYearStLoading(false);
      }
    })();
  }, [selectedChild]);

  /* ── Month navigation ── */
  function prevMonth() {
    if (viewMonth === 1) {
      setViewYear(y => y - 1);
      setViewMonth(12);
    } else setViewMonth(m => m - 1);
  }
  function nextMonth() {
    if (viewMonth === 12) {
      setViewYear(y => y + 1);
      setViewMonth(1);
    } else setViewMonth(m => m + 1);
  }
  const canGoNext = viewYear < nowDate.getFullYear() || viewYear === nowDate.getFullYear() && viewMonth < nowDate.getMonth() + 1;

  /* ── Derived stat values ── */
  const summary = attData ? attData.summary : null;

  /* For stat cards: yearly totals if available, else monthly */
  const _rawPresent = yearStats ? yearStats.present : summary ? summary.present : null;
  const _rawLate = yearStats ? yearStats.late : summary ? summary.late : null;
  const statAttended = _rawPresent !== null && _rawLate !== null ? _rawPresent + _rawLate : null; /* present + late */
  const statOnTime = _rawPresent; /* pure present only */
  const statAbsent = yearStats ? yearStats.absent : summary ? summary.absent : null;
  const statLate = _rawLate;
  const statRate = yearStats ? yearStats.rate : summary ? summary.rate : null;
  const statLoading = bootLoading || yearStLoading;
  const statTotal = yearStats ? yearStats.total_days : null;
  function rateNote(rate) {
    if (rate === null || rate === undefined) return {
      icon: null,
      text: 'No data yet',
      type: ''
    };
    if (rate >= 95) return {
      icon: '↑',
      text: 'Great attendance',
      type: 'up'
    };
    if (rate >= 80) return {
      icon: '↑',
      text: 'Above average',
      type: 'up'
    };
    if (rate >= 65) return {
      icon: '→',
      text: 'Needs improvement',
      type: ''
    };
    return {
      icon: '↓',
      text: 'Attendance is low',
      type: 'down'
    };
  }
  const rn = rateNote(statRate);
  const childName = selectedChild ? selectedChild.student_name : '';
  const childClass = selectedChild ? selectedChild.class_name : '';
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ParentNavbar, {
    activePage: "attendance",
    sidebarOpen: sidebarOpen,
    setSidebar: setSidebarOpen,
    unreadMsg: unreadMsg,
    students: students,
    selectedChild: selectedChild,
    setSelectedChild: setSelectedChild
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(ParentSidebar, {
    activePage: "attendance",
    sidebarOpen: sidebarOpen,
    unreadMsg: unreadMsg
  }), /*#__PURE__*/React.createElement("div", {
    className: `main-area ${sidebarOpen ? '' : 'collapsed'}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-title-wrap"
  }, /*#__PURE__*/React.createElement("h1", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  }), " Attendance", childName ? ` — ${childName}` : ''), /*#__PURE__*/React.createElement("div", {
    className: "page-sub"
  }, bootLoading ? 'Loading…' : childClass ? `View attendance history and statistics · ${childClass}` : 'View attendance history and statistics')), !bootLoading && selectedChild && /*#__PURE__*/React.createElement("div", {
    className: "header-actions"
  }, /*#__PURE__*/React.createElement(ChildSelector, {
    students: students,
    selectedChild: selectedChild,
    setSelectedChild: child => {
      setSelectedChild(child);
    }
  }))), bootErr && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-error"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), " ", bootErr), attErr && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-error"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), " ", attErr), bootLoading ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading\u2026")) : students.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      background: 'white',
      borderRadius: 14,
      border: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 52
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67",
    size: 18
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: 16
    }
  }, "No children linked to your account"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: 'var(--text-soft)',
      textAlign: 'center',
      maxWidth: 340
    }
  }, "Contact the school administrator to link your children to your parent account.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "stats-row"
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Days Attended",
    value: statAttended !== null ? statAttended : '—',
    barPct: statTotal ? Math.min(100, statAttended / statTotal * 100) : statAttended > 0 ? 80 : 0,
    color: "green",
    noteIcon: "\u2191",
    note: statLate > 0 ? `incl. ${statLate} late arrival${statLate !== 1 ? 's' : ''}` : statTotal ? `out of ${statTotal} days` : 'Academic year',
    noteType: "up",
    loading: statLoading
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Total Absent",
    value: statAbsent !== null ? statAbsent : '—',
    barPct: statTotal ? Math.min(100, statAbsent / statTotal * 100 * 5) : statAbsent > 0 ? 40 : 0,
    color: "red",
    noteIcon: null,
    note: yearStats ? 'Academic year' : 'This month',
    noteType: "",
    loading: statLoading
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Times Late",
    value: statLate !== null ? statLate : '—',
    barPct: statTotal ? Math.min(100, statLate / statTotal * 100 * 8) : statLate > 0 ? 30 : 0,
    color: "amber",
    noteIcon: null,
    note: statOnTime !== null ? `${statOnTime} on-time arrivals` : yearStats ? 'Academic year' : 'This month',
    noteType: "",
    loading: statLoading
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Attendance Rate",
    value: statRate !== null ? statRate + '%' : '—',
    barPct: statRate || 0,
    color: "blue",
    noteIcon: rn.icon,
    note: rn.text,
    noteType: rn.type,
    loading: statLoading
  })), /*#__PURE__*/React.createElement(AttCalendar, {
    year: viewYear,
    month: viewMonth,
    records: attData ? attData.records : [],
    loading: attLoading,
    onPrev: prevMonth,
    onNext: nextMonth,
    canNext: canGoNext
  }), !attLoading && attData && /*#__PURE__*/React.createElement(WeeklyBreakdown, {
    records: attData.records,
    year: viewYear,
    month: viewMonth,
    onPrevMonth: prevMonth,
    onNextMonth: canGoNext ? nextMonth : null
  }))))));
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/React.createElement(AttendanceApp, null));