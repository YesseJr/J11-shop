var useState = React.useState;
var useEffect = React.useEffect;

// ── Date helpers ─────────────────────────────────────────────────────────────
function fmtDate(iso) {
  if (!iso) return '—';
  var d = new Date(iso);
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}
function fmtDateShort(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short'
  });
}
function todayLabel() {
  return new Date().toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
}

// ── Subject emoji map ─────────────────────────────────────────────────────────
var SUBJECT_ICON = {
  'arithmetic': 'hash',
  'math': 'hash',
  'mathematics': 'hash',
  'communication': 'message',
  'english': 'book-open',
  'health': 'stethoscope',
  'environmental': 'leaf',
  'arts': 'palette',
  'culture': 'masks',
  'relation': 'handshake',
  'science': 'atom',
  'physical': 'football'
};
function subjectEmoji(sub) {
  // Returns Icon element for professional SVG display
  var name = 'book';
  if (sub) {
    var key = String(sub).toLowerCase();
    for (var k in SUBJECT_ICON) {
      if (key.indexOf(k) !== -1) {
        name = SUBJECT_ICON[k];
        break;
      }
    }
  }
  if (typeof Icon === 'function') return React.createElement(Icon, {
    name: name,
    size: 20
  });
  return '';
}

// ── PerformanceBar ────────────────────────────────────────────────────────────
function PerformanceBar(props) {
  var mounted = useState(false);
  var isMounted = mounted[0];
  var setMounted = mounted[1];
  useEffect(function () {
    var t = setTimeout(function () {
      setMounted(true);
    }, 100);
    return function () {
      clearTimeout(t);
    };
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    className: "perf-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "perf-top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "perf-label"
  }, props.label), /*#__PURE__*/React.createElement("span", {
    className: "perf-val",
    style: {
      color: props.color
    }
  }, props.value, "%")), /*#__PURE__*/React.createElement("div", {
    className: "perf-track"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'perf-fill ' + props.cls,
    style: {
      width: isMounted ? props.value + '%' : '0%'
    }
  })));
}

// ── ScheduleList ─────────────────────────────────────────────────────────────
function ScheduleList(props) {
  var items = props.items || [];
  if (!items.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "empty-schedule"
    }, /*#__PURE__*/React.createElement("div", {
      className: "empty-icon"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCED",
      size: 18
    })), /*#__PURE__*/React.createElement("div", null, "No upcoming homework assignments"));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "schedule-list"
  }, items.map(function (item) {
    var statusClass = item.hw_status === 'due_today' ? 'sch-due' : item.hw_status === 'upcoming' ? 'sch-upcoming' : 'sch-overdue';
    var badgeClass = item.hw_status === 'due_today' ? 'badge-due' : item.hw_status === 'upcoming' ? 'badge-upcoming' : 'badge-overdue';
    var badgeLabel = item.hw_status === 'due_today' ? 'Due Today' : item.hw_status === 'upcoming' ? 'Upcoming' : 'Overdue';
    return /*#__PURE__*/React.createElement("div", {
      key: item.id,
      className: 'schedule-item ' + statusClass
    }, /*#__PURE__*/React.createElement("div", {
      className: "schedule-emoji"
    }, subjectEmoji(item.subject)), /*#__PURE__*/React.createElement("div", {
      className: "schedule-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "schedule-subject"
    }, item.subject), /*#__PURE__*/React.createElement("div", {
      className: "schedule-desc"
    }, item.description), /*#__PURE__*/React.createElement("div", {
      className: "schedule-due"
    }, "Due: ", fmtDate(item.due_date))), /*#__PURE__*/React.createElement("span", {
      className: 'sch-badge ' + badgeClass
    }, badgeLabel));
  }));
}

// ── AnnouncementList ──────────────────────────────────────────────────────────
function AnnouncementList(props) {
  var items = props.items || [];
  if (!items.length) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        padding: '24px 0',
        color: '#94A3B8',
        fontSize: 13
      }
    }, "No announcements at the moment.");
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "ann-list"
  }, items.map(function (a) {
    return /*#__PURE__*/React.createElement("div", {
      key: a.id,
      className: 'ann-item ' + (a.is_urgent == 1 ? 'urgent' : 'normal')
    }, /*#__PURE__*/React.createElement("div", {
      className: "ann-title"
    }, a.is_urgent == 1 && /*#__PURE__*/React.createElement("span", {
      className: "ann-badge"
    }, "URGENT"), a.title), /*#__PURE__*/React.createElement("div", {
      className: "ann-date"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCC5",
      size: 18
    }), " ", fmtDate(a.created_at)));
  }));
}

// ── Main Dashboard ────────────────────────────────────────────────────────────
function TeacherDashboard() {
  var sessionS = useState(null);
  var session = sessionS[0];
  var setSession = sessionS[1];
  var dataS = useState(null);
  var data = dataS[0];
  var setData = dataS[1];
  var loadingS = useState(true);
  var loading = loadingS[0];
  var setLoading = loadingS[1];
  var sbSt = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  var sidebarOpen = sbSt[0];
  var setSidebarOpen = sbSt[1];

  // ── Welcome toast (shown once per browser session) ──────────────────────
  var toastVisS = useState(false);
  var toastVis = toastVisS[0];
  var setToastVis = toastVisS[1];
  var toastHideS = useState(false);
  var toastHiding = toastHideS[0];
  var setToastHiding = toastHideS[1];

  // ── Verify session + guard (works online and offline)
  useEffect(function () {
    fetch('/nsms/api/teacher.php?action=session', { credentials: 'same-origin', cache: 'no-store' }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) {
        // Try cached session for offline recovery
        try {
          var cached = sessionStorage.getItem('nsms_teacher_session');
          if (cached) {
            var cs = JSON.parse(cached);
            if (cs && cs.id) {
              setSession(cs);
              document.title = 'Dashboard — ' + (cs.full_name || 'Teacher');
              return;
            }
          }
        } catch (e) {}
        if (d.error === 'unauthorized') {
          window.location.href = '/nsms/public/index.html?login=1';
        }
        setLoading(false);
        return;
      }
      // First-login guard (skip when offline — setup needs server)
      if (d.data.password_changed == 0 && !d.data.offline_mode) {
        window.location.href = '/nsms/public/teacher/setup.html';
        return;
      }
      setSession(d.data);
      try { sessionStorage.setItem('nsms_teacher_session', JSON.stringify(d.data)); } catch (e) {}
      document.title = 'Dashboard — ' + (d.data.full_name || 'Teacher');

      if (!sessionStorage.getItem('nsms_teacher_welcomed')) {
        sessionStorage.setItem('nsms_teacher_welcomed', '1');
        setToastVis(true);
        setTimeout(function () { setToastHiding(true); }, 3500);
        setTimeout(function () { setToastVis(false); setToastHiding(false); }, 4200);
      }
    }).catch(function () {
      try {
        var cached2 = sessionStorage.getItem('nsms_teacher_session');
        if (cached2) {
          var cs2 = JSON.parse(cached2);
          if (cs2 && cs2.id) {
            setSession(cs2);
            document.title = 'Dashboard — ' + (cs2.full_name || 'Teacher');
            return;
          }
        }
      } catch (e) {}
      setLoading(false);
    });
  }, []);

  // ── Fetch dashboard data (timeout so offline never hangs on spinner)
  useEffect(function () {
    if (!session) return;
    var cancelled = false;
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = setTimeout(function () {
      try { if (ctrl) ctrl.abort(); } catch (e) {}
    }, 4000);
    var opts = { credentials: 'same-origin', cache: 'no-store' };
    if (ctrl) opts.signal = ctrl.signal;
    fetch('/nsms/api/teacher.php?action=dashboard' + (session.class_id ? ('&class_id=' + encodeURIComponent(session.class_id)) : ''), opts).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (cancelled) return;
      if (d && d.success && d.data) {
        var payload = d.data;
        if (!Array.isArray(payload.announcements)) payload.announcements = [];
        if (!Array.isArray(payload.schedule)) payload.schedule = [];
        if (!payload.performance) payload.performance = { attendance_rate: 0, homework_completion: 0, overall_progress: 0 };
        // Prefer session class name if API omitted
        if (!payload.class_name && session.class_name) payload.class_name = session.class_name;
        if (!payload.class_id && session.class_id) payload.class_id = session.class_id;
        setData(payload);
      } else {
        setData({
          day_info: { type: 'school_day', name: null },
          class_id: session.class_id || null,
          class_name: session.class_name || null,
          total_students: 0,
          present_today: 0,
          pending_homework: 0,
          unread_messages: 0,
          announcements: [],
          schedule: [],
          performance: { attendance_rate: 0, homework_completion: 0, overall_progress: 0 },
          offline_mode: true
        });
      }
    }).catch(function () {
      if (cancelled) return;
      setData({
        day_info: { type: 'school_day', name: null },
        class_id: session.class_id || null,
        class_name: session.class_name || null,
        total_students: 0,
        present_today: 0,
        pending_homework: 0,
        unread_messages: 0,
        announcements: [],
        schedule: [],
        performance: { attendance_rate: 0, homework_completion: 0, overall_progress: 0 },
        offline_mode: true
      });
    }).finally(function () {
      clearTimeout(timer);
      if (!cancelled) setLoading(false);
    });
    return function () { cancelled = true; clearTimeout(timer); try { if (ctrl) ctrl.abort(); } catch (e) {} };
  }, [session]);
  var firstName = session && session.full_name ? String(session.full_name).split(' ')[0] : '…';

  useEffect(function () {
    if (!(data && data.offline_mode)) return;
    if (document.getElementById('nsms-teacher-offline-banner')) return;
    var b = document.createElement('div');
    b.id = 'nsms-teacher-offline-banner';
    b.style.cssText = 'background:linear-gradient(135deg,#EFF6FF,#F0FDF4);border:1px solid #93C5FD;border-left:4px solid #2563EB;border-radius:12px;padding:12px 14px;margin:0 0 16px;color:#1E3A5F;font-size:13px;font-weight:600;display:flex;align-items:center;gap:10px';
    b.innerHTML = '<span style="width:8px;height:8px;border-radius:50%;background:#F59E0B;box-shadow:0 0 0 3px rgba(245,158,11,.25)"></span><span>Offline — dashboard is using local school data. Changes will sync when you reconnect.</span>';
    var host = document.querySelector('.page-header') || document.querySelector('#root');
    if (host && host.parentNode) host.parentNode.insertBefore(b, host.nextSibling);
  }, [data]);

  var perf = data ? data.performance : {
    attendance_rate: 0,
    homework_completion: 0,
    overall_progress: 0
  };
  var anns = data && Array.isArray(data.announcements) ? data.announcements : [];
  var schedule = data && Array.isArray(data.schedule) ? data.schedule : [];

  // ── Day-off detection (weekend / holiday) ─────────────────────────────
  var dayInfo = data && data.day_info ? data.day_info : {
    type: 'school_day',
    name: null
  };
  var isOffDay = dayInfo.type !== 'school_day';
  var isWeekend = dayInfo.type === 'weekend';
  var isPubHol = dayInfo.type === 'public_holiday';
  var isOfflineDash = !!(data && data.offline_mode);

  // Icon, headline, sub-label for the attendance card when school is off
  var offDayIcon = isWeekend ? /*#__PURE__*/React.createElement(Icon, {
    name: "sunrise",
    size: 22
  }) : isPubHol ? /*#__PURE__*/React.createElement(Icon, {
    name: "party",
    size: 22
  }) : /*#__PURE__*/React.createElement(Icon, {
    name: "school",
    size: 22
  });
  var offDayHeadline = isWeekend ? "It's Weekend" : 'Today is a Holiday';
  var offDayName = dayInfo.name || (isPubHol ? 'Public Holiday' : 'School Holiday');

  // ── Stat card helper
  function StatCard(props) {
    return /*#__PURE__*/React.createElement("div", {
      className: 'stat-card ' + props.cls
    }, /*#__PURE__*/React.createElement("div", {
      className: "sc-icon"
    }, props.icon), /*#__PURE__*/React.createElement("div", {
      className: "sc-value"
    }, loading ? /*#__PURE__*/React.createElement("span", {
      className: "shimmer",
      style: {
        display: 'inline-block',
        width: 48,
        height: 36
      }
    }) : props.value), /*#__PURE__*/React.createElement("div", {
      className: "sc-label"
    }, props.label), props.sub && /*#__PURE__*/React.createElement("div", {
      className: "sc-sub"
    }, props.sub));
  }
  var noClass = !loading && session && !session.class_id;
  return /*#__PURE__*/React.createElement("div", null, toastVis && /*#__PURE__*/React.createElement("div", {
    className: 'welcome-toast' + (toastHiding ? ' hiding' : '')
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF89",
    size: 18
  }), " Welcome back, ", firstName, "!"), /*#__PURE__*/React.createElement(TeacherNavbar, {
    activePage: "dashboard",
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(TeacherSidebar, {
    sidebarOpen: sidebarOpen,
    activePage: "dashboard"
  }), /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (sidebarOpen ? '' : ' collapsed')
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "page-title"
  }, "Welcome, ", firstName, "! ", /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC4B",
    size: 18
  }), session && session.class_name && /*#__PURE__*/React.createElement("span", {
    className: "class-pill",
    style: {
      background: session.class_color || '#2563EB',
      marginLeft: 14,
      fontSize: 13,
      verticalAlign: 'middle'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  }), " ", session.class_name)), /*#__PURE__*/React.createElement("div", {
    className: "page-sub"
  }, "Here's what's happening with your class today")), /*#__PURE__*/React.createElement("div", {
    className: "header-date"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      color: 'var(--text-mid)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  }), " ", todayLabel()), data && data.present_today > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#10B981',
      marginTop: 2
    }
  }, data.present_today, " / ", data.total_students, " students present"))), noClass && /*#__PURE__*/React.createElement("div", {
    className: "no-class-notice"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ncn-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ncn-text"
  }, "No class assigned yet"), /*#__PURE__*/React.createElement("div", {
    className: "ncn-sub"
  }, "Please contact the admin to assign you to a class. Some features won't be available until then."))), /*#__PURE__*/React.createElement("div", {
    className: "stats-grid"
  }, /*#__PURE__*/React.createElement(StatCard, {
    cls: "sc-blue",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "users",
      size: 22
    }),
    value: data ? data.total_students : '—',
    label: "Total Students",
    sub: session && session.class_name ? session.class_name : 'Not assigned'
  }), /*#__PURE__*/React.createElement(StatCard, {
    cls: "sc-green",
    icon: isOffDay ? offDayIcon : /*#__PURE__*/React.createElement(Icon, {
      name: "check-circle",
      size: 22
    }),
    value: isOffDay ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "sc-offday-msg"
    }, offDayHeadline), /*#__PURE__*/React.createElement("div", {
      className: "sc-offday-name"
    }, offDayName)) : data ? data.present_today : '—',
    label: isOffDay ? 'No Attendance Today' : 'Present Today',
    sub: isOffDay ? 'School is not in session' : data && data.total_students > 0 ? Math.round(data.present_today / data.total_students * 100) + '% attendance' : 'No data yet'
  }), /*#__PURE__*/React.createElement(StatCard, {
    cls: "sc-amber",
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u270F",
      size: 16
    }),
    value: data ? data.pending_homework : '—',
    label: "Active Homework",
    sub: "Due today or upcoming"
  }), /*#__PURE__*/React.createElement(StatCard, {
    cls: "sc-purple",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "message",
      size: 22
    }),
    value: data ? data.unread_messages : '—',
    label: "Unread Messages",
    sub: data && data.unread_messages > 0 ? 'Tap to view inbox' : 'All caught up!'
  })), /*#__PURE__*/React.createElement("div", {
    className: "two-col"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  }), " Homework Schedule"), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/teacher/homework.html",
    style: {
      fontSize: 12.5,
      color: 'var(--blue)',
      fontWeight: 700,
      textDecoration: 'none'
    }
  }, "+ Post Homework")), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        height: 72,
        borderRadius: 10
      },
      className: "shimmer"
    });
  })) : /*#__PURE__*/React.createElement(ScheduleList, {
    items: schedule
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  }), " Class Performance")), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "shimmer",
      style: {
        height: 36,
        borderRadius: 6
      }
    });
  })) : /*#__PURE__*/React.createElement("div", {
    className: "perf-list"
  }, /*#__PURE__*/React.createElement(PerformanceBar, {
    label: "Attendance Rate",
    value: perf.attendance_rate,
    cls: "pf-blue",
    color: "#2563EB"
  }), /*#__PURE__*/React.createElement(PerformanceBar, {
    label: "Homework Completion",
    value: perf.homework_completion,
    cls: "pf-green",
    color: "#10B981"
  }), /*#__PURE__*/React.createElement(PerformanceBar, {
    label: "Overall Progress",
    value: perf.overall_progress,
    cls: "pf-purple",
    color: "#7C3AED"
  })))), /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE2",
    size: 18
  }), " Announcements"), anns.length > 0 && /*#__PURE__*/React.createElement("span", {
    className: "panel-badge"
  }, anns.length)), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, [1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "shimmer",
      style: {
        height: 56,
        borderRadius: 9
      }
    });
  })) : /*#__PURE__*/React.createElement(AnnouncementList, {
    items: anns
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "quick-actions"
  }, /*#__PURE__*/React.createElement("div", {
    className: "qa-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  }), " Quick Actions"), /*#__PURE__*/React.createElement("div", {
    className: "qa-grid"
  }, /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/teacher/attendance.html",
    className: "qa-btn"
  }, /*#__PURE__*/React.createElement("span", {
    className: "qa-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "qa-label"
  }, "Mark Attendance"), /*#__PURE__*/React.createElement("div", {
    className: "qa-sub"
  }, "Today's class roll"))), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/teacher/homework.html",
    className: "qa-btn"
  }, /*#__PURE__*/React.createElement("span", {
    className: "qa-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "qa-label"
  }, "Post Homework"), /*#__PURE__*/React.createElement("div", {
    className: "qa-sub"
  }, "Assign to your class"))), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/teacher/reports.html",
    className: "qa-btn"
  }, /*#__PURE__*/React.createElement("span", {
    className: "qa-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "qa-label"
  }, "Create Report"), /*#__PURE__*/React.createElement("div", {
    className: "qa-sub"
  }, "Term or weekly report"))), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/teacher/my-class.html",
    className: "qa-btn"
  }, /*#__PURE__*/React.createElement("span", {
    className: "qa-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "qa-label"
  }, "My Class"), /*#__PURE__*/React.createElement("div", {
    className: "qa-sub"
  }, "View all students"))), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/teacher/gradebook.html",
    className: "qa-btn"
  }, /*#__PURE__*/React.createElement("span", {
    className: "qa-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCD2",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "qa-label"
  }, "Gradebook"), /*#__PURE__*/React.createElement("div", {
    className: "qa-sub"
  }, "Scores & grades"))), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/teacher/teacher-pulse.html",
    className: "qa-btn"
  }, /*#__PURE__*/React.createElement("span", {
    className: "qa-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "qa-label"
  }, "J11 Pulse"), /*#__PURE__*/React.createElement("div", {
    className: "qa-sub"
  }, "Messages & alerts")))))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(TeacherDashboard, null));