const {
  useState,
  useEffect,
  useRef
} = React;

/** Growth/delta display: arrows instead of +/- */
function formatGrowth(value) {
  if (value == null || value === '' || isNaN(Number(value))) {
    return { text: '—', dir: 'flat', cls: 'trend-flat' };
  }
  const n = Number(value);
  const abs = Math.abs(n);
  const text = abs % 1 === 0 ? String(abs) : abs.toFixed(1);
  if (n > 0) return { text: text + '%', dir: 'up', cls: 'trend-up', arrow: '↑' };
  if (n < 0) return { text: text + '%', dir: 'down', cls: 'trend-down', arrow: '↓' };
  return { text: '0%', dir: 'flat', cls: 'trend-flat', arrow: '→' };
}
function AnalyticsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  const [loading, setLoading] = useState(true);
  const [classDistribution, setClassDistribution] = useState([]);
  const [enrollmentTrends, setEnrollmentTrends] = useState([]);
  const [overview, setOverview] = useState(null);
  const [period, setPeriod] = useState('30');
  useEffect(() => {
    loadData(period);
  }, [period]);
  const loadData = async p => {
    setLoading(true);
    try {
      const [distRes, trendsRes, overviewRes] = await Promise.all([fetch('/nsms/api/analytics.php?action=class_distribution'), fetch(`/nsms/api/analytics.php?action=enrollment_trends&period=${p}`), fetch(`/nsms/api/analytics.php?action=overview&period=${p}`)]);
      const [distData, trendsData, overviewData] = await Promise.all([distRes.json(), trendsRes.json(), overviewRes.json()]);
      if (distData.success) setClassDistribution(distData.data);
      if (trendsData.success) setEnrollmentTrends(trendsData.data);
      if (overviewData.success) setOverview(overviewData.data);
    } catch (err) {
      console.error('Error loading analytics:', err);
    } finally {
      setLoading(false);
    }
  };
  const handleLogout = async () => {
    try {
      await fetch('/nsms/api/auth.php?action=logout', {
        method: 'POST'
      });
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      window.location.href = '/nsms/public/index.html';
    }
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NSMSNavbar, {
    activePage: "analytics",
    onLogout: handleLogout,
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement(NSMSSidebar, {
    activePage: "analytics",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "nsms-main",
    style: {
      marginLeft: sidebarOpen ? '220px' : '64px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-title-section"
  }, /*#__PURE__*/React.createElement("h1", null, "Analytics Dashboard"), /*#__PURE__*/React.createElement("p", {
    className: "page-subtitle"
  }, "Performance Insights & Trends"))), /*#__PURE__*/React.createElement("select", {
    className: "period-selector",
    value: period,
    onChange: e => setPeriod(e.target.value),
    style: {
      appearance: 'none',
      WebkitAppearance: 'none',
      paddingRight: '28px',
      background: "white url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2364748B' d='M6 8L1 3h10z'/%3E%3C/svg%3E\") no-repeat right 10px center"
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "7"
  }, "Last 7 Days"), /*#__PURE__*/React.createElement("option", {
    value: "30"
  }, "Last 30 Days"), /*#__PURE__*/React.createElement("option", {
    value: "90"
  }, "Last 3 Months"), /*#__PURE__*/React.createElement("option", {
    value: "180"
  }, "Last 6 Months")), loading ? /*#__PURE__*/React.createElement("div", {
    className: "loading"
  }, /*#__PURE__*/React.createElement("div", {
    className: "loading-spinner"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: '20px'
    }
  }, "Loading analytics\u2026")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "stats-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-card blue"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, overview != null ? (() => {
  const g = formatGrowth(overview.enrollment_growth);
  return /*#__PURE__*/React.createElement("span", {
    className: "stat-delta " + g.cls
  }, /*#__PURE__*/React.createElement("span", {
    className: "stat-arrow",
    "aria-hidden": "true"
  }, g.arrow || ''), " ", g.text);
})() : '—'), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Enrollment Growth"), /*#__PURE__*/React.createElement("div", {
    className: "stat-trend"
  }, overview != null && Number(overview.enrollment_growth) < 0 ? /*#__PURE__*/React.createElement("span", {
    className: "trend-down"
  }, "↓ down vs previous ", period, " days") : overview != null && Number(overview.enrollment_growth) > 0 ? /*#__PURE__*/React.createElement("span", {
    className: "trend-up"
  }, "↑ up vs previous ", period, " days") : /*#__PURE__*/React.createElement("span", null, "vs previous ", period, " days"))), /*#__PURE__*/React.createElement("div", {
    className: "stat-card green"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, overview != null ? overview.avg_attendance : '—', "%"), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Attendance Rate"), /*#__PURE__*/React.createElement("div", {
    className: "stat-trend"
  }, "Last ", period, " days")), /*#__PURE__*/React.createElement("div", {
    className: "stat-card purple"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, overview != null ? overview.total_students : '—'), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Total Students"), /*#__PURE__*/React.createElement("div", {
    className: "stat-trend"
  }, (overview != null && Number(overview.students_this_month) > 0 ? "↑ " : overview != null && Number(overview.students_this_month) < 0 ? "↓ " : "→ "), overview != null ? Math.abs(Number(overview.students_this_month)) : '—', " enrolled in ", period, "d")), /*#__PURE__*/React.createElement("div", {
    className: "stat-card orange"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, overview != null ? overview.fee_collection_rate : '—', "%"), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Fee Collection Rate"), /*#__PURE__*/React.createElement("div", {
    className: "stat-trend"
  }, "TSh ", overview != null ? (Number(overview.collected_amount) / 1000000).toFixed(1) : '—', "M in ", period, " days"))), /*#__PURE__*/React.createElement("div", {
    className: "chart-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "chart-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "chart-header"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC8",
    size: 18
  })), /*#__PURE__*/React.createElement("h2", {
    className: "chart-title"
  }, "Student Enrollment Trend")), enrollmentTrends.length > 0 ? (() => {
    const maxCount = Math.max(...enrollmentTrends.map(t => Number(t.count)), 1);
    const vbW = 500;
    const chartH = 160;
    const padL = 10;
    const padR = 10;
    const n = enrollmentTrends.length;
    const slot = (vbW - padL - padR) / n;
    const barW = Math.min(slot * 0.5, 40);
    return /*#__PURE__*/React.createElement("svg", {
      width: "100%",
      viewBox: `0 0 ${vbW} ${chartH + 44}`,
      preserveAspectRatio: "xMidYMid meet"
    }, enrollmentTrends.map((t, i) => {
      const count = Number(t.count);
      const barH = Math.max(count / maxCount * chartH, 4);
      const cx = padL + slot * i + slot / 2;
      const x = cx - barW / 2;
      const y = chartH - barH;
      return /*#__PURE__*/React.createElement("g", {
        key: i
      }, /*#__PURE__*/React.createElement("rect", {
        x: x,
        y: y,
        width: barW,
        height: barH,
        rx: "4",
        fill: "#2563EB",
        opacity: "0.85"
      }), /*#__PURE__*/React.createElement("text", {
        x: cx,
        y: y - 6,
        textAnchor: "middle",
        fontSize: "11",
        fill: "#1E293B",
        fontWeight: "600"
      }, count), /*#__PURE__*/React.createElement("text", {
        x: cx,
        y: chartH + 18,
        textAnchor: "middle",
        fontSize: "11",
        fill: "#64748B"
      }, t.month_name));
    }));
  })() : /*#__PURE__*/React.createElement("div", {
    className: "chart-placeholder"
  }, "No enrollment data for the last 6 months")), /*#__PURE__*/React.createElement("div", {
    className: "chart-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "chart-header"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  })), /*#__PURE__*/React.createElement("h2", {
    className: "chart-title"
  }, "Class Distribution")), classDistribution.length > 0 ? classDistribution.map((classItem, i) => {
    const studentCount = Number(classItem.student_count);
    const capacity = Number(classItem.capacity);
    const pct = capacity > 0 ? Math.min(studentCount / capacity * 100, 100) : 0;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "class-item"
    }, /*#__PURE__*/React.createElement("div", {
      className: "class-color",
      style: {
        background: classItem.class_color || '#2563EB'
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "class-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "class-name"
    }, classItem.class_name), /*#__PURE__*/React.createElement("div", {
      className: "class-bar"
    }, /*#__PURE__*/React.createElement("div", {
      className: "class-fill",
      style: {
        width: `${pct}%`,
        background: classItem.class_color || '#2563EB'
      }
    }))), /*#__PURE__*/React.createElement("div", {
      className: "class-count"
    }, studentCount, " / ", capacity));
  }) : /*#__PURE__*/React.createElement("div", {
    className: "chart-placeholder"
  }, "No class data available"))), /*#__PURE__*/React.createElement("div", {
    className: "chart-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "chart-header"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD11",
    size: 18
  })), /*#__PURE__*/React.createElement("h2", {
    className: "chart-title"
  }, "Key Performance Indicators")), overview != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr',
      gap: '20px',
      padding: '8px 0'
    }
  }, [{
    label: 'Total Students',
    value: overview.total_students,
    color: '#2563EB'
  }, {
    label: 'Enrolled This Month',
    value: overview.students_this_month,
    color: '#10B981'
  }, {
    label: 'Total Teachers',
    value: overview.total_teachers,
    color: '#8B5CF6'
  }, {
    label: 'Attendance Rate',
    value: overview.avg_attendance + '%',
    color: '#10B981'
  }, {
    label: 'Fee Collection Rate',
    value: overview.fee_collection_rate + '%',
    color: '#F59E0B'
  }, {
    label: 'Collected (TSh)',
    value: (Number(overview.collected_amount) / 1000000).toFixed(1) + 'M',
    color: '#F59E0B'
  }].map((kpi, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: '#F8FAFC',
      borderRadius: '10px',
      padding: '16px',
      borderLeft: `4px solid ${kpi.color}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '22px',
      fontWeight: '700',
      color: kpi.color
    }
  }, kpi.value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      color: '#64748B',
      marginTop: '4px'
    }
  }, kpi.label)))) : /*#__PURE__*/React.createElement("div", {
    className: "chart-placeholder"
  }, "No KPI data available")))));
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/React.createElement(AnalyticsPage, null));