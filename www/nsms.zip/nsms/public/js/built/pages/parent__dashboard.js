/* ── Helpers ── */
function fmt(d) {
  if (!d) return '';
  var dt = new Date(d);
  var M = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return dt.getDate() + ' ' + M[dt.getMonth()] + ' ' + dt.getFullYear();
}
function daysUntil(dateStr) {
  var diff = Math.round((new Date(dateStr) - new Date()) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Tomorrow';
  if (diff < 0) return 'Overdue';
  return 'In ' + diff + ' days';
}
function attColor(rate) {
  if (rate >= 90) return '#10B981';
  if (rate >= 75) return '#F59E0B';
  return '#EF4444';
}

/* ── Fee stat card mini ring ── */
function FeeRingSmall(props) {
  var pct = props.pct || 0;
  var r = 20;
  var circ = 2 * Math.PI * r;
  var dash = circ - pct / 100 * circ;
  return /*#__PURE__*/React.createElement("div", {
    className: "sc-fee-ring"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "52",
    height: "52",
    viewBox: "0 0 52 52"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "26",
    cy: "26",
    r: r,
    fill: "none",
    stroke: "rgba(255,255,255,.25)",
    strokeWidth: "5"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "26",
    cy: "26",
    r: r,
    fill: "none",
    stroke: "rgba(255,255,255,.9)",
    strokeWidth: "5",
    strokeLinecap: "round",
    strokeDasharray: circ,
    strokeDashoffset: dash,
    style: {
      transform: 'rotate(-90deg)',
      transformOrigin: '26px 26px',
      transition: 'stroke-dashoffset .8s ease'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "sc-fee-pct"
  }, pct, "%"));
}

/* ── Stat card ── */
function StatCard(props) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'stat-card ' + props.cls,
    onClick: props.onClick || undefined,
    style: props.onClick ? {
      cursor: 'pointer'
    } : {}
  }, props.children || /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "sc-value"
  }, props.value), /*#__PURE__*/React.createElement("div", {
    className: "sc-label"
  }, props.label), props.sub && /*#__PURE__*/React.createElement("div", {
    className: "sc-sub"
  }, props.sub)));
}

/* ── Homework item ── */
function HomeworkItem(props) {
  var hw = props.hw;
  var children = props.children || [];
  var useState = React.useState;
  var ackSt = useState(hw.acknowledged_by_students || []);
  var acked = ackSt[0];
  var setAcked = ackSt[1];
  var loadSt = useState({});
  var loadMap = loadSt[0];
  var setLoadMap = loadSt[1];
  var relevantKids = children.filter(function (c) {
    return c.class_id === hw.class_id;
  });
  function acknowledge(studentId) {
    if (acked.indexOf(studentId) !== -1) return;
    setLoadMap(function (m) {
      var n = Object.assign({}, m);
      n[studentId] = true;
      return n;
    });
    fetch('/nsms/api/parent-panel.php?action=acknowledge_homework', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        homework_id: hw.id,
        student_id: studentId
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setAcked(function (a) {
        return a.concat([studentId]);
      });
    }).catch(function () {}).finally(function () {
      setLoadMap(function (m) {
        var n = Object.assign({}, m);
        delete n[studentId];
        return n;
      });
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "hw-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hw-subject-badge"
  }, hw.subject), /*#__PURE__*/React.createElement("span", {
    className: "hw-due"
  }, "Due: ", daysUntil(hw.due_date)), /*#__PURE__*/React.createElement("span", {
    className: 'hw-status-badge badge-' + hw.hw_status,
    style: {
      marginLeft: 4
    }
  }, hw.due_label), relevantKids.map(function (kid) {
    var isDone = acked.indexOf(kid.id) !== -1;
    var isLoading = !!loadMap[kid.id];
    return /*#__PURE__*/React.createElement("button", {
      key: kid.id,
      className: 'hw-ack-btn ' + (isDone ? 'ack-done' : isLoading ? 'ack-loading' : 'ack-todo'),
      onClick: function () {
        acknowledge(kid.id);
      },
      disabled: isDone || isLoading
    }, isDone ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 16
    }), "Acknowledged") : isLoading ? '…' : /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 16
    }), "Acknowledge"));
  })), /*#__PURE__*/React.createElement("div", {
    className: "hw-desc"
  }, hw.description), /*#__PURE__*/React.createElement("span", {
    className: "hw-class-tag"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  }), " ", hw.class_name));
}

/* ── Announcement ── */
function AnnouncementItem(props) {
  var ann = props.ann;
  var idx = props.idx || 0;
  var cls = ann.is_urgent ? 'ann-urgent' : 'ann-normal-' + idx % 4;
  return /*#__PURE__*/React.createElement("div", {
    className: 'ann-item ' + cls
  }, /*#__PURE__*/React.createElement("div", {
    className: "ann-title"
  }, ann.is_urgent ? /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDEA8",
    size: 16
  }) : '', ann.title), /*#__PURE__*/React.createElement("div", {
    className: "ann-body"
  }, ann.content), /*#__PURE__*/React.createElement("div", {
    className: "ann-date"
  }, fmt(ann.created_at)));
}

/* ── Attendance panel ── */
function AttendancePanel(props) {
  var children = props.children || [];
  var loading = props.loading;
  if (loading) return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, [1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "shimmer",
      style: {
        height: 52,
        borderRadius: 10
      }
    });
  }));
  if (!children.length) return /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 13,
      padding: '8px 0'
    }
  }, "No children enrolled.");
  var bgColors = ['#10B981', '#3B82F6', '#F59E0B', '#8B5CF6'];
  return /*#__PURE__*/React.createElement("div", null, children.map(function (child) {
    var rate = child.attendance_rate || 0;
    var color = attColor(rate);
    var todayStatus = child.today_attendance;
    var initials = child.student_name ? child.student_name.split(' ').map(function (w) {
      return w[0];
    }).join('').toUpperCase().slice(0, 2) : '?';
    return /*#__PURE__*/React.createElement("div", {
      key: child.id,
      className: "att-child-row"
    }, /*#__PURE__*/React.createElement("div", {
      className: "att-child-avatar",
      style: {
        background: bgColors[child.id % bgColors.length]
      }
    }, child.photo_url ? /*#__PURE__*/React.createElement("img", {
      src: child.photo_url,
      alt: "",
      onError: function (e) {
        e.target.style.display = 'none';
      }
    }) : initials), /*#__PURE__*/React.createElement("div", {
      className: "att-child-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "att-child-name"
    }, child.student_name), /*#__PURE__*/React.createElement("div", {
      className: "att-child-class"
    }, child.class_name, todayStatus ? /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 8,
        color: todayStatus === 'present' ? '#10B981' : todayStatus === 'late' ? '#F59E0B' : '#EF4444',
        fontWeight: 600
      }
    }, "\u2022 ", todayStatus.charAt(0).toUpperCase() + todayStatus.slice(1), " today") : /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 8,
        color: 'var(--text-muted)',
        fontWeight: 500
      }
    }, "\u2022 Not yet marked"))), /*#__PURE__*/React.createElement("div", {
      className: "att-rate-bar"
    }, /*#__PURE__*/React.createElement("div", {
      className: "att-rate-val",
      style: {
        color
      }
    }, rate, "%"), /*#__PURE__*/React.createElement("div", {
      className: "att-rate-track"
    }, /*#__PURE__*/React.createElement("div", {
      className: "att-rate-fill",
      style: {
        width: rate + '%',
        background: color
      }
    }))));
  }));
}

/* ── Fee panel — FIXED ──
   Uses the ledger-backed fee_status + pct_paid from the backend.
   next_installment is shown as a hint but the authoritative "Paid/Pending"
   badge comes from fee_status (which the fixed PHP now derives from
   fee_payments ledger vs fee_structure expected total).
   pct_paid is also now returned by the PHP so we can show a progress bar. */
function FeePanel(props) {
  var children = props.children || [];
  var feeStatus = props.feeStatus || 'n/a'; // top-level status from PHP
  var loading = props.loading;
  if (loading) return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, [1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "shimmer",
      style: {
        height: 52,
        borderRadius: 10
      }
    });
  }));
  if (!children.length) return /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, "No fee data.");
  return /*#__PURE__*/React.createElement("div", null, children.map(function (child) {
    /* ── Determine badge per child from their individual fee data ──
       The PHP returns next_installment from fee_installments. But
       the top-level feeStatus (from fee_payments ledger) is the
       truth. If the overall status is 'paid', every child is paid.
       If 'pending', show per-child detail where available.
       This prevents the "shows Paid when no installment rows exist"
       bug AND the "shows Pending when fees were paid in cash" bug. */
    var badgeCls, badgeLabel;
    var inst = child.next_installment;
    var pct = typeof child.fee_pct === 'number' ? child.fee_pct : null;
    if (feeStatus === 'n/a') {
      badgeCls = 'fee-badge fee-na';
      badgeLabel = 'No fees set';
    } else if (feeStatus === 'paid') {
      /* Ledger confirms fully paid — override any stale installment row */
      badgeCls = 'fee-badge fee-paid';
      badgeLabel = /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u2713",
        size: 16
      }), "Fully Paid");
    } else if (!inst) {
      /* Overall status is pending but this child has no unpaid
         installment row (cash payments may not have seeded rows yet) */
      badgeCls = 'fee-badge fee-pending';
      badgeLabel = 'Pending';
    } else if (inst.status === 'partial') {
      badgeCls = 'fee-badge fee-pending';
      badgeLabel = 'Partial — Inst. #' + inst.installment_no;
    } else {
      badgeCls = 'fee-badge fee-pending';
      badgeLabel = 'Inst. #' + inst.installment_no + ' due';
    }
    var barColor = feeStatus === 'paid' ? '#10B981' : '#F59E0B';
    return /*#__PURE__*/React.createElement("div", {
      key: child.id,
      className: "fee-row"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "fee-child-name"
    }, child.student_name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--text-muted)',
        marginTop: 1
      }
    }, child.class_name)), pct !== null && /*#__PURE__*/React.createElement("div", {
      className: "fee-bar-wrap",
      style: {
        flex: '0 0 60px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        textAlign: 'right',
        color: barColor
      }
    }, pct, "%"), /*#__PURE__*/React.createElement("div", {
      className: "fee-bar-track"
    }, /*#__PURE__*/React.createElement("div", {
      className: "fee-bar-fill",
      style: {
        width: pct + '%',
        background: barColor
      }
    }))), /*#__PURE__*/React.createElement("span", {
      className: badgeCls
    }, badgeLabel));
  }));
}

/* ═══════════════════════════════════════════════════════════
   PARENT DASHBOARD
═══════════════════════════════════════════════════════════ */
function ParentDashboard() {
  var useState = React.useState;
  var useEffect = React.useEffect;
  var sbSt = useState(false);
  var sidebarOpen = sbSt[0];
  var setSidebarOpen = sbSt[1];
  var loadSt = useState(true);
  var loading = loadSt[0];
  var setLoading = loadSt[1];
  var dataSt = useState(null);
  var data = dataSt[0];
  var setData = dataSt[1];
  var errSt = useState(null);
  var error = errSt[0];
  var setError = errSt[1];
  var selKidSt = useState(null);
  var selectedKid = selKidSt[0];
  var setSelectedKid = selKidSt[1];
  var feePctSt = useState(null);
  var feePct = feePctSt[0];
  var setFeePct = feePctSt[1];
  function load() {
    setLoading(true);
    setError(null);
    fetch('/nsms/api/parent-panel.php?action=dashboard').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setData(d.data);
        if (d.data.children && d.data.children.length > 0 && !selectedKid) {
          setSelectedKid(d.data.children[0]);
        }
        /* Derive pct_paid per child from fee_by_class or fee_summary
           We do a best-effort fetch from the payment gateway summary
           to get real percentages. Falls back silently. */
        fetchFeePct(d.data.children || []);
      } else if (d.error === 'unauthorized') {
        window.location.href = '/nsms/public/index.html';
      } else {
        setError(d.error || 'Failed to load dashboard data.');
      }
    }).catch(function () {
      setError('Network error. Please refresh.');
    }).finally(function () {
      setLoading(false);
    });
  }
  function fetchFeePct(kids) {
    if (!kids.length) return;
    /* Fetch the real fee summary so we can show accurate per-child
       progress percentages. Uses the payment gateway's fee_summary
       endpoint which reads from fee_payments (the authoritative ledger). */
    fetch('/nsms/api/payment-gateway.php?action=fee_summary').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success || !Array.isArray(d.data)) return;
      var map = {};
      d.data.forEach(function (s) {
        if (s.grand_due > 0) {
          map[s.student_id] = Math.min(100, Math.round(s.grand_paid / s.grand_due * 100));
        } else {
          map[s.student_id] = 0;
        }
      });
      setFeePct(map);
    }).catch(function () {}); // non-critical — fee panel still works without it
  }
  useEffect(function () {
    fetch('/nsms/api/parent-panel.php?action=session').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) window.location.href = '/nsms/public/index.html?login=1';else if (d.data && d.data.password_changed != 1) window.location.href = '/nsms/public/parent/setup.html';
    }).catch(function () {
      window.location.href = '/nsms/public/index.html?login=1';
    });
  }, []);
  useEffect(function () {
    load();
  }, []);
  var children = data ? data.children || [] : [];
  var homework = data ? data.homework || [] : [];
  var anns = data ? data.announcements || [] : [];
  var calEvents = data ? data.calendar_events || [] : [];
  var attRate = data ? data.attendance_rate || 0 : 0;
  var hwToday = data ? data.homework_today || 0 : 0;
  var unreadMsg = data ? data.unread_messages || 0 : 0;
  var feeStatus = data ? data.fee_status || 'n/a' : 'n/a';
  var dayInfo = data ? data.day_info || {
    type: 'school_day',
    name: null
  } : {
    type: 'school_day',
    name: null
  };

  /* Annotate children with pct from fee summary */
  var annotatedChildren = children.map(function (c) {
    return Object.assign({}, c, {
      fee_pct: feePct && feePct[c.id] != null ? feePct[c.id] : null
    });
  });

  /* ── Fee stat card values ── */
  var feeDisplay, feeCardCls, feeSub, feeRingPct;
  if (feeStatus === 'paid') {
    feeDisplay = 'Paid';
    feeCardCls = 'sc-green';
    feeSub = 'All fees settled';
    feeRingPct = 100;
  } else if (feeStatus === 'pending') {
    feeDisplay = 'Pending';
    feeCardCls = 'sc-amber';
    feeSub = 'Payment outstanding';
    /* Use average pct from feePct map if available */
    var pcts = feePct ? Object.values(feePct) : [];
    feeRingPct = pcts.length > 0 ? Math.round(pcts.reduce(function (a, b) {
      return a + b;
    }, 0) / pcts.length) : 0;
  } else {
    feeDisplay = '—';
    feeCardCls = 'sc-slate';
    feeSub = 'No fees configured';
    feeRingPct = 0;
  }

  /* ── Day banner ── */
  var dayBanner = null;
  if (dayInfo.type === 'weekend') {
    dayBanner = {
      emoji: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83C\uDF24",
        size: 16
      }),
      msg: "It's the weekend — school resumes on Monday.",
      color: '#8B5CF6'
    };
  } else if (dayInfo.type === 'public_holiday' || dayInfo.type === 'school_holiday') {
    dayBanner = {
      emoji: null,
      msg: (dayInfo.name || 'Holiday') + ' — No school today.',
      color: '#F59E0B'
    };
  }
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ParentNavbar, {
    activePage: "dashboard",
    sidebarOpen: sidebarOpen,
    setSidebar: setSidebarOpen,
    unreadMsg: unreadMsg,
    children: children,
    selectedChild: selectedKid,
    setSelectedChild: setSelectedKid
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(ParentSidebar, {
    activePage: "dashboard",
    sidebarOpen: sidebarOpen,
    unreadMsg: unreadMsg
  }), /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (sidebarOpen ? '' : ' collapsed')
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, dayBanner && /*#__PURE__*/React.createElement("div", {
    style: {
      background: dayBanner.color + '18',
      border: '1.5px solid ' + dayBanner.color + '44',
      borderRadius: 12,
      padding: '12px 18px',
      marginBottom: 20,
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      fontSize: 13.5,
      fontWeight: 600,
      color: dayBanner.color
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 20
    }
  }, dayBanner.emoji), dayBanner.msg), /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", null, loading ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      height: 28,
      width: 220,
      marginBottom: 8,
      borderRadius: 6
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      height: 16,
      width: 160,
      borderRadius: 6
    }
  })) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "page-title"
  }, "Welcome back", children.length > 0 ? '! 👋' : '!'), /*#__PURE__*/React.createElement("div", {
    className: "page-sub"
  }, children.length > 0 ? "Here's what's happening with your " + (children.length === 1 ? 'child' : 'children') + ' today' : 'Parent Portal — check your notifications and messages'))), /*#__PURE__*/React.createElement("button", {
    onClick: load,
    style: {
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 10,
      padding: '8px 16px',
      fontSize: 12.5,
      fontWeight: 700,
      color: 'var(--text-mid)',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD04",
    size: 18
  }), " Refresh")), error && /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FEF2F2',
      border: '1.5px solid #FECACA',
      borderRadius: 12,
      padding: '14px 18px',
      marginBottom: 20,
      color: '#991B1B',
      fontSize: 13,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", error), /*#__PURE__*/React.createElement("div", {
    className: "stats-grid"
  }, loading ? [1, 2, 3, 4].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "shimmer",
      style: {
        height: 110,
        borderRadius: 18
      }
    });
  }) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatCard, {
    cls: "sc-green",
    value: attRate + '%',
    label: "Attendance Rate",
    sub: 'Last 30 days' + (children.length === 1 && children[0] ? ' — ' + children[0].student_name.split(' ')[0] : ''),
    onClick: function () {
      window.location.href = '/nsms/public/parent/attendance.html';
    }
  }), /*#__PURE__*/React.createElement(StatCard, {
    cls: "sc-blue",
    value: hwToday,
    label: "Homework",
    sub: hwToday === 0 ? 'No active assignments' : hwToday === 1 ? '1 active assignment' : hwToday + ' active assignments',
    onClick: function () {
      window.location.href = '/nsms/public/parent/daily-diary.html';
    }
  }), /*#__PURE__*/React.createElement(StatCard, {
    cls: "sc-purple",
    value: unreadMsg,
    label: "J11 Pulse",
    sub: unreadMsg === 0 ? 'No new messages' : unreadMsg + ' unread — tap',
    onClick: function () {
      window.location.href = '/nsms/public/parent/parent-pulse.html';
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: 'stat-card ' + feeCardCls,
    style: {
      cursor: 'pointer'
    },
    onClick: function () {
      window.location.href = '/nsms/public/parent/fee-payments.html';
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-fee-inner"
  }, /*#__PURE__*/React.createElement(FeeRingSmall, {
    pct: feeRingPct
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-value",
    style: {
      fontSize: 22,
      marginBottom: 3
    }
  }, feeDisplay), /*#__PURE__*/React.createElement("div", {
    className: "sc-label"
  }, "Fee Status"), /*#__PURE__*/React.createElement("div", {
    className: "sc-sub"
  }, feeSub)))))), /*#__PURE__*/React.createElement("div", {
    className: "two-col"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  }), " Homework"), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/parent/daily-diary.html",
    className: "panel-link"
  }, "View All")), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "shimmer",
      style: {
        height: 80,
        borderRadius: 12
      }
    });
  })) : homework.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "hw-empty"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-empty-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF89",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, "No homework due! Enjoy the day.")) : /*#__PURE__*/React.createElement("div", {
    className: "hw-list"
  }, homework.map(function (hw) {
    return /*#__PURE__*/React.createElement(HomeworkItem, {
      key: hw.id,
      hw: hw,
      children: children
    });
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  }), " Announcements"), anns.length > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'var(--blue-light)',
      color: 'var(--blue)',
      borderRadius: 20,
      padding: '3px 10px',
      fontSize: 11,
      fontWeight: 700
    }
  }, anns.length)), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "shimmer",
      style: {
        height: 60,
        borderRadius: 10
      }
    });
  })) : anns.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 13,
      padding: '8px 0',
      textAlign: 'center'
    }
  }, "No announcements right now.") : /*#__PURE__*/React.createElement("div", {
    className: "ann-list"
  }, anns.map(function (ann, i) {
    return /*#__PURE__*/React.createElement(AnnouncementItem, {
      key: ann.id,
      ann: ann,
      idx: i
    });
  })))), (loading || calEvents.length > 0) && /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  }), " Upcoming Events")), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, [1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "shimmer",
      style: {
        height: 48,
        borderRadius: 10
      }
    });
  })) : /*#__PURE__*/React.createElement("div", {
    className: "cal-list"
  }, calEvents.map(function (ev, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "cal-item"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cal-icon"
    }, ev.icon || '📅'), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "cal-title"
    }, ev.title), /*#__PURE__*/React.createElement("div", {
      className: "cal-date"
    }, fmt(ev.date)), ev.desc && /*#__PURE__*/React.createElement("div", {
      className: "cal-desc"
    }, ev.desc.slice(0, 80), ev.desc.length > 80 ? '…' : '')));
  })))))), children.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 24,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  }), " Attendance Summary"), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/parent/attendance.html",
    className: "panel-link"
  }, "Details")), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, /*#__PURE__*/React.createElement(AttendancePanel, {
    children: children,
    loading: loading
  }))), /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB0",
    size: 18
  }), " Fee Status"), /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/parent/fee-payments.html",
    className: "panel-link"
  }, "Pay / View")), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, /*#__PURE__*/React.createElement(FeePanel, {
    children: annotatedChildren,
    feeStatus: feeStatus,
    loading: loading
  })))), /*#__PURE__*/React.createElement("div", {
    className: "quick-actions"
  }, /*#__PURE__*/React.createElement("div", {
    className: "qa-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  }), " Quick Actions"), /*#__PURE__*/React.createElement("div", {
    className: "qa-grid"
  }, [{
    href: '/nsms/public/parent/daily-diary.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCC5",
      size: 20
    }),
    label: 'Daily Diary',
    sub: 'Homework & activities'
  }, {
    href: '/nsms/public/parent/reports.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCB",
      size: 20
    }),
    label: 'Reports',
    sub: 'Term & weekly reports'
  }, {
    href: '/nsms/public/parent/attendance.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCA",
      size: 20
    }),
    label: 'Attendance',
    sub: 'Daily records'
  }, {
    href: '/nsms/public/parent/fee-payments.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCB0",
      size: 20
    }),
    label: 'Fee Payments',
    sub: feeStatus === 'paid' ? 'All up to date' : 'Payment pending'
  }, {
    href: '/nsms/public/parent/parent-pulse.html',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u26A1",
      size: 20
    }),
    label: 'J11 Pulse',
    sub: unreadMsg > 0 ? unreadMsg + ' unread' : 'Messages & alerts'
  }].map(function (a, i) {
    return /*#__PURE__*/React.createElement("a", {
      key: i,
      href: a.href,
      className: "qa-btn"
    }, /*#__PURE__*/React.createElement("span", {
      className: "qa-icon"
    }, renderIcon(a.icon, 20)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "qa-label"
    }, a.label), /*#__PURE__*/React.createElement("div", {
      className: "qa-sub"
    }, a.sub)));
  })))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(ParentDashboard, null));