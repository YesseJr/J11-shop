const {
  useState,
  useEffect,
  useCallback,
  useRef
} = React;

/* ─── API helpers ─── */
async function api(params) {
  const url = '/nsms/api/parent-reports.php?' + new URLSearchParams(params);
  const r = await fetch(url, {
    credentials: 'include'
  });
  const text = await r.text();
  try {
    return JSON.parse(text);
  } catch {
    const s = text.indexOf('{');
    if (s >= 0) {
      try {
        return JSON.parse(text.slice(s));
      } catch {}
    }
    throw new Error('Server error');
  }
}
async function fetchClassRank(studentId, classId, term, academicYear, reportType) {
  try {
    const d = await api({
      action: 'class_rank',
      student_id: studentId,
      class_id: classId,
      term,
      academic_year: academicYear,
      report_type: reportType
    });
    return d.success ? d.data : null;
  } catch {
    return null;
  }
}

/* ─── Utilities ─── */
const AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2', '#BE185D'];
const avColor = n => n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
const initials = n => n ? n.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) : '?';
const fmtDate = iso => iso ? new Date(iso).toLocaleDateString('en-GB', {
  day: '2-digit',
  month: 'long',
  year: 'numeric'
}) : '—';
const typeLabel = t => ({
  daily: 'Daily Report',
  weekly: 'Weekly Report',
  midterm: 'Mid-term Report',
  terminal: 'Term Report'
})[t] || t;
const typeIcon = t => ({
  daily: '📅',
  weekly: '🗓',
  midterm: '📊',
  terminal: '🎓'
})[t] || '📄';
const gradeBigClass = g => ({
  A: 'ga',
  B: 'gb',
  C: 'gc',
  D: 'gd',
  E: 'ge',
  F: 'gf'
})[g] || 'gn';
function ordinal(n) {
  if (!n) return '';
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}
function ordinalSuffix(n) {
  if (!n) return '';
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return s[(v - 20) % 10] || s[v] || s[0];
}
function gradeToRemarks(g) {
  return {
    A: 'Excellent',
    B: 'Very Good',
    C: 'Good',
    D: 'Average',
    E: 'Below Average',
    F: 'Poor'
  }[g] || '—';
}
function gradeClass(g) {
  return {
    A: 'rgb-a',
    B: 'rgb-b',
    C: 'rgb-c',
    D: 'rgb-d'
  }[g] || 'rgb-n';
}
function gradeTrClass(g) {
  return {
    A: 'rdoc-tr-a',
    B: 'rdoc-tr-b',
    C: 'rdoc-tr-c',
    D: 'rdoc-tr-d'
  }[g] || '';
}
function gradeRmkClass(g) {
  return {
    A: 'rdoc-rmk-a',
    B: 'rdoc-rmk-b',
    C: 'rdoc-rmk-c',
    D: 'rdoc-rmk-d'
  }[g] || 'rdoc-rmk-n';
}
function gradeValClass(g) {
  return {
    A: 'grade-a',
    B: 'grade-b',
    C: 'grade-c',
    D: 'grade-d'
  }[g] || '';
}
function toLetter(r) {
  if (!r) return null;
  const l = r.toLowerCase();
  if (['excellent', 'very good', 'outstanding'].some(x => l.includes(x))) return 'A';
  if (['good', 'above average', 'above'].some(x => l.includes(x))) return 'B';
  if (['average', 'satisfactory', 'fair'].some(x => l.includes(x))) return 'C';
  if (['below', 'poor', 'needs', 'need'].some(x => l.includes(x))) return 'D';
  return null;
}
function toRemarks(r) {
  if (!r) return '—';
  const l = toLetter(r);
  return l ? gradeToRemarks(l) : r;
}

/* ─── Tanzania Coat of Arms — uses real image with SVG fallback ─── */
function TanzaniaCrest({
  size = 64
}) {
  const [err, setErr] = useState(false);
  if (!err) {
    return /*#__PURE__*/React.createElement("img", {
      src: "/nsms/public/uploads/logos/Tanzania.png",
      alt: "Tanzania Coat of Arms",
      style: {
        width: size,
        height: size,
        objectFit: 'contain'
      },
      onError: () => setErr(true)
    });
  }
  /* Fallback compact SVG */
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 90 100",
    width: size,
    height: size,
    xmlns: "http://www.w3.org/2000/svg"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20,20 H70 V56 Q60,75 45,82 Q30,75 20,56 Z",
    fill: "#1B5E35",
    stroke: "#B5912A",
    strokeWidth: "1.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M45,20 H70 V56 Q60,72 45,80 Z",
    fill: "#1a1a1a"
  }), /*#__PURE__*/React.createElement("clipPath", {
    id: "sc2"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20,20 H70 V56 Q60,75 45,82 Q30,75 20,56 Z"
  })), /*#__PURE__*/React.createElement("g", {
    clipPath: "url(#sc2)"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M15,62 Q22,58 30,62 Q37,66 45,62 Q53,58 60,62 Q67,66 75,62 L75,82 L15,82Z",
    fill: "#1565C0",
    opacity: "0.85"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M20,62 L34,38 L45,28 L56,38 L70,62Z",
    fill: "#5D4037",
    opacity: "0.4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M38,38 L45,28 L52,38Z",
    fill: "white",
    opacity: "0.7"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "43",
    y: "30",
    width: "4",
    height: "18",
    fill: "#8B4513"
  }), /*#__PURE__*/React.createElement("ellipse", {
    cx: "45",
    cy: "27",
    rx: "4",
    ry: "6",
    fill: "#F9A825"
  })), /*#__PURE__*/React.createElement("path", {
    d: "M25,18 Q32,10 45,13 Q58,10 65,18 Q55,13 45,16 Q35,13 25,18Z",
    fill: "#C8A951"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "45",
    cy: "11",
    r: "3.5",
    fill: "#C8A951"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8,55 Q20,50 45,52 Q70,50 82,55 Q65,60 45,62 Q25,60 8,55Z",
    fill: "#2E7D32",
    opacity: "0.7"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M10,80 Q45,73 80,80 Q45,88 10,80Z",
    fill: "#B5912A"
  }), /*#__PURE__*/React.createElement("text", {
    x: "45",
    y: "82",
    textAnchor: "middle",
    fontSize: "6",
    fill: "white",
    fontFamily: "serif",
    fontWeight: "bold",
    letterSpacing: "0.5"
  }, "UHURU NA UMOJA"), /*#__PURE__*/React.createElement("text", {
    x: "45",
    y: "97",
    textAnchor: "middle",
    fontSize: "7",
    fill: "#5D4037",
    fontFamily: "serif",
    fontWeight: "bold",
    letterSpacing: "0.3"
  }, "TANZANIA"));
}

/* ─── Avatar ─── */
function Av({
  name,
  photo,
  size = 34,
  r = 50
}) {
  const [err, setErr] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: `${r}%`,
      background: avColor(name),
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: 700,
      fontSize: size * 0.3,
      color: 'white',
      position: 'relative',
      overflow: 'hidden',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, initials(name)), photo && !err && /*#__PURE__*/React.createElement("img", {
    src: photo,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      borderRadius: `${r}%`
    },
    onError: () => setErr(true)
  }));
}

/* ─── Child Selector ─── */
function ChildSelector({
  children,
  selected,
  onSelect
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef();
  useEffect(() => {
    const h = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  if (!selected) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "child-sel",
    ref: ref
  }, /*#__PURE__*/React.createElement("button", {
    className: "child-sel-btn",
    onClick: () => setOpen(!open)
  }, /*#__PURE__*/React.createElement(Av, {
    name: selected.student_name,
    photo: selected.photo_url,
    size: 28
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--text-dark)'
    }
  }, selected.student_name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-soft)',
      marginTop: 1
    }
  }, selected.class_name || '—')), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--text-soft)',
      marginLeft: 4
    }
  }, open ? '▲' : '▼')), open && /*#__PURE__*/React.createElement("div", {
    className: "child-dd"
  }, children.map(c => /*#__PURE__*/React.createElement("button", {
    key: c.id,
    className: `child-dd-item ${selected.id === c.id ? 'sel' : ''}`,
    onClick: () => {
      onSelect(c);
      setOpen(false);
    }
  }, /*#__PURE__*/React.createElement(Av, {
    name: c.student_name,
    photo: c.photo_url,
    size: 26
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 13
    }
  }, c.student_name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-soft)'
    }
  }, c.class_name || '—'))))));
}

/* ─── Stat Card ─── */
function StatCard({
  icon,
  label,
  value,
  color,
  loading
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `stat-card sc-${color}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-icon"
  }, icon), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "stat-val"
  }, loading ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      color: '#CBD5E1'
    }
  }, "\u2026") : value), /*#__PURE__*/React.createElement("div", {
    className: "stat-lbl"
  }, label)));
}

/* ─── Report Card (list view) ─── */
function ReportCard({
  report,
  onView
}) {
  const typeCls = {
    daily: 'daily',
    weekly: 'weekly',
    midterm: 'midterm',
    terminal: 'terminal'
  }[report.report_type] || 'daily';
  const badgeCls = `rb-${typeCls}`;
  const stripeCls = `rs-${typeCls}`;
  const gradeC = gradeBigClass(report.overall_grade);
  return /*#__PURE__*/React.createElement("div", {
    className: "rpt-card",
    onClick: () => onView(report.id)
  }, /*#__PURE__*/React.createElement("div", {
    className: `rpt-stripe ${stripeCls}`
  }), /*#__PURE__*/React.createElement("div", {
    className: "rpt-card-body"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: `rpt-badge ${badgeCls}`
  }, typeIcon(report.report_type), ' ', typeLabel(report.report_type)), report.overall_grade && /*#__PURE__*/React.createElement("div", {
    className: `grade-big ${gradeC}`
  }, report.overall_grade)), /*#__PURE__*/React.createElement("div", {
    className: "rpt-title"
  }, report.period_label || report.term || fmtDate(report.report_date) || 'Report', report.academic_year ? ` — ${report.academic_year}` : ''), /*#__PURE__*/React.createElement("div", {
    className: "rpt-meta"
  }, report.term && /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  }), " ", report.term), report.report_date && /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  }), " ", fmtDate(report.report_date)), report.subject_count > 0 && /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCD6",
    size: 18
  }), " ", report.subject_count, " subjects"))), /*#__PURE__*/React.createElement("div", {
    className: "rpt-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-view",
    onClick: e => {
      e.stopPropagation();
      onView(report.id);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC41",
    size: 18
  }), " View Report")));
}

/* ─── Skeleton Grid ─── */
function SkGrid() {
  return /*#__PURE__*/React.createElement("div", {
    className: "reports-grid"
  }, [1, 2, 3, 4, 5, 6].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "rpt-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rpt-stripe shimmer",
    style: {
      height: 5
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "rpt-card-body",
    style: {
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      height: 24,
      width: '60%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      height: 18,
      width: '80%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      height: 14,
      width: '50%'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "rpt-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      height: 32,
      width: 100
    }
  })))));
}

/* ══════════════════════════════════════════════════════════════
PROFESSIONAL REPORT DOCUMENT
══════════════════════════════════════════════════════════════ */
function ReportDocument({
  report,
  school,
  positionData,
  onClose
}) {
  const printDate = new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });
  const isWeeklyOrDaily = report.report_type === 'weekly' || report.report_type === 'daily';
  const isExam = report.report_type === 'midterm' || report.report_type === 'terminal';
  const GRADE_SCALE = [{
    g: 'A',
    label: 'Excellent',
    range: '90–100%',
    scaleClass: 'gscale-a'
  }, {
    g: 'B',
    label: 'Very Good',
    range: '75–89%',
    scaleClass: 'gscale-b'
  }, {
    g: 'C',
    label: 'Good',
    range: '60–74%',
    scaleClass: 'gscale-c'
  }, {
    g: 'D',
    label: 'Average',
    range: '50–59%',
    scaleClass: 'gscale-d'
  }, {
    g: 'E',
    label: 'Below Avg.',
    range: '40–49%',
    scaleClass: 'gscale-e'
  }, {
    g: 'F',
    label: 'Poor',
    range: '0–39%',
    scaleClass: 'gscale-f'
  }];
  const TITLE_MAP = {
    daily: "PUPIL'S DAILY PROGRESS REPORT",
    weekly: "PUPIL'S WEEKLY PROGRESS REPORT",
    midterm: "PUPIL'S PROGRESSIVE REPORT",
    terminal: "PUPIL'S END OF TERM REPORT"
  };
  const SUBTITLE_MAP = {
    daily: 'Daily Report',
    weekly: 'Weekly Progress Report',
    midterm: 'Mid Term Examination Results',
    terminal: 'End of Term Results'
  };
  const TYPE_STRIPE_CLASS = {
    midterm: 'rts-midterm',
    terminal: 'rts-terminal',
    weekly: 'rts-weekly',
    daily: 'rts-daily'
  };
  const subjects = report.subjects || [];
  const totalMarks = subjects.reduce((a, s) => a + (parseFloat(s.average_score) || 0), 0);

  /* Position: prefer live positionData, fall back to report fields */
  const position = positionData?.position || report.position || null;
  const totalStudents = positionData?.total_students || report.total_students || null;
  const telNo = school?.school_phone || report.teacher_phone || report.school_phone || '';
  const periodParts = [SUBTITLE_MAP[report.report_type], report.period_label, report.term, report.academic_year ? `A.Y. ${report.academic_year}` : null].filter(Boolean);

  /* J11 Pulse — include teacher_id so the parent portal can pre-select the right conversation */
  const pulseRef = `RPT-${report.id}-${report.report_type.toUpperCase()}`;
  const pulseHref = `/nsms/public/parent/parent-pulse.html?report_ref=${report.id}` + `&teacher_id=${report.teacher_id || ''}` + `&student=${encodeURIComponent(report.student_name || '')}` + `&ref=${pulseRef}`;

  /* School logo: use DB value, else fall back to file on disk */
  const logoSrc = school?.school_logo || '/nsms/public/uploads/logos/logo.png';
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-ov",
    onClick: e => e.target === e.currentTarget && onClose()
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }), " Close"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-print",
    onClick: () => window.print()
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDDA8",
    size: 18
  }), " Print / Save PDF")), /*#__PURE__*/React.createElement("div", {
    className: "rdoc"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-frame"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-hdr"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-hdr-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-logo-box"
  }, /*#__PURE__*/React.createElement(LogoImg, {
    src: logoSrc
  })), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-school-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-school-name"
  }, school?.school_name || 'SCHOOL NAME'), school?.school_motto && /*#__PURE__*/React.createElement("div", {
    className: "rdoc-school-motto"
  }, "\u201C", school.school_motto, "\u201D"), school?.school_address && /*#__PURE__*/React.createElement("div", {
    className: "rdoc-school-contact"
  }, "\u25CF", ' ', school.school_address), telNo && /*#__PURE__*/React.createElement("div", {
    className: "rdoc-school-contact"
  }, "\u25CF ", telNo), school?.school_email && /*#__PURE__*/React.createElement("div", {
    className: "rdoc-school-contact"
  }, "\u25CF", ' ', school.school_email)), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-crest-box"
  }, /*#__PURE__*/React.createElement(TanzaniaCrest, {
    size: 62
  })))), /*#__PURE__*/React.createElement("div", {
    className: `rdoc-type-stripe ${TYPE_STRIPE_CLASS[report.report_type] || 'rts-daily'}`
  }), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-title-band"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-type-title"
  }, TITLE_MAP[report.report_type] || "PUPIL'S PROGRESS REPORT"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-type-period"
  }, periodParts.join('  ·  '))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-info-section"
  }, /*#__PURE__*/React.createElement("table", {
    className: "rdoc-info-table"
  }, /*#__PURE__*/React.createElement("tbody", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-label"
  }, "Pupil's Name"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-colon"
  }, ":"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-value name-val",
    style: {
      minWidth: 180
    }
  }, report.student_name || '—'), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-sep"
  }), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-label"
  }, "Class"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-colon"
  }, ":"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-value"
  }, report.class_name || '—'), isExam && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-sep"
  }), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-label"
  }, "Date"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-colon"
  }, ":"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-value"
  }, report.report_date ? fmtDate(report.report_date) : '—'))), isExam && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-label"
  }, "Class Teacher"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-colon"
  }, ":"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-value",
    style: {
      minWidth: 180
    }
  }, report.teacher_name || '—'), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-sep"
  }), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-label"
  }, "Term"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-colon"
  }, ":"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-value"
  }, report.term || '—'), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-sep"
  }), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-label"
  }, "Acad. Year"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-colon"
  }, ":"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-value"
  }, report.academic_year || '—')), isWeeklyOrDaily && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-label"
  }, report.report_type === 'weekly' ? 'Week' : 'Date'), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-colon"
  }, ":"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-value"
  }, report.period_label || '—'), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-sep"
  }), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-label"
  }, "Class Teacher"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-colon"
  }, ":"), /*#__PURE__*/React.createElement("td", {
    className: "rdoc-info-value",
    colSpan: 4
  }, report.teacher_name || '—'))))), isExam && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-grade-scale"
  }, GRADE_SCALE.map(({
    g,
    label,
    range,
    scaleClass
  }) => /*#__PURE__*/React.createElement("div", {
    key: g,
    className: `rdoc-gscale-item ${scaleClass}`
  }, /*#__PURE__*/React.createElement("span", {
    className: "gscale-label"
  }, g, " \u2014 ", label), /*#__PURE__*/React.createElement("span", {
    className: "gscale-range"
  }, range)))), subjects.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "rdoc-tbl-wrap"
  }, /*#__PURE__*/React.createElement("table", {
    className: "rdoc-table"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      width: '6%'
    }
  }, "S/N"), /*#__PURE__*/React.createElement("th", {
    className: "th-left",
    style: {
      width: '38%'
    }
  }, "Subject"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: '16%'
    }
  }, "Score (%)"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: '24%'
    }
  }, "Remarks"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: '16%'
    }
  }, "Grade"))), /*#__PURE__*/React.createElement("tbody", null, subjects.map((s, i) => {
    const g = s.grade_letter || toLetter(s.rating || s.grade_label) || '—';
    const remarks = s.average_score != null ? gradeToRemarks(g) : toRemarks(s.rating || s.grade_label || '');
    return /*#__PURE__*/React.createElement("tr", {
      key: i,
      className: gradeTrClass(g)
    }, /*#__PURE__*/React.createElement("td", {
      className: "td-sn"
    }, String(i + 1).padStart(2, '0')), /*#__PURE__*/React.createElement("td", {
      className: "td-left"
    }, s.subject_name), /*#__PURE__*/React.createElement("td", {
      style: {
        fontFamily: "'Plus Jakarta Sans',sans-serif",
        fontWeight: 700,
        fontSize: 13
      }
    }, s.average_score != null && s.average_score !== undefined ? parseFloat(s.average_score).toFixed(1) : '—'), /*#__PURE__*/React.createElement("td", null, remarks !== '—' ? /*#__PURE__*/React.createElement("span", {
      className: `rdoc-rmk ${gradeRmkClass(g)}`
    }, remarks) : '—'), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: `rdoc-grade-badge ${gradeClass(g)}`
    }, g)));
  }), /*#__PURE__*/React.createElement("tr", {
    className: "rdoc-total-row"
  }, /*#__PURE__*/React.createElement("td", {
    colSpan: 2,
    style: {
      textAlign: 'right',
      paddingRight: 16
    }
  }, "AGGREGATE TOTAL"), /*#__PURE__*/React.createElement("td", {
    style: {
      fontFamily: "'Playfair Display',serif",
      fontSize: 15
    }
  }, totalMarks.toFixed(0)), /*#__PURE__*/React.createElement("td", {
    colSpan: 2
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-summary-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-lbl"
  }, "Total Marks"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-val"
  }, totalMarks.toFixed(0))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-lbl"
  }, "Average (%)"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-val"
  }, report.overall_average != null && report.overall_average !== undefined ? parseFloat(report.overall_average).toFixed(1) : '—')), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-lbl"
  }, "Overall Grade"), /*#__PURE__*/React.createElement("div", {
    className: `rdoc-sum-val ${gradeValClass(report.overall_grade)}`
  }, report.overall_grade || '—')), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-lbl"
  }, "Subjects Sat"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-val"
  }, subjects.length || '—')), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-block",
    style: {
      borderLeft: '1px solid rgba(201,168,76,.4)',
      background: 'rgba(255,255,255,.05)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-lbl"
  }, "Class Position"), positionData === undefined ? /*#__PURE__*/React.createElement("div", {
    className: "rdoc-pos-loading-sm"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pos-spinner-sm"
  }), /*#__PURE__*/React.createElement("span", null, "Calc\u2026")) : position ? /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sum-val pos-val"
  }, position, /*#__PURE__*/React.createElement("span", {
    className: "rdoc-sum-suffix"
  }, ordinalSuffix(position)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Plus Jakarta Sans',sans-serif",
      fontSize: 9,
      color: 'rgba(240,208,128,.6)',
      display: 'block',
      marginTop: 1
    }
  }, "of", ' ', totalStudents || '—')) : /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans',sans-serif",
      fontSize: 9,
      color: 'rgba(240,208,128,.45)',
      marginTop: 4
    }
  }, "Not available"))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-comments"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-head"
  }, "Comments"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-role"
  }, "Class Teacher's Comment"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-text"
  }, report.teacher_comments || '\u00a0'), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-sig"
  }, "Signature:", /*#__PURE__*/React.createElement("span", {
    className: "rdoc-sig-line"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-role"
  }, "Head of School's Comment"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-text"
  }, report.recommendations || '\u00a0'), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-cmt-sig"
  }, "Signature:", /*#__PURE__*/React.createElement("span", {
    className: "rdoc-sig-line"
  }))))), report.report_type === 'terminal' && report.promotion_status && /*#__PURE__*/React.createElement("div", {
    className: "rdoc-promo-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-promo-title"
  }, "Promotion Status"), /*#__PURE__*/React.createElement("div", {
    className: `rdoc-promo-badge rdoc-promo-${(report.promotion_status || '').toLowerCase().replace(/\s+/g, '-')}`
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, report.promotion_status === 'Promoted' ? /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }) : report.promotion_status === 'Repeat' ? /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD01",
    size: 18
  }) : /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", null, report.promotion_status), report.promotion_status === 'Promoted' && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 600,
      opacity: 0.8
    }
  }, "Congratulations! Proceed to next level."), report.promotion_status === 'Repeat' && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 600,
      opacity: 0.8
    }
  }, "Student will repeat this level.")))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-general-info"
  }, telNo && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, "\u25C6"), "For enquiries, please contact the school on", ' ', /*#__PURE__*/React.createElement("strong", null, telNo), "."), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, "\u25C6"), "We thank you for your continued cooperation and support this term."), report.report_type === 'terminal' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, "\u25C6"), "Results are based on cumulative assessments throughout the term."))), isWeeklyOrDaily && /*#__PURE__*/React.createElement(React.Fragment, null, subjects.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "rdoc-tbl-wrap"
  }, /*#__PURE__*/React.createElement("table", {
    className: "rdoc-table"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      width: '7%'
    }
  }, "S/N"), /*#__PURE__*/React.createElement("th", {
    className: "th-left",
    style: {
      width: '50%'
    }
  }, "Subject"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: '30%'
    }
  }, "Rating"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: '13%'
    }
  }, "Grade"))), /*#__PURE__*/React.createElement("tbody", null, subjects.map((s, i) => {
    const g = s.grade_letter || toLetter(s.rating || s.grade_label) || '—';
    return /*#__PURE__*/React.createElement("tr", {
      key: i,
      className: gradeTrClass(g)
    }, /*#__PURE__*/React.createElement("td", {
      className: "td-sn"
    }, String(i + 1).padStart(2, '0')), /*#__PURE__*/React.createElement("td", {
      className: "td-left"
    }, s.subject_name), /*#__PURE__*/React.createElement("td", {
      style: {
        fontFamily: "'Plus Jakarta Sans',sans-serif",
        fontSize: 11,
        fontWeight: 600
      }
    }, s.rating || s.grade_label || '—'), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: `rdoc-grade-badge ${gradeClass(g)}`
    }, g)));
  })))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-sections-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-num"
  }, /*#__PURE__*/React.createElement("span", null, "1"), "Academic Progress"), report.teacher_comments ? /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-content"
  }, report.teacher_comments) : /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-empty"
  }, "No comment provided.")), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-num"
  }, /*#__PURE__*/React.createElement("span", null, "2"), "Entertainment & Social Skills"), report.social_skills || report.conduct ? /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-content"
  }, [report.social_skills, report.conduct].filter(Boolean).join(' · ')) : /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-empty"
  }, "No comment provided.")), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-num"
  }, /*#__PURE__*/React.createElement("span", null, "3"), "Eating Habits"), report.neatness || report.punctuality ? /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-content"
  }, [report.neatness, report.punctuality].filter(Boolean).join(' · ')) : /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-empty"
  }, "No comment provided.")), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-num"
  }, /*#__PURE__*/React.createElement("span", null, "4"), "Casualty / Recommendations"), report.recommendations ? /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-content"
  }, report.recommendations) : /*#__PURE__*/React.createElement("div", {
    className: "rdoc-section-empty"
  }, "No comment provided."))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-teacher-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-teacher-field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "rdoc-teacher-label"
  }, "Class Teacher"), /*#__PURE__*/React.createElement("span", {
    className: "rdoc-teacher-value"
  }, report.teacher_name || '—')), telNo && /*#__PURE__*/React.createElement("div", {
    className: "rdoc-teacher-field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "rdoc-teacher-label"
  }, "Tel. No."), /*#__PURE__*/React.createElement("span", {
    className: "rdoc-teacher-value"
  }, telNo)), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-teacher-field",
    style: {
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "rdoc-teacher-label"
  }, "Signature"), /*#__PURE__*/React.createElement("span", {
    className: "rdoc-sig-line",
    style: {
      width: 90,
      display: 'inline-block',
      borderBottom: '1px solid #C4B07A',
      marginLeft: 6
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-pulse-section"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "'Plus Jakarta Sans',sans-serif",
      fontSize: 9,
      fontWeight: 800,
      textTransform: 'uppercase',
      letterSpacing: '.5px',
      color: '#7A6530',
      marginBottom: 6,
      display: 'flex',
      alignItems: 'center',
      gap: 7
    }
  }, "Comments & Discussions", /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: '#D4C090',
      display: 'inline-block'
    }
  })), /*#__PURE__*/React.createElement("a", {
    className: "rdoc-pulse-card",
    href: pulseHref
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-pulse-icon-wrap"
  }, "\uD83D\uDCAC"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-pulse-text"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-pulse-title"
  }, "Open in J11 Pulse Messaging"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-pulse-sub"
  }, "Discuss this report with the teacher or school"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-pulse-ref"
  }, "Ref: ", pulseRef)), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-pulse-arrow"
  }, "\u2192")), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-pulse-print-note"
  }, "To discuss this report, visit J11 Pulse and reference:", ' ', /*#__PURE__*/React.createElement("strong", null, pulseRef))), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-foot"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-foot-sig-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-foot-sig-name"
  }, report.teacher_name || ''), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-foot-sig-line"
  }), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-foot-sig-label"
  }, "Class Teacher")), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-stamp"
  }, "OFFICIAL", /*#__PURE__*/React.createElement("br", null), "SCHOOL", /*#__PURE__*/React.createElement("br", null), "STAMP"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-foot-sig-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-foot-sig-name"
  }, "\xA0"), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-foot-sig-line"
  }), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-foot-sig-label"
  }, "Head of School")), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-print-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rdoc-print-school"
  }, school?.school_name || 'Little Scholars'), /*#__PURE__*/React.createElement("div", null, "Printed: ", printDate), /*#__PURE__*/React.createElement("div", null, "Report ID: RPT-", report.id))), /*#__PURE__*/React.createElement("div", {
    className: `rdoc-type-stripe ${TYPE_STRIPE_CLASS[report.report_type] || 'rts-daily'}`
  }), /*#__PURE__*/React.createElement("div", {
    className: "rdoc-closing"
  }, "Nurturing young minds, one day at a time.")))));
}

/* ─── Logo with fallback ─── */
function LogoImg({
  src
}) {
  const [err, setErr] = useState(false);
  if (!err && src) return /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "School Logo",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'contain'
    },
    onError: () => setErr(true)
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "rdoc-logo-placeholder"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  }));
}

/* ══════════════════════════════════════════════════════════════
MAIN APP
══════════════════════════════════════════════════════════════ */
function ReportsApp() {
  const [sidebarOpen, setSidebarOpen] = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  const [unreadMsg, setUnreadMsg] = useState(0);
  const [children, setChildren] = useState([]);
  const [selected, setSelected] = useState(null);
  const [school, setSchool] = useState(null);
  const [bootLoading, setBootLoading] = useState(true);
  const [bootErr, setBootErr] = useState('');
  const [reports, setReports] = useState([]);
  const [listLoading, setListLoading] = useState(false);
  const [listErr, setListErr] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [viewingId, setViewingId] = useState(null);
  const [viewData, setViewData] = useState(null);
  const [viewLoading, setViewLoading] = useState(false);
  const [positionData, setPositionData] = useState(undefined);
  const counts = {
    total: reports.length,
    daily: reports.filter(r => r.report_type === 'daily').length,
    weekly: reports.filter(r => r.report_type === 'weekly').length,
    midterm: reports.filter(r => r.report_type === 'midterm').length,
    terminal: reports.filter(r => r.report_type === 'terminal').length
  };

  /* Boot: load children + school info */
  useEffect(() => {
    Promise.all([api({
      action: 'children'
    }), api({
      action: 'school_info'
    })]).then(([cd, sd]) => {
      if (cd.success && cd.data?.children?.length > 0) {
        setChildren(cd.data.children);
        setSelected(cd.data.children[0]);
      }
      if (sd.success) setSchool(sd.data?.school || null);
    }).catch(e => setBootErr(e.message)).finally(() => setBootLoading(false));
  }, []);

  /* Load report list when selected child changes */
  useEffect(() => {
    if (!selected) return;
    setListLoading(true);
    setListErr('');
    setReports([]);
    setActiveTab('all');
    api({
      action: 'list',
      student_id: selected.id
    }).then(d => {
      if (d.success) setReports(d.data?.reports || []);else setListErr(d.error || 'Failed to load.');
    }).catch(e => setListErr(e.message)).finally(() => setListLoading(false));
  }, [selected]);
  const openReport = useCallback(id => {
    setViewingId(id);
    setViewData(null);
    setPositionData(undefined);
    setViewLoading(true);
    api({
      action: 'get',
      id
    }).then(d => {
      if (d.success) {
        const r = d.data;
        setViewData(r);
        /* Auto-calculate class rank if exam report */
        const isExam = r.report_type === 'midterm' || r.report_type === 'terminal';
        if (isExam && r.student_id && r.class_id && r.term && r.academic_year) {
          fetchClassRank(r.student_id, r.class_id, r.term, r.academic_year, r.report_type).then(rank => setPositionData(rank || null)).catch(() => setPositionData(null));
        } else {
          setPositionData(null);
        }
      } else {
        // API returned success:false — close the modal cleanly
        setViewData(null);
        setViewingId(null);
        setPositionData(null);
      }
    }).catch(() => {
      // Network/parse error — close the modal so the overlay doesn't trap the parent
      setViewData(null);
      setViewingId(null);
      setPositionData(null);
    }).finally(() => setViewLoading(false));
  }, []);
  const closeReport = () => {
    setViewingId(null);
    setViewData(null);
    setPositionData(null);
  };
  const visible = activeTab === 'all' ? reports : reports.filter(r => r.report_type === activeTab);
  const TABS = [{
    key: 'all',
    label: 'All',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCB",
      size: 20
    }),
    count: counts.total
  }, {
    key: 'daily',
    label: 'Daily',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCC5",
      size: 20
    }),
    count: counts.daily
  }, {
    key: 'weekly',
    label: 'Weekly',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDDD3",
      size: 20
    }),
    count: counts.weekly
  }, {
    key: 'midterm',
    label: 'Mid-term',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCA",
      size: 20
    }),
    count: counts.midterm
  }, {
    key: 'terminal',
    label: 'Terminal',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF93",
      size: 20
    }),
    count: counts.terminal
  }];
  const EMPTY = {
    all: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDCC4",
        size: 20
      }),
      title: 'No reports yet',
      body: 'Reports published by the teacher will appear here.'
    },
    daily: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDCC5",
        size: 20
      }),
      title: 'No daily reports yet',
      body: 'Daily assignment reports appear here once published.'
    },
    weekly: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDDD3",
        size: 20
      }),
      title: 'No weekly reports yet',
      body: 'Weekly progress reports will appear here.'
    },
    midterm: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83D\uDCCA",
        size: 20
      }),
      title: 'No mid-term reports yet',
      body: 'Mid-term assessment reports will appear here.'
    },
    terminal: {
      icon: /*#__PURE__*/React.createElement(Icon, {
        emoji: "\uD83C\uDF93",
        size: 20
      }),
      title: 'No term reports yet',
      body: 'End-of-term reports with promotion status appear here.'
    }
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ParentNavbar, {
    activePage: "reports",
    sidebarOpen: sidebarOpen,
    onToggleSidebar: () => setSidebarOpen(v => !v)
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(ParentSidebar, {
    activePage: "reports",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: `main-area ${sidebarOpen ? '' : 'collapsed'}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-title-wrap"
  }, /*#__PURE__*/React.createElement("h1", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  }), " Progress Reports", selected ? ` — ${selected.student_name}` : ''), /*#__PURE__*/React.createElement("div", {
    className: "page-sub"
  }, selected?.class_name ? `Class: ${selected.class_name}` : 'View all published reports for your child')), children.length > 0 && selected && /*#__PURE__*/React.createElement(ChildSelector, {
    children: children,
    selected: selected,
    onSelect: c => {
      setSelected(c);
      setActiveTab('all');
    }
  })), bootErr && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-error"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0",
    size: 18
  }), " ", bootErr), bootLoading ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading\u2026")) : children.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 52
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC64",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 17,
      color: 'var(--text-dark)'
    }
  }, "No children linked"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      maxWidth: 360,
      textAlign: 'center',
      color: 'var(--text-soft)',
      lineHeight: 1.65
    }
  }, "Contact the school administrator to link your child's profile.")) : selected && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "stats-row"
  }, /*#__PURE__*/React.createElement(StatCard, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCB",
      size: 20
    }),
    label: "Total Reports",
    value: counts.total,
    color: "blue",
    loading: listLoading
  }), /*#__PURE__*/React.createElement(StatCard, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCC5",
      size: 20
    }),
    label: "Daily Reports",
    value: counts.daily,
    color: "green",
    loading: listLoading
  }), /*#__PURE__*/React.createElement(StatCard, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDDD3",
      size: 20
    }),
    label: "Weekly Reports",
    value: counts.weekly,
    color: "purple",
    loading: listLoading
  }), /*#__PURE__*/React.createElement(StatCard, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCA",
      size: 20
    }),
    label: "Mid-term Reports",
    value: counts.midterm,
    color: "amber",
    loading: listLoading
  }), /*#__PURE__*/React.createElement(StatCard, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF93",
      size: 20
    }),
    label: "Term Reports",
    value: counts.terminal,
    color: "teal",
    loading: listLoading
  })), /*#__PURE__*/React.createElement("div", {
    className: "tab-bar"
  }, TABS.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.key,
    className: `tab-btn ${activeTab === t.key ? 'active' : ''}`,
    onClick: () => setActiveTab(t.key)
  }, renderIcon(t.icon, 20), " ", t.label, !listLoading && /*#__PURE__*/React.createElement("span", {
    className: "tab-count"
  }, t.count)))), listErr && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-error"
  }, "\u26A0 ", listErr), listLoading ? /*#__PURE__*/React.createElement(SkGrid, null) : visible.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      background: 'white',
      borderRadius: 16,
      border: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 54
    }
  }, EMPTY[activeTab].icon), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 17,
      color: 'var(--text-dark)'
    }
  }, EMPTY[activeTab].title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      maxWidth: 380,
      textAlign: 'center',
      color: 'var(--text-soft)',
      lineHeight: 1.65
    }
  }, EMPTY[activeTab].body)) : /*#__PURE__*/React.createElement("div", {
    className: "reports-grid"
  }, visible.map(r => /*#__PURE__*/React.createElement(ReportCard, {
    key: r.id,
    report: r,
    onView: openReport
  }))))))), viewingId && (viewLoading ? /*#__PURE__*/React.createElement("div", {
    className: "modal-ov",
    onClick: closeReport
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'white',
      borderRadius: 16,
      padding: 60,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 14,
      margin: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner",
    style: {
      width: 38,
      height: 38,
      border: '3px solid #E2E8F0',
      borderTopColor: 'var(--blue)'
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-soft)',
      fontSize: 14
    }
  }, "Loading report\u2026"))) : viewData ? /*#__PURE__*/React.createElement(ReportDocument, {
    report: viewData,
    school: school,
    positionData: positionData,
    onClose: closeReport
  }) : null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(ReportsApp, null));