const {
  useState,
  useEffect,
  useCallback
} = React;

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error: error };
  }
  componentDidCatch(error, info) {
    console.error('NSMS Payment Verification crash:', error, info);
  }
  render() {
    if (this.state.error) {
      return React.createElement('div', {
        style: {
          padding: 24,
          margin: 24,
          background: '#FEF2F2',
          border: '1px solid #FCA5A5',
          borderRadius: 12,
          color: '#991B1B',
          fontFamily: 'system-ui,sans-serif'
        }
      }, React.createElement('div', { style: { fontWeight: 700, marginBottom: 8 } }, 'Something went wrong on this page'),
        React.createElement('div', { style: { fontSize: 13, marginBottom: 12 } }, String(this.state.error && this.state.error.message || this.state.error)),
        React.createElement('button', {
          type: 'button',
          className: 'btn bb',
          onClick: function () { window.location.reload(); }
        }, 'Reload page'));
    }
    return this.props.children;
  }
}
const API = '/nsms/api/payment-gateway.php';
const PAGE_SIZE = 20;
const fmtF = v => 'TSh ' + (Number(v) || 0).toLocaleString('en-TZ', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 0
});
const fmtD = v => {
  if (!v) return '—';
  const d = new Date((v + '').replace(' ', 'T'));
  return isNaN(d.getTime()) ? v : d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
};
const fmtDT = v => {
  if (!v) return '—';
  const d = new Date((v + '').replace(' ', 'T'));
  return isNaN(d.getTime()) ? v : d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  }) + ' · ' + d.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit'
  });
};
const STATUS = {
  pending_verification: {
    label: 'Pending Verification',
    cls: 'xy',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD50",
      size: 20
    })
  },
  received: {
    label: 'Received',
    cls: 'xg',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2705",
      size: 20
    })
  },
  rejected: {
    label: 'Rejected',
    cls: 'xr',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u274C",
      size: 20
    })
  }
};
const Spin = () => /*#__PURE__*/React.createElement("div", {
  className: "spinner"
});
const SBadge = ({
  status
}) => {
  const m = STATUS[status] || {
    label: status,
    cls: 'xgr',
    icon: '•'
  };
  return /*#__PURE__*/React.createElement("span", {
    className: 'bx ' + m.cls
  }, m.icon, " ", m.label);
};

/* Official provider/card logos, with emoji fallback if the image
   file isn't present yet at /nsms/public/includes/images/. */
const LOGO_BASE = '/nsms/public/includes/images/';
const METHOD_LOGOS = {
  'M-Pesa': {
    file: LOGO_BASE + 'mpesa.png',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCF1",
      size: 20
    })
  },
  'Tigo Pesa': {
    file: LOGO_BASE + 'tigopesa.svg',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCF1",
      size: 20
    })
  },
  'Airtel Money': {
    file: LOGO_BASE + 'airtelmoney.png',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCF1",
      size: 20
    })
  },
  'HaloPesa': {
    file: LOGO_BASE + 'halopesa.png',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCF1",
      size: 20
    })
  },
  'Mixx by Yas': {
    file: LOGO_BASE + 'mixxbyyas.png',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCF1",
      size: 20
    })
  },
  'Visa': {
    file: LOGO_BASE + 'visa.png',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCB3",
      size: 20
    })
  },
  'Mastercard': {
    file: LOGO_BASE + 'mastercard.png',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCB3",
      size: 20
    })
  }
};
const MethodLogo = ({
  method,
  size
}) => {
  const [failed, setFailed] = React.useState(false);
  const m = METHOD_LOGOS[method];
  const s = size || 22;
  if (!m || failed) return /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: s * 0.8
    }
  }, m ? m.icon : /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB0",
    size: 20
  }));
  return /*#__PURE__*/React.createElement("img", {
    src: m.file,
    alt: method,
    style: {
      width: s,
      height: s,
      objectFit: 'contain',
      display: 'inline-block',
      verticalAlign: 'middle'
    },
    onError: () => setFailed(true)
  });
};

/* ---- Verify Modal ---- */
const VerifyModal = ({
  txnId,
  onClose,
  onUpdated
}) => {
  const [data, setData] = useState(null);
  const [loading, setLoad] = useState(true);
  const [acting, setAct] = useState(false);
  const [err, setErr] = useState('');
  const [ok, setOk] = useState('');
  const [showRej, setShowRej] = useState(false);
  const [reason, setReason] = useState('');
  useEffect(() => {
    setLoad(true);
    setErr('');
    setOk('');
    setShowRej(false);
    setReason('');
    fetch(API + '?action=transaction_detail&transaction_id=' + txnId).then(r => r.json()).then(d => {
      if (d.success) setData(d.data);else setErr(d.error || 'Load failed');
    }).catch(() => setErr('Network error')).finally(() => setLoad(false));
  }, [txnId]);
  const approve = async () => {
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Approve payment?', message: 'Approve this payment? All ' + ((data && data.items && (data.items||[]).length) || 0) + ' item(s) will be marked received and the student account updated.', confirmLabel: 'Approve', variant: 'warn' }) : Promise.resolve(false)))) return;
    setAct(true);
    setErr('');
    try {
      var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
      try {
        if (window.NSMS && typeof window.NSMS.getCsrfToken === 'function') {
          headers['X-CSRF-Token'] = await window.NSMS.getCsrfToken();
        } else if (typeof window.getCsrfToken === 'function') {
          headers['X-CSRF-Token'] = await window.getCsrfToken();
        }
      } catch (e) {}
      const r = await fetch(API + '?action=approve_transaction', {
        method: 'POST',
        credentials: 'same-origin',
        headers: headers,
        body: JSON.stringify({
          transaction_id: txnId
        })
      });
      var text = await r.text();
      var d = null;
      try { d = text ? JSON.parse(text) : null; } catch (parseErr) {
        setErr('Server returned invalid response (' + r.status + '). Check PHP error log.');
        setAct(false);
        return;
      }
      if (!d) {
        setErr('Empty response from server');
        setAct(false);
        return;
      }
      if (d.success) {
        var payload = d.data || {};
        var receipt = payload.receipt_number || '—';
        var nItems = payload.items_approved != null ? payload.items_approved : (data && data.items ? data.items.length : 0);
        setOk('Transaction approved. Receipt: ' + receipt + '. ' + nItems + ' item(s) updated. Parent notified.');
        setData(function (p) {
          var base = p || {};
          return Object.assign({}, base, {
            status: 'received',
            receipt_number: receipt !== '—' ? receipt : base.receipt_number,
            verified_at: base.verified_at || new Date().toISOString().slice(0, 19).replace('T', ' ')
          });
        });
        // Refresh list after paint so a list error cannot unmount the success UI
        setTimeout(function () {
          try {
            if (typeof onUpdated === 'function') onUpdated();
          } catch (e) {
            console.error('onUpdated failed', e);
          }
        }, 0);
      } else setErr(d.error || d.message || 'Approval failed');
    } catch (e) {
      console.error('approve error', e);
      setErr((e && e.message) ? e.message : 'Network error');
    }
    setAct(false);
  };
  const reject = async () => {
    if (!reason.trim()) {
      setErr('Please enter a rejection reason.');
      return;
    }
    setAct(true);
    setErr('');
    try {
      var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
      try {
        if (window.NSMS && typeof window.NSMS.getCsrfToken === 'function') {
          headers['X-CSRF-Token'] = await window.NSMS.getCsrfToken();
        } else if (typeof window.getCsrfToken === 'function') {
          headers['X-CSRF-Token'] = await window.getCsrfToken();
        }
      } catch (e) {}
      const r = await fetch(API + '?action=reject_transaction', {
        method: 'POST',
        credentials: 'same-origin',
        headers: headers,
        body: JSON.stringify({
          transaction_id: txnId,
          rejection_reason: reason
        })
      });
      const d = await r.json();
      if (d.success) {
        setOk('Transaction rejected. Parent has been notified with the reason.');
        setData(p => ({
          ...p,
          status: 'rejected',
          rejection_reason: reason
        }));
        setShowRej(false);
        onUpdated();
      } else setErr(d.error || 'Rejection failed');
    } catch (e) {
      setErr('Network error');
    }
    setAct(false);
  };
  const proofUrl = data && data.payment_proof ? '/nsms/publicuploads/' + data.payment_proof : null;
  const isPdf = proofUrl && proofUrl.endsWith('.pdf');
  const isPend = data && data.status === 'pending_verification';
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-bg",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-head-title"
  }, "Verify Transaction #", txnId), /*#__PURE__*/React.createElement("button", {
    className: "btn bo bsm",
    onClick: onClose
  }, "Close")), /*#__PURE__*/React.createElement("div", {
    className: "modal-body"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement(Spin, null)) : !data ? /*#__PURE__*/React.createElement("div", {
    className: "err-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-msg"
  }, "Transaction not found.")) : /*#__PURE__*/React.createElement(React.Fragment, null, err && /*#__PURE__*/React.createElement("div", {
    className: "err-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-title"
  }, "Error"), /*#__PURE__*/React.createElement("div", {
    className: "err-msg"
  }, err)), ok && /*#__PURE__*/React.createElement("div", {
    className: "ok-banner"
  }, ok), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(SBadge, {
    status: data.status
  })), data.status === 'rejected' && data.rejection_reason && /*#__PURE__*/React.createElement("div", {
    className: "err-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-title"
  }, "Rejection Reason"), /*#__PURE__*/React.createElement("div", {
    className: "err-msg"
  }, data.rejection_reason)), data.status === 'received' && /*#__PURE__*/React.createElement("div", {
    className: "ok-banner"
  }, "Verified by ", data.verified_by_name || 'Admin', " on ", fmtDT(data.verified_at), data.receipt_number && /*#__PURE__*/React.createElement(React.Fragment, null, " \xB7 Receipt: ", /*#__PURE__*/React.createElement("b", null, data.receipt_number))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#F8FAFC',
      borderRadius: 10,
      marginBottom: 16
    }
  }, [['Student', (data.student_name || '') + ' · ' + (data.class_name || '')], ['Parent', (data.parent_name || '') + (data.parent_phone ? ' · ' + data.parent_phone : '')], ['Total Amount', fmtF(data.total_amount)], ['Method', (data.payment_method || '—') + (data.network_provider ? ' (' + data.network_provider + ')' : '')], [data.payment_channel === 'card' ? 'Card' : 'Phone Number', data.payment_channel === 'card' ? data.card_type + ' •••• ' + data.card_last_four + (data.card_holder_name ? ' — ' + data.card_holder_name : '') : data.phone_number], ['Reference', data.transaction_reference], ['Claimed Date', fmtD(data.payment_date)], ['Submitted At', fmtDT(data.created_at)]].map(([l, v]) => /*#__PURE__*/React.createElement("div", {
    className: "detail-row",
    key: l
  }, /*#__PURE__*/React.createElement("span", {
    className: "detail-label"
  }, l), /*#__PURE__*/React.createElement("span", {
    className: "detail-val"
  }, v))), data.notes && /*#__PURE__*/React.createElement("div", {
    className: "detail-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "detail-label"
  }, "Notes"), /*#__PURE__*/React.createElement("span", {
    className: "detail-val",
    style: {
      fontStyle: 'italic',
      fontWeight: 500
    }
  }, data.notes))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--slate)',
      marginBottom: 8
    }
  }, "Fee Items (", (data.items||[]).length, ")"), (data.items||[]).map(it => /*#__PURE__*/React.createElement("div", {
    className: "item-row",
    key: it.id
  }, /*#__PURE__*/React.createElement("span", {
    className: "item-name"
  }, it.fee_type, it.installment_no ? ' — Instalment #' + it.installment_no : ''), /*#__PURE__*/React.createElement("span", {
    className: "item-amt"
  }, fmtF(it.amount))))), proofUrl ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--slate)',
      marginBottom: 6
    }
  }, "Payment Proof"), isPdf ? /*#__PURE__*/React.createElement("a", {
    href: proofUrl,
    target: "_blank",
    rel: "noreferrer",
    className: "proof-pdf-link"
  }, "\uD83D\uDCC4 View PDF Receipt") : /*#__PURE__*/React.createElement("img", {
    src: proofUrl,
    alt: "Payment proof",
    className: "proof-img",
    onClick: () => window.open(proofUrl, '_blank')
  })) : /*#__PURE__*/React.createElement("div", {
    className: "info-banner"
  }, "No payment proof uploaded by the parent."), isPend && !ok && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "action-strip"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bg",
    onClick: approve,
    disabled: acting
  }, acting ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Spin, null), " Processing\u2026") : /*#__PURE__*/React.createElement(React.Fragment, null, "Approve All (", (data.items||[]).length, ")")), /*#__PURE__*/React.createElement("button", {
    className: "btn br",
    onClick: () => {
      setShowRej(!showRej);
      setErr('');
    },
    disabled: acting
  }, "Reject")), showRej && /*#__PURE__*/React.createElement("div", {
    className: "reject-form"
  }, /*#__PURE__*/React.createElement("label", {
    className: "reject-label"
  }, "Rejection Reason ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--red)'
    }
  }, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "reject-textarea",
    value: reason,
    onChange: e => setReason(e.target.value),
    placeholder: "Explain why this payment is being rejected. The parent will see this message."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn br",
    onClick: reject,
    disabled: acting || !reason.trim()
  }, acting ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Spin, null), " \u2026") : 'Confirm Rejection'), /*#__PURE__*/React.createElement("button", {
    className: "btn bo bsm",
    onClick: () => setShowRej(false)
  }, "Cancel"))))))));
};

/* ---- Main App ---- */
const App = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [stats, setStats] = useState(null);
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoad] = useState(true);
  const [err, setErr] = useState('');
  const [filter, setFilter] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const [modal, setModal] = useState(null);
  const loadStats = useCallback(() => {
    fetch(API + '?action=verification_stats').then(r => r.json()).then(d => {
      if (d.success) setStats(d.data);
    });
  }, []);
  const loadRows = useCallback(pg => {
    const p = pg !== undefined ? pg : 0;
    setLoad(true);
    let url = API + '?action=all_transactions&limit=' + PAGE_SIZE + '&offset=' + p * PAGE_SIZE;
    if (filter) url += '&status=' + filter;
    fetch(url).then(r => r.json()).then(d => {
      if (d.success) {
        var payload = d.data || {};
        setRows(payload.transactions || []);
        setTotal(payload.total || 0);
      } else setErr(d.error || 'Failed to load');
    }).catch(() => setErr('Network error')).finally(() => setLoad(false));
  }, [filter]);
  useEffect(() => {
    loadStats();
  }, [loadStats]);
  useEffect(() => {
    setPage(0);
    loadRows(0);
  }, [loadRows]);
  const onUpdated = () => {
    loadStats();
    loadRows(page);
  };
  const safeRows = Array.isArray(rows) ? rows : [];
  const visible = search.trim() ? safeRows.filter(r => (r.student_name || '').toLowerCase().includes(search.toLowerCase()) || (r.parent_name || '').toLowerCase().includes(search.toLowerCase()) || (r.transaction_reference || '').toLowerCase().includes(search.toLowerCase())) : rows;
  const totalPages = Math.ceil(total / PAGE_SIZE);
  const proofCell = row => {
    if (!row.payment_proof) return /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--subtle)',
        fontSize: 11
      }
    }, "None");
    const url = '/nsms/publicuploads/' + row.payment_proof;
    if (url.endsWith('.pdf')) return /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 20,
        cursor: 'pointer'
      },
      title: "PDF proof",
      onClick: () => window.open(url, '_blank')
    }, "\uD83D\uDCC4");
    return /*#__PURE__*/React.createElement("img", {
      src: url,
      alt: "proof",
      className: "proof-thumb-sm",
      onClick: () => window.open(url, '_blank')
    });
  };
  const methodCell = row => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(MethodLogo, {
    method: row.payment_method,
    size: 26
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600
    }
  }, row.payment_method), /*#__PURE__*/React.createElement("span", {
    className: "channel-badge"
  }, row.payment_channel === 'card' ? '•••• ' + row.card_last_four : row.network_provider || '')));
  const filters = [{
    key: '',
    label: 'All',
    cls: ''
  }, {
    key: 'pending_verification',
    label: 'Pending',
    cls: 'pend'
  }, {
    key: 'received',
    label: 'Approved',
    cls: 'recv'
  }, {
    key: 'rejected',
    label: 'Rejected',
    cls: 'rejt'
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(NSMSNavbar, {
    activePage: "payment_verification",
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(NSMSSidebar, {
    activePage: "payment_verification",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (sidebarOpen ? ' expanded' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ph"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", null, "Payment Verification"), /*#__PURE__*/React.createElement("div", {
    className: "ph-sub"
  }, "Review, approve, or reject parent payment transactions")), /*#__PURE__*/React.createElement("button", {
    className: "refresh-btn",
    onClick: onUpdated,
    title: "Refresh data"
  }, "Refresh")), stats && /*#__PURE__*/React.createElement("div", {
    className: "stat-cards"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc pend"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-icon",
    style: {
      background: '#FEF3C7'
    }
  }, "\uD83D\uDD50"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "sc-label"
  }, "PENDING VERIFICATION"), /*#__PURE__*/React.createElement("div", {
    className: "sc-value"
  }, ((stats.counts||{}).pending_verification||0)), /*#__PURE__*/React.createElement("div", {
    className: "sc-sub"
  }, (stats.new_today||0), " new today"))), /*#__PURE__*/React.createElement("div", {
    className: "sc recv"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-icon",
    style: {
      background: '#D1FAE5'
    }
  }, "\u2705"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "sc-label"
  }, "APPROVED"), /*#__PURE__*/React.createElement("div", {
    className: "sc-value"
  }, ((stats.counts||{}).received||0)), /*#__PURE__*/React.createElement("div", {
    className: "sc-sub"
  }, "Transactions verified"))), /*#__PURE__*/React.createElement("div", {
    className: "sc rejt"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-icon",
    style: {
      background: '#FEE2E2'
    }
  }, "\u274C"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "sc-label"
  }, "REJECTED"), /*#__PURE__*/React.createElement("div", {
    className: "sc-value"
  }, ((stats.counts||{}).rejected||0)), /*#__PURE__*/React.createElement("div", {
    className: "sc-sub"
  }, "Needs parent action"))), /*#__PURE__*/React.createElement("div", {
    className: "sc total"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-icon",
    style: {
      background: '#DBEAFE'
    }
  }, "\uD83D\uDCB0"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "sc-label"
  }, "TOTAL RECEIVED"), /*#__PURE__*/React.createElement("div", {
    className: "sc-value",
    style: {
      fontSize: 18
    }
  }, fmtF((stats.total_received||0))), /*#__PURE__*/React.createElement("div", {
    className: "sc-sub"
  }, "All approved payments")))), /*#__PURE__*/React.createElement("div", {
    className: "filter-bar"
  }, filters.map(f => /*#__PURE__*/React.createElement("button", {
    key: f.key,
    className: 'filter-btn' + (filter === f.key ? ' on' : '') + ' ' + f.cls,
    onClick: () => setFilter(f.key)
  }, f.label, stats && f.key && /*#__PURE__*/React.createElement("span", {
    className: "cnt"
  }, ((stats.counts||{})[f.key]||0) || 0))), /*#__PURE__*/React.createElement("input", {
    className: "search-input",
    placeholder: "Search student, parent, reference\u2026",
    value: search,
    onChange: e => setSearch(e.target.value)
  })), err && /*#__PURE__*/React.createElement("div", {
    className: "err-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-title"
  }, "Error"), /*#__PURE__*/React.createElement("div", {
    className: "err-msg"
  }, err)), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '18px 22px 0',
      marginBottom: 16,
      flexWrap: 'wrap',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: 700
    }
  }, "Transactions"), /*#__PURE__*/React.createElement("span", {
    className: "bx xb"
  }, total, " total")), loading ? /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement(Spin, null), /*#__PURE__*/React.createElement("span", null, "Loading transactions\u2026")) : visible.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty",
    style: {
      padding: '50px 40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 32,
      marginBottom: 10
    }
  }, "\uD83D\uDCED"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      marginBottom: 4
    }
  }, "No transactions found"), /*#__PURE__*/React.createElement("div", null, "Try a different filter or check back later.")) : /*#__PURE__*/React.createElement("div", {
    className: "tw",
    style: {
      paddingBottom: 4
    }
  }, /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "#"), /*#__PURE__*/React.createElement("th", null, "Student"), /*#__PURE__*/React.createElement("th", null, "Parent"), /*#__PURE__*/React.createElement("th", null, "Items"), /*#__PURE__*/React.createElement("th", null, "Total"), /*#__PURE__*/React.createElement("th", null, "Method"), /*#__PURE__*/React.createElement("th", null, "Reference"), /*#__PURE__*/React.createElement("th", null, "Submitted"), /*#__PURE__*/React.createElement("th", null, "Proof"), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", null, "Action"))), /*#__PURE__*/React.createElement("tbody", null, visible.map(r => /*#__PURE__*/React.createElement("tr", {
    key: r.id
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      color: 'var(--muted)',
      fontSize: 12,
      fontWeight: 600
    }
  }, r.id), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700
    }
  }, r.student_name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, r.class_name)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 500
    }
  }, r.parent_name), r.parent_phone && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, r.parent_phone)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "bx xb"
  }, r.item_count, " item", r.item_count > 1 ? 's' : '')), /*#__PURE__*/React.createElement("td", {
    className: "amt"
  }, fmtF(r.total_amount)), /*#__PURE__*/React.createElement("td", null, methodCell(r)), /*#__PURE__*/React.createElement("td", {
    style: {
      fontFamily: 'monospace',
      fontSize: 12,
      letterSpacing: '.3px'
    }
  }, r.transaction_reference), /*#__PURE__*/React.createElement("td", {
    style: {
      color: 'var(--muted)',
      fontSize: 12,
      whiteSpace: 'nowrap'
    }
  }, fmtD(r.created_at)), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'center'
    }
  }, proofCell(r)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(SBadge, {
    status: r.status
  })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("button", {
    className: 'btn bsm ' + (r.status === 'pending_verification' ? 'bb' : 'bo'),
    onClick: () => setModal(r.id)
  }, r.status === 'pending_verification' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 16
  }), "Review") : 'View')))))), totalPages > 1 && /*#__PURE__*/React.createElement("div", {
    className: "pagination"
  }, /*#__PURE__*/React.createElement("span", {
    className: "page-info"
  }, "Page ", page + 1, " of ", totalPages), /*#__PURE__*/React.createElement("button", {
    className: "page-btn",
    disabled: page === 0,
    onClick: () => {
      setPage(0);
      loadRows(0);
    }
  }, "\xAB"), /*#__PURE__*/React.createElement("button", {
    className: "page-btn",
    disabled: page === 0,
    onClick: () => {
      const p = page - 1;
      setPage(p);
      loadRows(p);
    }
  }, "\u2039"), /*#__PURE__*/React.createElement("button", {
    className: "page-btn",
    disabled: page >= totalPages - 1,
    onClick: () => {
      const p = page + 1;
      setPage(p);
      loadRows(p);
    }
  }, "\u203A"), /*#__PURE__*/React.createElement("button", {
    className: "page-btn",
    disabled: page >= totalPages - 1,
    onClick: () => {
      const p = totalPages - 1;
      setPage(p);
      loadRows(p);
    }
  }, "\xBB"))))))), modal && /*#__PURE__*/React.createElement(VerifyModal, {
    txnId: modal,
    onClose: () => setModal(null),
    onUpdated: onUpdated
  }));
};
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/React.createElement(ErrorBoundary, null, /*#__PURE__*/React.createElement(App, null)));