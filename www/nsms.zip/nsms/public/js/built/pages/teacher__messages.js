var useState = React.useState;
var useEffect = React.useEffect;
var useRef = React.useRef;

/* ─── Helpers ─── */
var AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2', '#DB2777'];
function avColor(n) {
  return n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
}
function initials(n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
}
function fmtConvTime(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  var now = new Date();
  var todayStr = now.toDateString();
  var dStr = d.toDateString();
  if (dStr === todayStr) {
    return d.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  }
  var yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (dStr === yesterday.toDateString()) return 'Yesterday';
  if (d.getFullYear() === now.getFullYear()) {
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short'
    });
  }
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}
function fmtMsgTime(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  var now = new Date();
  var time = d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
  return d.toDateString() === now.toDateString() ? time : fmtConvTime(iso) + ', ' + time;
}
function dateSepLabel(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  var now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today';
  var yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long'
  });
}
function sameDay(a, b) {
  return new Date(a).toDateString() === new Date(b).toDateString();
}
function fileIcon(mime) {
  if (!mime) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📄',
    size: 18
  }) : null;
  if (mime.startsWith('image/')) return /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDDBC",
    size: 16
  });
  if (mime === 'application/pdf') return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📕',
    size: 18
  }) : null;
  if (mime.includes('word')) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📝',
    size: 18
  }) : null;
  if (mime.includes('excel') || mime.includes('spreadsheet')) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📊',
    size: 18
  }) : null;
  return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📎',
    size: 18
  }) : null;
}
function fmtBytes(b) {
  if (b < 1024) return b + 'B';
  if (b < 1048576) return (b / 1024).toFixed(1) + 'KB';
  return (b / 1048576).toFixed(1) + 'MB';
}
function isImageMime(m) {
  return m && m.startsWith('image/');
}

/* ─── Contact Avatar (with optional online dot) ─── */
function CAvatar(props) {
  var contact = props.contact;
  var size = props.size || 42;
  var isOnline = props.isOnline;
  var name = contact.full_name || contact.contact_name || '?';
  var photo = contact.photo_url || contact.contact_photo || null;
  return /*#__PURE__*/React.createElement("div", {
    className: "av-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "c-avatar",
    style: {
      width: size,
      height: size,
      background: avColor(name),
      fontSize: Math.round(size * 0.35)
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, initials(name)), photo && /*#__PURE__*/React.createElement("img", {
    src: photo,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      borderRadius: '50%',
      zIndex: 2
    },
    onError: function (e) {
      e.currentTarget.style.display = 'none';
    }
  })), isOnline && /*#__PURE__*/React.createElement("div", {
    className: "online-dot"
  }));
}

/* ─── Shimmer conversation items ─── */
function ShimmerConvs() {
  return /*#__PURE__*/React.createElement(React.Fragment, null, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 11,
        padding: '13px 16px',
        borderBottom: '1px solid #F1F5F9'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 42,
        height: 42,
        borderRadius: '50%'
      },
      className: "shimmer"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "sh shimmer",
      style: {
        width: '55%',
        marginBottom: 7
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "sh shimmer",
      style: {
        width: '80%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "sh shimmer",
      style: {
        width: '65%',
        height: 11
      }
    })));
  }));
}

/* ════════════════════════════════════════════
   NEW MESSAGE MODAL
════════════════════════════════════════════ */
function NewMessageModal(props) {
  var onClose = props.onClose;
  var contacts = props.contacts;
  var onSent = props.onSent;
  var myId = props.myId;
  var recipSt = useState('');
  var recipId = recipSt[0];
  var setRecipId = recipSt[1];
  var subjSt = useState('');
  var subject = subjSt[0];
  var setSubject = subjSt[1];
  var bodySt = useState('');
  var body = bodySt[0];
  var setBody = bodySt[1];
  var sendSt = useState(false);
  var sending = sendSt[0];
  var setSending = sendSt[1];
  var errSt = useState('');
  var err = errSt[0];
  var setErr = errSt[1];
  function handleSend() {
    if (!recipId) {
      setErr('Please select a recipient.');
      return;
    }
    if (!subject.trim()) {
      setErr('Please enter a subject.');
      return;
    }
    if (!body.trim()) {
      setErr('Please enter a message.');
      return;
    }
    setSending(true);
    setErr('');
    fetch('/nsms/api/teacher-messages.php?action=send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        recipient_id: parseInt(recipId),
        subject: subject.trim(),
        message: body.trim()
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        onSent(parseInt(recipId));
        onClose();
      } else {
        setErr(d.error || 'Failed to send message.');
      }
    }).catch(function () {
      setErr('Network error. Please try again.');
    }).finally(function () {
      setSending(false);
    });
  }
  function onOverlay(e) {
    if (e.target === e.currentTarget) onClose();
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: onOverlay
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "modal-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2709\uFE0F",
    size: 18
  }), " New Message"), /*#__PURE__*/React.createElement("button", {
    className: "modal-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "modal-body"
  }, err && /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FEF2F2',
      border: '1.5px solid #FCA5A5',
      borderRadius: 8,
      padding: '10px 14px',
      color: '#991B1B',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", err), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "To ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("div", {
    className: "select-wrap"
  }, /*#__PURE__*/React.createElement("select", {
    className: "field-select",
    value: recipId,
    onChange: function (e) {
      setRecipId(e.target.value);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Select recipient\u2026"), contacts.filter(function (c) {
    return c.role === 'admin';
  }).length > 0 && /*#__PURE__*/React.createElement("optgroup", {
    label: "Administration"
  }, contacts.filter(function (c) {
    return c.role === 'admin';
  }).map(function (c) {
    return /*#__PURE__*/React.createElement("option", {
      key: c.id,
      value: c.id
    }, c.full_name);
  })), contacts.filter(function (c) {
    return c.role === 'parent';
  }).length > 0 && /*#__PURE__*/React.createElement("optgroup", {
    label: "Parents"
  }, contacts.filter(function (c) {
    return c.role === 'parent';
  }).map(function (c) {
    return /*#__PURE__*/React.createElement("option", {
      key: c.id,
      value: c.id
    }, c.full_name, c.student_name ? ' (Parent of ' + c.student_name + ')' : '');
  }))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Subject ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "field-input",
    placeholder: "Message subject\u2026",
    value: subject,
    onChange: function (e) {
      setSubject(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Message ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "field-textarea",
    placeholder: "Type your message here\u2026",
    value: body,
    onChange: function (e) {
      setBody(e.target.value);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "modal-foot"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-cancel",
    onClick: onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "btn-primary",
    onClick: handleSend,
    disabled: sending
  }, sending ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "btn-spinner"
  }), "Sending\u2026") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2709\uFE0F",
    size: 18
  }), " Send Message")))));
}

/* ════════════════════════════════════════════
   MAIN PAGE
════════════════════════════════════════════ */
function MessagesPage() {
  var sbSt = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  var sidebarOpen = sbSt[0];
  var setSidebarOpen = sbSt[1];
  var myIdSt = useState(null);
  var myId = myIdSt[0];
  var setMyId = myIdSt[1];
  var convsSt = useState([]);
  var convs = convsSt[0];
  var setConvs = convsSt[1];
  var contactsSt = useState([]);
  var contacts = contactsSt[0];
  var setContacts = contactsSt[1];
  var activeSt = useState(null);
  var activeId = activeSt[0];
  var setActiveId = activeSt[1];
  var threadSt = useState([]);
  var thread = threadSt[0];
  var setThread = threadSt[1];
  var loadConvSt = useState(true);
  var loadConvs = loadConvSt[0];
  var setLoadConvs = loadConvSt[1];
  var loadThrdSt = useState(false);
  var loadThread = loadThrdSt[0];
  var setLoadThread = loadThrdSt[1];
  var composeSt = useState('');
  var compose = composeSt[0];
  var setCompose = composeSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  var searchSt = useState('');
  var search = searchSt[0];
  var setSearch = searchSt[1];
  var newMsgSt = useState(false);
  var showNewMsg = newMsgSt[0];
  var setShowNewMsg = newMsgSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];

  /* ── New state: presence, typing, file, lightbox ── */
  var onlineSt = useState(false);
  var contactOnline = onlineSt[0];
  var setContactOnline = onlineSt[1];
  var typingSt = useState(false);
  var contactTyping = typingSt[0];
  var setContactTyping = typingSt[1];
  var pendFileSt = useState(null);
  var pendFile = pendFileSt[0];
  var setPendFile = pendFileSt[1];
  var lightboxSt = useState(null);
  var lightbox = lightboxSt[0];
  var setLightbox = lightboxSt[1];
  var messagesEndRef = useRef(null);
  var pollRef = useRef(null);
  var fileInputRef = useRef(null);
  var lastMsgId = useRef(0);
  var typingSentAt = useRef(0);
  var heartbeatRef = useRef(null);

  /* active contact object */
  var activeContact = contacts.find(function (c) {
    return c.id === activeId;
  }) || convs.find(function (c) {
    return c.contact_id === activeId;
  }) || {};

  /* ── Initial load: profile + conversations + contacts in parallel ── */
  useEffect(function () {
    Promise.all([fetch('/nsms/api/teacher-profile.php?action=get').then(function (r) {
      return r.json();
    }).catch(function () {
      return null;
    }), fetch('/nsms/api/teacher-messages.php?action=conversations').then(function (r) {
      return r.json();
    }).catch(function () {
      return null;
    }), fetch('/nsms/api/teacher-messages.php?action=contacts').then(function (r) {
      return r.json();
    }).catch(function () {
      return null;
    })]).then(function (res) {
      var prof = res[0];
      var convD = res[1];
      var contD = res[2];
      if (prof && prof.success && prof.data) setMyId(prof.data.id || null);
      if (convD && convD.success) setConvs(convD.data || []);
      if (contD && contD.success) setContacts(contD.data || []);
    }).finally(function () {
      setLoadConvs(false);
    });

    /* Heartbeat — update own presence every 30 s */
    heartbeatRef.current = setInterval(function () {
      fetch('/nsms/api/teacher-messages.php?action=heartbeat', {
        method: 'POST'
      }).catch(function () {});
    }, 30000);
    return function () {
      clearInterval(heartbeatRef.current);
    };
  }, []);

  /* ── Load thread when active changes ── */
  useEffect(function () {
    if (!activeId) return;
    setLoadThread(true);
    setThread([]);
    setContactOnline(false);
    setContactTyping(false);
    lastMsgId.current = 0; /* reset so thread_updates starts from beginning of this thread */
    fetch('/nsms/api/teacher-messages.php?action=thread&contact_id=' + activeId).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        /* API now returns { messages: [...], contact_online: bool } */
        var msgs = d.data && d.data.messages ? d.data.messages : Array.isArray(d.data) ? d.data : [];
        setThread(msgs);
        setContactOnline(!!(d.data && d.data.contact_online));
        if (msgs.length > 0) lastMsgId.current = msgs[msgs.length - 1].id;
        /* Mark unread as read */
        fetch('/nsms/api/teacher-messages.php?action=mark_read&contact_id=' + activeId, {
          method: 'POST'
        });
        /* Clear unread badge */
        setConvs(function (prev) {
          return prev.map(function (c) {
            return c.contact_id === activeId ? Object.assign({}, c, {
              unread_count: 0
            }) : c;
          });
        });
      }
    }).catch(function () {}).finally(function () {
      setLoadThread(false);
    });
  }, [activeId]);

  /* ── Scroll to bottom when thread updates ── */
  useEffect(function () {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, [thread]);

  /* ── Incremental poll every 4 s — only fetches new messages ── */
  useEffect(function () {
    if (!activeId) return;
    pollRef.current = setInterval(function () {
      fetch('/nsms/api/teacher-messages.php?action=thread_updates&contact_id=' + activeId + '&since_id=' + lastMsgId.current).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (!d.success) return;
        /* Update online + typing status on every poll */
        setContactOnline(!!d.data.contact_online);
        setContactTyping(!!d.data.contact_typing);
        var newMsgs = d.data.new_messages || [];
        if (newMsgs.length > 0) {
          lastMsgId.current = newMsgs[newMsgs.length - 1].id;
          setThread(function (prev) {
            return prev.concat(newMsgs);
          });
          /* Mark newly arrived messages as read */
          fetch('/nsms/api/teacher-messages.php?action=mark_read&contact_id=' + activeId, {
            method: 'POST'
          });
          /* Clear badge */
          setConvs(function (prev) {
            return prev.map(function (c) {
              return c.contact_id === activeId ? Object.assign({}, c, {
                unread_count: 0
              }) : c;
            });
          });
          /* Refresh conv list preview */
          fetch('/nsms/api/teacher-messages.php?action=conversations').then(function (r) {
            return r.json();
          }).then(function (r2) {
            if (r2.success) {
              setConvs(function (prev) {
                return (r2.data || []).map(function (c) {
                  return c.contact_id === activeId ? Object.assign({}, c, {
                    unread_count: 0
                  }) : c;
                });
              });
            }
          }).catch(function () {});
        }
      }).catch(function () {});
    }, 4000);
    return function () {
      clearInterval(pollRef.current);
    };
  }, [activeId]);

  /* ── Toast auto-dismiss ── */
  useEffect(function () {
    if (!toast) return;
    var t = setTimeout(function () {
      setToast(null);
    }, 3000);
    return function () {
      clearTimeout(t);
    };
  }, [toast]);

  /* ── Send text message ── */
  function handleSend() {
    /* Route to file sender if a file is pending */
    if (pendFile) {
      handleSendFile();
      return;
    }
    if (!compose.trim() || !activeId) return;
    var text = compose.trim();
    setSending(true);
    fetch('/nsms/api/teacher-messages.php?action=send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        recipient_id: activeId,
        subject: '',
        message: text
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setCompose('');
        /* Use server-returned object so id + files are correct */
        var newMsg = d.data || {
          id: null,
          sender_id: myId,
          recipient_id: activeId,
          message: text,
          subject: '',
          is_read: 0,
          has_file: 0,
          files: [],
          created_at: new Date().toISOString()
        };
        if (newMsg.id && newMsg.id > lastMsgId.current) lastMsgId.current = newMsg.id;
        setThread(function (prev) {
          return prev.concat([newMsg]);
        });
        /* Update conversation preview */
        setConvs(function (prev) {
          var exists = prev.find(function (c) {
            return c.contact_id === activeId;
          });
          if (exists) {
            return prev.map(function (c) {
              return c.contact_id === activeId ? Object.assign({}, c, {
                last_message: text,
                last_at: newMsg.created_at
              }) : c;
            });
          }
          return prev;
        });
      } else {
        setToast({
          type: 'error',
          msg: d.error || 'Failed to send.'
        });
      }
    }).catch(function () {
      setToast({
        type: 'error',
        msg: 'Network error.'
      });
    }).finally(function () {
      setSending(false);
    });
  }

  /* ── Send file ── */
  function handleSendFile() {
    if (!pendFile || !activeId) return;
    setSending(true);
    var fd = new FormData();
    fd.append('recipient_id', activeId);
    fd.append('message', compose.trim());
    fd.append('subject', '');
    fd.append('attachment', pendFile);
    fetch('/nsms/api/teacher-messages.php?action=send_file', {
      method: 'POST',
      body: fd
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setCompose('');
        setPendFile(null);
        var newMsg = d.data;
        if (newMsg && newMsg.id && newMsg.id > lastMsgId.current) lastMsgId.current = newMsg.id;
        setThread(function (prev) {
          return prev.concat([newMsg]);
        });
        var preview = /*#__PURE__*/React.createElement(Icon, {
          emoji: "\uD83D\uDCCE",
          size: 16
        }) + pendFile.name;
        setConvs(function (prev) {
          return prev.map(function (c) {
            return c.contact_id === activeId ? Object.assign({}, c, {
              last_message: preview,
              last_at: newMsg.created_at
            }) : c;
          });
        });
      } else {
        setToast({
          type: 'error',
          msg: d.error || 'Failed to send file.'
        });
      }
    }).catch(function () {
      setToast({
        type: 'error',
        msg: 'Network error.'
      });
    }).finally(function () {
      setSending(false);
    });
  }

  /* Enter key sends (Shift+Enter = new line) */
  function onComposeKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  /* Typing indicator — POST heartbeat at most once per 3 s while typing */
  function onComposeChange(e) {
    setCompose(e.target.value);
    if (!activeId) return;
    var now = Date.now();
    if (now - typingSentAt.current > 3000) {
      typingSentAt.current = now;
      fetch('/nsms/api/teacher-messages.php?action=set_typing&contact_id=' + activeId, {
        method: 'POST'
      }).catch(function () {});
    }
  }

  /* File picker handler */
  function onFileChange(e) {
    var f = e.target.files[0];
    if (!f) return;
    if (f.size > 10 * 1024 * 1024) {
      setToast({
        type: 'error',
        msg: 'File too large (max 10 MB)'
      });
      return;
    }
    setPendFile(f);
    e.target.value = '';
  }

  /* After sending from New Message modal */
  function onNewMsgSent(contactId) {
    setToast({
      type: 'success',
      msg: /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        emoji: "\u2713",
        size: 16
      }), "Message sent!")
    });
    fetch('/nsms/api/teacher-messages.php?action=conversations').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setConvs(d.data || []);
    });
    setActiveId(contactId);
  }
  var filteredConvs = search ? convs.filter(function (c) {
    var q = search.toLowerCase();
    return (c.contact_name || '').toLowerCase().includes(q) || (c.last_message || '').toLowerCase().includes(q) || (c.subject || '').toLowerCase().includes(q);
  }) : convs;

  /* Total unread for all convs */
  var totalUnread = convs.reduce(function (sum, c) {
    return sum + (c.unread_count || 0);
  }, 0);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TeacherNavbar, {
    activePage: "messages",
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(TeacherSidebar, {
    activePage: "messages",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (sidebarOpen ? '' : ' collapsed')
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    className: "page-title"
  }, "Messages", totalUnread > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 10,
      fontSize: 14,
      fontWeight: 700,
      background: '#EF4444',
      color: 'white',
      padding: '2px 9px',
      borderRadius: 20,
      verticalAlign: 'middle'
    }
  }, totalUnread)), /*#__PURE__*/React.createElement("p", {
    className: "page-sub"
  }, "Communicate with parents and administration")), /*#__PURE__*/React.createElement("button", {
    className: "btn-new-msg",
    onClick: function () {
      setShowNewMsg(true);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2709\uFE0F",
    size: 18
  }), " New Message")), /*#__PURE__*/React.createElement("div", {
    className: "chat-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "conv-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "conv-search-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "conv-search"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    type: "text",
    placeholder: "Search messages\u2026",
    value: search,
    onChange: function (e) {
      setSearch(e.target.value);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "conv-list"
  }, loadConvs ? /*#__PURE__*/React.createElement(ShimmerConvs, null) : filteredConvs.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty-convs"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCAC",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, search ? 'No conversations match your search.' : 'No messages yet. Start a new conversation!')) : filteredConvs.map(function (conv) {
    var isActive = conv.contact_id === activeId;
    var hasUnread = conv.unread_count > 0;
    var contact = {
      full_name: conv.contact_name,
      photo_url: conv.contact_photo
    };
    return /*#__PURE__*/React.createElement("div", {
      key: conv.contact_id,
      className: 'conv-item' + (isActive ? ' active' : '') + (hasUnread ? ' unread' : ''),
      onClick: function () {
        setActiveId(conv.contact_id);
      }
    }, /*#__PURE__*/React.createElement(CAvatar, {
      contact: contact,
      size: 42,
      isOnline: conv.is_online
    }), /*#__PURE__*/React.createElement("div", {
      className: "conv-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "conv-top"
    }, /*#__PURE__*/React.createElement("span", {
      className: "conv-name"
    }, conv.contact_name), /*#__PURE__*/React.createElement("span", {
      className: "conv-time"
    }, fmtConvTime(conv.last_at))), conv.subject && /*#__PURE__*/React.createElement("div", {
      className: "conv-subject"
    }, conv.subject), /*#__PURE__*/React.createElement("div", {
      className: "conv-preview"
    }, conv.last_message || '—')), hasUnread && /*#__PURE__*/React.createElement("div", {
      className: "unread-dot"
    }));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "thread-panel"
  }, !activeId ? /*#__PURE__*/React.createElement("div", {
    className: "empty-thread"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCAC",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "Select a conversation to start messaging")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "thread-head"
  }, /*#__PURE__*/React.createElement(CAvatar, {
    contact: {
      full_name: activeContact.contact_name || activeContact.full_name || '?',
      photo_url: activeContact.contact_photo || activeContact.photo_url
    },
    size: 44,
    isOnline: contactOnline
  }), /*#__PURE__*/React.createElement("div", {
    className: "thread-head-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "thread-contact-name"
  }, activeContact.contact_name || activeContact.full_name || '—'), contactTyping ? /*#__PURE__*/React.createElement("div", {
    className: "thread-status typing"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270D\uFE0F",
    size: 18
  }), " typing\u2026") : contactOnline ? /*#__PURE__*/React.createElement("div", {
    className: "thread-status online"
  }, " Online") : /*#__PURE__*/React.createElement("div", {
    className: "thread-status offline"
  }, activeContact.contact_role ? activeContact.contact_role : activeContact.role === 'admin' ? 'Administrator' : activeContact.student_name ? 'Parent of ' + activeContact.student_name : 'Parent'))), /*#__PURE__*/React.createElement("div", {
    className: "messages-area"
  }, loadThread ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        justifyContent: i % 2 === 0 ? 'flex-end' : 'flex-start'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: '55%',
        height: 68,
        borderRadius: 12
      },
      className: "shimmer"
    }));
  })) : thread.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      color: 'var(--text-muted)',
      fontSize: 13,
      marginTop: 32
    }
  }, "No messages yet. Send the first one!") : thread.map(function (msg, idx) {
    var isMine = msg.sender_id === myId;
    var showSep = idx === 0 || !sameDay(thread[idx - 1].created_at, msg.created_at);
    var isRead = msg.is_read == 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: msg.id || idx
    }, showSep && /*#__PURE__*/React.createElement("div", {
      className: "date-sep"
    }, dateSepLabel(msg.created_at)), /*#__PURE__*/React.createElement("div", {
      className: 'msg-row ' + (isMine ? 'mine' : 'theirs')
    }, msg.message ? /*#__PURE__*/React.createElement("div", {
      className: "msg-bubble"
    }, msg.message) : null, msg.files && msg.files.map(function (f, fi) {
      if (isImageMime(f.mime_type)) {
        return /*#__PURE__*/React.createElement("img", {
          key: fi,
          className: "img-preview",
          src: f.url,
          alt: f.original_name,
          onClick: function () {
            setLightbox(f.url);
          },
          onError: function (e) {
            e.currentTarget.style.display = 'none';
          }
        });
      }
      return /*#__PURE__*/React.createElement("a", {
        key: fi,
        className: "file-card",
        href: f.url,
        target: "_blank",
        rel: "noopener noreferrer"
      }, /*#__PURE__*/React.createElement("span", {
        className: "f-icon"
      }, fileIcon(f.mime_type)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
        className: "f-name"
      }, f.original_name), /*#__PURE__*/React.createElement("div", {
        className: "f-size"
      }, fmtBytes(f.file_size))), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 13,
          opacity: .6
        }
      }, "\u2193"));
    }), /*#__PURE__*/React.createElement("div", {
      className: "msg-meta"
    }, /*#__PURE__*/React.createElement("span", {
      className: "msg-time"
    }, fmtMsgTime(msg.created_at)), isMine && /*#__PURE__*/React.createElement("span", {
      className: 'msg-receipt' + (isRead ? ' read' : '')
    }, isRead ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 16
    }), /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 18
    })) : '✓'))));
  }), /*#__PURE__*/React.createElement("div", {
    ref: messagesEndRef
  })), /*#__PURE__*/React.createElement("div", {
    className: "compose-wrap"
  }, pendFile && /*#__PURE__*/React.createElement("div", {
    className: "file-preview-bar"
  }, isImageMime(pendFile.type) ? /*#__PURE__*/React.createElement("img", {
    className: "fp-img",
    src: URL.createObjectURL(pendFile),
    alt: ""
  }) : /*#__PURE__*/React.createElement("span", {
    className: "fp-icon"
  }, fileIcon(pendFile.type)), /*#__PURE__*/React.createElement("span", {
    className: "fp-name"
  }, pendFile.name), /*#__PURE__*/React.createElement("span", {
    className: "fp-size"
  }, fmtBytes(pendFile.size)), /*#__PURE__*/React.createElement("button", {
    className: "fp-remove",
    onClick: function () {
      setPendFile(null);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "compose-area"
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileInputRef,
    type: "file",
    style: {
      display: 'none'
    },
    accept: "image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt",
    onChange: onFileChange
  }), /*#__PURE__*/React.createElement("button", {
    className: "compose-attach",
    title: "Attach file",
    onClick: function () {
      fileInputRef.current && fileInputRef.current.click();
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCE",
    size: 18
  })), /*#__PURE__*/React.createElement("textarea", {
    className: "compose-input",
    placeholder: pendFile ? 'Add a caption (optional)…' : 'Type your message… (Enter to send, Shift+Enter for new line)',
    value: compose,
    onChange: onComposeChange,
    onKeyDown: onComposeKey,
    rows: 1
  }), /*#__PURE__*/React.createElement("button", {
    className: "btn-send",
    onClick: handleSend,
    disabled: sending || !compose.trim() && !pendFile
  }, sending ? '…' : 'Send ▶')))))))), showNewMsg && /*#__PURE__*/React.createElement(NewMessageModal, {
    contacts: contacts,
    myId: myId,
    onClose: function () {
      setShowNewMsg(false);
    },
    onSent: onNewMsgSent
  }), lightbox && /*#__PURE__*/React.createElement("div", {
    className: "lightbox",
    onClick: function () {
      setLightbox(null);
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: lightbox,
    alt: "Preview",
    onClick: function (e) {
      e.stopPropagation();
    }
  })), toast && /*#__PURE__*/React.createElement("div", {
    className: 'toast toast-' + toast.type
  }, toast.msg));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(MessagesPage, null));