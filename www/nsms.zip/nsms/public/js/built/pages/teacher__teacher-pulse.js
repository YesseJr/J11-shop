var useState = React.useState;
var useEffect = React.useEffect;
var useRef = React.useRef;

/* ── constants ── */
var API = '/nsms/api/pulse-api.php';

/* ── helpers ── */
var AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2', '#DB2777'];
function avColor(n) {
  return n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
}
function initials(n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
}
function fmtConvTime(iso) {
  if (!iso) return '';
  var d = new Date(iso),
    now = new Date();
  if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
  var y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short'
  });
}
function fmtFull(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  }) + ' ' + d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}
function fmtMsgTime(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  return d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}
function fmtBytes(b) {
  if (!b) return '';
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}
function sameDay(a, b) {
  return a && b && new Date(a).toDateString() === new Date(b).toDateString();
}
function dateSep(iso) {
  if (!iso) return '';
  var d = new Date(iso),
    now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today';
  var y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long'
  });
}
function isImg(m) {
  return m && m.startsWith('image/');
}

/**
 * Plays a short, pleasant two-note chime using the Web Audio API — no
 * external sound file needed, so nothing to host or fail to load. Fails
 * silently on browsers that block audio before any user interaction.
 */
function playPulseChime() {
  try {
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    var ctx = new Ctx();
    [880, 1108].forEach(function (freq, i) {
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      var start = ctx.currentTime + i * 0.09;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.13, start + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.22);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.24);
    });
  } catch (e) {
    /* audio not available — non-fatal */
  }
}
function fileIcon(m) {
  if (!m) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📄',
    size: 18
  }) : null;
  if (m.startsWith('image/')) return /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDDBC",
    size: 16
  });
  if (m === 'application/pdf') return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📕',
    size: 18
  }) : null;
  if (m.includes('word')) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📘',
    size: 18
  }) : null;
  if (m.includes('sheet') || m.includes('excel')) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📗',
    size: 18
  }) : null;
  return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📄',
    size: 18
  }) : null;
}
function apiGet(action, params) {
  var q = Object.keys(params || {}).map(function (k) {
    return k + '=' + encodeURIComponent(params[k]);
  }).join('&');
  return fetch(API + '?action=' + action + (q ? '&' + q : ''), {
    credentials: 'same-origin'
  });
}
function apiPost(action, data, params) {
  var q = Object.keys(params || {}).map(function (k) {
    return k + '=' + encodeURIComponent(params[k]);
  }).join('&');
  return fetch(API + '?action=' + action + (q ? '&' + q : ''), {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  });
}
function apiForm(action, fd, params) {
  var q = Object.keys(params || {}).map(function (k) {
    return k + '=' + encodeURIComponent(params[k]);
  }).join('&');
  return fetch(API + '?action=' + action + (q ? '&' + q : ''), {
    method: 'POST',
    credentials: 'same-origin',
    body: fd
  });
}
function showToastGlobal(setToast, msg, type) {
  setToast({
    msg: msg,
    type: type || 'success'
  });
  setTimeout(function () {
    setToast(null);
  }, 3000);
}

/* ── Avatar ── */
function Av(props) {
  var n = props.name || '',
    sz = props.size || 40,
    sq = props.sq,
    src = props.src;
  return /*#__PURE__*/React.createElement("div", {
    className: 'av' + (sq ? ' sq' : ''),
    style: {
      width: sz,
      height: sz,
      background: avColor(n),
      flexShrink: 0
    }
  }, src && /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: n,
    onError: function (e) {
      e.currentTarget.style.display = 'none';
    }
  }), !src && initials(n));
}

/* ── Priority badge ── */
function PrioBadge(props) {
  var p = props.priority || 'medium';
  var labels = {
    low: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDFE2",
      size: 16
    }), "Low"),
    medium: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD35",
      size: 16
    }), "Medium"),
    high: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDFE0",
      size: 16
    }), "High"),
    urgent: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD34",
      size: 16
    }), "Urgent")
  };
  var cls = {
    low: 'pb-low',
    medium: 'pb-med',
    high: 'pb-hi',
    urgent: 'pb-urg'
  };
  return /*#__PURE__*/React.createElement("span", {
    className: 'pb ' + cls[p]
  }, labels[p] || p);
}

/* ── Toast ── */
function Toast(props) {
  if (!props.toast) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: 'ptoast ' + props.toast.type
  }, props.toast.msg);
}

/* ═══════════════════════════════════
MESSAGES TAB
═══════════════════════════════════ */
function MessagesTab(props) {
  var myId = props.myId;
  var convsSt = useState([]);
  var convs = convsSt[0];
  var setConvs = convsSt[1];
  var selSt = useState(null);
  var selContact = selSt[0];
  var setSelContact = selSt[1];
  var threadSt = useState([]);
  var thread = threadSt[0];
  var setThread = threadSt[1];
  var cInfoSt = useState(null);
  var cInfo = cInfoSt[0];
  var setCInfo = cInfoSt[1];
  var onlineSt = useState(false);
  var isOnline = onlineSt[0];
  var setIsOnline = onlineSt[1];
  var typingSt = useState(false);
  var isTyping = typingSt[0];
  var setIsTyping = typingSt[1];
  var composeSt = useState('');
  var compose = composeSt[0];
  var setCompose = composeSt[1];
  var pendFileSt = useState(null);
  var pendFile = pendFileSt[0];
  var setPendFile = pendFileSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  var loadThreadSt = useState(false);
  var loadThread = loadThreadSt[0];
  var setLoadThread = loadThreadSt[1];
  var showNewSt = useState(false);
  var showNew = showNewSt[0];
  var setShowNew = showNewSt[1];
  var searchSt = useState('');
  var search = searchSt[0];
  var setSearch = searchSt[1];
  var lightboxSt = useState(null);
  var lightbox = lightboxSt[0];
  var setLightbox = lightboxSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];
  var fileInputRef = useRef(null);
  var bottomRef = useRef(null);
  var lastMsgIdRef = useRef(0);
  var pollRef = useRef(null);
  var replyToSt = useState(null);
  var replyTo = replyToSt[0];
  var setReplyTo = replyToSt[1];
  var threadSearchSt = useState('');
  var threadSearch = threadSearchSt[0];
  var setThreadSearch = threadSearchSt[1];
  var showSearchSt = useState(false);
  var showSearch = showSearchSt[0];
  var setShowSearch = showSearchSt[1];
  var editingIdSt = useState(null);
  var editingId = editingIdSt[0];
  var setEditingId = editingIdSt[1];
  var editTextSt = useState('');
  var editText = editTextSt[0];
  var setEditText = editTextSt[1];
  var reactPickerForSt = useState(null);
  var reactPickerFor = reactPickerForSt[0];
  var setReactPickerFor = reactPickerForSt[1];
  var QUICK_EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🙏'].map(function (e) {
    return typeof Icon === 'function' ? React.createElement(Icon, {
      emoji: e,
      size: 18,
      key: e
    }) : e;
  });
  async function toggleReaction(messageId, emoji) {
    setReactPickerFor(null);
    setThread(function (prev) {
      return prev.map(function (m) {
        if (m.id !== messageId) return m;
        var reactions = async (m.reactions || []).slice();
        var idx = reactions.findIndex(function (r) {
          return r.emoji === emoji;
        });
        if (idx >= 0 && reactions[idx].mine) {
          if (reactions[idx].count <= 1) reactions.splice(idx, 1);else reactions[idx] = Object.assign({}, reactions[idx], {
            count: reactions[idx].count - 1,
            mine: false
          });
        } else if (idx >= 0) {
          reactions[idx] = Object.assign({}, reactions[idx], {
            count: reactions[idx].count + 1,
            mine: true
          });
        } else {
          reactions.push({
            emoji: emoji,
            count: 1,
            mine: true
          });
        }
        return Object.assign({}, m, {
          reactions: reactions
        });
      });
    });
    apiPost('toggle_reaction', {
      message_id: messageId,
      emoji: emoji
    });
  }
  async function startEdit(msg) {
    setEditingId(msg.id);
    setEditText(msg.message || '');
    setReactPickerFor(null);
  }
  async function cancelEdit() {
    setEditingId(null);
    setEditText('');
  }
  async function saveEdit(messageId) {
    var text = editText.trim();
    if (!text) return;
    apiPost('edit_message', {
      message_id: messageId,
      message: text
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setThread(function (prev) {
          return prev.map(function (m) {
            return m.id === messageId ? Object.assign({}, m, {
              message: text,
              edited_at: new Date().toISOString()
            }) : m;
          });
        });
        setEditingId(null);
        setEditText('');
      } else {
        showToastGlobal(setToast, d.error || 'Could not edit message', 'error');
      }
    });
  }
  async function deleteMessage(messageId) {
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Delete message?', message: 'Delete this message? This cannot be undone.', confirmLabel: 'Delete', variant: 'danger' }) : Promise.resolve(false)))) return;
    apiPost('delete_message', {
      message_id: messageId
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setThread(function (prev) {
          return prev.map(function (m) {
            return m.id === messageId ? Object.assign({}, m, {
              is_deleted: true,
              message: null,
              files: [],
              reactions: []
            }) : m;
          });
        });
      } else {
        showToastGlobal(setToast, d.error || 'Could not delete message', 'error');
      }
    });
  }
  function canEdit(msg) {
    if (msg.sender_id !== myId || msg.is_deleted) return false;
    return Date.now() - new Date(msg.created_at).getTime() < 15 * 60 * 1000;
  }
  useEffect(function () {
    if (reactPickerFor === null) return;
    function onDocClick(e) {
      if (!e.target.closest('.react-picker') && !e.target.closest('.mact-btn')) setReactPickerFor(null);
    }
    document.addEventListener('click', onDocClick);
    return function () {
      document.removeEventListener('click', onDocClick);
    };
  }, [reactPickerFor]);
  function isEmojiOnly(str) {
    if (!str || str.length > 8) return false;
    var stripped = str.replace(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}\u{FE00}-\u{FEFF}]/gu, '').trim();
    return stripped.length === 0;
  }
  var convsPollRef = useRef(null);
  useEffect(function () {
    loadConvs();
    var hb = setInterval(function () {
      fetch(API + '?action=heartbeat', {
        method: 'POST',
        credentials: 'same-origin'
      });
    }, 30000);
    convsPollRef.current = setInterval(function () {
      loadConvs();
    }, 10000);
    return function () {
      clearInterval(hb);
      if (pollRef.current) clearInterval(pollRef.current);
      if (convsPollRef.current) clearInterval(convsPollRef.current);
    };
  }, []);
  function loadConvs() {
    apiGet('conversations').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setConvs(d.data || []);
    });
  }
  function openThread(cid) {
    if (selContact === cid) return;
    setSelContact(cid);
    setThread([]);
    setLoadThread(true);
    lastMsgIdRef.current = 0;
    if (pollRef.current) clearInterval(pollRef.current);
    apiGet('thread', {
      contact_id: cid
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        var msgs = d.data.messages || [];
        setThread(msgs);
        setCInfo(d.data.contact);
        setIsOnline(d.data.is_online);
        if (msgs.length) lastMsgIdRef.current = msgs[msgs.length - 1].id;
        setTimeout(function () {
          if (bottomRef.current) bottomRef.current.scrollIntoView();
        }, 80);
      }
      setLoadThread(false);
    });
    fetch(API + '?action=mark_read&contact_id=' + cid, {
      method: 'POST',
      credentials: 'same-origin'
    });
    pollRef.current = setInterval(function () {
      pollUpdates(cid);
    }, 3000);
  }
  function pollUpdates(cid) {
    apiGet('thread_updates', {
      contact_id: cid,
      since_id: lastMsgIdRef.current
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) return;
      setIsOnline(d.data.is_online);
      setIsTyping(d.data.is_typing);
      if (d.data.messages && d.data.messages.length) {
        var hasIncoming = d.data.messages.some(function (m) {
          return m.sender_id !== myId;
        });
        if (hasIncoming) playPulseChime();
        setThread(function (prev) {
          var updated = prev.concat(d.data.messages);
          lastMsgIdRef.current = updated[updated.length - 1].id;
          return updated;
        });
        fetch(API + '?action=mark_read&contact_id=' + cid, {
          method: 'POST',
          credentials: 'same-origin'
        });
        setTimeout(function () {
          if (bottomRef.current) bottomRef.current.scrollIntoView({
            behavior: 'smooth'
          });
        }, 80);
        loadConvs();
      }
    });
  }
  function handleSend() {
    if (sending || !compose.trim() && !pendFile) return;
    setSending(true);
    var rid = replyTo ? replyTo.id : null;
    setReplyTo(null);
    if (pendFile) {
      var fd = new FormData();
      fd.append('recipient_id', selContact);
      fd.append('message', compose.trim());
      fd.append('attachment', pendFile);
      if (rid) fd.append('reply_to_id', rid);
      apiForm('send_file', fd).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) {
          setThread(function (p) {
            return p.concat([d.data]);
          });
          lastMsgIdRef.current = d.data.id;
          setCompose('');
          setPendFile(null);
          loadConvs();
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        } else showToastGlobal(setToast, d.error || d.message || 'Send failed', 'error');
        setSending(false);
      }).catch(function (err) {
        showToastGlobal(setToast, 'Send error: ' + (err && err.message ? err.message : 'Network error'), 'error');
        setSending(false);
      });
    } else {
      apiPost('send', {
        recipient_id: selContact,
        message: compose.trim(),
        reply_to_id: rid || null
      }).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) {
          setThread(function (p) {
            return p.concat([d.data]);
          });
          lastMsgIdRef.current = d.data.id;
          setCompose('');
          loadConvs();
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        } else showToastGlobal(setToast, d.error || d.message || 'Send failed', 'error');
        setSending(false);
      }).catch(function (err) {
        showToastGlobal(setToast, 'Send error: ' + (err && err.message ? err.message : 'Network error'), 'error');
        setSending(false);
      });
    }
  }
  function onKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }
  function onComposeChange(e) {
    var ta = e.target;
    setCompose(ta.value);
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 100) + 'px';
    if (selContact) fetch(API + '?action=set_typing&contact_id=' + selContact, {
      method: 'POST',
      credentials: 'same-origin'
    });
  }
  var filteredConvs = convs.filter(function (c) {
    return !search || c.full_name.toLowerCase().includes(search.toLowerCase());
  });
  var visibleThread = threadSearch.trim() ? thread.filter(function (m) {
    return m.message && m.message.toLowerCase().includes(threadSearch.toLowerCase());
  }) : thread;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "lp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lp-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lp-title"
  }, "Direct Messages"), /*#__PURE__*/React.createElement("button", {
    className: "lp-btn lp-btn-blue",
    onClick: function () {
      setShowNew(true);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  }), " New")), /*#__PURE__*/React.createElement("div", {
    className: "lp-search"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lp-si"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search conversations\u2026",
    value: search,
    onChange: function (e) {
      setSearch(e.target.value);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "lp-list"
  }, filteredConvs.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "lp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCAC",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "No conversations yet")), filteredConvs.map(function (c) {
    return /*#__PURE__*/React.createElement("div", {
      key: c.contact_id,
      className: 'ci' + (selContact === c.contact_id ? ' active' : ''),
      onClick: function () {
        openThread(c.contact_id);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "avw"
    }, /*#__PURE__*/React.createElement(Av, {
      name: c.full_name,
      src: c.photo_url,
      size: 40
    }), c.is_online && /*#__PURE__*/React.createElement("span", {
      className: "odot"
    })), /*#__PURE__*/React.createElement("div", {
      className: "ci-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ci-top"
    }, /*#__PURE__*/React.createElement("span", {
      className: "ci-name"
    }, c.full_name), /*#__PURE__*/React.createElement("span", {
      className: "ci-time"
    }, fmtConvTime(c.last_at))), /*#__PURE__*/React.createElement("div", {
      className: "ci-prev"
    }, c.last_message || 'No messages yet')), c.unread_count > 0 && /*#__PURE__*/React.createElement("span", {
      className: "bcount"
    }, c.unread_count));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "rp"
  }, !selContact ? /*#__PURE__*/React.createElement("div", {
    className: "rp-empty-new"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  })), /*#__PURE__*/React.createElement("h3", null, "J11 Pulse"), /*#__PURE__*/React.createElement("p", null, "Select a conversation on the left to start messaging. Your messages are private and end-to-end secure.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "rp-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "avw"
  }, /*#__PURE__*/React.createElement(Av, {
    name: cInfo ? cInfo.full_name : '',
    src: cInfo ? cInfo.photo_url : '',
    size: 38
  }), isOnline && /*#__PURE__*/React.createElement("span", {
    className: "odot"
  })), /*#__PURE__*/React.createElement("div", {
    className: "rp-hi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rp-name"
  }, cInfo ? cInfo.full_name : '…'), /*#__PURE__*/React.createElement("div", {
    className: 'rp-st ' + (isTyping ? 'typing' : isOnline ? 'online' : 'offline')
  }, isTyping ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 3
    }
  }, [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        width: 5,
        height: 5,
        borderRadius: '50%',
        background: '#2563EB',
        animation: 'tdot 1.4s infinite ease-in-out both',
        animationDelay: i === 0 ? '-.32s' : i === 1 ? '-.16s' : '0s',
        display: 'inline-block'
      }
    });
  })), "typing") : isOnline ? '● Online' : 'Last seen recently')), /*#__PURE__*/React.createElement("button", {
    title: "Search in thread",
    onClick: function () {
      setShowSearch(function (v) {
        return !v;
      });
      setThreadSearch('');
    },
    style: {
      width: 30,
      height: 30,
      borderRadius: 8,
      border: '1.5px solid var(--border)',
      background: showSearch ? '#EFF6FF' : 'white',
      color: showSearch ? '#2563EB' : 'var(--text-muted)',
      cursor: 'pointer',
      fontSize: 14,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  }))), showSearch && /*#__PURE__*/React.createElement("div", {
    className: "tsbar"
  }, /*#__PURE__*/React.createElement("input", {
    className: "tsbar-in",
    placeholder: "Search messages in this chat\u2026",
    autoFocus: true,
    value: threadSearch,
    onChange: function (e) {
      setThreadSearch(e.target.value);
    },
    onKeyDown: function (e) {
      if (e.key === 'Escape') {
        setShowSearch(false);
        setThreadSearch('');
      }
    }
  }), threadSearch && /*#__PURE__*/React.createElement("span", {
    className: "tsbar-cnt"
  }, visibleThread.length, ' ', "result", visibleThread.length !== 1 ? 's' : ''), /*#__PURE__*/React.createElement("button", {
    className: "tsbar-close",
    onClick: function () {
      setShowSearch(false);
      setThreadSearch('');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "msgs-area"
  }, loadThread && [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "mr theirs"
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: 130 + i * 50 + 'px',
        height: 34,
        borderRadius: 9
      }
    }));
  }), !loadThread && visibleThread.map(function (msg, idx) {
    var isMine = msg.sender_id === myId;
    var showSep = !threadSearch && (idx === 0 || !sameDay(visibleThread[idx - 1].created_at, msg.created_at));
    var emojiOnly = isEmojiOnly(msg.message);
    var isEditing = editingId === msg.id;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: msg.id || idx
    }, showSep && /*#__PURE__*/React.createElement("div", {
      className: "dsep"
    }, dateSep(msg.created_at)), /*#__PURE__*/React.createElement("div", {
      className: 'mr ' + (isMine ? 'mine' : 'theirs') + ' msg-row' + (threadSearch && msg.message && msg.message.toLowerCase().includes(threadSearch.toLowerCase()) ? ' msg-highlight' : ''),
      style: {
        position: 'relative'
      }
    }, !msg.is_deleted && /*#__PURE__*/React.createElement("div", {
      className: "msg-actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "React",
      onClick: function () {
        setReactPickerFor(reactPickerFor === msg.id ? null : msg.id);
      }
    }, ' ', /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDE0A",
      size: 18
    }), ' '), /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "Reply",
      onClick: function () {
        setReplyTo(msg);
      }
    }, ' ', "\u21A9", ' '), /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "Copy",
      onClick: function () {
        if (msg.message) try {
          navigator.clipboard.writeText(msg.message);
        } catch (e) {}
      }
    }, ' ', /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCB",
      size: 18
    }), ' '), canEdit(msg) && /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "Edit",
      onClick: function () {
        startEdit(msg);
      }
    }, ' ', /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u270F\uFE0F",
      size: 18
    }), ' '), isMine && /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "Delete",
      onClick: function () {
        deleteMessage(msg.id);
      }
    }, ' ', /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDDD1\uFE0F",
      size: 18
    }), ' ')), reactPickerFor === msg.id && /*#__PURE__*/React.createElement("div", {
      className: "react-picker"
    }, QUICK_EMOJIS.map(function (e) {
      return /*#__PURE__*/React.createElement("button", {
        key: e,
        onClick: function () {
          toggleReaction(msg.id, e);
        }
      }, e);
    })), msg.is_deleted ? /*#__PURE__*/React.createElement("div", {
      className: "msg-deleted"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDEAB",
      size: 18
    }), " This message was deleted") : /*#__PURE__*/React.createElement(React.Fragment, null, msg.reply_to_message && /*#__PURE__*/React.createElement("div", {
      className: "quote-ref"
    }, /*#__PURE__*/React.createElement("div", {
      className: "quote-ref-name"
    }, msg.reply_to_sender || 'Message'), /*#__PURE__*/React.createElement("div", {
      className: "quote-ref-text"
    }, msg.reply_to_message)), isEditing ? /*#__PURE__*/React.createElement("div", {
      className: "edit-box"
    }, /*#__PURE__*/React.createElement("textarea", {
      autoFocus: true,
      value: editText,
      onChange: function (e) {
        setEditText(e.target.value);
      },
      onKeyDown: function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          saveEdit(msg.id);
        } else if (e.key === 'Escape') {
          cancelEdit();
        }
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "edit-box-actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "edit-cancel",
      onClick: cancelEdit
    }, "Cancel"), /*#__PURE__*/React.createElement("button", {
      className: "edit-save",
      onClick: function () {
        saveEdit(msg.id);
      }
    }, "Save"))) : /*#__PURE__*/React.createElement(React.Fragment, null, msg.message && /*#__PURE__*/React.createElement("div", {
      className: 'bbl' + (emojiOnly ? ' emoji-only' : '')
    }, msg.message, msg.edited_at && /*#__PURE__*/React.createElement("span", {
      className: "msg-edited-tag"
    }, "(edited)")), msg.files && msg.files.map(function (f, fi) {
      if (isImg(f.mime_type)) return /*#__PURE__*/React.createElement("img", {
        key: fi,
        className: "imgprev",
        src: f.url,
        alt: f.original_name,
        onClick: function () {
          setLightbox(f.url);
        },
        onError: function (e) {
          e.currentTarget.style.display = 'none';
        }
      });
      return /*#__PURE__*/React.createElement("a", {
        key: fi,
        className: "fcard",
        href: f.url,
        target: "_blank",
        rel: "noopener noreferrer"
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 19
        }
      }, fileIcon(f.mime_type)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
        className: "fname"
      }, f.original_name), /*#__PURE__*/React.createElement("div", {
        className: "fsize"
      }, fmtBytes(f.file_size))), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 11,
          opacity: 0.6
        }
      }, "\u2193"));
    })), msg.reactions && msg.reactions.length > 0 && /*#__PURE__*/React.createElement("div", {
      className: "react-pills"
    }, msg.reactions.map(function (r) {
      return /*#__PURE__*/React.createElement("button", {
        key: r.emoji,
        className: 'react-pill' + (r.mine ? ' mine' : ''),
        onClick: function () {
          toggleReaction(msg.id, r.emoji);
        }
      }, /*#__PURE__*/React.createElement("span", null, r.emoji), /*#__PURE__*/React.createElement("span", null, r.count));
    })), /*#__PURE__*/React.createElement("div", {
      className: "mmeta"
    }, /*#__PURE__*/React.createElement("span", {
      className: "mtime"
    }, fmtMsgTime(msg.created_at)), isMine && /*#__PURE__*/React.createElement("span", {
      className: 'mrec' + (msg.is_read == 1 ? ' read' : ' sent')
    }, msg.is_read == 1 ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 16
    }), /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 18
    })) : '✓')))));
  }), !loadThread && visibleThread.length === 0 && threadSearch && /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--text-muted)',
      gap: 8,
      padding: 32
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13
    }
  }, "No messages match \"", threadSearch, "\"")), isTyping && !loadThread && /*#__PURE__*/React.createElement("div", {
    className: "mr theirs"
  }, /*#__PURE__*/React.createElement("div", {
    className: "bbl",
    style: {
      padding: '10px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "typing-dots"
  }, /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null)))), /*#__PURE__*/React.createElement("div", {
    ref: bottomRef
  })), /*#__PURE__*/React.createElement("div", {
    className: "cwrap"
  }, replyTo && /*#__PURE__*/React.createElement("div", {
    className: "reply-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "reply-bar-line"
  }), /*#__PURE__*/React.createElement("div", {
    className: "reply-bar-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "reply-bar-name"
  }, "\u21A9 Replying to", ' ', replyTo.sender_id === myId ? 'yourself' : cInfo ? cInfo.full_name : '…'), /*#__PURE__*/React.createElement("div", {
    className: "reply-bar-prev"
  }, replyTo.message || /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCE",
    size: 16
  }), "Attachment"))), /*#__PURE__*/React.createElement("button", {
    className: "reply-bar-close",
    onClick: function () {
      setReplyTo(null);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), pendFile && /*#__PURE__*/React.createElement("div", {
    className: "fpbar"
  }, isImg(pendFile.type) ? /*#__PURE__*/React.createElement("img", {
    style: {
      maxHeight: 40,
      maxWidth: 60,
      borderRadius: 4,
      objectFit: 'cover'
    },
    src: URL.createObjectURL(pendFile),
    alt: ""
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, fileIcon(pendFile.type)), /*#__PURE__*/React.createElement("span", {
    className: "fp-nm"
  }, pendFile.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, fmtBytes(pendFile.size)), /*#__PURE__*/React.createElement("button", {
    className: "fp-rm",
    onClick: function () {
      setPendFile(null);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "crow"
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileInputRef,
    type: "file",
    style: {
      display: 'none'
    },
    accept: "image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt",
    onChange: function (e) {
      if (e.target.files[0]) setPendFile(e.target.files[0]);
      e.target.value = '';
    }
  }), /*#__PURE__*/React.createElement("button", {
    className: "catt",
    onClick: function () {
      fileInputRef.current && fileInputRef.current.click();
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCE",
    size: 18
  })), /*#__PURE__*/React.createElement("textarea", {
    className: "cinput",
    placeholder: replyTo ? 'Write your reply…' : pendFile ? 'Add a caption…' : 'Type a message… (Enter to send)',
    value: compose,
    onChange: onComposeChange,
    onKeyDown: onKey,
    rows: 1
  }), /*#__PURE__*/React.createElement("button", {
    className: "bsend",
    onClick: handleSend,
    disabled: sending || !compose.trim() && !pendFile
  }, sending ? '…' : 'Send ▶'))))), showNew && /*#__PURE__*/React.createElement(NewDMModal, {
    onClose: function () {
      setShowNew(false);
    },
    onSent: function (cid) {
      setShowNew(false);
      openThread(cid);
      loadConvs();
    }
  }), lightbox && /*#__PURE__*/React.createElement("div", {
    className: "plbox",
    onClick: function () {
      setLightbox(null);
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: lightbox,
    alt: "Preview",
    onClick: function (e) {
      e.stopPropagation();
    }
  })), /*#__PURE__*/React.createElement(Toast, {
    toast: toast
  }));
}

/* ═══════════════════════════════════
COLLABORATION TAB
/* ═══════════════════════════════════
COLLABORATION TAB
═══════════════════════════════════ */
function CollabTab(props) {
  var myId = props.myId;
  var groupsSt = useState([]);
  var groups = groupsSt[0];
  var setGroups = groupsSt[1];
  var selGrpSt = useState(null);
  var selGrp = selGrpSt[0];
  var setSelGrp = selGrpSt[1];
  var grpInfoSt = useState(null);
  var grpInfo = grpInfoSt[0];
  var setGrpInfo = grpInfoSt[1];
  var threadSt = useState([]);
  var thread = threadSt[0];
  var setThread = threadSt[1];
  var membersSt = useState([]);
  var members = membersSt[0];
  var setMembers = membersSt[1];
  var resourcesSt = useState([]);
  var resources = resourcesSt[0];
  var setResources = resourcesSt[1];
  var subTabSt = useState('chat');
  var subTab = subTabSt[0];
  var setSubTab = subTabSt[1];
  var composeSt = useState('');
  var compose = composeSt[0];
  var setCompose = composeSt[1];
  var pendFileSt = useState(null);
  var pendFile = pendFileSt[0];
  var setPendFile = pendFileSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  var loadingSt = useState(false);
  var loading = loadingSt[0];
  var setLoading = loadingSt[1];
  var showNGSt = useState(false);
  var showNG = showNGSt[0];
  var setShowNG = showNGSt[1];
  var showRUSt = useState(false);
  var showRU = showRUSt[0];
  var setShowRU = showRUSt[1];
  var showAGSt = useState(false);
  var showAG = showAGSt[0];
  var setShowAG = showAGSt[1];
  var lightboxSt = useState(null);
  var lightbox = lightboxSt[0];
  var setLightbox = lightboxSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];
  var bottomRef = useRef(null);
  var fileRef = useRef(null);
  var lastIdRef = useRef(0);
  var pollRef = useRef(null);
  var grpListPollRef = useRef(null);
  useEffect(function () {
    loadGroups();
    grpListPollRef.current = setInterval(function () {
      loadGroups();
    }, 15000);
    return function () {
      if (pollRef.current) clearInterval(pollRef.current);
      if (grpListPollRef.current) clearInterval(grpListPollRef.current);
    };
  }, []);
  function loadGroups() {
    apiGet('my_groups').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setGroups(d.data || []);
    });
  }
  function openGroup(gid) {
    if (selGrp === gid) return;
    setSelGrp(gid);
    setThread([]);
    setLoading(true);
    lastIdRef.current = 0;
    setSubTab('chat');
    if (pollRef.current) clearInterval(pollRef.current);
    fetch(API + '?action=mark_group_read&group_id=' + gid, {
      method: 'POST',
      credentials: 'same-origin'
    });
    Promise.all([apiGet('group_thread', {
      group_id: gid
    }).then(function (r) {
      return r.json();
    }), apiGet('group_members', {
      group_id: gid
    }).then(function (r) {
      return r.json();
    }), apiGet('resources', {
      group_id: gid
    }).then(function (r) {
      return r.json();
    })]).then(function (results) {
      var tR = results[0],
        mR = results[1],
        rR = results[2];
      if (tR.success) {
        var msgs = tR.data.messages || [];
        setThread(msgs);
        setGrpInfo(tR.data.group);
        if (msgs.length) lastIdRef.current = msgs[msgs.length - 1].id;
        setTimeout(function () {
          if (bottomRef.current) bottomRef.current.scrollIntoView();
        }, 80);
      }
      if (mR.success) setMembers(mR.data || []);
      if (rR.success) setResources(rR.data || []);
      setLoading(false);
    });
    pollRef.current = setInterval(function () {
      apiGet('group_thread_updates', {
        group_id: gid,
        since_id: lastIdRef.current
      }).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success && d.data.messages && d.data.messages.length) {
          setThread(function (prev) {
            var u = prev.concat(d.data.messages);
            lastIdRef.current = u[u.length - 1].id;
            return u;
          });
          fetch(API + '?action=mark_group_read&group_id=' + gid, {
            method: 'POST',
            credentials: 'same-origin'
          });
          loadGroups();
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        }
      });
    }, 3000);
  }
  function reloadRes() {
    apiGet('resources', {
      group_id: selGrp
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setResources(d.data || []);
    });
  }
  function handleSend() {
    if (sending || !compose.trim() && !pendFile) return;
    setSending(true);
    if (pendFile) {
      var fd = new FormData();
      fd.append('group_id', selGrp);
      fd.append('message', compose.trim());
      fd.append('attachment', pendFile);
      apiForm('group_send_file', fd).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) {
          setThread(function (p) {
            return p.concat([d.data]);
          });
          lastIdRef.current = d.data.id;
          setCompose('');
          setPendFile(null);
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        }
        setSending(false);
      });
    } else {
      apiPost('group_send', {
        group_id: selGrp,
        message: compose.trim()
      }).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) {
          setThread(function (p) {
            return p.concat([d.data]);
          });
          lastIdRef.current = d.data.id;
          setCompose('');
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        }
        setSending(false);
      });
    }
  }
  function onKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "lp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lp-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lp-title"
  }, "Collaboration Hub"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "lp-btn lp-btn-green",
    onClick: function () {
      setShowNG(true);
    }
  }, "+ Group"), /*#__PURE__*/React.createElement("button", {
    className: "lp-btn lp-btn-blue",
    onClick: function () {
      setShowAG(true);
    }
  }, "Browse"))), /*#__PURE__*/React.createElement("div", {
    className: "lp-list"
  }, groups.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "lp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "No groups yet"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11
    }
  }, "Create one or join existing")), groups.map(function (g) {
    return /*#__PURE__*/React.createElement("div", {
      key: g.id,
      className: 'gi' + (selGrp === g.id ? ' active' : ''),
      onClick: function () {
        openGroup(g.id);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "av sq",
      style: {
        width: 40,
        height: 40,
        background: g.avatar_color || '#10B981',
        borderRadius: 10,
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 16,
        fontWeight: 800,
        color: 'white'
      }
    }, g.name ? g.name[0].toUpperCase() : 'G'), /*#__PURE__*/React.createElement("div", {
      className: "gi-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "gi-name"
    }, g.name), /*#__PURE__*/React.createElement("div", {
      className: "gi-meta"
    }, g.member_count, " member", g.member_count != 1 ? 's' : '')));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "rp"
  }, !selGrp ? /*#__PURE__*/React.createElement("div", {
    className: "rp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "Select a group to collaborate"), /*#__PURE__*/React.createElement("small", null, "Share resources, experiences and real-time group chat")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "rp-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "av sq",
    style: {
      width: 38,
      height: 38,
      background: grpInfo ? grpInfo.avatar_color : '#10B981',
      borderRadius: 9,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 16,
      fontWeight: 800,
      color: 'white',
      flexShrink: 0
    }
  }, grpInfo ? grpInfo.name[0].toUpperCase() : 'G'), /*#__PURE__*/React.createElement("div", {
    className: "rp-hi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rp-name"
  }, grpInfo ? grpInfo.name : 'Group'), /*#__PURE__*/React.createElement("div", {
    className: "rp-st offline"
  }, members.length, " member", members.length != 1 ? 's' : '')), subTab === 'resources' && /*#__PURE__*/React.createElement("button", {
    className: "lp-btn lp-btn-green",
    style: {
      marginLeft: 'auto'
    },
    onClick: function () {
      setShowRU(true);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCE",
    size: 18
  }), " Share")), /*#__PURE__*/React.createElement("div", {
    className: "subtabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: 'stab' + (subTab === 'chat' ? ' ag' : ''),
    onClick: function () {
      setSubTab('chat');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCAC",
    size: 18
  }), " Chat"), /*#__PURE__*/React.createElement("button", {
    className: 'stab' + (subTab === 'resources' ? ' ag' : ''),
    onClick: function () {
      setSubTab('resources');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  }), " Resources (", resources.length, ")"), /*#__PURE__*/React.createElement("button", {
    className: 'stab' + (subTab === 'members' ? ' ag' : ''),
    onClick: function () {
      setSubTab('members');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC64",
    size: 18
  }), " Members (", members.length, ")")), subTab === 'chat' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "msgs-area"
  }, loading && [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "mr gm"
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: 130 + i * 50 + 'px',
        height: 34,
        borderRadius: 9
      }
    }));
  }), !loading && thread.map(function (msg, idx) {
    var isMine = msg.sender_id === myId;
    var showSep = idx === 0 || !sameDay(thread[idx - 1].created_at, msg.created_at);
    var showName = !isMine && (idx === 0 || thread[idx - 1].sender_id !== msg.sender_id);
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: msg.id || idx
    }, showSep && /*#__PURE__*/React.createElement("div", {
      className: "dsep"
    }, dateSep(msg.created_at)), /*#__PURE__*/React.createElement("div", {
      className: 'mr gm' + (isMine ? ' ismine' : '')
    }, showName && /*#__PURE__*/React.createElement("span", {
      className: "slbl"
    }, msg.sender_name), msg.message && /*#__PURE__*/React.createElement("div", {
      className: "bbl"
    }, msg.message), msg.files && msg.files.map(function (f, fi) {
      if (isImg(f.mime_type)) return /*#__PURE__*/React.createElement("img", {
        key: fi,
        className: "imgprev",
        src: f.url,
        alt: "",
        onClick: function () {
          setLightbox(f.url);
        }
      });
      return /*#__PURE__*/React.createElement("a", {
        key: fi,
        className: "fcard",
        href: f.url,
        target: "_blank",
        rel: "noopener noreferrer"
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 19
        }
      }, fileIcon(f.mime_type)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
        className: "fname"
      }, f.original_name), /*#__PURE__*/React.createElement("div", {
        className: "fsize"
      }, fmtBytes(f.file_size))));
    }), /*#__PURE__*/React.createElement("div", {
      className: "mmeta"
    }, /*#__PURE__*/React.createElement("span", {
      className: "mtime"
    }, fmtMsgTime(msg.created_at)))));
  }), /*#__PURE__*/React.createElement("div", {
    ref: bottomRef
  })), /*#__PURE__*/React.createElement("div", {
    className: "cwrap"
  }, pendFile && /*#__PURE__*/React.createElement("div", {
    className: "fpbar"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, fileIcon(pendFile.type)), /*#__PURE__*/React.createElement("span", {
    className: "fp-nm"
  }, pendFile.name), /*#__PURE__*/React.createElement("button", {
    className: "fp-rm",
    onClick: function () {
      setPendFile(null);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "crow"
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    style: {
      display: 'none'
    },
    accept: "image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt",
    onChange: function (e) {
      if (e.target.files[0]) setPendFile(e.target.files[0]);
      e.target.value = '';
    }
  }), /*#__PURE__*/React.createElement("button", {
    className: "catt",
    onClick: function () {
      fileRef.current && fileRef.current.click();
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCE",
    size: 18
  })), /*#__PURE__*/React.createElement("textarea", {
    className: "cinput",
    placeholder: "Send a group message\u2026 (Enter to send)",
    value: compose,
    onChange: function (e) {
      setCompose(e.target.value);
    },
    onKeyDown: onKey,
    rows: 1
  }), /*#__PURE__*/React.createElement("button", {
    className: 'bsend bsend-g',
    onClick: handleSend,
    disabled: sending || !compose.trim() && !pendFile
  }, sending ? '…' : 'Send ▶')))), subTab === 'resources' && /*#__PURE__*/React.createElement("div", {
    className: "reswrap"
  }, resources.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '48px 0',
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  }), " No resources yet. Click \"Share\" to add!"), /*#__PURE__*/React.createElement("div", {
    className: "resgrid"
  }, resources.map(function (r) {
    return /*#__PURE__*/React.createElement("a", {
      key: r.id,
      className: "rescard",
      href: r.url,
      target: "_blank",
      rel: "noopener noreferrer"
    }, /*#__PURE__*/React.createElement("span", {
      className: "res-ic"
    }, fileIcon(r.mime_type)), /*#__PURE__*/React.createElement("div", {
      className: "res-ti"
    }, r.title), r.description && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-soft)',
        lineHeight: 1.4
      }
    }, r.description), /*#__PURE__*/React.createElement("div", {
      className: "res-mt"
    }, "By", ' ', r.shared_by_name, ' ', "\xB7", ' ', fmtBytes(r.file_size)));
  }))), subTab === 'members' && /*#__PURE__*/React.createElement("div", {
    className: "reswrap"
  }, members.map(function (m) {
    return /*#__PURE__*/React.createElement("div", {
      key: m.id,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '10px 12px',
        border: '1.5px solid var(--border)',
        borderRadius: 10,
        marginBottom: 8
      }
    }, /*#__PURE__*/React.createElement(Av, {
      name: m.full_name,
      src: m.photo_url,
      size: 38
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13.5,
        fontWeight: 700,
        color: 'var(--text-dark)'
      }
    }, m.full_name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-soft)'
      }
    }, m.role, " \xB7 Joined", ' ', fmtConvTime(m.joined_at))), m.group_role === 'owner' && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        color: '#D97706',
        background: '#FEF3C7',
        padding: '2px 8px',
        borderRadius: 5
      }
    }, "Owner"));
  })))), showNG && /*#__PURE__*/React.createElement(NewGroupModal, {
    onClose: function () {
      setShowNG(false);
    },
    onCreated: function () {
      setShowNG(false);
      loadGroups();
      showToastGlobal(setToast, 'Group created!');
    }
  }), showRU && selGrp && /*#__PURE__*/React.createElement(UploadResModal, {
    groupId: selGrp,
    onClose: function () {
      setShowRU(false);
    },
    onUploaded: function () {
      setShowRU(false);
      reloadRes();
      showToastGlobal(setToast, 'Resource shared!');
    }
  }), showAG && /*#__PURE__*/React.createElement(BrowseGroupsModal, {
    onClose: function () {
      setShowAG(false);
    },
    onJoined: function () {
      setShowAG(false);
      loadGroups();
      showToastGlobal(setToast, 'Joined group!');
    }
  }), lightbox && /*#__PURE__*/React.createElement("div", {
    className: "plbox",
    onClick: function () {
      setLightbox(null);
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: lightbox,
    alt: "",
    onClick: function (e) {
      e.stopPropagation();
    }
  })), /*#__PURE__*/React.createElement(Toast, {
    toast: toast
  }));
}

/* ═══════════════════════════════════
ALERTS TAB
═══════════════════════════════════ */
function AlertsTab(props) {
  var myId = props.myId;
  var listTabSt = useState('received');
  var listTab = listTabSt[0];
  var setListTab = listTabSt[1];
  var myAlertsSt = useState([]);
  var myAlerts = myAlertsSt[0];
  var setMyAlerts = myAlertsSt[1];
  var sentSt = useState([]);
  var sentAlerts = sentSt[0];
  var setSentAlerts = sentSt[1];
  var selSt = useState(null);
  var selAlert = selSt[0];
  var setSelAlert = selSt[1];
  var viewSt = useState('list');
  var viewMode = viewSt[0];
  var setViewMode = viewSt[1];
  var loadingSt = useState(true);
  var loading = loadingSt[0];
  var setLoading = loadingSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];
  useEffect(function () {
    loadAlerts();
  }, []);
  function loadAlerts() {
    setLoading(true);
    Promise.all([apiGet('my_alerts').then(function (r) {
      return r.json();
    }), apiGet('sent_alerts').then(function (r) {
      return r.json();
    })]).then(function (results) {
      if (results[0].success) setMyAlerts(results[0].data || []);
      if (results[1].success) setSentAlerts(results[1].data || []);
      setLoading(false);
    });
  }
  function openAlert(al) {
    setSelAlert(al);
    setViewMode('detail');
    if (al.is_read == 0) {
      fetch(API + '?action=mark_alert_read&alert_id=' + al.id, {
        method: 'POST',
        credentials: 'same-origin'
      }).then(function () {
        setMyAlerts(function (prev) {
          return prev.map(function (a) {
            return a.id === al.id ? Object.assign({}, a, {
              is_read: 1
            }) : a;
          });
        });
      });
    }
  }
  var activeList = listTab === 'received' ? myAlerts : sentAlerts;
  var unreadCount = myAlerts.filter(function (a) {
    return a.is_read == 0;
  }).length;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "lp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lp-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lp-title"
  }, "Alerts"), /*#__PURE__*/React.createElement("button", {
    className: "lp-btn lp-btn-amber",
    onClick: function () {
      setViewMode('compose');
      setSelAlert(null);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  }), " Send")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 2,
      padding: '7px 10px',
      borderBottom: '1px solid var(--border)',
      background: '#FAFBFC',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: 'stab' + (listTab === 'received' ? ' ag' : ''),
    style: {
      flex: 1,
      borderBottom: 'none',
      borderRadius: 7,
      fontSize: 12,
      padding: '6px'
    },
    onClick: function () {
      setListTab('received');
    }
  }, "Received", ' ', unreadCount > 0 && /*#__PURE__*/React.createElement("span", {
    className: "tab-badge",
    style: {
      background: '#F59E0B',
      marginLeft: 4
    }
  }, unreadCount)), /*#__PURE__*/React.createElement("button", {
    className: 'stab' + (listTab === 'sent' ? ' ag' : ''),
    style: {
      flex: 1,
      borderBottom: 'none',
      borderRadius: 7,
      fontSize: 12,
      padding: '6px'
    },
    onClick: function () {
      setListTab('sent');
    }
  }, "Sent")), /*#__PURE__*/React.createElement("div", {
    className: "lp-list"
  }, loading && [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        padding: '11px 13px',
        borderBottom: '1px solid #F8FAFC'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '70%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '50%'
      }
    }));
  }), !loading && activeList.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "lp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, listTab === 'received' ? 'No alerts received' : 'No alerts sent')), !loading && activeList.map(function (al) {
    return /*#__PURE__*/React.createElement("div", {
      key: al.id,
      className: 'ali' + (selAlert && selAlert.id === al.id ? ' active' : '') + (al.is_read == 0 ? ' unread' : ''),
      onClick: function () {
        openAlert(al);
      }
    }, /*#__PURE__*/React.createElement(PrioBadge, {
      priority: al.priority
    }), /*#__PURE__*/React.createElement("div", {
      className: "ali-tit"
    }, al.title), /*#__PURE__*/React.createElement("div", {
      className: "ali-from"
    }, listTab === 'received' ? 'From: ' + (al.sender_name || 'Admin') : 'To: ' + (al.target_role || 'specific'), ' ', "\xB7", ' ', fmtConvTime(al.created_at)));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "rp"
  }, viewMode === 'list' && !selAlert && /*#__PURE__*/React.createElement("div", {
    className: "rp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "Select an alert to view details"), /*#__PURE__*/React.createElement("small", null, "Use alerts for urgent notices to teachers, parents, or individuals")), viewMode === 'detail' && selAlert && /*#__PURE__*/React.createElement("div", {
    className: "al-det"
  }, /*#__PURE__*/React.createElement(PrioBadge, {
    priority: selAlert.priority
  }), /*#__PURE__*/React.createElement("div", {
    className: "al-dt"
  }, selAlert.title), /*#__PURE__*/React.createElement("div", {
    className: "al-dm"
  }, /*#__PURE__*/React.createElement("span", null, "From:", ' ', /*#__PURE__*/React.createElement("strong", null, selAlert.sender_name || 'You')), /*#__PURE__*/React.createElement("span", null, fmtFull(selAlert.created_at)), selAlert.recipient_count != null && /*#__PURE__*/React.createElement("span", null, "Read: ", selAlert.read_count || 0, "/", selAlert.recipient_count)), /*#__PURE__*/React.createElement("div", {
    className: "al-db"
  }, selAlert.body)), viewMode === 'compose' && /*#__PURE__*/React.createElement(SendAlertForm, {
    onSent: function () {
      loadAlerts();
      setViewMode('list');
      showToastGlobal(setToast, 'Alert sent!');
    },
    onCancel: function () {
      setViewMode(selAlert ? 'detail' : 'list');
    }
  })), /*#__PURE__*/React.createElement(Toast, {
    toast: toast
  }));
}
function SendAlertForm(props) {
  var titleSt = useState('');
  var title = titleSt[0];
  var setTitle = titleSt[1];
  var bodySt = useState('');
  var body = bodySt[0];
  var setBody = bodySt[1];
  var prioSt = useState('medium');
  var prio = prioSt[0];
  var setPrio = prioSt[1];
  var targetSt = useState('admin');
  var target = targetSt[0];
  var setTarget = targetSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];
  var roles = [{
    v: 'admin',
    l: 'Admin'
  }, {
    v: 'parent',
    l: 'All Parents'
  }];
  function handleSend() {
    if (!title || !body) {
      showToastGlobal(setToast, 'Title and message required', 'error');
      return;
    }
    setSending(true);
    apiPost('send_alert', {
      title: title,
      body: body,
      priority: prio,
      target_type: 'role',
      target_role: target
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) props.onSent && props.onSent();else {
        showToastGlobal(setToast, d.error || d.message || 'Failed', 'error');
        setSending(false);
      }
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "cform"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cftit"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  }), " Send an Alert"), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Title ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    className: "finp",
    placeholder: "What is this alert about?",
    value: title,
    onChange: function (e) {
      setTitle(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Message ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "ftxt",
    placeholder: "Describe the alert clearly and concisely\u2026",
    value: body,
    onChange: function (e) {
      setBody(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Priority"), /*#__PURE__*/React.createElement("div", {
    className: "selwrap"
  }, /*#__PURE__*/React.createElement("select", {
    className: "fsel",
    value: prio,
    onChange: function (e) {
      setPrio(e.target.value);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "low"
  }, "Low"), /*#__PURE__*/React.createElement("option", {
    value: "medium"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD35",
    size: 18
  }), " Medium"), /*#__PURE__*/React.createElement("option", {
    value: "high"
  }, "High"), /*#__PURE__*/React.createElement("option", {
    value: "urgent"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD34",
    size: 18
  }), " Urgent")))), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Send To"), /*#__PURE__*/React.createElement("div", {
    className: "selwrap"
  }, /*#__PURE__*/React.createElement("select", {
    className: "fsel",
    value: target,
    onChange: function (e) {
      setTarget(e.target.value);
    }
  }, roles.map(function (r) {
    return /*#__PURE__*/React.createElement("option", {
      key: r.v,
      value: r.v
    }, r.l);
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      paddingTop: 4
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onCancel
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "bprimary amber",
    onClick: handleSend,
    disabled: sending
  }, sending && /*#__PURE__*/React.createElement("span", {
    className: "bspinner"
  }), /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  }), "Send Alert")), /*#__PURE__*/React.createElement(Toast, {
    toast: toast
  }));
}

/* ═══════════════════════════════════
BROADCAST TAB
═══════════════════════════════════ */
function BroadcastTab() {
  var bcTabSt = useState('announcements');
  var bcTab = bcTabSt[0];
  var setBcTab = bcTabSt[1];
  var annsSt = useState([]);
  var anns = annsSt[0];
  var setAnns = annsSt[1];
  var nlsSt = useState([]);
  var nls = nlsSt[0];
  var setNls = nlsSt[1];
  var showAnnSt = useState(false);
  var showAnn = showAnnSt[0];
  var setShowAnn = showAnnSt[1];
  var showNlSt = useState(false);
  var showNl = showNlSt[0];
  var setShowNl = showNlSt[1];
  var selNlSt = useState(null);
  var selNl = selNlSt[0];
  var setSelNl = selNlSt[1];
  var loadingSt = useState(true);
  var loading = loadingSt[0];
  var setLoading = loadingSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];
  useEffect(function () {
    loadAll();
  }, []);
  function loadAll() {
    setLoading(true);
    Promise.all([apiGet('announcements').then(function (r) {
      return r.json();
    }), apiGet('newsletters').then(function (r) {
      return r.json();
    })]).then(function (results) {
      if (results[0].success) setAnns(results[0].data || []);
      if (results[1].success) setNls(results[1].data || []);
      setLoading(false);
    });
  }
  function delAnn(id) {
    if (!confirm('Delete this announcement?')) return;
    fetch(API + '?action=delete_announcement&id=' + id, {
      method: 'POST',
      credentials: 'same-origin'
    }).then(function () {
      setAnns(function (p) {
        return p.filter(function (a) {
          return a.id !== id;
        });
      });
      showToastGlobal(setToast, 'Deleted');
    });
  }
  function delNl(id) {
    if (!confirm('Delete this newsletter?')) return;
    fetch(API + '?action=delete_newsletter&id=' + id, {
      method: 'POST',
      credentials: 'same-origin'
    }).then(function () {
      setNls(function (p) {
        return p.filter(function (n) {
          return n.id !== id;
        });
      });
      setSelNl(null);
      showToastGlobal(setToast, 'Deleted');
    });
  }
  var TL = {
    all: 'All',
    teacher: 'Teachers',
    parent: 'Parents',
    admin: 'Admins'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 18px',
      borderBottom: '1px solid var(--border)',
      background: '#FAFBFC',
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "bcsubs",
    style: {
      margin: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: 'bcst' + (bcTab === 'announcements' ? ' active' : ''),
    onClick: function () {
      setBcTab('announcements');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE2",
    size: 18
  }), " Announcements (", anns.length, ")"), /*#__PURE__*/React.createElement("button", {
    className: 'bcst' + (bcTab === 'newsletters' ? ' active' : ''),
    onClick: function () {
      setBcTab('newsletters');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF0",
    size: 18
  }), " Newsletters (", nls.length, ")"))), /*#__PURE__*/React.createElement("div", {
    className: "bcwrap"
  }, loading && [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "anncard"
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '60%',
        marginBottom: 10,
        height: 16
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '90%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '70%'
      }
    }));
  }), !loading && bcTab === 'announcements' && (anns.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '48px 0',
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE2",
    size: 18
  }), " No announcements yet") : anns.map(function (a) {
    return /*#__PURE__*/React.createElement("div", {
      key: a.id,
      className: 'anncard' + (a.pinned ? ' pinned' : '')
    }, /*#__PURE__*/React.createElement("div", {
      className: "ann-hd"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ann-ti"
    }, a.title), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 7
      }
    }, a.pinned && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        color: '#7C3AED',
        background: '#F3E8FF',
        padding: '2px 7px',
        borderRadius: 5
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCC",
      size: 18
    }), " Pinned"), /*#__PURE__*/React.createElement("span", {
      className: "tpill"
    }, TL[a.target_role] || a.target_role))), /*#__PURE__*/React.createElement("div", {
      className: "ann-bd"
    }, a.body), /*#__PURE__*/React.createElement("div", {
      className: "ann-ft"
    }, /*#__PURE__*/React.createElement(Av, {
      name: a.author_name,
      src: a.author_photo,
      size: 22
    }), /*#__PURE__*/React.createElement("span", null, a.author_name), /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto'
      }
    }, fmtFull(a.created_at)), a.expires_at && /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#D97706',
        fontSize: 11
      }
    }, "Expires", ' ', fmtConvTime(a.expires_at))));
  })), !loading && bcTab === 'newsletters' && (selNl ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("button", {
    className: "lp-btn",
    style: {
      background: '#F1F5F9',
      color: 'var(--text-dark)',
      marginBottom: 16
    },
    onClick: function () {
      setSelNl(null);
    }
  }, "\u2190 Back to list"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 19,
      marginBottom: 8,
      color: 'var(--text-dark)'
    }
  }, selNl.subject), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-soft)',
      marginBottom: 16,
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", null, "From:", ' ', /*#__PURE__*/React.createElement("strong", null, selNl.author_name)), /*#__PURE__*/React.createElement("span", null, fmtFull(selNl.created_at)), /*#__PURE__*/React.createElement("span", null, "Audience:", ' ', /*#__PURE__*/React.createElement("strong", null, TL[selNl.target_role]))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      lineHeight: 1.8,
      color: 'var(--text-dark)',
      whiteSpace: 'pre-wrap',
      background: '#FAFBFC',
      borderRadius: 10,
      padding: 20
    }
  }, selNl.content)) : nls.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '48px 0',
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF0",
    size: 18
  }), " No newsletters yet") : nls.map(function (n) {
    return /*#__PURE__*/React.createElement("div", {
      key: n.id,
      className: "nlcard",
      onClick: function () {
        setSelNl(n);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "nl-su"
    }, n.subject), /*#__PURE__*/React.createElement("div", {
      className: "nl-pv"
    }, n.content), /*#__PURE__*/React.createElement("div", {
      className: "nl-ft"
    }, /*#__PURE__*/React.createElement(Av, {
      name: n.author_name,
      src: n.author_photo,
      size: 20
    }), /*#__PURE__*/React.createElement("span", null, n.author_name), /*#__PURE__*/React.createElement("span", {
      className: "tpill",
      style: {
        marginLeft: 'auto'
      }
    }, TL[n.target_role]), /*#__PURE__*/React.createElement("span", null, fmtConvTime(n.created_at))));
  }))), /*#__PURE__*/React.createElement(Toast, {
    toast: toast
  }));
}

/* ═══════════════════════════════════
MODALS
═══════════════════════════════════ */
function NewDMModal(props) {
  var contactsSt = useState([]);
  var contacts = contactsSt[0];
  var setContacts = contactsSt[1];
  var selSt = useState(null);
  var sel = selSt[0];
  var setSel = selSt[1];
  var searchSt = useState('');
  var search = searchSt[0];
  var setSearch = searchSt[1];
  var msgSt = useState('');
  var msg = msgSt[0];
  var setMsg = msgSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  var loadSt = useState(true);
  var loadingC = loadSt[0];
  var setLoadingC = loadSt[1];
  var loadErrSt = useState('');
  var loadErr = loadErrSt[0];
  var setLoadErr = loadErrSt[1];
  var sendErrSt = useState('');
  var sendErr = sendErrSt[0];
  var setSendErr = sendErrSt[1];
  function loadContacts() {
    setLoadingC(true);
    setLoadErr('');
    apiGet('contacts').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setContacts(d.data || []);else setLoadErr(d.error || 'Could not load contacts.');
    }).catch(function () {
      setLoadErr('Could not load contacts — check your connection and try again.');
    }).finally(function () {
      setLoadingC(false);
    });
  }
  useEffect(function () {
    loadContacts();
  }, []);
  var filtered = contacts.filter(function (c) {
    return !search || c.full_name.toLowerCase().includes(search.toLowerCase());
  });
  function handleSend() {
    if (!sel || !msg.trim()) return;
    setSending(true);
    setSendErr('');
    apiPost('send', {
      recipient_id: sel.id,
      message: msg.trim()
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) props.onSent && props.onSent(sel.id);else setSendErr(d.error || 'Could not send message.');
    }).catch(function () {
      setSendErr('Network error — message was not sent. Please try again.');
    }).finally(function () {
      setSending(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "New Direct Message"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "To"), sel ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 12px',
      border: '2px solid #2563EB',
      borderRadius: 8,
      background: '#EFF6FF'
    }
  }, /*#__PURE__*/React.createElement(Av, {
    name: sel.full_name,
    src: sel.photo_url,
    size: 28
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontSize: 13.5,
      flex: 1
    }
  }, sel.full_name), /*#__PURE__*/React.createElement("button", {
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--text-soft)'
    },
    onClick: function () {
      setSel(null);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))) : /*#__PURE__*/React.createElement("input", {
    className: "finp",
    placeholder: "Search contacts\u2026",
    value: search,
    onChange: function (e) {
      setSearch(e.target.value);
    }
  })), !sel && /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 200,
      overflowY: 'auto',
      border: '1.5px solid var(--border)',
      borderRadius: 8
    }
  }, loadingC && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      textAlign: 'center',
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "Loading\u2026"), !loadingC && loadErr && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: '#B91C1C',
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", loadErr), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    style: {
      background: '#F1F5F9',
      padding: '4px 14px',
      borderRadius: 7,
      fontSize: 12
    },
    onClick: loadContacts
  }, "Retry")), !loadingC && !loadErr && filtered.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      textAlign: 'center',
      fontSize: 12.5,
      color: 'var(--text-muted)'
    }
  }, "No contacts found."), !loadingC && !loadErr && filtered.map(function (c) {
    return /*#__PURE__*/React.createElement("div", {
      key: c.id,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '8px 12px',
        cursor: 'pointer',
        borderBottom: '1px solid #F8FAFC'
      },
      onMouseEnter: function (e) {
        e.currentTarget.style.background = '#F8FBFF';
      },
      onMouseLeave: function (e) {
        e.currentTarget.style.background = '';
      },
      onClick: function () {
        setSel(c);
        setSearch('');
      }
    }, /*#__PURE__*/React.createElement(Av, {
      name: c.full_name,
      src: c.photo_url,
      size: 32
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: 'var(--text-dark)'
      }
    }, c.full_name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--text-soft)'
      }
    }, c.role)));
  })), sel && /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Message ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "ftxt",
    placeholder: "Write your message\u2026",
    value: msg,
    onChange: function (e) {
      setMsg(e.target.value);
    }
  }), sendErr && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#B91C1C',
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", sendErr))), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "bprimary blue",
    onClick: handleSend,
    disabled: !sel || !msg.trim() || sending
  }, sending && /*#__PURE__*/React.createElement("span", {
    className: "bspinner"
  }), "Send ", /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u25B6",
    size: 18
  })))));
}
var GROUP_COLORS = ['#10B981', '#2563EB', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2', '#DB2777', '#0F172A'];
function NewGroupModal(props) {
  var nameSt = useState('');
  var grpName = nameSt[0];
  var setGrpName = nameSt[1];
  var descSt = useState('');
  var desc = descSt[0];
  var setDesc = descSt[1];
  var colorSt = useState('#10B981');
  var color = colorSt[0];
  var setColor = colorSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  function handleCreate() {
    if (!grpName.trim()) return;
    setSending(true);
    apiPost('create_group', {
      name: grpName,
      description: desc,
      color: color
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) props.onCreated && props.onCreated();
      setSending(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "Create Collaboration Group"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Group Name ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    className: "finp",
    placeholder: "e.g. Grade 1 Teachers, Science Team\u2026",
    value: grpName,
    onChange: function (e) {
      setGrpName(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Description"), /*#__PURE__*/React.createElement("textarea", {
    className: "ftxt",
    placeholder: "What is this group for?",
    value: desc,
    onChange: function (e) {
      setDesc(e.target.value);
    },
    style: {
      minHeight: 70
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Group Color"), /*#__PURE__*/React.createElement("div", {
    className: "cpicker"
  }, GROUP_COLORS.map(function (c) {
    return /*#__PURE__*/React.createElement("div", {
      key: c,
      className: 'cswatch' + (color === c ? ' sel' : ''),
      style: {
        background: c
      },
      onClick: function () {
        setColor(c);
      }
    });
  })))), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "bprimary green",
    onClick: handleCreate,
    disabled: !grpName.trim() || sending
  }, sending && /*#__PURE__*/React.createElement("span", {
    className: "bspinner"
  }), "Create Group"))));
}
function BrowseGroupsModal(props) {
  var groupsSt = useState([]);
  var groups = groupsSt[0];
  var setGroups = groupsSt[1];
  var joiningSt = useState(null);
  var joiningId = joiningSt[0];
  var setJoiningId = joiningSt[1];
  var loadSt = useState(true);
  var loadingG = loadSt[0];
  var setLoadingG = loadSt[1];
  useEffect(function () {
    apiGet('available_groups').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setGroups(d.data || []);
      setLoadingG(false);
    });
  }, []);
  function joinGroup(gid) {
    setJoiningId(gid);
    fetch(API + '?action=join_group&group_id=' + gid, {
      method: 'POST',
      credentials: 'same-origin'
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setGroups(function (p) {
          return p.map(function (g) {
            return g.id === gid ? Object.assign({}, g, {
              is_member: 1
            }) : g;
          });
        });
        props.onJoined && props.onJoined();
      }
      setJoiningId(null);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "Browse Groups"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, loadingG && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      textAlign: 'center',
      color: 'var(--text-muted)'
    }
  }, "Loading\u2026"), !loadingG && groups.map(function (g) {
    return /*#__PURE__*/React.createElement("div", {
      key: g.id,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '10px 12px',
        border: '1.5px solid var(--border)',
        borderRadius: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 38,
        height: 38,
        background: g.avatar_color || '#10B981',
        borderRadius: 9,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 16,
        fontWeight: 800,
        color: 'white',
        flexShrink: 0
      }
    }, g.name[0].toUpperCase()), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13.5,
        fontWeight: 700,
        color: 'var(--text-dark)'
      }
    }, g.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-soft)'
      }
    }, g.member_count, " member", g.member_count != 1 ? 's' : '', g.description ? ' · ' + g.description : '')), g.is_member == 1 ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        color: '#059669',
        background: '#ECFDF5',
        padding: '3px 9px',
        borderRadius: 5
      }
    }, "Joined") : /*#__PURE__*/React.createElement("button", {
      className: "bprimary green",
      style: {
        padding: '6px 14px',
        fontSize: 12
      },
      onClick: function () {
        joinGroup(g.id);
      },
      disabled: joiningId === g.id
    }, joiningId === g.id ? /*#__PURE__*/React.createElement("span", {
      className: "bspinner"
    }) : 'Join'));
  }), !loadingG && groups.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: 20,
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, "No groups available yet.")), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Close"))));
}
function UploadResModal(props) {
  var titleSt = useState('');
  var resTitle = titleSt[0];
  var setResTitle = titleSt[1];
  var descSt = useState('');
  var resDesc = descSt[0];
  var setResDesc = descSt[1];
  var fileSt = useState(null);
  var file = fileSt[0];
  var setFile = fileSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  var fileRef = useRef(null);
  function handleUpload() {
    if (!resTitle.trim() || !file) return;
    setSending(true);
    var fd = new FormData();
    fd.append('title', resTitle);
    fd.append('description', resDesc);
    fd.append('group_id', props.groupId);
    fd.append('attachment', file);
    apiForm('upload_resource', fd).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) props.onUploaded && props.onUploaded();
      setSending(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "Share a Resource"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Title ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    className: "finp",
    placeholder: "Resource title\u2026",
    value: resTitle,
    onChange: function (e) {
      setResTitle(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Description"), /*#__PURE__*/React.createElement("textarea", {
    className: "ftxt",
    placeholder: "Briefly describe this resource\u2026",
    value: resDesc,
    onChange: function (e) {
      setResDesc(e.target.value);
    },
    style: {
      minHeight: 70
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "File ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    style: {
      display: 'none'
    },
    accept: "image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.pptx",
    onChange: function (e) {
      if (e.target.files[0]) setFile(e.target.files[0]);
    }
  }), file ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '8px 12px',
      border: '2px solid var(--border)',
      borderRadius: 8,
      background: '#F8FAFC'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 20
    }
  }, fileIcon(file.type)), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 12.5,
      fontWeight: 600
    }
  }, file.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, fmtBytes(file.size)), /*#__PURE__*/React.createElement("button", {
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--text-soft)'
    },
    onClick: function () {
      setFile(null);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))) : /*#__PURE__*/React.createElement("button", {
    className: "finp",
    style: {
      cursor: 'pointer',
      textAlign: 'left',
      color: 'var(--text-soft)'
    },
    onClick: function () {
      fileRef.current && fileRef.current.click();
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCE",
    size: 18
  }), " Choose file\u2026"))), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "bprimary green",
    onClick: handleUpload,
    disabled: !resTitle.trim() || !file || sending
  }, sending && /*#__PURE__*/React.createElement("span", {
    className: "bspinner"
  }), "Share Resource"))));
}
function NewAnnModal(props) {
  var titleSt = useState('');
  var title = titleSt[0];
  var setTitle = titleSt[1];
  var bodySt = useState('');
  var body = bodySt[0];
  var setBody = bodySt[1];
  var targetSt = useState('all');
  var target = targetSt[0];
  var setTarget = targetSt[1];
  var pinnedSt = useState(false);
  var pinned = pinnedSt[0];
  var setPinned = pinnedSt[1];
  var expSt = useState('');
  var expires = expSt[0];
  var setExpires = expSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  function handlePost() {
    if (!title || !body) return;
    setSending(true);
    apiPost('post_announcement', {
      title: title,
      body: body,
      target_role: target,
      pinned: pinned ? 1 : 0,
      expires_at: expires
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) props.onPosted && props.onPosted();
      setSending(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "Post Announcement"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Title ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    className: "finp",
    placeholder: "Announcement title\u2026",
    value: title,
    onChange: function (e) {
      setTitle(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Content ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "ftxt",
    placeholder: "Write your announcement\u2026",
    value: body,
    onChange: function (e) {
      setBody(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Audience"), /*#__PURE__*/React.createElement("div", {
    className: "selwrap"
  }, /*#__PURE__*/React.createElement("select", {
    className: "fsel",
    value: target,
    onChange: function (e) {
      setTarget(e.target.value);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "all"
  }, "Everyone"), /*#__PURE__*/React.createElement("option", {
    value: "teacher"
  }, "Teachers"), /*#__PURE__*/React.createElement("option", {
    value: "parent"
  }, "Parents"), /*#__PURE__*/React.createElement("option", {
    value: "admin"
  }, "Admins")))), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Expires (optional)"), /*#__PURE__*/React.createElement("input", {
    className: "finp",
    type: "date",
    value: expires,
    onChange: function (e) {
      setExpires(e.target.value);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    id: "ann-pin",
    checked: pinned,
    onChange: function (e) {
      setPinned(e.target.checked);
    },
    style: {
      width: 16,
      height: 16,
      accentColor: '#7C3AED'
    }
  }), /*#__PURE__*/React.createElement("label", {
    htmlFor: "ann-pin",
    style: {
      fontSize: 13.5,
      fontWeight: 600,
      color: 'var(--text-dark)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCC",
    size: 18
  }), " Pin this announcement"))), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "bprimary violet",
    onClick: handlePost,
    disabled: !title || !body || sending
  }, sending && /*#__PURE__*/React.createElement("span", {
    className: "bspinner"
  }), "Post Announcement"))));
}
function NewNlModal(props) {
  var subjectSt = useState('');
  var subject = subjectSt[0];
  var setSubject = subjectSt[1];
  var contentSt = useState('');
  var content = contentSt[0];
  var setContent = contentSt[1];
  var targetSt = useState('all');
  var target = targetSt[0];
  var setTarget = targetSt[1];
  var sendingSt = useState(false);
  var sending = sendingSt[0];
  var setSending = sendingSt[1];
  function handlePost() {
    if (!subject || !content) return;
    setSending(true);
    apiPost('post_newsletter', {
      subject: subject,
      content: content,
      target_role: target
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) props.onPosted && props.onPosted();
      setSending(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal lg"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "Post Newsletter"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Subject ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    className: "finp",
    placeholder: "Newsletter subject\u2026",
    value: subject,
    onChange: function (e) {
      setSubject(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Audience"), /*#__PURE__*/React.createElement("div", {
    className: "selwrap"
  }, /*#__PURE__*/React.createElement("select", {
    className: "fsel",
    value: target,
    onChange: function (e) {
      setTarget(e.target.value);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "all"
  }, "Everyone"), /*#__PURE__*/React.createElement("option", {
    value: "teacher"
  }, "Teachers"), /*#__PURE__*/React.createElement("option", {
    value: "parent"
  }, "Parents"), /*#__PURE__*/React.createElement("option", {
    value: "admin"
  }, "Admins")))), /*#__PURE__*/React.createElement("div", null)), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Content ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "ftxt",
    placeholder: "Write the full newsletter content here\u2026",
    value: content,
    onChange: function (e) {
      setContent(e.target.value);
    },
    style: {
      minHeight: 180
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "bprimary violet",
    onClick: handlePost,
    disabled: !subject || !content || sending
  }, sending && /*#__PURE__*/React.createElement("span", {
    className: "bspinner"
  }), "Post Newsletter"))));
}

/* ═══════════════════════════════════
MAIN APP
═══════════════════════════════════ */
function PulseApp() {
  var tabSt = useState('messages');
  var activeTab = tabSt[0];
  var setActiveTab = tabSt[1];
  var myIdSt = useState(0);
  var myId = myIdSt[0];
  var setMyId = myIdSt[1];
  var collapsedSt = useState(false);
  var collapsed = collapsedSt[0];
  var setCollapsed = collapsedSt[1];
  var countsSt = useState({
    dm: 0,
    alerts: 0
  });
  var counts = countsSt[0];
  var setCounts = countsSt[1];
  var darkModeSt = useState(function () {
    try {
      return localStorage.getItem('j11pulse_dark') === '1';
    } catch (e) {
      return false;
    }
  });
  var darkMode = darkModeSt[0];
  var setDarkMode = darkModeSt[1];
  useEffect(function () {
    document.body.classList.toggle('pulse-dark', darkMode);
  }, [darkMode]);
  function toggleDarkMode() {
    setDarkMode(function (d) {
      var next = !d;
      try {
        localStorage.setItem('j11pulse_dark', next ? '1' : '0');
      } catch (e) {}
      return next;
    });
  }
  useEffect(function () {
    apiGet('whoami').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setMyId(d.data.id);
    });
    function loadCounts() {
      apiGet('unread_counts').then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) setCounts(d.data);
      });
    }
    loadCounts();
    var t = setInterval(loadCounts, 15000);
    return function () {
      clearInterval(t);
    };
  }, []);
  var TABS = [{
    key: 'messages',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCAC",
      size: 20
    }),
    label: 'Messages',
    dot: '#2563EB',
    badge: counts.dm
  }, {
    key: 'collab',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDC65",
      size: 20
    }),
    label: 'Collaboration Hub',
    dot: '#10B981',
    badge: counts.collab
  }, {
    key: 'alerts',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD14",
      size: 20
    }),
    label: 'Alerts',
    dot: '#F59E0B',
    badge: counts.alerts
  }, {
    key: 'broadcast',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCE2",
      size: 20
    }),
    label: 'Broadcast',
    dot: '#8B5CF6',
    badge: 0
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TeacherNavbar, {
    activePage: "pulse",
    onToggleSidebar: function () {
      setCollapsed(function (c) {
        return !c;
      });
    }
  }), /*#__PURE__*/React.createElement(TeacherSidebar, {
    items: TEACHER_SIDEBAR_ITEMS,
    activePage: "pulse",
    collapsed: collapsed
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (collapsed ? ' collapsed' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulse-shell"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulse-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulse-brand"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulse-icon"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 12h3l3-8 4 16 3-8h7",
    stroke: "white",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "pulse-logo-text"
  }, "J11 Pulse"), /*#__PURE__*/React.createElement("div", {
    className: "pulse-tagline"
  }, "Communication Hub"))), /*#__PURE__*/React.createElement("button", {
    className: "dark-toggle",
    title: darkMode ? 'Switch to light mode' : 'Switch to dark mode',
    onClick: toggleDarkMode
  }, darkMode ? /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2600",
    size: 16
  }) : '🌙')), /*#__PURE__*/React.createElement("div", {
    className: "pulse-tabs"
  }, TABS.map(function (t) {
    return /*#__PURE__*/React.createElement("button", {
      key: t.key,
      className: 'pulse-tab' + (activeTab === t.key ? ' active' : ''),
      onClick: function () {
        setActiveTab(t.key);
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "tab-dot",
      style: {
        background: activeTab === t.key ? t.dot : '#CBD5E1'
      }
    }), renderIcon(t.icon, 20), " ", t.label, t.badge > 0 && /*#__PURE__*/React.createElement("span", {
      className: "tab-badge",
      style: {
        background: t.dot
      }
    }, t.badge));
  })), /*#__PURE__*/React.createElement("div", {
    className: "pulse-content"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: activeTab === 'messages' ? 'contents' : 'none'
    }
  }, /*#__PURE__*/React.createElement(MessagesTab, {
    myId: myId
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: activeTab === 'collab' ? 'contents' : 'none'
    }
  }, /*#__PURE__*/React.createElement(CollabTab, {
    myId: myId
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: activeTab === 'alerts' ? 'contents' : 'none'
    }
  }, /*#__PURE__*/React.createElement(AlertsTab, {
    myId: myId
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: activeTab === 'broadcast' ? 'contents' : 'none'
    }
  }, /*#__PURE__*/React.createElement(BroadcastTab, null)))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(PulseApp, null));