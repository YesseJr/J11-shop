const {
  useState,
  useEffect,
  useCallback,
  useRef,
  useMemo
} = React;
const API = '/nsms/api/payment-gateway.php';
const fmtF = v => 'TSh ' + (Number(v) || 0).toLocaleString('en-TZ', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 0
});
const fmtD = v => {
  if (!v) return '—';
  const d = new Date((v + '').replace(' ', 'T'));
  return isNaN(d.getTime()) ? v : d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
};
const fmtDT = v => {
  if (!v) return '—';
  const d = new Date((v + '').replace(' ', 'T'));
  return isNaN(d.getTime()) ? v : d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  }) + ' · ' + d.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit'
  });
};
const pct = (a, b) => b > 0 ? Math.min(100, Math.round(a / b * 100)) : 0;
const todayStr = () => new Date().toISOString().split('T')[0];
const STATUS_M = {
  pending_verification: {
    lbl: 'Pending',
    cls: 'xy',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD50",
      size: 20
    })
  },
  received: {
    lbl: 'Received',
    cls: 'xg',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2705",
      size: 20
    })
  },
  rejected: {
    lbl: 'Rejected',
    cls: 'xr',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u274C",
      size: 20
    })
  }
};
const FEE_ICONS = {
  'Registration Fee': '📝',
  Stationery: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F",
    size: 16
  }),
  Uniform: '👕',
  Meals: '🍽️',
  Transport: '🚌',
  'School Fees': '🏫'
};
const FEE_BG = {
  'Registration Fee': '#DBEAFE',
  Stationery: '#FCE7F3',
  Uniform: '#D1FAE5',
  Meals: '#FEF3C7',
  Transport: '#EDE9FE',
  'School Fees': '#DBEAFE'
};
const FEE_CLR = {
  'Registration Fee': '#1E40AF',
  Stationery: '#9D174D',
  Uniform: '#065F46',
  Meals: '#92400E',
  Transport: '#5B21B6',
  'School Fees': '#1E40AF'
};

/* Logo files expected at /nsms/public/includes/images/.
If a file is missing, the <img onError> falls back to the emoji tile
automatically — nothing breaks while icons are still being added. */
const LOGO_BASE = '/nsms/public/includes/images/';
const MOBILE_METHODS = [{
  key: 'M-Pesa',
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF1",
    size: 20
  }),
  lbl: 'M-Pesa',
  logo: LOGO_BASE + 'mpesa.png'
}, {
  key: 'Tigo Pesa',
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF1",
    size: 20
  }),
  lbl: 'Tigo Pesa',
  logo: LOGO_BASE + 'tigopesa.svg'
}, {
  key: 'Airtel Money',
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF1",
    size: 20
  }),
  lbl: 'Airtel Money',
  logo: LOGO_BASE + 'airtelmoney.png'
}, {
  key: 'HaloPesa',
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF1",
    size: 20
  }),
  lbl: 'HaloPesa',
  logo: LOGO_BASE + 'halopesa.png'
}, {
  key: 'Mixx by Yas',
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF1",
    size: 20
  }),
  lbl: 'Mixx by Yas',
  logo: LOGO_BASE + 'mixxbyyas.jpg'
}];
const CARD_METHODS = [{
  key: 'Visa',
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB3",
    size: 20
  }),
  lbl: 'Visa',
  logo: LOGO_BASE + 'visa.png'
}, {
  key: 'Mastercard',
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB3",
    size: 20
  }),
  lbl: 'Mastercard',
  logo: LOGO_BASE + 'mastercard.png'
}];
const CONTROL_METHODS = [{ key: 'Control Number', icon: null, lbl: 'Control Number', logo: null }];
const BRAND_CLASS = {
  'M-Pesa': 'brand-mpesa',
  'Tigo Pesa': 'brand-tigo',
  'Airtel Money': 'brand-airtel',
  'HaloPesa': 'brand-halo',
  'Mixx by Yas': 'brand-mixx',
  'Visa': 'brand-visa',
  'Mastercard': 'brand-mastercard',
  'Control Number': 'brand-control'
};
function brandClass(key) {
  return BRAND_CLASS[key] || '';
}
const MM_PREFIX_MAP = [[['074', '075', '076'], 'Vodacom'], [['068', '069', '078', '073'], 'Airtel'], [['071', '065', '067'], 'Tigo/Yas'], [['062', '061'], 'Halotel'], [['077'], 'Zantel']];
function detectProviderClient(phone) {
  const digits = (phone || '').replace(/\D/g, '').replace(/^255/, '0');
  if (digits.length < 4) return null;
  const pre = digits.substring(0, 3);
  for (const [prefixes, name] of MM_PREFIX_MAP) {
    if (prefixes.includes(pre)) return name;
  }
  return digits.length >= 9 ? 'Unknown' : null;
}
function detectCardTypeClient(num) {
  const digits = (num || '').replace(/\D/g, '');
  if (/^4/.test(digits)) return 'Visa';
  if (/^(5[1-5]|22[2-9]|2[3-6][0-9]|27[0-1]|2720)/.test(digits)) return 'Mastercard';
  return null;
}
function formatCardNumber(v) {
  const digits = v.replace(/\D/g, '').slice(0, 19);
  return digits.replace(/(.{4})/g, '$1 ').trim();
}
function formatExpiry(v) {
  const digits = v.replace(/\D/g, '').slice(0, 4);
  if (digits.length >= 3) return digits.slice(0, 2) + '/' + digits.slice(2);
  return digits;
}
const Spin = () => /*#__PURE__*/React.createElement("div", {
  className: "spinner"
});
const SBadge = ({
  status
}) => {
  const m = STATUS_M[status] || {
    lbl: status,
    cls: 'xb',
    icon: '•'
  };
  return /*#__PURE__*/React.createElement("span", {
    className: 'bx ' + m.cls
  }, m.icon, " ", m.lbl);
};

/* Renders a payment method's official logo image; falls back to its
emoji icon automatically if the image file isn't present yet (404). */
const MethodLogo = ({
  method,
  size
}) => {
  const [failed, setFailed] = React.useState(false);
  const all = [...MOBILE_METHODS, ...CARD_METHODS, ...CONTROL_METHODS];
  const m = all.find(x => x.key === method);
  if (!m) return null;
  const s = size || 28;
  if (failed || !m.logo) {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: s * 0.8,
        lineHeight: 1
      }
    }, m.icon);
  }
  return /*#__PURE__*/React.createElement("img", {
    src: m.logo,
    alt: m.lbl,
    className: "gw-logo-img",
    style: {
      width: '100%',
      height: s || 48,
      maxWidth: '100%',
      maxHeight: s || 48,
      objectFit: 'contain',
      objectPosition: 'center',
      display: 'block'
    },
    onError: () => setFailed(true)
  });
};

/* ════════════════════════════════════════
GATEWAY MODAL
Steps: method -> details -> review -> processing -> success
════════════════════════════════════════ */
const PROCESSING_STAGES = [{
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD04",
    size: 20
  }),
  text: 'Initiating payment...'
}, {
  icon: '📡',
  text: 'Connecting to payment gateway...'
}, {
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 20
  }),
  text: 'Verifying payment details...'
}, {
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 20
  }),
  text: 'Payment submitted successfully.'
}];
const GatewayModal = ({
  studentId,
  studentName,
  items,
  onClose,
  onSuccess
}) => {
  const [step, setStep] = useState('method'); // method | details | review | processing | success | error
  const [method, setMethod] = useState(null);
  const [phone, setPhone] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [proof, setProof] = useState(null);
  const [drag, setDrag] = useState(false);
  const [notes, setNotes] = useState('');
  const [err, setErr] = useState('');
  const [stageIdx, setStageIdx] = useState(0);
  const [result, setResult] = useState(null);
  const fileRef = useRef();
  const total = items.reduce((s, i) => s + i.amount, 0);
  const channel = !method ? null : (method === 'Control Number' ? 'control_number' : (CARD_METHODS.some(m => m.key === method) ? 'card' : 'mobile_money'));
  const provider = channel === 'mobile_money' ? detectProviderClient(phone) : null;
  const detectedCardType = channel === 'card' ? detectCardTypeClient(cardNumber) : null;
  const goDetails = m => {
    setMethod(m);
    setErr('');
    setStep('details');
  };
  const validateDetails = () => {
    setErr('');
    if (channel === 'control_number') {
      return true;
    }
    if (channel === 'mobile_money') {
      const digits = phone.replace(/\D/g, '');
      if (digits.length < 9) {
        setErr('Enter a valid phone number');
        return false;
      }
      if (!provider || provider === 'Unknown') {
        setErr('Could not detect network provider from this number');
        return false;
      }
    } else {
      if (!cardHolder.trim()) {
        setErr('Card holder name is required');
        return false;
      }
      const digits = cardNumber.replace(/\D/g, '');
      if (digits.length < 13) {
        setErr('Enter a valid card number');
        return false;
      }
      if (!detectedCardType) {
        setErr('Unrecognized card number');
        return false;
      }
      if (detectedCardType !== method) {
        setErr(`This card number doesn't match ${method}. Detected: ${detectedCardType}`);
        return false;
      }
      if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(cardExpiry)) {
        setErr('Enter expiry as MM/YY');
        return false;
      }
      if (!/^\d{3,4}$/.test(cardCvv)) {
        setErr('Enter a valid CVV');
        return false;
      }
    }
    return true;
  };
  const handleFile = f => {
    if (!f) return;
    const ok = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
    if (!ok.includes(f.type)) {
      setErr('Invalid file type');
      return;
    }
    if (f.size > 5 * 1024 * 1024) {
      setErr('Max file size is 5MB');
      return;
    }
    setErr('');
    setProof(f);
  };
  const goReview = () => {
    if (validateDetails()) setStep('review');
  };
  const confirmPayment = async () => {
    setStep('processing');
    setStageIdx(0);

    // Animate through stages 0..2 with delays, then fire the real request
    for (let i = 0; i < PROCESSING_STAGES.length - 1; i++) {
      await new Promise(res => setTimeout(res, 700));
      setStageIdx(i + 1);
    }
    try {
      const payload = {
        student_id: studentId,
        items: items.map(it => ({
          fee_type: it.feeType,
          installment_no: it.installmentNo,
          amount: it.amount
        })),
        payment_method: method,
        payment_date: todayStr(),
        notes: notes || null
      };
      if (channel === 'mobile_money') {
        payload.phone_number = phone.replace(/\D/g, '');
      } else if (channel === 'card') {
        payload.card_holder_name = cardHolder;
        payload.card_number = cardNumber.replace(/\D/g, '');
        payload.card_expiry = cardExpiry;
        payload.card_cvv = cardCvv;
      }
      const r = await fetch(API + '?action=submit_transaction', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });
      const d = await r.json();
      if (!d.success) {
        setErr(d.error || 'Transaction failed');
        setStep('error');
        return;
      }
      if (proof) {
        const fd = new FormData();
        fd.append('transaction_id', d.data.transaction_id);
        fd.append('proof', proof);
        await fetch(API + '?action=upload_proof', {
          method: 'POST',
          body: fd
        });
      }
      setResult(d.data);
      setStep('success');
    } catch (e) {
      setErr('Network error. Please try again.');
      setStep('error');
    }
  };
  const stepNum = {
    method: 1,
    details: 2,
    review: 3,
    processing: 4,
    success: 4,
    error: 3
  }[step];
  return /*#__PURE__*/React.createElement("div", {
    className: "gw-overlay",
    onClick: step === 'processing' ? undefined : onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-modal",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-head-title"
  }, step === 'method' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB3",
    size: 16
  }), "Choose Payment Method") : step === 'details' ? `${channel === 'card' ? typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '💳',
    size: 16
  }) : null : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📱',
    size: 16
  }) : null} ${method} Details` : step === 'review' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 16
  }), "Review Payment") : step === 'processing' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F3",
    size: 16
  }), "Processing...") : step === 'success' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 16
  }), "Payment Submitted") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 16
  }), "Error")), step !== 'processing' && /*#__PURE__*/React.createElement("button", {
    className: "btn bo bsm",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "gw-body"
  }, step !== 'success' && step !== 'processing' && /*#__PURE__*/React.createElement("div", {
    className: "gw-step-dots"
  }, [1, 2, 3].map(n => /*#__PURE__*/React.createElement("div", {
    key: n,
    className: 'gw-dot' + (n === stepNum ? ' active' : n < stepNum ? ' done' : '')
  }))), step === 'method' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "gw-summary-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-summary-lbl"
  }, "Total to Pay \xB7 ", studentName), /*#__PURE__*/React.createElement("div", {
    className: "gw-summary-total"
  }, fmtF(total)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--muted)',
      marginTop: 4
    }
  }, items.length, " item", items.length > 1 ? 's' : '', ' ', "selected")), /*#__PURE__*/React.createElement("div", {
    className: "gw-method-group"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-group-lbl"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF1",
    size: 18
  }), " Mobile Money"), /*#__PURE__*/React.createElement("div", {
    className: "gw-tiles"
  }, MOBILE_METHODS.map(m => /*#__PURE__*/React.createElement("div", {
    key: m.key,
    className: "gw-tile " + brandClass(m.key) + (method === m.key ? " sel" : ""),
    onClick: () => goDetails(m.key)
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-tile-ico"
  }, /*#__PURE__*/React.createElement(MethodLogo, {
    method: m.key,
    size: 48
  })), /*#__PURE__*/React.createElement("div", {
    className: "gw-tile-lbl"
  }, m.lbl))))), /*#__PURE__*/React.createElement("div", {
    className: "gw-method-group"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-group-lbl"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB3",
    size: 18
  }), " Bank Card"), /*#__PURE__*/React.createElement("div", {
    className: "gw-tiles",
    style: {
      gridTemplateColumns: '1fr 1fr'
    }
  }, CARD_METHODS.map(m => /*#__PURE__*/React.createElement("div", {
    key: m.key,
    className: "gw-tile " + brandClass(m.key) + (method === m.key ? " sel" : ""),
    onClick: () => goDetails(m.key)
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-tile-ico"
  }, /*#__PURE__*/React.createElement(MethodLogo, {
    method: m.key,
    size: 48
  })), /*#__PURE__*/React.createElement("div", {
    className: "gw-tile-lbl"
  }, m.lbl))))), /*#__PURE__*/React.createElement("div", {
    className: "gw-method-group"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-group-lbl"
  }, "Control Number"), /*#__PURE__*/React.createElement("div", {
    className: "gw-tiles",
    style: { gridTemplateColumns: "1fr" }
  }, CONTROL_METHODS.map(function (m) {
    return /*#__PURE__*/React.createElement("div", {
      key: m.key,
      className: "gw-tile " + brandClass(m.key) + (method === m.key ? " sel" : ""),
      onClick: function () {
        goDetails(m.key);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "gw-tile-lbl"
    }, m.lbl), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "#64748b",
        marginTop: 4,
        textAlign: "center",
        padding: "0 8px"
      }
    }, "Bank / mobile pay with generated number (simulation)"));
  })))), step === 'details' && /*#__PURE__*/React.createElement(React.Fragment, null, err && /*#__PURE__*/React.createElement("div", {
    className: "err"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-m"
  }, err)), channel === 'mobile_money' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "gw-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "gw-flbl"
  }, "Phone Number"), /*#__PURE__*/React.createElement("input", {
    className: 'gw-finput' + (provider && provider !== 'Unknown' ? ' detected' : ''),
    type: "tel",
    placeholder: "0754 123 456",
    value: phone,
    onChange: e => setPhone(e.target.value),
    autoFocus: true
  })), provider && provider !== 'Unknown' && /*#__PURE__*/React.createElement("div", {
    className: "gw-detect-row"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "Detected provider:", ' ', /*#__PURE__*/React.createElement("b", null, provider))), provider === 'Unknown' && /*#__PURE__*/React.createElement("div", {
    className: "gw-detect-row",
    style: {
      background: '#FEF2F2',
      borderColor: '#FCA5A5',
      color: '#991B1B'
    }
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "Provider not recognized \u2014 check the number"))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: 'gw-card-preview ' + (detectedCardType === 'Visa' ? 'visa' : detectedCardType === 'Mastercard' ? 'mastercard' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-card-brand"
  }, detectedCardType ? /*#__PURE__*/React.createElement(MethodLogo, {
    method: detectedCardType,
    size: 34
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 800,
      opacity: 0.85
    }
  }, method)), /*#__PURE__*/React.createElement("div", {
    className: "gw-card-chip"
  }), /*#__PURE__*/React.createElement("div", {
    className: "gw-card-number"
  }, cardNumber ? formatCardNumber(cardNumber) : '•••• •••• •••• ••••'), /*#__PURE__*/React.createElement("div", {
    className: "gw-card-bottom"
  }, /*#__PURE__*/React.createElement("span", null, cardHolder || 'CARD HOLDER'), /*#__PURE__*/React.createElement("span", null, cardExpiry || 'MM/YY'))), /*#__PURE__*/React.createElement("div", {
    className: "gw-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "gw-flbl"
  }, "Card Holder Name"), /*#__PURE__*/React.createElement("input", {
    className: "gw-finput",
    type: "text",
    placeholder: "John Doe",
    value: cardHolder,
    onChange: e => setCardHolder(e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    className: "gw-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "gw-flbl"
  }, "Card Number"), /*#__PURE__*/React.createElement("input", {
    className: 'gw-finput' + (detectedCardType ? ' detected' : ''),
    type: "text",
    placeholder: "4111 1111 1111 1111",
    inputMode: "numeric",
    value: formatCardNumber(cardNumber),
    onChange: e => setCardNumber(e.target.value.replace(/\D/g, '').slice(0, 19))
  }), detectedCardType && /*#__PURE__*/React.createElement("div", {
    className: "gw-detect-row",
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "Detected:", ' ', /*#__PURE__*/React.createElement("b", null, detectedCardType)))), /*#__PURE__*/React.createElement("div", {
    className: "gw-card-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "gw-flbl"
  }, "Expiry (MM/YY)"), /*#__PURE__*/React.createElement("input", {
    className: "gw-finput",
    type: "text",
    placeholder: "08/29",
    inputMode: "numeric",
    value: cardExpiry,
    onChange: e => setCardExpiry(formatExpiry(e.target.value)),
    maxLength: 5
  })), /*#__PURE__*/React.createElement("div", {
    className: "gw-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "gw-flbl"
  }, "CVV"), /*#__PURE__*/React.createElement("input", {
    className: "gw-finput",
    type: "password",
    placeholder: "123",
    inputMode: "numeric",
    value: cardCvv,
    onChange: e => setCardCvv(e.target.value.replace(/\D/g, '').slice(0, 4)),
    maxLength: 4
  })))), /*#__PURE__*/React.createElement("div", {
    className: "gw-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "gw-flbl"
  }, "Proof of Payment (optional)"), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '2px dashed var(--border)',
      borderRadius: 10,
      padding: 14,
      textAlign: 'center',
      cursor: 'pointer',
      background: drag ? '#EFF6FF' : '#FAFBFC'
    },
    onClick: () => fileRef.current.click(),
    onDragOver: e => {
      e.preventDefault();
      setDrag(true);
    },
    onDragLeave: () => setDrag(false),
    onDrop: e => {
      e.preventDefault();
      setDrag(false);
      handleFile(e.dataTransfer.files[0]);
    }
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    accept: "image/*,.pdf",
    style: {
      display: 'none'
    },
    onChange: e => handleFile(e.target.files[0])
  }), proof ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      justifyContent: 'center'
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("span", null, proof.type === 'application/pdf' ? '📄' : /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDDBC",
    size: 16
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600
    }
  }, proof.name), /*#__PURE__*/React.createElement("button", {
    className: "btn bo bsm",
    onClick: () => setProof(null)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCE",
    size: 18
  }), " Click or drag a receipt/screenshot"))), /*#__PURE__*/React.createElement("div", {
    className: "gw-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: () => setStep('method')
  }, "\u2190 Back"), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: goReview
  }, "Continue \u2192"))), step === 'review' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--muted)',
      marginBottom: 8
    }
  }, "STUDENT"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 700,
      marginBottom: 16
    }
  }, studentName), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--muted)',
      marginBottom: 8
    }
  }, "SELECTED FEES"), /*#__PURE__*/React.createElement("div", {
    className: "gw-item-list"
  }, items.map(it => /*#__PURE__*/React.createElement("div", {
    key: it.feeType + (it.installmentNo || ''),
    className: "gw-item-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-item-name"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " ", it.label), /*#__PURE__*/React.createElement("span", {
    className: "gw-item-amt"
  }, fmtF(it.amount))))), /*#__PURE__*/React.createElement("div", {
    className: "gw-total-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-total-lbl"
  }, "Total Amount"), /*#__PURE__*/React.createElement("span", {
    className: "gw-total-val"
  }, fmtF(total))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-review-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-review-lbl"
  }, "Payment Method"), /*#__PURE__*/React.createElement("span", {
    className: "gw-review-val",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(MethodLogo, {
    method: method,
    size: 20
  }), channel === 'mobile_money' ? `${provider} ${method}` : `${method}`)), /*#__PURE__*/React.createElement("div", {
    className: "gw-review-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-review-lbl"
  }, channel === 'mobile_money' ? 'Phone Number' : 'Card'), /*#__PURE__*/React.createElement("span", {
    className: "gw-review-val"
  }, channel === 'mobile_money' ? phone : `${method} ending in ${cardNumber.replace(/\D/g, '').slice(-4)}`)), /*#__PURE__*/React.createElement("div", {
    className: "gw-review-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-review-lbl"
  }, "Date"), /*#__PURE__*/React.createElement("span", {
    className: "gw-review-val"
  }, fmtD(todayStr())))), /*#__PURE__*/React.createElement("div", {
    className: "gw-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: () => setStep('details')
  }, "\u2190 Back"), /*#__PURE__*/React.createElement("button", {
    className: "btn bg2",
    onClick: confirmPayment
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " Confirm Payment"))), step === 'processing' && /*#__PURE__*/React.createElement("div", {
    className: "gw-processing"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-proc-icon"
  }, PROCESSING_STAGES[stageIdx].icon), /*#__PURE__*/React.createElement("div", {
    className: "gw-proc-stage"
  }, PROCESSING_STAGES[stageIdx].text), /*#__PURE__*/React.createElement("div", {
    className: "gw-proc-sub"
  }, "Please don't close this window"), /*#__PURE__*/React.createElement("div", {
    className: "gw-proc-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-proc-fill",
    style: {
      width: (stageIdx + 1) / PROCESSING_STAGES.length * 100 + '%'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "gw-proc-steps"
  }, PROCESSING_STAGES.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: 'gw-proc-step' + (i === stageIdx ? ' active' : i < stageIdx ? ' done' : '')
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-proc-step-icon"
  }, i < stageIdx ? /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }) : i === stageIdx ? '●' : '○'), /*#__PURE__*/React.createElement("span", null, s.text))))), step === 'success' && result && /*#__PURE__*/React.createElement("div", {
    className: "gw-success"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-success-icon"
  }, "\uD83C\uDF89"), /*#__PURE__*/React.createElement("div", {
    className: "gw-success-title"
  }, "Payment Submitted!"), /*#__PURE__*/React.createElement("div", {
    className: "gw-success-sub"
  }, "Your payment of", ' ', /*#__PURE__*/React.createElement("b", null, fmtF(result.total_amount)), ' ', "is now ", /*#__PURE__*/React.createElement("b", null, "Pending Verification"), ".", /*#__PURE__*/React.createElement("br", null), "The school will confirm shortly and you'll be notified."), /*#__PURE__*/React.createElement("div", {
    className: "gw-ref-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gw-ref-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-ref-lbl"
  }, "Reference"), /*#__PURE__*/React.createElement("span", {
    className: "gw-ref-val"
  }, result.transaction_reference)), result.control_number ? /*#__PURE__*/React.createElement("div", {
    className: "gw-ref-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-ref-lbl"
  }, "Control No."), /*#__PURE__*/React.createElement("span", {
    className: "gw-ref-val",
    style: { fontWeight: 800, letterSpacing: "0.04em", color: "#1D5C42" }
  }, result.control_number)) : null, result.control_number ? /*#__PURE__*/React.createElement("div", {
    style: {
      margin: "12px 0 4px",
      padding: 14,
      background: "#F8FAFC",
      border: "1px solid #E2E8F0",
      borderRadius: 12,
      fontSize: 13,
      color: "#334155",
      lineHeight: 1.55,
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: { fontWeight: 800, marginBottom: 8, color: "#0F172A" }
  }, "How to complete payment"), /*#__PURE__*/React.createElement("ol", {
    style: { margin: "0 0 0 18px", padding: 0 }
  }, /*#__PURE__*/React.createElement("li", null, "Copy the control number above."), /*#__PURE__*/React.createElement("li", null, "Pay via mobile money (M-Pesa, Tigo, Airtel, etc.) or bank using that control number."), /*#__PURE__*/React.createElement("li", null, "Keep your receipt. The school will verify the payment."), /*#__PURE__*/React.createElement("li", null, "This is a simulation until a live payment API is connected."))) : null, /*#__PURE__*/React.createElement("div", {
    className: "gw-ref-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-ref-lbl"
  }, "Items"), /*#__PURE__*/React.createElement("span", {
    className: "gw-ref-val"
  }, items.length)), /*#__PURE__*/React.createElement("div", {
    className: "gw-ref-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gw-ref-lbl"
  }, "Status"), /*#__PURE__*/React.createElement("span", {
    className: "gw-ref-val",
    style: {
      color: '#92400E'
    }
  }, "Pending Verification"))), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    style: {
      width: '100%',
      justifyContent: 'center'
    },
    onClick: onSuccess
  }, "Done")), step === 'error' && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '20px 10px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 40,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      marginBottom: 8
    }
  }, "Submission Failed"), /*#__PURE__*/React.createElement("div", {
    className: "err"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-m"
  }, err)), /*#__PURE__*/React.createElement("div", {
    className: "gw-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: onClose
  }, "Close"), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: () => setStep('review')
  }, "Try Again"))))));
};

/* ════════════════════════════════════════
ONE-TIME CONTRIBUTIONS SECTION
════════════════════════════════════════ */
const OneTimeSection = ({
  lines,
  allDone,
  studentId,
  studentName,
  onPaid
}) => {
  const [open, setOpen] = useState(true);
  const [selected, setSelected] = useState({});
  const [showGateway, setShowGateway] = useState(false);
  const payableLines = lines.filter(l => !l.is_paid && l.pending === 0);
  const selectedLines = payableLines.filter(l => selected[l.fee_type]);
  const allChecked = payableLines.length > 0 && payableLines.every(l => selected[l.fee_type]);
  const toggle = ft => setSelected(s => ({
    ...s,
    [ft]: !s[ft]
  }));
  const toggleAll = () => {
    if (allChecked) setSelected({});else {
      const n = {};
      payableLines.forEach(l => n[l.fee_type] = true);
      setSelected(n);
    }
  };
  const items = selectedLines.map(l => ({
    feeType: l.fee_type,
    installmentNo: null,
    label: l.fee_type,
    amount: l.balance
  }));
  const total = lines.reduce((s, l) => s + l.amount_due, 0);
  const paid = lines.reduce((s, l) => s + l.amount_paid, 0);
  return /*#__PURE__*/React.createElement("div", {
    className: "sec"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-head",
    onClick: () => setOpen(o => !o)
  }, /*#__PURE__*/React.createElement("span", {
    className: "sec-title"
  }, "\uD83E\uDDF3 Contributions & One-Time Fees", allDone ? /*#__PURE__*/React.createElement("span", {
    className: "sec-badge",
    style: {
      background: '#D1FAE5',
      color: '#065F46'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " Complete") : /*#__PURE__*/React.createElement("span", {
    className: "sec-badge",
    style: {
      background: '#FEF3C7',
      color: '#92400E'
    }
  }, "Required First")), /*#__PURE__*/React.createElement("div", {
    className: "sec-right"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--slate)'
    }
  }, fmtF(paid), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      color: 'var(--muted)'
    }
  }, ' ', "/ ", fmtF(total))), /*#__PURE__*/React.createElement("span", {
    className: 'sec-arr' + (open ? ' open' : '')
  }, "\u203A"))), open && /*#__PURE__*/React.createElement("div", null, payableLines.length > 1 && /*#__PURE__*/React.createElement("div", {
    className: "sel-all-row",
    onClick: e => {
      e.stopPropagation();
      toggleAll();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: `chk${allChecked ? ' chk-on' : ''}`
  }, allChecked && /*#__PURE__*/React.createElement("span", {
    className: "chk-tick"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2714",
    size: 18
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--muted)'
    }
  }, allChecked ? 'Deselect all' : 'Select all payable fees')), lines.map(l => {
    const isPayable = !l.is_paid && l.pending === 0;
    const isChecked = !!selected[l.fee_type];
    return /*#__PURE__*/React.createElement("div", {
      key: l.fee_type,
      className: 'fee-row' + (isChecked ? ' fee-row-sel' : ''),
      onClick: () => {
        if (isPayable) toggle(l.fee_type);
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, isPayable ? /*#__PURE__*/React.createElement("div", {
      className: `chk${isChecked ? ' chk-on' : ''}`
    }, isChecked && /*#__PURE__*/React.createElement("span", {
      className: "chk-tick"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2714",
      size: 18
    }))) : /*#__PURE__*/React.createElement("div", {
      className: "fee-icon",
      style: {
        background: FEE_BG[l.fee_type] || '#F1F5F9',
        color: FEE_CLR[l.fee_type] || '#475569'
      }
    }, FEE_ICONS[l.fee_type] || '💰')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "fee-name"
    }, FEE_ICONS[l.fee_type] || '💰', ' ', l.fee_type), /*#__PURE__*/React.createElement("div", {
      className: "fee-meta"
    }, l.is_paid ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2705",
      size: 16
    }), "Fully paid") : l.pending > 0 ? `⏳ ${fmtF(l.pending)} awaiting verification` : `${fmtF(l.balance)} remaining`), /*#__PURE__*/React.createElement("div", {
      className: "fee-prog"
    }, /*#__PURE__*/React.createElement("div", {
      className: "fee-prog-f",
      style: {
        width: pct(l.amount_paid, l.amount_due) + '%',
        background: l.is_paid ? 'var(--green)' : 'var(--amber)'
      }
    }))), /*#__PURE__*/React.createElement("div", {
      className: "fee-right"
    }, /*#__PURE__*/React.createElement("div", {
      className: "fee-amount",
      style: {
        color: l.is_paid ? 'var(--green)' : l.balance > 0 ? 'var(--red)' : 'var(--slate)'
      }
    }, fmtF(l.amount_due)), l.is_paid && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--green)',
        fontWeight: 700,
        marginTop: 4
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2714",
      size: 18
    }), " Paid"), !l.is_paid && l.pending > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--amber)',
        fontWeight: 700,
        marginTop: 4
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u23F3",
      size: 18
    }), " Pending"), isPayable && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: isChecked ? 'var(--blue)' : 'var(--muted)',
        fontWeight: 600,
        marginTop: 4
      }
    }, isChecked ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2611",
      size: 16
    }), "Selected") : 'Click to select')));
  }), selectedLines.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "pay-tray"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pay-tray-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pay-tray-count"
  }, selectedLines.length, " fee", selectedLines.length > 1 ? 's' : '', ' ', "selected"), /*#__PURE__*/React.createElement("div", {
    className: "pay-tray-total"
  }, fmtF(selectedLines.reduce((s, l) => s + l.balance, 0)))), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: () => setShowGateway(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB3",
    size: 18
  }), " Pay Now"))), showGateway && /*#__PURE__*/React.createElement(GatewayModal, {
    studentId: studentId,
    studentName: studentName,
    items: items,
    onClose: () => setShowGateway(false),
    onSuccess: () => {
      setShowGateway(false);
      setSelected({});
      onPaid();
    }
  }));
};

/* ════════════════════════════════════════
INSTALMENT SECTION (School Fees / Transport)
════════════════════════════════════════ */
const InstallSection = ({
  line,
  blocked,
  studentId,
  studentName,
  feeType,
  onPaid
}) => {
  const [open, setOpen] = useState(true);
  const [selected, setSelected] = useState({});
  const [showGateway, setShowGateway] = useState(false);
  if (!line) return null;
  const slots = line.slots || [];
  const paidCnt = slots.filter(s => s.status === 'paid').length;
  const sectionTitle = feeType === 'Transport' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDE8C",
    size: 16
  }), "Transport") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 16
  }), "School Fees");
  const payableSlots = slots.filter(s => s.status !== 'paid' && s.pending === 0 && !blocked);
  const selectedSlots = payableSlots.filter(s => selected[s.no]);
  const allSlotChecked = payableSlots.length > 0 && payableSlots.every(s => selected[s.no]);
  const toggleSlot = no => setSelected(sel => ({
    ...sel,
    [no]: !sel[no]
  }));
  const toggleAllSlots = () => {
    if (allSlotChecked) setSelected({});else {
      const n = {};
      payableSlots.forEach(s => n[s.no] = true);
      setSelected(n);
    }
  };
  const items = selectedSlots.map(s => ({
    feeType,
    installmentNo: s.no,
    label: `${feeType} #${s.no}`,
    amount: s.amount_due
  }));
  return /*#__PURE__*/React.createElement("div", {
    className: "sec"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-head",
    onClick: () => setOpen(o => !o)
  }, /*#__PURE__*/React.createElement("span", {
    className: "sec-title"
  }, sectionTitle, line.is_paid ? /*#__PURE__*/React.createElement("span", {
    className: "sec-badge",
    style: {
      background: '#D1FAE5',
      color: '#065F46'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " Complete") : blocked ? /*#__PURE__*/React.createElement("span", {
    className: "sec-badge",
    style: {
      background: '#FEE2E2',
      color: '#991B1B'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD12",
    size: 18
  }), " Pay contributions first") : /*#__PURE__*/React.createElement("span", {
    className: "sec-badge",
    style: {
      background: '#DBEAFE',
      color: '#1E40AF'
    }
  }, paidCnt, "/", slots.length, " paid")), /*#__PURE__*/React.createElement("div", {
    className: "sec-right"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--slate)'
    }
  }, fmtF(line.amount_paid), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      color: 'var(--muted)'
    }
  }, ' ', "/ ", fmtF(line.amount_due))), /*#__PURE__*/React.createElement("span", {
    className: 'sec-arr' + (open ? ' open' : '')
  }, "\u203A"))), open && /*#__PURE__*/React.createElement(React.Fragment, null, blocked && /*#__PURE__*/React.createElement("div", {
    className: "rule-banner",
    style: {
      margin: '14px 18px 0',
      marginBottom: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "rule-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "Complete all contribution fees above to unlock school fee instalment payments.")), /*#__PURE__*/React.createElement("div", {
    className: "inst-toolbar"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--muted)',
      fontWeight: 600
    }
  }, blocked ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD12",
    size: 16
  }), "Locked until contributions are paid.") : slots[0] ? `Each instalment = ${fmtF(slots[0].amount_due)} · Click to select` : ''), !blocked && payableSlots.length > 1 && /*#__PURE__*/React.createElement("button", {
    className: "btn bo bsm",
    style: {
      fontSize: 11
    },
    onClick: toggleAllSlots
  }, allSlotChecked ? 'Deselect all' : 'Select all unpaid')), /*#__PURE__*/React.createElement("div", {
    className: "inst-grid"
  }, slots.map(s => {
    const isPayable = s.status !== 'paid' && s.pending === 0 && !blocked;
    const isSel = !!selected[s.no] && isPayable;
    const cls = s.status === 'paid' ? 'paid' : s.pending > 0 ? 'pending' : blocked ? 'blocked' : isSel ? 'selected' : 'unpaid';
    return /*#__PURE__*/React.createElement("div", {
      key: s.no,
      className: 'inst-slot ' + cls,
      onClick: () => {
        if (isPayable) toggleSlot(s.no);
      }
    }, isSel && /*#__PURE__*/React.createElement("div", {
      className: "inst-chk-mark"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2714",
      size: 18
    })), /*#__PURE__*/React.createElement("div", {
      className: "inst-no"
    }, s.no), /*#__PURE__*/React.createElement("div", {
      className: "inst-lbl"
    }, s.status === 'paid' ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2714",
      size: 16
    }), "PAID") : s.pending > 0 ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u23F3",
      size: 16
    }), "PEND") : blocked ? '🔒' : isSel ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2611",
      size: 16
    }), "SEL") : '• PAY'));
  })), /*#__PURE__*/React.createElement("div", {
    className: "inst-legend"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "leg-dot",
    style: {
      background: '#D1FAE5',
      border: '1px solid #6EE7B7'
    }
  }), /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2714",
    size: 18
  }), " Paid"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "leg-dot",
    style: {
      background: '#FEF3C7',
      border: '1px solid #FDE68A'
    }
  }), /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F3",
    size: 18
  }), " Pending"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "leg-dot",
    style: {
      background: '#EFF6FF',
      border: '2px solid var(--blue)'
    }
  }), /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2611",
    size: 18
  }), " Selected"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "leg-dot",
    style: {
      background: '#F8FAFC',
      border: '1px solid #E2E8F0'
    }
  }), "\u2022 Unpaid")), selectedSlots.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "pay-tray",
    style: {
      borderTop: '2px solid #BFDBFE'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pay-tray-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pay-tray-count"
  }, selectedSlots.length, ' ', "instalment", selectedSlots.length > 1 ? 's' : '', ' ', "selected", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)',
      fontWeight: 400,
      marginLeft: 6
    }
  }, "(#", selectedSlots.map(s => s.no).join(', #'), ")")), /*#__PURE__*/React.createElement("div", {
    className: "pay-tray-total"
  }, fmtF(selectedSlots.reduce((s, sl) => s + sl.amount_due, 0)))), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: () => setShowGateway(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB3",
    size: 18
  }), " Pay Now"))), showGateway && /*#__PURE__*/React.createElement(GatewayModal, {
    studentId: studentId,
    studentName: studentName,
    items: items,
    onClose: () => setShowGateway(false),
    onSuccess: () => {
      setShowGateway(false);
      setSelected({});
      onPaid();
    }
  }));
};

/* ════════════════════════════════════════
DETAIL BOTTOM SHEET (transaction + items)
════════════════════════════════════════ */
const DetailSheet = ({
  id,
  onClose
}) => {
  const [d, setD] = useState(null);
  const [loading, setL] = useState(true);
  useEffect(() => {
    fetch(API + '?action=transaction_detail&transaction_id=' + id).then(r => r.json()).then(res => {
      if (res.success) setD(res.data);
    }).finally(() => setL(false));
  }, [id]);
  const proofUrl = d && d.payment_proof ? '/nsms/publicuploads/' + d.payment_proof : null;
  return /*#__PURE__*/React.createElement("div", {
    className: "bsheet-bg",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "bsheet-ov"
  }), /*#__PURE__*/React.createElement("div", {
    className: "bsheet",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: 17
    }
  }, "Transaction Details"), /*#__PURE__*/React.createElement("button", {
    className: "btn bo bsm",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }), " Close")), loading ? /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement(Spin, null)) : !d ? /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, "Not found.") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(SBadge, {
    status: d.status
  })), d.status === 'rejected' && d.rejection_reason && /*#__PURE__*/React.createElement("div", {
    className: "err"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-m"
  }, /*#__PURE__*/React.createElement("b", null, "Rejection Reason:"), ' ', d.rejection_reason)), d.status === 'received' && /*#__PURE__*/React.createElement("div", {
    className: "ok"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " Payment verified. Receipt:", ' ', d.receipt_number), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--muted)',
      marginBottom: 8
    }
  }, "ITEMS (", d.items.length, ")"), d.items.map(it => /*#__PURE__*/React.createElement("div", {
    key: it.id,
    className: "item-chip-row"
  }, /*#__PURE__*/React.createElement("span", null, it.fee_type, it.installment_no ? ` #${it.installment_no}` : ''), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700
    }
  }, fmtF(it.amount)))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14
    }
  }, [['Total', fmtF(d.total_amount)], ['Method', d.payment_method + (d.network_provider ? ' (' + d.network_provider + ')' : '')], [d.payment_channel === 'card' ? 'Card' : 'Phone', d.payment_channel === 'card' ? d.card_type + ' ••••' + d.card_last_four : d.phone_number], ['Reference', d.transaction_reference], ['Pay Date', fmtD(d.payment_date)], ['Submitted', fmtDT(d.created_at)], ['Verified', d.verified_at ? fmtDT(d.verified_at) : '—']].map(([l, v]) => /*#__PURE__*/React.createElement("div", {
    className: "dr",
    key: l
  }, /*#__PURE__*/React.createElement("span", {
    className: "dlbl"
  }, l), /*#__PURE__*/React.createElement("span", {
    className: "dval"
  }, v)))), proofUrl && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      marginBottom: 4
    }
  }, "Payment Proof"), proofUrl.endsWith('.pdf') ? /*#__PURE__*/React.createElement("a", {
    href: proofUrl,
    target: "_blank",
    className: "pdf-link"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC4",
    size: 18
  }), " View PDF") : /*#__PURE__*/React.createElement("img", {
    src: proofUrl,
    alt: "proof",
    className: "proof-img",
    onClick: () => window.open(proofUrl, '_blank')
  })))));
};

/* ════════════════════════════════════════
HISTORY TAB
════════════════════════════════════════ */
const HistoryTab = ({
  studentId,
  onDetail
}) => {
  const [rows, setRows] = useState([]);
  const [loading, setL] = useState(true);
  const [err, setErr] = useState('');
  useEffect(() => {
    fetch(API + '?action=my_transactions').then(r => r.json()).then(d => {
      if (d.success) setRows((d.data || []).filter(r => String(r.student_id) === String(studentId)));else setErr(d.error || 'Failed');
    }).catch(() => setErr('Network error')).finally(() => setL(false));
  }, [studentId]);
  if (loading) return /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement(Spin, null));
  if (err) return /*#__PURE__*/React.createElement("div", {
    className: "err"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-m"
  }, err));
  if (!rows.length) return /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      textAlign: 'center',
      padding: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 30,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCED",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600
    }
  }, "No payments yet"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--muted)',
      marginTop: 4
    }
  }, "Use the Pay Fees tab to make your first payment."));
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tw"
  }, /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Date"), /*#__PURE__*/React.createElement("th", null, "Items"), /*#__PURE__*/React.createElement("th", null, "Method"), /*#__PURE__*/React.createElement("th", null, "Amount"), /*#__PURE__*/React.createElement("th", null, "Reference"), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", null))), /*#__PURE__*/React.createElement("tbody", null, rows.map(r => /*#__PURE__*/React.createElement("tr", {
    key: r.id
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      color: 'var(--muted)',
      fontSize: 12,
      whiteSpace: 'nowrap'
    }
  }, fmtD(r.created_at)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "bx xb"
  }, r.item_count, " item", r.item_count > 1 ? 's' : '')), /*#__PURE__*/React.createElement("td", null, r.payment_method, r.network_provider ? ` (${r.network_provider})` : ''), /*#__PURE__*/React.createElement("td", {
    className: "amt"
  }, fmtF(r.total_amount)), /*#__PURE__*/React.createElement("td", {
    style: {
      fontFamily: 'monospace',
      fontSize: 12
    }
  }, r.transaction_reference), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(SBadge, {
    status: r.status
  })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("button", {
    className: "btn bo bsm",
    onClick: () => onDetail(r.id)
  }, "View"))))))));
};

/* ════════════════════════════════════════
MAIN APP
════════════════════════════════════════ */
const App = () => {
  const [sbCol, setSb] = useState(false);
  const [data, setData] = useState([]);
  const [loading, setL] = useState(true);
  const [err, setErr] = useState('');
  const [activeIdx, setAI] = useState(0);
  const [tab, setTab] = useState('pay');
  const [detail, setDetail] = useState(null);
  const load = useCallback(() => {
    setL(true);
    fetch(API + '?action=fee_summary').then(r => r.json()).then(d => {
      if (d.success) setData(d.data || []);else setErr(d.error || 'Failed to load');
    }).catch(() => setErr('Network error')).finally(() => setL(false));
  }, []);
  useEffect(() => {
    load();
  }, [load]);
  const child = data[activeIdx];
  const colors = ['#2563EB', '#7C3AED', '#059669', '#D97706'];
  const sfLine = child ? (child.install_lines || []).find(l => l.fee_type === 'School Fees') : null;
  const tpLine = child ? (child.install_lines || []).find(l => l.fee_type === 'Transport') : null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ParentNavbar, {
    onToggle: () => setSb(s => !s)
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(ParentSidebar, {
    collapsed: sbCol
  }), /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (sbCol ? ' collapsed' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ph"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB3",
    size: 18
  }), " Pay Fees"), /*#__PURE__*/React.createElement("div", {
    className: "ph-sub"
  }, "Select fees, choose a payment method, and confirm"))), loading ? /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement(Spin, null), /*#__PURE__*/React.createElement("span", null, "Loading\u2026")) : err ? /*#__PURE__*/React.createElement("div", {
    className: "err"
  }, /*#__PURE__*/React.createElement("div", {
    className: "err-m"
  }, err)) : data.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, "No children found in your account.") : /*#__PURE__*/React.createElement(React.Fragment, null, data.length > 1 && /*#__PURE__*/React.createElement("div", {
    className: "ssel"
  }, data.map((c, i) => /*#__PURE__*/React.createElement("button", {
    key: c.student_id,
    className: 'ssel-btn' + (activeIdx === i ? ' active' : ''),
    onClick: () => setAI(i)
  }, /*#__PURE__*/React.createElement("div", {
    className: "sdot",
    style: {
      background: colors[i % colors.length]
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", null, c.student_name, c.status === 'graduated' && /*#__PURE__*/React.createElement("span", {
    className: "grad-tag"
  }, ' ', /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), "Graduated")), /*#__PURE__*/React.createElement("div", {
    className: "scls"
  }, c.class_name))))), child && child.status === 'graduated' && /*#__PURE__*/React.createElement("div", {
    className: "grad-notice"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), ' ', /*#__PURE__*/React.createElement("b", null, child.student_name), ' ', "has graduated. You can still view and settle any remaining balance below."), child && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "ovc-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc blue-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "ovc-lbl"
  }, "Total Fees"), /*#__PURE__*/React.createElement("div", {
    className: "ovc-val"
  }, fmtF(child.grand_due)), /*#__PURE__*/React.createElement("div", {
    className: "ovc-sub"
  }, child.academic_year)), /*#__PURE__*/React.createElement("div", {
    className: "ovc green-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "ovc-lbl"
  }, "Total Paid"), /*#__PURE__*/React.createElement("div", {
    className: "ovc-val"
  }, fmtF(child.grand_paid)), /*#__PURE__*/React.createElement("div", {
    className: "ovc-sub"
  }, pct(child.grand_paid, child.grand_due), "% of total"), /*#__PURE__*/React.createElement("div", {
    className: "ovc-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc-bar-f",
    style: {
      width: pct(child.grand_paid, child.grand_due) + '%'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: 'ovc ' + (child.grand_balance <= 0 ? 'green-card' : 'amber-card')
  }, /*#__PURE__*/React.createElement("div", {
    className: "ovc-ico"
  }, child.grand_balance <= 0 ? typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: null,
    size: 16
  }) : null : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '⏳',
    size: 16
  }) : null), /*#__PURE__*/React.createElement("div", {
    className: "ovc-lbl"
  }, "Balance Due"), /*#__PURE__*/React.createElement("div", {
    className: "ovc-val"
  }, fmtF(Math.max(0, child.grand_balance))), /*#__PURE__*/React.createElement("div", {
    className: "ovc-sub"
  }, child.grand_balance <= 0 ? 'Fully paid!' : 'Remaining'))), child.total_pending > 0 && /*#__PURE__*/React.createElement("div", {
    className: "rule-banner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "rule-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F3",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", null, fmtF(child.total_pending)), ' ', "currently awaiting verification by the school office.")), !child.all_one_time_done && /*#__PURE__*/React.createElement("div", {
    className: "rule-banner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "rule-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", null, "Pay order:"), ' ', "All contribution and one-time fees must be fully paid before school fee instalments can be submitted.")), /*#__PURE__*/React.createElement("div", {
    className: "tabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: 'tab' + (tab === 'pay' ? ' on' : ''),
    onClick: () => setTab('pay')
  }, "Pay Fees"), /*#__PURE__*/React.createElement("button", {
    className: 'tab' + (tab === 'history' ? ' on' : ''),
    onClick: () => setTab('history')
  }, "History")), tab === 'pay' && /*#__PURE__*/React.createElement(React.Fragment, null, child.one_time_lines && child.one_time_lines.length > 0 && /*#__PURE__*/React.createElement(OneTimeSection, {
    lines: child.one_time_lines,
    allDone: child.all_one_time_done,
    studentId: child.student_id,
    studentName: child.student_name,
    onPaid: load
  }), sfLine && /*#__PURE__*/React.createElement(InstallSection, {
    line: sfLine,
    blocked: !child.all_one_time_done,
    studentId: child.student_id,
    studentName: child.student_name,
    feeType: "School Fees",
    onPaid: load
  }), tpLine && child.has_transport && /*#__PURE__*/React.createElement(InstallSection, {
    line: tpLine,
    blocked: false,
    studentId: child.student_id,
    studentName: child.student_name,
    feeType: "Transport",
    onPaid: load
  }), child.fully_paid && /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      textAlign: 'center',
      padding: '36px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 44,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF89",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 800,
      color: '#065F46',
      marginBottom: 6
    }
  }, "All Fees Fully Paid!"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--muted)'
    }
  }, child.student_name, ' ', "has no outstanding balances for", ' ', child.academic_year, "."))), tab === 'history' && /*#__PURE__*/React.createElement(HistoryTab, {
    studentId: child.student_id,
    onDetail: setDetail
  })))))), detail && /*#__PURE__*/React.createElement(DetailSheet, {
    id: detail,
    onClose: () => setDetail(null)
  }));
};
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/React.createElement(App, null));