var useState = React.useState;
var useEffect = React.useEffect;
var useRef = React.useRef;

/* ── Helpers ── */
function todayISO() {
  var d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function tomorrowISO() {
  var d = new Date();
  d.setDate(d.getDate() + 1);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function fmtDate(iso) {
  if (!iso) return '—';
  var d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}
function fmtTime(t) {
  if (!t) return '';
  var parts = t.split(':');
  var h = parseInt(parts[0], 10);
  var m = parts[1];
  var ampm = h >= 12 ? 'PM' : 'AM';
  var h12 = h % 12 || 12;
  return h12 + ':' + m + ' ' + ampm;
}
function fmtBytes(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}
function dueBadge(iso) {
  if (!iso) return {
    cls: 'hw-due-future',
    label: '—'
  };
  var today = todayISO();
  if (iso < today) return {
    cls: 'hw-due-past',
    label: 'Overdue'
  };
  if (iso === today) return {
    cls: 'hw-due-today',
    label: 'Due today'
  };
  return {
    cls: 'hw-due-future',
    label: 'Due ' + fmtDate(iso)
  };
}
var DOT_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2'];
function dotColor(s) {
  return s ? DOT_COLORS[s.charCodeAt(0) % DOT_COLORS.length] : '#94A3B8';
}

/* ═══════════════════════════════════════════════
RECENT HOMEWORK PANEL
═══════════════════════════════════════════════ */
function RecentPanel(props) {
  var items = props.items;
  var loading = props.loading;
  var onSelect = props.onSelect;
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "recent-head"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  }), " Recent Assignments"), /*#__PURE__*/React.createElement("div", {
    className: "recent-body"
  }, loading ? [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        padding: '12px',
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "sh shimmer",
      style: {
        width: '70%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "sh shimmer",
      style: {
        width: '90%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "sh shimmer",
      style: {
        width: '40%',
        height: 10
      }
    }));
  }) : items.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty-recent"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCED",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "No homework posted yet.")) : items.map(function (hw, i) {
    var badge = dueBadge(hw.due_date);
    var hasCounts = hw.total_students !== undefined && hw.total_students !== null;
    return /*#__PURE__*/React.createElement("div", {
      key: hw.id || i,
      className: "hw-item",
      onClick: function () {
        if (hw.id && onSelect) onSelect(hw.id);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "hw-dot",
      style: {
        background: dotColor(hw.subject)
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "hw-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "hw-subject"
    }, hw.subject || 'Homework'), /*#__PURE__*/React.createElement("div", {
      className: "hw-desc"
    }, hw.description || '—'), /*#__PURE__*/React.createElement("div", {
      className: "hw-meta"
    }, /*#__PURE__*/React.createElement("span", {
      className: 'hw-due ' + badge.cls
    }, badge.label)), hasCounts && /*#__PURE__*/React.createElement("div", {
      className: "hw-progress-mini"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 18
    }), ' ', hw.acknowledged_count || 0, ' ', "of ", hw.total_students, ' ', "acknowledged")));
  })));
}

/* ═══════════════════════════════════════════════
HOMEWORK DETAIL MODAL
Edit assignment, extend/set deadline, and view + grade the
acknowledgment roster — all in one place.
═══════════════════════════════════════════════ */
function HomeworkDetailModal(props) {
  var hwId = props.homeworkId;
  var onClose = props.onClose;
  var onChanged = props.onChanged;
  var dataSt = useState(null);
  var data = dataSt[0];
  var setData = dataSt[1];
  var loadSt = useState(true);
  var loading = loadSt[0];
  var setLoading = loadSt[1];
  var editSt = useState(false);
  var editing = editSt[0];
  var setEditing = editSt[1];
  var formSt = useState({
    subject: '',
    description: ''
  });
  var editForm = formSt[0];
  var setEditForm = formSt[1];
  var savingSt = useState(false);
  var saving = savingSt[0];
  var setSaving = savingSt[1];
  var extSt = useState(false);
  var extending = extSt[0];
  var setExtending = extSt[1];
  var cdSt = useState('');
  var customDate = cdSt[0];
  var setCustomDate = cdSt[1];
  var ctSt = useState('');
  var customTime = ctSt[0];
  var setCustomTime = ctSt[1];
  var toastSt = useState(null);
  var localToast = toastSt[0];
  var setLocalToast = toastSt[1];
  var commentsSt = useState([]);
  var parentComments = commentsSt[0];
  var setParentComments = commentsSt[1];
  function load() {
    setLoading(true);
    fetch('/nsms/api/teacher-homework.php?action=acknowledgments&homework_id=' + hwId).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setData(d.data);
        setEditForm({
          subject: d.data.homework.subject,
          description: d.data.homework.description
        });
      }
    }).catch(function () {}).finally(function () {
      setLoading(false);
    });
    fetch('/nsms/api/teacher-homework.php?action=comments&homework_id=' + hwId, { credentials: 'same-origin' }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setParentComments(d.data || []);
    }).catch(function () {});
  }
  useEffect(function () {
    load();
  }, [hwId]);
  useEffect(function () {
    if (!localToast) return;
    var t = setTimeout(function () {
      setLocalToast(null);
    }, 3000);
    return function () {
      clearTimeout(t);
    };
  }, [localToast]);
  function postUpdate(body, successMsg) {
    setSaving(true);
    return fetch('/nsms/api/teacher-homework.php?action=update', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setLocalToast({
          type: 'success',
          msg: successMsg
        });
        load();
        if (onChanged) onChanged();
      } else {
        setLocalToast({
          type: 'error',
          msg: d.error || 'Something went wrong.'
        });
      }
      return d;
    }).catch(function () {
      setLocalToast({
        type: 'error',
        msg: 'Network error. Please try again.'
      });
    }).finally(function () {
      setSaving(false);
    });
  }
  function saveEdit() {
    if (!editForm.subject.trim() || !editForm.description.trim()) {
      setLocalToast({
        type: 'error',
        msg: 'Subject and task cannot be empty.'
      });
      return;
    }
    postUpdate({
      id: hwId,
      subject: editForm.subject,
      description: editForm.description
    }, 'Homework updated').then(function () {
      setEditing(false);
    });
  }
  function extend(days, hours) {
    postUpdate({
      id: hwId,
      extend_days: days || 0,
      extend_hours: hours || 0
    }, 'Deadline extended — parents have been notified.');
  }
  function setExplicitDeadline() {
    if (!customDate) {
      setLocalToast({
        type: 'error',
        msg: 'Pick a date first.'
      });
      return;
    }
    postUpdate({
      id: hwId,
      due_date: customDate,
      due_time: customTime || null
    }, 'Deadline updated — parents have been notified.').then(function () {
      setExtending(false);
    });
  }
  if (!hwId) return null;
  var hw = data && data.homework;
  var pct = data && data.total_count > 0 ? Math.round(data.acknowledged_count / data.total_count * 100) : 0;
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: function (e) {
      if (e.target === e.currentTarget) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-modal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-head"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--text-muted)',
      textTransform: 'uppercase',
      letterSpacing: '.5px',
      marginBottom: 4
    }
  }, hw ? hw.class_name : 'Loading…'), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 800,
      color: 'var(--text-dark)'
    }
  }, "Homework Details")), /*#__PURE__*/React.createElement("button", {
    className: "hw-modal-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-body"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 0',
      color: 'var(--text-muted)'
    }
  }, "Loading\u2026") : !hw ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 0',
      color: 'var(--text-muted)'
    }
  }, "Could not load this homework.") : /*#__PURE__*/React.createElement(React.Fragment, null, localToast && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14,
      padding: '9px 14px',
      borderRadius: 8,
      fontSize: 13,
      fontWeight: 600,
      background: localToast.type === 'error' ? '#FEF2F2' : '#F0FDF4',
      color: localToast.type === 'error' ? '#B91C1C' : '#166534'
    }
  }, localToast.msg), /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-section"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-label"
  }, "Assignment"), !editing && /*#__PURE__*/React.createElement("button", {
    className: "extend-chip",
    onClick: function () {
      setEditing(true);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  }), " Edit")), editing ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("input", {
    className: "field-input",
    style: {
      marginBottom: 8
    },
    value: editForm.subject,
    onChange: function (e) {
      setEditForm(Object.assign({}, editForm, {
        subject: e.target.value
      }));
    }
  }), /*#__PURE__*/React.createElement("textarea", {
    className: "field-textarea",
    style: {
      minHeight: 80
    },
    value: editForm.description,
    onChange: function (e) {
      setEditForm(Object.assign({}, editForm, {
        description: e.target.value
      }));
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "hw-edit-row"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    disabled: saving,
    onClick: saveEdit
  }, saving ? 'Saving…' : 'Save Changes'), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-cancel",
    onClick: function () {
      setEditing(false);
      setEditForm({
        subject: hw.subject,
        description: hw.description
      });
    }
  }, "Cancel"))) : /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 700,
      color: 'var(--text-dark)',
      marginBottom: 4
    }
  }, hw.subject), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      color: 'var(--text-soft)',
      lineHeight: 1.6
    }
  }, hw.description))), /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-label"
  }, "Deadline"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5,
      fontWeight: 700,
      color: 'var(--text-dark)'
    }
  }, fmtDate(hw.due_date), hw.due_time ? ' at ' + fmtTime(hw.due_time) : ''), !extending ? /*#__PURE__*/React.createElement("div", {
    className: "extend-row"
  }, /*#__PURE__*/React.createElement("button", {
    className: "extend-chip",
    disabled: saving,
    onClick: function () {
      extend(0, 3);
    }
  }, "+3 hours"), /*#__PURE__*/React.createElement("button", {
    className: "extend-chip",
    disabled: saving,
    onClick: function () {
      extend(0, 24);
    }
  }, "+1 day"), /*#__PURE__*/React.createElement("button", {
    className: "extend-chip",
    disabled: saving,
    onClick: function () {
      extend(3, 0);
    }
  }, "+3 days"), /*#__PURE__*/React.createElement("button", {
    className: "extend-chip",
    disabled: saving,
    onClick: function () {
      extend(7, 0);
    }
  }, "+1 week"), /*#__PURE__*/React.createElement("button", {
    className: "extend-chip",
    disabled: saving,
    onClick: function () {
      setExtending(true);
      setCustomDate(hw.due_date);
      setCustomTime(hw.due_time || '');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  }), " Custom date\u2026")) : /*#__PURE__*/React.createElement("div", {
    className: "hw-edit-row",
    style: {
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      marginBottom: 0
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field-label",
    style: {
      fontSize: 11
    }
  }, "New Date"), /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "field-input",
    value: customDate,
    onChange: function (e) {
      setCustomDate(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "field",
    style: {
      marginBottom: 0
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "field-label",
    style: {
      fontSize: 11
    }
  }, "Time (optional)"), /*#__PURE__*/React.createElement("input", {
    type: "time",
    className: "field-input",
    value: customTime,
    onChange: function (e) {
      setCustomTime(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    disabled: saving,
    onClick: setExplicitDeadline
  }, "Set"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-cancel",
    onClick: function () {
      setExtending(false);
    }
  }, "Cancel"))), /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-label"
  }, "Parent feedback (", parentComments.length, ")"), parentComments.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: { fontSize: 13, color: '#94a3b8' }
  }, "No parent comments on this assignment yet.") : parentComments.map(function (c) {
    return /*#__PURE__*/React.createElement("div", {
      key: c.id,
      style: {
        padding: '10px 12px',
        marginBottom: 8,
        background: '#F8FAFC',
        borderRadius: 8,
        border: '1px solid #E2E8F0'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: { fontSize: 13.5, color: '#334155', lineHeight: 1.5 }
    }, c.comment), /*#__PURE__*/React.createElement("div", {
      style: { fontSize: 11, color: '#94a3b8', marginTop: 6 }
    }, (c.parent_name || 'Parent') + (c.student_name ? ' · ' + c.student_name : '') + (c.created_at ? ' · ' + c.created_at : '')));
  })), /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-label"
  }, "Acknowledgment Progress"), /*#__PURE__*/React.createElement("div", {
    className: "hw-progress-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-progress-fill",
    style: {
      width: pct + '%'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "hw-progress-text"
  }, data.acknowledged_count, " of", ' ', data.total_count, " parents acknowledged (", pct, "%)")), /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hw-modal-label"
  }, "Class Roster & Grading"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      marginBottom: 10,
      marginTop: -4
    }
  }, "Scores are out of 10 and count toward this student's weekly continuous assessment \u2014 grading works regardless of whether a parent has acknowledged yet."), /*#__PURE__*/React.createElement("table", {
    className: "roster-table"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Student"), /*#__PURE__*/React.createElement("th", null, "Acknowledged"), /*#__PURE__*/React.createElement("th", null, "Grade"), /*#__PURE__*/React.createElement("th", null))), /*#__PURE__*/React.createElement("tbody", null, data.roster.map(function (r) {
    return /*#__PURE__*/React.createElement(RosterRow, {
      key: r.student_id,
      row: r,
      homeworkId: hwId
    });
  }))))))));
}
function RosterRow(props) {
  var r = props.row;
  var hwId = props.homeworkId;
  var scSt = useState(r.score !== null && r.score !== undefined ? String(r.score) : '');
  var score = scSt[0];
  var setScore = scSt[1];
  var fbSt = useState(r.feedback || '');
  var feedback = fbSt[0];
  var setFeedback = fbSt[1];
  var sSt = useState(false);
  var saving = sSt[0];
  var setSaving = sSt[1];
  var jSt = useState(false);
  var justSaved = jSt[0];
  var setJustSaved = jSt[1];
  var eSt = useState('');
  var err = eSt[0];
  var setErr = eSt[1];
  function saveGrade() {
    var n = parseFloat(score);
    if (isNaN(n) || n < 0 || n > 10) {
      setErr('0–10');
      return;
    }
    setErr('');
    setSaving(true);
    fetch('/nsms/api/teacher-homework.php?action=grade', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        homework_id: hwId,
        student_id: r.student_id,
        score: n,
        feedback: feedback
      })
    }).then(function (res) {
      return res.json();
    }).then(function (d) {
      if (d.success) {
        setJustSaved(true);
        setTimeout(function () {
          setJustSaved(false);
        }, 2500);
      } else setErr(d.error || 'Failed');
    }).finally(function () {
      setSaving(false);
    });
  }
  return /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    className: "roster-name"
  }, r.student_name), /*#__PURE__*/React.createElement("td", null, r.acknowledged_at ? /*#__PURE__*/React.createElement("span", {
    className: "ack-badge ack-yes"
  }, "\u2713 ", fmtDate(r.acknowledged_at.slice(0, 10))) : /*#__PURE__*/React.createElement("span", {
    className: "ack-badge ack-no"
  }, "Not yet")), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "number",
    min: "0",
    max: "10",
    step: "0.5",
    className: "grade-input",
    style: {
      width: 56
    },
    value: score,
    placeholder: "\u2014",
    onChange: function (e) {
      setScore(e.target.value);
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, "/10")), /*#__PURE__*/React.createElement("input", {
    className: "field-input",
    style: {
      marginTop: 6,
      padding: '5px 9px',
      fontSize: 12,
      width: 170
    },
    placeholder: "Feedback (optional)",
    value: feedback,
    onChange: function (e) {
      setFeedback(e.target.value);
    }
  }), err && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#DC2626',
      marginTop: 3,
      fontWeight: 600
    }
  }, err)), /*#__PURE__*/React.createElement("td", null, justSaved ? /*#__PURE__*/React.createElement("span", {
    className: "grade-saved-tag"
  }, "\u2713 Saved to gradebook") : /*#__PURE__*/React.createElement("button", {
    className: "grade-save-btn",
    disabled: saving,
    onClick: saveGrade
  }, saving ? '…' : 'Save')));
}

/* ═══════════════════════════════════════════════
MAIN PAGE
═══════════════════════════════════════════════ */
function HomeworkPage() {
  var sbSt = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  var sidebarOpen = sbSt[0];
  var setSidebarOpen = sbSt[1];
  var profSt = useState(null);
  var profile = profSt[0];
  var setProfile = profSt[1];
  var subjSt = useState([]);
  var subjects = subjSt[0];
  var setSubjects = subjSt[1];
  var recentSt = useState([]);
  var recent = recentSt[0];
  var setRecent = recentSt[1];
  var loadSt = useState(true);
  var loading = loadSt[0];
  var setLoading = loadSt[1];
  var savingSt = useState(false);
  var saving = savingSt[0];
  var setSaving = savingSt[1];
  var toastSt = useState(null);
  var toast = toastSt[0];
  var setToast = toastSt[1];
  var dragSt = useState(false);
  var dragOver = dragSt[0];
  var setDragOver = dragSt[1];
  var filesSt = useState([]);
  var files = filesSt[0];
  var setFiles = filesSt[1];
  var selSt = useState(null);
  var selectedHwId = selSt[0];
  var setSelectedHwId = selSt[1];
  var fileRef = useRef(null);

  /* form state */
  var fmSt = useState({
    subject: '',
    description: '',
    due_date: tomorrowISO()
  });
  var form = fmSt[0];
  var setForm = fmSt[1];
  function setField(k, v) {
    setForm(function (f) {
      return Object.assign({}, f, {
        [k]: v
      });
    });
  }
  function reloadRecent() {
    var cid = profile && profile.class_id ? profile.class_id : null;
    var hwUrl = '/nsms/api/teacher-homework.php?action=list';
    if (cid) hwUrl += '&class_id=' + cid;
    fetch(hwUrl).then(function (r) {
      return r.json();
    }).then(function (hwData) {
      if (hwData.success) setRecent((hwData.data || []).slice(0, 8));
    }).catch(function () {});
  }

  /* ── Load profile + subjects + recent homework ── */
  useEffect(function () {
    fetch('/nsms/api/teacher-profile.php?action=get').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success && d.data) {
        setProfile(d.data);
        var cid = d.data.class_id || null;

        /* subjects assigned to this teacher */
        var sid = d.data.id || null;
        var subjUrl = '/nsms/api/teacher-homework.php?action=subjects';
        if (sid) subjUrl += '&teacher_id=' + sid;

        /* recent homework */
        var hwUrl = '/nsms/api/teacher-homework.php?action=list';
        if (cid) hwUrl += '&class_id=' + cid;
        return Promise.all([fetch(subjUrl).then(function (r) {
          return r.json();
        }), fetch(hwUrl).then(function (r) {
          return r.json();
        })]);
      }
      return Promise.all([fetch('/nsms/api/teacher-homework.php?action=subjects').then(function (r) {
        return r.json();
      }), fetch('/nsms/api/teacher-homework.php?action=list').then(function (r) {
        return r.json();
      })]);
    }).then(function (results) {
      var subjData = results[0];
      var hwData = results[1];
      if (subjData.success) setSubjects(subjData.data || []);
      if (hwData.success) setRecent((hwData.data || []).slice(0, 8));
    }).catch(function () {}).finally(function () {
      setLoading(false);
    });
  }, []);

  /* ── Toast auto-dismiss ── */
  useEffect(function () {
    if (!toast) return;
    var t = setTimeout(function () {
      setToast(null);
    }, 3500);
    return function () {
      clearTimeout(t);
    };
  }, [toast]);

  /* ── File handling ── */
  function addFiles(newFiles) {
    var arr = Array.from(newFiles).filter(function (f) {
      return f.size <= 5 * 1024 * 1024; /* 5 MB max */
    });
    setFiles(function (prev) {
      return prev.concat(arr).slice(0, 5);
    });
  }
  function removeFile(idx) {
    setFiles(function (prev) {
      return prev.filter(function (_, i) {
        return i !== idx;
      });
    });
  }
  function onDrop(e) {
    e.preventDefault();
    setDragOver(false);
    addFiles(e.dataTransfer.files);
  }

  /* ── Submit ── */
  function handleSubmit() {
    if (!form.subject) {
      setToast({
        type: 'error',
        msg: 'Please select a subject.'
      });
      return;
    }
    if (!form.description.trim()) {
      setToast({
        type: 'error',
        msg: 'Please enter the homework task.'
      });
      return;
    }
    if (!form.due_date) {
      setToast({
        type: 'error',
        msg: 'Please set a due date.'
      });
      return;
    }
    setSaving(true);
    var cid = profile && profile.class_id ? profile.class_id : null;
    var fd = new FormData();
    fd.append('subject', form.subject);
    fd.append('description', form.description);
    fd.append('due_date', form.due_date);
    if (cid) fd.append('class_id', cid);
    files.forEach(function (f, i) {
      fd.append('attachment_' + i, f);
    });
    var url = '/nsms/api/teacher-homework.php?action=create';
    if (cid) url += '&class_id=' + cid;
    fetch(url, {
      method: 'POST',
      body: fd
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setToast({
          type: 'success',
          msg: /*#__PURE__*/React.createElement("span", {
            style: {
              display: "inline-flex",
              alignItems: "center",
              gap: 6
            }
          }, /*#__PURE__*/React.createElement(Icon, {
            emoji: "\u2713",
            size: 16
          }), "Homework posted successfully!")
        });
        /* Reset form */
        setForm({
          subject: '',
          description: '',
          due_date: tomorrowISO()
        });
        setFiles([]);
        /* Prepend to recent list */
        setRecent(function (prev) {
          var newItem = {
            id: d.data && d.data.id,
            subject: form.subject,
            description: form.description,
            due_date: form.due_date
          };
          return [newItem].concat(prev).slice(0, 8);
        });
      } else {
        setToast({
          type: 'error',
          msg: d.error || 'Failed to post homework.'
        });
      }
    }).catch(function () {
      setToast({
        type: 'error',
        msg: 'Network error. Please try again.'
      });
    }).finally(function () {
      setSaving(false);
    });
  }
  var className = profile && profile.class_name ? profile.class_name : '—';
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TeacherNavbar, {
    activePage: "homework",
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(TeacherSidebar, {
    activePage: "homework",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (sidebarOpen ? '' : ' collapsed')
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "page-title"
  }, "Post Homework"), /*#__PURE__*/React.createElement("p", {
    className: "page-sub"
  }, "Create and post homework for your class")), /*#__PURE__*/React.createElement("div", {
    className: "content-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, "\u270F\uFE0F New Homework Assignment")), /*#__PURE__*/React.createElement("div", {
    className: "card-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Subject ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("div", {
    className: "select-wrap"
  }, /*#__PURE__*/React.createElement("select", {
    className: "field-select",
    value: form.subject,
    onChange: function (e) {
      setField('subject', e.target.value);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Select Subject"), subjects.map(function (s) {
    return /*#__PURE__*/React.createElement("option", {
      key: s.id,
      value: s.subject_name
    }, s.subject_name);
  })))), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Homework Task", ' ', /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "field-textarea",
    placeholder: "Describe the homework task clearly\u2026",
    value: form.description,
    onChange: function (e) {
      setField('description', e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "field-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Due Date", ' ', /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "field-input",
    value: form.due_date,
    min: todayISO(),
    onChange: function (e) {
      setField('due_date', e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Class"), /*#__PURE__*/React.createElement("div", {
    className: "select-wrap"
  }, /*#__PURE__*/React.createElement("select", {
    className: "field-select",
    disabled: true
  }, /*#__PURE__*/React.createElement("option", null, loading ? 'Loading…' : className))))), /*#__PURE__*/React.createElement("div", {
    className: "field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "field-label"
  }, "Attachments", ' ', /*#__PURE__*/React.createElement("small", {
    style: {
      fontWeight: 500,
      color: 'var(--text-muted)'
    }
  }, "(Optional)")), /*#__PURE__*/React.createElement("div", {
    className: 'drop-zone' + (dragOver ? ' drag-over' : ''),
    onClick: function () {
      fileRef.current && fileRef.current.click();
    },
    onDragOver: function (e) {
      e.preventDefault();
      setDragOver(true);
    },
    onDragLeave: function () {
      setDragOver(false);
    },
    onDrop: onDrop
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    multiple: true,
    accept: ".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif",
    style: {
      display: 'none'
    },
    onChange: function (e) {
      addFiles(e.target.files);
      e.target.value = '';
    }
  }), /*#__PURE__*/React.createElement("svg", {
    className: "drop-zone-icon",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l8.57-8.57A4 4 0 0118 8.84l-8.59 8.57a2 2 0 01-2.83-2.83l8.49-8.48",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })), /*#__PURE__*/React.createElement("div", {
    className: "drop-zone-text"
  }, "Click to upload files or drag and drop"), /*#__PURE__*/React.createElement("div", {
    className: "drop-zone-hint"
  }, "PDF, Images, or Documents \u2014 max 5 MB each")), files.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "file-list"
  }, files.map(function (f, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "file-chip"
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 16
      }
    }, "\uD83D\uDCCE"), /*#__PURE__*/React.createElement("span", {
      className: "file-chip-name"
    }, f.name), /*#__PURE__*/React.createElement("span", {
      className: "file-chip-size"
    }, fmtBytes(f.size)), /*#__PURE__*/React.createElement("button", {
      className: "file-chip-del",
      onClick: function () {
        removeFile(i);
      }
    }, "\u2715"));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "form-actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-cancel",
    onClick: function () {
      setForm({
        subject: '',
        description: '',
        due_date: tomorrowISO()
      });
      setFiles([]);
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSubmit,
    disabled: saving
  }, saving ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "btn-spinner"
  }), ' ', "Posting\u2026") : /*#__PURE__*/React.createElement(React.Fragment, null, "\uD83D\uDCDA Post Homework"))))), /*#__PURE__*/React.createElement(RecentPanel, {
    items: recent,
    loading: loading,
    onSelect: setSelectedHwId
  }))))), toast && /*#__PURE__*/React.createElement("div", {
    className: 'toast toast-' + toast.type
  }, toast.msg), selectedHwId && /*#__PURE__*/React.createElement(HomeworkDetailModal, {
    homeworkId: selectedHwId,
    onClose: function () {
      setSelectedHwId(null);
    },
    onChanged: reloadRecent
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(HomeworkPage, null));