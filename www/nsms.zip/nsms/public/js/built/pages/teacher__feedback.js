const { useState, useEffect } = React;

function starsText(n) {
  n = Math.round(parseFloat(n) || 0);
  var s = '';
  for (var i = 1; i <= 5; i++) s += i <= n ? '\u2605' : '\u2606';
  return s;
}

function fmtDate(d) {
  if (!d) return '';
  try {
    return new Date(String(d).replace(' ', 'T')).toLocaleDateString('en-GB', {
      day: 'numeric', month: 'short', year: 'numeric'
    });
  } catch (e) {
    return d;
  }
}

function FeedbackPage() {
  var _sb = useState(false), sidebarOpen = _sb[0], setSidebarOpen = _sb[1];
  var _l = useState(true), loading = _l[0], setLoading = _l[1];
  var _d = useState(null), data = _d[0], setData = _d[1];
  var _e = useState(''), err = _e[0], setErr = _e[1];
  var _tab = useState('ratings'), tab = _tab[0], setTab = _tab[1];
  var _replying = useState(null), replyingId = _replying[0], setReplyingId = _replying[1];
  var _replyText = useState(''), replyText = _replyText[0], setReplyText = _replyText[1];
  var _saving = useState(false), saving = _saving[0], setSaving = _saving[1];
  var _toast = useState(null), toast = _toast[0], setToast = _toast[1];

  function load() {
    setLoading(true);
    fetch('/nsms/api/teacher-ratings.php?action=teacher_feedback', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j.success) {
          setData(j.data);
          // Prefer homework tab if there are comments and no ratings
          var hw = (j.data && j.data.homework_comments) ? j.data.homework_comments.length : 0;
          var rv = (j.data && j.data.reviews) ? j.data.reviews.length : 0;
          if (hw > 0 && rv === 0) setTab('homework');
        } else setErr(j.error || 'Failed to load feedback');
      })
      .catch(function () { setErr('Network error'); })
      .finally(function () { setLoading(false); });
  }

  useEffect(function () { load(); }, []);

  useEffect(function () {
    if (!toast) return;
    var t = setTimeout(function () { setToast(null); }, 3500);
    return function () { clearTimeout(t); };
  }, [toast]);

  var summary = data && data.summary ? data.summary : {};
  var dist = data && data.distribution ? data.distribution : { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  var reviews = data && data.reviews ? data.reviews : [];
  var hwComments = data && data.homework_comments ? data.homework_comments : [];
  var totalPublic = summary.public_reviews || 0;
  var unreplied = hwComments.filter(function (c) { return !c.teacher_reply; }).length;
  var maxDist = 1;
  [5, 4, 3, 2, 1].forEach(function (s) {
    if ((dist[s] || 0) > maxDist) maxDist = dist[s];
  });

  function startReply(c) {
    setReplyingId(c.id);
    setReplyText(c.teacher_reply || '');
  }

  function sendReply(commentId) {
    var text = (replyText || '').trim();
    if (text.length < 2) {
      setToast({ type: 'err', msg: 'Please write a short reply.' });
      return;
    }
    setSaving(true);
    fetch('/nsms/api/teacher-ratings.php?action=reply_homework_comment', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ comment_id: commentId, reply: text })
    })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j.success) {
          setToast({ type: 'ok', msg: j.message || 'Reply sent to parent' });
          setReplyingId(null);
          setReplyText('');
          setData(function (prev) {
            if (!prev) return prev;
            var list = (prev.homework_comments || []).map(function (c) {
              if (c.id === commentId) {
                return Object.assign({}, c, {
                  teacher_reply: text,
                  replied_at: (j.data && j.data.replied_at) || new Date().toISOString()
                });
              }
              return c;
            });
            return Object.assign({}, prev, { homework_comments: list });
          });
        } else {
          setToast({ type: 'err', msg: j.error || 'Could not send reply' });
        }
      })
      .catch(function () { setToast({ type: 'err', msg: 'Network error' }); })
      .finally(function () { setSaving(false); });
  }

  function tabEl(key, label, count) {
    return React.createElement('button', {
      type: 'button',
      key: key,
      className: 'tab' + (tab === key ? ' on' : ''),
      onClick: function () { setTab(key); }
    }, label, React.createElement('span', { className: 'count' }, count));
  }

  return React.createElement(React.Fragment, null,
    React.createElement(TeacherNavbar, {
      activePage: 'feedback',
      sidebarOpen: sidebarOpen,
      setSidebarOpen: setSidebarOpen
    }),
    React.createElement(TeacherSidebar, {
      activePage: 'feedback',
      sidebarOpen: sidebarOpen
    }),
    React.createElement('div', { className: 'page-body' + (sidebarOpen ? ' expanded' : '') },
      React.createElement('div', { className: 'ph' },
        React.createElement('h1', null, 'Feedback Dashboard'),
        React.createElement('div', { className: 'ph-sub' },
          data && data.teacher
            ? ('Ratings and homework comments for ' + (data.teacher.full_name || 'you') +
               (data.teacher.class_name ? ' \u00b7 ' + data.teacher.class_name : ''))
            : 'See how parents rate you and respond to homework comments'
        )
      ),
      toast && React.createElement('div', {
        className: 'toast ' + (toast.type === 'ok' ? 'ok' : 'err')
      }, toast.msg),
      loading
        ? React.createElement('div', { className: 'sw' }, React.createElement('div', { className: 'spinner' }))
        : err
          ? React.createElement('div', { className: 'toast err' }, err)
          : React.createElement(React.Fragment, null,
              React.createElement('div', { className: 'tabs' },
                tabEl('ratings', 'Parent ratings', reviews.length),
                tabEl('homework', 'Homework feedback', hwComments.length)
              ),
              tab === 'ratings' && React.createElement(React.Fragment, null,
                React.createElement('div', { className: 'stats' },
                  React.createElement('div', { className: 'stat' },
                    React.createElement('div', { className: 'stat-l' }, 'Average rating'),
                    React.createElement('div', { className: 'stat-v amber' },
                      summary.avg_rating != null ? summary.avg_rating : '\u2014'
                    ),
                    React.createElement('div', { className: 'stat-hint' },
                      summary.avg_rating != null ? 'out of 5 stars' : 'Waiting for first rating'
                    )
                  ),
                  React.createElement('div', { className: 'stat' },
                    React.createElement('div', { className: 'stat-l' }, 'Total reviews'),
                    React.createElement('div', { className: 'stat-v blue' }, summary.total_reviews || 0),
                    React.createElement('div', { className: 'stat-hint' }, 'All submitted reviews')
                  ),
                  React.createElement('div', { className: 'stat' },
                    React.createElement('div', { className: 'stat-l' }, 'On website'),
                    React.createElement('div', { className: 'stat-v green' }, summary.public_reviews || 0),
                    React.createElement('div', { className: 'stat-hint' }, 'Visible on landing page')
                  ),
                  React.createElement('div', { className: 'stat' },
                    React.createElement('div', { className: 'stat-l' }, '4\u20135 star'),
                    React.createElement('div', { className: 'stat-v green' }, summary.positive_reviews || 0),
                    React.createElement('div', { className: 'stat-hint' }, 'Positive reviews')
                  )
                ),
                React.createElement('div', { className: 'grid' },
                  React.createElement('div', { className: 'card' },
                    React.createElement('h2', null, 'Rating breakdown'),
                    React.createElement('div', { className: 'card-sub' }, 'How your public ratings are distributed'),
                    totalPublic === 0
                      ? React.createElement('div', { className: 'empty' },
                          React.createElement('strong', null, 'No public ratings yet'),
                          'When parents rate you, the star chart will appear here.')
                      : [5, 4, 3, 2, 1].map(function (s) {
                          var n = dist[s] || 0;
                          var pct = Math.round((n / maxDist) * 100);
                          return React.createElement('div', { className: 'bar-row', key: s },
                            React.createElement('div', { className: 'bar-lab' }, s + '\u2605'),
                            React.createElement('div', { className: 'bar-track' },
                              React.createElement('div', { className: 'bar-fill', style: { width: pct + '%' } })
                            ),
                            React.createElement('div', { className: 'bar-n' }, n)
                          );
                        })
                  ),
                  React.createElement('div', { className: 'card' },
                    React.createElement('h2', null, 'Parent reviews'),
                    React.createElement('div', { className: 'card-sub' }, 'Written comments from parents of your class'),
                    reviews.length === 0
                      ? React.createElement('div', { className: 'empty' },
                          React.createElement('strong', null, 'No reviews yet'),
                          'Parents who share feedback about your teaching will show up in this list.')
                      : reviews.map(function (rv) {
                          return React.createElement('div', { className: 'rev', key: rv.id },
                            React.createElement('div', { className: 'rev-top' },
                              React.createElement('div', null,
                                React.createElement('div', { className: 'rev-name' }, rv.parent_display || 'Parent'),
                                React.createElement('div', { className: 'stars' }, starsText(rv.rating))
                              ),
                              React.createElement('div', { style: { textAlign: 'right' } },
                                React.createElement('div', { className: 'rev-date' }, fmtDate(rv.created_at)),
                                React.createElement('span', {
                                  className: 'badge ' + (rv.is_approved ? 'badge-on' : 'badge-off')
                                }, rv.is_approved ? 'On website' : 'Hidden')
                              )
                            ),
                            React.createElement('div', { className: 'rev-body' }, rv.comment || '')
                          );
                        })
                  )
                )
              ),
              tab === 'homework' && React.createElement(React.Fragment, null,
                React.createElement('div', { className: 'stats' },
                  React.createElement('div', { className: 'stat' },
                    React.createElement('div', { className: 'stat-l' }, 'Total comments'),
                    React.createElement('div', { className: 'stat-v blue' }, hwComments.length),
                    React.createElement('div', { className: 'stat-hint' }, 'On your assignments')
                  ),
                  React.createElement('div', { className: 'stat' },
                    React.createElement('div', { className: 'stat-l' }, 'Awaiting reply'),
                    React.createElement('div', { className: 'stat-v amber' }, unreplied),
                    React.createElement('div', { className: 'stat-hint' }, 'Parents waiting for a response')
                  ),
                  React.createElement('div', { className: 'stat' },
                    React.createElement('div', { className: 'stat-l' }, 'Replied'),
                    React.createElement('div', { className: 'stat-v green' }, hwComments.length - unreplied),
                    React.createElement('div', { className: 'stat-hint' }, 'Already answered')
                  ),
                  React.createElement('div', { className: 'stat' },
                    React.createElement('div', { className: 'stat-l' }, 'Tip'),
                    React.createElement('div', { className: 'stat-hint', style: { marginTop: 10, lineHeight: 1.45 } },
                      'Clear, kind replies help parents stay engaged with homework.')
                  )
                ),
                React.createElement('div', { className: 'card' },
                  React.createElement('h2', null, 'Homework feedback'),
                  React.createElement('div', { className: 'card-sub' },
                    'Comments parents left on Daily Diary assignments. Reply to notify them in their portal.'),
                  hwComments.length === 0
                    ? React.createElement('div', { className: 'empty' },
                        React.createElement('strong', null, 'No homework comments yet'),
                        'When a parent leaves feedback on an assignment, it will appear here for you to reply.')
                    : hwComments.map(function (c) {
                        return React.createElement('div', { className: 'rev', key: 'hw-' + c.id },
                          React.createElement('div', { className: 'rev-top' },
                            React.createElement('div', null,
                              React.createElement('div', { className: 'rev-name' }, c.parent_display || 'Parent'),
                              React.createElement('div', { className: 'rev-meta' },
                                (c.student_name ? c.student_name + ' \u00b7 ' : '') + fmtDate(c.created_at)
                              ),
                              React.createElement('div', { className: 'hw-chip' },
                                c.homework_subject || 'Homework'
                              )
                            ),
                            !c.teacher_reply
                              ? React.createElement('span', { className: 'badge badge-hw' }, 'Needs reply')
                              : React.createElement('span', { className: 'badge badge-on' }, 'Replied')
                          ),
                          React.createElement('div', { className: 'rev-body' }, c.comment || ''),
                          c.teacher_reply
                            ? React.createElement('div', { className: 'reply-box' },
                                React.createElement('div', { className: 'lbl' }, 'Your reply'),
                                c.teacher_reply,
                                c.replied_at
                                  ? React.createElement('div', {
                                      style: { fontSize: 11, color: '#64748b', marginTop: 6 }
                                    }, fmtDate(c.replied_at))
                                  : null
                              )
                            : null,
                          replyingId === c.id
                            ? React.createElement('div', null,
                                React.createElement('textarea', {
                                  className: 'reply-input',
                                  value: replyText,
                                  onChange: function (e) { setReplyText(e.target.value); },
                                  rows: 3,
                                  placeholder: 'Write a helpful reply to the parent\u2026'
                                }),
                                React.createElement('div', {
                                  style: { display: 'flex', gap: 8, marginTop: 10, justifyContent: 'flex-end' }
                                },
                                  React.createElement('button', {
                                    type: 'button',
                                    className: 'btn-ghost',
                                    disabled: saving,
                                    onClick: function () { setReplyingId(null); setReplyText(''); }
                                  }, 'Cancel'),
                                  React.createElement('button', {
                                    type: 'button',
                                    className: 'btn-primary',
                                    disabled: saving,
                                    onClick: function () { sendReply(c.id); }
                                  }, saving ? 'Sending\u2026' : (c.teacher_reply ? 'Update reply' : 'Send reply'))
                                )
                              )
                            : React.createElement('button', {
                                type: 'button',
                                className: 'btn-reply',
                                onClick: function () { startReply(c); }
                              }, c.teacher_reply ? 'Edit reply' : 'Reply to parent')
                        );
                      })
                )
              )
            )
    )
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(FeedbackPage));
