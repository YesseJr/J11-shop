function renderIcon(v, size) {
  size = size || 18;
  if (v == null || v === '') return null;
  if (typeof v === 'object') return v;
  if (typeof Icon === 'function') {
    return React.createElement(Icon, {
      emoji: String(v),
      size: size,
      name: window.NSMS_EMOJI_MAP && window.NSMS_EMOJI_MAP[v] || undefined
    });
  }
  return null;
}
const {
  useState,
  useEffect
} = React;
function FirstTimeSetup() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({
    type: '',
    text: ''
  });
  const [passwordStrength, setPasswordStrength] = useState('');
  const [adminExists, setAdminExists] = useState(false);
  const [checking, setChecking] = useState(true);

  // Check if admin already exists
  useEffect(() => {
    checkAdminExists();
  }, []);
  const checkAdminExists = async () => {
    try {
      const response = await fetch('/nsms/api/setup.php?action=check');
      const data = await response.json();
      if (data.admin_exists) {
        setAdminExists(true);
        setMessage({
          type: 'info',
          text: 'Admin account already exists. Please use the login page.'
        });
      }
    } catch (err) {
      console.error('Check error:', err);
    } finally {
      setChecking(false);
    }
  };
  const calculatePasswordStrength = password => {
    if (!password) return '';
    let strength = 0;
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^a-zA-Z0-9]/.test(password)) strength++;
    if (strength <= 2) return 'weak';
    if (strength <= 3) return 'medium';
    return 'strong';
  };
  const handleChange = e => {
    const {
      name,
      value
    } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }

    // Update password strength
    if (name === 'password') {
      setPasswordStrength(calculatePasswordStrength(value));
    }
  };
  const validate = () => {
    const newErrors = {};
    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\+?[0-9]{10,15}$/.test(formData.phone.replace(/\s/g, ''))) {
      newErrors.phone = 'Invalid phone format (e.g., +255712345678)';
    }
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async e => {
    e.preventDefault();
    setMessage({
      type: '',
      text: ''
    });
    if (!validate()) {
      return;
    }
    setLoading(true);
    try {
      const response = await fetch('/nsms/api/setup.php?action=create_admin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          full_name: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          password: formData.password
        })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        setMessage({
          type: 'success',
          text: 'Admin account created successfully! Redirecting to login...'
        });
        setTimeout(() => {
          window.location.href = '/nsms/public/index.html';
        }, 2000);
      } else {
        setMessage({
          type: 'error',
          text: data.error || 'Failed to create admin account'
        });
      }
    } catch (err) {
      setMessage({
        type: 'error',
        text: 'Connection error. Please check your setup.'
      });
      console.error('Setup error:', err);
    } finally {
      setLoading(false);
    }
  };
  if (checking) {
    return /*#__PURE__*/React.createElement("div", {
      className: "setup-container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "logo-section"
    }, /*#__PURE__*/React.createElement("div", {
      className: "logo"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDFEB",
      size: 18
    })), /*#__PURE__*/React.createElement("h1", null, "Checking Setup...")));
  }
  if (adminExists) {
    return /*#__PURE__*/React.createElement("div", {
      className: "setup-container"
    }, /*#__PURE__*/React.createElement("div", {
      className: "logo-section"
    }, /*#__PURE__*/React.createElement("div", {
      className: "logo"
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2705",
      size: 18
    })), /*#__PURE__*/React.createElement("h1", null, "Setup Complete"), /*#__PURE__*/React.createElement("p", {
      className: "subtitle"
    }, "Admin account already exists")), message.type && /*#__PURE__*/React.createElement("div", {
      className: `${message.type}-message`
    }, message.text), /*#__PURE__*/React.createElement("div", {
      className: "login-link"
    }, /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement("a", {
      href: "/nsms/public/index.html"
    }, "Go to Login Page \u2192"))), /*#__PURE__*/React.createElement("div", {
      className: "warning-box"
    }, /*#__PURE__*/React.createElement("h3", null, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u26A0\uFE0F",
      size: 18
    }), " Important"), /*#__PURE__*/React.createElement("p", null, "You can now safely delete this file: ", /*#__PURE__*/React.createElement("strong", null, "setup.html"))));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "setup-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "logo-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "logo"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  })), /*#__PURE__*/React.createElement("h1", null, "First Time Setup"), /*#__PURE__*/React.createElement("p", {
    className: "subtitle"
  }, "Create your administrator account")), /*#__PURE__*/React.createElement("div", {
    className: "warning-box"
  }, /*#__PURE__*/React.createElement("h3", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " Important Security Notice"), /*#__PURE__*/React.createElement("p", null, "This is a one-time setup page. After creating your admin account,", /*#__PURE__*/React.createElement("strong", null, " delete this file"), " from your server for security.")), message.type && /*#__PURE__*/React.createElement("div", {
    className: `${message.type}-message`
  }, message.text), /*#__PURE__*/React.createElement("form", {
    onSubmit: handleSubmit
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    htmlFor: "fullName"
  }, "Full Name ", /*#__PURE__*/React.createElement("span", {
    className: "required"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "text",
    id: "fullName",
    name: "fullName",
    value: formData.fullName,
    onChange: handleChange,
    placeholder: "e.g., John Doe",
    disabled: loading,
    className: errors.fullName ? 'error' : ''
  }), errors.fullName && /*#__PURE__*/React.createElement("div", {
    className: "error-text"
  }, errors.fullName)), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    htmlFor: "email"
  }, "Email Address ", /*#__PURE__*/React.createElement("span", {
    className: "required"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "email",
    id: "email",
    name: "email",
    value: formData.email,
    onChange: handleChange,
    placeholder: "admin@nurseryschool.com",
    disabled: loading,
    className: errors.email ? 'error' : '',
    autoComplete: "email"
  }), errors.email && /*#__PURE__*/React.createElement("div", {
    className: "error-text"
  }, errors.email)), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    htmlFor: "phone"
  }, "Phone Number ", /*#__PURE__*/React.createElement("span", {
    className: "required"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "tel",
    id: "phone",
    name: "phone",
    value: formData.phone,
    onChange: handleChange,
    placeholder: "+255712345678",
    disabled: loading,
    className: errors.phone ? 'error' : '',
    autoComplete: "tel"
  }), errors.phone && /*#__PURE__*/React.createElement("div", {
    className: "error-text"
  }, errors.phone)), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    htmlFor: "password"
  }, "Password ", /*#__PURE__*/React.createElement("span", {
    className: "required"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "password",
    id: "password",
    name: "password",
    value: formData.password,
    onChange: handleChange,
    placeholder: "Minimum 6 characters",
    disabled: loading,
    className: errors.password ? 'error' : '',
    autoComplete: "new-password"
  }), errors.password && /*#__PURE__*/React.createElement("div", {
    className: "error-text"
  }, errors.password), passwordStrength && /*#__PURE__*/React.createElement("div", {
    className: `password-strength strength-${passwordStrength}`
  }, "Password strength: ", passwordStrength.toUpperCase())), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    htmlFor: "confirmPassword"
  }, "Confirm Password ", /*#__PURE__*/React.createElement("span", {
    className: "required"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "password",
    id: "confirmPassword",
    name: "confirmPassword",
    value: formData.confirmPassword,
    onChange: handleChange,
    placeholder: "Re-enter your password",
    disabled: loading,
    className: errors.confirmPassword ? 'error' : '',
    autoComplete: "new-password"
  }), errors.confirmPassword && /*#__PURE__*/React.createElement("div", {
    className: "error-text"
  }, errors.confirmPassword)), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "btn",
    disabled: loading
  }, loading ? 'Creating Account...' : 'Create Admin Account')), /*#__PURE__*/React.createElement("div", {
    className: "login-link"
  }, /*#__PURE__*/React.createElement("p", null, "Already have an account? ", /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/index.html"
  }, "Login here"))));
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/React.createElement(FirstTimeSetup, null));