function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState,
  useEffect
} = React;

// ── DEFAULTS & STATIC DATA ─────────────────────────────────────────────────────

var DEFAULT_SCHOOL = {
  school_name: 'Our School',
  school_tagline: 'Early Childhood Centre',
  school_phone: '+255 712 345 678',
  school_email: 'info@school.ac.tz',
  school_address: 'Plot 45, Mikocheni Street, Dar es Salaam',
  established_year: '2012',
  principal_name: '',
  reg_number: '',
  school_logo: '',
  school_mission: 'To foster curiosity, confidence and a lifelong love of learning in every child through play-based education.',
  school_vision: 'To be the leading centre of holistic early childhood development in the region.'
};
var DEMO_GALLERY = [{
  id: 1,
  url: 'https://picsum.photos/seed/nurs11/800/600',
  caption: 'Our Bright Learning Classroom',
  date: '2025-01-10'
}, {
  id: 2,
  url: 'https://picsum.photos/seed/nurs22/800/600',
  caption: 'Outdoor Play & Discovery Time',
  date: '2025-01-12'
}, {
  id: 3,
  url: 'https://picsum.photos/seed/nurs33/800/600',
  caption: 'Creative Arts & Crafts Session',
  date: '2025-02-14'
}, {
  id: 4,
  url: 'https://picsum.photos/seed/nurs44/800/600',
  caption: 'Graduation Ceremony',
  date: '2025-06-20'
}, {
  id: 5,
  url: 'https://picsum.photos/seed/nurs55/800/600',
  caption: 'Storytime Corner',
  date: '2025-02-22'
}, {
  id: 6,
  url: 'https://picsum.photos/seed/nurs66/800/600',
  caption: 'Annual Sports Day',
  date: '2025-05-16'
}, {
  id: 7,
  url: 'https://picsum.photos/seed/nurs77/800/600',
  caption: 'Music & Dance Workshop',
  date: '2025-03-01'
}, {
  id: 8,
  url: 'https://picsum.photos/seed/nurs88/800/600',
  caption: 'Healthy Meals Program',
  date: '2025-04-05'
}];

// DEMO_REGULATIONS — admin can override these via settings.php?action=get_regulations
var DEMO_REGULATIONS = [{
  id: 1,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD56",
    size: 20
  }),
  title: 'Attendance & Punctuality',
  text: 'Children must arrive by 7:30 AM. Any absence must be reported to the school office by 8:00 AM on the same day.'
}, {
  id: 2,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC57",
    size: 20
  }),
  title: 'School Uniform',
  text: 'All learners are required to wear the official school uniform every day. Hair must be neat and tidy at all times.'
}, {
  id: 3,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF4E",
    size: 20
  }),
  title: 'Healthy Nutrition',
  text: 'Only wholesome, nut-free snacks and meals are permitted. No sweets, chips, or sugary drinks during school hours.'
}, {
  id: 4,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF5",
    size: 20
  }),
  title: 'No Electronic Devices',
  text: 'Mobile phones, tablets, and electronic toys are strictly prohibited. The school takes no responsibility for such items.'
}, {
  id: 5,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83E\uDD1D",
    size: 20
  }),
  title: 'Respect & Conduct',
  text: 'All children, parents, and staff are expected to treat one another with courtesy, kindness, and respect at all times.'
}, {
  id: 6,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDE97",
    size: 20
  }),
  title: 'Pick-Up Safety',
  text: 'Children are released only to registered guardians. Any change must be communicated in writing and valid ID may be required.'
}, {
  id: 7,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC8A",
    size: 20
  }),
  title: 'Medical & Allergies',
  text: 'All medical conditions, allergies, and medications must be disclosed in full during the enrolment process.'
}, {
  id: 8,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE2",
    size: 20
  }),
  title: 'Communication Policy',
  text: 'Official school communication is issued through the parent portal and written notices. Verbal messages via children are not accepted.'
}];

// DEMO_CALENDAR — admin can override these via settings.php?action=get_calendar
var DEMO_CALENDAR = [{
  id: 1,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 20
  }),
  type: 'term',
  title: 'Term 1 Begins',
  date: '2025-01-15',
  desc: 'First day of the new academic year. Children should arrive by 7:30 AM.'
}, {
  id: 2,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67",
    size: 16
  }),
  type: 'event',
  title: "Parent's Day",
  date: '2025-02-14',
  desc: 'Annual parent engagement day. Please confirm attendance by 10 Feb.'
}, {
  id: 3,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF34",
    size: 20
  }),
  type: 'holiday',
  title: 'Mid-Term Break',
  date: '2025-03-03',
  desc: 'School closes for mid-term. Classes resume on Monday, 10 March.'
}, {
  id: 4,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFC6",
    size: 20
  }),
  type: 'event',
  title: 'Sports Day',
  date: '2025-05-16',
  desc: 'Annual sports day at school grounds. Parents are warmly invited.'
}, {
  id: 5,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 20
  }),
  type: 'term',
  title: 'Term 1 Ends',
  date: '2025-06-20',
  desc: 'End of Term 1. Report cards will be issued on this day.'
}, {
  id: 6,
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "sun",
    size: 22
  }),
  type: 'holiday',
  title: 'Long Holiday',
  date: '2025-06-27',
  desc: 'School closes. Term 2 commences 4 August 2025.'
}, {
  id: 7,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 20
  }),
  type: 'term',
  title: 'Term 2 Begins',
  date: '2025-08-04',
  desc: 'First day of Term 2. Please ensure all Term 2 fees are settled.'
}, {
  id: 8,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF34",
    size: 20
  }),
  type: 'holiday',
  title: 'Mid-Term Break',
  date: '2025-09-29',
  desc: 'School closes for mid-term. Classes resume on Monday, 6 October.'
}, {
  id: 9,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFB6",
    size: 20
  }),
  type: 'event',
  title: 'End-of-Year Concert',
  date: '2025-11-28',
  desc: 'Annual concert and prize-giving. All families warmly welcome.'
}, {
  id: 10,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 20
  }),
  type: 'event',
  title: 'Graduation Ceremony',
  date: '2025-12-10',
  desc: 'Graduation for our Nursery II & Pre-Primary leavers. By invitation.'
}, {
  id: 11,
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 20
  }),
  type: 'term',
  title: 'Term 2 Ends',
  date: '2025-12-12',
  desc: 'End of Term 2 and the academic year. Report cards will be issued on this day.'
}];
var FEATURES = [{
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83E\uDDD2",
    size: 20
  }),
  bg: '#EAF2EE',
  title: 'Nurturing Environment',
  desc: 'Every classroom is designed to spark curiosity — safe, warm, and filled with wonder for little minds to explore freely.'
}, {
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC69\u200D\uD83C\uDFEB",
    size: 16
  }),
  bg: '#FAF3E0',
  title: 'Qualified Teachers',
  desc: 'Our educators are carefully selected, fully trained, and deeply passionate about early childhood development.'
}, {
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFA8",
    size: 20
  }),
  bg: '#F5EFE8',
  title: 'Creative Curriculum',
  desc: "A rich, play-based programme blending arts, movement, language, and early numeracy tailored to every child's pace."
}, {
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83E\uDD1D",
    size: 20
  }),
  bg: '#EDF5F0',
  title: 'Parent Partnership',
  desc: 'We keep families informed and involved at every step — through real-time updates, report cards, and open-door meetings.'
}, {
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "shield",
    size: 22
  }),
  bg: '#F0EBF7',
  title: 'Safety First',
  desc: "From secure premises to trained first-aid staff, your child's safety and wellbeing is our highest priority, always."
}, {
  icon: /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF31",
    size: 20
  }),
  bg: '#EBF4F5',
  title: 'Holistic Development',
  desc: 'We nurture the whole child — emotional intelligence, social skills, physical health, and academic readiness in equal measure.'
}];
function renderIcon(v, size) {
  size = size || 20;
  if (v == null) return null;
  if (typeof v === 'object') return v; // already React element
  if (typeof Icon === 'function') return React.createElement(Icon, {
    emoji: String(v),
    size: size
  });
  return null;
}
var TESTIMONIALS = [{
  quote: 'Our daughter has grown so much in confidence since joining. The teachers truly know every child and treat them with such care.',
  name: 'Amina J.',
  role: 'Parent of a Nursery II child',
  avatar: /*#__PURE__*/React.createElement(Icon, {
    name: "user",
    size: 22
  })
}, {
  quote: 'The daily updates and open communication give us real peace of mind. We always know how our son is progressing.',
  name: 'David & Grace M.',
  role: 'Parents of a Pre-Primary child',
  avatar: /*#__PURE__*/React.createElement(Icon, {
    name: "users",
    size: 22
  })
}, {
  quote: 'A warm, professional environment where learning feels like play. We recommend this school without hesitation.',
  name: 'Sarah K.',
  role: 'Parent of twins in Baby Class',
  avatar: /*#__PURE__*/React.createElement(Icon, {
    name: "users",
    size: 22
  })
}];
// ── DECORATIVE LEAF SVG ────────────────────────────────────────────────────────

// ── SCROLL REVEAL ─────────────────────────────────────────────────────────────
// Wraps any block; fades + rises into place the first time it enters the
// viewport, then leaves it alone. `delay` (ms) lets siblings in a grid
// stagger instead of popping in all at once.
function Reveal(props) {
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useRef = React.useRef;
  var ref = useRef(null);
  var st = useState(false);
  var visible = st[0];
  var setVisible = st[1];
  var Tag = props.as || 'div';
  var delay = props.delay || 0;
  useEffect(function () {
    var el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') {
      setVisible(true);
      return;
    }
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          setVisible(true);
          obs.unobserve(el);
        }
      });
    }, {
      threshold: 0.15,
      rootMargin: '0px 0px -40px 0px'
    });
    obs.observe(el);
    return function () {
      obs.disconnect();
    };
  }, []);

  // Forward anything that isn't one of our own config props (onClick, etc.)
  // so Reveal stays a transparent wrapper around whatever it holds.
  var extra = {};
  Object.keys(props).forEach(function (k) {
    if (['as', 'delay', 'className', 'style', 'children'].indexOf(k) === -1) extra[k] = props[k];
  });
  return /*#__PURE__*/React.createElement(Tag, _extends({
    ref: ref,
    className: 'reveal' + (visible ? ' in' : '') + (props.className ? ' ' + props.className : ''),
    style: Object.assign({
      '--rd': delay + 'ms'
    }, props.style || {})
  }, extra), props.children);
}
function LeafDecor(props) {
  var s = props.size || 70;
  return /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 70 70",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M35 8 C52 8 62 22 62 35 C62 48 52 62 35 62 C18 62 8 48 8 35 C8 22 18 8 35 8Z",
    stroke: "rgba(255,255,255,0.45)",
    strokeWidth: "1.2",
    fill: "none"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M35 8 C35 22 28 48 35 62",
    stroke: "rgba(255,255,255,0.35)",
    strokeWidth: "1",
    fill: "none"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M35 8 C42 18 55 28 62 35",
    stroke: "rgba(255,255,255,0.2)",
    strokeWidth: ".8",
    fill: "none"
  }));
}

// ── LIGHTBOX ──────────────────────────────────────────────────────────────────

function Lightbox(props) {
  var images = props.images,
    idx = props.idx,
    onClose = props.onClose,
    onNav = props.onNav;
  useEffect(function () {
    function onKey(e) {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') onNav(-1);
      if (e.key === 'ArrowRight') onNav(1);
    }
    window.addEventListener('keydown', onKey);
    return function () {
      window.removeEventListener('keydown', onKey);
    };
  }, []);
  var img = images[idx];
  if (!img) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "lb-bg",
    onClick: function (e) {
      if (e.target === e.currentTarget) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "lb-box"
  }, /*#__PURE__*/React.createElement("button", {
    className: "lb-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  })), images.length > 1 && /*#__PURE__*/React.createElement("button", {
    className: "lb-nav lb-prev",
    onClick: function () {
      onNav(-1);
    }
  }, "\u2039"), /*#__PURE__*/React.createElement("img", {
    className: "lb-img",
    src: img.url,
    alt: img.caption
  }), img.caption && /*#__PURE__*/React.createElement("div", {
    className: "lb-cap"
  }, img.caption), images.length > 1 && /*#__PURE__*/React.createElement("button", {
    className: "lb-nav lb-next",
    onClick: function () {
      onNav(1);
    }
  }, "\u203A")));
}

// ── SHARED: post-login redirect ───────────────────────────────────────────────
// Used by both LoginModal and RegisterModal (activation) so the two entry points
// always route consistently — first-time users land on their role's setup page,
// returning users land straight on their dashboard.
function redirectAfterLogin(user) {
  var r = user.role;
  var pc = user.password_changed; // 0 = first login, 1 = already set
  if (r === 'teacher') {
    window.location.href = pc === 0 || pc === '0' ? '/nsms/public/teacher/setup.html' : '/nsms/public/teacher/dashboard.html';
  } else if (r === 'parent') {
    window.location.href = pc === 0 || pc === '0' ? '/nsms/public/parent/setup.html' : '/nsms/public/parent/dashboard.html';
  } else {
    window.location.href = '/nsms/public/admin/dashboard.html';
  }
}

// ── LOGIN MODAL ───────────────────────────────────────────────────────────────

function LoginModal(props) {
  var onClose = props.onClose,
    schoolInfo = props.schoolInfo,
    onSwitchToRegister = props.onSwitchToRegister,
    onForgotPassword = props.onForgotPassword;
  var es = useState('');
  var email = es[0];
  var setEmail = es[1];
  var ps = useState('');
  var password = ps[0];
  var setPassword = ps[1];
  var ls = useState(false);
  var loading = ls[0];
  var setLoading = ls[1];
  var errs = useState('');
  var error = errs[0];
  var setError = errs[1];
  var scs = useState('');
  var success = scs[0];
  var setSuccess = scs[1];
  function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!email || !password) {
      setError('Please enter both email and password');
      return;
    }
    setLoading(true);
    fetch('/nsms/api/auth.php?action=login', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        email: email.trim(),
        password: password
      })
    }).then(function (r) {
      return r.json();
    }).then(function (data) {
      if (data.success) {
        setSuccess('Login successful! Redirecting…');
        setTimeout(function () {
          redirectAfterLogin(data.data.user);
        }, 1000);
      } else {
        setError(data.code === 'csrf_failed' ? 'Security token expired — refresh the page and try again.' : data.error || 'Login failed. Teachers: teacher123. Parents: phone digits or parent123.');
        setLoading(false);
      }
    }).catch(function () {
      setError('Connection error. Please try again.');
      setLoading(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-bg",
    onClick: function (e) {
      if (e.target === e.currentTarget) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "login-card"
  }, /*#__PURE__*/React.createElement("button", {
    className: "lc-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "lc-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lc-logo"
  }, schoolInfo.school_logo ? /*#__PURE__*/React.createElement("img", {
    src: schoolInfo.school_logo,
    alt: "Logo",
    style: {
      width: '52px',
      height: '52px',
      objectFit: 'contain',
      borderRadius: '10px'
    }
  }) : '🏫'), /*#__PURE__*/React.createElement("div", {
    className: "lc-title"
  }, "Welcome Back"), /*#__PURE__*/React.createElement("div", {
    className: "lc-sub"
  }, "Sign in to ", schoolInfo.school_name)), error && /*#__PURE__*/React.createElement("div", {
    className: "lc-err"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", error), success && /*#__PURE__*/React.createElement("div", {
    className: "lc-ok"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " ", success), /*#__PURE__*/React.createElement("form", {
    onSubmit: handleSubmit
  }, /*#__PURE__*/React.createElement("div", {
    className: "lc-field"
  }, /*#__PURE__*/React.createElement("label", null, "Email Address"), /*#__PURE__*/React.createElement("input", {
    type: "email",
    placeholder: "Enter your email",
    value: email,
    onChange: function (e) {
      setEmail(e.target.value);
    },
    disabled: loading,
    autoComplete: "email"
  })), /*#__PURE__*/React.createElement("div", {
    className: "lc-field"
  }, /*#__PURE__*/React.createElement("label", null, "Password"), /*#__PURE__*/React.createElement("input", {
    type: "password",
    placeholder: "Enter your password",
    value: password,
    onChange: function (e) {
      setPassword(e.target.value);
    },
    disabled: loading,
    autoComplete: "current-password"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      margin: '-6px 0 12px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onForgotPassword,
    style: {
      background: 'none',
      border: 'none',
      color: '#2563EB',
      fontSize: 13,
      fontWeight: 600,
      cursor: 'pointer',
      padding: 0
    }
  }, "Forgot password?")), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "lc-submit",
    disabled: loading
  }, loading ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F3",
    size: 16
  }), "Signing In\u2026") : 'Sign In')), onSwitchToRegister && /*#__PURE__*/React.createElement("div", {
    className: "lc-switch"
  }, "First time here?", ' ', /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onSwitchToRegister
  }, "Activate your account"))));
}
function ForgotPasswordModal(props) {
  var onClose = props.onClose;
  var es = useState('');
  var email = es[0];
  var setEmail = es[1];
  var ls = useState(false);
  var loading = ls[0];
  var setLoading = ls[1];
  var errs = useState('');
  var error = errs[0];
  var setError = errs[1];
  var scs = useState('');
  var success = scs[0];
  var setSuccess = scs[1];
  function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!email) {
      setError('Please enter the email on your account');
      return;
    }
    setLoading(true);
    fetch('/nsms/api/auth.php?action=forgot_password', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      body: JSON.stringify({
        email: email.trim()
      })
    }).then(function (r) {
      return r.json();
    }).then(function (data) {
      setLoading(false);
      if (data.success) {
        setSuccess(data.message || 'If an account exists for that email, a password reset link has been sent.');
      } else {
        setError(data.error || 'Could not process the request. Try again.');
      }
    }).catch(function () {
      setLoading(false);
      setError('Connection error. Please try again.');
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-bg",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "login-card",
    onClick: function (e) {
      e.stopPropagation();
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "reg-close",
    type: "button",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "lc-title"
  }, "Forgot password"), /*#__PURE__*/React.createElement("div", {
    className: "lc-sub",
    style: {
      marginBottom: 16
    }
  }, "Enter the email for your teacher or parent account. If we find it, we will email a one-time reset link (expires in 1 hour). Your school data is never deleted."), error && /*#__PURE__*/React.createElement("div", {
    className: "lc-err"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", error), success && /*#__PURE__*/React.createElement("div", {
    className: "reg-ok"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " ", success), /*#__PURE__*/React.createElement("form", {
    className: "lc-form",
    onSubmit: handleSubmit
  }, /*#__PURE__*/React.createElement("div", {
    className: "lc-field"
  }, /*#__PURE__*/React.createElement("label", null, "Email Address"), /*#__PURE__*/React.createElement("input", {
    type: "email",
    placeholder: "you@example.com",
    value: email,
    onChange: function (e) {
      setEmail(e.target.value);
    },
    disabled: loading || !!success,
    autoComplete: "email"
  })), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "lc-submit",
    disabled: loading || !!success
  }, loading ? 'Sending…' : 'Send reset link'))));
}

// ── REGISTER MODAL (first-time account activation) ────────────────────────────
// Parents and teachers don't self-register from scratch — their account is
// created by the school admin first. This modal is their first interaction
// with the system: they sign in with the default credentials they were given,
// and (same as the login flow) get routed to their role's setup page to pick a
// personal password when it's their first login.
function RegisterModal(props) {
  var onClose = props.onClose,
    onSwitchToLogin = props.onSwitchToLogin;
  var es = useState('');
  var email = es[0];
  var setEmail = es[1];
  var ps = useState('');
  var password = ps[0];
  var setPassword = ps[1];
  var ls = useState(false);
  var loading = ls[0];
  var setLoading = ls[1];
  var errs = useState('');
  var error = errs[0];
  var setError = errs[1];
  var scs = useState('');
  var success = scs[0];
  var setSuccess = scs[1];
  function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!email || !password) {
      setError('Please enter both the email and default password given to you by the school');
      return;
    }
    setLoading(true);
    fetch('/nsms/api/auth.php?action=login', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        email: email.trim(),
        password: password
      })
    }).then(function (r) {
      return r.json();
    }).then(function (data) {
      if (data.success) {
        var u = data.data.user;
        setSuccess(u.password_changed === 0 || u.password_changed === '0' ? 'Account verified! Taking you to set your personal password…' : 'Welcome back! Redirecting to your dashboard…');
        setTimeout(function () {
          redirectAfterLogin(u);
        }, 1000);
      } else {
        setError(data.code === 'csrf_failed' ? 'Security token expired — refresh the page and try again.' : data.error || 'We could not verify those details. Teachers use teacher123; parents use phone digits or parent123.');
        setLoading(false);
      }
    }).catch(function () {
      setError('Connection error. Please try again.');
      setLoading(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-bg",
    onClick: function (e) {
      if (e.target === e.currentTarget) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "reg-card"
  }, /*#__PURE__*/React.createElement("button", {
    className: "reg-close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "reg-badge"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD11",
    size: 18
  }), " First-Time Activation"), /*#__PURE__*/React.createElement("div", {
    className: "reg-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "reg-title"
  }, "Activate Your Account"), /*#__PURE__*/React.createElement("div", {
    className: "reg-desc"
  }, "Use the email the school registered for you, and the temporary password. Teachers: usually ", /*#__PURE__*/React.createElement("strong", null, "teacher123"), ". Parents: your phone number (digits) or ", /*#__PURE__*/React.createElement("strong", null, "parent123"), " if no phone was set. You will then choose your own password."), error && /*#__PURE__*/React.createElement("div", {
    className: "lc-err"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", error), success && /*#__PURE__*/React.createElement("div", {
    className: "reg-ok"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " ", success), /*#__PURE__*/React.createElement("form", {
    className: "reg-form",
    onSubmit: handleSubmit
  }, /*#__PURE__*/React.createElement("div", {
    className: "reg-field"
  }, /*#__PURE__*/React.createElement("label", null, "Email Address"), /*#__PURE__*/React.createElement("input", {
    type: "email",
    placeholder: "the email your school registered",
    value: email,
    onChange: function (e) {
      setEmail(e.target.value);
    },
    disabled: loading,
    autoComplete: "email"
  })), /*#__PURE__*/React.createElement("div", {
    className: "reg-field"
  }, /*#__PURE__*/React.createElement("label", null, "Default Password"), /*#__PURE__*/React.createElement("input", {
    type: "password",
    placeholder: "the temporary password your school gave you",
    value: password,
    onChange: function (e) {
      setPassword(e.target.value);
    },
    disabled: loading,
    autoComplete: "current-password"
  }), /*#__PURE__*/React.createElement("div", {
    className: "reg-hint"
  }, "You'll be asked to replace this with your own password right after.")), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "reg-submit",
    disabled: loading
  }, loading ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F3",
    size: 16
  }), "Verifying\u2026") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD13",
    size: 16
  }), "Activate My Account"))), onSwitchToLogin && /*#__PURE__*/React.createElement("div", {
    className: "reg-switch",
    style: {
      marginTop: '14px',
      paddingTop: '14px',
      borderTop: '1px solid #F1EDE6'
    }
  }, "Already activated?", ' ', /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onSwitchToLogin
  }, "Sign in instead"))));
}

// ── NAVBAR ────────────────────────────────────────────────────────────────────

// ── SCROLL PROGRESS BAR ────────────────────────────────────────────────────────
function ScrollProgress() {
  var st = useState(0);
  var pct = st[0];
  var setPct = st[1];
  useEffect(function () {
    function onScroll() {
      var h = document.documentElement;
      var scrollable = h.scrollHeight - h.clientHeight;
      setPct(scrollable > 0 ? h.scrollTop / scrollable * 100 : 0);
    }
    window.addEventListener('scroll', onScroll, {
      passive: true
    });
    onScroll();
    return function () {
      window.removeEventListener('scroll', onScroll);
    };
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    className: "scroll-progress",
    style: {
      width: pct + '%'
    }
  });
}
function Navbar(props) {
  var onLogin = props.onLogin,
    onRegister = props.onRegister,
    schoolInfo = props.schoolInfo;
  var sc = useState(false);
  var isScrolled = sc[0];
  var setScrolled = sc[1];
  var acs = useState('');
  var activeSection = acs[0];
  var setActiveSection = acs[1];
  useEffect(function () {
    function onScroll() {
      setScrolled(window.scrollY > 40);
    }
    window.addEventListener('scroll', onScroll);
    return function () {
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  // Highlight whichever section currently owns the vertical centre of the
  // viewport, so the nav link always reflects where the visitor actually is.
  useEffect(function () {
    var ids = ['features', 'about', 'rules', 'calendar', 'gallery', 'contact'];
    var els = ids.map(function (id) {
      return document.getElementById(id);
    }).filter(Boolean);
    if (!els.length || typeof IntersectionObserver === 'undefined') return;
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) setActiveSection(entry.target.id);
      });
    }, {
      rootMargin: '-45% 0px -45% 0px',
      threshold: 0
    });
    els.forEach(function (el) {
      obs.observe(el);
    });
    return function () {
      obs.disconnect();
    };
  }, []);
  function scrollTo(id) {
    var el = document.getElementById(id);
    if (el) el.scrollIntoView({
      behavior: 'smooth'
    });
  }
  function linkClass(id) {
    return 'nav-link' + (activeSection === id ? ' active' : '');
  }
  return /*#__PURE__*/React.createElement("nav", {
    className: 'nav ' + (isScrolled ? 'scrolled' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-brand",
    onClick: function () {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-brand-emblem"
  }, schoolInfo.school_logo ? /*#__PURE__*/React.createElement("img", {
    src: schoolInfo.school_logo,
    alt: "Logo",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'contain',
      borderRadius: '10px'
    }
  }) : /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "nav-brand-text"
  }, /*#__PURE__*/React.createElement("span", {
    className: "nav-brand-name"
  }, schoolInfo.school_name || 'Our School'), /*#__PURE__*/React.createElement("span", {
    className: "nav-brand-sub"
  }, schoolInfo.school_tagline || 'Nursery School'))), /*#__PURE__*/React.createElement("div", {
    className: "nav-links"
  }, /*#__PURE__*/React.createElement("button", {
    className: linkClass('features'),
    onClick: function () {
      scrollTo('features');
    }
  }, "Why Us"), /*#__PURE__*/React.createElement("button", {
    className: linkClass('about'),
    onClick: function () {
      scrollTo('about');
    }
  }, "About"), /*#__PURE__*/React.createElement("button", {
    className: linkClass('rules'),
    onClick: function () {
      scrollTo('rules');
    }
  }, "Rules"), /*#__PURE__*/React.createElement("button", {
    className: linkClass('calendar'),
    onClick: function () {
      scrollTo('calendar');
    }
  }, "Calendar"), /*#__PURE__*/React.createElement("button", {
    className: linkClass('gallery'),
    onClick: function () {
      scrollTo('gallery');
    }
  }, "Gallery"), /*#__PURE__*/React.createElement("button", {
    className: linkClass('contact'),
    onClick: function () {
      scrollTo('contact');
    }
  }, "Contact")), /*#__PURE__*/React.createElement("div", {
    className: "nav-actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "nav-btn-register",
    onClick: onRegister
  }, "Activate", /*#__PURE__*/React.createElement("span", {
    className: "tooltip"
  }, "First-time parents & teachers")), /*#__PURE__*/React.createElement("button", {
    className: "nav-btn-login",
    onClick: onLogin
  }, "Sign In")));
}

// ── HERO ──────────────────────────────────────────────────────────────────────

function Hero(props) {
  var onLogin = props.onLogin,
    schoolInfo = props.schoolInfo;
  var heroRef = React.useRef(null);
  function handleMouseMove(e) {
    var el = heroRef.current;
    if (!el) return;
    var rect = el.getBoundingClientRect();
    el.style.setProperty('--mx', ((e.clientX - rect.left) / rect.width * 100).toFixed(1) + '%');
    el.style.setProperty('--my', ((e.clientY - rect.top) / rect.height * 100).toFixed(1) + '%');
  }
  return /*#__PURE__*/React.createElement("section", {
    className: "hero",
    id: "home",
    ref: heroRef,
    onMouseMove: handleMouseMove
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-dots"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-spot"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-glow hero-glow-1"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-glow hero-glow-2"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-glow hero-glow-3"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-ring hr-1"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-ring hr-2"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-ring hr-3"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-leaves"
  }, /*#__PURE__*/React.createElement("div", {
    className: "h-leaf hl-1"
  }, /*#__PURE__*/React.createElement(LeafDecor, {
    size: 80
  })), /*#__PURE__*/React.createElement("div", {
    className: "h-leaf hl-2"
  }, /*#__PURE__*/React.createElement(LeafDecor, {
    size: 54
  })), /*#__PURE__*/React.createElement("div", {
    className: "h-leaf hl-3"
  }, /*#__PURE__*/React.createElement(LeafDecor, {
    size: 72
  })), /*#__PURE__*/React.createElement("div", {
    className: "h-leaf hl-4"
  }, /*#__PURE__*/React.createElement(LeafDecor, {
    size: 90
  })), /*#__PURE__*/React.createElement("div", {
    className: "h-leaf hl-5"
  }, /*#__PURE__*/React.createElement(LeafDecor, {
    size: 50
  }))), /*#__PURE__*/React.createElement("div", {
    className: "hero-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-txt"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "hero-title hero-fade"
  }, "Where Every Child", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("em", null, "Truly Belongs")), /*#__PURE__*/React.createElement("p", {
    className: "hero-desc hero-fade"
  }, "A safe, joyful place where curiosity is celebrated, confidence is built, and a lifelong love of learning begins \u2014 for every child in our care."), /*#__PURE__*/React.createElement("div", {
    className: "hero-actions hero-fade"
  }, /*#__PURE__*/React.createElement("button", {
    className: "hbtn-gold",
    onClick: function () {
      var el = document.getElementById('about');
      if (el) el.scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "Discover Our School \u2193"), /*#__PURE__*/React.createElement("button", {
    className: "hbtn-ghost",
    onClick: onLogin
  }, "Parent & Staff Login"))), /*#__PURE__*/React.createElement("div", {
    className: "hero-card-right hero-fade"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-glance"
  }, /*#__PURE__*/React.createElement("div", {
    className: "glance-hd"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "school",
    size: 18
  }), " ", schoolInfo.school_name, " \u2014 Our Promise to You"), /*#__PURE__*/React.createElement("div", {
    className: "promise-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "promise-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "promise-icon"
  }, "\uD83D\uDEE1\uFE0F"), /*#__PURE__*/React.createElement("div", {
    className: "promise-label"
  }, "Safe & Secure"), /*#__PURE__*/React.createElement("div", {
    className: "promise-sub"
  }, "Supervised premises, trained staff, and secure pick-up protocols")), /*#__PURE__*/React.createElement("div", {
    className: "promise-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "promise-icon"
  }, "\uD83C\uDF93"), /*#__PURE__*/React.createElement("div", {
    className: "promise-label"
  }, "Expert Teachers"), /*#__PURE__*/React.createElement("div", {
    className: "promise-sub"
  }, "Certified, caring educators dedicated to your child's growth")), /*#__PURE__*/React.createElement("div", {
    className: "promise-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "promise-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF31",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "promise-label"
  }, "Holistic Growth"), /*#__PURE__*/React.createElement("div", {
    className: "promise-sub"
  }, "Developing the whole child \u2014 mind, body, creativity, and character")), /*#__PURE__*/React.createElement("div", {
    className: "promise-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "promise-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83E\uDD1D",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "promise-label"
  }, "Family Partnership"), /*#__PURE__*/React.createElement("div", {
    className: "promise-sub"
  }, "Transparent communication and open doors for every family"))), /*#__PURE__*/React.createElement("div", {
    className: "promise-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "promise-footer-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "promise-footer-text"
  }, schoolInfo.established_year ? 'Est. ' + schoolInfo.established_year : 'Proudly Established'), /*#__PURE__*/React.createElement("div", {
    className: "promise-footer-sub"
  }, "Excellence in Early Childhood Education")))))), /*#__PURE__*/React.createElement("div", {
    className: "scroll-hint"
  }, /*#__PURE__*/React.createElement("div", {
    className: "scroll-line"
  }), /*#__PURE__*/React.createElement("span", null, "Scroll")));
}

// ── FEATURES ──────────────────────────────────────────────────────────────────

function Features() {
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    id: "features"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-inner"
  }, /*#__PURE__*/React.createElement(Reveal, {
    className: "features-hd"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-eyebrow forest"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2726",
    size: 18
  }), " Why Choose Us"), /*#__PURE__*/React.createElement("h2", {
    className: "sec-title"
  }, "A School Built Around", /*#__PURE__*/React.createElement("br", null), "Your Child's Happiness"), /*#__PURE__*/React.createElement("p", {
    className: "sec-desc"
  }, "Everything we do \u2014 from our curriculum to our classrooms \u2014 is shaped by one question: what is best for your child?")), /*#__PURE__*/React.createElement("div", {
    className: "feat-grid"
  }, FEATURES.map(function (f, i) {
    return /*#__PURE__*/React.createElement(Reveal, {
      className: "feat-card",
      key: f.title,
      delay: i * 90
    }, /*#__PURE__*/React.createElement("div", {
      className: "feat-icon-ring",
      style: {
        background: f.bg
      }
    }, renderIcon(f.icon, 22)), /*#__PURE__*/React.createElement("div", {
      className: "feat-divider"
    }), /*#__PURE__*/React.createElement("div", {
      className: "feat-name"
    }, f.title), /*#__PURE__*/React.createElement("div", {
      className: "feat-text"
    }, f.desc));
  }))));
}

// ── TESTIMONIALS ───────────────────────────────────────────────────────────────

function Testimonials() {
  var _s = React.useState([]), live = _s[0], setLive = _s[1];
  var _l = React.useState(true), loading = _l[0], setLoading = _l[1];
  React.useEffect(function () {
    fetch('/nsms/api/teacher-ratings.php?action=public_list&limit=9')
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d && d.success && d.data && Array.isArray(d.data.reviews) && d.data.reviews.length) {
          setLive(d.data.reviews.map(function (rv) {
            var stars = '';
            var n = Math.round(parseFloat(rv.rating) || 0);
            for (var i = 0; i < 5; i++) stars += i < n ? '\u2605' : '\u2606';
            return {
              name: rv.parent_display || 'Parent',
              role: (stars + ' \u00b7 About school teachers'),
              quote: rv.comment,
              avatar: (rv.parent_display || 'P').charAt(0).toUpperCase(),
              key: 'r' + rv.id
            };
          }));
        }
      })
      .catch(function () {})
      .finally(function () { setLoading(false); });
  }, []);
  var cards = live.length ? live : TESTIMONIALS.map(function (t, i) {
    return Object.assign({}, t, { key: t.name || i });
  });
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    id: "testimonials"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-inner"
  }, /*#__PURE__*/React.createElement(Reveal, {
    className: "testi-hd"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-eyebrow gold"
  }, "Parent Voices"), /*#__PURE__*/React.createElement("h2", {
    className: "sec-title"
  }, "Trusted by Families", /*#__PURE__*/React.createElement("br", null), "Like Yours"), /*#__PURE__*/React.createElement("p", {
    className: "sec-desc"
  }, live.length
    ? "Real reviews from parents about our teachers \u2014 updated as families share their experience."
    : "Hear from parents who have placed their trust in us \u2014 and watched their children thrive.")), /*#__PURE__*/React.createElement("div", {
    className: "testi-grid"
  }, cards.map(function (t, i) {
    return /*#__PURE__*/React.createElement(Reveal, {
      className: "testi-card",
      key: t.key || t.name || i,
      delay: i * 100
    }, /*#__PURE__*/React.createElement("div", {
      className: "testi-quote"
    }, t.quote), /*#__PURE__*/React.createElement("div", {
      className: "testi-author"
    }, /*#__PURE__*/React.createElement("div", {
      className: "testi-avatar"
    }, t.avatar), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "testi-name"
    }, t.name), /*#__PURE__*/React.createElement("div", {
      className: "testi-role"
    }, t.role))));
  }))));
}

// ── ABOUT ─────────────────────────────────────────────────────────────────────

function About(props) {
  var s = props.schoolInfo;
  var ainfoItems = [{
    ico: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCD",
      size: 18
    }),
    name: 'Our Location',
    txt: /*#__PURE__*/React.createElement("span", null, s.school_address || 'Plot 45, Mikocheni Street, Dar es Salaam, Tanzania.', /*#__PURE__*/React.createElement("br", null), "Easily accessible from all major neighbourhoods.")
  }, {
    ico: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD57",
      size: 18
    }),
    name: 'School Hours',
    txt: /*#__PURE__*/React.createElement("span", null, "Monday \u2013 Friday: 7:00 AM \u2013 4:00 PM", /*#__PURE__*/React.createElement("br", null), "Extended care available until 6:00 PM for parents.")
  }, {
    ico: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCDE",
      size: 18
    }),
    name: 'Contact Us',
    txt: /*#__PURE__*/React.createElement("span", null, "\uD83D\uDCF1 ", s.school_phone || '+255 712 345 678', /*#__PURE__*/React.createElement("br", null), "\uD83D\uDCE7 ", s.school_email || 'info@school.ac.tz', s.principal_name ? /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement(Icon, {
      name: "user",
      size: 14
    }), " ", s.principal_name) : null)
  }, {
    ico: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF93",
      size: 18
    }),
    name: 'Accreditation',
    txt: /*#__PURE__*/React.createElement("span", null, "Registered with Tanzania Ministry of Education", s.reg_number ? ' (Reg. No. ' + s.reg_number + ')' : '', ". Fully accredited pre-primary institution.")
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    id: "about"
  }, /*#__PURE__*/React.createElement("div", {
    className: "about-glow about-glow-1"
  }), /*#__PURE__*/React.createElement("div", {
    className: "about-glow about-glow-2"
  }), /*#__PURE__*/React.createElement("div", {
    className: "sec-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "about-grid"
  }, /*#__PURE__*/React.createElement(Reveal, {
    className: "about-txt"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-eyebrow white"
  }, "\u2726 About Us"), /*#__PURE__*/React.createElement("h2", {
    className: "sec-title"
  }, "Where Every Child's", /*#__PURE__*/React.createElement("br", null), "Journey Begins"), /*#__PURE__*/React.createElement("p", {
    className: "sec-desc"
  }, s.school_name, " has been a beacon of early childhood education", s.established_year ? ' since ' + s.established_year : '', ". We believe the foundation of lifelong learning is built in these precious early years \u2014 through play, creativity, and a nurturing environment."), /*#__PURE__*/React.createElement("div", {
    className: "about-pillars"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pillar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pillar-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCA1",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "pillar-name"
  }, "Our Mission"), /*#__PURE__*/React.createElement("div", {
    className: "pillar-txt"
  }, s.school_mission || 'Foster curiosity and love for learning in every child through play-based education.')), /*#__PURE__*/React.createElement("div", {
    className: "pillar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pillar-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD2D",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "pillar-name"
  }, "Our Vision"), /*#__PURE__*/React.createElement("div", {
    className: "pillar-txt"
  }, s.school_vision || 'To be the leading centre of holistic early childhood development in the region.')), /*#__PURE__*/React.createElement("div", {
    className: "pillar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pillar-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2764\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "pillar-name"
  }, "Core Values"), /*#__PURE__*/React.createElement("div", {
    className: "pillar-txt"
  }, "Respect, creativity, safety, and inclusivity guide everything we do every single day.")), /*#__PURE__*/React.createElement("div", {
    className: "pillar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pillar-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83E\uDD1D",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "pillar-name"
  }, "Community"), /*#__PURE__*/React.createElement("div", {
    className: "pillar-txt"
  }, "We build strong partnerships with families to ensure every child's wellbeing.")))), /*#__PURE__*/React.createElement("div", {
    className: "ainfo-list"
  }, ainfoItems.map(function (item, i) {
    return /*#__PURE__*/React.createElement(Reveal, {
      className: "ainfo-card",
      key: item.name,
      delay: 150 + i * 100
    }, /*#__PURE__*/React.createElement("div", {
      className: "ainfo-ico"
    }, item.ico), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "ainfo-name"
    }, item.name), /*#__PURE__*/React.createElement("div", {
      className: "ainfo-txt"
    }, item.txt)));
  })))));
}

// ── REGULATIONS ───────────────────────────────────────────────────────────────

function Regulations(props) {
  var rules = props.rules,
    s = props.schoolInfo;
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    id: "rules"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-inner"
  }, /*#__PURE__*/React.createElement(Reveal, {
    className: "rules-hd"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-eyebrow forest"
  }, "\u2726 School Policies"), /*#__PURE__*/React.createElement("h2", {
    className: "sec-title"
  }, "Our Regulations & Guidelines"), /*#__PURE__*/React.createElement("p", {
    className: "sec-desc"
  }, "To ensure every child has a safe, happy, and productive day at ", s.school_name, ", we ask all families to observe and uphold the following school regulations.")), /*#__PURE__*/React.createElement("div", {
    className: "rules-grid"
  }, rules.map(function (r, i) {
    return /*#__PURE__*/React.createElement(Reveal, {
      className: "rule-card",
      key: r.id,
      delay: i % 4 * 80
    }, /*#__PURE__*/React.createElement("div", {
      className: "rule-num"
    }, String(i + 1).padStart(2, '0')), /*#__PURE__*/React.createElement("div", {
      className: "rule-icon"
    }, renderIcon(r.icon, 20)), /*#__PURE__*/React.createElement("div", {
      className: "rule-title"
    }, r.title), /*#__PURE__*/React.createElement("div", {
      className: "rule-text"
    }, r.text));
  })), /*#__PURE__*/React.createElement(Reveal, {
    className: "rules-footer",
    as: "div"
  }, /*#__PURE__*/React.createElement("p", {
    className: "rules-footer-text"
  }, "A full copy of our school policies and code of conduct is available from the school office and on the parent portal."), /*#__PURE__*/React.createElement("button", {
    className: "hbtn-gold",
    style: {
      margin: '0 auto'
    },
    onClick: function () {
      document.getElementById('contact').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "\uD83D\uDCCB Request Full Policy Document"))));
}

// ── SCHOOL CALENDAR ────────────────────────────────────────────────────────────

var CAL_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function SchoolCalendar(props) {
  var events = props.events,
    s = props.schoolInfo,
    schedule = props.schedule;
  function fmtDate(d) {
    if (!d) return null;
    var parts = d.split('-');
    var day = parseInt(parts[2], 10);
    var mon = CAL_MONTHS[parseInt(parts[1], 10) - 1] || '';
    return {
      day: day,
      mon: mon,
      short: day + ' ' + mon
    };
  }
  function fmtRange(start, end) {
    var s = fmtDate(start),
      e = fmtDate(end);
    if (!s && !e) return null;
    if (s && e) return s.short + ' – ' + e.short;
    return (s || e).short;
  }
  function badgeClass(type) {
    if (type === 'term') return 'cal-badge cal-badge-term';
    if (type === 'holiday') return 'cal-badge cal-badge-holiday';
    if (type === 'exam') return 'cal-badge cal-badge-exam';
    return 'cal-badge cal-badge-event';
  }
  function badgeLabel(type) {
    if (type === 'term') return 'Term';
    if (type === 'holiday') return 'Holiday';
    if (type === 'exam') return 'Exam';
    return 'Event';
  }

  // Build dynamic term panels from schedule
  var term1Range = schedule ? fmtRange(schedule.acad_term1_start, schedule.acad_term1_end) : null;
  var term1Exam = schedule ? fmtRange(schedule.acad_term1_exam_start, schedule.acad_term1_exam_end) : null;
  var term2Range = schedule ? fmtRange(schedule.acad_term2_start, schedule.acad_term2_end) : null;
  var term2Exam = schedule ? fmtRange(schedule.acad_term2_exam_start, schedule.acad_term2_exam_end) : null;
  var gradDate = schedule && schedule.acad_graduation_date ? fmtDate(schedule.acad_graduation_date) : null;

  // Only show a term row if at least one date is set
  var hasT1 = term1Range !== null;
  var hasT2 = term2Range !== null;
  var hasGrad = gradDate !== null;
  var hasAny = hasT1 || hasT2 || hasGrad;
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    id: "calendar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-glow-1"
  }), /*#__PURE__*/React.createElement("div", {
    className: "cal-glow-2"
  }), /*#__PURE__*/React.createElement("div", {
    className: "sec-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-grid"
  }, /*#__PURE__*/React.createElement(Reveal, {
    className: "cal-left"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-eyebrow white"
  }, "\u2726 Academic Year"), /*#__PURE__*/React.createElement("h2", {
    className: "sec-title"
  }, "School Calendar & Key Dates"), /*#__PURE__*/React.createElement("p", {
    className: "sec-desc"
  }, "Stay informed and plan ahead. Here are the most important dates, terms, events, and holidays for the current academic year at ", s.school_name, "."), hasAny ? /*#__PURE__*/React.createElement("div", {
    className: "cal-terms"
  }, hasT1 && /*#__PURE__*/React.createElement("div", {
    className: "cal-term"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-term-dot",
    style: {
      background: '#B8892E'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-term-name"
  }, "Term 1"), /*#__PURE__*/React.createElement("div", {
    className: "cal-term-dates"
  }, term1Range), term1Exam && /*#__PURE__*/React.createElement("div", {
    className: "cal-term-exam"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cal-term-exam-dot"
  }), "Exams:", ' ', term1Exam))), hasT2 && /*#__PURE__*/React.createElement("div", {
    className: "cal-term"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-term-dot",
    style: {
      background: '#3D9E6E'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-term-name"
  }, "Term 2"), /*#__PURE__*/React.createElement("div", {
    className: "cal-term-dates"
  }, term2Range), term2Exam && /*#__PURE__*/React.createElement("div", {
    className: "cal-term-exam"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cal-term-exam-dot"
  }), "Exams:", ' ', term2Exam))), hasGrad && /*#__PURE__*/React.createElement("div", {
    className: "cal-term-grad"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-term-grad-ico"
  }, "\uD83C\uDF93"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "cal-term-grad-name"
  }, "Graduation Ceremony"), /*#__PURE__*/React.createElement("div", {
    className: "cal-term-grad-dates"
  }, gradDate.short)))) : /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32,
      fontSize: 13,
      color: 'rgba(255,255,255,.32)',
      fontStyle: 'italic'
    }
  }, "Term dates not yet published. Check back soon.")), /*#__PURE__*/React.createElement(Reveal, {
    as: "div",
    delay: 150
  }, events.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "cal-empty"
  }, "\uD83D\uDCC5 Calendar not yet published. Check back soon.") : /*#__PURE__*/React.createElement("div", {
    className: "cal-events"
  }, events.map(function (ev) {
    var d = fmtDate(ev.date);
    return /*#__PURE__*/React.createElement("div", {
      className: "cal-event",
      key: ev.id
    }, /*#__PURE__*/React.createElement("div", {
      className: "cal-date-badge"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cal-date-day"
    }, d.day), /*#__PURE__*/React.createElement("div", {
      className: "cal-date-mon"
    }, d.mon)), /*#__PURE__*/React.createElement("div", {
      className: "cal-event-body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "cal-event-title"
    }, renderIcon(ev.icon, 20), ' ', ev.title), ev.desc && /*#__PURE__*/React.createElement("div", {
      className: "cal-event-desc"
    }, ev.desc), /*#__PURE__*/React.createElement("span", {
      className: badgeClass(ev.type)
    }, badgeLabel(ev.type))));
  }))))));
}

// ── GALLERY ───────────────────────────────────────────────────────────────────

function Gallery(props) {
  var images = props.images,
    s = props.schoolInfo;
  var lis = useState(null);
  var lbIdx = lis[0];
  var setLbIdx = lis[1];
  function navLb(dir) {
    setLbIdx(function (cur) {
      var next = cur + dir;
      if (next < 0) return images.length - 1;
      if (next >= images.length) return 0;
      return next;
    });
  }

  // Respect reduced-motion: don't duplicate the strip if it isn't going to
  // animate anyway — that would just show every photo twice for no reason.
  var reduceMotion = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var track = images.length > 1 && !reduceMotion ? images.concat(images) : images;
  var duration = Math.max(24, images.length * 5) + 's';
  function sizeClass(i) {
    if (i % 5 === 1) return ' g-tall';
    if (i % 5 === 3) return ' g-wide';
    return '';
  }
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    id: "gallery"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-inner"
  }, /*#__PURE__*/React.createElement(Reveal, {
    className: "gallery-hd"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "sec-eyebrow gold"
  }, "\u2726 Our Gallery"), /*#__PURE__*/React.createElement("h2", {
    className: "sec-title",
    style: {
      color: 'var(--forest)'
    }
  }, "Life at ", s.school_name)), /*#__PURE__*/React.createElement("p", {
    className: "sec-desc"
  }, "A glimpse into the joyful, learning-filled days our children live and love every week.")), images.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "g-empty"
  }, /*#__PURE__*/React.createElement("div", {
    className: "g-empty-ico"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF8",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "g-empty-text"
  }, "No gallery images yet.", /*#__PURE__*/React.createElement("br", null), "The school admin will upload photos here soon.")) : /*#__PURE__*/React.createElement(Reveal, {
    className: "gallery-slider",
    delay: 100
  }, /*#__PURE__*/React.createElement("div", {
    className: "gallery-track",
    style: {
      '--gdur': duration
    }
  }, track.map(function (img, i) {
    var realIdx = i % images.length;
    return /*#__PURE__*/React.createElement("div", {
      className: 'g-item' + sizeClass(realIdx),
      key: img.id + '-' + i,
      onClick: function () {
        setLbIdx(realIdx);
      }
    }, /*#__PURE__*/React.createElement("img", {
      className: "g-img",
      src: img.url,
      alt: img.caption,
      loading: "lazy"
    }), /*#__PURE__*/React.createElement("div", {
      className: "g-overlay"
    }, /*#__PURE__*/React.createElement("div", {
      className: "g-caption"
    }, /*#__PURE__*/React.createElement("div", {
      className: "g-cap-text"
    }, img.caption), img.date && /*#__PURE__*/React.createElement("div", {
      className: "g-cap-date"
    }, img.date))));
  })))), lbIdx !== null && /*#__PURE__*/React.createElement(Lightbox, {
    images: images,
    idx: lbIdx,
    onClose: function () {
      setLbIdx(null);
    },
    onNav: navLb
  }));
}

// ── CONTACT STRIP ─────────────────────────────────────────────────────────────

function ContactStrip(props) {
  var onLogin = props.onLogin,
    onRegister = props.onRegister,
    s = props.schoolInfo;
  var phone = s.school_phone || '+255 712 345 678';
  var email = s.school_email || 'info@school.ac.tz';
  return /*#__PURE__*/React.createElement("section", {
    className: "contact-strip",
    id: "contact"
  }, /*#__PURE__*/React.createElement(Reveal, {
    className: "contact-strip-inner",
    as: "div"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-eyebrow white",
    style: {
      justifyContent: 'center',
      margin: '0 auto 20px'
    }
  }, "\u2726 Get In Touch"), /*#__PURE__*/React.createElement("h2", {
    className: "sec-title"
  }, "Ready to Join the", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("em", null, s.school_name, " Family?")), /*#__PURE__*/React.createElement("p", {
    className: "sec-desc"
  }, "Whether you are enquiring about enrolment or accessing the parent & staff portal, we are here to support you every step of the way."), /*#__PURE__*/React.createElement("div", {
    className: "contact-strip-btns"
  }, /*#__PURE__*/React.createElement("button", {
    className: "hbtn-gold",
    onClick: onLogin
  }, "Parent & Staff Login"), /*#__PURE__*/React.createElement("button", {
    className: "hbtn-ghost",
    onClick: onRegister
  }, "Activate Your Account")), /*#__PURE__*/React.createElement("div", {
    className: "contact-strip-meta"
  }, "\uD83D\uDCDE ", phone, " \xA0\u2022\xA0 \uD83D\uDCE7 ", email)));
}

// ── FOOTER ────────────────────────────────────────────────────────────────────

function Footer(props) {
  var s = props.schoolInfo;
  var year = new Date().getFullYear();
  return /*#__PURE__*/React.createElement("footer", null, /*#__PURE__*/React.createElement("div", {
    className: "ft-upper"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ft-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ft-top"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ft-logo"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ft-logo-ico"
  }, s.school_logo ? /*#__PURE__*/React.createElement("img", {
    src: s.school_logo,
    alt: "Logo",
    style: {
      width: '34px',
      height: '34px',
      objectFit: 'contain',
      borderRadius: '6px'
    }
  }) : /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "ft-logo-name"
  }, s.school_name || 'Our School')), /*#__PURE__*/React.createElement("div", {
    className: "ft-brand-desc"
  }, "Providing excellence in early childhood education", s.established_year ? ' since ' + s.established_year : '', ". A nurturing space where every child is seen, heard, and celebrated."), /*#__PURE__*/React.createElement("div", {
    className: "ft-brand-tagline"
  }, "\u2726 Proudly Serving Families")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ft-col-h"
  }, "Quick Links"), /*#__PURE__*/React.createElement("ul", {
    className: "ft-col-links"
  }, /*#__PURE__*/React.createElement("li", {
    onClick: function () {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  }, "Home"), /*#__PURE__*/React.createElement("li", {
    onClick: function () {
      document.getElementById('features').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "Why Choose Us"), /*#__PURE__*/React.createElement("li", {
    onClick: function () {
      document.getElementById('about').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "About Us"), /*#__PURE__*/React.createElement("li", {
    onClick: function () {
      document.getElementById('gallery').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "Gallery"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ft-col-h"
  }, "School Info"), /*#__PURE__*/React.createElement("ul", {
    className: "ft-col-links"
  }, /*#__PURE__*/React.createElement("li", {
    onClick: function () {
      document.getElementById('rules').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "Regulations"), /*#__PURE__*/React.createElement("li", {
    onClick: function () {
      document.getElementById('calendar').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "School Calendar"), /*#__PURE__*/React.createElement("li", {
    onClick: function () {
      document.getElementById('contact').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "Admissions"), /*#__PURE__*/React.createElement("li", {
    onClick: function () {
      document.getElementById('contact').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "Contact Us"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ft-col-h"
  }, "Contact"), /*#__PURE__*/React.createElement("ul", {
    className: "ft-col-links"
  }, /*#__PURE__*/React.createElement("li", {
    className: "nc"
  }, "\uD83D\uDCCD", ' ', s.school_address || 'Mikocheni, Dar es Salaam'), /*#__PURE__*/React.createElement("li", {
    className: "nc"
  }, "\uD83D\uDCDE", ' ', s.school_phone || '+255 712 345 678'), /*#__PURE__*/React.createElement("li", {
    className: "nc"
  }, "\uD83D\uDCE7", ' ', s.school_email || 'info@school.ac.tz'), /*#__PURE__*/React.createElement("li", {
    className: "nc"
  }, "\uD83D\uDD57 Mon\u2013Fri: 7AM \u2013 4PM")))))), /*#__PURE__*/React.createElement("div", {
    className: "ft-bottom-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ft-bottom"
  }, /*#__PURE__*/React.createElement("div", null, "\xA9 ", year, " ", s.school_name || 'Nursery School', ". All rights reserved."), /*#__PURE__*/React.createElement("div", {
    style: {
      opacity: 0.7
    }
  }, "School management powered by NSMS"))));
}

// ── APP ───────────────────────────────────────────────────────────────────────

function App() {
  // ── School info (from settings API) ───────────────────────────────────────
  var sis = useState(DEFAULT_SCHOOL);
  var schoolInfo = sis[0];
  var setSchoolInfo = sis[1];

  // ── UI state ───────────────────────────────────────────────────────────────
  var sls = useState(false);
  var showLogin = sls[0];
  var setShowLogin = sls[1];
  var srs = useState(false);
  var showReg = srs[0];
  var setShowReg = srs[1];
  var sfs = useState(false);
  var showForgot = sfs[0];
  var setShowForgot = sfs[1];
  var scs = useState(false);
  var showScroll = scs[0];
  var setShowScroll = scs[1];

  // ── Dynamic content (admin-managed via settings panel) ─────────────────────
  var gls = useState(DEMO_GALLERY);
  var gallery = gls[0];
  var setGallery = gls[1];
  var rls = useState(DEMO_REGULATIONS);
  var regulations = rls[0];
  var setRegulations = rls[1];
  var cls = useState(DEMO_CALENDAR);
  var calEvents = cls[0];
  var setCalEvents = cls[1];
  var acs = useState(null);
  var acSched = acs[0];
  var setAcSched = acs[1];

  // Fetch school info
  useEffect(function () {
    fetch('/nsms/api/settings.php?action=get_public').then(function (r) {
      return r.json();
    }).then(function (data) {
      if (data.success && data.data) {
        setSchoolInfo(function (prev) {
          return Object.assign({}, prev, data.data);
        });
        if (data.data.school_name) {
          document.title = data.data.school_name + ' — Welcome';
        }
      }
    }).catch(function () {
      /* keep defaults */
    });
  }, []);

  // Fetch gallery — managed by admin in settings panel
  // Requires settings.php?action=get_gallery → { success, data: [{ id, url, caption, date }] }
  useEffect(function () {
    fetch('/nsms/api/settings.php?action=get_gallery').then(function (r) {
      return r.json();
    }).then(function (data) {
      if (data.success && data.data && data.data.length > 0) setGallery(data.data);
    }).catch(function () {
      /* keep demo gallery */
    });
  }, []);

  // Fetch regulations — managed by admin in settings panel
  // Requires settings.php?action=get_regulations → { success, data: [{ id, icon, title, text }] }
  useEffect(function () {
    fetch('/nsms/api/settings.php?action=get_regulations').then(function (r) {
      return r.json();
    }).then(function (data) {
      if (data.success && data.data && data.data.length > 0) setRegulations(data.data);
    }).catch(function () {
      /* keep demo regulations */
    });
  }, []);

  // Fetch calendar — managed by admin in settings panel
  // Requires settings.php?action=get_calendar → { success, data: [{ id, icon, type, title, date, desc }] }
  useEffect(function () {
    fetch('/nsms/api/settings.php?action=get_calendar').then(function (r) {
      return r.json();
    }).then(function (data) {
      if (data.success && data.data && data.data.length > 0) setCalEvents(data.data);
    }).catch(function () {
      /* keep demo calendar */
    });
  }, []);

  // Fetch academic schedule — term/exam/graduation dates set by admin in settings
  useEffect(function () {
    fetch('/nsms/api/settings.php?action=get_academic_schedule').then(function (r) {
      return r.json();
    }).then(function (data) {
      if (data.success && data.data) setAcSched(data.data);
    }).catch(function () {
      /* leave null — calendar shows nothing in term panel */
    });
  }, []);

  // Scroll-to-top button visibility
  useEffect(function () {
    function onScroll() {
      setShowScroll(window.scrollY > 400);
    }
    window.addEventListener('scroll', onScroll);
    return function () {
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  // Auto-open login modal when redirected from teacher setup page (?login=1)
  useEffect(function () {
    var params = new URLSearchParams(window.location.search);
    if (params.get('login') === '1') {
      setShowLogin(true);
      // Clean the URL without reloading
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, []);
  function openLogin() {
    setShowLogin(true);
    setShowReg(false);
  }
  function openRegister() {
    setShowReg(true);
    setShowLogin(false);
  }
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ScrollProgress, null), /*#__PURE__*/React.createElement(Navbar, {
    onLogin: openLogin,
    onRegister: openRegister,
    schoolInfo: schoolInfo
  }), /*#__PURE__*/React.createElement(Hero, {
    onLogin: openLogin,
    schoolInfo: schoolInfo
  }), /*#__PURE__*/React.createElement(Features, null), /*#__PURE__*/React.createElement(Testimonials, null), /*#__PURE__*/React.createElement(About, {
    schoolInfo: schoolInfo
  }), /*#__PURE__*/React.createElement(Regulations, {
    rules: regulations,
    schoolInfo: schoolInfo
  }), /*#__PURE__*/React.createElement(SchoolCalendar, {
    events: calEvents,
    schedule: acSched,
    schoolInfo: schoolInfo
  }), /*#__PURE__*/React.createElement(Gallery, {
    images: gallery,
    schoolInfo: schoolInfo
  }), /*#__PURE__*/React.createElement(ContactStrip, {
    onLogin: openLogin,
    onRegister: openRegister,
    schoolInfo: schoolInfo
  }), /*#__PURE__*/React.createElement(Footer, {
    schoolInfo: schoolInfo
  }), /*#__PURE__*/React.createElement("button", {
    className: 'scroll-top-btn ' + (showScroll ? '' : 'hidden'),
    onClick: function () {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  }, "\u2191"), showLogin && /*#__PURE__*/React.createElement(LoginModal, {
    onClose: function () {
      setShowLogin(false);
    },
    schoolInfo: schoolInfo,
    onSwitchToRegister: openRegister,
    onForgotPassword: function () {
      setShowLogin(false);
      setShowForgot(true);
    }
  }), showForgot && /*#__PURE__*/React.createElement(ForgotPasswordModal, {
    onClose: function () {
      setShowForgot(false);
    }
  }), showReg && /*#__PURE__*/React.createElement(RegisterModal, {
    onClose: function () {
      setShowReg(false);
    },
    onSwitchToLogin: openLogin
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));