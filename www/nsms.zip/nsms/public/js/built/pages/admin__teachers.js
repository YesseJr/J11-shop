var useState = React.useState;
var useEffect = React.useEffect;
var useRef = React.useRef;

// ── Utility helpers ────────────────────────────────────────────────────
function getInitials(name) {
  if (!name) return '?';
  return name.split(' ').map(function (n) {
    return n[0];
  }).join('').toUpperCase().slice(0, 2);
}
function getAvatarColor(name) {
  var colors = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2'];
  return name ? colors[name.charCodeAt(0) % colors.length] : '#94A3B8';
}
function formatDate(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}
function renderStars(rating, large) {
  var r = parseFloat(rating) || 0;
  var full = Math.floor(r);
  var empty = 5 - full;
  var stars = [];
  for (var i = 0; i < full; i++) stars.push(React.createElement(Icon, {
    name: 'star',
    size: 14,
    key: 'f' + i
  }));
  for (var j = 0; j < empty; j++) stars.push(React.createElement(Icon, {
    name: 'star',
    size: 14,
    key: 'e' + j,
    style: {
      opacity: 0.25
    }
  }));
  return /*#__PURE__*/React.createElement("span", {
    className: large ? 'rating-stars-large' : 'stars'
  }, stars);
}
function statusLabel(s) {
  if (s === 'active') return 'Active';
  if (s === 'on_leave') return 'On Leave';
  if (s === 'inactive') return 'Inactive';
  if (s === 'suspended') return 'Suspended';
  return s;
}
function showToast(msg, type, setToast) {
  setToast({
    msg: msg,
    type: type || 'success'
  });
  setTimeout(function () {
    setToast(null);
  }, 3200);
}

// ── VIEW MODAL ─────────────────────────────────────────────────────────
function ViewModal(props) {
  var teacher = props.teacher;
  var onClose = props.onClose;
  var onEdit = props.onEdit;
  if (!teacher) return null;
  var subjectList = teacher.subjects ? teacher.subjects.split(', ') : [];
  var classColor = teacher.class_color || '#94A3B8';
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-modal",
    onClick: function (e) {
      e.stopPropagation();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-modal-header"
  }, /*#__PURE__*/React.createElement("h2", null, "Teacher Profile"), /*#__PURE__*/React.createElement("button", {
    className: "modal-close-btn",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "view-profile"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-photo-wrap"
  }, teacher.photo_url ? /*#__PURE__*/React.createElement("img", {
    src: teacher.photo_url,
    alt: teacher.full_name,
    className: "view-photo"
  }) : /*#__PURE__*/React.createElement("div", {
    className: "view-photo-placeholder",
    style: {
      background: getAvatarColor(teacher.full_name)
    }
  }, getInitials(teacher.full_name))), /*#__PURE__*/React.createElement("div", {
    className: "view-info"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-name"
  }, teacher.full_name), /*#__PURE__*/React.createElement("div", {
    className: "view-meta"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'status-badge status-' + teacher.status
  }, statusLabel(teacher.status)), teacher.class_name && /*#__PURE__*/React.createElement("span", {
    className: "class-badge",
    style: {
      background: classColor
    }
  }, teacher.class_name)), /*#__PURE__*/React.createElement("div", {
    className: "view-details"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-detail-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-detail-label"
  }, "Email"), /*#__PURE__*/React.createElement("div", {
    className: "view-detail-value"
  }, teacher.email)), /*#__PURE__*/React.createElement("div", {
    className: "view-detail-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-detail-label"
  }, "Phone"), /*#__PURE__*/React.createElement("div", {
    className: "view-detail-value"
  }, teacher.phone || '—')), /*#__PURE__*/React.createElement("div", {
    className: "view-detail-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-detail-label"
  }, "Joined"), /*#__PURE__*/React.createElement("div", {
    className: "view-detail-value"
  }, formatDate(teacher.created_at))), /*#__PURE__*/React.createElement("div", {
    className: "view-detail-item"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-detail-label"
  }, "Last Login"), /*#__PURE__*/React.createElement("div", {
    className: "view-detail-value"
  }, formatDate(teacher.last_login)))))), /*#__PURE__*/React.createElement("div", {
    className: "view-sections"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-section-title"
  }, "Performance Rating"), /*#__PURE__*/React.createElement("div", {
    className: "rating-display"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rating-number"
  }, teacher.avg_rating || '—'), /*#__PURE__*/React.createElement("div", null, renderStars(teacher.avg_rating, true), /*#__PURE__*/React.createElement("div", {
    className: "rating-meta"
  }, teacher.rating_count > 0 ? teacher.rating_count + ' review' + (teacher.rating_count !== 1 ? 's' : '') : 'No reviews yet')))), /*#__PURE__*/React.createElement("div", {
    className: "view-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-section-title"
  }, "Subjects Teaching"), /*#__PURE__*/React.createElement("div", {
    className: "subjects-chips"
  }, subjectList.length > 0 ? subjectList.map(function (s, i) {
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      className: "subject-chip"
    }, s);
  }) : /*#__PURE__*/React.createElement("span", {
    className: "subject-chip empty"
  }, "No subjects assigned"))), /*#__PURE__*/React.createElement("div", {
    className: "view-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "view-section-title"
  }, "Class Assignment"), teacher.class_name ? /*#__PURE__*/React.createElement("span", {
    className: "class-badge",
    style: {
      background: classColor,
      padding: '6px 16px',
      fontSize: '14px',
      borderRadius: '8px'
    }
  }, teacher.class_name) : /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#94A3B8',
      fontSize: '14px'
    }
  }, "Not assigned to any class"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 28px 24px',
      display: 'flex',
      gap: '12px',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-cancel",
    onClick: onClose
  }, "Close"), /*#__PURE__*/React.createElement("button", {
    className: "btn-submit",
    onClick: onEdit
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  }), " Edit Teacher"))));
}

// ── FORM MODAL (Add / Edit) ────────────────────────────────────────────
function TeacherFormModal(props) {
  var mode = props.mode;
  var teacher = props.teacher;
  var onClose = props.onClose;
  var onSave = props.onSave;
  var fileRef = useRef(null);
  var emptyForm = {
    full_name: '',
    email: '',
    phone: '',
    password: '',
    status: 'active',
    class_id: '',
    subject_ids: []
  };
  var initForm = function () {
    if (mode === 'edit' && teacher) {
      var sids = [];
      if (teacher.subject_ids) {
        sids = teacher.subject_ids.toString().split(',').filter(function (s) {
          return s.trim() !== '';
        });
      }
      return {
        full_name: teacher.full_name || '',
        email: teacher.email || '',
        phone: teacher.phone || '',
        password: '',
        status: teacher.status || 'active',
        class_id: teacher.class_id ? teacher.class_id.toString() : '',
        subject_ids: sids
      };
    }
    return emptyForm;
  };
  var stateInit = useState(initForm);
  var formData = stateInit[0];
  var setFormData = stateInit[1];
  var photoState = useState(null);
  var photoFile = photoState[0];
  var setPhotoFile = photoState[1];
  var previewState = useState(teacher && teacher.photo_url ? teacher.photo_url : null);
  var photoPreview = previewState[0];
  var setPhotoPreview = previewState[1];
  var savingState = useState(false);
  var saving = savingState[0];
  var setSaving = savingState[1];
  var subjectsState = useState([]);
  var subjects = subjectsState[0];
  var setSubjects = subjectsState[1];
  var classesState = useState([]);
  var classes = classesState[0];
  var setClasses = classesState[1];
  var errorState = useState({});
  var errors = errorState[0];
  var setErrors = errorState[1];
  var formErrorState = useState('');
  var formError = formErrorState[0];
  var setFormError = formErrorState[1];

  // Load subjects and classes when modal opens
  useEffect(function () {
    var teacherId = mode === 'edit' && teacher ? teacher.id : '';
    var classUrl = '/nsms/api/teachers.php?action=classes' + (teacherId ? '&teacher_id=' + teacherId : '');
    fetch('/nsms/api/teachers.php?action=subjects').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setSubjects(d.data || []);
    }).catch(function () {});
    fetch(classUrl).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setClasses(d.data || []);
    }).catch(function () {});
  }, []);
  var handlePhotoChange = function (e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    setPhotoFile(file);
    var reader = new FileReader();
    reader.onload = function (ev) {
      setPhotoPreview(ev.target.result);
    };
    reader.readAsDataURL(file);
  };
  var toggleSubject = function (sid) {
    var sids = formData.subject_ids.slice();
    var idx = sids.indexOf(sid);
    if (idx > -1) {
      sids.splice(idx, 1);
    } else {
      sids.push(sid);
    }
    setFormData(Object.assign({}, formData, {
      subject_ids: sids
    }));
  };
  var validate = function () {
    var errs = {};
    try {
      var name = (formData.full_name || '').trim();
      var email = (formData.email || '').trim().toLowerCase();
      var phone = (formData.phone || '').trim();
      if (!name) {
        errs.full_name = 'Full name is required';
      } else if (name.length < 2) {
        errs.full_name = 'Full name is too short';
      } else if (!/^[A-Za-z\u00C0-\u024F\u1E00-\u1EFF][A-Za-z\u00C0-\u024F\u1E00-\u1EFF\s'.\-]*$/.test(name)) {
        errs.full_name = 'Full name may only contain letters and common name characters';
      }
      if (!email) {
        errs.email = 'Email is required';
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errs.email = 'Please enter a valid email address';
      }
      if (!phone) {
        errs.phone = 'Phone number is required';
      } else if (!/^\+?[0-9]+$/.test(phone)) {
        errs.phone = 'Phone may only contain digits and an optional + at the start';
      } else {
        var digits = phone.replace(/\D+/g, '');
        if (digits.length < 9 || digits.length > 15) {
          errs.phone = 'Enter a valid phone number (9–15 digits)';
        }
        if ((phone.match(/\+/g) || []).length > 1 || phone.indexOf('+') > 0) {
          errs.phone = 'Phone may only have + at the beginning';
        }
      }
    } catch (e) {
      console.error('Teacher form validate error:', e);
      errs.full_name = errs.full_name || 'Please check the form fields';
    }
    setErrors(errs);
    var keys = Object.keys(errs);
    if (!keys.length) {
      setFormError('');
      return { ok: true, message: '' };
    }
    var order = ['full_name', 'email', 'phone'];
    var parts = [];
    order.forEach(function (k) { if (errs[k]) parts.push(errs[k]); });
    keys.forEach(function (k) { if (order.indexOf(k) < 0 && errs[k]) parts.push(errs[k]); });
    var message = parts.join(' · ');
    setFormError(message);
    return { ok: false, message: message };
  };
  var handleSubmit = function () {
    var result = validate();
    if (!result || !result.ok) {
      try {
        var bad = document.querySelector('.form-modal input.error, .form-modal .error-msg');
        if (bad && bad.scrollIntoView) bad.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } catch (e) {}
      return;
    }
    setFormError('');
    setSaving(true);
    var fd = new FormData();
    fd.append('full_name', formData.full_name.trim());
    fd.append('email', formData.email.trim().toLowerCase());
    // Normalize phone: keep leading + and digits only
    var phoneNorm = (formData.phone || '').trim().replace(/[^\d+]/g, '');
    if (phoneNorm.indexOf('+') > 0) phoneNorm = phoneNorm.replace(/\+/g, '');
    if ((phoneNorm.match(/\+/g) || []).length > 1) phoneNorm = '+' + phoneNorm.replace(/\+/g, '');
    fd.append('phone', phoneNorm);
    fd.append('status', formData.status || 'active');
    if (formData.class_id) fd.append('class_id', formData.class_id);
    (formData.subject_ids || []).forEach(function (sid) {
      fd.append('subject_ids[]', sid);
    });
    if (mode === 'edit' && teacher) {
      fd.append('id', teacher.id);
    } else {
      fd.append('password', formData.password || 'teacher123');
    }
    if (photoFile) fd.append('photo', photoFile);
    var url = mode === 'add' ? '/nsms/api/teachers.php?action=create' : '/nsms/api/teachers.php?action=update';
    fetch(url, {
      method: 'POST',
      body: fd,
      credentials: 'same-origin',
      headers: { 'Accept': 'application/json' }
    }).then(function (r) {
      return r.text().then(function (text) {
        var data;
        try {
          data = JSON.parse(text);
        } catch (e) {
          console.error('Non-JSON teacher save response:', text.slice(0, 400));
          throw new Error('Server returned an invalid response. Check PHP errors.');
        }
        return data;
      });
    }).then(function (data) {
      if (data.success) {
        if (data.data && data.data.photo_warning) {
          onSave(data.message || 'Teacher saved', data.data.photo_warning);
        } else if (data.data && data.data.photo_url) {
          setPhotoPreview(data.data.photo_url);
          onSave(data.message || 'Teacher saved');
        } else {
          onSave(data.message || 'Teacher saved');
        }
      } else {
        setErrors(Object.assign({}, errors, {
          email: data.error && /email/i.test(data.error) ? data.error : errors.email,
          phone: data.error && /phone/i.test(data.error) ? data.error : errors.phone,
          full_name: data.error && /name/i.test(data.error) ? data.error : errors.full_name
        }));
        setFormError(data.error || 'Could not save teacher');
        alert(data.error || 'Could not save teacher');
      }
    }).catch(function (err) {
      console.error('Save error:', err);
      setFormError(err.message || 'Failed to save teacher. Check console for details.');
      alert(err.message || 'Failed to save teacher. Check console for details.');
    }).finally(function () {
      setSaving(false);
    });
  };
  var setField = function (key, val) {
    setFormData(Object.assign({}, formData, {
      [key]: val
    }));
    if (errors[key]) setErrors(Object.assign({}, errors, {
      [key]: null
    }));
    if (formError) setFormError('');
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "modal-overlay",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-modal",
    onClick: function (e) {
      e.stopPropagation();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-modal-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "form-modal-title"
  }, mode === 'add' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 16
  }), "Add New Teacher") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 16
  }), "Edit Teacher")), /*#__PURE__*/React.createElement("button", {
    className: "modal-close-btn",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "form-modal-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-section-title"
  }, "Passport Photo"), /*#__PURE__*/React.createElement("div", {
    className: "photo-upload-wrap"
  }, photoPreview ? /*#__PURE__*/React.createElement("img", {
    src: photoPreview,
    alt: "Preview",
    className: "photo-preview"
  }) : /*#__PURE__*/React.createElement("div", {
    className: "photo-preview-placeholder"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC64",
    size: 18
  }), /*#__PURE__*/React.createElement("span", null, "No photo")), /*#__PURE__*/React.createElement("div", {
    className: "photo-upload-info"
  }, /*#__PURE__*/React.createElement("label", {
    className: "photo-upload-btn"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF7",
    size: 18
  }), " ", photoPreview ? 'Change Photo' : 'Upload Photo', /*#__PURE__*/React.createElement("input", {
    type: "file",
    accept: "image/jpeg,image/png,image/webp",
    style: {
      display: 'none'
    },
    ref: fileRef,
    onChange: handlePhotoChange
  })), /*#__PURE__*/React.createElement("div", {
    className: "photo-hint"
  }, "Passport-sized photo", /*#__PURE__*/React.createElement("br", null), "JPG, PNG or WebP \xB7 Max 5 MB"))), /*#__PURE__*/React.createElement("div", {
    className: "form-section-title"
  }, "Basic Information"), /*#__PURE__*/React.createElement("div", {
    className: "form-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Full Name ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: 'form-input' + (errors.full_name ? ' error' : ''),
    value: formData.full_name,
    onChange: function (e) {
      setField('full_name', e.target.value);
    },
    placeholder: "e.g. Grace Mwangi"
  }), errors.full_name && /*#__PURE__*/React.createElement("div", {
    className: "error-msg"
  }, errors.full_name)), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Phone ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    type: "tel",
    inputMode: "tel",
    autoComplete: "tel",
    className: 'form-input' + (errors.phone ? ' error' : ''),
    value: formData.phone,
    onChange: function (e) {
      var v = e.target.value.replace(/[^\d+]/g, '');
      if (v.indexOf('+') > 0) v = v.replace(/\+/g, '');
      var plus = v.charAt(0) === '+';
      v = (plus ? '+' : '') + v.replace(/\+/g, '');
      setField('phone', v);
    },
    placeholder: "+255712345678"
  }), errors.phone && /*#__PURE__*/React.createElement("div", {
    className: "error-msg"
  }, errors.phone))), /*#__PURE__*/React.createElement("div", {
    className: "form-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Email ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    type: "email",
    className: 'form-input' + (errors.email ? ' error' : ''),
    value: formData.email,
    onChange: function (e) {
      setField('email', e.target.value);
    },
    placeholder: "teacher@school.com"
  }), errors.email && /*#__PURE__*/React.createElement("div", {
    className: "error-msg"
  }, errors.email)), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Status"), /*#__PURE__*/React.createElement("select", {
    className: "form-select",
    value: formData.status,
    onChange: function (e) {
      setField('status', e.target.value);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "active"
  }, "Active"), /*#__PURE__*/React.createElement("option", {
    value: "on_leave"
  }, "On Leave"), /*#__PURE__*/React.createElement("option", {
    value: "inactive"
  }, "Inactive"), /*#__PURE__*/React.createElement("option", {
    value: "suspended"
  }, "Suspended")))), mode === 'add' && /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Password"), /*#__PURE__*/React.createElement("input", {
    type: "password",
    className: "form-input",
    value: formData.password,
    onChange: function (e) {
      setField('password', e.target.value);
    },
    placeholder: "Default: teacher123"
  })), /*#__PURE__*/React.createElement("div", {
    className: "form-section-title"
  }, "Class Assignment"), /*#__PURE__*/React.createElement("div", {
    className: "class-options"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'class-option-none' + (formData.class_id === '' ? ' selected' : ''),
    onClick: function () {
      setField('class_id', '');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDEAB",
    size: 18
  }), " No Class Assigned"), classes.map(function (cls) {
    var isTaken = cls.teacher_id && cls.teacher_id.toString() !== (teacher ? teacher.id.toString() : '');
    var isSelected = formData.class_id === cls.id.toString();
    return /*#__PURE__*/React.createElement("div", {
      key: cls.id,
      className: 'class-option' + (isSelected ? ' selected' : '') + (isTaken ? ' taken' : ''),
      style: isSelected ? {
        borderColor: cls.class_color,
        background: cls.class_color + '18'
      } : {},
      onClick: function () {
        if (!isTaken) setField('class_id', cls.id.toString());
      },
      title: isTaken ? 'Assigned to ' + cls.assigned_teacher_name : ''
    }, /*#__PURE__*/React.createElement("div", {
      className: "class-dot",
      style: {
        background: cls.class_color
      }
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "class-option-name"
    }, cls.class_name), isTaken && /*#__PURE__*/React.createElement("div", {
      className: "class-option-note"
    }, "Taken")));
  })), /*#__PURE__*/React.createElement("div", {
    className: "form-section-title"
  }, "Subjects Teaching"), subjects.length === 0 ? /*#__PURE__*/React.createElement("p", {
    style: {
      color: '#94A3B8',
      fontSize: '14px'
    }
  }, "Loading subjects...") : /*#__PURE__*/React.createElement("div", {
    className: "subjects-grid"
  }, subjects.map(function (sub) {
    var checked = formData.subject_ids.indexOf(sub.id.toString()) > -1 || formData.subject_ids.indexOf(sub.id) > -1;
    return /*#__PURE__*/React.createElement("div", {
      key: sub.id,
      className: 'subject-check-item' + (checked ? ' checked' : ''),
      onClick: function () {
        toggleSubject(sub.id.toString());
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      checked: checked,
      onChange: function () {},
      onClick: function (e) {
        e.stopPropagation();
        toggleSubject(sub.id.toString());
      }
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "subject-check-label"
    }, sub.subject_name), /*#__PURE__*/React.createElement("div", {
      className: "subject-check-code"
    }, sub.subject_code)));
  }))), formError ? /*#__PURE__*/React.createElement("div", {
    className: "form-error-banner",
    role: "alert",
    style: {
      margin: '8px 20px 12px',
      padding: '12px 14px',
      borderRadius: 10,
      background: '#FEF2F2',
      border: '1px solid #FECACA',
      color: '#991B1B',
      fontSize: 13,
      fontWeight: 600,
      lineHeight: 1.45
    }
  }, formError) : null, /*#__PURE__*/React.createElement("div", {
    className: "form-modal-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-cancel",
    onClick: onClose,
    disabled: saving
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "btn-submit",
    onClick: handleSubmit,
    disabled: saving
  }, saving ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F3",
    size: 16
  }), "Saving...") : mode === 'add' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 16
  }), "Add Teacher") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCBE",
    size: 16
  }), "Save Changes")))));
}

// ── MAIN PAGE ──────────────────────────────────────────────────────────
function TeachersPage() {
  var sidebarState = useState(false);
  var sidebarOpen = sidebarState[0];
  var setSidebarOpen = sidebarState[1];
  var teachersState = useState([]);
  var teachers = teachersState[0];
  var setTeachers = teachersState[1];
  var loadingState = useState(true);
  var loading = loadingState[0];
  var setLoading = loadingState[1];
  var modalState = useState(null); // null | 'view' | 'add' | 'edit'
  var modal = modalState[0];
  var setModal = modalState[1];
  var selectedState = useState(null);
  var selected = selectedState[0];
  var setSelected = selectedState[1];
  var searchState = useState('');
  var search = searchState[0];
  var setSearch = searchState[1];
  var toastState = useState(null);
  var toast = toastState[0];
  var setToast = toastState[1];
  var loadTeachers = async function () {
    setLoading(true);
    fetch('/nsms/api/teachers.php?action=list').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setTeachers(d.data || []);
    }).catch(function (err) {
      console.error('Load error:', err);
    }).finally(function () {
      setLoading(false);
    });
  };
  useEffect(function () {
    loadTeachers();
  }, []);
  var handleView = async function (teacher) {
    // Fetch full details for view modal
    fetch('/nsms/api/teachers.php?action=get&id=' + teacher.id).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setSelected(d.data);
        setModal('view');
      } else {
        setSelected(teacher);
        setModal('view');
      }
    }).catch(function () {
      setSelected(teacher);
      setModal('view');
    });
  };
  var handleEdit = async function (teacher) {
    setSelected(teacher);
    setModal('edit');
  };
  var handleResetPassword = async function (teacher) {
    if (!teacher || !teacher.id) return;
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Reset password?', message: 'Reset password for ' + teacher.full_name + '?\n\nThey will receive a temporary password by email and must activate again. No class data will be lost.', confirmLabel: 'Reset password', variant: 'warn' }) : Promise.resolve(false)))) return;
    fetch('/nsms/api/teachers.php?action=reset_password', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        id: teacher.id
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        var msg = d.message || 'Password reset';
        if (d.data && d.data.reset_url && !d.data.email_sent) {
          msg += ' Link: ' + d.data.reset_url;
        } else if (d.data && d.data.temp_password && !d.data.email_sent) {
          msg += ' Temporary password: ' + d.data.temp_password;
        }
        showToast(msg, 'success', setToast);
      } else {
        showToast(d.error || 'Reset failed', 'error', setToast);
      }
    }).catch(function () {
      showToast('Network error', 'error', setToast);
    });
  };
  var handleDelete = function (teacher) {
    if (!confirm('Remove ' + teacher.full_name + ' from the system?\n(This marks them as inactive.)')) return;
    fetch('/nsms/api/teachers.php?action=delete', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        id: teacher.id
      })
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        showToast(d.message || 'Teacher removed', 'success', setToast);
        loadTeachers();
      } else {
        showToast(d.error || 'Error removing teacher', 'error', setToast);
      }
    }).catch(function () {
      showToast('Network error', 'error', setToast);
    });
  };
  var handleSave = function (msg, photoWarning) {
    setModal(null);
    setSelected(null);
    showToast(msg || 'Saved successfully', 'success', setToast);
    if (photoWarning) {
      // Delay the warning toast slightly so both are visible
      setTimeout(function () {
        showToast('⚠️ ' + photoWarning, 'error', setToast);
      }, 400);
    }
    loadTeachers();
  };

  // Stats
  var active = teachers.filter(function (t) {
    return t.status === 'active';
  }).length;
  var onLeave = teachers.filter(function (t) {
    return t.status === 'on_leave';
  }).length;
  var ratings = teachers.filter(function (t) {
    return t.avg_rating;
  }).map(function (t) {
    return parseFloat(t.avg_rating);
  });
  var avgAll = ratings.length > 0 ? (ratings.reduce(function (a, b) {
    return a + b;
  }, 0) / ratings.length).toFixed(1) : '—';

  // Search filter
  var displayed = search.trim() === '' ? teachers : teachers.filter(function (t) {
    var q = search.toLowerCase();
    return t.full_name && t.full_name.toLowerCase().indexOf(q) > -1 || t.email && t.email.toLowerCase().indexOf(q) > -1 || t.class_name && t.class_name.toLowerCase().indexOf(q) > -1 || t.subjects && t.subjects.toLowerCase().indexOf(q) > -1;
  });
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NSMSNavbar, {
    activePage: "teachers",
    onLogout: function () {
      fetch('/nsms/api/auth.php?action=logout', {
        method: 'POST'
      }).finally(function () {
        window.location.href = '/nsms/public/index.html';
      });
    },
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement(NSMSSidebar, {
    activePage: "teachers",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "nsms-main",
    style: {
      marginLeft: sidebarOpen ? '220px' : '64px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-title-section"
  }, /*#__PURE__*/React.createElement("h1", null, "Teacher Management"), /*#__PURE__*/React.createElement("p", {
    className: "page-subtitle"
  }, "Manage staff, class assignments and subjects")), /*#__PURE__*/React.createElement("button", {
    className: "add-btn",
    onClick: function () {
      setSelected(null);
      setModal('add');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 18
  }), " Add New Teacher")), /*#__PURE__*/React.createElement("div", {
    className: "stats-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-card blue"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, teachers.length), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Total Teachers")), /*#__PURE__*/React.createElement("div", {
    className: "stat-card green"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, active), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Active")), /*#__PURE__*/React.createElement("div", {
    className: "stat-card orange"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, onLeave), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "On Leave")), /*#__PURE__*/React.createElement("div", {
    className: "stat-card purple"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat-value"
  }, avgAll), /*#__PURE__*/React.createElement("div", {
    className: "stat-label"
  }, "Avg Rating"))), /*#__PURE__*/React.createElement("div", {
    className: "table-container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "table-toolbar"
  }, /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "search-box",
    placeholder: "Search by name, class, subject...",
    value: search,
    onChange: function (e) {
      setSearch(e.target.value);
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '13px',
      color: '#94A3B8'
    }
  }, displayed.length, " teacher", displayed.length !== 1 ? 's' : '')), loading ? /*#__PURE__*/React.createElement("div", {
    className: "loading"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F3",
    size: 18
  }), " Loading teachers...") : displayed.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty-state"
  }, /*#__PURE__*/React.createElement("div", {
    className: "empty-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC68\u200D\uD83C\uDFEB",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, search ? 'No teachers match your search.' : 'No teachers yet. Add one to get started.')) : /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Teacher"), /*#__PURE__*/React.createElement("th", null, "Class"), /*#__PURE__*/React.createElement("th", null, "Subjects"), /*#__PURE__*/React.createElement("th", null, "Rating"), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", null, "Actions"))), /*#__PURE__*/React.createElement("tbody", null, displayed.map(function (t) {
    return /*#__PURE__*/React.createElement("tr", {
      key: t.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "teacher-cell"
    }, /*#__PURE__*/React.createElement("div", {
      className: "teacher-avatar",
      style: {
        background: getAvatarColor(t.full_name)
      }
    }, t.photo_url ? /*#__PURE__*/React.createElement("img", {
      src: t.photo_url,
      alt: t.full_name
    }) : getInitials(t.full_name)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "teacher-name"
    }, t.full_name), /*#__PURE__*/React.createElement("div", {
      className: "teacher-email"
    }, t.email)))), /*#__PURE__*/React.createElement("td", null, t.class_name ? /*#__PURE__*/React.createElement("span", {
      className: "class-badge",
      style: {
        background: t.class_color || '#94A3B8'
      }
    }, t.class_name) : /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#CBD5E1',
        fontSize: '12px'
      }
    }, "Unassigned")), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "subjects-text"
    }, t.subjects || /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#CBD5E1'
      }
    }, "\u2014"))), /*#__PURE__*/React.createElement("td", null, t.avg_rating ? /*#__PURE__*/React.createElement("div", null, renderStars(t.avg_rating, false), /*#__PURE__*/React.createElement("span", {
      className: "stars-count"
    }, t.avg_rating)) : /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#CBD5E1',
        fontSize: '12px'
      }
    }, "No rating")), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
      className: 'status-badge status-' + t.status
    }, statusLabel(t.status))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
      className: "action-buttons"
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn btn-view",
      onClick: function () {
        handleView(t);
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDC41",
      size: 18
    }), " View"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-edit",
      onClick: function () {
        handleEdit(t);
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u270F\uFE0F",
      size: 18
    }), " Edit"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-reset",
      title: "Reset password",
      onClick: function () {
        handleResetPassword(t);
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD11",
      size: 18
    }), " Reset"), /*#__PURE__*/React.createElement("button", {
      className: "btn btn-delete",
      onClick: function () {
        handleDelete(t);
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDDD1",
      size: 18
    })))));
  }))))), modal === 'view' && /*#__PURE__*/React.createElement(ViewModal, {
    teacher: selected,
    onClose: function () {
      setModal(null);
      setSelected(null);
    },
    onEdit: function () {
      setModal('edit');
    }
  }), (modal === 'add' || modal === 'edit') && /*#__PURE__*/React.createElement(TeacherFormModal, {
    mode: modal,
    teacher: selected,
    onClose: function () {
      setModal(null);
      setSelected(null);
    },
    onSave: handleSave
  }), toast && /*#__PURE__*/React.createElement("div", {
    className: 'toast ' + toast.type
  }, toast.msg));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(TeachersPage, null));