function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState,
  useEffect,
  useCallback,
  useRef
} = React;

/* ── Constants ── */
const TYPE_CFG = {
  daily: {
    label: 'Daily',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCC5",
      size: 20
    }),
    desc: 'Daily assignment report',
    color: 'daily'
  },
  weekly: {
    label: 'Weekly',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDDD3",
      size: 20
    }),
    desc: 'Weekly progress report',
    color: 'weekly'
  },
  midterm: {
    label: 'Mid-term',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCCA",
      size: 20
    }),
    desc: 'Mid-term assessment report',
    color: 'midterm'
  },
  terminal: {
    label: 'Terminal',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF93",
      size: 20
    }),
    desc: 'End-of-term report',
    color: 'terminal'
  }
};
const TRAIT_OPTIONS = ['Excellent', 'Very Good', 'Good', 'Fair', 'Needs Improvement', 'Poor'];
const RATING_OPTIONS = ['Excellent', 'Very Good', 'Good', 'Fair', 'Needs Improvement', 'Poor'];

/* ── Period options per type ── */
function getPeriodOptions(type, terms) {
  if (type === 'daily') return null; // date picker
  if (type === 'weekly') return Array.from({
    length: 20
  }, (_, i) => `Week ${i + 1}`).map(w => ({
    label: w,
    value: w
  }));
  if (type === 'midterm') return [{
    label: 'Midterm 1',
    value: 'Midterm 1'
  }, {
    label: 'Midterm 2',
    value: 'Midterm 2'
  }];
  if (type === 'terminal') return (terms || []).map(t => ({
    label: t,
    value: t
  }));
  return null;
}

/* ── Helpers ── */
const AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2'];
const avColor = n => n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
const initials = n => n ? n.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) : '?';
function gradeClass(g) {
  return {
    A: 'gd-a',
    B: 'gd-b',
    C: 'gd-c',
    D: 'gd-d',
    E: 'gd-e',
    F: 'gd-f'
  }[g] || 'gd-none';
}
function histTypeClass(t) {
  return {
    daily: 'ht-daily',
    weekly: 'ht-weekly',
    midterm: 'ht-midterm',
    terminal: 'ht-terminal'
  }[t] || 'ht-daily';
}
async function api(path, params, method = 'GET', body = null) {
  const qs = method === 'GET' && params && Object.keys(params).length > 0 ? '?' + new URLSearchParams(params) : '';
  const url = path + qs;
  const opts = {
    method,
    headers: {
      'Content-Type': 'application/json'
    },
    credentials: 'include'
  };
  if (method === 'POST' && body) opts.body = JSON.stringify(body);
  const r = await fetch(url, opts);
  const text = await r.text();
  try {
    return JSON.parse(text);
  } catch {
    const s = text.indexOf('{');
    if (s > 0) {
      try {
        return JSON.parse(text.slice(s));
      } catch {}
    }
    throw new Error('Server error: ' + text.slice(0, 200));
  }
}
const gbApi = (p, m, b) => api('/nsms/api/gradebook.php', p, m, b);
const rpApi = (p, m, b) => api('/nsms/api/teacher-reports.php', p, m, b);

/* ── Alert ── */
function Alert({
  type,
  msg,
  onClose
}) {
  if (!msg) return null;
  const icon = type === 'success' ? '✅' : type === 'info' ? 'ℹ️' : /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0",
    size: 16
  });
  return /*#__PURE__*/React.createElement("div", {
    className: `alert alert-${type}`
  }, /*#__PURE__*/React.createElement("span", null, icon), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, msg), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'inherit',
      fontSize: 16
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  })));
}

/* ── Student avatar ── */
function SAv({
  student,
  size = 34
}) {
  const [err, setErr] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "s-av",
    style: {
      width: size,
      height: size,
      background: avColor(student.student_name || student.name)
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      zIndex: 1,
      fontSize: size * 0.35
    }
  }, initials(student.student_name || student.name)), student.photo_url && !err && /*#__PURE__*/React.createElement("img", {
    src: student.photo_url,
    alt: "",
    onError: () => setErr(true)
  }));
}

/* ════════════════════════════════
REPORT EDITOR
════════════════════════════════ */
function ReportEditor({
  student,
  terms,
  academicYear,
  onPublished,
  prefillReportId
}) {
  /* Step control */
  const [step, setStep] = useState('type'); // type → period → edit → done
  const [reportType, setReportType] = useState('');
  const [periodLabel, setPeriodLabel] = useState('');
  const [periodDate, setPeriodDate] = useState(''); // for daily date picker

  /* Grades */
  const [loadingGrades, setLoadingGrades] = useState(false);
  const [subjectData, setSubjectData] = useState({});
  const [hasGrades, setHasGrades] = useState(false);
  const [existingReportId, setExistingReportId] = useState(null);
  const [isPublished, setIsPublished] = useState(false);
  const [classPosition, setClassPosition] = useState(null);
  const [needsReview, setNeedsReview] = useState(false);
  const [reviewStatus, setReviewStatus] = useState(null);
  const [reviewNote, setReviewNote] = useState('');

  /* Form */
  const [term, setTerm] = useState(terms[0] || '');
  const [conduct, setConduct] = useState('');
  const [punctuality, setPunctuality] = useState('');
  const [neatness, setNeatness] = useState('');
  const [classPartic, setClassPartic] = useState('');
  const [socialSkills, setSocialSkills] = useState('');
  const [comments, setComments] = useState('');
  const [recommendations, setRecommendations] = useState('');
  const [promoStatus, setPromoStatus] = useState('');
  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [alert, setAlert] = useState(null);

  /* If a prefill report_id was passed (loaded existing report) */
  useEffect(() => {
    if (!prefillReportId) return;
    rpApi({
      action: 'existing_report',
      id: prefillReportId
    }).then(d => {
      if (!d.success) return;
      const r = d.data.report;
      setReportType(r.report_type);
      setPeriodLabel(r.period_label);
      setTerm(r.term);
      setSubjectData(r.subject_data || {});
      setHasGrades(Object.keys(r.subject_data || {}).length > 0);
      setConduct(r.conduct || '');
      setPunctuality(r.punctuality || '');
      setNeatness(r.neatness || '');
      setClassPartic(r.class_participation || '');
      setSocialSkills(r.social_skills || '');
      setComments(r.teacher_comments || '');
      setRecommendations(r.recommendations || '');
      setPromoStatus(r.promotion_status || '');
      setExistingReportId(r.id);
      setIsPublished(!!r.is_published);
      setStep('edit');
    });
  }, [prefillReportId]);

  /* Reset when student changes */
  useEffect(() => {
    setStep('type');
    setReportType('');
    setPeriodLabel('');
    setSubjectData({});
    setHasGrades(false);
    setExistingReportId(null);
    setIsPublished(false);
    setClassPosition(null);
    setNeedsReview(false);
    setReviewStatus(null);
    setReviewNote('');
    setAlert(null);
    setConduct('');
    setPunctuality('');
    setNeatness('');
    setClassPartic('');
    setSocialSkills('');
    setComments('');
    setRecommendations('');
    setPromoStatus('');
  }, [student?.id]);

  /* Load grades when type+period+term are chosen */
  function loadDraftFromGrades(rtype, pl, t) {
    if (!student || !pl || !t) return;
    setLoadingGrades(true);
    setAlert(null);
    rpApi({
      action: 'draft_from_grades',
      student_id: student.id,
      term: t,
      academic_year: academicYear,
      report_type: rtype,
      period_label: pl
    }).then(d => {
      if (!d.success) {
        setAlert({
          type: 'error',
          msg: d.error
        });
        return;
      }
      setSubjectData(d.data.subject_data || {});
      setHasGrades(d.data.has_grades || false);
      setExistingReportId(d.data.existing_report_id);
      setIsPublished(d.data.is_published || false);
      setClassPosition(d.data.class_position || null);
      setReviewStatus(null);
      setReviewNote('');
      setNeedsReview(false);
      /* If existing draft, load its narrative fields too */
      if (d.data.existing_report_id && !d.data.is_published) {
        rpApi({
          action: 'existing_report',
          id: d.data.existing_report_id
        }).then(rd => {
          if (!rd.success) return;
          const r = rd.data.report;
          setConduct(r.conduct || '');
          setPunctuality(r.punctuality || '');
          setNeatness(r.neatness || '');
          setClassPartic(r.class_participation || '');
          setSocialSkills(r.social_skills || '');
          setComments(r.teacher_comments || '');
          setRecommendations(r.recommendations || '');
          setPromoStatus(r.promotion_status || '');
          setReviewStatus(r.review_status || null);
          setReviewNote(r.review_note || '');
          setNeedsReview(r.review_status === 'pending');
        });
      }
      setStep('edit');
    }).catch(e => setAlert({
      type: 'error',
      msg: e.message
    })).finally(() => setLoadingGrades(false));
  }
  async function handleSelectType(t) {
    setReportType(t);
    if (t === 'terminal') {
      setPeriodLabel(term);
      setStep('edit_loading');
    } else setStep('period');
  }
  async function handleSelectPeriod(pl) {
    setPeriodLabel(pl);
    loadDraftFromGrades(reportType, pl, term);
  }

  /* Edit loading effect */
  useEffect(() => {
    if (step === 'edit_loading' && reportType === 'terminal' && periodLabel && term) {
      loadDraftFromGrades(reportType, periodLabel, term);
    }
  }, [step]);
  async function buildPayload(extra = {}) {
    return {
      student_id: student.id,
      report_type: reportType,
      period_label: periodLabel,
      term,
      academic_year: academicYear,
      report_date: new Date().toISOString().slice(0, 10),
      subject_data: subjectData,
      conduct,
      punctuality,
      neatness,
      class_participation: classPartic,
      social_skills: socialSkills,
      teacher_comments: comments,
      recommendations,
      promotion_status: reportType === 'terminal' ? promoStatus : null,
      ...extra
    };
  }
  async function handleSave() {
    if (!academicYear) {
      setAlert({
        type: 'error',
        msg: 'Academic year not loaded yet. Please wait a moment and try again.'
      });
      return;
    }
    setSaving(true);
    setAlert(null);
    try {
      const d = await rpApi(null, 'POST', {
        action: 'save_report',
        ...buildPayload()
      });
      if (d.success) {
        setAlert({
          type: 'success',
          msg: /*#__PURE__*/React.createElement("span", {
            style: {
              display: "inline-flex",
              alignItems: "center",
              gap: 6
            }
          }, /*#__PURE__*/React.createElement(Icon, {
            emoji: "\uD83D\uDCBE",
            size: 16
          }), "Draft saved.")
        });
        setExistingReportId(d.data.report_id);
      } else setAlert({
        type: 'error',
        msg: d.error || 'Save failed.'
      });
    } catch (e) {
      setAlert({
        type: 'error',
        msg: e.message
      });
    } finally {
      setSaving(false);
    }
  }
  async function handlePublish() {
    if (!academicYear) {
      setAlert({
        type: 'error',
        msg: 'Academic year not loaded yet. Please wait a moment and try again.'
      });
      return;
    }
    if (!comments.trim()) {
      setAlert({
        type: 'error',
        msg: 'Please add teacher comments before publishing.'
      });
      return;
    }
    const isReviewed = reportType === 'midterm' || reportType === 'terminal';
    const confirmMsg = isReviewed ? 'Submit this report for admin review? It will be sent to the parent once approved.' : 'Publish this report? It will be visible to the parent immediately.';
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ message: confirmMsg, variant: 'warn' }) : Promise.resolve(false)))) return;
    setPublishing(true);
    setAlert(null);
    try {
      const d = await rpApi(null, 'POST', {
        action: 'publish_report',
        ...buildPayload()
      });
      if (d.success) {
        setNeedsReview(!!d.data.needs_review);
        setIsPublished(!d.data.needs_review);
        setStep('done');
        onPublished && onPublished();
      } else setAlert({
        type: 'error',
        msg: d.error || 'Publish failed.'
      });
    } catch (e) {
      setAlert({
        type: 'error',
        msg: e.message
      });
    } finally {
      setPublishing(false);
    }
  }
  function updateSubjectRating(subName, field, value) {
    setSubjectData(prev => ({
      ...prev,
      [subName]: {
        ...prev[subName],
        [field]: value
      }
    }));
  }

  /* ── Render steps ── */
  if (!student) return null;

  /* Step: type selection */
  if (step === 'type') return /*#__PURE__*/React.createElement("div", {
    className: "card editor-wrap",
    style: {
      overflow: 'visible'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDD",
    size: 18
  }), " New Report \u2014 ", student.student_name), /*#__PURE__*/React.createElement("div", {
    className: "card-sub"
  }, "Select report type to begin")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-soft)'
    }
  }, "Term:"), /*#__PURE__*/React.createElement("select", {
    className: "trait-select",
    style: {
      fontSize: 13,
      padding: '6px 10px'
    },
    value: term,
    onChange: e => setTerm(e.target.value)
  }, terms.map(t => /*#__PURE__*/React.createElement("option", {
    key: t,
    value: t
  }, t))))), /*#__PURE__*/React.createElement("div", {
    className: "card-body"
  }, alert && /*#__PURE__*/React.createElement(Alert, _extends({}, alert, {
    onClose: () => setAlert(null)
  })), /*#__PURE__*/React.createElement("div", {
    className: "type-grid"
  }, Object.entries(TYPE_CFG).map(([k, v]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    className: `type-btn sel-${k}`,
    onClick: () => handleSelectType(k)
  }, /*#__PURE__*/React.createElement("div", {
    className: "type-icon"
  }, v.icon), /*#__PURE__*/React.createElement("span", {
    className: "type-name"
  }, v.label), /*#__PURE__*/React.createElement("span", {
    className: "type-desc"
  }, v.desc))))));

  /* Step: period selection */
  if (step === 'period') {
    const opts = getPeriodOptions(reportType, terms);
    return /*#__PURE__*/React.createElement("div", {
      className: "card"
    }, /*#__PURE__*/React.createElement("div", {
      className: "card-header"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "card-title"
    }, TYPE_CFG[reportType].icon, ' ', TYPE_CFG[reportType].label, " Report \u2014 Select Period"), /*#__PURE__*/React.createElement("div", {
      className: "card-sub"
    }, student.student_name)), /*#__PURE__*/React.createElement("button", {
      className: "btn-primary btn-ghost",
      style: {
        fontSize: 12
      },
      onClick: () => setStep('type')
    }, "\u2190 Back")), /*#__PURE__*/React.createElement("div", {
      className: "card-body"
    }, alert && /*#__PURE__*/React.createElement(Alert, _extends({}, alert, {
      onClose: () => setAlert(null)
    })), reportType === 'daily' ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
      className: "form-label"
    }, "Select Date"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "period-input",
      value: periodDate,
      onChange: e => {
        setPeriodDate(e.target.value);
        if (e.target.value) {
          const d = new Date(e.target.value + 'T12:00:00');
          const lbl = d.toLocaleDateString('en-GB', {
            weekday: 'short',
            day: '2-digit',
            month: 'short',
            year: 'numeric'
          });
          handleSelectPeriod(lbl);
        }
      }
    }), loadingGrades && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginTop: 14,
        color: 'var(--text-soft)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "spinner",
      style: {
        width: 18,
        height: 18,
        border: '2px solid var(--border)',
        borderTopColor: 'var(--blue)'
      }
    }), "Loading grades\u2026")) : /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
      className: "form-label"
    }, "Select", ' ', reportType === 'weekly' ? 'Week' : reportType === 'midterm' ? 'Midterm Period' : 'Term'), /*#__PURE__*/React.createElement("div", {
      className: "period-row"
    }, opts && opts.map(o => /*#__PURE__*/React.createElement("button", {
      key: o.value,
      className: `period-chip ${periodLabel === o.value ? 'active' : ''}`,
      onClick: () => handleSelectPeriod(o.value),
      disabled: loadingGrades
    }, loadingGrades && periodLabel === o.value ? /*#__PURE__*/React.createElement("span", {
      className: "spinner",
      style: {
        width: 12,
        height: 12,
        border: '2px solid rgba(255,255,255,.4)',
        borderTopColor: 'white',
        display: 'inline-block'
      }
    }) : o.label))))));
  }

  /* Step: loading */
  if (step === 'edit_loading') return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading grades\u2026")));

  /* Step: done */
  if (step === 'done') return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 56
    }
  }, needsReview ? typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📨',
    size: 16
  }) : null : typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: null,
    size: 16
  }) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 17,
      color: 'var(--text-dark)'
    }
  }, needsReview ? 'Submitted for Review!' : 'Report Published!'), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-soft)',
      textAlign: 'center',
      maxWidth: 320
    }
  }, needsReview ? /*#__PURE__*/React.createElement(React.Fragment, null, "The", ' ', /*#__PURE__*/React.createElement("b", null, TYPE_CFG[reportType]?.label), ' ', "report for", ' ', /*#__PURE__*/React.createElement("b", null, student.student_name), " (", periodLabel, ") has been sent to the admin for review. You'll be notified once it's approved and sent to the parent.") : /*#__PURE__*/React.createElement(React.Fragment, null, "The", ' ', /*#__PURE__*/React.createElement("b", null, TYPE_CFG[reportType]?.label), ' ', "report for", ' ', /*#__PURE__*/React.createElement("b", null, student.student_name), " (", periodLabel, ") is now visible to the parent.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-primary btn-ghost",
    onClick: () => setStep('type')
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDD",
    size: 18
  }), " Write Another"))));

  /* Step: edit */
  const subjectEntries = Object.entries(subjectData);
  const typeLabel = TYPE_CFG[reportType]?.label;
  return /*#__PURE__*/React.createElement("div", {
    className: "editor-wrap"
  }, alert && /*#__PURE__*/React.createElement(Alert, _extends({}, alert, {
    onClose: () => setAlert(null)
  })), isPublished && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-info"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD12",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "This report is already ", /*#__PURE__*/React.createElement("b", null, "published"), ". You are viewing a read-only copy. Use \"Write Another\" to create a new one.")), needsReview && !isPublished && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-info",
    style: {
      background: '#FFFBEB',
      borderColor: '#FDE68A'
    }
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u23F3",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "This report was", ' ', /*#__PURE__*/React.createElement("b", null, "submitted for admin review"), " and hasn't reached the parent yet. You can still edit and resubmit it below if needed.")), reviewStatus === 'rejected' && !needsReview && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-error"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", null, "The admin sent this back for changes:"), ' ', "\"", reviewNote, "\" \u2014 update it below and submit again.")), hasGrades && !isPublished && /*#__PURE__*/React.createElement("div", {
    className: "banner-prefill"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 24
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      fontWeight: 700,
      color: '#1E40AF',
      marginBottom: 3
    }
  }, "Grades loaded from Gradebook"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: '#3B82F6'
    }
  }, subjectEntries.length, " subject", subjectEntries.length !== 1 ? 's' : '', ' ', "\xB7 averages auto-filled. Adjust ratings below if needed."))), !hasGrades && !isPublished && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-info"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCA1",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "No published grades found for this period. You can still write a narrative report \u2014 subject ratings will be blank.")), (reportType === 'midterm' || reportType === 'terminal') && classPosition && /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      background: 'linear-gradient(135deg,#1B3D2F,#2D5943)',
      border: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '18px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 32
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFC6",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'rgba(255,255,255,.65)',
      textTransform: 'uppercase',
      letterSpacing: '.5px',
      marginBottom: 2
    }
  }, "Class Position"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 800,
      color: '#fff'
    }
  }, classPosition.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'rgba(255,255,255,.7)',
      marginTop: 2
    }
  }, "Overall average:", ' ', classPosition.overall_average, "% \xB7 ranked among", ' ', classPosition.class_size, ' ', "students with recorded grades")))), (reportType === 'midterm' || reportType === 'terminal') && !classPosition && hasGrades && !isPublished && /*#__PURE__*/React.createElement("div", {
    className: "alert alert-info"
  }, /*#__PURE__*/React.createElement("span", null, "\u2139\uFE0F"), /*#__PURE__*/React.createElement("span", null, "Class position isn't available yet \u2014 it needs published subject performance for other students in this class too.")), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, TYPE_CFG[reportType].icon, " ", typeLabel, ' ', "Report \u2014 ", periodLabel), /*#__PURE__*/React.createElement("div", {
    className: "card-sub"
  }, student.student_name, " \xB7 ", term, " \xB7", ' ', academicYear)), !isPublished && /*#__PURE__*/React.createElement("button", {
    className: "btn-primary btn-ghost",
    style: {
      fontSize: 12
    },
    onClick: () => setStep(reportType === 'terminal' ? 'type' : 'period')
  }, "\u2190 Change Period"))), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  }), " Subject Ratings")), /*#__PURE__*/React.createElement("div", {
    className: "card-body"
  }, subjectEntries.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '24px',
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, "No grades loaded. Add subjects manually below or publish assessments in Gradebook first.") : /*#__PURE__*/React.createElement("div", null, subjectEntries.map(([name, sd]) => /*#__PURE__*/React.createElement("div", {
    key: name,
    className: "subj-row"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "subj-name"
  }, name), /*#__PURE__*/React.createElement("div", {
    className: "subj-code"
  }, sd.subject_code, " \xB7", ' ', sd.average_score !== null ? `${sd.average_score}% avg` : 'No score')), isPublished ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-mid)'
    }
  }, sd.rating || '—') : /*#__PURE__*/React.createElement("select", {
    className: "rating-select",
    value: sd.rating || '',
    onChange: e => updateSubjectRating(name, 'rating', e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "\u2014 Rate \u2014"), RATING_OPTIONS.map(o => /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o))), /*#__PURE__*/React.createElement("span", {
    className: `grade-dot ${gradeClass(sd.grade_letter)}`
  }, sd.grade_letter || '—')))))), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, "\u2B50 Character & Behaviour")), /*#__PURE__*/React.createElement("div", {
    className: "card-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "traits-grid"
  }, [{
    key: 'conduct',
    label: 'Conduct',
    val: conduct,
    set: setConduct
  }, {
    key: 'punctuality',
    label: 'Punctuality',
    val: punctuality,
    set: setPunctuality
  }, {
    key: 'neatness',
    label: 'Neatness',
    val: neatness,
    set: setNeatness
  }, {
    key: 'classPartic',
    label: 'Class Participation',
    val: classPartic,
    set: setClassPartic
  }, {
    key: 'social',
    label: 'Social Skills',
    val: socialSkills,
    set: setSocialSkills
  }].map(t => /*#__PURE__*/React.createElement("div", {
    key: t.key,
    className: "trait-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "trait-label"
  }, t.label), isPublished ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      padding: '8px 11px',
      background: '#F8FAFC',
      borderRadius: 8,
      fontWeight: 600,
      color: 'var(--text-mid)'
    }
  }, t.val || '—') : /*#__PURE__*/React.createElement("select", {
    className: "trait-select",
    value: t.val,
    onChange: e => t.set(e.target.value)
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "\u2014 Select \u2014"), TRAIT_OPTIONS.map(o => /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o)))))))), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCAC",
    size: 18
  }), " Teacher's Narrative")), /*#__PURE__*/React.createElement("div", {
    className: "card-body",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "General Comments *"), isPublished ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      lineHeight: 1.7,
      color: 'var(--text-dark)',
      background: '#F8FAFC',
      padding: '11px 14px',
      borderRadius: 10
    }
  }, comments || '—') : /*#__PURE__*/React.createElement("textarea", {
    className: "textarea",
    value: comments,
    onChange: e => setComments(e.target.value),
    placeholder: `Write your overall assessment of ${student.student_name}'s performance this period…`,
    rows: 4
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "form-label"
  }, "Recommendations"), isPublished ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      lineHeight: 1.7,
      color: 'var(--text-dark)',
      background: '#F8FAFC',
      padding: '11px 14px',
      borderRadius: 10
    }
  }, recommendations || '—') : /*#__PURE__*/React.createElement("textarea", {
    className: "textarea",
    value: recommendations,
    onChange: e => setRecommendations(e.target.value),
    placeholder: "Areas to focus on, suggestions for improvement\u2026",
    rows: 3
  })))), reportType === 'terminal' && /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-title"
  }, "\uD83C\uDF93 Promotion Status")), /*#__PURE__*/React.createElement("div", {
    className: "card-body"
  }, isPublished ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--text-dark)'
    }
  }, promoStatus || 'Not specified') : /*#__PURE__*/React.createElement("div", {
    className: "promo-grid"
  }, [{
    v: 'Promoted',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2B06",
      size: 16
    }),
    cls: 'promoted'
  }, {
    v: 'Repeat',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD01",
      size: 20
    }),
    cls: 'repeat'
  }, {
    v: 'Under Review',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD0D",
      size: 20
    }),
    cls: 'review'
  }].map(p => /*#__PURE__*/React.createElement("button", {
    key: p.v,
    className: `promo-btn ${promoStatus === p.v ? `sel-${p.cls}` : ''}`,
    onClick: () => setPromoStatus(p.v)
  }, /*#__PURE__*/React.createElement("span", {
    className: "promo-icon"
  }, p.icon), /*#__PURE__*/React.createElement("span", {
    className: "promo-name"
  }, p.v)))))), !isPublished && /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "action-row"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-primary btn-ghost",
    onClick: () => setStep('type')
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "btn-primary",
    onClick: handleSave,
    disabled: saving || publishing
  }, saving ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "spinner",
    style: {
      width: 13,
      height: 13,
      border: '2px solid rgba(255,255,255,.4)',
      borderTopColor: 'white'
    }
  }), "Saving\u2026") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCBE",
    size: 16
  }), "Save Draft")), /*#__PURE__*/React.createElement("button", {
    className: "btn-primary btn-publish",
    onClick: handlePublish,
    disabled: publishing || saving
  }, publishing ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "spinner",
    style: {
      width: 13,
      height: 13,
      border: '2px solid rgba(255,255,255,.4)',
      borderTopColor: 'white'
    }
  }), reportType === 'midterm' || reportType === 'terminal' ? 'Submitting…' : 'Publishing…') : reportType === 'midterm' || reportType === 'terminal' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE8",
    size: 16
  }), "Submit for Review") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE4",
    size: 16
  }), "Publish to Parent")))), isPublished && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-primary",
    onClick: () => setStep('type')
  }, "\uD83D\uDCDD Write New Report")));
}

/* ════════════════════════════════
REPORT HISTORY PANEL
════════════════════════════════ */
function ReportHistory({
  student,
  onSelect,
  refresh
}) {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!student) return;
    setLoading(true);
    rpApi({
      action: 'report_list',
      student_id: student.id
    }).then(d => {
      if (d.success) setReports(d.data.reports || []);
    }).catch(() => {}).finally(() => setLoading(false));
  }, [student?.id, refresh]);
  const typeLabel = {
    daily: 'Daily',
    weekly: 'Weekly',
    midterm: 'Mid-term',
    terminal: 'Terminal'
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      position: 'sticky',
      top: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "sidebar-header"
  }, "Report History"), !student ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      fontSize: 12.5,
      color: 'var(--text-muted)',
      textAlign: 'center'
    }
  }, "Select a student") : loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "shimmer"
  }), /*#__PURE__*/React.createElement("div", {
    className: "shimmer",
    style: {
      marginTop: 8,
      width: '70%'
    }
  })) : reports.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      fontSize: 12.5,
      color: 'var(--text-muted)',
      textAlign: 'center'
    }
  }, "No reports yet") : reports.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.id,
    className: "hist-row",
    onClick: () => onSelect && onSelect(r.id)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: `pub-dot ${r.is_published ? 'pd-pub' : 'pd-draft'}`
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: `hist-type ${histTypeClass(r.report_type)}`
  }, typeLabel[r.report_type] || r.report_type), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: r.is_published ? '#059669' : '#D97706',
      fontWeight: 700
    }
  }, r.is_published ? 'Published' : 'Draft')), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-mid)',
      marginTop: 4,
      fontWeight: 600,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, r.period_label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, r.term, " \xB7 ", r.academic_year))))));
}

/* ════════════════════════════════
ROOT
════════════════════════════════ */
function ReportsApp() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [studLoad, setStudLoad] = useState(true);
  const [terms, setTerms] = useState(['Term 1', 'Term 2']);
  const [academicYear, setAcademicYear] = useState('');
  const [histRefresh, setHistRefresh] = useState(0);
  const [prefillReportId, setPrefillReportId] = useState(null);

  /* Boot */
  useEffect(() => {
    Promise.all([rpApi({
      action: 'students'
    }), gbApi({
      action: 'terms'
    })]).then(([sd, td]) => {
      if (sd.success) {
        const stus = sd.data.students || [];
        setStudents(stus);
        if (stus.length > 0) setSelectedStudent(stus[0]);
      }
      if (td.success) {
        setTerms(td.data.terms || ['Term 1', 'Term 2']);
        setAcademicYear(td.data.academic_year || '');
      }
    }).catch(() => {}).finally(() => setStudLoad(false));
  }, []);

  /* Handle report_id in URL for deep-link from notification */
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const rid = params.get('report_id');
    if (rid) setPrefillReportId(parseInt(rid));
  }, []);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(TeacherNavbar, {
    activePage: "reports",
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement(TeacherSidebar, {
    activePage: "reports",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: `main-area ${sidebarOpen ? '' : 'collapsed'}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-title-wrap"
  }, /*#__PURE__*/React.createElement("h1", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC4",
    size: 18
  }), " Reports"), /*#__PURE__*/React.createElement("div", {
    className: "page-sub"
  }, studLoad ? 'Loading…' : `${students.length} students · ${academicYear}`))), studLoad ? /*#__PURE__*/React.createElement("div", {
    className: "state-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("p", null, "Loading\u2026")) : students.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "state-box",
    style: {
      background: 'white',
      borderRadius: 14,
      border: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 52
    }
  }, "\uD83D\uDC65"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700
    }
  }, "No students assigned yet")) : /*#__PURE__*/React.createElement("div", {
    className: "rp-layout"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card rp-side-left"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sidebar-header"
  }, "Students"), students.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.id,
    className: `stu-row ${selectedStudent?.id === s.id ? 'selected' : ''}`,
    onClick: () => {
      setSelectedStudent(s);
      setPrefillReportId(null);
    }
  }, /*#__PURE__*/React.createElement(SAv, {
    student: s,
    size: 30
  }), /*#__PURE__*/React.createElement("span", {
    className: "stu-name"
  }, s.student_name)))), /*#__PURE__*/React.createElement("div", null, selectedStudent && /*#__PURE__*/React.createElement(ReportEditor, {
    student: selectedStudent,
    terms: terms,
    academicYear: academicYear,
    prefillReportId: prefillReportId,
    onPublished: () => setHistRefresh(n => n + 1)
  })), /*#__PURE__*/React.createElement("div", {
    className: "rp-side-right"
  }, /*#__PURE__*/React.createElement(ReportHistory, {
    student: selectedStudent,
    refresh: histRefresh,
    onSelect: id => {
      setPrefillReportId(id);
    }
  })))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(ReportsApp, null));