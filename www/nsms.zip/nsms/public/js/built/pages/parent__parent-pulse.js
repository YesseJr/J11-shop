var useState = React.useState;
var useEffect = React.useEffect;
var useRef = React.useRef;
var API = '/nsms/api/parent-pulse-api.php';

/* ── URL param helper ── */
function getUrlParam(k) {
  return new URLSearchParams(window.location.search).get(k) || '';
}

/* ── Helpers ── */
var AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2', '#DB2777'];
function avColor(n) {
  return n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
}
function initials(n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
}
function fmtConvTime(iso) {
  if (!iso) return '';
  var d = new Date(iso),
    now = new Date();
  if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
  var y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short'
  });
}
function fmtFull(iso) {
  if (!iso) return '';
  var d = new Date(iso);
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  }) + ' ' + d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}
function fmtMsgTime(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}
function fmtBytes(b) {
  if (!b) return '';
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}
function sameDay(a, b) {
  return a && b && new Date(a).toDateString() === new Date(b).toDateString();
}
function dateSep(iso) {
  if (!iso) return '';
  var d = new Date(iso),
    now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today';
  var y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long'
  });
}
function isImg(m) {
  return m && m.startsWith('image/');
}

/**
 * Plays a short, pleasant two-note chime using the Web Audio API — no
 * external sound file needed. Fails silently if audio is blocked before
 * any user interaction (standard browser autoplay policy).
 */
function playPulseChime() {
  try {
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    var ctx = new Ctx();
    [880, 1108].forEach(function (freq, i) {
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      var start = ctx.currentTime + i * 0.09;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.13, start + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.22);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.24);
    });
  } catch (e) {
    /* audio not available — non-fatal */
  }
}
function fileIcon(m) {
  if (!m) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📄',
    size: 18
  }) : null;
  if (m.startsWith('image/')) return /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDDBC",
    size: 16
  });
  if (m === 'application/pdf') return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📕',
    size: 18
  }) : null;
  if (m.includes('word')) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📘',
    size: 18
  }) : null;
  if (m.includes('sheet') || m.includes('excel')) return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📗',
    size: 18
  }) : null;
  return typeof Icon === 'function' ? React.createElement(Icon, {
    emoji: '📄',
    size: 18
  }) : null;
}
function apiGet(action, params) {
  var q = Object.keys(params || {}).map(function (k) {
    return k + '=' + encodeURIComponent(params[k]);
  }).join('&');
  return fetch(API + '?action=' + action + (q ? '&' + q : ''), {
    credentials: 'same-origin'
  });
}
function apiPost(action, data) {
  return fetch(API + '?action=' + action, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  });
}
function apiForm(action, fd) {
  return fetch(API + '?action=' + action, {
    method: 'POST',
    credentials: 'same-origin',
    body: fd
  });
}
function showToast(setT, msg, type) {
  setT({
    msg: msg,
    type: type || 'success'
  });
  setTimeout(function () {
    setT(null);
  }, 3000);
}
function Av(props) {
  var n = props.name || '',
    sz = props.size || 40,
    src = props.src,
    sq = props.sq;
  return /*#__PURE__*/React.createElement("div", {
    className: 'av' + (sq ? ' sq' : ''),
    style: {
      width: sz,
      height: sz,
      background: avColor(n),
      flexShrink: 0
    }
  }, src && /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: n,
    onError: function (e) {
      e.currentTarget.style.display = 'none';
    }
  }), !src && initials(n));
}
function PrioBadge(p) {
  var labels = {
    low: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDFE2",
      size: 16
    }), "Low"),
    medium: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD35",
      size: 16
    }), "Medium"),
    high: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDFE0",
      size: 16
    }), "High"),
    urgent: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD34",
      size: 16
    }), "Urgent")
  };
  var cls = {
    low: 'pb-low',
    medium: 'pb-med',
    high: 'pb-hi',
    urgent: 'pb-urg'
  };
  var v = p.priority || 'medium';
  return /*#__PURE__*/React.createElement("span", {
    className: 'pb ' + (cls[v] || 'pb-med')
  }, labels[v] || v);
}
function SenderChip(p) {
  if (p.role === 'admin') return /*#__PURE__*/React.createElement("span", {
    className: "src-chip src-admin"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFEB",
    size: 18
  }), " Admin");
  if (p.role === 'teacher') return /*#__PURE__*/React.createElement("span", {
    className: "src-chip src-teacher"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCDA",
    size: 18
  }), " Teacher");
  return null;
}
function RoleTag(p) {
  var cls = p.role === 'teacher' ? 'ci-tag-teacher' : p.role === 'admin' ? 'ci-tag-admin' : 'ci-tag-parent';
  return /*#__PURE__*/React.createElement("span", {
    className: 'ci-tag ' + cls
  }, p.role === 'teacher' ? 'Teacher' : p.role === 'admin' ? 'Admin' : 'Parent');
}
function Toast(p) {
  if (!p.toast) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: 'ptoast ' + p.toast.type
  }, p.toast.msg);
}

/* ═══════════════════════════
MESSAGES TAB
deepTeacherId — auto-open this contact's thread (from ?teacher_id URL param)
preFillMsg    — pre-fill the compose box (built from report context)
reportRef     — the raw report id (from ?report_ref URL param)
═══════════════════════════ */
function MessagesTab(props) {
  var myId = props.myId,
    deepTeacherId = props.deepTeacherId || 0;
  var preFillMsg = props.preFillMsg || '',
    reportRef = props.reportRef || '';
  var [convs, setConvs] = useState([]);
  var [selContact, setSelContact] = useState(null);
  var [thread, setThread] = useState([]);
  var [cInfo, setCInfo] = useState(null);
  var [isOnline, setIsOnline] = useState(false);
  var [isTyping, setIsTyping] = useState(false);
  var [compose, setCompose] = useState(preFillMsg);
  var [pendFile, setPendFile] = useState(null);
  var [sending, setSending] = useState(false);
  var [loadThread, setLoadThread] = useState(false);
  var [showNew, setShowNew] = useState(false);
  var [search, setSearch] = useState('');
  var [lightbox, setLightbox] = useState(null);
  var [toast, setToast] = useState(null);
  var [replyTo, setReplyTo] = useState(null);
  var [threadSearch, setThreadSearch] = useState('');
  var [showSearch, setShowSearch] = useState(false);
  var [editingId, setEditingId] = useState(null);
  var [editText, setEditText] = useState('');
  var [reactPickerFor, setReactPickerFor] = useState(null);
  var QUICK_EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🙏'].map(function (e) {
    return typeof Icon === 'function' ? React.createElement(Icon, {
      emoji: e,
      size: 18,
      key: e
    }) : e;
  });
  async function toggleReaction(messageId, emoji) {
    setReactPickerFor(null);
    setThread(function (prev) {
      return prev.map(function (m) {
        if (m.id !== messageId) return m;
        var reactions = async (m.reactions || []).slice();
        var idx = reactions.findIndex(function (r) {
          return r.emoji === emoji;
        });
        if (idx >= 0 && reactions[idx].mine) {
          if (reactions[idx].count <= 1) reactions.splice(idx, 1);else reactions[idx] = Object.assign({}, reactions[idx], {
            count: reactions[idx].count - 1,
            mine: false
          });
        } else if (idx >= 0) {
          reactions[idx] = Object.assign({}, reactions[idx], {
            count: reactions[idx].count + 1,
            mine: true
          });
        } else {
          reactions.push({
            emoji: emoji,
            count: 1,
            mine: true
          });
        }
        return Object.assign({}, m, {
          reactions: reactions
        });
      });
    });
    apiPost('toggle_reaction', {
      message_id: messageId,
      emoji: emoji
    });
  }
  async function startEdit(msg) {
    setEditingId(msg.id);
    setEditText(msg.message || '');
    setReactPickerFor(null);
  }
  async function cancelEdit() {
    setEditingId(null);
    setEditText('');
  }
  async function saveEdit(messageId) {
    var text = editText.trim();
    if (!text) return;
    apiPost('edit_message', {
      message_id: messageId,
      message: text
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setThread(function (prev) {
          return prev.map(function (m) {
            return m.id === messageId ? Object.assign({}, m, {
              message: text,
              edited_at: new Date().toISOString()
            }) : m;
          });
        });
        setEditingId(null);
        setEditText('');
      } else {
        showToast(setToast, d.error || 'Could not edit message', 'error');
      }
    });
  }
  async function deleteMessage(messageId) {
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Delete message?', message: 'Delete this message? This cannot be undone.', confirmLabel: 'Delete', variant: 'danger' }) : Promise.resolve(false)))) return;
    apiPost('delete_message', {
      message_id: messageId
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setThread(function (prev) {
          return prev.map(function (m) {
            return m.id === messageId ? Object.assign({}, m, {
              is_deleted: true,
              message: null,
              files: [],
              reactions: []
            }) : m;
          });
        });
      } else {
        showToast(setToast, d.error || 'Could not delete message', 'error');
      }
    });
  }
  function canEdit(msg) {
    if (msg.sender_id !== myId || msg.is_deleted) return false;
    return Date.now() - new Date(msg.created_at).getTime() < 15 * 60 * 1000;
  }
  useEffect(function () {
    if (reactPickerFor === null) return;
    function onDocClick(e) {
      if (!e.target.closest('.react-picker') && !e.target.closest('.mact-btn')) setReactPickerFor(null);
    }
    document.addEventListener('click', onDocClick);
    return function () {
      document.removeEventListener('click', onDocClick);
    };
  }, [reactPickerFor]);
  var fileInputRef = useRef(null),
    bottomRef = useRef(null);
  var lastMsgIdRef = useRef(0),
    pollRef = useRef(null);
  var convsPollRef = useRef(null);
  /* deepLinkedRef: ensures auto-open fires only once, not on every 10s poll */
  var deepLinkedRef = useRef(false);
  useEffect(function () {
    loadConvs();
    var hb = setInterval(function () {
      fetch(API + '?action=heartbeat', {
        method: 'POST',
        credentials: 'same-origin'
      });
    }, 30000);
    convsPollRef.current = setInterval(loadConvs, 10000);
    return function () {
      clearInterval(hb);
      if (pollRef.current) clearInterval(pollRef.current);
      if (convsPollRef.current) clearInterval(convsPollRef.current);
    };
  }, []);
  function loadConvs() {
    apiGet('conversations').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) return;
      setConvs(d.data || []);
      /* Deep-link: auto-open teacher thread once after first successful load */
      if (deepTeacherId && !deepLinkedRef.current) {
        deepLinkedRef.current = true;
        setTimeout(function () {
          openThread(deepTeacherId);
        }, 200);
      }
    });
  }
  function openThread(cid) {
    if (selContact === cid) return;
    setSelContact(cid);
    setThread([]);
    setLoadThread(true);
    lastMsgIdRef.current = 0;
    if (pollRef.current) clearInterval(pollRef.current);
    apiGet('thread', {
      contact_id: cid
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        var msgs = d.data.messages || [];
        setThread(msgs);
        setCInfo(d.data.contact);
        setIsOnline(!!d.data.is_online);
        if (msgs.length) lastMsgIdRef.current = msgs[msgs.length - 1].id;
        setTimeout(function () {
          if (bottomRef.current) bottomRef.current.scrollIntoView();
        }, 80);
      }
      setLoadThread(false);
    });
    fetch(API + '?action=mark_read&contact_id=' + cid, {
      method: 'POST',
      credentials: 'same-origin'
    });
    pollRef.current = setInterval(function () {
      pollUpdates(cid);
    }, 3000);
  }
  function pollUpdates(cid) {
    apiGet('thread_updates', {
      contact_id: cid,
      since_id: lastMsgIdRef.current
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) return;
      setIsOnline(!!d.data.is_online);
      setIsTyping(!!d.data.is_typing);
      if (d.data.new_messages && d.data.new_messages.length) {
        var hasIncoming = d.data.new_messages.some(function (m) {
          return m.sender_id !== myId;
        });
        if (hasIncoming) playPulseChime();
        setThread(function (prev) {
          var u = prev.concat(d.data.new_messages);
          lastMsgIdRef.current = u[u.length - 1].id;
          return u;
        });
        fetch(API + '?action=mark_read&contact_id=' + cid, {
          method: 'POST',
          credentials: 'same-origin'
        });
        setTimeout(function () {
          if (bottomRef.current) bottomRef.current.scrollIntoView({
            behavior: 'smooth'
          });
        }, 80);
        loadConvs();
      }
    });
  }
  function handleSend() {
    if (sending || !compose.trim() && !pendFile) return;
    setSending(true);
    if (pendFile) {
      var fd = new FormData();
      fd.append('recipient_id', selContact);
      fd.append('message', compose.trim());
      fd.append('reply_to_id', replyTo ? replyTo.id : 0);
      fd.append('attachment', pendFile);
      apiForm('send_file', fd).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) {
          setThread(function (p) {
            return p.concat([d.data]);
          });
          lastMsgIdRef.current = d.data.id || lastMsgIdRef.current;
          setCompose('');
          setReplyTo(null);
          setPendFile(null);
          loadConvs();
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        } else showToast(setToast, d.message || 'Send failed', 'error');
        setSending(false);
      }).catch(function () {
        setSending(false);
      });
    } else {
      apiPost('send', {
        recipient_id: selContact,
        message: compose.trim(),
        reply_to_id: replyTo ? replyTo.id : 0
      }).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) {
          setThread(function (p) {
            return p.concat([d.data]);
          });
          lastMsgIdRef.current = d.data.id || lastMsgIdRef.current;
          setCompose('');
          setReplyTo(null);
          loadConvs();
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        } else showToast(setToast, d.message || 'Send failed', 'error');
        setSending(false);
      }).catch(function () {
        setSending(false);
      });
    }
  }
  function onKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }
  function onComposeChange(e) {
    var ta = e.target;
    setCompose(ta.value);
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 100) + 'px';
    if (selContact) fetch(API + '?action=set_typing&contact_id=' + selContact, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        is_typing: 1
      })
    });
  }
  var filtered = convs.filter(function (c) {
    return !search || c.full_name.toLowerCase().includes(search.toLowerCase());
  });
  var visibleThread = threadSearch.trim() ? thread.filter(function (m) {
    return m.message && m.message.toLowerCase().includes(threadSearch.toLowerCase());
  }) : thread;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "lp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lp-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lp-title"
  }, "Direct Messages"), /*#__PURE__*/React.createElement("button", {
    className: "lp-btn lp-btn-blue",
    onClick: function () {
      setShowNew(true);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  }), " New")), /*#__PURE__*/React.createElement("div", {
    className: "lp-search"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lp-si"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search conversations\u2026",
    value: search,
    onChange: function (e) {
      setSearch(e.target.value);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "lp-list"
  }, filtered.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "lp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCAC",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "No conversations yet"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11
    }
  }, "Message a teacher, admin or class parent")), filtered.map(function (c) {
    var isDeepTarget = deepTeacherId && c.id === deepTeacherId;
    return /*#__PURE__*/React.createElement("div", {
      key: c.id,
      className: 'ci' + (selContact === c.id ? ' active' : '') + (isDeepTarget ? ' deeplink-hl' : ''),
      onClick: function () {
        openThread(c.id);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "avw"
    }, /*#__PURE__*/React.createElement(Av, {
      name: c.full_name,
      src: c.photo_url,
      size: 40
    }), c.is_online && /*#__PURE__*/React.createElement("span", {
      className: "odot"
    })), /*#__PURE__*/React.createElement("div", {
      className: "ci-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ci-top"
    }, /*#__PURE__*/React.createElement("span", {
      className: "ci-name"
    }, c.full_name), /*#__PURE__*/React.createElement("span", {
      className: "ci-time"
    }, fmtConvTime(c.last_at))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 5,
        marginBottom: 1
      }
    }, /*#__PURE__*/React.createElement(RoleTag, {
      role: c.role
    })), /*#__PURE__*/React.createElement("div", {
      className: "ci-prev"
    }, c.last_message || 'No messages yet')), c.unread_count > 0 && /*#__PURE__*/React.createElement("span", {
      className: "bcount"
    }, c.unread_count));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "rp"
  }, !selContact ? /*#__PURE__*/React.createElement("div", {
    className: "rp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 800,
      fontSize: 17,
      color: 'var(--text-dark)'
    }
  }, "J11 Pulse"), deepTeacherId ? /*#__PURE__*/React.createElement("p", null, "Opening your teacher's conversation\u2026") : /*#__PURE__*/React.createElement("p", null, "Select a conversation or start a new message."), /*#__PURE__*/React.createElement("small", null, "All messages are private and end-to-end between you and the recipient.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "rp-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "avw"
  }, /*#__PURE__*/React.createElement(Av, {
    name: cInfo ? cInfo.full_name : '',
    src: cInfo ? cInfo.photo_url : '',
    size: 38
  }), isOnline && /*#__PURE__*/React.createElement("span", {
    className: "odot"
  })), /*#__PURE__*/React.createElement("div", {
    className: "rp-hi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rp-name"
  }, cInfo ? cInfo.full_name : '…', cInfo && cInfo.role && /*#__PURE__*/React.createElement(RoleTag, {
    role: cInfo.role
  })), /*#__PURE__*/React.createElement("div", {
    className: 'rp-st ' + (isTyping ? 'typing' : isOnline ? 'online' : 'offline')
  }, isTyping ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 3
    }
  }, [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        width: 5,
        height: 5,
        borderRadius: '50%',
        background: '#2563EB',
        animation: 'tdot 1.4s infinite ease-in-out both',
        animationDelay: i === 0 ? '-.32s' : i === 1 ? '-.16s' : '0s',
        display: 'inline-block'
      }
    });
  })), "typing") : isOnline ? '● Online' : 'Last seen recently')), /*#__PURE__*/React.createElement("button", {
    title: "Search in thread",
    onClick: function () {
      setShowSearch(function (v) {
        return !v;
      });
      setThreadSearch('');
    },
    style: {
      width: 30,
      height: 30,
      borderRadius: 8,
      border: '1.5px solid var(--border)',
      background: showSearch ? '#EFF6FF' : 'white',
      color: showSearch ? '#2563EB' : 'var(--text-muted)',
      cursor: 'pointer',
      fontSize: 14,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginLeft: 'auto'
    }
  }, "\uD83D\uDD0D")), showSearch && /*#__PURE__*/React.createElement("div", {
    className: "tsbar"
  }, /*#__PURE__*/React.createElement("input", {
    className: "tsbar-in",
    placeholder: "Search messages in this chat\u2026",
    autoFocus: true,
    value: threadSearch,
    onChange: function (e) {
      setThreadSearch(e.target.value);
    },
    onKeyDown: function (e) {
      if (e.key === 'Escape') {
        setShowSearch(false);
        setThreadSearch('');
      }
    }
  }), threadSearch && /*#__PURE__*/React.createElement("span", {
    className: "tsbar-cnt"
  }, visibleThread.length, ' ', "result", visibleThread.length !== 1 ? 's' : ''), /*#__PURE__*/React.createElement("button", {
    className: "tsbar-close",
    onClick: function () {
      setShowSearch(false);
      setThreadSearch('');
    }
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "msgs-area"
  }, loadThread && [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "mr theirs"
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: 130 + i * 50 + 'px',
        height: 34,
        borderRadius: 9
      }
    }));
  }), !loadThread && visibleThread.map(function (msg, idx) {
    var isMine = msg.sender_id === myId;
    var showSep = !threadSearch && (idx === 0 || !sameDay(visibleThread[idx - 1].created_at, msg.created_at));
    var isEditing = editingId === msg.id;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: msg.id || idx
    }, showSep && /*#__PURE__*/React.createElement("div", {
      className: "dsep"
    }, dateSep(msg.created_at)), /*#__PURE__*/React.createElement("div", {
      className: 'mr msg-row ' + (isMine ? 'mine' : 'theirs'),
      style: {
        position: 'relative'
      }
    }, !msg.is_deleted && /*#__PURE__*/React.createElement("div", {
      className: "msg-actions",
      style: {
        justifyContent: isMine ? 'flex-end' : 'flex-start'
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "React",
      onClick: function () {
        setReactPickerFor(reactPickerFor === msg.id ? null : msg.id);
      }
    }, "\uD83D\uDE0A"), /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "Reply",
      onClick: function () {
        setReplyTo(msg);
      }
    }, "\u21A9 Reply"), /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "Copy",
      onClick: function () {
        if (msg.message) try {
          navigator.clipboard.writeText(msg.message);
        } catch (e) {}
      }
    }, "\uD83D\uDCCB"), canEdit(msg) && /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "Edit",
      onClick: function () {
        startEdit(msg);
      }
    }, "\u270F\uFE0F"), isMine && /*#__PURE__*/React.createElement("button", {
      className: "mact-btn",
      title: "Delete",
      onClick: function () {
        deleteMessage(msg.id);
      }
    }, "\uD83D\uDDD1\uFE0F")), reactPickerFor === msg.id && /*#__PURE__*/React.createElement("div", {
      className: "react-picker"
    }, QUICK_EMOJIS.map(function (e) {
      return /*#__PURE__*/React.createElement("button", {
        key: e,
        onClick: function () {
          toggleReaction(msg.id, e);
        }
      }, e);
    })), msg.is_deleted ? /*#__PURE__*/React.createElement("div", {
      className: "msg-deleted"
    }, "\uD83D\uDEAB This message was deleted") : /*#__PURE__*/React.createElement(React.Fragment, null, msg.reply_to_message && /*#__PURE__*/React.createElement("div", {
      className: "quote-ref"
    }, /*#__PURE__*/React.createElement("div", {
      className: "quote-ref-name"
    }, msg.reply_to_sender || 'Message'), /*#__PURE__*/React.createElement("div", {
      className: "quote-ref-text"
    }, msg.reply_to_message)), isEditing ? /*#__PURE__*/React.createElement("div", {
      className: "edit-box"
    }, /*#__PURE__*/React.createElement("textarea", {
      autoFocus: true,
      value: editText,
      onChange: function (e) {
        setEditText(e.target.value);
      },
      onKeyDown: function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          saveEdit(msg.id);
        } else if (e.key === 'Escape') {
          cancelEdit();
        }
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "edit-box-actions"
    }, /*#__PURE__*/React.createElement("button", {
      className: "edit-cancel",
      onClick: cancelEdit
    }, "Cancel"), /*#__PURE__*/React.createElement("button", {
      className: "edit-save",
      onClick: function () {
        saveEdit(msg.id);
      }
    }, "Save"))) : /*#__PURE__*/React.createElement(React.Fragment, null, msg.message && /*#__PURE__*/React.createElement("div", {
      className: "bbl"
    }, msg.message, msg.edited_at && /*#__PURE__*/React.createElement("span", {
      className: "msg-edited-tag"
    }, "(edited)")), msg.files && msg.files.map(function (f, fi) {
      if (isImg(f.mime_type)) return /*#__PURE__*/React.createElement("img", {
        key: fi,
        className: "imgprev",
        src: f.url,
        alt: f.original_name,
        onClick: function () {
          setLightbox(f.url);
        },
        onError: function (e) {
          e.currentTarget.style.display = 'none';
        }
      });
      return /*#__PURE__*/React.createElement("a", {
        key: fi,
        className: "fcard",
        href: f.url,
        target: "_blank",
        rel: "noopener noreferrer"
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 19
        }
      }, fileIcon(f.mime_type)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
        className: "fname"
      }, f.original_name), /*#__PURE__*/React.createElement("div", {
        className: "fsize"
      }, fmtBytes(f.file_size))), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 11,
          opacity: 0.6
        }
      }, "\u2193"));
    })), msg.reactions && msg.reactions.length > 0 && /*#__PURE__*/React.createElement("div", {
      className: "react-pills"
    }, msg.reactions.map(function (r) {
      return /*#__PURE__*/React.createElement("button", {
        key: r.emoji,
        className: 'react-pill' + (r.mine ? ' mine' : ''),
        onClick: function () {
          toggleReaction(msg.id, r.emoji);
        }
      }, /*#__PURE__*/React.createElement("span", null, r.emoji), /*#__PURE__*/React.createElement("span", null, r.count));
    })), /*#__PURE__*/React.createElement("div", {
      className: "mmeta"
    }, /*#__PURE__*/React.createElement("span", {
      className: "mtime"
    }, fmtMsgTime(msg.created_at)), isMine && /*#__PURE__*/React.createElement("span", {
      className: 'mrec' + (msg.is_read == 1 ? ' read' : '')
    }, msg.is_read == 1 ? /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 16
    }) : /*#__PURE__*/React.createElement(Icon, {
      name: "circle",
      size: 14
    }))))));
  }), !loadThread && visibleThread.length === 0 && threadSearch && /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--text-muted)',
      gap: 8,
      padding: 32
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, "\uD83D\uDD0D"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13
    }
  }, "No messages match \"", threadSearch, "\"")), isTyping && !loadThread && /*#__PURE__*/React.createElement("div", {
    className: "mr theirs"
  }, /*#__PURE__*/React.createElement("div", {
    className: "bbl",
    style: {
      padding: '10px 16px',
      display: 'flex',
      gap: 4,
      alignItems: 'center'
    }
  }, [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        width: 6,
        height: 6,
        borderRadius: '50%',
        background: '#94A3B8',
        animation: 'tdot 1.4s infinite ease-in-out both',
        animationDelay: i === 0 ? '-.32s' : i === 1 ? '-.16s' : '0s',
        display: 'inline-block'
      }
    });
  }))), /*#__PURE__*/React.createElement("div", {
    ref: bottomRef
  })), /*#__PURE__*/React.createElement("div", {
    className: "cwrap"
  }, reportRef && !replyTo && /*#__PURE__*/React.createElement("div", {
    className: "rpt-ref-bar"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "Discussing report", ' ', /*#__PURE__*/React.createElement("span", {
    className: "rpt-ref-code"
  }, "RPT-", reportRef)), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10.5,
      color: '#3B82F6',
      fontWeight: 500
    }
  }, "Reference included in your message")), replyTo && /*#__PURE__*/React.createElement("div", {
    className: "reply-bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "reply-bar-line"
  }), /*#__PURE__*/React.createElement("div", {
    className: "reply-bar-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "reply-bar-name"
  }, "\u21A9 Replying to", ' ', replyTo.sender_id === myId ? 'yourself' : cInfo ? cInfo.full_name : '…'), /*#__PURE__*/React.createElement("div", {
    className: "reply-bar-prev"
  }, replyTo.message || /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCE",
    size: 16
  }), "Attachment"))), /*#__PURE__*/React.createElement("button", {
    className: "reply-bar-close",
    onClick: function () {
      setReplyTo(null);
    }
  }, "\u2715")), pendFile && /*#__PURE__*/React.createElement("div", {
    className: "fpbar"
  }, isImg(pendFile.type) ? /*#__PURE__*/React.createElement("img", {
    style: {
      maxHeight: 40,
      maxWidth: 60,
      borderRadius: 4,
      objectFit: 'cover'
    },
    src: URL.createObjectURL(pendFile),
    alt: ""
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, fileIcon(pendFile.type)), /*#__PURE__*/React.createElement("span", {
    className: "fp-nm"
  }, pendFile.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, fmtBytes(pendFile.size)), /*#__PURE__*/React.createElement("button", {
    className: "fp-rm",
    onClick: function () {
      setPendFile(null);
    }
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "crow"
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileInputRef,
    type: "file",
    style: {
      display: 'none'
    },
    accept: "image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt",
    onChange: function (e) {
      if (e.target.files[0]) setPendFile(e.target.files[0]);
      e.target.value = '';
    }
  }), /*#__PURE__*/React.createElement("button", {
    className: "catt",
    onClick: function () {
      fileInputRef.current && fileInputRef.current.click();
    }
  }, "\uD83D\uDCCE"), /*#__PURE__*/React.createElement("textarea", {
    className: "cinput",
    placeholder: replyTo ? 'Write your reply…' : pendFile ? 'Add a caption…' : 'Type a message… (Enter to send)',
    value: compose,
    onChange: onComposeChange,
    onKeyDown: onKey,
    rows: 1
  }), /*#__PURE__*/React.createElement("button", {
    className: "bsend",
    onClick: handleSend,
    disabled: sending || !compose.trim() && !pendFile
  }, sending ? '…' : 'Send <Icon emoji="▶" size={18} />'))))), showNew && /*#__PURE__*/React.createElement(NewDMModal, {
    onClose: function () {
      setShowNew(false);
    },
    onSent: function (cid) {
      setShowNew(false);
      openThread(cid);
      loadConvs();
    }
  }), lightbox && /*#__PURE__*/React.createElement("div", {
    className: "plbox",
    onClick: function () {
      setLightbox(null);
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: lightbox,
    alt: "Preview",
    onClick: function (e) {
      e.stopPropagation();
    }
  })), /*#__PURE__*/React.createElement(Toast, {
    toast: toast
  }));
}

/* ═══════════════════════════
COLLAB TAB
═══════════════════════════ */
function CollabTab(props) {
  var myId = props.myId;
  var [groups, setGroups] = useState([]);
  var [selGrp, setSelGrp] = useState(null);
  var [grpInfo, setGrpInfo] = useState(null);
  var [thread, setThread] = useState([]);
  var [members, setMembers] = useState([]);
  var [resources, setResources] = useState([]);
  var [subTab, setSubTab] = useState('chat');
  var [compose, setCompose] = useState('');
  var [pendFile, setPendFile] = useState(null);
  var [sending, setSending] = useState(false);
  var [loading, setLoading] = useState(false);
  var [showNG, setShowNG] = useState(false);
  var [showRU, setShowRU] = useState(false);
  var [showAG, setShowAG] = useState(false);
  var [lightbox, setLightbox] = useState(null);
  var [toast, setToast] = useState(null);
  var bottomRef = useRef(null),
    fileRef = useRef(null),
    lastIdRef = useRef(0),
    pollRef = useRef(null),
    grpPollRef = useRef(null);
  useEffect(function () {
    loadGroups();
    grpPollRef.current = setInterval(loadGroups, 15000);
    return function () {
      if (pollRef.current) clearInterval(pollRef.current);
      if (grpPollRef.current) clearInterval(grpPollRef.current);
    };
  }, []);
  function loadGroups() {
    apiGet('my_groups').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setGroups(d.data || []);
    });
  }
  function openGroup(gid) {
    if (selGrp === gid) return;
    setSelGrp(gid);
    setThread([]);
    setLoading(true);
    lastIdRef.current = 0;
    setSubTab('chat');
    if (pollRef.current) clearInterval(pollRef.current);
    fetch(API + '?action=mark_group_read&group_id=' + gid, {
      method: 'POST',
      credentials: 'same-origin'
    });
    Promise.all([apiGet('group_thread', {
      group_id: gid
    }).then(function (r) {
      return r.json();
    }), apiGet('group_members', {
      group_id: gid
    }).then(function (r) {
      return r.json();
    }), apiGet('resources', {
      group_id: gid
    }).then(function (r) {
      return r.json();
    })]).then(function (res) {
      if (res[0].success) {
        var msgs = res[0].data.messages || [];
        setThread(msgs);
        setGrpInfo(res[0].data.group);
        if (msgs.length) lastIdRef.current = msgs[msgs.length - 1].id;
        setTimeout(function () {
          if (bottomRef.current) bottomRef.current.scrollIntoView();
        }, 80);
      }
      if (res[1].success) setMembers(res[1].data || []);
      if (res[2].success) setResources(res[2].data || []);
      setLoading(false);
    });
    pollRef.current = setInterval(function () {
      apiGet('group_thread_updates', {
        group_id: gid,
        since_id: lastIdRef.current
      }).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success && d.data.messages && d.data.messages.length) {
          setThread(function (p) {
            var u = p.concat(d.data.messages);
            lastIdRef.current = u[u.length - 1].id;
            return u;
          });
          fetch(API + '?action=mark_group_read&group_id=' + gid, {
            method: 'POST',
            credentials: 'same-origin'
          });
          loadGroups();
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        }
      });
    }, 3000);
  }
  function handleSend() {
    if (sending || !compose.trim() && !pendFile) return;
    setSending(true);
    if (pendFile) {
      var fd = new FormData();
      fd.append('group_id', selGrp);
      fd.append('message', compose.trim());
      fd.append('attachment', pendFile);
      apiForm('group_send_file', fd).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) {
          setThread(function (p) {
            return p.concat([d.data]);
          });
          lastIdRef.current = d.data.id;
          setCompose('');
          setPendFile(null);
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        }
        setSending(false);
      });
    } else {
      apiPost('group_send', {
        group_id: selGrp,
        message: compose.trim()
      }).then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) {
          setThread(function (p) {
            return p.concat([d.data]);
          });
          lastIdRef.current = d.data.id;
          setCompose('');
          setTimeout(function () {
            if (bottomRef.current) bottomRef.current.scrollIntoView({
              behavior: 'smooth'
            });
          }, 80);
        }
        setSending(false);
      });
    }
  }
  function leaveGroup(gid) {
    /* Check if current user is the owner of this group */
    var grp = groups.find(function (g) {
      return g.id === gid;
    });
    if (grp && grp.group_role === 'owner') {
      showToast(setToast, 'You are the group owner. Transfer ownership before leaving.', 'error');
      return;
    }
    if (!confirm('Leave this group?')) return;
    fetch(API + '?action=leave_group&group_id=' + gid, {
      method: 'POST',
      credentials: 'same-origin'
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setGroups(function (p) {
          return p.filter(function (g) {
            return g.id !== gid;
          });
        });
        setSelGrp(null);
        showToast(setToast, 'Left group.');
      } else {
        showToast(setToast, d.message || 'Could not leave group.', 'error');
      }
    });
  }
  function onKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }
  function reloadRes() {
    apiGet('resources', {
      group_id: selGrp
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setResources(d.data || []);
    });
  }
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "lp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lp-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lp-title"
  }, "Collaboration Hub"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "lp-btn lp-btn-green",
    onClick: function () {
      setShowNG(true);
    }
  }, "+ Group"), /*#__PURE__*/React.createElement("button", {
    className: "lp-btn lp-btn-blue",
    onClick: function () {
      setShowAG(true);
    }
  }, "Browse"))), /*#__PURE__*/React.createElement("div", {
    className: "lp-list"
  }, groups.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "lp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "No groups yet")), groups.map(function (g) {
    return /*#__PURE__*/React.createElement("div", {
      key: g.id,
      className: 'gi' + (selGrp === g.id ? ' active' : ''),
      onClick: function () {
        openGroup(g.id);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "av sq",
      style: {
        width: 40,
        height: 40,
        background: g.avatar_color || '#10B981',
        borderRadius: 10,
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 16,
        fontWeight: 800,
        color: 'white'
      }
    }, g.name ? g.name[0].toUpperCase() : 'G'), /*#__PURE__*/React.createElement("div", {
      className: "gi-info"
    }, /*#__PURE__*/React.createElement("div", {
      className: "gi-name"
    }, g.name), /*#__PURE__*/React.createElement("div", {
      className: "gi-meta"
    }, g.member_count, " member", g.member_count != 1 ? 's' : '')));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "rp"
  }, !selGrp ? /*#__PURE__*/React.createElement("div", {
    className: "rp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC65",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "Select a group to collaborate")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "rp-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "av sq",
    style: {
      width: 38,
      height: 38,
      background: grpInfo ? grpInfo.avatar_color : '#10B981',
      borderRadius: 9,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 16,
      fontWeight: 800,
      color: 'white',
      flexShrink: 0
    }
  }, grpInfo ? grpInfo.name[0].toUpperCase() : 'G'), /*#__PURE__*/React.createElement("div", {
    className: "rp-hi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rp-name"
  }, grpInfo ? grpInfo.name : 'Group'), /*#__PURE__*/React.createElement("div", {
    className: "rp-st offline"
  }, members.length, " members")), /*#__PURE__*/React.createElement("button", {
    style: {
      marginLeft: 'auto',
      background: 'none',
      border: '1.5px solid #FECACA',
      borderRadius: 7,
      padding: '5px 10px',
      fontSize: 11.5,
      fontWeight: 700,
      color: '#DC2626',
      cursor: 'pointer'
    },
    onClick: function () {
      leaveGroup(selGrp);
    }
  }, "Leave")), /*#__PURE__*/React.createElement("div", {
    className: "subtabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: 'stab' + (subTab === 'chat' ? ' ag' : ''),
    onClick: function () {
      setSubTab('chat');
    }
  }, "\uD83D\uDCAC Chat"), /*#__PURE__*/React.createElement("button", {
    className: 'stab' + (subTab === 'resources' ? ' ag' : ''),
    onClick: function () {
      setSubTab('resources');
    }
  }, "\uD83D\uDCDA Resources (", resources.length, ")"), /*#__PURE__*/React.createElement("button", {
    className: 'stab' + (subTab === 'members' ? ' ag' : ''),
    onClick: function () {
      setSubTab('members');
    }
  }, "\uD83D\uDC64 Members (", members.length, ")")), subTab === 'chat' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "msgs-area"
  }, loading && [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "mr gm"
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: 130 + i * 50 + 'px',
        height: 34,
        borderRadius: 9
      }
    }));
  }), !loading && thread.map(function (msg, idx) {
    var isMine = msg.sender_id === myId;
    var showSep = idx === 0 || !sameDay(thread[idx - 1].created_at, msg.created_at);
    var showName = !isMine && (idx === 0 || thread[idx - 1].sender_id !== msg.sender_id);
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: msg.id || idx
    }, showSep && /*#__PURE__*/React.createElement("div", {
      className: "dsep"
    }, dateSep(msg.created_at)), /*#__PURE__*/React.createElement("div", {
      className: 'mr gm' + (isMine ? ' ismine' : '')
    }, showName && /*#__PURE__*/React.createElement("span", {
      className: "slbl"
    }, msg.sender_name), msg.message && /*#__PURE__*/React.createElement("div", {
      className: "bbl"
    }, msg.message), msg.files && msg.files.map(function (f, fi) {
      if (isImg(f.mime_type)) return /*#__PURE__*/React.createElement("img", {
        key: fi,
        className: "imgprev",
        src: f.url,
        alt: "",
        onClick: function () {
          setLightbox(f.url);
        }
      });
      return /*#__PURE__*/React.createElement("a", {
        key: fi,
        className: "fcard",
        href: f.url,
        target: "_blank",
        rel: "noopener noreferrer"
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 19
        }
      }, fileIcon(f.mime_type)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
        className: "fname"
      }, f.original_name), /*#__PURE__*/React.createElement("div", {
        className: "fsize"
      }, fmtBytes(f.file_size))));
    }), /*#__PURE__*/React.createElement("div", {
      className: "mmeta"
    }, /*#__PURE__*/React.createElement("span", {
      className: "mtime"
    }, fmtMsgTime(msg.created_at)))));
  }), /*#__PURE__*/React.createElement("div", {
    ref: bottomRef
  })), /*#__PURE__*/React.createElement("div", {
    className: "cwrap"
  }, pendFile && /*#__PURE__*/React.createElement("div", {
    className: "fpbar"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, fileIcon(pendFile.type)), /*#__PURE__*/React.createElement("span", {
    className: "fp-nm"
  }, pendFile.name), /*#__PURE__*/React.createElement("button", {
    className: "fp-rm",
    onClick: function () {
      setPendFile(null);
    }
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "crow"
  }, /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    style: {
      display: 'none'
    },
    accept: "image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt",
    onChange: function (e) {
      if (e.target.files[0]) setPendFile(e.target.files[0]);
      e.target.value = '';
    }
  }), /*#__PURE__*/React.createElement("button", {
    className: "catt",
    onClick: function () {
      fileRef.current && fileRef.current.click();
    }
  }, "\uD83D\uDCCE"), /*#__PURE__*/React.createElement("textarea", {
    className: "cinput",
    placeholder: "Group message\u2026 (Enter to send)",
    value: compose,
    onChange: function (e) {
      setCompose(e.target.value);
    },
    onKeyDown: onKey,
    rows: 1
  }), /*#__PURE__*/React.createElement("button", {
    className: "bsend bsend-g",
    onClick: handleSend,
    disabled: sending || !compose.trim() && !pendFile
  }, sending ? '…' : 'Send <Icon emoji="▶" size={18} />')))), subTab === 'resources' && /*#__PURE__*/React.createElement("div", {
    className: "reswrap"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "lp-btn lp-btn-green",
    onClick: function () {
      setShowRU(true);
    }
  }, "\uD83D\uDCCE Share Resource")), resources.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 0',
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, "\uD83D\uDCDA No resources yet."), /*#__PURE__*/React.createElement("div", {
    className: "resgrid"
  }, resources.map(function (r) {
    return /*#__PURE__*/React.createElement("a", {
      key: r.id,
      className: "rescard",
      href: r.url,
      target: "_blank",
      rel: "noopener noreferrer"
    }, /*#__PURE__*/React.createElement("span", {
      className: "res-ic"
    }, fileIcon(r.mime_type)), /*#__PURE__*/React.createElement("div", {
      className: "res-ti"
    }, r.title), r.description && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-soft)',
        lineHeight: 1.4
      }
    }, r.description), /*#__PURE__*/React.createElement("div", {
      className: "res-mt"
    }, "By", ' ', r.shared_by_name, ' ', "\xB7", ' ', fmtBytes(r.file_size)));
  }))), subTab === 'members' && /*#__PURE__*/React.createElement("div", {
    className: "reswrap"
  }, members.map(function (m) {
    return /*#__PURE__*/React.createElement("div", {
      key: m.id,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '10px 12px',
        border: '1.5px solid var(--border)',
        borderRadius: 10,
        marginBottom: 8
      }
    }, /*#__PURE__*/React.createElement(Av, {
      name: m.full_name,
      src: m.photo_url,
      size: 38
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13.5,
        fontWeight: 700,
        color: 'var(--text-dark)'
      }
    }, m.full_name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-soft)',
        textTransform: 'capitalize'
      }
    }, m.role)), m.group_role === 'owner' && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        color: '#D97706',
        background: '#FEF3C7',
        padding: '2px 8px',
        borderRadius: 5
      }
    }, "Owner"));
  })))), showNG && /*#__PURE__*/React.createElement(NewGroupModal, {
    onClose: function () {
      setShowNG(false);
    },
    onCreated: function () {
      setShowNG(false);
      loadGroups();
      showToast(setToast, 'Group created!');
    }
  }), showRU && selGrp && /*#__PURE__*/React.createElement(UploadResModal, {
    groupId: selGrp,
    onClose: function () {
      setShowRU(false);
    },
    onUploaded: function () {
      setShowRU(false);
      reloadRes();
      showToast(setToast, 'Resource shared!');
    }
  }), showAG && /*#__PURE__*/React.createElement(BrowseGroupsModal, {
    onClose: function () {
      setShowAG(false);
    },
    onJoined: function () {
      setShowAG(false);
      loadGroups();
      showToast(setToast, 'Joined group!');
    }
  }), lightbox && /*#__PURE__*/React.createElement("div", {
    className: "plbox",
    onClick: function () {
      setLightbox(null);
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: lightbox,
    alt: "",
    onClick: function (e) {
      e.stopPropagation();
    }
  })), /*#__PURE__*/React.createElement(Toast, {
    toast: toast
  }));
}

/* ═══════════════════════════
ALERTS TAB
═══════════════════════════ */
function AlertsTab() {
  var [alerts, setAlerts] = useState([]);
  var [selAlert, setSelAlert] = useState(null);
  var [loading, setLoading] = useState(true);
  useEffect(function () {
    setLoading(true);
    apiGet('my_alerts').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setAlerts(d.data || []);
      setLoading(false);
    });
  }, []);
  function openAlert(al) {
    setSelAlert(al);
    if (al.is_read == 0) {
      fetch(API + '?action=mark_alert_read&alert_id=' + al.id, {
        method: 'POST',
        credentials: 'same-origin'
      }).then(function () {
        setAlerts(function (prev) {
          return prev.map(function (a) {
            return a.id === al.id ? Object.assign({}, a, {
              is_read: 1
            }) : a;
          });
        });
      });
    }
  }
  var unread = alerts.filter(function (a) {
    return a.is_read == 0;
  }).length;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "lp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lp-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lp-title"
  }, "Alerts"), unread > 0 && /*#__PURE__*/React.createElement("span", {
    className: "tab-badge",
    style: {
      background: '#F59E0B'
    }
  }, unread)), /*#__PURE__*/React.createElement("div", {
    className: "ro-notice"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD12",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "Alerts from teachers & admin only")), /*#__PURE__*/React.createElement("div", {
    className: "lp-list"
  }, loading && [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        padding: '11px 13px',
        borderBottom: '1px solid #F8FAFC'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '40%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '70%'
      }
    }));
  }), !loading && alerts.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "lp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "No alerts yet")), !loading && alerts.map(function (al) {
    return /*#__PURE__*/React.createElement("div", {
      key: al.id,
      className: 'ali' + (selAlert && selAlert.id === al.id ? ' active' : '') + (al.is_read == 0 ? ' unread' : ''),
      onClick: function () {
        openAlert(al);
      }
    }, /*#__PURE__*/React.createElement(PrioBadge, {
      priority: al.priority
    }), /*#__PURE__*/React.createElement("div", {
      className: "ali-tit"
    }, al.title), /*#__PURE__*/React.createElement("div", {
      className: "ali-from"
    }, "From:", ' ', al.sender_name || 'School', ' ', "\xB7", ' ', fmtConvTime(al.created_at)));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "rp"
  }, !selAlert ? /*#__PURE__*/React.createElement("div", {
    className: "rp-empty"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ei"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  })), /*#__PURE__*/React.createElement("p", null, "Select an alert to read it")) : /*#__PURE__*/React.createElement("div", {
    className: "al-det"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(PrioBadge, {
    priority: selAlert.priority
  }), /*#__PURE__*/React.createElement(SenderChip, {
    role: selAlert.sender_role
  })), /*#__PURE__*/React.createElement("div", {
    className: "al-dt"
  }, selAlert.title), /*#__PURE__*/React.createElement("div", {
    className: "al-dm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Av, {
    name: selAlert.sender_name,
    src: selAlert.sender_photo,
    size: 26
  }), /*#__PURE__*/React.createElement("span", null, "From:", ' ', /*#__PURE__*/React.createElement("strong", null, selAlert.sender_name || 'School'))), /*#__PURE__*/React.createElement("span", null, fmtFull(selAlert.created_at))), /*#__PURE__*/React.createElement("div", {
    className: "al-db"
  }, selAlert.body))));
}

/* ═══════════════════════════
BROADCAST TAB
═══════════════════════════ */
function BroadcastTab() {
  var [bcTab, setBcTab] = useState('announcements');
  var [anns, setAnns] = useState([]);
  var [nls, setNls] = useState([]);
  var [selNl, setSelNl] = useState(null);
  var [loading, setLoading] = useState(true);
  useEffect(function () {
    setLoading(true);
    Promise.all([apiGet('announcements').then(function (r) {
      return r.json();
    }), apiGet('newsletters').then(function (r) {
      return r.json();
    })]).then(function (res) {
      if (res[0].success) setAnns(res[0].data || []);
      if (res[1].success) setNls(res[1].data || []);
      setLoading(false);
    });
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    className: "bcwrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "bcsubs"
  }, /*#__PURE__*/React.createElement("button", {
    className: 'bcst' + (bcTab === 'announcements' ? ' active' : ''),
    onClick: function () {
      setBcTab('announcements');
    }
  }, "\uD83D\uDCE2 Announcements"), /*#__PURE__*/React.createElement("button", {
    className: 'bcst' + (bcTab === 'newsletters' ? ' active' : ''),
    onClick: function () {
      setBcTab('newsletters');
    }
  }, "\uD83D\uDCF0 Newsletters")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      padding: '8px 12px',
      background: '#F0FDF4',
      border: '1.5px solid #BBF7D0',
      borderRadius: 8,
      marginBottom: 14,
      fontSize: 12,
      color: '#15803D',
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD12",
    size: 18
  })), /*#__PURE__*/React.createElement("span", null, "Published by school administration")), loading && [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        border: '1.5px solid var(--border)',
        borderRadius: 12,
        padding: 16,
        marginBottom: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '55%',
        marginBottom: 10
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '90%',
        marginBottom: 6
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "shimmer sh",
      style: {
        width: '40%'
      }
    }));
  }), !loading && bcTab === 'announcements' && (anns.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '48px 0',
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, "\uD83D\uDCE2 No announcements yet") : anns.map(function (a) {
    return /*#__PURE__*/React.createElement("div", {
      key: a.id,
      className: 'anncard' + (a.pinned ? ' pinned' : '')
    }, /*#__PURE__*/React.createElement("div", {
      className: "ann-hd"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ann-ti"
    }, a.title), a.pinned && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        color: '#7C3AED',
        background: '#F3E8FF',
        padding: '2px 7px',
        borderRadius: 5
      }
    }, "\uD83D\uDCCC Pinned")), /*#__PURE__*/React.createElement("div", {
      className: "ann-bd"
    }, a.body), /*#__PURE__*/React.createElement("div", {
      className: "ann-ft"
    }, /*#__PURE__*/React.createElement(Av, {
      name: a.author_name,
      src: a.author_photo,
      size: 22
    }), /*#__PURE__*/React.createElement("span", null, a.author_name), /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto'
      }
    }, fmtFull(a.created_at))));
  })), !loading && bcTab === 'newsletters' && (selNl ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("button", {
    style: {
      background: '#F1F5F9',
      color: 'var(--text-dark)',
      marginBottom: 16,
      padding: '7px 14px',
      borderRadius: 8,
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--font)',
      fontSize: 13,
      fontWeight: 700
    },
    onClick: function () {
      setSelNl(null);
    }
  }, "\u2190 Back"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 19,
      marginBottom: 8,
      color: 'var(--text-dark)'
    }
  }, selNl.subject), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      lineHeight: 1.8,
      color: 'var(--text-dark)',
      whiteSpace: 'pre-wrap',
      background: '#FAFBFC',
      borderRadius: 10,
      padding: 20
    }
  }, selNl.content)) : nls.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '48px 0',
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, "\uD83D\uDCF0 No newsletters yet") : nls.map(function (n) {
    return /*#__PURE__*/React.createElement("div", {
      key: n.id,
      className: "nlcard",
      onClick: function () {
        setSelNl(n);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "nl-su"
    }, n.subject), /*#__PURE__*/React.createElement("div", {
      className: "nl-pv"
    }, n.content), /*#__PURE__*/React.createElement("div", {
      className: "nl-ft"
    }, /*#__PURE__*/React.createElement(Av, {
      name: n.author_name,
      src: n.author_photo,
      size: 20
    }), /*#__PURE__*/React.createElement("span", null, n.author_name), /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto'
      }
    }, fmtConvTime(n.created_at))));
  })));
}

/* ═══════════════════════════
NEW DM MODAL
═══════════════════════════ */
function NewDMModal(props) {
  var [data, setData] = useState({
    admins: [],
    teachers: [],
    coParents: []
  });
  var [sel, setSel] = useState(null);
  var [search, setSearch] = useState('');
  var [msg, setMsg] = useState('');
  var [sending, setSending] = useState(false);
  var [loadingC, setLoadingC] = useState(true);
  useEffect(function () {
    apiGet('contacts').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setData(d.data || {
        admins: [],
        teachers: [],
        coParents: []
      });
      setLoadingC(false);
    });
  }, []);
  var allContacts = [].concat(data.admins || []).concat(data.teachers || []).concat(data.coParents || []);
  function handleSend() {
    if (!sel || !msg.trim()) return;
    setSending(true);
    apiPost('send', {
      recipient_id: sel.id,
      message: msg.trim()
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) props.onSent && props.onSent(sel.id);
      setSending(false);
    });
  }
  function CR(rp) {
    var c = rp.contact;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '8px 12px',
        cursor: 'pointer',
        borderBottom: '1px solid #F8FAFC'
      },
      onMouseEnter: function (e) {
        e.currentTarget.style.background = '#F8FBFF';
      },
      onMouseLeave: function (e) {
        e.currentTarget.style.background = '';
      },
      onClick: function () {
        setSel(c);
        setSearch('');
      }
    }, /*#__PURE__*/React.createElement(Av, {
      name: c.full_name,
      src: c.photo_url,
      size: 32
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: 'var(--text-dark)'
      }
    }, c.full_name), /*#__PURE__*/React.createElement(RoleTag, {
      role: c.role
    })), c.is_online && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        color: '#10B981',
        fontWeight: 700
      }
    }, "\u25CF Online"));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "New Message"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Send to"), sel ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 12px',
      border: '2px solid #2563EB',
      borderRadius: 8,
      background: '#EFF6FF'
    }
  }, /*#__PURE__*/React.createElement(Av, {
    name: sel.full_name,
    src: sel.photo_url,
    size: 28
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 13.5
    }
  }, sel.full_name), /*#__PURE__*/React.createElement(RoleTag, {
    role: sel.role
  })), /*#__PURE__*/React.createElement("button", {
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--text-soft)'
    },
    onClick: function () {
      setSel(null);
    }
  }, "\u2715")) : /*#__PURE__*/React.createElement("input", {
    className: "finp",
    placeholder: "Search teachers, admin, parents\u2026",
    value: search,
    onChange: function (e) {
      setSearch(e.target.value);
    }
  })), !sel && /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 240,
      overflowY: 'auto',
      border: '1.5px solid var(--border)',
      borderRadius: 8
    }
  }, loadingC && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      textAlign: 'center',
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "Loading\u2026"), !loadingC && function () {
    if (search) {
      var res = allContacts.filter(function (c) {
        return c.full_name.toLowerCase().includes(search.toLowerCase());
      });
      return res.length === 0 ? /*#__PURE__*/React.createElement("div", {
        style: {
          padding: 14,
          textAlign: 'center',
          fontSize: 13,
          color: 'var(--text-muted)'
        }
      }, "No contacts found") : res.map(function (c) {
        return /*#__PURE__*/React.createElement(CR, {
          key: c.id,
          contact: c
        });
      });
    }
    return /*#__PURE__*/React.createElement(React.Fragment, null, (data.admins || []).length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "cnt-sec-hd"
    }, "\uD83C\uDFEB School Admin"), data.admins.map(function (c) {
      return /*#__PURE__*/React.createElement(CR, {
        key: c.id,
        contact: c
      });
    })), (data.teachers || []).length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "cnt-sec-hd"
    }, "\uD83D\uDCDA Teachers"), data.teachers.map(function (c) {
      return /*#__PURE__*/React.createElement(CR, {
        key: c.id,
        contact: c
      });
    })), (data.coParents || []).length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "cnt-sec-hd"
    }, "\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67 Class Parents"), data.coParents.map(function (c) {
      return /*#__PURE__*/React.createElement(CR, {
        key: c.id,
        contact: c
      });
    })), allContacts.length === 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 14,
        textAlign: 'center',
        fontSize: 13,
        color: 'var(--text-muted)'
      }
    }, "No contacts yet"));
  }()), sel && /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Message ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "ftxt",
    placeholder: "Write your message\u2026",
    value: msg,
    onChange: function (e) {
      setMsg(e.target.value);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "bprimary blue",
    onClick: handleSend,
    disabled: !sel || !msg.trim() || sending
  }, sending && /*#__PURE__*/React.createElement("span", {
    className: "bspinner"
  }), "Send \u25B6"))));
}

/* ═══════════════════════════
GROUP MODALS
═══════════════════════════ */
var GROUP_COLORS = ['#10B981', '#2563EB', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2', '#DB2777', '#0F172A'];
function NewGroupModal(props) {
  var [grpName, setGrpName] = useState('');
  var [desc, setDesc] = useState('');
  var [color, setColor] = useState('#10B981');
  var [sending, setSending] = useState(false);
  function handleCreate() {
    if (!grpName.trim()) return;
    setSending(true);
    apiPost('create_group', {
      name: grpName,
      description: desc,
      color: color
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) props.onCreated && props.onCreated();
      setSending(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "Create Group"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Name ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    className: "finp",
    placeholder: "e.g. Grade 1-A Parents",
    value: grpName,
    onChange: function (e) {
      setGrpName(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Description"), /*#__PURE__*/React.createElement("textarea", {
    className: "ftxt",
    placeholder: "What is this group for?",
    value: desc,
    onChange: function (e) {
      setDesc(e.target.value);
    },
    style: {
      minHeight: 70
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Color"), /*#__PURE__*/React.createElement("div", {
    className: "cpicker"
  }, GROUP_COLORS.map(function (c) {
    return /*#__PURE__*/React.createElement("div", {
      key: c,
      className: 'cswatch' + (color === c ? ' sel' : ''),
      style: {
        background: c
      },
      onClick: function () {
        setColor(c);
      }
    });
  })))), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "bprimary green",
    onClick: handleCreate,
    disabled: !grpName.trim() || sending
  }, sending && /*#__PURE__*/React.createElement("span", {
    className: "bspinner"
  }), "Create"))));
}
function BrowseGroupsModal(props) {
  var [groups, setGroups] = useState([]);
  var [joiningId, setJoiningId] = useState(null);
  var [loadingG, setLoadingG] = useState(true);
  useEffect(function () {
    apiGet('available_groups').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setGroups(d.data || []);
      setLoadingG(false);
    });
  }, []);
  function joinGroup(gid) {
    setJoiningId(gid);
    fetch(API + '?action=join_group&group_id=' + gid, {
      method: 'POST',
      credentials: 'same-origin'
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setGroups(function (p) {
          return p.map(function (g) {
            return g.id === gid ? Object.assign({}, g, {
              is_member: 1
            }) : g;
          });
        });
        props.onJoined && props.onJoined();
      }
      setJoiningId(null);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "Browse Groups"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, loadingG && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      textAlign: 'center',
      color: 'var(--text-muted)'
    }
  }, "Loading\u2026"), !loadingG && groups.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: 20,
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, "No groups available yet."), !loadingG && groups.map(function (g) {
    return /*#__PURE__*/React.createElement("div", {
      key: g.id,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '10px 12px',
        border: '1.5px solid var(--border)',
        borderRadius: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 38,
        height: 38,
        background: g.avatar_color || '#10B981',
        borderRadius: 9,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 16,
        fontWeight: 800,
        color: 'white',
        flexShrink: 0
      }
    }, g.name[0].toUpperCase()), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13.5,
        fontWeight: 700,
        color: 'var(--text-dark)'
      }
    }, g.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-soft)'
      }
    }, g.member_count, " member", g.member_count != 1 ? 's' : '')), g.is_member == 1 ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        color: '#059669',
        background: '#ECFDF5',
        padding: '3px 9px',
        borderRadius: 5
      }
    }, "Joined") : /*#__PURE__*/React.createElement("button", {
      className: "bprimary green",
      style: {
        padding: '6px 14px',
        fontSize: 12
      },
      onClick: function () {
        joinGroup(g.id);
      },
      disabled: joiningId === g.id
    }, joiningId === g.id ? /*#__PURE__*/React.createElement("span", {
      className: "bspinner"
    }) : 'Join'));
  })), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Close"))));
}
function UploadResModal(props) {
  var [resTitle, setResTitle] = useState('');
  var [resDesc, setResDesc] = useState('');
  var [file, setFile] = useState(null);
  var [sending, setSending] = useState(false);
  var fileRef = useRef(null);
  function handleUpload() {
    if (!resTitle.trim() || !file) return;
    setSending(true);
    var fd = new FormData();
    fd.append('title', resTitle);
    fd.append('description', resDesc);
    fd.append('group_id', props.groupId);
    fd.append('attachment', file);
    apiForm('upload_resource', fd).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) props.onUploaded && props.onUploaded();
      setSending(false);
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "mov",
    onClick: function (e) {
      if (e.target === e.currentTarget) props.onClose && props.onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmodal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pmh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pmt"
  }, "Share a Resource"), /*#__PURE__*/React.createElement("button", {
    className: "pmc",
    onClick: props.onClose
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "pmb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Title ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    className: "finp",
    placeholder: "Resource title\u2026",
    value: resTitle,
    onChange: function (e) {
      setResTitle(e.target.value);
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "Description"), /*#__PURE__*/React.createElement("textarea", {
    className: "ftxt",
    placeholder: "Describe this resource\u2026",
    value: resDesc,
    onChange: function (e) {
      setResDesc(e.target.value);
    },
    style: {
      minHeight: 70
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flbl"
  }, "File ", /*#__PURE__*/React.createElement("span", null, "*")), /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    style: {
      display: 'none'
    },
    accept: "image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.pptx",
    onChange: function (e) {
      if (e.target.files[0]) setFile(e.target.files[0]);
    }
  }), file ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '8px 12px',
      border: '2px solid var(--border)',
      borderRadius: 8,
      background: '#F8FAFC'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 20
    }
  }, fileIcon(file.type)), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 12.5,
      fontWeight: 600
    }
  }, file.name), /*#__PURE__*/React.createElement("button", {
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--text-soft)'
    },
    onClick: function () {
      setFile(null);
    }
  }, "\u2715")) : /*#__PURE__*/React.createElement("button", {
    className: "finp",
    style: {
      cursor: 'pointer',
      textAlign: 'left',
      color: 'var(--text-soft)'
    },
    onClick: function () {
      fileRef.current && fileRef.current.click();
    }
  }, "\uD83D\uDCCE Choose file\u2026"))), /*#__PURE__*/React.createElement("div", {
    className: "pmf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "bcancelbtn",
    onClick: props.onClose
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "bprimary green",
    onClick: handleUpload,
    disabled: !resTitle.trim() || !file || sending
  }, sending && /*#__PURE__*/React.createElement("span", {
    className: "bspinner"
  }), "Share"))));
}

/* ═══════════════════════════════════════
MAIN APP
Reads these URL params on mount:
?report_ref  — student_reports.id (e.g. "1")
?teacher_id  — users.id of the teacher (e.g. "20")
?student     — student name, URI-encoded (e.g. "Emmanuel%20Peter")
?ref         — short reference code (e.g. "RPT-1-DAILY")
When present:
• Messages tab is shown
• A context banner is displayed
• MessagesTab auto-opens the teacher thread
• Compose box is pre-filled with a report-reference message
═══════════════════════════════════════ */
function PulseApp() {
  var reportRef = getUrlParam('report_ref');
  var teacherId = parseInt(getUrlParam('teacher_id'), 10) || 0;
  var studentName = decodeURIComponent(getUrlParam('student') || '');
  var refCode = getUrlParam('ref');
  var [activeTab, setActiveTab] = useState('messages');
  var [myId, setMyId] = useState(0);
  var [collapsed, setCollapsed] = useState(false);
  var [counts, setCounts] = useState({
    dm: 0,
    alerts: 0,
    collab: 0,
    broadcast: 0
  });
  var [showBanner, setShowBanner] = useState(!!reportRef);
  var [darkMode, setDarkMode] = useState(function () {
    try {
      return localStorage.getItem('j11pulse_dark') === '1';
    } catch (e) {
      return false;
    }
  });
  useEffect(function () {
    document.body.classList.toggle('pulse-dark', darkMode);
  }, [darkMode]);
  function toggleDarkMode() {
    setDarkMode(function (d) {
      var next = !d;
      try {
        localStorage.setItem('j11pulse_dark', next ? '1' : '0');
      } catch (e) {}
      return next;
    });
  }
  useEffect(function () {
    apiGet('whoami').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) setMyId(d.data.id);
    });
    function loadCounts() {
      apiGet('unread_counts').then(function (r) {
        return r.json();
      }).then(function (d) {
        if (d.success) setCounts(d.data);
      });
    }
    loadCounts();
    var t = setInterval(loadCounts, 15000);
    return function () {
      clearInterval(t);
    };
  }, []);

  /* Pre-fill message for the compose box */
  var preFillMsg = reportRef ? 'Hi, I would like to discuss the report for ' + (studentName || 'my child') + '. Reference: ' + (refCode || 'RPT-' + reportRef) + '.' : '';
  var TABS = [{
    key: 'messages',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCAC",
      size: 18
    }),
    label: 'Messages',
    dot: '#2563EB',
    badge: counts.dm
  }, {
    key: 'collab',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDC65",
      size: 18
    }),
    label: 'Collaboration Hub',
    dot: '#10B981',
    badge: counts.collab
  }, {
    key: 'alerts',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDD14",
      size: 18
    }),
    label: 'Alerts',
    dot: '#F59E0B',
    badge: counts.alerts
  }, {
    key: 'broadcast',
    icon: /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCE2",
      size: 18
    }),
    label: 'Broadcast',
    dot: '#8B5CF6',
    badge: 0
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ParentNavbar, {
    activePage: "pulse",
    onToggleSidebar: function () {
      setCollapsed(function (c) {
        return !c;
      });
    }
  }), /*#__PURE__*/React.createElement(ParentSidebar, {
    items: PARENT_SIDEBAR_ITEMS,
    activePage: "pulse",
    collapsed: collapsed
  }), /*#__PURE__*/React.createElement("div", {
    className: "layout"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'main-area' + (collapsed ? ' collapsed' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulse-shell"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulse-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulse-brand"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pulse-icon"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    style: {
      width: 22,
      height: 22
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 12h3l3-8 4 16 3-8h7",
    stroke: "white",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "pulse-logo-text"
  }, "J11 Pulse"), /*#__PURE__*/React.createElement("div", {
    className: "pulse-tagline"
  }, "School Communication"))), /*#__PURE__*/React.createElement("span", {
    className: "pulse-role-badge"
  }, "\uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67 Parent Portal"), /*#__PURE__*/React.createElement("button", {
    className: "dark-toggle",
    title: darkMode ? 'Switch to light mode' : 'Switch to dark mode',
    onClick: toggleDarkMode,
    style: {
      marginLeft: 8
    }
  }, darkMode ? /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2600",
    size: 16
  }) : /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF19",
    size: 18
  }))), showBanner && reportRef && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 14px',
      background: 'linear-gradient(90deg,#EFF6FF,#F0FDF4)',
      border: '1.5px solid #BFDBFE',
      borderRadius: 10,
      marginBottom: 12,
      flexWrap: 'wrap',
      rowGap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 17
    }
  }, "\uD83D\uDCCB"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 160
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      fontWeight: 800,
      color: '#1E3A8A'
    }
  }, "Opened from report:", ' ', /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'monospace',
      background: '#DBEAFE',
      padding: '1px 7px',
      borderRadius: 4,
      color: '#1D4ED8'
    }
  }, refCode || 'RPT-' + reportRef)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5,
      color: '#3B82F6',
      marginTop: 2
    }
  }, studentName ? 'Student: ' + studentName + ' — ' : '', teacherId ? "The teacher's conversation is highlighted in the list." : 'Select a teacher to start a conversation.')), /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      setShowBanner(false);
    },
    style: {
      fontSize: 12,
      color: '#94A3B8',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: '3px 7px',
      borderRadius: 5,
      flexShrink: 0
    }
  }, "\u2715 Dismiss")), /*#__PURE__*/React.createElement("div", {
    className: "pulse-tabs"
  }, TABS.map(function (t) {
    return /*#__PURE__*/React.createElement("button", {
      key: t.key,
      className: 'pulse-tab' + (activeTab === t.key ? ' active' : ''),
      onClick: function () {
        setActiveTab(t.key);
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "tab-dot",
      style: {
        background: activeTab === t.key ? t.dot : '#CBD5E1'
      }
    }), renderIcon(t.icon, 20), " ", t.label, t.badge > 0 && /*#__PURE__*/React.createElement("span", {
      className: "tab-badge",
      style: {
        background: t.dot
      }
    }, t.badge));
  })), /*#__PURE__*/React.createElement("div", {
    className: "pulse-content"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: activeTab === 'messages' ? 'contents' : 'none'
    }
  }, /*#__PURE__*/React.createElement(MessagesTab, {
    myId: myId,
    deepTeacherId: teacherId,
    preFillMsg: preFillMsg,
    reportRef: reportRef
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: activeTab === 'collab' ? 'contents' : 'none'
    }
  }, /*#__PURE__*/React.createElement(CollabTab, {
    myId: myId
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: activeTab === 'alerts' ? 'contents' : 'none'
    }
  }, /*#__PURE__*/React.createElement(AlertsTab, null)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: activeTab === 'broadcast' ? 'contents' : 'none'
    }
  }, /*#__PURE__*/React.createElement(BroadcastTab, null)))))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(PulseApp, null));