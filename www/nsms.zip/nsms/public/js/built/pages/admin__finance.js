const {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo
} = React;

/* ── Formatters ── */
const fmtM = v => {
  const n = Number(v) || 0;
  if (n >= 1000000) return 'TSh ' + (n / 1000000).toFixed(3) + 'M';
  if (n >= 1000) return 'TSh ' + (n / 1000).toFixed(1) + 'K';
  return 'TSh ' + n.toLocaleString();
};
/* fmtNet: always shows full exact number so minor expenses are always visible */
const fmtNet = v => {
  const n = Number(v) || 0;
  const abs = Math.abs(n);
  const sign = n < 0 ? '− ' : '';
  return sign + 'TSh ' + abs.toLocaleString('en-TZ', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  });
};
const fmtF = v => 'TSh ' + (Number(v) || 0).toLocaleString('en-TZ', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 0
});
const fmtD = v => {
  if (!v) return '—';
  const d = new Date((v + '').replace(' ', 'T'));
  return isNaN(d) ? v : d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
};
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const curY = () => new Date().getFullYear();
const curM = () => new Date().getMonth() + 1;
const toMS = (y, m) => `${y}-${String(m).padStart(2, '0')}`;
const mLbl = m => {
  const [y, mo] = m.split('-');
  return new Date(y, mo - 1, 1).toLocaleDateString('en-GB', {
    month: 'long',
    year: 'numeric'
  });
};
const mbadge = m => {
  if (!m) return 'xgr';
  if (m === 'Cash') return 'xg';
  if (m === 'M-Pesa') return 'xb';
  if (m === 'Bank Transfer') return 'xy';
  if (m === 'Cheque') return 'xgr';
  if (m.startsWith('Scholarship')) return 'xp';
  if (['Tigo Pesa', 'Airtel Money', 'HaloPesa', 'Mixx by Yas'].includes(m)) return 'xb';
  if (['Visa', 'Mastercard'].includes(m)) return 'xv';
  return 'xgr';
};
const methodDisplay = m => {
  if (!m) return m;
  const p = 'Scholarship (';
  if (m.startsWith(p) && m.endsWith(')')) return 'Scholarship — ' + m.slice(p.length, -1);
  return m;
};
const AV_COLORS = ['#2563EB', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0891B2'];
const avColor = n => n ? AV_COLORS[n.charCodeAt(0) % AV_COLORS.length] : '#94A3B8';
const navInitials = n => n ? n.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) : '?';
async function apiFetch(url) {
  try {
    const r = await fetch(url);
    const raw = await r.text();
    try {
      return JSON.parse(raw);
    } catch (e) {
      return {
        success: false,
        error: 'Server error: ' + raw.slice(0, 300)
      };
    }
  } catch (e) {
    return {
      success: false,
      error: 'Network error: ' + e.message
    };
  }
}
async function apiPost(url, body) {
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });
    const raw = await r.text();
    try {
      return JSON.parse(raw);
    } catch (e) {
      return {
        success: false,
        error: 'Server error: ' + raw.slice(0, 300)
      };
    }
  } catch (e) {
    return {
      success: false,
      error: 'Network error: ' + e.message
    };
  }
}

/* ═══════════════════════════════════════════
   COUNT-UP (animated number)
═══════════════════════════════════════════ */
function useCountUp(target, duration) {
  duration = duration || 900;
  const [val, setVal] = React.useState(0);
  const rafRef = React.useRef(null);
  React.useEffect(() => {
    const start = performance.now();
    cancelAnimationFrame(rafRef.current);
    const tick = now => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(target * eased);
      if (p < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [target, duration]);
  return val;
}

/* ═══════════════════════════════════════════
   TREND CHART
═══════════════════════════════════════════ */
function TrendChart({ data }) {
  const [hover, setHover] = React.useState(null);

  if (!data || !data.length) {
    return /*#__PURE__*/React.createElement("div", { className: "nsms-trend-empty" },
      "No revenue recorded in the last 6 months yet.");
  }

  const fmtShort = v => {
    const n = Number(v) || 0;
    if (n >= 1e6) return (n / 1e6).toFixed(n % 1e6 < 1000 ? 0 : 1) + "M";
    if (n >= 1e3) return (n / 1e3).toFixed(n % 1e3 < 10 ? 0 : 1) + "K";
    return String(Math.round(n));
  };
  const fmtFull = v => "TSh " + Math.round(Number(v) || 0).toLocaleString();

  const W = 720, H = 220, PL = 52, PR = 20, PT = 24, PB = 40;
  const values = data.map(d => Number(d.revenue) || 0);
  const maxV = Math.max(...values, 1);
  const chartW = W - PL - PR;
  const chartH = H - PT - PB;
  const n = data.length;
  const xs = data.map((_, i) => PL + (n === 1 ? chartW / 2 : i * (chartW / Math.max(n - 1, 1))));
  const ys = values.map(v => PT + chartH - v / maxV * chartH);
  const baseY = PT + chartH;

  const smoothLine = () => {
    if (xs.length === 1) return "M" + xs[0] + "," + ys[0];
    let d = "M" + xs[0] + "," + ys[0];
    for (let i = 0; i < xs.length - 1; i++) {
      const x0 = xs[i], y0 = ys[i], x1 = xs[i + 1], y1 = ys[i + 1];
      const cx = (x0 + x1) / 2;
      d += " C" + cx + "," + y0 + " " + cx + "," + y1 + " " + x1 + "," + y1;
    }
    return d;
  };
  const line = smoothLine();
  const area = line + " L" + xs[xs.length - 1] + "," + baseY + " L" + xs[0] + "," + baseY + " Z";

  const gridLines = [];
  for (let i = 0; i <= 4; i++) {
    const t = i / 4;
    gridLines.push({ y: PT + chartH * (1 - t), val: maxV * t });
  }

  const total = values.reduce((s, v) => s + v, 0);
  const peak = Math.max(...values);
  const peakIdx = values.indexOf(peak);
  const peakMonth = peakIdx >= 0 && data[peakIdx] ? String(data[peakIdx].label || "").split(" ")[0] : "—";
  const activeMonths = values.filter(v => v > 0).length;
  const avg = activeMonths ? total / activeMonths : 0;
  const last = values[values.length - 1] || 0;
  const prev = values.length > 1 ? values[values.length - 2] : 0;
  let growthLabel = "—";
  let growthClass = "";
  if (prev > 0) {
    const pct = (last - prev) / prev * 100;
    growthLabel = (pct >= 0 ? "+" : "") + pct.toFixed(1) + "%";
    growthClass = pct >= 0 ? "growth-up" : "growth-down";
  } else if (last > 0) {
    growthLabel = "New";
    growthClass = "growth-up";
  }

  const Stat = ({ label, value, sub, extraClass }) =>
    /*#__PURE__*/React.createElement("div", {
      className: "nsms-trend-stat" + (extraClass ? " " + extraClass : ""),
      "data-no-emoji": "1"
    },
      /*#__PURE__*/React.createElement("div", { className: "nsms-trend-stat-label" }, label),
      /*#__PURE__*/React.createElement("div", { className: "nsms-trend-stat-value" }, value),
      sub ? /*#__PURE__*/React.createElement("div", { className: "nsms-trend-stat-sub" }, sub) : null
    );

  return /*#__PURE__*/React.createElement("div", {
    className: "nsms-trend-wrap",
    "data-no-emoji": "1"
  },
    /*#__PURE__*/React.createElement("div", { className: "nsms-trend-stats" },
      React.createElement(Stat, { label: "6-month total", value: fmtFull(total) }),
      React.createElement(Stat, { label: "Peak month", value: fmtFull(peak), sub: peakMonth, extraClass: "accent" }),
      React.createElement(Stat, { label: "Avg (active months)", value: fmtFull(avg) }),
      React.createElement(Stat, { label: "vs last month", value: growthLabel, extraClass: growthClass })
    ),
    /*#__PURE__*/React.createElement("div", { className: "nsms-trend-chart-card" },
      /*#__PURE__*/React.createElement("svg", {
        viewBox: "0 0 " + W + " " + H,
        width: "100%",
        className: "nsms-trend-svg",
        role: "img",
        "aria-label": "Revenue trend last 6 months"
      },
        /*#__PURE__*/React.createElement("defs", null,
          /*#__PURE__*/React.createElement("linearGradient", { id: "nsmsTrendFill", x1: "0", y1: "0", x2: "0", y2: "1" },
            /*#__PURE__*/React.createElement("stop", { offset: "0%", stopColor: "#2563EB", stopOpacity: "0.28" }),
            /*#__PURE__*/React.createElement("stop", { offset: "70%", stopColor: "#3B82F6", stopOpacity: "0.08" }),
            /*#__PURE__*/React.createElement("stop", { offset: "100%", stopColor: "#93C5FD", stopOpacity: "0.02" })
          ),
          /*#__PURE__*/React.createElement("linearGradient", { id: "nsmsTrendStroke", x1: "0", y1: "0", x2: "1", y2: "0" },
            /*#__PURE__*/React.createElement("stop", { offset: "0%", stopColor: "#1D4ED8" }),
            /*#__PURE__*/React.createElement("stop", { offset: "100%", stopColor: "#0EA5E9" })
          )
        ),
        xs.map((x, i) => {
          const barH = Math.max(0, baseY - ys[i]);
          const barW = Math.min(28, chartW / Math.max(n, 1) * 0.35);
          return /*#__PURE__*/React.createElement("rect", {
            key: "bar" + i,
            x: x - barW / 2,
            y: ys[i],
            width: barW,
            height: barH,
            rx: "6",
            fill: values[i] > 0 ? "rgba(37,99,235,0.10)" : "rgba(148,163,184,0.06)"
          });
        }),
        gridLines.map((g, i) => /*#__PURE__*/React.createElement("g", { key: "grid" + i },
          /*#__PURE__*/React.createElement("line", {
            x1: PL, y1: g.y, x2: W - PR, y2: g.y,
            stroke: i === 0 ? "#CBD5E1" : "#E2E8F0",
            strokeWidth: "1",
            strokeDasharray: i === 0 ? "0" : "5 5"
          }),
          /*#__PURE__*/React.createElement("text", {
            x: PL - 10, y: g.y + 3.5, textAnchor: "end",
            fontSize: "10", fill: "#94A3B8",
            fontFamily: "Plus Jakarta Sans, system-ui, sans-serif"
          }, fmtShort(g.val))
        )),
        /*#__PURE__*/React.createElement("path", { d: area, fill: "url(#nsmsTrendFill)" }),
        /*#__PURE__*/React.createElement("path", {
          d: line, fill: "none", stroke: "url(#nsmsTrendStroke)",
          strokeWidth: "3.25", strokeLinejoin: "round", strokeLinecap: "round"
        }),
        xs.map((x, i) => {
          const rev = values[i];
          const active = hover === i;
          const lbl = String(data[i].label || "").split(" ")[0];
          return /*#__PURE__*/React.createElement("g", {
            key: "pt" + i,
            onMouseEnter: () => setHover(i),
            onMouseLeave: () => setHover(null),
            style: { cursor: "pointer" }
          },
            /*#__PURE__*/React.createElement("line", {
              x1: x, y1: PT, x2: x, y2: baseY,
              stroke: active ? "rgba(37,99,235,0.12)" : "transparent",
              strokeWidth: "24"
            }),
            active && /*#__PURE__*/React.createElement("g", null,
              /*#__PURE__*/React.createElement("rect", {
                x: Math.min(Math.max(x - 44, PL), W - PR - 88),
                y: Math.max(ys[i] - 38, 6),
                width: "88", height: "30", rx: "8",
                fill: "#0F172A"
              }),
              /*#__PURE__*/React.createElement("text", {
                x: Math.min(Math.max(x, PL + 44), W - PR - 44),
                y: Math.max(ys[i] - 18, 26),
                textAnchor: "middle", fontSize: "12", fontWeight: "700",
                fill: "#F8FAFC",
                fontFamily: "Plus Jakarta Sans, system-ui, sans-serif"
              }, fmtFull(rev))
            ),
            /*#__PURE__*/React.createElement("circle", {
              cx: x, cy: ys[i],
              r: active ? 8 : (rev > 0 ? 6 : 4.5),
              fill: "#fff",
              stroke: rev > 0 ? "#2563EB" : "#CBD5E1",
              strokeWidth: active ? 3.5 : 2.5
            }),
            /*#__PURE__*/React.createElement("text", {
              x: x, y: H - 14, textAnchor: "middle",
              fontSize: "12",
              fontWeight: active || i === peakIdx ? "700" : "500",
              fill: active || i === peakIdx ? "#1E293B" : "#64748B",
              fontFamily: "Plus Jakarta Sans, system-ui, sans-serif"
            }, lbl)
          );
        })
      )
    )
  );
}


function InstDots({
  slots
}) {
  if (!slots || !slots.length) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "idots"
  }, slots.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.no,
    className: "idot",
    title: `Inst.${s.no}: ${s.status} — ${fmtF(s.amount_paid)}/${fmtF(s.amount_due)}`,
    style: {
      background: s.status === 'paid' ? '#10B981' : s.amount_due === 0 ? '#A78BFA' : s.status === 'partial' ? '#F59E0B' : '#E2E8F0',
      color: s.status === 'unpaid' && s.amount_due > 0 ? '#94A3B8' : '#fff'
    }
  }, s.no)));
}

/* ═══════════════════════════════════════════
   STUDENT SEARCH (reusable)
═══════════════════════════════════════════ */
function StudentSearch({
  onSelect,
  placeholder
}) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const dbt = useRef();
  useEffect(() => {
    clearTimeout(dbt.current);
    if (q.length < 2) {
      setResults([]);
      return;
    }
    dbt.current = setTimeout(async () => {
      const d = await apiFetch(`/nsms/api/finance.php?action=students_list&q=${encodeURIComponent(q)}`);
      if (d.success) setResults(d.data);
    }, 300);
  }, [q]);
  return /*#__PURE__*/React.createElement("div", {
    className: "srw"
  }, /*#__PURE__*/React.createElement("input", {
    className: "fi",
    placeholder: placeholder || 'Search student…',
    value: q,
    onChange: e => setQ(e.target.value),
    autoFocus: true
  }), results.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "srd"
  }, results.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.id,
    className: "sri",
    onClick: () => {
      onSelect(s);
      setQ('');
      setResults([]);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "srn"
  }, s.student_name), /*#__PURE__*/React.createElement("div", {
    className: "srs"
  }, s.class_name, s.parent_name && ` · ${s.parent_name}`)))), q.length >= 2 && results.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "srd"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 14px',
      color: '#94A3B8',
      fontSize: 14
    }
  }, "No students found")));
}

/* ═══════════════════════════════════════════
   PAYMENT MODAL
═══════════════════════════════════════════ */
function PaymentModal({
  onClose,
  onSaved
}) {
  const [step, setStep] = useState(1);
  const [student, setStudent] = useState(null);
  const [pStatus, setPStatus] = useState(null);
  const [pLoading, setPLoading] = useState(false);
  const [form, setForm] = useState({
    method: 'Cash',
    date: new Date().toISOString().split('T')[0],
    ref: '',
    notes: '',
    amount: ''
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [receipt, setReceipt] = useState(null);
  const [assigningTp, setAssigningTp] = useState(false);
  const loadStatus = useCallback(async sid => {
    setPLoading(true);
    const d = await apiFetch(`/nsms/api/finance.php?action=student_payment_status&student_id=${sid}`);
    if (d.success) setPStatus(d.data);else setErr(d.error || 'Failed to load status');
    setPLoading(false);
  }, []);
  useEffect(() => {
    if (!student) {
      setPStatus(null);
      return;
    }
    setErr('');
    loadStatus(student.id);
  }, [student, loadStatus]);
  const alloc = useMemo(() => {
    if (!pStatus || !form.amount) return null;
    const recv = Number(form.amount);
    if (recv <= 0) return null;
    let rem = recv;
    const steps = [];
    for (const [ft, amt] of Object.entries(pStatus.one_time_fees || {})) {
      const paid = Math.min(pStatus.total_paid, amt);
      const owed = Math.max(0, amt - paid);
      if (owed > 0 && rem > 0) {
        const pay = Math.min(owed, rem);
        steps.push({
          label: ft,
          amount: pay
        });
        rem -= pay;
      }
    }
    const sf = (pStatus.installments || {})['School Fees'] || [];
    for (const inst of sf) {
      if (inst.status === 'paid' || inst.amount_due === 0) continue;
      if (rem <= 0) break;
      const owed = inst.amount_due - inst.amount_paid;
      const minP = Math.max(0.01, +(inst.amount_due * 0.10).toFixed(2));
      if (rem < minP) break;
      const pay = Math.min(owed, rem);
      steps.push({
        label: `School Fees — Inst.${inst.no}`,
        amount: pay
      });
      rem -= pay;
    }
    // Step 3: Transport installments (if assigned, allocated after mandatory fees)
    if (pStatus.transport_assigned) {
      const tp = (pStatus.installments || {})['Transport'] || [];
      for (const inst of tp) {
        if (inst.status === 'paid' || inst.amount_due === 0) continue;
        if (rem <= 0) break;
        const owed = inst.amount_due - inst.amount_paid;
        if (owed <= 0) continue;
        const pay = Math.min(owed, rem);
        steps.push({
          label: `Transport — Inst.${inst.no}`,
          amount: pay
        });
        rem -= pay;
      }
    }
    return {
      steps,
      remaining: rem
    };
  }, [pStatus, form.amount]);
  const set = (k, v) => setForm(p => ({
    ...p,
    [k]: v
  }));
  const toggleTransport = async () => {
    if (!pStatus || !student) return;
    setAssigningTp(true);
    const action = pStatus.transport_assigned ? 'remove_transport' : 'assign_transport';
    const d = await apiPost(`/nsms/api/finance.php?action=${action}`, {
      student_id: student.id
    });
    if (d.success) loadStatus(student.id);else setErr(d.error || 'Failed');
    setAssigningTp(false);
  };
  const submit = async () => {
    if (!student) {
      setErr('Select a student');
      return;
    }
    if (!form.amount || Number(form.amount) <= 0) {
      setErr('Enter the amount received');
      return;
    }
    if (pStatus && pStatus.fully_paid) {
      setErr('Student has no outstanding balance');
      return;
    }
    setSaving(true);
    setErr('');
    const d = await apiPost('/nsms/api/finance.php?action=record_payment', {
      student_id: student.id,
      amount: Number(form.amount),
      payment_method: form.method,
      payment_date: form.date,
      reference_number: form.ref || null,
      notes: form.notes || null
    });
    setSaving(false);
    if (d.success) {
      setReceipt(d.data);
      setStep(2);
      onSaved();
    } else setErr(d.error || 'Failed');
  };
  const reset = () => {
    setStep(1);
    setReceipt(null);
    setStudent(null);
    setPStatus(null);
    set('amount', '');
  };

  /* Receipt */
  if (step === 2 && receipt) return /*#__PURE__*/React.createElement("div", {
    className: "ov",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    style: {
      maxWidth: 460
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "mh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mht"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " Payment Recorded"), /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mb",
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 48,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF89",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "rbox"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rlbl"
  }, "RECEIPT NUMBER"), /*#__PURE__*/React.createElement("div", {
    className: "rnum"
  }, receipt.receipt_number), /*#__PURE__*/React.createElement("div", {
    className: "rdet"
  }, /*#__PURE__*/React.createElement("strong", null, receipt.student_name), /*#__PURE__*/React.createElement("br", null), fmtF(receipt.amount), " \u2014 ", form.method, /*#__PURE__*/React.createElement("br", null), fmtD(form.date), receipt.discount_pct > 0 && /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFF7\uFE0F",
    size: 18
  }), " ", receipt.discount_pct, "% discount on School Fees"))), receipt.allocations && receipt.allocations.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'left',
      marginTop: 12,
      background: '#F8FAFC',
      borderRadius: 8,
      padding: '10px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: '#64748B',
      marginBottom: 6,
      textTransform: 'uppercase'
    }
  }, "Allocated to"), receipt.allocations.map((a, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 13,
      padding: '3px 0',
      borderBottom: '1px solid #E2E8F0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#475569'
    }
  }, a.fee_type, a.installment_no ? ` — Inst.${a.installment_no}` : ''), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      color: '#10B981'
    }
  }, fmtF(a.amount)))), receipt.remaining > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#F59E0B',
      fontWeight: 600,
      paddingTop: 5
    }
  }, "Unallocated: ", fmtF(receipt.remaining)))), /*#__PURE__*/React.createElement("div", {
    className: "mf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: reset
  }, "Record Another"), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: onClose
  }, "Done"))));

  /* Form */
  return /*#__PURE__*/React.createElement("div", {
    className: "ov",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal wide",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "mh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mht"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB5",
    size: 18
  }), " Record Payment"), /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mb"
  }, err && /*#__PURE__*/React.createElement("div", {
    className: "ferr"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", err), /*#__PURE__*/React.createElement("div", {
    className: "fsec"
  }, "Student"), student ? /*#__PURE__*/React.createElement("div", {
    className: "selstu"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "seln"
  }, student.student_name), /*#__PURE__*/React.createElement("div", {
    className: "selsb"
  }, student.class_name, student.parent_name && ` · ${student.parent_name}`)), /*#__PURE__*/React.createElement("button", {
    className: "clrb",
    onClick: () => {
      setStudent(null);
      setPStatus(null);
      set('amount', '');
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))) : /*#__PURE__*/React.createElement(StudentSearch, {
    onSelect: setStudent,
    placeholder: "Search student by name or parent\u2026"
  }), pLoading && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      padding: '12px 0',
      color: '#64748B',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner",
    style: {
      width: 18,
      height: 18,
      borderWidth: 2
    }
  }), "Loading status\u2026"), pStatus && !pLoading && (pStatus.migration_needed ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FFF7ED',
      border: '2px solid #FED7AA',
      borderRadius: 10,
      padding: '14px 16px',
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 14,
      color: '#92400E',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " Database migration required"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#B45309'
    }
  }, "The finance tables have not been created yet. Please run ", /*#__PURE__*/React.createElement("code", {
    style: {
      background: 'rgba(0,0,0,.08)',
      padding: '1px 5px',
      borderRadius: 4
    }
  }, "finance_migration.sql"), " on your database, then refresh the page.")) : pStatus.no_fees_configured ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FFF7ED',
      border: '2px solid #FED7AA',
      borderRadius: 10,
      padding: '14px 16px',
      marginTop: 12,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 14,
      color: '#92400E'
    }
  }, "No fee structure configured"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#B45309',
      marginTop: 4
    }
  }, "Set up fees for ", /*#__PURE__*/React.createElement("strong", null, pStatus.class_name), " in the Fee Structure tab first.")) : pStatus.fully_paid ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#F0FDF4',
      border: '2px solid #86EFAC',
      borderRadius: 10,
      padding: '14px 16px',
      marginTop: 12,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 26,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 15,
      color: '#166534'
    }
  }, "All fees fully paid!"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#166534',
      marginTop: 4,
      opacity: .8
    }
  }, pStatus.student_name, " has no outstanding balance for ", pStatus.academic_year, ".", pStatus.transport_assigned && /*#__PURE__*/React.createElement("span", null, " Transport fees are also settled.")), pStatus.scholarship_total > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      background: '#EDE9FE',
      border: '1px solid #C4B5FD',
      borderRadius: 20,
      padding: '4px 14px',
      fontSize: 13,
      color: '#5B21B6'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), " ", fmtF(pStatus.scholarship_total), " covered by scholarship")) : pStatus.mandatory_complete && !pStatus.transport_assigned ?
  /*#__PURE__*/
  /* Mandatory fees done, transport NOT yet assigned — prompt admin */
  React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#F0FDF4',
      border: '2px solid #86EFAC',
      borderRadius: 10,
      padding: '14px 16px',
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 15,
      color: '#166534'
    }
  }, "Mandatory fees complete!"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#166534',
      opacity: .85,
      marginTop: 3
    }
  }, "All one-time fees and school fees installments are fully paid."), pStatus.scholarship_total > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      background: '#EDE9FE',
      border: '1px solid #C4B5FD',
      borderRadius: 20,
      padding: '3px 12px',
      fontSize: 12,
      color: '#5B21B6'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), " ", fmtF(pStatus.scholarship_total), " covered by scholarship")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "fsec"
  }, "Transport (Optional)"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#64748B',
      marginBottom: 8
    }
  }, "This student is not assigned to transport. Would you like to add it?"), /*#__PURE__*/React.createElement("div", {
    className: `tog${pStatus.transport_assigned ? ' on' : ''}`,
    onClick: assigningTp ? undefined : toggleTransport,
    style: {
      opacity: assigningTp ? .6 : 1
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "tog-lbl"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDE8C",
    size: 18
  }), " Assign Transport Service"), /*#__PURE__*/React.createElement("div", {
    className: "tog-sub"
  }, "Click to activate \u2014 transport fees are optional")), /*#__PURE__*/React.createElement("div", {
    className: `tog-sw${pStatus.transport_assigned ? ' on' : ''}`
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#94A3B8',
      marginTop: 6
    }
  }, "If this student does not use transport, you can close this dialog."))) : /*#__PURE__*/React.createElement("div", null, pStatus.scholarship_total > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: '#EDE9FE',
      border: '1px solid #C4B5FD',
      borderRadius: 10,
      padding: '10px 14px',
      marginTop: 10,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 13,
      color: '#5B21B6'
    }
  }, "Scholarship applied \u2014 ", fmtF(pStatus.scholarship_total)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#7C3AED',
      marginTop: 1
    }
  }, "Fees covered by scholarship are marked below. Remaining balance must be paid."))), pStatus.discount_pct > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      background: '#EDE9FE',
      border: '1px solid #C4B5FD',
      borderRadius: 20,
      padding: '4px 12px',
      fontSize: 13,
      color: '#5B21B6',
      marginTop: 10,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFF7\uFE0F",
    size: 18
  }), " ", /*#__PURE__*/React.createElement("strong", null, pStatus.discount_pct, "% discount"), " \u2014 School Fees only"), (() => {
    const totalFees = pStatus.grand_total + (pStatus.transport_assigned ? pStatus.transport_total : 0);
    const tpOwed = pStatus.transport_assigned && !pStatus.transport_complete ? Math.max(0, pStatus.transport_total - pStatus.transport_paid) : 0;
    const balOwed = pStatus.balance_owed + tpOwed;
    const schAmt = pStatus.scholarship_total || 0;
    const hasSch = schAmt > 0;
    const cashPaid = Math.max(0, pStatus.total_paid - schAmt);
    const cols = hasSch ? '1fr 1fr 1fr 1fr' : '1fr 1fr 1fr';
    const stats = hasSch ? [['Total Fees', totalFees, '#1E293B', false], ['Scholarship', schAmt, '#7C3AED', true], ['Cash Paid', cashPaid, '#10B981', false], ['Balance Owed', balOwed, '#EF4444', false]] : [['Total Fees', totalFees, '#1E293B', false], ['Total Paid', pStatus.total_paid, '#10B981', false], ['Balance Owed', balOwed, '#EF4444', false]];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: cols,
        gap: 8,
        marginTop: 12,
        marginBottom: 4
      }
    }, stats.map(([lbl, val, col, isSch]) => /*#__PURE__*/React.createElement("div", {
      key: lbl,
      style: {
        background: isSch ? '#F5F3FF' : '#F8FAFC',
        borderRadius: 8,
        padding: '9px 12px',
        textAlign: 'center',
        border: isSch ? '1px solid #DDD6FE' : 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: isSch ? '#7C3AED' : '#94A3B8',
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '.4px'
      }
    }, isSch ? lbl : lbl), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: col,
        marginTop: 3
      }
    }, fmtF(val)), isSch && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: '#A78BFA',
        marginTop: 2
      }
    }, "auto-applied"))));
  })(), Object.keys(pStatus.one_time_fees || {}).length > 0 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "fsec",
    style: {
      marginTop: 14
    }
  }, "One-time Fees (paid upfront)"), (() => {
    let budgetLeft = pStatus.total_paid;
    return Object.entries(pStatus.one_time_fees).map(([ft, amt]) => {
      const covered = Math.min(amt, Math.max(0, budgetLeft));
      budgetLeft = Math.max(0, budgetLeft - amt);
      const isPaid = covered >= amt;
      const isPartial = covered > 0 && !isPaid;
      return /*#__PURE__*/React.createElement("div", {
        key: ft,
        style: {
          display: 'flex',
          justifyContent: 'space-between',
          padding: '7px 10px',
          borderRadius: 7,
          background: isPaid ? '#F0FDF4' : isPartial ? '#FFFBEB' : '#FFF7ED',
          marginBottom: 5,
          border: `1px solid ${isPaid ? '#86EFAC' : isPartial ? '#FDE68A' : '#FED7AA'}`,
          fontSize: 13
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          color: '#475569'
        }
      }, ft), /*#__PURE__*/React.createElement("span", {
        style: {
          fontWeight: 700,
          color: isPaid ? '#10B981' : isPartial ? '#D97706' : '#F59E0B'
        }
      }, isPaid ? /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'inline-flex',
          gap: 6,
          alignItems: 'center'
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "check-circle",
        size: 14
      }), " Paid") : isPartial ? `⏳ ${fmtF(covered)} of ${fmtF(amt)}` : `Owed ${fmtF(amt)}`));
    });
  })()), (pStatus.installments || {})['School Fees'] && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "fsec",
    style: {
      marginTop: 14
    }
  }, "School Fees Installments", /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      color: '#64748B',
      marginLeft: 8,
      fontSize: 12
    }
  }, (pStatus.installments['School Fees'] || []).filter(s => s.status === 'paid' || s.amount_due === 0).length, "/10 done")), /*#__PURE__*/React.createElement(InstDots, {
    slots: pStatus.installments['School Fees']
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#94A3B8',
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDFE2",
    size: 18
  }), " Paid \xB7 ", /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDFE1",
    size: 18
  }), " Partial \xB7 ", /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDFE3",
    size: 18
  }), " 100% disc \xB7 ", /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26AA",
    size: 18
  }), " Unpaid")), /*#__PURE__*/React.createElement("div", {
    className: "fsec",
    style: {
      marginTop: 14
    }
  }, "Transport (Optional)"), pStatus.mandatory_complete && pStatus.transport_assigned && !pStatus.transport_complete && /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FFF7ED',
      border: '1px solid #FED7AA',
      borderRadius: 8,
      padding: '8px 12px',
      marginBottom: 8,
      fontSize: 13,
      color: '#92400E'
    }
  }, "\u2139\uFE0F Mandatory fees are complete. Proceed to pay transport fees below."), /*#__PURE__*/React.createElement("div", {
    className: `tog${pStatus.transport_assigned ? ' on' : ''}`,
    onClick: assigningTp ? undefined : toggleTransport,
    style: {
      opacity: assigningTp ? .6 : 1
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "tog-lbl"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDE8C",
    size: 18
  }), " Transport Fee"), /*#__PURE__*/React.createElement("div", {
    className: "tog-sub"
  }, pStatus.transport_assigned ? `Assigned — ${fmtF(pStatus.transport_total)} annual${pStatus.transport_complete ? ' · ✅ Paid' : ''}` : 'Not assigned — click to add transport for this student')), /*#__PURE__*/React.createElement("div", {
    className: `tog-sw${pStatus.transport_assigned ? ' on' : ''}`
  })), pStatus.transport_assigned && (pStatus.installments || {})['Transport'] && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(InstDots, {
    slots: pStatus.installments['Transport']
  })), /*#__PURE__*/React.createElement("div", {
    className: "fsec",
    style: {
      marginTop: 18
    }
  }, "Amount Received"), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Amount (TSh)", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      color: '#94A3B8',
      marginLeft: 6,
      fontSize: 12
    }
  }, "\u2014 one-time fees first, then School Fees, then Transport")), /*#__PURE__*/React.createElement("input", {
    type: "number",
    className: "fi",
    placeholder: "e.g. 300000",
    min: "0",
    value: form.amount,
    onChange: e => set('amount', e.target.value)
  })), alloc && alloc.steps.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#EFF6FF',
      border: '1px solid #BFDBFE',
      borderRadius: 8,
      padding: '10px 14px',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: '#1E40AF',
      textTransform: 'uppercase',
      letterSpacing: '.5px',
      marginBottom: 7
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  }), " Allocation Preview"), alloc.steps.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 13,
      padding: '3px 0',
      borderBottom: '1px solid #DBEAFE'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#1E40AF'
    }
  }, s.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: '#2563EB'
    }
  }, fmtF(s.amount)))), alloc.remaining > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#F59E0B',
      fontWeight: 600,
      paddingTop: 5
    }
  }, "Unallocated carry-over: ", fmtF(alloc.remaining))), /*#__PURE__*/React.createElement("div", {
    className: "fsec"
  }, "Payment Details"), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Method", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("select", {
    className: "fs",
    value: form.method,
    onChange: e => set('method', e.target.value)
  }, /*#__PURE__*/React.createElement("option", null, "Cash"), /*#__PURE__*/React.createElement("option", null, "M-Pesa"), /*#__PURE__*/React.createElement("option", null, "Bank Transfer"), /*#__PURE__*/React.createElement("option", null, "Cheque"), /*#__PURE__*/React.createElement("option", null, "Tigo Pesa"), /*#__PURE__*/React.createElement("option", null, "Airtel Money"), /*#__PURE__*/React.createElement("option", null, "HaloPesa"), /*#__PURE__*/React.createElement("option", null, "Mixx by Yas"), /*#__PURE__*/React.createElement("option", null, "Visa"), /*#__PURE__*/React.createElement("option", null, "Mastercard"))), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Date", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "fi",
    value: form.date,
    onChange: e => set('date', e.target.value)
  }))), form.method !== 'Cash' && /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Reference / Control Number"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "fi",
    placeholder: "Transaction or control number",
    value: form.ref,
    onChange: e => set('ref', e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Notes (optional)"), /*#__PURE__*/React.createElement("textarea", {
    className: "fi",
    placeholder: "Any notes\u2026",
    value: form.notes,
    onChange: e => set('notes', e.target.value)
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "mf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: onClose,
    disabled: saving
  }, "Cancel"), pStatus && !pStatus.fully_paid && !pStatus.no_fees_configured && !pStatus.migration_needed && !(pStatus.mandatory_complete && !pStatus.transport_assigned) && /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: submit,
    disabled: saving
  }, saving ? 'Recording…' : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 6,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check-circle",
    size: 16
  }), " Record Payment")))));
}

/* ═══════════════════════════════════════════
   EXPENSE MODAL
═══════════════════════════════════════════ */
const EXP_CATS = ['Salaries and Wages', 'Utilities (Electricity)', 'Utilities (Water)', 'Utilities (Internet)', 'Stationery and Supplies', 'Maintenance and Repairs', 'Cleaning and Sanitation', 'Transport', 'Food & Catering', 'Equipment Purchase', 'Insurance', 'Printing', 'Other'];
function ExpenseModal({
  onClose,
  onSaved
}) {
  const [form, setForm] = useState({
    cat: '',
    desc: '',
    amount: '',
    method: 'Cash',
    date: new Date().toISOString().split('T')[0],
    ref: ''
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const set = (k, v) => setForm(p => ({
    ...p,
    [k]: v
  }));
  const submit = async e => {
    e.preventDefault();
    if (!form.cat) {
      setErr('Select a category');
      return;
    }
    if (!form.desc) {
      setErr('Enter a description');
      return;
    }
    if (!form.amount || Number(form.amount) <= 0) {
      setErr('Enter a valid amount');
      return;
    }
    setSaving(true);
    setErr('');
    const d = await apiPost('/nsms/api/finance.php?action=record_expense', {
      category: form.cat,
      description: form.desc,
      amount: Number(form.amount),
      payment_method: form.method,
      expense_date: form.date,
      reference_number: form.ref || null
    });
    setSaving(false);
    if (d.success) {
      onSaved();
      onClose();
    } else setErr(d.error || 'Failed');
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "ov",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "mh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mht"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE4",
    size: 18
  }), " Record Expense"), /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mb"
  }, err && /*#__PURE__*/React.createElement("div", {
    className: "ferr"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", err), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Category", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("select", {
    className: "fs",
    value: form.cat,
    onChange: e => set('cat', e.target.value),
    required: true
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "\u2014 Select \u2014"), EXP_CATS.map(c => /*#__PURE__*/React.createElement("option", {
    key: c
  }, c)))), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Amount (TSh)", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "number",
    className: "fi",
    placeholder: "e.g. 450000",
    min: "1",
    required: true,
    value: form.amount,
    onChange: e => set('amount', e.target.value)
  }))), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Description", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("textarea", {
    className: "fi",
    required: true,
    placeholder: "Brief description\u2026",
    value: form.desc,
    onChange: e => set('desc', e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Method", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("select", {
    className: "fs",
    value: form.method,
    onChange: e => set('method', e.target.value)
  }, /*#__PURE__*/React.createElement("option", null, "Cash"), /*#__PURE__*/React.createElement("option", null, "Bank Transfer"), /*#__PURE__*/React.createElement("option", null, "M-Pesa"), /*#__PURE__*/React.createElement("option", null, "Cheque"))), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Date", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "fi",
    required: true,
    value: form.date,
    onChange: e => set('date', e.target.value)
  }))), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Reference (optional)"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "fi",
    placeholder: "Invoice / receipt number",
    value: form.ref,
    onChange: e => set('ref', e.target.value)
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mf"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "btn bo",
    onClick: onClose,
    disabled: saving
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "btn bg",
    disabled: saving
  }, saving ? 'Saving…' : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 6,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "save",
    size: 16
  }), " Record Expense"))))));
}

/* ═══════════════════════════════════════════
   DISCOUNT / SCHOLARSHIP MODAL
═══════════════════════════════════════════ */
function DiscountModal({
  onClose,
  onSaved
}) {
  const [panel, setPanel] = useState('home');
  const [student, setStudent] = useState(null);
  const [disc, setDisc] = useState(null);
  const [form, setForm] = useState({
    pct: '',
    reason: '',
    from: new Date().toISOString().split('T')[0],
    duration: '',
    customTo: ''
  });
  const [saving, setSaving] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [allDiscs, setAllDiscs] = useState(null);
  const [allLoading, setAllLoading] = useState(false);
  const [scList, setScList] = useState(null);
  const [scLoading, setScLoading] = useState(false);
  const [scForm, setScForm] = useState({
    name: '',
    description: '',
    amount: ''
  });
  const [scStudents, setScStudents] = useState([]);
  const [scMethod, setScMethod] = useState('Cash');
  const [scSaving, setScSaving] = useState(false);
  const [scMsg, setScMsg] = useState('');
  const [scErr, setScErr] = useState('');
  useEffect(() => {
    if (panel === 'view') {
      setAllLoading(true);
      apiFetch('/nsms/api/finance.php?action=get_all_discounts').then(d => {
        if (d.success) setAllDiscs(d.data);
      }).finally(() => setAllLoading(false));
    }
    if (panel === 'scholarships') {
      setScLoading(true);
      apiFetch('/nsms/api/finance.php?action=get_scholarships').then(d => {
        if (d.success) setScList(d.data);
      }).finally(() => setScLoading(false));
    }
  }, [panel]);
  const loadDisc = async sid => {
    const d = await apiFetch(`/nsms/api/finance.php?action=get_discount&student_id=${sid}`);
    if (d.success) setDisc(d.data);
  };
  const pickStudent = s => {
    setStudent(s);
    setMsg('');
    setErr('');
    setEditMode(false);
    loadDisc(s.id);
  };
  const clearStudent = () => {
    setStudent(null);
    setDisc(null);
    setMsg('');
    setErr('');
    setEditMode(false);
  };
  const set = (k, v) => setForm(p => ({
    ...p,
    [k]: v
  }));
  const startEdit = () => {
    const ar = disc?.active_row;
    setForm({
      pct: ar ? String(ar.discount_percent) : '',
      reason: ar?.reason || '',
      from: ar?.effective_from || new Date().toISOString().split('T')[0],
      duration: '',
      customTo: ar?.effective_to || ''
    });
    setEditMode(true);
    setMsg('');
    setErr('');
  };
  const computedTo = () => {
    if (form.customTo) return form.customTo;
    if (form.duration && form.from) {
      const d = new Date(form.from);
      d.setMonth(d.getMonth() + Number(form.duration));
      return d.toISOString().split('T')[0];
    }
    return null;
  };
  const saveDisc = async () => {
    const pct = Number(form.pct);
    if (isNaN(pct) || pct <= 0 || pct > 100) {
      setErr('Enter 1–100');
      return;
    }
    setSaving(true);
    setMsg('');
    setErr('');
    const to = computedTo();
    const d = await apiPost('/nsms/api/finance.php?action=set_discount', {
      student_id: student.id,
      discount_percent: pct,
      reason: form.reason || null,
      effective_from: form.from,
      effective_to: to || null,
      duration_months: form.duration ? Number(form.duration) : null
    });
    setSaving(false);
    if (d.success) {
      setMsg(d.message);
      setEditMode(false);
      loadDisc(student.id);
    } else setErr(d.error || 'Failed');
  };
  const removeDisc = async () => {
    if (!confirm(`Remove discount for ${student.student_name}?`)) return;
    setRemoving(true);
    const d = await apiPost('/nsms/api/finance.php?action=remove_discount', {
      student_id: student.id
    });
    setRemoving(false);
    if (d.success) {
      setMsg('Discount removed.');
      setEditMode(false);
      loadDisc(student.id);
    } else setErr(d.error || 'Failed');
  };
  const hasActive = disc && disc.active_percent > 0;
  const scSet = (k, v) => setScForm(p => ({
    ...p,
    [k]: v
  }));
  const addScStudent = s => {
    if (!scStudents.find(x => x.id === s.id)) setScStudents(p => [...p, s]);
  };
  const removeScStudent = id => setScStudents(p => p.filter(s => s.id !== id));
  const saveScholarship = async () => {
    if (!scForm.name) {
      setScErr('Name required');
      return;
    }
    if (!scForm.amount || Number(scForm.amount) <= 0) {
      setScErr('Amount required');
      return;
    }
    if (scStudents.length === 0) {
      setScErr('Assign at least one student');
      return;
    }
    setScSaving(true);
    setScMsg('');
    setScErr('');
    const d = await apiPost('/nsms/api/finance.php?action=save_scholarship', {
      name: scForm.name,
      description: scForm.description || null,
      amount: Number(scForm.amount),
      student_ids: scStudents.map(s => s.id),
      source_method: scMethod
    });
    setScSaving(false);
    if (d.success) {
      const skipped = d.data.skipped_count || 0;
      const errs = d.data.debug_errors || [];
      const skipNote = skipped > 0 ? ` (${skipped} skipped — already fully paid or error)` : '';
      setScMsg(`Saved! ${d.data.students_assigned} student(s) assigned — recorded as Scholarship (${d.data.source_method || scMethod}).${skipNote}`);
      if (errs.length > 0) setScErr('Debug info:\n' + errs.join('\n'));
      setScForm({
        name: '',
        description: '',
        amount: ''
      });
      setScStudents([]);
      setScMethod('Cash');
      apiFetch('/nsms/api/finance.php?action=get_scholarships').then(r => {
        if (r.success) setScList(r.data);
      });
      if (onSaved) onSaved();
    } else setScErr(d.error || 'Failed');
  };
  const goBack = () => {
    setPanel('home');
    setStudent(null);
    setDisc(null);
    setEditMode(false);
    setMsg('');
    setErr('');
    setScMsg('');
    setScErr('');
    setScMethod('Cash');
  };

  /* HOME */
  if (panel === 'home') return /*#__PURE__*/React.createElement("div", {
    className: "ov",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    style: {
      maxWidth: 440
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "mh"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mht"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFF7\uFE0F",
    size: 18
  }), " Discounts & Scholarships"), /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mb",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      paddingTop: 20,
      paddingBottom: 20
    }
  }, [['view', '📋', 'View Active Discounts', 'See all students currently receiving a School Fees discount', '#EDE9FE', '#C4B5FD', '#3B0764'], ['add', '➕', 'Add / Edit Discount', 'Search a student and set or update their discount', '#EFF6FF', '#BFDBFE', '#1E3A8A'], ['scholarships', '🎓', 'Scholarships', 'Create scholarship programmes and assign beneficiaries', '#F0FDF4', '#86EFAC', '#14532D']].map(([p, icon, title, sub, bg, border, col]) => /*#__PURE__*/React.createElement("button", {
    key: p,
    onClick: () => setPanel(p),
    style: {
      background: bg,
      border: `2px solid ${border}`,
      borderRadius: 12,
      padding: '16px 20px',
      cursor: 'pointer',
      textAlign: 'left',
      width: '100%',
      fontFamily: 'var(--font)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      marginBottom: 5
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 14,
      color: col
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: col,
      opacity: .75,
      marginTop: 2
    }
  }, sub)))), /*#__PURE__*/React.createElement("div", {
    className: "mf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: onClose
  }, "Close"))));

  /* VIEW ALL */
  if (panel === 'view') return /*#__PURE__*/React.createElement("div", {
    className: "ov",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    style: {
      maxWidth: 620
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "mh"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: goBack,
    style: {
      fontSize: 16
    }
  }, "\u2190"), /*#__PURE__*/React.createElement("span", {
    className: "mht"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCB",
    size: 18
  }), " Active Discounts")), /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mb"
  }, allLoading ? /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  })) : !allDiscs || allDiscs.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 36,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFF7\uFE0F",
    size: 18
  })), "No active discounts.", /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#2563EB',
      cursor: 'pointer'
    },
    onClick: () => setPanel('add')
  }, "Add one \u2192"))) : /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#64748B',
      marginBottom: 10
    }
  }, allDiscs.length, " student", allDiscs.length !== 1 ? 's' : '', " on discount"), allDiscs.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '10px 12px',
      borderRadius: 8,
      background: i % 2 === 0 ? '#F8FAFC' : '#fff',
      marginBottom: 4,
      border: '1px solid #F1F5F9'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 14
    }
  }, d.student_name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#64748B',
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "bx xb",
    style: {
      fontSize: 11
    }
  }, d.class_name), d.reason && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 8
    }
  }, d.reason))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 700,
      color: '#5B21B6'
    }
  }, d.discount_percent, "%"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#94A3B8'
    }
  }, fmtD(d.effective_from), " \u2192 ", d.effective_to ? fmtD(d.effective_to) : /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#10B981'
    }
  }, "No expiry"))))))), /*#__PURE__*/React.createElement("div", {
    className: "mf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: goBack
  }, "\u2190 Back"), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: () => setPanel('add')
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 18
  }), " Add Discount"))));

  /* SCHOLARSHIPS */
  if (panel === 'scholarships') return /*#__PURE__*/React.createElement("div", {
    className: "ov",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal wide",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "mh"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: goBack,
    style: {
      fontSize: 16
    }
  }, "\u2190"), /*#__PURE__*/React.createElement("span", {
    className: "mht"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), " Scholarships")), /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fsec"
  }, "Create New Scholarship"), scErr && /*#__PURE__*/React.createElement("div", {
    className: "ferr",
    style: {
      whiteSpace: 'pre-line',
      fontFamily: scErr.startsWith('Debug') ? 'monospace' : 'inherit',
      fontSize: scErr.startsWith('Debug') ? 12 : 14
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", scErr), scMsg && /*#__PURE__*/React.createElement("div", {
    className: "fok"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " ", scMsg), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Name", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "fi",
    placeholder: "e.g. Merit Scholarship 2025",
    value: scForm.name,
    onChange: e => scSet('name', e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Amount (TSh)", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "number",
    className: "fi",
    placeholder: "e.g. 500000",
    min: "1",
    value: scForm.amount,
    onChange: e => scSet('amount', e.target.value)
  }))), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Description (optional)"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "fi",
    placeholder: "Brief description\u2026",
    value: scForm.description,
    onChange: e => scSet('description', e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Paid via", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("select", {
    className: "fs",
    value: scMethod,
    onChange: e => setScMethod(e.target.value)
  }, /*#__PURE__*/React.createElement("option", null, "Cash"), /*#__PURE__*/React.createElement("option", null, "M-Pesa"), /*#__PURE__*/React.createElement("option", null, "Bank Transfer"), /*#__PURE__*/React.createElement("option", null, "Cheque")))), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Assign Students", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement(StudentSearch, {
    onSelect: addScStudent,
    placeholder: "Search and add students\u2026"
  }), scStudents.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, scStudents.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.id,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      background: '#EFF6FF',
      border: '1px solid #BFDBFE',
      borderRadius: 20,
      padding: '4px 10px',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#1E40AF',
      fontWeight: 600
    }
  }, s.student_name), /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#94A3B8',
      fontSize: 11
    }
  }, s.class_name), /*#__PURE__*/React.createElement("button", {
    onClick: () => removeScStudent(s.id),
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: '#94A3B8',
      fontSize: 14,
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#94A3B8',
      marginTop: 4
    }
  }, scForm.amount ? fmtF(Number(scForm.amount)) : 'TSh 0', " per student \u2014 recorded as ", /*#__PURE__*/React.createElement("strong", null, "Scholarship (", scMethod, ")"), ". Fees auto-allocated: one-time \u2192 school fees \u2192 transport (if excess).")), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: saveScholarship,
    disabled: scSaving,
    style: {
      width: '100%'
    }
  }, scSaving ? 'Saving…' : '🎓 Save Scholarship & Record Revenue'), scList && scList.length > 0 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "fsec",
    style: {
      marginTop: 20
    }
  }, "Previous Scholarships"), scList.map((sc, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: '10px 12px',
      borderRadius: 8,
      background: '#F8FAFC',
      marginBottom: 6,
      border: '1px solid #E2E8F0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 14
    }
  }, sc.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      color: '#10B981'
    }
  }, fmtF(sc.amount))), sc.description && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#64748B',
      marginTop: 2
    }
  }, sc.description), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#94A3B8',
      marginTop: 4
    }
  }, sc.beneficiary_count, " student", sc.beneficiary_count !== 1 ? 's' : '', ": ", sc.beneficiaries || '—'))))), /*#__PURE__*/React.createElement("div", {
    className: "mf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: goBack
  }, "\u2190 Back"))));

  /* ADD / EDIT */
  return /*#__PURE__*/React.createElement("div", {
    className: "ov",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "modal",
    style: {
      maxWidth: 520
    },
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "mh"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: goBack,
    style: {
      fontSize: 16
    }
  }, "\u2190"), /*#__PURE__*/React.createElement("span", {
    className: "mht"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2795",
    size: 18
  }), " Add / Edit Discount")), /*#__PURE__*/React.createElement("button", {
    className: "mcl",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fsec"
  }, "Select Student"), student ? /*#__PURE__*/React.createElement("div", {
    className: "selstu"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "seln"
  }, student.student_name), /*#__PURE__*/React.createElement("div", {
    className: "selsb"
  }, student.class_name)), /*#__PURE__*/React.createElement("button", {
    className: "clrb",
    onClick: clearStudent
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\xD7",
    size: 18
  }))) : /*#__PURE__*/React.createElement(StudentSearch, {
    onSelect: pickStudent,
    placeholder: "Search student by name\u2026"
  }), student && disc && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: hasActive ? '#EDE9FE' : '#F8FAFC',
      border: `1px solid ${hasActive ? '#C4B5FD' : '#E2E8F0'}`,
      borderRadius: 10,
      padding: '12px 16px',
      marginTop: 12,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#64748B',
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.5px',
      marginBottom: 2
    }
  }, "Current Discount (School Fees only)"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 26,
      fontWeight: 700,
      color: hasActive ? '#5B21B6' : '#94A3B8'
    }
  }, hasActive ? `${disc.active_percent}%` : 'None'), hasActive && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#7C3AED',
      marginTop: 2
    }
  }, disc.active_row?.effective_to ? `Expires: ${fmtD(disc.active_row.effective_to)}` : 'No expiry')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, !editMode && /*#__PURE__*/React.createElement("button", {
    className: "btn bsm bo",
    onClick: startEdit
  }, hasActive ? '✏️ Edit' : '➕ Set'), hasActive && !editMode && /*#__PURE__*/React.createElement("button", {
    className: "btn bsm br",
    onClick: removeDisc,
    disabled: removing
  }, removing ? '…' : '🗑️'))), editMode && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "fsec"
  }, hasActive ? 'Edit Discount' : 'Set Discount', /*#__PURE__*/React.createElement("button", {
    style: {
      float: 'right',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: '#94A3B8',
      fontSize: 12
    },
    onClick: () => setEditMode(false)
  }, "Cancel")), err && /*#__PURE__*/React.createElement("div", {
    className: "ferr"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", err), msg && /*#__PURE__*/React.createElement("div", {
    className: "fok"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " ", msg), /*#__PURE__*/React.createElement("div", {
    className: "frow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Discount %", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    type: "number",
    className: "fi",
    min: "1",
    max: "100",
    step: "5",
    placeholder: "e.g. 50",
    value: form.pct,
    onChange: e => set('pct', e.target.value)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: '#94A3B8',
      marginTop: 3
    }
  }, "School Fees only. 1\u2013100.")), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Effective From"), /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "fi",
    value: form.from,
    onChange: e => set('from', e.target.value)
  }))), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Duration"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, [['3', '3 months'], ['6', '6 months'], ['12', '1 year'], ['', 'No expiry']].map(([val, lbl]) => /*#__PURE__*/React.createElement("button", {
    key: lbl,
    className: "btn bsm",
    style: {
      background: form.duration === val && !form.customTo ? '#2563EB' : '#F1F5F9',
      color: form.duration === val && !form.customTo ? '#fff' : '#475569',
      border: 'none'
    },
    onClick: () => {
      set('duration', val);
      set('customTo', '');
    }
  }, lbl)), /*#__PURE__*/React.createElement("button", {
    className: "btn bsm",
    style: {
      background: form.customTo ? '#2563EB' : '#F1F5F9',
      color: form.customTo ? '#fff' : '#475569',
      border: 'none'
    },
    onClick: () => set('duration', '')
  }, "Custom")), form.duration === '' && form.customTo === '' && /*#__PURE__*/React.createElement("input", {
    type: "date",
    className: "fi",
    style: {
      marginTop: 8
    },
    value: form.customTo,
    onChange: e => set('customTo', e.target.value)
  }), computedTo() && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#64748B',
      marginTop: 5
    }
  }, "Expires: ", /*#__PURE__*/React.createElement("strong", null, fmtD(computedTo())))), /*#__PURE__*/React.createElement("div", {
    className: "fg"
  }, /*#__PURE__*/React.createElement("label", {
    className: "fl"
  }, "Reason (optional)"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    className: "fi",
    placeholder: "e.g. Financial hardship, Scholarship\u2026",
    value: form.reason,
    onChange: e => set('reason', e.target.value)
  })), form.pct !== '' && Number(form.pct) > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#EDE9FE',
      border: '1px solid #C4B5FD',
      borderRadius: 8,
      padding: '9px 14px',
      fontSize: 13,
      color: '#5B21B6',
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFF7\uFE0F",
    size: 18
  }), " ", /*#__PURE__*/React.createElement("strong", null, form.pct, "%"), " off School Fees only. All other fees remain at full price.", computedTo() && /*#__PURE__*/React.createElement(React.Fragment, null, " Expires ", /*#__PURE__*/React.createElement("strong", null, fmtD(computedTo())), ".")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    style: {
      flex: 1
    },
    onClick: () => setEditMode(false),
    disabled: saving
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    style: {
      flex: 1
    },
    onClick: saveDisc,
    disabled: saving
  }, saving ? 'Saving…' : '💾 Save'))), !editMode && disc.history && disc.history.length > 0 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "fsec",
    style: {
      marginTop: 14
    }
  }, "History"), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 140,
      overflowY: 'auto'
    }
  }, disc.history.map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      padding: '6px 10px',
      borderRadius: 7,
      background: '#F8FAFC',
      marginBottom: 4,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: '#5B21B6'
    }
  }, h.discount_percent, "%"), h.reason && /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#64748B',
      marginLeft: 8
    }
  }, h.reason)), /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#94A3B8',
      fontSize: 12
    }
  }, fmtD(h.effective_from), " \u2192 ", h.effective_to ? fmtD(h.effective_to) : /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#10B981'
    }
  }, "Active")))))), !hasActive && !editMode && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      textAlign: 'center',
      color: '#94A3B8',
      fontSize: 13
    }
  }, "No active discount. ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#2563EB',
      cursor: 'pointer'
    },
    onClick: startEdit
  }, "Set one \u2192")))), /*#__PURE__*/React.createElement("div", {
    className: "mf"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: goBack
  }, "\u2190 Back"))));
}

/* ═══════════════════════════════════════════
   FEE STRUCTURE TAB
═══════════════════════════════════════════ */
const SW_FEE_TYPES = ['Registration Fee', 'Stationery', 'Uniform', 'Meals', 'Transport'];
const CLASS_FEE_TYPE = 'School Fees';
function FeeStructureTab() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [editing, setEditing] = useState(undefined);
  const [editFees, setEditFees] = useState([]);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const load = useCallback(() => {
    setLoading(true);
    setErr('');
    apiFetch('/nsms/api/finance.php?action=fee_structure_all').then(d => {
      if (d.success) {
        const payload = d.data || {};
        if (!payload.fee_map) payload.fee_map = { school_wide: [] };
        if (!payload.fee_map.school_wide) payload.fee_map.school_wide = [];
        if (!payload.classes) payload.classes = [];
        setData(payload);
      } else setErr(d.error || 'Failed');
    }).finally(() => setLoading(false));
  }, []);
  useEffect(() => {
    load();
  }, [load]);
  const startEdit = cid => {
    const key = cid === null ? 'school_wide' : cid;
    const existing = data.fee_map[key] || [];
    const feeTypes = cid === null ? SW_FEE_TYPES : [CLASS_FEE_TYPE];
    const fees = feeTypes.map(ft => {
      const f = existing.find(e => e.fee_type === ft);
      return {
        fee_type: ft,
        amount: f ? f.amount : ''
      };
    });
    setEditFees(fees);
    setEditing(cid);
    setMsg('');
  };
  const setAmt = (i, v) => setEditFees(p => p.map((f, idx) => idx === i ? {
    ...f,
    amount: v
  } : f));
  const save = async () => {
    setSaving(true);
    setMsg('');
    const fees = editFees.filter(f => f.amount !== '' && Number(f.amount) > 0).map(f => ({
      fee_type: f.fee_type,
      amount: Number(f.amount)
    }));
    const d = await apiPost('/nsms/api/finance.php?action=save_fee_structure', {
      class_id: editing,
      fees,
      academic_year: data.academic_year
    });
    setSaving(false);
    if (d.success) {
      setMsg('Saved!');
      setEditing(undefined);
      load();
    } else setMsg('⚠️ ' + (d.error || 'Failed'));
  };
  if (loading) return /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading\u2026"));
  if (err) return /*#__PURE__*/React.createElement("div", {
    className: "ferr"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", err);
  if (!data) return null;
  const groups = [{
    label: 'School-wide Fees',
    sub: 'Apply to all classes · Paid upfront in full',
    classId: null,
    color: '#8B5CF6',
    feeTypes: SW_FEE_TYPES
  }, ...(data.classes || []).map(c => ({
    label: c.class_name,
    sub: 'School Fees only · Split into 10 monthly installments',
    classId: c.id,
    color: c.class_color,
    feeTypes: [CLASS_FEE_TYPE]
  }))];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#EFF6FF',
      border: '1px solid #BFDBFE',
      borderRadius: 10,
      padding: '12px 16px',
      marginBottom: 16,
      fontSize: 13,
      color: '#1E40AF'
    }
  }, /*#__PURE__*/React.createElement("strong", null, "Fee structure rules:"), " School-wide fees apply to all students and are paid upfront. Each class has its own ", /*#__PURE__*/React.createElement("strong", null, "School Fees"), " split into 10 installments. Transport is optional \u2014 assign per-student in the payment form."), msg && editing === undefined && /*#__PURE__*/React.createElement("div", {
    className: "fok"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " ", msg), /*#__PURE__*/React.createElement("div", {
    className: "fsgrid"
  }, groups.map(g => {
    const key = g.classId === null ? 'school_wide' : g.classId;
    const fees = (data.fee_map[key] || []).filter(f => g.feeTypes.includes(f.fee_type));
    const total = fees.reduce((s, f) => s + f.amount, 0);
    const isEd = editing === g.classId;
    return /*#__PURE__*/React.createElement("div", {
      key: String(key),
      className: "card",
      style: {
        borderTop: `4px solid ${g.color}`
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "ch"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 700,
        fontSize: 15,
        color: '#1E293B'
      }
    }, g.label), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: '#94A3B8',
        marginTop: 2
      }
    }, g.sub)), !isEd && /*#__PURE__*/React.createElement("button", {
      className: "btn bsm bo",
      onClick: () => startEdit(g.classId)
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u270F\uFE0F",
      size: 18
    }), " Edit")), isEd ? /*#__PURE__*/React.createElement("div", null, editFees.map((f, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        marginBottom: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        fontWeight: 600,
        color: '#475569',
        marginBottom: 4
      }
    }, f.fee_type, f.fee_type === 'School Fees' && /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#94A3B8',
        fontWeight: 400
      }
    }, " \u2014 annual total (\xF710 per installment)")), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 10,
        top: '50%',
        transform: 'translateY(-50%)',
        fontSize: 12,
        color: '#94A3B8'
      }
    }, "TSh"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      min: "0",
      className: "fi",
      style: {
        paddingLeft: 38,
        fontSize: 14
      },
      placeholder: "0",
      value: f.amount,
      onChange: e => setAmt(i, e.target.value)
    })), f.fee_type === 'School Fees' && f.amount && Number(f.amount) > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: '#10B981',
        marginTop: 3
      }
    }, "= ", fmtF(Number(f.amount) / 10), " per installment"))), msg && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        marginBottom: 6,
        color: msg.startsWith('⚠️') ? '#B91C1C' : '#166534'
      }
    }, msg), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        marginTop: 6
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "btn bo bsm",
      style: {
        flex: 1
      },
      onClick: () => setEditing(undefined),
      disabled: saving
    }, "Cancel"), /*#__PURE__*/React.createElement("button", {
      className: "btn bb bsm",
      style: {
        flex: 1
      },
      onClick: save,
      disabled: saving
    }, saving ? 'Saving…' : '💾 Save'))) : fees.length > 0 ? /*#__PURE__*/React.createElement("div", null, fees.map((f, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        padding: '6px 0',
        borderBottom: '1px solid #F1F5F9',
        fontSize: 13
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#475569'
      }
    }, f.fee_type), /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700,
        color: '#1E293B'
      }
    }, fmtF(f.amount))), f.fee_type === 'School Fees' && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: '#94A3B8',
        marginTop: 2
      }
    }, fmtF(f.amount / 10), " ", /*#__PURE__*/React.createElement(Icon, {
      emoji: "\xD7",
      size: 18
    }), " 10 installments"))), fees.length > 1 && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        padding: '8px 0 0'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: '#64748B'
      }
    }, "TOTAL"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 15,
        fontWeight: 700,
        color: g.color
      }
    }, fmtF(total)))) : /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: '#94A3B8',
        padding: '8px 0',
        textAlign: 'center'
      }
    }, "No fees set. ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#2563EB',
        cursor: 'pointer'
      },
      onClick: () => startEdit(g.classId)
    }, "Click Edit \u2192")));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#94A3B8',
      marginTop: 12
    }
  }, "Academic Year: ", /*#__PURE__*/React.createElement("strong", null, data.academic_year)));
}

/* ═══════════════════════════════════════════
   OVERVIEW TAB
═══════════════════════════════════════════ */
/* ═══════════════════════════════════════════
   SEND FEE REMINDERS
═══════════════════════════════════════════ */
function SendRemindersCard() {
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState(null);
  const [err, setErr] = useState('');
  async function sendAll() {
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Send fee reminders?', message: 'Send a fee reminder email to every family with an outstanding balance?', confirmLabel: 'Send emails', variant: 'warn' }) : Promise.resolve(false)))) return;
    setSending(true);
    setErr('');
    setResult(null);
    const d = await apiPost('/nsms/api/finance.php?action=send_fee_reminders', {});
    setSending(false);
    if (d.success) setResult(d.data);else setErr(d.error || 'Failed to send reminders');
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE7",
    size: 18
  }), " Fee Payment Reminders")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      color: '#64748B',
      maxWidth: 480
    }
  }, "Emails every family that still has a balance owed this academic year. Families who are fully paid are skipped automatically."), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: sendAll,
    disabled: sending
  }, sending ? 'Sending…' : '📧 Send Reminders to All')), result && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      padding: '10px 14px',
      background: '#F0FDF4',
      border: '1px solid #86EFAC',
      borderRadius: 8,
      fontSize: 13.5,
      color: '#166534'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " Sent ", result.reminders_sent, " reminder", result.reminders_sent !== 1 ? 's' : '', result.students_skipped > 0 ? ` — ${result.students_skipped} student${result.students_skipped !== 1 ? 's' : ''} already fully paid or skipped.` : '.'), err && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      padding: '10px 14px',
      background: '#FEF2F2',
      border: '1px solid #FCA5A5',
      borderRadius: 8,
      fontSize: 13.5,
      color: '#B91C1C'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", err));
}
function OverviewTab({
  ov
}) {
  if (!ov) return /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, "No data for this period");
  const COLS = ['#2563EB', '#10B981', '#F59E0B', '#8B5CF6', '#EF4444', '#06B6D4', '#EC4899', '#84CC16'];
  const trendData = (ov.revenue_trend && ov.revenue_trend.length > 0) ? ov.revenue_trend : [];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SendRemindersCard, null), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC8",
    size: 18
  }), " Revenue Trend (Last 6 Months)")), /*#__PURE__*/React.createElement(TrendChart, {
    data: trendData.length ? trendData : [{ month: "", label: "No data", revenue: 0 }]
  })), /*#__PURE__*/React.createElement("div", {
    className: "twocol"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCCA",
    size: 18
  }), " Expense Breakdown"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: '#64748B'
    }
  }, fmtF(ov.total_expenses))), ov.expense_breakdown && ov.expense_breakdown.length > 0 ? ov.expense_breakdown.map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "erow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "einfo"
  }, /*#__PURE__*/React.createElement("div", {
    className: "elbl"
  }, /*#__PURE__*/React.createElement("span", null, e.category), /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLS[i % COLS.length],
      fontWeight: 700
    }
  }, fmtF(e.amount))), /*#__PURE__*/React.createElement("div", {
    className: "ebar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "efill",
    style: {
      width: `${e.percentage}%`,
      background: COLS[i % COLS.length]
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: '#475569',
      width: 34,
      textAlign: 'right'
    }
  }, e.percentage, "%"))) : /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, "No expenses this period")), /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB3",
    size: 18
  }), " Payment Methods")), ov.method_breakdown && ov.method_breakdown.length > 0 ? /*#__PURE__*/React.createElement("div", {
    className: "mgrid"
  }, ov.method_breakdown.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "mpill",
    style: {
      borderLeftColor: COLS[i % COLS.length]
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mpl"
  }, methodDisplay(m.payment_method)), /*#__PURE__*/React.createElement("div", {
    className: "mpv"
  }, fmtF(m.total)), /*#__PURE__*/React.createElement("div", {
    className: "mpc"
  }, m.count, " transaction", m.count !== 1 ? 's' : '')))) : /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, "No payments this period"))));
}

/* ═══════════════════════════════════════════
   PAYMENTS TAB
═══════════════════════════════════════════ */
function PaymentsTab({
  month
}) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  useEffect(() => {
    setLoading(true);
    setErr('');
    apiFetch(`/nsms/api/finance.php?action=transactions&limit=100&month=${month}`).then(d => {
      if (d.success) setRows(d.data);else setErr(d.error || 'Failed');
    }).finally(() => setLoading(false));
  }, [month]);
  if (loading) return /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading\u2026"));
  if (err) return /*#__PURE__*/React.createElement("div", {
    className: "ferr"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", err);
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB5",
    size: 18
  }), " Payments \u2014 ", mLbl(month)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: '#64748B'
    }
  }, rows.length, " records")), /*#__PURE__*/React.createElement("div", {
    className: "tw"
  }, rows.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, "No payments for this period") : /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Date"), /*#__PURE__*/React.createElement("th", null, "Receipt"), /*#__PURE__*/React.createElement("th", null, "Student"), /*#__PURE__*/React.createElement("th", null, "Class"), /*#__PURE__*/React.createElement("th", null, "Parent"), /*#__PURE__*/React.createElement("th", null, "Method"), /*#__PURE__*/React.createElement("th", null, "Ref."), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Amount"))), /*#__PURE__*/React.createElement("tbody", null, rows.map(p => /*#__PURE__*/React.createElement("tr", {
    key: p.id
  }, /*#__PURE__*/React.createElement("td", null, fmtD(p.payment_date)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: '#64748B',
      fontFamily: 'monospace'
    }
  }, p.receipt_number), /*#__PURE__*/React.createElement("button", {
    className: "btn bsm bp",
    style: {
      padding: '2px 8px',
      fontSize: 11,
      flexShrink: 0,
      lineHeight: 1.4
    },
    onClick: () => printPaymentReceipt(p.id),
    title: "Print Receipt"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDDA8\uFE0F",
    size: 18
  })))), /*#__PURE__*/React.createElement("td", {
    style: {
      fontWeight: 600
    }
  }, p.student_name), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "bx xb"
  }, p.class_name)), /*#__PURE__*/React.createElement("td", {
    style: {
      fontSize: 12
    }
  }, p.parent_name || '—'), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: `bx ${mbadge(p.payment_method)}`
  }, methodDisplay(p.payment_method))), /*#__PURE__*/React.createElement("td", {
    style: {
      fontSize: 12,
      color: '#64748B'
    }
  }, p.reference_number || '—'), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: `bx ${p.status === 'confirmed' ? 'xg' : p.status === 'pending' ? 'xy' : 'xr'}`
  }, p.status)), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right'
    },
    className: "pos"
  }, fmtF(p.amount))))))));
}

/* ═══════════════════════════════════════════
   EXPENSES TAB
═══════════════════════════════════════════ */
function ExpensesTab({
  month,
  refreshRef
}) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const load = useCallback(() => {
    setLoading(true);
    setErr('');
    apiFetch(`/nsms/api/finance.php?action=expenses&limit=100&month=${month}`).then(d => {
      if (d.success) setRows(d.data);else setErr(d.error || 'Failed');
    }).finally(() => setLoading(false));
  }, [month]);
  useEffect(() => {
    load();
  }, [load]);
  useEffect(() => {
    if (refreshRef) refreshRef.current = load;
  }, [load, refreshRef]);
  if (loading) return /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading\u2026"));
  if (err) return /*#__PURE__*/React.createElement("div", {
    className: "ferr"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " ", err);
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ch"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE4",
    size: 18
  }), " Expenses \u2014 ", mLbl(month)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: '#64748B'
    }
  }, rows.length, " records")), /*#__PURE__*/React.createElement("div", {
    className: "tw"
  }, rows.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, "No expenses for this period") : /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Date"), /*#__PURE__*/React.createElement("th", null, "Category"), /*#__PURE__*/React.createElement("th", null, "Description"), /*#__PURE__*/React.createElement("th", null, "Method"), /*#__PURE__*/React.createElement("th", null, "Ref."), /*#__PURE__*/React.createElement("th", null, "By"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Amount"))), /*#__PURE__*/React.createElement("tbody", null, rows.map(e => /*#__PURE__*/React.createElement("tr", {
    key: e.id
  }, /*#__PURE__*/React.createElement("td", null, fmtD(e.expense_date)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "bx xgr"
  }, e.category)), /*#__PURE__*/React.createElement("td", null, e.description), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: `bx ${mbadge(e.payment_method)}`
  }, e.payment_method)), /*#__PURE__*/React.createElement("td", {
    style: {
      fontSize: 12,
      color: '#64748B'
    }
  }, e.reference_number || '—'), /*#__PURE__*/React.createElement("td", {
    style: {
      fontSize: 12,
      color: '#64748B'
    }
  }, e.recorded_by_name || '—'), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right'
    },
    className: "neg"
  }, fmtF(e.amount))))))));
}

/* ═══════════════════════════════════════════
   EXPORT REPORT
═══════════════════════════════════════════ */

async function exportReport(month) {
  const d = await apiFetch(`/nsms/api/finance.php?action=export_report&month=${month}`);
  if (!d.success) {
    alert('Export failed: ' + (d.error || 'Unknown error'));
    return;
  }
  const rd = d.data;
  const s = rd.settings || {};
  const w = window.open('', '_blank');
  w.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Finance Report</title>
<style>*{margin:0;padding:0;box-sizing:border-box;}body{font-family:'Times New Roman',serif;font-size:13px;color:#1a1a1a;}
.page{width:210mm;min-height:297mm;padding:18mm 20mm;margin:0 auto;}
@media print{.page{padding:14mm 18mm;}.np{display:none!important;}}
.rh{display:flex;align-items:center;justify-content:space-between;padding-bottom:12px;border-bottom:3px solid #1E3A8A;margin-bottom:10px;}
.lb{width:72px;height:72px;border:2px solid #CBD5E1;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:24px;background:#EFF6FF;flex-shrink:0;}
.hc{text-align:center;flex:1;padding:0 14px;}
.sn{font-size:20px;font-weight:700;color:#1E3A8A;}
.rt{font-size:14px;font-weight:700;color:#1E293B;margin-top:7px;text-transform:uppercase;}
.rp{font-size:12px;color:#2563EB;font-weight:600;margin-top:2px;}
.sh{background:#1E3A8A;color:#fff;padding:7px 14px;border-radius:4px;margin:12px 0;display:flex;justify-content:space-between;font-size:11px;}
.sg{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:9px;margin:13px 0;}
.sc2{border:1px solid #E2E8F0;border-radius:6px;padding:9px 11px;}
.sc2.g{border-left:4px solid #10B981;}.sc2.r{border-left:4px solid #EF4444;}.sc2.b{border-left:4px solid #2563EB;}.sc2.o{border-left:4px solid #F59E0B;}
.scl{font-size:10px;color:#64748B;text-transform:uppercase;font-weight:700;letter-spacing:.4px;}
.scv{font-size:14px;font-weight:700;margin-top:2px;}
.sc2.g .scv{color:#10B981;}.sc2.r .scv{color:#EF4444;}.sc2.b .scv{color:#2563EB;}.sc2.o .scv{color:#F59E0B;}
.st{font-size:13px;font-weight:700;color:#1E3A8A;border-bottom:2px solid #DBEAFE;padding-bottom:4px;margin:14px 0 8px;text-transform:uppercase;}
table{width:100%;border-collapse:collapse;margin-bottom:12px;font-size:11px;}
th{background:#1E3A8A;color:#fff;padding:5px 9px;text-align:left;font-size:10px;}
td{padding:5px 9px;border-bottom:1px solid #E2E8F0;}
tr:nth-child(even) td{background:#F8FAFC;}
.right{text-align:right;}
.tr2 td{font-weight:700;background:#EFF6FF!important;border-top:2px solid #2563EB;}
.tc2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:10px 0;}
.rf{margin-top:26px;padding-top:10px;border-top:2px solid #E2E8F0;display:flex;justify-content:space-between;font-size:11px;color:#64748B;}
.rb{text-align:center;width:145px;}
.rl{border-top:1px solid #1a1a1a;margin:26px auto 3px;width:125px;}
.pb{background:#1E3A8A;color:#fff;padding:9px 20px;text-align:center;position:sticky;top:0;z-index:100;}
.pb button{background:#fff;color:#1E3A8A;border:none;padding:6px 16px;border-radius:5px;font-size:13px;font-weight:700;cursor:pointer;margin:0 4px;}
</style></head><body>
<div class="pb np"><strong>Finance Report</strong>
<button onclick="window.print()">🖨️ Print / PDF</button>
<button onclick="window.close()">✕ Close</button></div>
<div class="page">
<div class="rh">
<div class="lb" style="padding:0;overflow:hidden;"><img src="/nsms/public/uploads/logos/Tanzania.png" style="width:100%;height:100%;object-fit:contain;" onerror="this.parentElement.innerHTML='🏫'"/></div>
<div class="hc">
<div class="sn">${s.school_name || 'Nursery School'}</div>
<div style="font-size:11px;color:#475569;">United Republic of Tanzania</div>
<div class="rt">Monthly Finance Report</div>
<div class="rp">${mLbl(month)}</div>
</div>
<div class="lb" style="padding:0;overflow:hidden;background:#fff;"><img src="/nsms/public/uploads/logos/logo.png" style="width:100%;height:100%;object-fit:contain;" onerror="this.parentElement.innerHTML='🇹🇿'"/></div>
</div>
<div class="sh">
<div><b>Academic Year:</b> ${s.academic_year || ''}</div>
<div><b>Period:</b> ${mLbl(month)}</div>
<div><b>Generated:</b> ${new Date(rd.generated_at).toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  })}</div>
</div>
<div class="sg">
<div class="sc2 g"><div class="scl">Total Revenue</div><div class="scv">${fmtF(rd.revenue.total)}</div></div>
<div class="sc2 r"><div class="scl">Total Expenses</div><div class="scv">${fmtF(rd.expenses_total.total)}</div></div>
<div class="sc2 b"><div class="scl">Net Profit</div><div class="scv" style="color:${rd.net >= 0 ? '#2563EB' : '#EF4444'}">${fmtF(rd.net)}</div></div>
<div class="sc2 o"><div class="scl">Pending Students</div><div class="scv">${rd.pending_students.length}</div></div>
</div>
<div class="tc2">
<div><div class="st">Revenue by Method</div>
<table><thead><tr><th>Method</th><th>Count</th><th class="right">Amount</th></tr></thead><tbody>
${rd.method_breakdown.map(m => `<tr><td>${m.payment_method}</td><td>${m.count}</td><td class="right">${fmtF(m.total)}</td></tr>`).join('') || '<tr><td colspan="3" style="text-align:center;color:#94A3B8">No data</td></tr>'}
<tr class="tr2"><td colspan="2">TOTAL</td><td class="right">${fmtF(rd.revenue.total)}</td></tr>
</tbody></table></div>
<div><div class="st">Expenses by Category</div>
<table><thead><tr><th>Category</th><th>Count</th><th class="right">Amount</th></tr></thead><tbody>
${rd.exp_breakdown.map(e => `<tr><td>${e.category}</td><td>${e.count}</td><td class="right">${fmtF(e.total)}</td></tr>`).join('') || '<tr><td colspan="3" style="text-align:center;color:#94A3B8">No data</td></tr>'}
<tr class="tr2"><td colspan="2">TOTAL</td><td class="right">${fmtF(rd.expenses_total.total)}</td></tr>
</tbody></table></div>
</div>
<div class="st">Fee Payments</div>
<table><thead><tr><th>#</th><th>Date</th><th>Student</th><th>Class</th><th>Parent</th><th>Method</th><th class="right">Amount</th></tr></thead><tbody>
${rd.payments.map((p, i) => `<tr><td>${i + 1}</td><td>${fmtD(p.payment_date)}</td><td><b>${p.student_name}</b></td><td>${p.class_name}</td><td>${p.parent_name || '—'}</td><td>${p.payment_method}</td><td class="right"><b>${fmtF(p.amount)}</b></td></tr>`).join('') || '<tr><td colspan="7" style="text-align:center;color:#94A3B8;padding:12px;">No payments this period</td></tr>'}
<tr class="tr2"><td colspan="6">TOTAL</td><td class="right">${fmtF(rd.revenue.total)}</td></tr>
</tbody></table>
<div class="st">Expenses</div>
<table><thead><tr><th>#</th><th>Date</th><th>Category</th><th>Description</th><th>Method</th><th class="right">Amount</th></tr></thead><tbody>
${rd.expenses.map((e, i) => `<tr><td>${i + 1}</td><td>${fmtD(e.expense_date)}</td><td>${e.category}</td><td>${e.description}</td><td>${e.payment_method}</td><td class="right">${fmtF(e.amount)}</td></tr>`).join('') || '<tr><td colspan="6" style="text-align:center;color:#94A3B8;padding:12px;">No expenses this period</td></tr>'}
<tr class="tr2"><td colspan="5">TOTAL</td><td class="right">${fmtF(rd.expenses_total.total)}</td></tr>
</tbody></table>
<div class="rf">
<div class="rb"><div class="rl"></div><div><b>Finance Officer</b></div></div>
<div style="text-align:center;font-size:10px;color:#94A3B8;align-self:flex-end;">Generated ${new Date(rd.generated_at).toLocaleString('en-GB')}<br/>NSMS</div>
<div class="rb"><div class="rl"></div><div><b>School Principal</b></div></div>
</div>
</div></body></html>`);
  w.document.close();
}

/* ═══════════════════════════════════════════
   PRINT PAYMENT RECEIPT
═══════════════════════════════════════════ */
async function printPaymentReceipt(payId) {
  const d = await apiFetch(`/nsms/api/finance.php?action=get_payment_receipt&payment_id=${payId}`);
  if (!d.success) {
    alert('Failed to load receipt: ' + (d.error || 'Unknown error'));
    return;
  }
  const {
    payment: p,
    linked_installments: linst,
    status: st,
    settings: s,
    generated_at
  } = d.data;
  const fL = v => 'TSh ' + (Number(v) || 0).toLocaleString('en-TZ', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  });
  const dL = v => {
    if (!v) return '—';
    const dt = new Date((v + '').replace(' ', 'T'));
    return isNaN(dt) ? v : dt.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });
  };
  const mD = m => {
    if (!m) return m;
    const pp = 'Scholarship (';
    if (m.startsWith(pp) && m.endsWith(')')) return 'Scholarship — ' + m.slice(pp.length, -1);
    return m;
  };
  const dotBg = s => s.status === 'paid' ? '#10B981' : s.amount_due === 0 ? '#A78BFA' : s.status === 'partial' ? '#F59E0B' : '#E2E8F0';
  const dotFg = s => s.status === 'paid' || s.status === 'partial' || s.amount_due === 0 ? '#fff' : '#94A3B8';
  const totalFees = st ? st.grand_total + (st.transport_assigned ? st.transport_total : 0) : 0;
  const sfSlots = st && st.installments && st.installments['School Fees'] ? st.installments['School Fees'] : [];
  const tpSlots = st && st.installments && st.installments['Transport'] ? st.installments['Transport'] : [];

  /* ── Allocation table (installments last updated by this payment) ── */
  const allocHtml = linst && linst.length > 0 ? `
<div class="sl">Fee Installments Updated by This Payment</div>
<table><thead><tr><th>Fee Type</th><th style="text-align:center">Inst. #</th><th>Status</th><th class="right">Amount Paid</th><th class="right">Total Due</th></tr></thead><tbody>
${linst.map(i => `<tr>
  <td>${i.fee_type}</td>
  <td style="text-align:center">${i.installment_no || '—'}</td>
  <td><span style="font-weight:700;color:${i.status === 'paid' ? '#10B981' : i.status === 'partial' ? '#D97706' : '#94A3B8'}">${i.status.toUpperCase()}</span></td>
  <td class="right" style="font-weight:700;color:#10B981">${fL(i.amount_paid)}</td>
  <td class="right" style="color:#64748B">${fL(i.amount_due)}</td>
</tr>`).join('')}
</tbody></table>` : '';

  /* ── Installment dot grids ── */
  const sfDots = sfSlots.length > 0 ? `
<div class="sl">School Fees — Installment Progress (${sfSlots.filter(x => x.status === 'paid' || x.amount_due === 0).length} / ${sfSlots.length} complete)</div>
<div class="idots">${sfSlots.map(x => `<div class="idot" title="Inst.${x.no}: ${x.status} — ${fL(x.amount_paid)} / ${fL(x.amount_due)}" style="background:${dotBg(x)};color:${dotFg(x)}">${x.no}</div>`).join('')}</div>
<div style="font-size:9px;color:#94A3B8;margin-top:3px;">&#x1F7E2; Paid &nbsp; &#x1F7E1; Partial &nbsp; &#x1F7E3; 100% disc &nbsp; &#x26AA; Unpaid</div>` : '';
  const tpDots = tpSlots.length > 0 ? `
<div class="sl" style="margin-top:10px;">Transport — Installment Progress (${tpSlots.filter(x => x.status === 'paid' || x.amount_due === 0).length} / ${tpSlots.length} complete)</div>
<div class="idots">${tpSlots.map(x => `<div class="idot" title="Transport Inst.${x.no}: ${x.status}" style="background:${dotBg(x)};color:${dotFg(x)}">${x.no}</div>`).join('')}</div>` : '';

  /* ── Banners ── */
  const discBanner = st && st.discount_pct > 0 ? `
<div style="margin-top:8px;background:#EDE9FE;border:1px solid #C4B5FD;border-radius:5px;padding:6px 10px;font-size:11px;color:#5B21B6;">
  &#x1F3F7;&#xFE0F; <strong>${st.discount_pct}% School Fees discount</strong> is active for this student.
</div>` : '';
  const schBanner = st && st.scholarship_total > 0 ? `
<div style="margin-top:6px;background:#EDE9FE;border:1px solid #C4B5FD;border-radius:5px;padding:6px 10px;font-size:11px;color:#5B21B6;">
  &#x1F393; <strong>${fL(st.scholarship_total)}</strong> covered by scholarship programme.
</div>` : '';

  /* ── Account summary ── */
  const summaryHtml = st ? `
<div class="sl">Account Summary &mdash; ${st.academic_year}</div>
<div class="sg">
  <div class="sc" style="border-left:3px solid #475569">
    <div class="scl">Total Fees</div><div class="scv" style="color:#1E293B">${fL(totalFees)}</div>
  </div>
  <div class="sc" style="border-left:3px solid #10B981">
    <div class="scl">Paid to Date</div><div class="scv" style="color:#10B981">${fL(st.total_paid)}</div>
  </div>
  <div class="sc" style="border-left:3px solid ${st.balance_owed > 0 ? '#EF4444' : '#10B981'}">
    <div class="scl">${st.balance_owed > 0 ? 'Outstanding' : 'Cleared'}</div>
    <div class="scv" style="color:${st.balance_owed > 0 ? '#EF4444' : '#10B981'}">${fL(st.balance_owed)}</div>
  </div>
</div>
${sfDots}
${tpDots}
${discBanner}
${schBanner}` : '';
  const w = window.open('', '_blank');
  w.document.write(`<!DOCTYPE html><html><head>
<meta charset="UTF-8">
<title>Receipt ${p.receipt_number}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Times New Roman',serif;font-size:13px;color:#1a1a1a;background:#fff;}
.page{width:148mm;min-height:210mm;padding:14mm 16mm;margin:0 auto;}
@media print{.page{padding:10mm 14mm;}.np{display:none!important;}}
.rh{display:flex;align-items:center;justify-content:space-between;padding-bottom:10px;border-bottom:3px solid #1E3A8A;margin-bottom:8px;}
.lb{width:62px;height:62px;border:1px solid #CBD5E1;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:22px;background:#EFF6FF;flex-shrink:0;overflow:hidden;padding:0;}
.hc{text-align:center;flex:1;padding:0 12px;}
.sn{font-size:17px;font-weight:700;color:#1E3A8A;}
.rt{font-size:11px;color:#475569;margin-top:2px;}
.rtitle{font-size:12px;font-weight:700;color:#1E293B;margin-top:7px;text-transform:uppercase;letter-spacing:.6px;}
.rbar{background:#1E3A8A;color:#fff;padding:7px 14px;border-radius:4px;margin:10px 0;display:flex;justify-content:space-between;align-items:center;}
.rnum{font-size:15px;font-weight:700;letter-spacing:1.5px;font-family:monospace;}
.stb{padding:2px 9px;border-radius:4px;font-size:10px;font-weight:700;}
.stc{background:#D1FAE5;color:#065F46;}.stp{background:#FEF3C7;color:#92400E;}
.amt{background:#F0FDF4;border:2px solid #86EFAC;border-radius:8px;padding:13px 16px;text-align:center;margin:10px 0;}
.aml{font-size:10px;color:#4ADE80;font-weight:700;text-transform:uppercase;letter-spacing:.5px;}
.amv{font-size:28px;font-weight:700;color:#166534;}
.amm{font-size:12px;color:#166534;margin-top:3px;}
.tc{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin:10px 0;}
.inf{margin-bottom:6px;}
.il{font-size:9px;color:#94A3B8;font-weight:700;text-transform:uppercase;letter-spacing:.4px;}
.iv{font-size:12px;color:#1E293B;font-weight:600;margin-top:1px;}
.sl{font-size:9px;font-weight:700;color:#94A3B8;text-transform:uppercase;letter-spacing:.6px;border-bottom:1px solid #E2E8F0;padding-bottom:3px;margin:12px 0 6px;}
table{width:100%;border-collapse:collapse;font-size:11px;margin:6px 0;}
th{background:#1E3A8A;color:#fff;padding:4px 8px;text-align:left;font-size:10px;}
td{padding:5px 8px;border-bottom:1px solid #E2E8F0;}
tr:nth-child(even) td{background:#F8FAFC;}
.right{text-align:right;}
.sg{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin:6px 0;}
.sc{border:1px solid #E2E8F0;border-radius:5px;padding:7px 9px;text-align:center;}
.scl{font-size:9px;color:#94A3B8;text-transform:uppercase;font-weight:700;letter-spacing:.3px;}
.scv{font-size:13px;font-weight:700;margin-top:2px;}
.idots{display:flex;gap:4px;flex-wrap:wrap;margin:5px 0;}
.idot{width:22px;height:22px;border-radius:50%;font-size:10px;font-weight:700;display:flex;align-items:center;justify-content:center;border:1px solid rgba(0,0,0,.08);cursor:default;}
.sig{margin-top:22px;padding-top:10px;border-top:2px solid #E2E8F0;display:flex;justify-content:space-between;font-size:11px;color:#475569;}
.sb{text-align:center;width:130px;}
.sbl{border-top:1px solid #1a1a1a;margin:26px auto 3px;width:110px;}
.pb{background:#1E3A8A;color:#fff;padding:8px 16px;text-align:center;position:sticky;top:0;z-index:100;}
.pb button{background:#fff;color:#1E3A8A;border:none;padding:5px 14px;border-radius:4px;font-size:13px;font-weight:700;cursor:pointer;margin:0 4px;}
</style></head><body>
<div class="pb np"><strong>Fee Payment Receipt</strong>
<button onclick="window.print()">&#x1F5A8;&#xFE0F; Print / PDF</button>
<button onclick="window.close()">&#x2715; Close</button></div>
<div class="page">
<div class="rh">
<div class="lb"><img src="/nsms/public/uploads/logos/Tanzania.png" style="width:100%;height:100%;object-fit:contain;" onerror="this.parentElement.innerHTML='&#x1F3EB;'"/></div>
<div class="hc">
<div class="sn">${s.school_name || 'Nursery School'}</div>
<div class="rt">United Republic of Tanzania</div>
<div class="rtitle">Official Fee Payment Receipt</div>
</div>
<div class="lb" style="background:#fff;"><img src="/nsms/public/uploads/logos/logo.png" style="width:100%;height:100%;object-fit:contain;" onerror="this.parentElement.innerHTML='&#x1F1F9;&#x1F1FF;'"/></div>
</div>
<div class="rbar">
<div>
  <div style="font-size:9px;opacity:.65;letter-spacing:.6px;">RECEIPT NUMBER</div>
  <div class="rnum">${p.receipt_number}</div>
</div>
<div style="text-align:center">
  <div style="font-size:9px;opacity:.65;letter-spacing:.6px;">PAYMENT DATE</div>
  <div style="font-weight:600;font-size:12px;">${dL(p.payment_date)}</div>
</div>
<div style="text-align:right">
  <span class="stb ${p.status === 'confirmed' ? 'stc' : 'stp'}">${(p.status || '').toUpperCase()}</span>
</div>
</div>
<div class="amt">
<div class="aml">Amount Received</div>
<div class="amv">${fL(p.amount)}</div>
<div class="amm">via ${mD(p.payment_method)}${p.reference_number ? ' &nbsp;&middot;&nbsp; Ref: ' + p.reference_number : ''}</div>
</div>
<div class="tc">
<div>
<div class="sl">Student Details</div>
<div class="inf"><div class="il">Student Name</div><div class="iv">${p.student_name}</div></div>
<div class="inf"><div class="il">Class</div><div class="iv">${p.class_name}</div></div>
<div class="inf"><div class="il">Parent / Guardian</div><div class="iv">${p.parent_name || '&mdash;'}</div></div>
${p.parent_relationship ? `<div class="inf"><div class="il">Relationship</div><div class="iv">${p.parent_relationship}</div></div>` : ''}
</div>
<div>
<div class="sl">Payment Details</div>
<div class="inf"><div class="il">Payment Method</div><div class="iv">${mD(p.payment_method)}</div></div>
<div class="inf"><div class="il">Date Paid</div><div class="iv">${dL(p.payment_date)}</div></div>
${p.reference_number ? `<div class="inf"><div class="il">Reference / Control No.</div><div class="iv" style="font-family:monospace;font-size:12px;">${p.reference_number}</div></div>` : ''}
<div class="inf"><div class="il">Academic Year</div><div class="iv">${st ? st.academic_year : '&mdash;'}</div></div>
<div class="inf"><div class="il">Processed By</div><div class="iv">${p.recorded_by_name || '&mdash;'}</div></div>
</div>
</div>
${allocHtml}
${summaryHtml}
<div class="sig">
<div class="sb"><div class="sbl"></div><div><b>Finance Officer</b></div></div>
<div style="text-align:center;font-size:9px;color:#94A3B8;align-self:flex-end;">
  Generated ${new Date(generated_at.replace(' ', 'T')).toLocaleString('en-GB')}<br/>NSMS &mdash; ${p.receipt_number}
</div>
<div class="sb"><div class="sbl"></div><div><b>Parent / Guardian</b></div></div>
</div>
</div>
</body></html>`);
  w.document.close();
}

/* ═══════════════════════════════════════════
   MAIN PAGE
═══════════════════════════════════════════ */
function FinancePage() {
  const [sidebarOpen, setSidebarOpen] = useState(typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 768px)").matches ? false : true);
  const [year, setYear] = useState(curY());
  const [mNum, setMNum] = useState(curM());
  const month = toMS(year, mNum);
  const [ov, setOv] = useState(null);
  const [ovLoad, setOvLoad] = useState(true);
  const [ovErr, setOvErr] = useState('');
  const [tab, setTab] = useState('overview');
  const [showPay, setShowPay] = useState(false);
  const [showExp, setShowExp] = useState(false);
  const [showDisc, setShowDisc] = useState(false);
  const [pendingVerifyCount, setPendingVerifyCount] = useState(0);
  const expRef = useRef(null);
  const loadOv = useCallback(() => {
    setOvLoad(true);
    setOvErr('');
    apiFetch(`/nsms/api/finance.php?action=overview&month=${month}`).then(d => {
      if (d.success) setOv(d.data);else setOvErr(d.error || 'Unknown error — check server logs');
    }).finally(() => setOvLoad(false));
  }, [month]);
  useEffect(() => {
    loadOv();
  }, [loadOv]);

  /* Pending count for the "Verify Payments" header button badge —
     parent-submitted gateway transactions awaiting admin review. */
  useEffect(() => {
    let cancelled = false;
    const loadPending = () => {
      fetch('/nsms/api/payment-gateway.php?action=verification_stats').then(r => r.json()).then(d => {
        if (!cancelled && d.success) setPendingVerifyCount(d.data.counts.pending_verification || 0);
      }).catch(() => {});
    };
    loadPending();
    const iv = setInterval(loadPending, 30000); // refresh every 30s
    return () => {
      cancelled = true;
      clearInterval(iv);
    };
  }, []);
  const logout = async () => {
    try {
      await fetch('/nsms/api/auth.php?action=logout', {
        method: 'POST'
      });
    } catch (e) {}
    window.location.href = '/nsms/public/index.html';
  };
  const yearOpts = [];
  for (let y = curY() - 3; y <= curY() + 1; y++) yearOpts.push(y);
  const TABS = [['overview', '📊 Overview'], ['payments', '💵 Payments'], ['expenses', '📤 Expenses'], ['fees', '🏷️ Fee Structure']];
  const ml = sidebarOpen ? '220px' : '64px';
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NSMSNavbar, {
    activePage: "finance",
    onLogout: logout,
    sidebarOpen: sidebarOpen,
    setSidebarOpen: setSidebarOpen
  }), /*#__PURE__*/React.createElement(NSMSSidebar, {
    activePage: "finance",
    sidebarOpen: sidebarOpen
  }), /*#__PURE__*/React.createElement("div", {
    className: "nsms-main",
    style: {
      marginLeft: ml
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ph"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", null, "Financial Overview"), /*#__PURE__*/React.createElement("p", {
    className: "ph-sub"
  }, mLbl(month))), /*#__PURE__*/React.createElement("div", {
    className: "ha"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("select", {
    className: "psel",
    value: mNum,
    onChange: e => setMNum(Number(e.target.value))
  }, MONTHS.map((m, i) => /*#__PURE__*/React.createElement("option", {
    key: i,
    value: i + 1
  }, m))), /*#__PURE__*/React.createElement("select", {
    className: "psel",
    value: year,
    onChange: e => setYear(Number(e.target.value))
  }, yearOpts.map(y => /*#__PURE__*/React.createElement("option", {
    key: y
  }, y)))), /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    onClick: () => exportReport(month)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDDA8\uFE0F",
    size: 18
  }), " Export"), /*#__PURE__*/React.createElement("button", {
    className: "btn bp",
    onClick: () => setShowDisc(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDFF7\uFE0F",
    size: 18
  }), " Discounts"), /*#__PURE__*/React.createElement("button", {
    className: "btn bg",
    onClick: () => setShowExp(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCE4",
    size: 18
  }), " Expense"), /*#__PURE__*/React.createElement("button", {
    className: "btn bb",
    onClick: () => setShowPay(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCB5",
    size: 18
  }), " Payment"), /*#__PURE__*/React.createElement("button", {
    className: "btn bo",
    style: {
      position: 'relative'
    },
    onClick: () => window.location.href = '/nsms/public/admin/payment-verification.html'
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD0D",
    size: 18
  }), " Verify Payments", pendingVerifyCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -7,
      right: -7,
      background: '#EF4444',
      color: '#fff',
      borderRadius: 10,
      fontSize: 11,
      fontWeight: 700,
      padding: '1px 6px',
      minWidth: 18,
      textAlign: 'center',
      lineHeight: '16px',
      border: '2px solid #fff'
    }
  }, pendingVerifyCount)))), ovLoad ? /*#__PURE__*/React.createElement("div", {
    className: "sw"
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }), /*#__PURE__*/React.createElement("span", null, "Loading overview\u2026")) : ovErr ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FEF2F2',
      border: '1px solid #FCA5A5',
      borderRadius: 10,
      padding: '16px 20px',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      color: '#B91C1C',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A0\uFE0F",
    size: 18
  }), " API Error"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#991B1B',
      fontFamily: 'monospace',
      marginBottom: 10,
      wordBreak: 'break-all'
    }
  }, ovErr), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: '#7F1D1D',
      background: '#FEE2E2',
      borderRadius: 8,
      padding: '10px 14px'
    }
  }, /*#__PURE__*/React.createElement("strong", null, "If this is a \"table doesn't exist\" error:"), /*#__PURE__*/React.createElement("br", null), "Run ", /*#__PURE__*/React.createElement("code", {
    style: {
      background: 'rgba(0,0,0,.08)',
      padding: '1px 5px',
      borderRadius: 4
    }
  }, "finance_migration.sql"), " on your database to create the required tables, then refresh the page.")) : ov ? /*#__PURE__*/React.createElement("div", {
    className: "stats"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc cg"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sv"
  }, fmtM(ov.total_revenue)), /*#__PURE__*/React.createElement("div", {
    className: "sl"
  }, "Revenue This Month"), /*#__PURE__*/React.createElement("div", {
    className: "ss"
  }, fmtM(ov.total_year_revenue), " year-to-date"), (ov.scholarship_revenue || 0) > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      background: '#EDE9FE',
      border: '1px solid #C4B5FD',
      borderRadius: 8,
      padding: '4px 10px',
      fontSize: 12,
      color: '#5B21B6',
      fontWeight: 600,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83C\uDF93",
    size: 18
  }), " ", fmtM(ov.scholarship_revenue), " from ", ov.scholarship_count || 0, " scholarship student", (ov.scholarship_count || 0) !== 1 ? 's' : '')), /*#__PURE__*/React.createElement("div", {
    className: "sc cr"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sv"
  }, fmtM(ov.total_expenses)), /*#__PURE__*/React.createElement("div", {
    className: "sl"
  }, "Total Expenses"), /*#__PURE__*/React.createElement("div", {
    className: "ss"
  }, ov.expense_breakdown?.length || 0, " categories")), /*#__PURE__*/React.createElement("div", {
    className: "sc cb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sv",
    style: {
      color: ov.net_profit >= 0 ? '#2563EB' : '#EF4444'
    }
  }, fmtNet(ov.net_profit)), /*#__PURE__*/React.createElement("div", {
    className: "sl"
  }, "Net ", ov.net_profit >= 0 ? 'Profit' : 'Loss')), /*#__PURE__*/React.createElement("div", {
    className: "sc co"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sv"
  }, fmtM(ov.pending_amount)), /*#__PURE__*/React.createElement("div", {
    className: "sl"
  }, "Pending Payments"), /*#__PURE__*/React.createElement("div", {
    className: "ss"
  }, ov.pending_count, " student", ov.pending_count !== 1 ? 's' : '', " with balance"))) : /*#__PURE__*/React.createElement("div", {
    className: "fok"
  }, "\u2139\uFE0F No financial data for ", mLbl(month), "."), /*#__PURE__*/React.createElement("div", {
    className: "tabs"
  }, TABS.map(([k, l]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    className: `tab${tab === k ? ' on' : ''}`,
    onClick: () => setTab(k)
  }, l))), tab === 'overview' && /*#__PURE__*/React.createElement(OverviewTab, {
    ov: ov
  }), tab === 'payments' && /*#__PURE__*/React.createElement(PaymentsTab, {
    month: month
  }), tab === 'expenses' && /*#__PURE__*/React.createElement(ExpensesTab, {
    month: month,
    refreshRef: expRef
  }), tab === 'fees' && /*#__PURE__*/React.createElement(FeeStructureTab, null)), showDisc && /*#__PURE__*/React.createElement(DiscountModal, {
    onClose: () => setShowDisc(false),
    onSaved: loadOv
  }), showPay && /*#__PURE__*/React.createElement(PaymentModal, {
    onClose: () => setShowPay(false),
    onSaved: loadOv
  }), showExp && /*#__PURE__*/React.createElement(ExpenseModal, {
    onClose: () => setShowExp(false),
    onSaved: () => {
      loadOv();
      if (expRef.current) expRef.current();
    }
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(FinancePage, null));