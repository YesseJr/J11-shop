/* ═══════════════════════════════════════════════════════════════
   NSMS PARENT SHARED COMPONENTS  —  nsms/public/includes/js/parent-shared.js
   Self-contained — no dependency on nsms-shared.js
   Exposes globals: ParentNavbar, ParentSidebar

   Requires: React loaded before this file.

   ── Bell architecture (mirrors TcBell in teacher-shared.js) ─────
   • PrBell is fully tabbed (⚡ J11 Pulse + 📣 Alerts) with live
     polling, per-alert mark-as-read, and a bell-pulse animation —
     identical pattern to TcBell.
   • J11 Pulse tab links to parent/parent-pulse.html (parent Pulse inbox).
   • Alerts tab shows merged auto-notifications + pulse_alert items.
   • API endpoints:
       parent-panel.php?action=notifications_count
         → { msgs, notifications, pulse, total }
       parent-panel.php?action=notifications
         → { notifications: [...], pulse: [...] }
       parent-panel.php?action=mark_notifications_read
         POST { source: 'notification'|'pulse' }          — mark all
         POST { source: 'notification'|'pulse', id: N }   — mark one
       parent-panel.php?action=generate_notifications
   • Fast poll (10 s) refreshes badge + alert list silently.
   • Slow poll (5 min) also re-seeds notifications via
     generate_notifications.

   ── Navbar / Sidebar alignment ────────────────────────────────
   • <nav> uses className "nsms-nav"   (matches NSMSNavbar / TeacherNavbar)
   • toggle button uses "nav-toggle"   (matches both)
   • <aside> uses "nsms-sidebar"       (matches both)
   • All shared layout classes identical to nsms-shared.js
   • Child selector lives in nav-right (before the bell), keeping
     nav-brand → nav-links → nav-center → nav-right clean.
   • Child selector shows real student photo_url (or initials fallback)
     for both the trigger button and each dropdown row, matching the
     att-child-avatar pattern in dashboard.html.
   • Dropdown includes an "All Students" sentinel option (id: null).
═══════════════════════════════════════════════════════════════ */

/* ── Avatar helpers ── */
var PR_AV_COLORS = ['#10B981', '#2563EB', '#F59E0B', '#8B5CF6', '#EF4444', '#0891B2'];
var prAvColor = function (n) {
  return n ? PR_AV_COLORS[n.charCodeAt(0) % PR_AV_COLORS.length] : '#94A3B8';
};
var prInitials = function (n) {
  return n ? n.split(' ').map(function (w) {
    return w[0];
  }).join('').toUpperCase().slice(0, 2) : '?';
};

/* ── Parent sidebar items ──
   NOTE: 'fee_payments' now points to pay-fees.html — the multi-fee
   payment gateway page (method selection, phone/card detection,
   review + confirm flow) that replaced the older fee-payments.html
   single-item form. */
var PARENT_SIDEBAR_ITEMS = [{
  key: 'dashboard',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "home",
    size: 20
  }),
  label: 'Dashboard',
  href: '/nsms/public/parent/dashboard.html'
}, {
  key: 'daily_diary',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "calendar",
    size: 20
  }),
  label: 'Daily Diary',
  href: '/nsms/public/parent/daily-diary.html'
}, {
  key: 'reports',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "clipboard",
    size: 20
  }),
  label: 'Reports',
  href: '/nsms/public/parent/reports.html'
}, {
  key: 'attendance',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "chart",
    size: 20
  }),
  label: 'Attendance',
  href: '/nsms/public/parent/attendance.html'
}, {
  key: 'fee_payments',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "dollar",
    size: 20
  }),
  label: 'Fee Payments',
  href: '/nsms/public/parent/pay-fees.html'
}, {
  key: 'handbook',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "book",
    size: 20
  }),
  label: 'School Handbook',
  href: '/nsms/public/parent/handbook.html'
}, {
  key: 'teacher_ratings',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "star",
    size: 20
  }),
  label: 'Rate Teachers',
  href: '/nsms/public/parent/teacher-ratings.html'
}, {
  key: 'messages',
  icon: /*#__PURE__*/React.createElement(Icon, {
    name: "zap",
    size: 20
  }),
  label: 'J11 Pulse',
  href: '/nsms/public/parent/parent-pulse.html'
}];

/* ── Parent navbar quick-links (right-aligned, 4 items) ── */
var PARENT_NAV_LINKS = [{
  key: 'dashboard',
  label: 'Home',
  href: '/nsms/public/parent/dashboard.html'
}, {
  key: 'daily_diary',
  label: 'Daily Diary',
  href: '/nsms/public/parent/daily-diary.html'
}, {
  key: 'attendance',
  label: 'Attendance',
  href: '/nsms/public/parent/attendance.html'
}, {
  key: 'fee_payments',
  label: 'Pay Fees',
  href: '/nsms/public/parent/pay-fees.html'
}];

/* ── Module-level logo cache — one fetch per page load ── */
var _prLogoCache = {
  loaded: false,
  url: (function () {
    try { return localStorage.getItem('nsms_school_logo') || ''; } catch (e) { return ''; }
  })()
};
var _prLogoWaiters = [];
function _prLoadLogo(cb) {
  if (_prLogoCache.loaded) {
    cb(_prLogoCache.url);
    return;
  }
  _prLogoWaiters.push(cb);
  if (_prLogoWaiters.length > 1) return;
  fetch('/nsms/api/settings.php?action=get_public').then(function (r) {
    return r.json();
  }).then(function (d) {
    if (d.success && d.data) _prLogoCache.url = d.data.school_logo || '';
    try {
      if (_prLogoCache.url) localStorage.setItem('nsms_school_logo', _prLogoCache.url);
      else localStorage.removeItem('nsms_school_logo');
    } catch (e) {}
  }).catch(function () {}).finally(function () {
    _prLogoCache.loaded = true;
    var waiters = _prLogoWaiters.slice();
    _prLogoWaiters = [];
    waiters.forEach(function (fn) {
      fn(_prLogoCache.url);
    });
  });
}

/* ── School logo mark ── */
function PrLogoMark(props) {
  var logoUrl = props.logoUrl || '';
  if (logoUrl) {
    return /*#__PURE__*/React.createElement("img", {
      src: logoUrl,
      alt: "School Logo",
      style: {
        width: '100%',
        height: '100%',
        objectFit: 'contain',
        borderRadius: '6px',
        display: 'block'
      },
      onError: function (e) {
        e.target.style.display = 'none';
      }
    });
  }
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 21h18M5 21V7l7-4 7 4v14",
    stroke: "rgba(255,255,255,.7)",
    strokeWidth: "1.5",
    strokeLinejoin: "round"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "10",
    y: "14",
    width: "4",
    height: "7",
    rx: ".5",
    fill: "rgba(255,255,255,.9)"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "6.5",
    y: "9.5",
    width: "3",
    height: "3",
    rx: ".5",
    fill: "rgba(255,255,255,.8)"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14.5",
    y: "9.5",
    width: "3",
    height: "3",
    rx: ".5",
    fill: "rgba(255,255,255,.8)"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "3.2",
    x2: "12",
    y2: "1",
    stroke: "rgba(255,255,255,.7)",
    strokeWidth: "1.2"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "12,1 15,2.2 12,3.4",
    fill: "rgba(255,255,255,.9)"
  }));
}

/* ═══════════════════════════════════════════════════════════════
   LIVE CLOCK  (centre of navbar — identical to TcNavClock)
═══════════════════════════════════════════════════════════════ */
function PrNavClock() {
  var useState = React.useState;
  var useEffect = React.useEffect;
  var nowSt = useState(new Date());
  var now = nowSt[0];
  var setNow = nowSt[1];
  useEffect(function () {
    var t = setInterval(function () {
      setNow(new Date());
    }, 1000);
    return function () {
      clearInterval(t);
    };
  }, []);
  function ordinal(n) {
    var s = ['th', 'st', 'nd', 'rd'],
      v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
  }
  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  var dateStr = ordinal(now.getDate()) + ' ' + MONTHS[now.getMonth()] + ' ' + now.getFullYear();
  var hh = String(now.getHours()).padStart(2, '0');
  var mm = String(now.getMinutes()).padStart(2, '0');
  var ss = String(now.getSeconds()).padStart(2, '0');
  return /*#__PURE__*/React.createElement("div", {
    className: "nav-center"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-date-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-date-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCC5",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "nav-date-text"
  }, dateStr)), /*#__PURE__*/React.createElement("div", {
    className: "nav-center-sep"
  }), /*#__PURE__*/React.createElement("div", {
    className: "nav-time-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-time-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD50",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "nav-time-text"
  }, hh, ":", mm, ":", ss)));
}

/* ═══════════════════════════════════════════════════════════════
   PARENT PROFILE MODAL
   Mirrors the pf-* class structure used by NSMSProfileModal in
   nsms-shared.js for a consistent, polished look.
═══════════════════════════════════════════════════════════════ */
function ParentProfileModal(props) {
  var open = props.open;
  var onClose = props.onClose;
  var onPhotoUpdate = props.onPhotoUpdate;
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useRef = React.useRef;
  var profSt = useState(null);
  var profile = profSt[0];
  var setProfile = profSt[1];
  var loadSt = useState(true);
  var loading = loadSt[0];
  var setLoading = loadSt[1];
  var saveSt = useState(false);
  var saving = saveSt[0];
  var setSaving = saveSt[1];
  var alertSt = useState(null);
  var alert = alertSt[0];
  var setAlert = alertSt[1];
  var editSt = useState(false);
  var editMode = editSt[0];
  var setEditMode = editSt[1];
  var showPwSt = useState(false);
  var showPw = showPwSt[0];
  var setShowPw = showPwSt[1];
  var prevSt = useState(null);
  var preview = prevSt[0];
  var setPreview = prevSt[1];
  var upSt = useState(false);
  var uploading = upSt[0];
  var setUploading = upSt[1];
  var photoErrSt = useState(false);
  var photoErr = photoErrSt[0];
  var setPhotoErr = photoErrSt[1];
  var formSt = useState({
    full_name: '',
    email: '',
    phone: ''
  });
  var form = formSt[0];
  var setForm = formSt[1];
  var pwSt = useState({
    current: '',
    newPw: '',
    confirm: ''
  });
  var pw = pwSt[0];
  var setPw = pwSt[1];

  // Emergency contacts (per child)
  var ecOpenSt = useState(null);
  var ecOpenFor = ecOpenSt[0];
  var setEcOpenFor = ecOpenSt[1];
  var ecListSt = useState([]);
  var ecList = ecListSt[0];
  var setEcList = ecListSt[1];
  var ecLoadSt = useState(false);
  var ecLoading = ecLoadSt[0];
  var setEcLoading = ecLoadSt[1];
  var ecFormOpenSt = useState(false);
  var ecFormOpen = ecFormOpenSt[0];
  var setEcFormOpen = ecFormOpenSt[1];
  var ecEditIdSt = useState(null);
  var ecEditId = ecEditIdSt[0];
  var setEcEditId = ecEditIdSt[1];
  var ecSavingSt = useState(false);
  var ecSaving = ecSavingSt[0];
  var setEcSaving = ecSavingSt[1];
  var ecErrSt = useState('');
  var ecErr = ecErrSt[0];
  var setEcErr = ecErrSt[1];
  var ecFormSt = useState({
    full_name: '',
    relationship: '',
    phone: '',
    alt_phone: '',
    notes: ''
  });
  var ecForm = ecFormSt[0];
  var setEcForm = ecFormSt[1];
  var fileRef = useRef(null);
  useEffect(function () {
    if (!open) return;
    setLoading(true);
    setAlert(null);
    setEditMode(false);
    setShowPw(false);
    setPreview(null);
    setPhotoErr(false);
    setPw({
      current: '',
      newPw: '',
      confirm: ''
    });
    setEcOpenFor(null);
    setEcList([]);
    setEcFormOpen(false);
    setEcEditId(null);
    setEcErr('');
    fetch('/nsms/api/parent-panel.php?action=get_profile').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setProfile(d.data);
        setForm({
          full_name: d.data.full_name || '',
          email: d.data.email || '',
          phone: d.data.phone || ''
        });
      } else {
        setAlert({
          type: 'error',
          msg: d.error || 'Failed to load profile.'
        });
      }
    }).catch(function () {
      setAlert({
        type: 'error',
        msg: 'Network error loading profile.'
      });
    }).finally(function () {
      setLoading(false);
    });
  }, [open]);
  useEffect(function () {
    if (!open) return;
    var onKey = function (e) {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return function () {
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);
  if (!open) return null;
  var hasPhoto = !photoErr && profile && profile.photo_url;
  var dispPhoto = preview || (hasPhoto ? profile.photo_url : null);
  function setF(k, v) {
    setForm(function (f) {
      var n = Object.assign({}, f);
      n[k] = v;
      return n;
    });
  }
  function setP(k, v) {
    setPw(function (p) {
      var n = Object.assign({}, p);
      n[k] = v;
      return n;
    });
  }
  function handlePhotoChange(e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setAlert({
        type: 'error',
        msg: 'Image must be under 5 MB.'
      });
      return;
    }

    /* Show preview immediately */
    var reader = new FileReader();
    reader.onload = function (ev) {
      setPreview(ev.target.result);
    };
    reader.readAsDataURL(file);

    /* Upload straight away — don't wait for a second button click */
    var fd = new FormData();
    fd.append('photo', file);
    setUploading(true);
    setAlert(null);
    fetch('/nsms/api/parent-panel.php?action=upload_photo', {
      method: 'POST',
      body: fd
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setProfile(function (p) {
          return Object.assign({}, p, {
            photo_url: d.data.photo_url
          });
        });
        setPhotoErr(false);
        setPreview(null);
        setAlert({
          type: 'success',
          msg: 'Photo updated.'
        });
        if (onPhotoUpdate) {
          onPhotoUpdate(d.data.photo_url);
        }
      } else {
        setAlert({
          type: 'error',
          msg: d.error || 'Upload failed.'
        });
        setPreview(null);
      }
    }).catch(function () {
      setAlert({
        type: 'error',
        msg: 'Network error during upload.'
      });
      setPreview(null);
    }).finally(function () {
      setUploading(false);
    });
  }
  function handleSave() {
    if (!form.full_name.trim()) {
      setAlert({
        type: 'error',
        msg: 'Full name is required.'
      });
      return;
    }
    if (showPw) {
      if (!pw.current) {
        setAlert({
          type: 'error',
          msg: 'Enter your current password.'
        });
        return;
      }
      if (!pw.newPw) {
        setAlert({
          type: 'error',
          msg: 'Enter a new password.'
        });
        return;
      }
      if (pw.newPw.length < 6) {
        setAlert({
          type: 'error',
          msg: 'New password must be at least 6 characters.'
        });
        return;
      }
      if (pw.newPw !== pw.confirm) {
        setAlert({
          type: 'error',
          msg: 'New passwords do not match.'
        });
        return;
      }
    }
    var body = {
      full_name: form.full_name.trim(),
      phone: form.phone.trim()
    };
    if (showPw) {
      body.change_password = true;
      body.current_password = pw.current;
      body.new_password = pw.newPw;
    }
    setSaving(true);
    setAlert(null);
    fetch('/nsms/api/parent-panel.php?action=update_profile', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setProfile(function (p) {
          return Object.assign({}, p, {
            full_name: form.full_name,
            phone: form.phone
          });
        });
        setAlert({
          type: 'success',
          msg: 'Profile updated successfully.'
        });
        setEditMode(false);
        setShowPw(false);
        setPw({
          current: '',
          newPw: '',
          confirm: ''
        });
      } else {
        setAlert({
          type: 'error',
          msg: d.error || 'Update failed.'
        });
      }
    }).catch(function () {
      setAlert({
        type: 'error',
        msg: 'Network error.'
      });
    }).finally(function () {
      setSaving(false);
    });
  }
  async function loadContacts(studentId) {
    setEcLoading(true);
    fetch('/nsms/api/parent-panel.php?action=get_emergency_contacts&student_id=' + studentId).then(function (r) {
      return r.json();
    }).then(function (d) {
      setEcList(d.success ? d.data : []);
    }).catch(function () {
      setEcList([]);
    }).finally(function () {
      setEcLoading(false);
    });
  }
  async function toggleChild(studentId) {
    if (ecOpenFor === studentId) {
      setEcOpenFor(null);
      return;
    }
    setEcOpenFor(studentId);
    setEcFormOpen(false);
    setEcEditId(null);
    setEcErr('');
    loadContacts(studentId);
  }
  async function openAddContact() {
    setEcForm({
      full_name: '',
      relationship: '',
      phone: '',
      alt_phone: '',
      notes: ''
    });
    setEcEditId(null);
    setEcFormOpen(true);
    setEcErr('');
  }
  async function openEditContact(c) {
    setEcForm({
      full_name: c.full_name || '',
      relationship: c.relationship || '',
      phone: c.phone || '',
      alt_phone: c.alt_phone || '',
      notes: c.notes || ''
    });
    setEcEditId(c.id);
    setEcFormOpen(true);
    setEcErr('');
  }
  async function setEc(k, v) {
    setEcForm(function (f) {
      var n = Object.assign({}, f);
      n[k] = v;
      return n;
    });
  }
  async function saveContact() {
    if (!ecForm.full_name.trim()) {
      setEcErr('Contact name is required.');
      return;
    }
    if (!ecForm.relationship.trim()) {
      setEcErr('Relationship is required.');
      return;
    }
    if (!ecForm.phone.trim()) {
      setEcErr('Phone number is required.');
      return;
    }
    setEcSaving(true);
    setEcErr('');
    var body = Object.assign({
      student_id: ecOpenFor,
      id: ecEditId
    }, ecForm);
    fetch('/nsms/api/parent-panel.php?action=save_emergency_contact', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setEcFormOpen(false);
        loadContacts(ecOpenFor);
      } else setEcErr(d.error || 'Failed to save contact.');
    }).catch(function () {
      setEcErr('Network error. Please try again.');
    }).finally(function () {
      setEcSaving(false);
    });
  }
  async function deleteContact(id) {
    if (!(await (window.NSMS && window.NSMS.confirm ? window.NSMS.confirm({ title: 'Remove contact?', message: 'Remove this emergency contact?', confirmLabel: 'Remove', variant: 'danger' }) : Promise.resolve(false)))) return;
    fetch('/nsms/api/parent-panel.php?action=delete_emergency_contact&id=' + id, {
      method: 'DELETE'
    }).then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) loadContacts(ecOpenFor);
    }).catch(function () {});
  }
  var loadSpinner = /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '60px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "spinner"
  }));
  return /*#__PURE__*/React.createElement("div", {
    className: "pf-overlay",
    onClick: function (e) {
      if (e.target === e.currentTarget) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-modal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pf-header-title"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC64",
    size: 18
  }), " My Profile"), /*#__PURE__*/React.createElement("button", {
    className: "pf-close",
    onClick: onClose,
    title: "Close"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2715",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "pf-body"
  }, loading ? loadSpinner : /*#__PURE__*/React.createElement(React.Fragment, null, alert && /*#__PURE__*/React.createElement("div", {
    className: 'pf-alert ' + (alert.type === 'success' ? 'pf-alert-success' : 'pf-alert-error')
  }, /*#__PURE__*/React.createElement("span", null, alert.type === 'success' ? /*#__PURE__*/React.createElement(Icon, {
    name: "check-circle",
    size: 16
  }) : /*#__PURE__*/React.createElement(Icon, {
    name: "alert-triangle",
    size: 16
  })), /*#__PURE__*/React.createElement("span", null, alert.msg)), /*#__PURE__*/React.createElement("div", {
    className: "pf-photo-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-photo-ring"
  }, dispPhoto ? /*#__PURE__*/React.createElement("img", {
    className: "pf-photo",
    src: dispPhoto,
    alt: "Profile",
    onError: function () {
      setPhotoErr(true);
    }
  }) : /*#__PURE__*/React.createElement("div", {
    className: "pf-photo-initials",
    style: {
      background: prAvColor(profile ? profile.full_name : '')
    }
  }, prInitials(profile ? profile.full_name : '')), /*#__PURE__*/React.createElement("button", {
    className: "pf-photo-btn",
    title: "Change photo",
    onClick: function () {
      fileRef.current && fileRef.current.click();
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCF7",
    size: 18
  })), uploading && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 3,
      borderRadius: '50%',
      background: 'rgba(0,0,0,.55)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#fff',
      fontSize: 11,
      fontWeight: 700
    }
  }, "Uploading\u2026")), /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    accept: "image/*",
    style: {
      display: 'none'
    },
    onChange: handlePhotoChange
  }), /*#__PURE__*/React.createElement("div", {
    className: "pf-role-badge"
  }, "Parent Account"), /*#__PURE__*/React.createElement("div", {
    className: "pf-photo-change-text"
  }, uploading ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#6B7280'
    }
  }, "Uploading photo\u2026") : /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      fileRef.current && fileRef.current.click();
    }
  }, "Click to change photo"), ' (JPG / PNG, max 3 MB)'))), /*#__PURE__*/React.createElement("div", {
    className: "pf-sep"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--text-mid)',
      textTransform: 'uppercase',
      letterSpacing: '.5px'
    }
  }, "Personal Information"), !editMode && /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      setEditMode(true);
      setAlert(null);
    },
    style: {
      border: 'none',
      background: 'var(--blue-light)',
      color: 'var(--blue)',
      padding: '5px 12px',
      borderRadius: 7,
      fontSize: 12,
      fontWeight: 700,
      cursor: 'pointer',
      fontFamily: 'var(--font)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u270F\uFE0F",
    size: 18
  }), " Edit")), /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Full Name"), editMode ? /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    value: form.full_name,
    onChange: function (e) {
      setF('full_name', e.target.value);
    },
    placeholder: "Your full name"
  }) : /*#__PURE__*/React.createElement("div", {
    className: "pf-input-ro"
  }, profile ? profile.full_name : '—')), /*#__PURE__*/React.createElement("div", {
    className: "pf-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Email Address"), /*#__PURE__*/React.createElement("div", {
    className: "pf-input-ro",
    style: {
      opacity: .7
    }
  }, profile ? profile.email : '—')), /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Phone Number"), editMode ? /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    type: "tel",
    value: form.phone,
    onChange: function (e) {
      setF('phone', e.target.value);
    },
    placeholder: "+255 7xx xxx xxx"
  }) : /*#__PURE__*/React.createElement("div", {
    className: "pf-input-ro"
  }, profile && profile.phone ? profile.phone : '—'))), profile && profile.children && profile.children.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "pf-sep"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--text-mid)',
      textTransform: 'uppercase',
      letterSpacing: '.5px',
      marginBottom: 10
    }
  }, "My Children \u2014 Emergency Contacts"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      marginBottom: 4
    }
  }, profile.children.map(function (c, i) {
    var isOpen = ecOpenFor === c.id;
    return /*#__PURE__*/React.createElement("div", {
      className: "ec-child-block",
      key: i
    }, /*#__PURE__*/React.createElement("button", {
      className: 'ec-child-toggle' + (isOpen ? ' open' : ''),
      onClick: function () {
        toggleChild(c.id);
      }
    }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83C\uDF92",
      size: 18
    }), " ", c.student_name), /*#__PURE__*/React.createElement("span", {
      className: "ec-child-arrow"
    }, isOpen ? '▲' : '▼')), isOpen && /*#__PURE__*/React.createElement("div", {
      className: "ec-panel"
    }, ecLoading ? /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        padding: '10px 0'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "spinner",
      style: {
        width: 20,
        height: 20
      }
    })) : /*#__PURE__*/React.createElement(React.Fragment, null, ecList.length === 0 && !ecFormOpen && /*#__PURE__*/React.createElement("div", {
      className: "ec-empty"
    }, "No emergency contacts added yet \u2014 add someone who can be reached if you're unavailable."), ecList.map(function (contact) {
      return /*#__PURE__*/React.createElement("div", {
        className: "ec-item",
        key: contact.id
      }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
        className: "ec-item-name"
      }, contact.full_name, " ", /*#__PURE__*/React.createElement("span", {
        className: "ec-item-rel"
      }, "\xB7 ", contact.relationship)), /*#__PURE__*/React.createElement("div", {
        className: "ec-item-phone"
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "phone",
        size: 14
      }), " ", contact.phone, contact.alt_phone ? ' · ' + contact.alt_phone : ''), contact.notes && /*#__PURE__*/React.createElement("div", {
        className: "ec-item-notes"
      }, contact.notes)), /*#__PURE__*/React.createElement("div", {
        className: "ec-item-actions"
      }, /*#__PURE__*/React.createElement("button", {
        onClick: function () {
          openEditContact(contact);
        },
        title: "Edit"
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "pencil",
        size: 14
      })), /*#__PURE__*/React.createElement("button", {
        onClick: function () {
          deleteContact(contact.id);
        },
        title: "Remove"
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "trash",
        size: 14
      }))));
    }), ecFormOpen ? /*#__PURE__*/React.createElement("div", {
      className: "ec-form"
    }, ecErr && /*#__PURE__*/React.createElement("div", {
      className: "pf-alert pf-alert-error",
      style: {
        marginBottom: 10
      }
    }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
      name: "alert-triangle",
      size: 14
    })), /*#__PURE__*/React.createElement("span", null, ecErr)), /*#__PURE__*/React.createElement("div", {
      className: "pf-row"
    }, /*#__PURE__*/React.createElement("div", {
      className: "pf-field"
    }, /*#__PURE__*/React.createElement("label", {
      className: "pf-label"
    }, "Full Name"), /*#__PURE__*/React.createElement("input", {
      className: "pf-input",
      value: ecForm.full_name,
      onChange: function (e) {
        setEc('full_name', e.target.value);
      },
      placeholder: "e.g. Grace Mushi"
    })), /*#__PURE__*/React.createElement("div", {
      className: "pf-field"
    }, /*#__PURE__*/React.createElement("label", {
      className: "pf-label"
    }, "Relationship"), /*#__PURE__*/React.createElement("input", {
      className: "pf-input",
      value: ecForm.relationship,
      onChange: function (e) {
        setEc('relationship', e.target.value);
      },
      placeholder: "e.g. Grandmother, Neighbour"
    }))), /*#__PURE__*/React.createElement("div", {
      className: "pf-row"
    }, /*#__PURE__*/React.createElement("div", {
      className: "pf-field"
    }, /*#__PURE__*/React.createElement("label", {
      className: "pf-label"
    }, "Phone Number"), /*#__PURE__*/React.createElement("input", {
      className: "pf-input",
      type: "tel",
      value: ecForm.phone,
      onChange: function (e) {
        setEc('phone', e.target.value);
      },
      placeholder: "+255 7xx xxx xxx"
    })), /*#__PURE__*/React.createElement("div", {
      className: "pf-field"
    }, /*#__PURE__*/React.createElement("label", {
      className: "pf-label"
    }, "Alt. Phone (optional)"), /*#__PURE__*/React.createElement("input", {
      className: "pf-input",
      type: "tel",
      value: ecForm.alt_phone,
      onChange: function (e) {
        setEc('alt_phone', e.target.value);
      },
      placeholder: "+255 7xx xxx xxx"
    }))), /*#__PURE__*/React.createElement("div", {
      className: "pf-field"
    }, /*#__PURE__*/React.createElement("label", {
      className: "pf-label"
    }, "Notes (optional)"), /*#__PURE__*/React.createElement("input", {
      className: "pf-input",
      value: ecForm.notes,
      onChange: function (e) {
        setEc('notes', e.target.value);
      },
      placeholder: "e.g. Only contact after 6pm"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "pf-btn-save",
      style: {
        flex: 'none',
        padding: '8px 18px'
      },
      onClick: saveContact,
      disabled: ecSaving
    }, ecSaving ? 'Saving…' : /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDCBE",
      size: 18
    }), " Save Contact")), /*#__PURE__*/React.createElement("button", {
      className: "pf-btn-cancel",
      style: {
        flex: 'none',
        padding: '8px 18px'
      },
      onClick: function () {
        setEcFormOpen(false);
        setEcErr('');
      }
    }, "Cancel"))) : /*#__PURE__*/React.createElement("button", {
      className: "ec-add-btn",
      onClick: openAddContact
    }, "+ Add Emergency Contact"))));
  }))), editMode && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "pf-sep"
  }), /*#__PURE__*/React.createElement("div", {
    className: "pf-pw-toggle",
    onClick: function () {
      setShowPw(function (v) {
        return !v;
      });
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: 'pf-pw-toggle-icon' + (showPw ? ' checked' : '')
  }, showPw ? /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }) : null), /*#__PURE__*/React.createElement("span", {
    className: "pf-pw-toggle-label"
  }, "Change password")), showPw && /*#__PURE__*/React.createElement("div", {
    className: "pf-pw-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Current Password"), /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    type: "password",
    value: pw.current,
    onChange: function (e) {
      setP('current', e.target.value);
    },
    placeholder: "Enter current password"
  })), /*#__PURE__*/React.createElement("div", {
    className: "pf-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "New Password"), /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    type: "password",
    value: pw.newPw,
    onChange: function (e) {
      setP('newPw', e.target.value);
    },
    placeholder: "Min. 6 characters"
  })), /*#__PURE__*/React.createElement("div", {
    className: "pf-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "pf-label"
  }, "Confirm Password"), /*#__PURE__*/React.createElement("input", {
    className: "pf-input",
    type: "password",
    value: pw.confirm,
    onChange: function (e) {
      setP('confirm', e.target.value);
    },
    placeholder: "Repeat new password"
  }))))))), /*#__PURE__*/React.createElement("div", {
    className: "pf-footer"
  }, editMode ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("button", {
    className: "pf-btn-cancel",
    onClick: function () {
      setEditMode(false);
      setAlert(null);
      setShowPw(false);
      setPw({
        current: '',
        newPw: '',
        confirm: ''
      });
      if (profile) setForm({
        full_name: profile.full_name || '',
        email: profile.email || '',
        phone: profile.phone || ''
      });
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "pf-btn-save",
    onClick: handleSave,
    disabled: saving
  }, saving ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14,
      height: 14,
      border: '2px solid rgba(255,255,255,.4)',
      borderTopColor: 'white',
      borderRadius: '50%',
      animation: 'nsmspin .7s linear infinite',
      display: 'inline-block'
    }
  }), " Saving\u2026") : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCBE",
    size: 18
  }), " Save Changes"))) : /*#__PURE__*/React.createElement("button", {
    className: "pf-btn-cancel",
    onClick: onClose
  }, "Close"))));
}

/* ═══════════════════════════════════════════════════════════════
   BELL KEYFRAME INJECTION
   Same animation curve as bellPulse in teacher-shared.js.
   Injected once per page load; safe to call multiple times.
═══════════════════════════════════════════════════════════════ */
(function () {
  if (document.getElementById('pr-bell-kf')) return;
  var s = document.createElement('style');
  s.id = 'pr-bell-kf';
  s.textContent = ['@keyframes prBellPulse {', '  0%   { transform: rotate(0deg)   scale(1);    }', '  15%  { transform: rotate(-18deg) scale(1.18); }', '  30%  { transform: rotate(14deg)  scale(1.18); }', '  45%  { transform: rotate(-10deg) scale(1.12); }', '  60%  { transform: rotate(8deg)   scale(1.08); }', '  75%  { transform: rotate(-4deg)  scale(1.04); }', '  100% { transform: rotate(0deg)   scale(1);    }', '}'].join('\n');
  document.head.appendChild(s);
})();

/* ── Parent bell sync constants (mirrors TcBell BELL_POLL_MS / REMINDER_MS) ── */
var PR_BELL_POLL_MS = 10000; /* badge + silent list refresh — 10 s  */
var PR_REMINDER_MS = 300000; /* re-seed notifications — 5 min       */

/* ═══════════════════════════════════════════════════════════════
   NOTIFICATION BELL  (PrBell)
   Full port of TcBell from teacher-shared.js, adapted for the
   parent portal's two-source alert system.

   ┌ Two tabs ─────────────────────────────────────────────────┐
   │  <Icon emoji="⚡" size={18} /> J11 Pulse  — unread message count, links to inbox     │
   │  📣 Alerts     — merged notifications + pulse_alerts,     │
   │                  mark-as-read (one or all), timeAgo        │
   └───────────────────────────────────────────────────────────┘

   API response shapes:
     notifications_count → { msgs, notifications, pulse, total }
     notifications       → { notifications: [...], pulse: [...] }

   Each alert object in the merged list carries a hidden _source
   field ('notification' or 'pulse') so markRead can route the
   POST to the correct table via mark_notifications_read.

   Sync schedule:
     PR_BELL_POLL_MS (10 s)  — fetchCounts + silentRefresh
     PR_REMINDER_MS  (5 min) — generate_notifications + fetchCounts
═══════════════════════════════════════════════════════════════ */
function PrBell() {
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useRef = React.useRef;

  /* ── state ── */
  var countsSt = useState({
    msgs: 0,
    alerts: 0
  });
  var counts = countsSt[0];
  var setCounts = countsSt[1];
  var openSt = useState(false);
  var open = openSt[0];
  var setOpen = openSt[1];
  var tabSt = useState('alerts');
  var activeTab = tabSt[0];
  var setActiveTab = tabSt[1];

  /* Merged list of notification + pulse_alert rows, each tagged with _source */
  var alertsSt = useState([]);
  var alerts = alertsSt[0];
  var setAlerts = alertsSt[1];
  var alLoadSt = useState(false);
  var alLoading = alLoadSt[0];
  var setAlLoading = alLoadSt[1];

  /* Bell pulse — fires only when total count increases.
     Single source: only fetchCounts drives the animation
     to prevent double-ring on the same event. */
  var prevTotalRef = useRef(-1);
  var pulseSt = useState(false);
  var isPulsing = pulseSt[0];
  var setIsPulsing = pulseSt[1];
  var panelRef = useRef(null);

  /* ── helpers ── */
  function timeAgo(ts) {
    if (!ts) return '';
    var d = new Date(ts.replace(' ', 'T'));
    var diff = Math.floor((Date.now() - d.getTime()) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    return Math.floor(diff / 86400) + 'd ago';
  }
  function alertIcon(type) {
    var MAP = {
      'attendance': 'chart',
      'attendance_issue': 'alert-triangle',
      'homework': 'book',
      'homework_deadline': 'pencil',
      'fee': 'dollar',
      'fee_payment': 'dollar',
      'payment': 'dollar',
      'announcement': 'megaphone',
      'report': 'clipboard',
      'exam_reminder': 'edit',
      'new_student': 'backpack',
      'class_assignment': 'school',
      'subject_assignment': 'book',
      'admin_message': 'mail',
      'teacher_message': 'message',
      'parent_message': 'family',
      'system': 'settings',
      'info': 'megaphone',
      'pulse_alert': 'bell'
    };
    var n = MAP[type] || 'megaphone';
    return typeof Icon === 'function' ? React.createElement(Icon, {
      name: n,
      size: 18
    }) : null;
  }
  function alertColors(type, unread) {
    if (!unread) return {
      bg: '#FAFBFC',
      border: '#F1F5F9',
      iconBg: '#F1F5F9'
    };
    var T = {
      'attendance': {
        bg: '#FFF1F2',
        border: '#FECDD3',
        iconBg: '#FFE4E6'
      },
      'attendance_issue': {
        bg: '#FFF1F2',
        border: '#FECDD3',
        iconBg: '#FFE4E6'
      },
      'homework': {
        bg: '#F5F3FF',
        border: '#DDD6FE',
        iconBg: '#EDE9FE'
      },
      'homework_deadline': {
        bg: '#FFFBEB',
        border: '#FDE68A',
        iconBg: '#FEF3C7'
      },
      'fee': {
        bg: '#F0FDF4',
        border: '#BBF7D0',
        iconBg: '#DCFCE7'
      },
      'fee_payment': {
        bg: '#F0FDF4',
        border: '#BBF7D0',
        iconBg: '#DCFCE7'
      },
      'payment': {
        bg: '#F0FDF4',
        border: '#BBF7D0',
        iconBg: '#DCFCE7'
      },
      'exam_reminder': {
        bg: '#FFF7ED',
        border: '#FED7AA',
        iconBg: '#FFEDD5'
      },
      'class_assignment': {
        bg: '#EFF6FF',
        border: '#BFDBFE',
        iconBg: '#DBEAFE'
      },
      'subject_assignment': {
        bg: '#F5F3FF',
        border: '#DDD6FE',
        iconBg: '#EDE9FE'
      },
      'announcement': {
        bg: '#F0F9FF',
        border: '#BAE6FD',
        iconBg: '#E0F2FE'
      },
      'teacher_message': {
        bg: '#F0F9FF',
        border: '#BAE6FD',
        iconBg: '#E0F2FE'
      },
      'parent_message': {
        bg: '#F5F3FF',
        border: '#DDD6FE',
        iconBg: '#EDE9FE'
      },
      'pulse_alert': {
        bg: '#FFF7ED',
        border: '#FED7AA',
        iconBg: '#FFEDD5'
      }
    };
    return T[type] || {
      bg: '#FFFBEB',
      border: '#FDE68A',
      iconBg: '#FEF3C7'
    };
  }

  /* ─────────────────────────────────────────────────────────
     mergeAlerts — joins the two arrays from the notifications
     response, tags each item with _source, then sorts by
     created_at DESC so the newest alert always appears first.
  ───────────────────────────────────────────────────────── */
  function mergeAlerts(data) {
    var notifs = (data.notifications || []).map(function (n) {
      return Object.assign({}, n, {
        _source: 'notification'
      });
    });
    var pulse = (data.pulse || []).map(function (p) {
      /* Prefix pulse IDs with 'p' so they can't collide with
         notification IDs when we do id-based lookups in markRead. */
      return Object.assign({}, p, {
        _source: 'pulse',
        _uid: 'p' + p.id
      });
    });
    var merged = notifs.concat(pulse);
    merged.sort(function (a, b) {
      var ta = new Date((a.created_at || '').replace(' ', 'T')).getTime();
      var tb = new Date((b.created_at || '').replace(' ', 'T')).getTime();
      return tb - ta;
    });
    return merged;
  }

  /* ── API ── */

  /*
   * Lightweight — two COUNT queries only.
   * API response: { msgs, notifications, pulse, total }
   *   msgs         → J11 Pulse tab badge (unread messages)
   *   notifications + pulse → Alerts tab badge (all system alerts)
   */
  function fetchCounts() {
    fetch('/nsms/api/parent-panel.php?action=notifications_count').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) return;
      var nm = d.data.msgs || 0;
      var na = (d.data.notifications || 0) + (d.data.pulse || 0);
      var tot = nm + na;
      /* Pulse bell only when total increases (not on first load) */
      if (tot > prevTotalRef.current && prevTotalRef.current !== -1) {
        setIsPulsing(true);
        setTimeout(function () {
          setIsPulsing(false);
        }, 820);
      }
      prevTotalRef.current = tot;
      setCounts({
        msgs: nm,
        alerts: na
      });
    }).catch(function () {});
  }

  /*
   * Full fetch — shows shimmer. Only called on first panel open.
   * API response: { notifications: [...], pulse: [...] }
   */
  function fetchAlerts() {
    setAlLoading(true);
    fetch('/nsms/api/parent-panel.php?action=notifications').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) return;
      var merged = mergeAlerts(d.data || {});
      setAlerts(merged);
      var unread = merged.filter(function (a) {
        return !a.is_read || a.is_read == 0;
      }).length;
      setCounts(function (c) {
        return Object.assign({}, c, {
          alerts: unread
        });
      });
      fetchCounts(); /* sync message badge too */
    }).catch(function () {}).finally(function () {
      setAlLoading(false);
    });
  }

  /*
   * Silent refresh — no shimmer. Runs on every fast tick
   * regardless of whether the panel is open.
   */
  function silentRefresh() {
    fetch('/nsms/api/parent-panel.php?action=notifications').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (!d.success) return;
      var merged = mergeAlerts(d.data || {});
      setAlerts(merged);
      var unread = merged.filter(function (a) {
        return !a.is_read || a.is_read == 0;
      }).length;
      setCounts(function (c) {
        return Object.assign({}, c, {
          alerts: unread
        });
      });
    }).catch(function () {});
  }

  /*
   * markRead(id)
   *   id === 0  → mark ALL alerts as read (calls endpoint for each source)
   *   id  >  0  → mark single item; resolves _source from the merged list
   *
   * POST body: { source: 'notification'|'pulse' }         — mark all
   *            { source: 'notification'|'pulse', id: N }  — mark one
   *
   * PHP mark_notifications_read must handle the optional id field.
   * (See parent-panel.php — mark_notifications_read case.)
   */
  function markRead(id) {
    if (id === 0) {
      /* Mark all — one request per source table */
      ['notification', 'pulse'].forEach(function (src) {
        fetch('/nsms/api/parent-panel.php?action=mark_notifications_read', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            source: src
          })
        }).catch(function () {});
      });
      /* Optimistic UI update */
      setAlerts(function (prev) {
        return prev.map(function (a) {
          return Object.assign({}, a, {
            is_read: 1
          });
        });
      });
      setCounts(function (c) {
        return Object.assign({}, c, {
          alerts: 0
        });
      });
    } else {
      /* Find the item to get its _source */
      var found = null;
      for (var i = 0; i < alerts.length; i++) {
        if (alerts[i].id === id) {
          found = alerts[i];
          break;
        }
      }
      var src = found && found._source ? found._source : 'notification';
      fetch('/nsms/api/parent-panel.php?action=mark_notifications_read', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          source: src,
          id: id
        })
      }).then(function () {
        setAlerts(function (prev) {
          return prev.map(function (a) {
            return a.id === id ? Object.assign({}, a, {
              is_read: 1
            }) : a;
          });
        });
        setCounts(function (c) {
          return Object.assign({}, c, {
            alerts: Math.max(0, c.alerts - 1)
          });
        });
      }).catch(function () {});
    }
  }

  /* ── effects ── */

  /* Mount: -1 sentinel prevents false pulse on first load */
  useEffect(function () {
    prevTotalRef.current = -1;

    /* Seed notifications in background on mount */
    fetch('/nsms/api/parent-panel.php?action=generate_notifications').catch(function () {});
    fetchCounts();
    silentRefresh(); /* initialise alert badge from full list */

    /* fastT — badge + silent list refresh every PR_BELL_POLL_MS */
    var fastT = setInterval(function () {
      fetchCounts();
      silentRefresh();
    }, PR_BELL_POLL_MS);

    /* slowT — re-seed notifications + sync counts every 5 min */
    var slowT = setInterval(function () {
      fetch('/nsms/api/parent-panel.php?action=generate_notifications').catch(function () {});
      fetchCounts();
    }, PR_REMINDER_MS);
    return function () {
      clearInterval(fastT);
      clearInterval(slowT);
    };
  }, []);

  /* Panel open: full list load with shimmer + outside-click close */
  useEffect(function () {
    if (!open) return;
    fetchAlerts();
    var close = function (e) {
      if (panelRef.current && !panelRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', close);
    return function () {
      document.removeEventListener('mousedown', close);
    };
  }, [open]);
  var total = counts.msgs + counts.alerts;
  var badgeNum = total > 99 ? '99+' : total;

  /* ── render ── */
  return /*#__PURE__*/React.createElement("div", {
    ref: panelRef,
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      setOpen(function (o) {
        return !o;
      });
    },
    style: {
      position: 'relative',
      width: 40,
      height: 40,
      borderRadius: 9,
      border: 'none',
      background: open ? 'var(--blue-light)' : 'none',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 20,
      transition: 'background .15s',
      flexShrink: 0
    },
    title: "Notifications"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      transformOrigin: '50% 10%',
      animation: isPulsing ? 'prBellPulse .82s ease' : 'none'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  })), total > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      right: 3,
      minWidth: 16,
      height: 16,
      borderRadius: 8,
      background: '#EF4444',
      color: 'white',
      fontSize: 9,
      fontWeight: 800,
      lineHeight: '16px',
      textAlign: 'center',
      padding: '0 3px',
      border: '1.5px solid white',
      fontFamily: 'var(--font)'
    }
  }, badgeNum)), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(var(--nav-h) + 4px)',
      right: 0,
      background: 'white',
      border: '1px solid var(--border)',
      borderRadius: 14,
      boxShadow: '0 12px 40px rgba(0,0,0,.15)',
      width: 330,
      overflow: 'hidden',
      zIndex: 1100,
      animation: 'navDrop .18s ease'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'linear-gradient(135deg,#2563EB,#1E40AF)',
      padding: '14px 16px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'white'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDD14",
    size: 18
  }), " Notifications"), total > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'rgba(255,255,255,.22)',
      color: 'white',
      fontSize: 11,
      fontWeight: 700,
      padding: '2px 8px',
      borderRadius: 20
    }
  }, total, " unread")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4
    }
  }, [{
    id: 'messages',
    label: 'J11 Pulse',
    badge: counts.msgs
  }, {
    id: 'alerts',
    label: 'Alerts',
    badge: counts.alerts
  }].map(function (tab) {
    var isActive = activeTab === tab.id;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.id,
      onClick: function () {
        setActiveTab(tab.id);
      },
      style: {
        flex: 1,
        padding: '8px 6px',
        borderRadius: '8px 8px 0 0',
        border: 'none',
        cursor: 'pointer',
        fontSize: 12.5,
        fontWeight: 700,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 5,
        background: isActive ? 'white' : 'rgba(255,255,255,.16)',
        color: isActive ? '#1E40AF' : 'rgba(255,255,255,.88)',
        transition: 'all .15s',
        fontFamily: 'var(--font)'
      }
    }, tab.label, tab.badge > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        background: isActive ? '#EF4444' : 'rgba(255,255,255,.28)',
        color: 'white',
        fontSize: 10,
        fontWeight: 800,
        padding: '1px 5px',
        borderRadius: 10,
        minWidth: 16,
        textAlign: 'center'
      }
    }, tab.badge));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 360,
      overflowY: 'auto'
    }
  }, activeTab === 'messages' && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 10px'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/parent/parent-pulse.html",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '13px 14px',
      borderRadius: 11,
      background: counts.msgs > 0 ? '#F0F9FF' : '#FAFBFC',
      border: counts.msgs > 0 ? '1.5px solid #BFDBFE' : '1.5px solid #F1F5F9',
      color: 'var(--text-mid)',
      textDecoration: 'none',
      transition: 'background .15s'
    },
    onMouseOver: function (e) {
      e.currentTarget.style.background = '#EFF6FF';
    },
    onMouseOut: function (e) {
      e.currentTarget.style.background = counts.msgs > 0 ? '#F0F9FF' : '#FAFBFC';
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      fontWeight: 700,
      color: 'var(--text-dark)'
    }
  }, "J11 Pulse"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, counts.msgs > 0 ? counts.msgs + ' unread message' + (counts.msgs > 1 ? 's' : '') : 'No unread messages')), counts.msgs > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      background: '#2563EB',
      color: 'white',
      fontSize: 12,
      fontWeight: 800,
      padding: '3px 10px',
      borderRadius: 20
    }
  }, counts.msgs)), counts.msgs === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '18px 0 10px',
      color: 'var(--text-muted)',
      fontSize: 12.5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 26,
      marginBottom: 5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  })), "All messages read")), activeTab === 'alerts' && /*#__PURE__*/React.createElement("div", null, alLoading ?
  /*#__PURE__*/
  /* Shimmer placeholder rows */
  React.createElement("div", {
    style: {
      padding: '14px 12px',
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, [1, 2, 3].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        height: 60,
        borderRadius: 10,
        background: 'linear-gradient(90deg,#F1F5F9 25%,#E9EEF3 50%,#F1F5F9 75%)',
        backgroundSize: '200% 100%',
        animation: 'shim 1.4s infinite'
      }
    });
  })) : alerts.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '32px 0',
      color: 'var(--text-muted)',
      fontSize: 12.5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 28,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDCED",
    size: 18
  })), "No system alerts") : /*#__PURE__*/React.createElement(React.Fragment, null, counts.alerts > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      padding: '8px 14px 2px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      markRead(0);
    },
    style: {
      border: 'none',
      background: 'none',
      color: 'var(--blue)',
      fontSize: 11.5,
      fontWeight: 700,
      cursor: 'pointer',
      fontFamily: 'var(--font)',
      padding: '2px 6px',
      borderRadius: 5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " Mark all read")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 10px 10px'
    }
  }, alerts.map(function (al) {
    var unread = !al.is_read || al.is_read == 0;
    var clr = alertColors(al.type, unread);
    return /*#__PURE__*/React.createElement("div", {
      key: (al._source || '') + al.id,
      style: {
        display: 'flex',
        gap: 10,
        padding: '11px 12px',
        borderRadius: 11,
        marginBottom: 7,
        background: clr.bg,
        border: '1.5px solid ' + clr.border,
        transition: 'background .15s, border-color .15s'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 34,
        height: 34,
        borderRadius: 9,
        flexShrink: 0,
        background: clr.iconBg,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 17
      }
    }, alertIcon(al.type)), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: unread ? 700 : 600,
        color: 'var(--text-dark)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, al.title || 'Alert'), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-soft)',
        marginTop: 2,
        lineHeight: 1.4,
        display: '-webkit-box',
        WebkitLineClamp: 2,
        WebkitBoxOrient: 'vertical',
        overflow: 'hidden'
      }
    }, al.message), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10.5,
        color: 'var(--text-muted)',
        marginTop: 5
      }
    }, timeAgo(al.created_at))), unread && /*#__PURE__*/React.createElement("button", {
      onClick: function () {
        markRead(al.id);
      },
      title: "Mark as read",
      style: {
        border: 'none',
        background: 'none',
        cursor: 'pointer',
        padding: '2px 4px',
        color: '#94A3B8',
        fontSize: 14,
        alignSelf: 'flex-start',
        flexShrink: 0,
        fontFamily: 'var(--font)',
        lineHeight: 1
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2715",
      size: 18
    })));
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border)',
      padding: '8px 10px',
      background: '#FAFBFC'
    }
  }, activeTab === 'messages' ? /*#__PURE__*/React.createElement("a", {
    href: "/nsms/public/parent/parent-pulse.html",
    style: {
      display: 'block',
      textAlign: 'center',
      padding: '8px',
      borderRadius: 7,
      color: 'var(--blue)',
      fontSize: 12,
      fontWeight: 700,
      textDecoration: 'none',
      transition: 'background .15s'
    },
    onMouseOver: function (e) {
      e.currentTarget.style.background = 'var(--blue-light)';
    },
    onMouseOut: function (e) {
      e.currentTarget.style.background = 'none';
    }
  }, "Open J11 Pulse \u2192") : counts.alerts > 0 ? /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      markRead(0);
    },
    style: {
      display: 'block',
      width: '100%',
      textAlign: 'center',
      padding: '8px',
      borderRadius: 7,
      border: 'none',
      background: 'none',
      color: 'var(--blue)',
      fontSize: 12,
      fontWeight: 700,
      cursor: 'pointer',
      transition: 'background .15s',
      fontFamily: 'var(--font)'
    },
    onMouseOver: function (e) {
      e.currentTarget.style.background = 'var(--blue-light)';
    },
    onMouseOut: function (e) {
      e.currentTarget.style.background = 'none';
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2713",
    size: 18
  }), " Mark all alerts as read") : /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '6px 0',
      color: 'var(--text-muted)',
      fontSize: 12,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u2705",
    size: 18
  }), " All caught up"))));
}

/* ═══════════════════════════════════════════════════════════════
   PARENT NAVBAR
   Layout: [toggle] [brand] [child-selector] | [links] [clock] [bell + user]
   CSS classes match NSMSNavbar / TeacherNavbar:
   nsms-nav · nav-toggle · nav-brand · nav-links · nav-center
   nav-right · nav-user-btn · nav-dd
═══════════════════════════════════════════════════════════════ */
function ParentNavbar(props) {
  var activePage = props.activePage || 'dashboard';
  var sidebarOpen = props.sidebarOpen !== undefined ? props.sidebarOpen : true;
  /* Accept onToggleSidebar (preferred) or legacy setSidebar */
  var setSidebar = props.onToggleSidebar || props.setSidebar || function () {};
  var unreadMsg = props.unreadMsg || 0;
  var children = props.children || [];
  var selectedChild = props.selectedChild;
  var setSelectedChild = props.setSelectedChild;
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useRef = React.useRef;
  var ddOpenSt = useState(false);
  var ddOpen = ddOpenSt[0];
  var setDdOpen = ddOpenSt[1];
  var pfOpenSt = useState(false);
  var pfOpen = pfOpenSt[0];
  var setPfOpen = pfOpenSt[1];
  var loadSt = useState(true);
  var loading = loadSt[0];
  var setLoading = loadSt[1];
  var userSt = useState(null);
  var user = userSt[0];
  var setUser = userSt[1];
  var logoSt = useState('');
  var logoUrl = logoSt[0];
  var setLogoUrl = logoSt[1];
  var schNmSt = useState('');
  var schName = schNmSt[0];
  var setSchName = schNmSt[1];
  var imgErrSt = useState(false);
  var imgErr = imgErrSt[0];
  var setImgErr = imgErrSt[1];
  var ddRef = useRef(null);
  var go = function (href) {
    window.location.href = href;
  };

  /* Load session + logo + school name */
  useEffect(function () {
    fetch('/nsms/api/parent-panel.php?action=session').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success) {
        setUser(d.data);
        if (d.data.children && d.data.children.length > 0 && !selectedChild) {
          if (setSelectedChild) setSelectedChild(d.data.children[0]);
        }
      } else if (d.error === 'unauthorized') {
        window.location.href = '/nsms/public/index.html';
      }
    }).catch(function () {}).finally(function () {
      setLoading(false);
    });
    _prLoadLogo(function (url) {
      setLogoUrl(url);
    });
    fetch('/nsms/api/settings.php?action=get_public').then(function (r) {
      return r.json();
    }).then(function (d) {
      if (d.success && d.data) setSchName(d.data.school_name || '');
    }).catch(function () {});
  }, []);

  /* Close dropdown on outside click */
  useEffect(function () {
    if (!ddOpen) return;
    function onOut(e) {
      if (ddRef.current && !ddRef.current.contains(e.target)) setDdOpen(false);
    }
    document.addEventListener('mousedown', onOut);
    return function () {
      document.removeEventListener('mousedown', onOut);
    };
  }, [ddOpen]);
  function handleSignOut() {
    fetch('/nsms/api/parent-panel.php?action=signout').finally(function () {
      window.location.href = '/nsms/public/index.html';
    });
  }
  var dispName = schName || 'NSMS';
  var hasPhoto = !imgErr && user && user.photo_url;

  /* ── Child selector dropdown ── */
  var kidListSt = useState(false);
  var kidOpen = kidListSt[0];
  var setKidOpen = kidListSt[1];
  var kidRef = useRef(null);
  var kidImgErrSt = useState({});
  var kidImgErr = kidImgErrSt[0];
  var setKidImgErr = kidImgErrSt[1];
  var trigImgErrSt = useState(false);
  var trigImgErr = trigImgErrSt[0];
  var setTrigImgErr = trigImgErrSt[1];
  useEffect(function () {
    if (!kidOpen) return;
    function onOut(e) {
      if (kidRef.current && !kidRef.current.contains(e.target)) setKidOpen(false);
    }
    document.addEventListener('mousedown', onOut);
    return function () {
      document.removeEventListener('mousedown', onOut);
    };
  }, [kidOpen]);
  var userChildren = user && user.children ? user.children : children;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("nav", {
    className: "nsms-nav"
  }, /*#__PURE__*/React.createElement("button", {
    className: "nav-toggle",
    onClick: function () {
      setSidebar(function (o) {
        return !o;
      });
    },
    title: "Toggle sidebar"
  }, sidebarOpen ? /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 18
  }) : /*#__PURE__*/React.createElement(Icon, {
    name: "menu",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "nav-brand"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-logo"
  }, /*#__PURE__*/React.createElement(PrLogoMark, {
    logoUrl: logoUrl
  })), /*#__PURE__*/React.createElement("div", {
    className: "nav-school-name"
  }, loading ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nav-shimmer",
    style: {
      height: 13,
      width: 120,
      marginBottom: 4
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "nav-shimmer",
    style: {
      height: 9,
      width: 72
    }
  })) : /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nav-school-title"
  }, dispName), /*#__PURE__*/React.createElement("div", {
    className: "nav-school-sub"
  }, "Parent Portal")))), /*#__PURE__*/React.createElement("div", {
    className: "nav-links"
  }, PARENT_NAV_LINKS.map(function (item) {
    return /*#__PURE__*/React.createElement("button", {
      key: item.key,
      className: 'nav-link' + (activePage === item.key ? ' active' : ''),
      onClick: function () {
        go(item.href);
      }
    }, item.label);
  })), /*#__PURE__*/React.createElement(PrNavClock, null), /*#__PURE__*/React.createElement("div", {
    className: "nav-right",
    style: {
      gap: 8
    }
  }, userChildren.length > 0 && /*#__PURE__*/React.createElement("div", {
    ref: kidRef,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function () {
      setKidOpen(function (o) {
        return !o;
      });
    },
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: 'rgba(255,255,255,.12)',
      border: '1px solid rgba(255,255,255,.2)',
      borderRadius: 8,
      padding: '4px 10px 4px 6px',
      color: '#fff',
      fontSize: 13,
      fontWeight: 600,
      cursor: 'pointer',
      transition: 'background .2s',
      height: 36
    }
  }, function () {
    var selKid = selectedChild;
    if (selKid && selKid.id !== null && selKid.id !== undefined) {
      var hasPh = !trigImgErr && selKid.photo_url;
      var bgC = prAvColor(selKid.student_name);
      return /*#__PURE__*/React.createElement("div", {
        style: {
          width: 26,
          height: 26,
          borderRadius: '50%',
          overflow: 'hidden',
          background: bgC,
          flexShrink: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 10,
          fontWeight: 700,
          color: '#fff'
        }
      }, hasPh ? /*#__PURE__*/React.createElement("img", {
        src: selKid.photo_url,
        alt: "",
        style: {
          width: '100%',
          height: '100%',
          objectFit: 'cover'
        },
        onError: function () {
          setTrigImgErr(true);
        }
      }) : prInitials(selKid.student_name));
    }
    /* All Students */
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: 26,
        height: 26,
        borderRadius: '50%',
        flexShrink: 0,
        background: 'rgba(255,255,255,.25)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 14
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDC65",
      size: 18
    }));
  }(), /*#__PURE__*/React.createElement("span", {
    style: {
      maxWidth: 120,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, selectedChild && selectedChild.id !== null && selectedChild.id !== undefined ? selectedChild.student_name : 'All Students'), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      opacity: .7
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u25BE",
    size: 18
  }))), kidOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(100% + 6px)',
      right: 0,
      background: '#fff',
      borderRadius: 10,
      boxShadow: '0 8px 24px rgba(0,0,0,.14)',
      minWidth: 200,
      zIndex: 300,
      overflow: 'hidden',
      border: '1px solid #E2E8F0'
    }
  }, function () {
    var isAllSel = !selectedChild || selectedChild.id === null || selectedChild.id === undefined;
    return /*#__PURE__*/React.createElement("button", {
      onClick: function () {
        if (setSelectedChild) setSelectedChild(null);
        setKidOpen(false);
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        width: '100%',
        padding: '10px 14px',
        background: isAllSel ? '#EFF6FF' : 'transparent',
        border: 'none',
        borderBottom: '1px solid #F1F5F9',
        cursor: 'pointer',
        textAlign: 'left',
        color: isAllSel ? 'var(--blue)' : 'var(--text-dark)',
        fontSize: 13,
        fontWeight: isAllSel ? 700 : 500
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: '50%',
        flexShrink: 0,
        background: isAllSel ? '#DBEAFE' : '#F1F5F9',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 16
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\uD83D\uDC65",
      size: 18
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: isAllSel ? 700 : 600
      }
    }, "All Students"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--text-muted)'
      }
    }, userChildren.length, " ", userChildren.length === 1 ? 'student' : 'students')), isAllSel && /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto',
        color: 'var(--blue)',
        fontSize: 16
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 18
    })));
  }(), userChildren.map(function (child) {
    var isSel = selectedChild && selectedChild.id === child.id;
    var hasPh = !kidImgErr[child.id] && child.photo_url;
    var bgC = prAvColor(child.student_name);
    return /*#__PURE__*/React.createElement("button", {
      key: child.id,
      onClick: function () {
        if (setSelectedChild) setSelectedChild(child);
        setTrigImgErr(false);
        setKidOpen(false);
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        width: '100%',
        padding: '10px 14px',
        background: isSel ? '#EFF6FF' : 'transparent',
        border: 'none',
        cursor: 'pointer',
        textAlign: 'left',
        color: isSel ? 'var(--blue)' : 'var(--text-dark)',
        fontSize: 13,
        fontWeight: isSel ? 700 : 500
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: '50%',
        overflow: 'hidden',
        flexShrink: 0,
        background: bgC,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 12,
        fontWeight: 700,
        color: '#fff'
      }
    }, hasPh ? /*#__PURE__*/React.createElement("img", {
      src: child.photo_url,
      alt: "",
      style: {
        width: '100%',
        height: '100%',
        objectFit: 'cover'
      },
      onError: function () {
        setKidImgErr(function (prev) {
          return Object.assign({}, prev, {
            [child.id]: true
          });
        });
      }
    }) : prInitials(child.student_name)), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, child.student_name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--text-muted)',
        marginTop: 1
      }
    }, child.class_name)), isSel && /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto',
        color: 'var(--blue)',
        fontSize: 16
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      emoji: "\u2713",
      size: 18
    })));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "nav-divider"
  }), /*#__PURE__*/React.createElement(PrBell, null), /*#__PURE__*/React.createElement("div", {
    className: "nav-divider"
  }), /*#__PURE__*/React.createElement("div", {
    ref: ddRef,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: 'nav-user-btn' + (ddOpen ? ' open' : ''),
    onClick: function () {
      setDdOpen(function (o) {
        return !o;
      });
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-avatar",
    style: {
      background: user ? prAvColor(user.full_name) : '#E2E8F0'
    }
  }, hasPhoto ? /*#__PURE__*/React.createElement("img", {
    src: user.photo_url,
    alt: "",
    onError: function () {
      setImgErr(true);
    }
  }) : user ? prInitials(user.full_name) : '?'), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nav-user-name"
  }, loading ? '…' : user ? user.full_name.split(' ')[0] : 'Parent'), /*#__PURE__*/React.createElement("div", {
    className: "nav-user-role"
  }, "Parent")), /*#__PURE__*/React.createElement("span", {
    className: "nav-chevron"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u25BE",
    size: 18
  }))), ddOpen && /*#__PURE__*/React.createElement("div", {
    className: "nav-dd"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-av",
    style: {
      background: user ? prAvColor(user.full_name) : 'rgba(255,255,255,.2)'
    }
  }, hasPhoto ? /*#__PURE__*/React.createElement("img", {
    src: user.photo_url,
    alt: ""
  }) : user ? prInitials(user.full_name) : '?'), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-name"
  }, user ? user.full_name : 'Parent'), /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-email"
  }, user ? user.email : ''), /*#__PURE__*/React.createElement("span", {
    className: "nav-dd-role"
  }, "Parent Portal"))), /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-body"
  }, /*#__PURE__*/React.createElement("button", {
    className: "nav-dd-item",
    onClick: function () {
      setDdOpen(false);
      setPfOpen(true);
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nav-dd-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\uD83D\uDC64",
    size: 18
  })), " My Profile"), /*#__PURE__*/React.createElement("button", {
    className: "nav-dd-item",
    onClick: function () {
      setDdOpen(false);
      go('/nsms/public/parent/parent-pulse.html');
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "nav-dd-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    emoji: "\u26A1",
    size: 18
  })), " J11 Pulse", unreadMsg > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      background: '#EF4444',
      color: '#fff',
      borderRadius: 20,
      padding: '1px 7px',
      fontSize: 11,
      fontWeight: 700
    }
  }, unreadMsg)), /*#__PURE__*/React.createElement("div", {
    className: "nav-dd-sep"
  }), /*#__PURE__*/React.createElement("button", {
    className: "nav-dd-item danger",
    onClick: handleSignOut
  }, /*#__PURE__*/React.createElement("span", {
    className: "nav-dd-icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "logout",
    size: 18
  })), " Sign Out")))))), /*#__PURE__*/React.createElement(ParentProfileModal, {
    open: pfOpen,
    onClose: function () {
      setPfOpen(false);
    },
    onPhotoUpdate: function (newUrl) {
      setUser(function (u) {
        return Object.assign({}, u, {
          photo_url: newUrl
        });
      });
      setImgErr(false);
    }
  }));
}

/* ═══════════════════════════════════════════════════════════════
   PARENT SIDEBAR
   Matches NSMSSidebar / TeacherSidebar exactly:
   • Collapsed by default; hover → expands; mouse-leave → collapses
     after 180 ms delay.
   • Toggle pin from navbar (sidebarOpen prop).
   • Uses nsms-sidebar / sb-item / sb-icon / sb-label CSS classes.
   • J11 Pulse item shows unread badge when unreadMsg > 0.
═══════════════════════════════════════════════════════════════ */
function ParentSidebar(props) {
  /* Map legacy activePage aliases → sidebar item keys */
  var _rawPage = props.activePage || 'dashboard';
  var activePage = _rawPage === 'pulse' ? 'messages' : _rawPage;
  /* Accept sidebarOpen (reports pattern) OR collapsed (pulse pattern) */
  var sidebarOpen = props.sidebarOpen !== undefined ? props.sidebarOpen : props.collapsed !== undefined ? !props.collapsed : true;
  var unreadMsg = props.unreadMsg || 0;
  var go = function (href) {
    window.location.href = href;
  };
  var useState = React.useState;
  var useRef = React.useRef;
  var hoverSt = useState(false);
  var isHovered = hoverSt[0];
  var setIsHovered = hoverSt[1];
  var leaveTimer = useRef(null);
  function handleEnter() {
    if (leaveTimer.current) {
      clearTimeout(leaveTimer.current);
      leaveTimer.current = null;
    }
    setIsHovered(true);
  }
  function handleLeave() {
    leaveTimer.current = setTimeout(function () {
      setIsHovered(false);
    }, 180);
  }
  var isExpanded = sidebarOpen || isHovered;
  return /*#__PURE__*/React.createElement("aside", {
    className: 'nsms-sidebar' + (isExpanded ? '' : ' collapsed'),
    onMouseEnter: handleEnter,
    onMouseLeave: handleLeave
  }, PARENT_SIDEBAR_ITEMS.map(function (item) {
    var badge = item.key === 'messages' && unreadMsg > 0 ? unreadMsg : 0;
    return /*#__PURE__*/React.createElement("button", {
      key: item.key,
      className: 'sb-item' + (activePage === item.key ? ' active' : ''),
      "data-tip": item.label,
      onClick: function () {
        go(item.href);
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "sb-icon"
    }, item.icon), /*#__PURE__*/React.createElement("span", {
      className: "sb-label"
    }, item.label), badge > 0 && /*#__PURE__*/React.createElement("span", {
      className: "sb-badge"
    }, badge > 9 ? '9+' : badge));
  }), /*#__PURE__*/React.createElement("div", {
    className: "sb-spacer"
  }));
}