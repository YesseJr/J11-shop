/**
 * NSMS mobile helpers — off-canvas sidebar + safe defaults on small screens
 */
(function () {
  'use strict';
  var MQ = window.matchMedia('(max-width: 768px)');

  function ensureBackdrop() {
    var el = document.querySelector('.nsms-sb-backdrop');
    if (!el) {
      el = document.createElement('button');
      el.type = 'button';
      el.className = 'nsms-sb-backdrop';
      el.setAttribute('aria-label', 'Close menu');
      el.addEventListener('click', function () {
        closeSidebar();
      });
      document.body.appendChild(el);
    }
    return el;
  }

  function findSidebar() {
    return document.querySelector('.nsms-sidebar');
  }

  function isOpen(sb) {
    return sb && !sb.classList.contains('collapsed');
  }

  function closeSidebar() {
    var sb = findSidebar();
    if (!sb) return;
    sb.classList.add('collapsed');
    document.body.classList.remove('nsms-sb-open');
    // Try to sync React state via hamburger if present
    var btn = document.querySelector('[data-nsms-sidebar-toggle], .nav-toggle, .sidebar-toggle');
    // Also dispatch a custom event pages can listen to
    try {
      window.dispatchEvent(new CustomEvent('nsms:sidebar-close'));
    } catch (e) {}
  }

  function syncBodyClass() {
    var sb = findSidebar();
    if (!MQ.matches) {
      document.body.classList.remove('nsms-sb-open');
      return;
    }
    if (isOpen(sb)) document.body.classList.add('nsms-sb-open');
    else document.body.classList.remove('nsms-sb-open');
  }

  function onSidebarNavClick(e) {
    if (!MQ.matches) return;
    var a = e.target.closest('a, button.sb-item');
    if (!a || !findSidebar()) return;
    // Close drawer after navigating / selecting
    setTimeout(closeSidebar, 120);
  }

  function init() {
    ensureBackdrop();
    syncBodyClass();
    var sb = findSidebar();
    if (sb) {
      sb.addEventListener('click', onSidebarNavClick);
      // Observe class changes (React toggles collapsed)
      if (window.MutationObserver) {
        new MutationObserver(syncBodyClass).observe(sb, {
          attributes: true,
          attributeFilter: ['class'],
        });
      }
    }
    // Re-check when React mounts sidebar a bit later
    var tries = 0;
    var t = setInterval(function () {
      tries++;
      var s = findSidebar();
      if (s || tries > 40) {
        clearInterval(t);
        if (s) {
          ensureBackdrop();
          s.addEventListener('click', onSidebarNavClick);
          if (window.MutationObserver) {
            new MutationObserver(syncBodyClass).observe(s, {
              attributes: true,
              attributeFilter: ['class'],
            });
          }
          syncBodyClass();
        }
      }
    }, 250);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  window.addEventListener('resize', function () {
    if (!MQ.matches) document.body.classList.remove('nsms-sb-open');
    else syncBodyClass();
  });
})();
