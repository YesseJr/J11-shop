/**
 * NSMS image helpers — client-side compress + lazy loading for mobile
 */
(function (window, document) {
  'use strict';
  var NSMS = window.NSMS || (window.NSMS = {});

  /**
   * Compress an image File for upload. Returns a Promise<Blob|File>.
   * Skips non-images and small files.
   */
  NSMS.compressImageFile = function (file, opts) {
    opts = opts || {};
    var maxEdge = opts.maxEdge || 1280;
    var quality = opts.quality || 0.82;
    var maxBytes = opts.maxBytes || 5 * 1024 * 1024;

    return new Promise(function (resolve) {
      if (!file || !file.type || file.type.indexOf('image/') !== 0) {
        resolve(file);
        return;
      }
      if (file.type.indexOf('svg') !== -1) {
        resolve(file);
        return;
      }
      // Already small enough
      if (file.size < 180 * 1024) {
        resolve(file);
        return;
      }

      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(url);
        var w = img.naturalWidth || img.width;
        var h = img.naturalHeight || img.height;
        if (!w || !h) {
          resolve(file);
          return;
        }
        var scale = 1;
        if (w > maxEdge || h > maxEdge) {
          scale = Math.min(maxEdge / w, maxEdge / h);
        }
        var cw = Math.max(1, Math.round(w * scale));
        var ch = Math.max(1, Math.round(h * scale));
        var canvas = document.createElement('canvas');
        canvas.width = cw;
        canvas.height = ch;
        var ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(file);
          return;
        }
        ctx.drawImage(img, 0, 0, cw, ch);
        var outType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
        canvas.toBlob(
          function (blob) {
            if (!blob || blob.size >= file.size) {
              resolve(file);
              return;
            }
            if (blob.size > maxBytes) {
              // second pass lower quality
              canvas.toBlob(
                function (blob2) {
                  if (!blob2) {
                    resolve(file);
                    return;
                  }
                  var name = (file.name || 'photo.jpg').replace(/\.\w+$/, outType === 'image/png' ? '.png' : '.jpg');
                  try {
                    resolve(new File([blob2], name, { type: outType, lastModified: Date.now() }));
                  } catch (e) {
                    resolve(blob2);
                  }
                },
                outType,
                0.7
              );
              return;
            }
            var name = (file.name || 'photo.jpg').replace(/\.\w+$/, outType === 'image/png' ? '.png' : '.jpg');
            try {
              resolve(new File([blob], name, { type: outType, lastModified: Date.now() }));
            } catch (e) {
              resolve(blob);
            }
          },
          outType,
          quality
        );
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        resolve(file);
      };
      img.src = url;
    });
  };

  /** Add loading=lazy decoding=async to content images */
  function enhanceImages(root) {
    root = root || document;
    var imgs = root.querySelectorAll ? root.querySelectorAll('img') : [];
    for (var i = 0; i < imgs.length; i++) {
      var el = imgs[i];
      if (!el.getAttribute('loading')) el.setAttribute('loading', 'lazy');
      if (!el.getAttribute('decoding')) el.setAttribute('decoding', 'async');
      // Prevent layout blow-up
      if (!el.style.maxWidth) el.style.maxWidth = '100%';
    }
  }

  function boot() {
    enhanceImages(document);
    if (window.MutationObserver) {
      var obs = new MutationObserver(function (muts) {
        for (var i = 0; i < muts.length; i++) {
          var nodes = muts[i].addedNodes;
          for (var j = 0; j < nodes.length; j++) {
            var n = nodes[j];
            if (n.nodeType === 1) {
              if (n.tagName === 'IMG') {
                if (!n.getAttribute('loading')) n.setAttribute('loading', 'lazy');
                if (!n.getAttribute('decoding')) n.setAttribute('decoding', 'async');
              } else if (n.querySelectorAll) {
                enhanceImages(n);
              }
            }
          }
        }
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  // Patch HTMLInputElement files selection for image inputs via helper
  NSMS.prepareImageInput = function (inputEl, opts) {
    if (!inputEl || inputEl.__nsmsImgPrep) return;
    inputEl.__nsmsImgPrep = true;
    inputEl.addEventListener('change', function () {
      var files = inputEl.files;
      if (!files || !files.length) return;
      var file = files[0];
      if (!file.type || file.type.indexOf('image/') !== 0) return;
      NSMS.compressImageFile(file, opts).then(function (out) {
        if (!out || out === file) return;
        try {
          var dt = new DataTransfer();
          dt.items.add(out instanceof File ? out : new File([out], file.name, { type: out.type || file.type }));
          inputEl.files = dt.files;
        } catch (e) {
          /* browsers without DataTransfer assignment — server still optimizes */
        }
      });
    });
  };

  // Auto-bind common photo file inputs
  document.addEventListener(
    'change',
    function (e) {
      var t = e.target;
      if (!t || t.tagName !== 'INPUT' || t.type !== 'file') return;
      if (!t.accept || t.accept.indexOf('image') === -1) return;
      if (t.__nsmsCompressing) return;
      var files = t.files;
      if (!files || !files.length) return;
      var file = files[0];
      if (!file.type || file.type.indexOf('image/') !== 0) return;
      t.__nsmsCompressing = true;
      NSMS.compressImageFile(file).then(function (out) {
        t.__nsmsCompressing = false;
        if (!out || out === file) return;
        try {
          var dt = new DataTransfer();
          dt.items.add(out instanceof File ? out : new File([out], file.name, { type: out.type || 'image/jpeg' }));
          t.files = dt.files;
        } catch (err) {}
      });
    },
    true
  );
})(window, document);
