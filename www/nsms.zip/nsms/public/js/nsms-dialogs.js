/**
 * NSMS styled dialogs — replaces window.alert / window.confirm
 * Usage:
 *   await NSMS.confirm({ title, message, confirmLabel, cancelLabel, variant })
 *   await NSMS.alert({ title, message, confirmLabel, variant })
 *   NSMS.toast(message, { variant, duration })
 */
(function (window, document) {
  'use strict';
  var NSMS = window.NSMS || (window.NSMS = {});
  if (NSMS.__dialogsReady) return;
  NSMS.__dialogsReady = true;

  var STYLE_ID = 'nsms-dialog-styles';
  if (!document.getElementById(STYLE_ID)) {
    var css = document.createElement('style');
    css.id = STYLE_ID;
    css.textContent = [
      '.nsms-dlg-root{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;padding:16px;font-family:system-ui,-apple-system,"Segoe UI",Roboto,"Plus Jakarta Sans",sans-serif}',
      '.nsms-dlg-bg{position:absolute;inset:0;background:rgba(15,23,42,.55);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);animation:nsmsDlgIn .18s ease}',
      '.nsms-dlg-card{position:relative;width:100%;max-width:420px;background:#fff;border-radius:16px;box-shadow:0 25px 50px -12px rgba(0,0,0,.25);padding:24px 24px 20px;animation:nsmsDlgPop .2s ease;color:#0f172a}',
      '.nsms-dlg-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin-bottom:14px}',
      '.nsms-dlg-icon.danger{background:#FEF2F2;color:#DC2626}',
      '.nsms-dlg-icon.warn{background:#FFFBEB;color:#D97706}',
      '.nsms-dlg-icon.info{background:#EFF6FF;color:#2563EB}',
      '.nsms-dlg-icon.success{background:#ECFDF5;color:#059669}',
      '.nsms-dlg-title{font-size:18px;font-weight:800;margin:0 0 8px;letter-spacing:-.02em}',
      '.nsms-dlg-msg{font-size:14px;line-height:1.55;color:#475569;margin:0 0 20px;white-space:pre-wrap}',
      '.nsms-dlg-actions{display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap}',
      '.nsms-dlg-btn{border:none;border-radius:10px;padding:10px 16px;font-size:13.5px;font-weight:700;cursor:pointer;font-family:inherit;transition:transform .12s,box-shadow .12s,background .12s}',
      '.nsms-dlg-btn:active{transform:scale(.98)}',
      '.nsms-dlg-btn.ghost{background:#F1F5F9;color:#334155}',
      '.nsms-dlg-btn.ghost:hover{background:#E2E8F0}',
      '.nsms-dlg-btn.primary{background:#2563EB;color:#fff;box-shadow:0 1px 2px rgba(37,99,235,.3)}',
      '.nsms-dlg-btn.primary:hover{background:#1D4ED8}',
      '.nsms-dlg-btn.danger{background:#DC2626;color:#fff;box-shadow:0 1px 2px rgba(220,38,38,.3)}',
      '.nsms-dlg-btn.danger:hover{background:#B91C1C}',
      '.nsms-toast-wrap{position:fixed;top:20px;right:20px;z-index:2147483001;display:flex;flex-direction:column;gap:10px;max-width:360px;pointer-events:none}',
      '.nsms-toast{pointer-events:auto;background:#0f172a;color:#fff;padding:12px 16px;border-radius:12px;font-size:13.5px;font-weight:600;box-shadow:0 10px 30px rgba(0,0,0,.2);animation:nsmsDlgPop .2s ease;display:flex;gap:10px;align-items:flex-start}',
      '.nsms-toast.success{background:#065F46}',
      '.nsms-toast.danger{background:#991B1B}',
      '.nsms-toast.info{background:#1E40AF}',
      '@keyframes nsmsDlgIn{from{opacity:0}to{opacity:1}}',
      '@keyframes nsmsDlgPop{from{opacity:0;transform:translateY(8px) scale(.97)}to{opacity:1;transform:none}}'
    ].join('');
    (document.head || document.documentElement).appendChild(css);
  }

  function iconSvg(variant) {
    if (variant === 'danger') {
      return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>';
    }
    if (variant === 'success') {
      return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 6L9 17l-5-5"/></svg>';
    }
    if (variant === 'warn') {
      return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>';
    }
    return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>';
  }

  function normalizeOpts(messageOrOpts, maybeOpts) {
    if (typeof messageOrOpts === 'string') {
      var o = maybeOpts || {};
      o.message = messageOrOpts;
      return o;
    }
    return messageOrOpts || {};
  }

  function openDialog(opts) {
    opts = opts || {};
    var variant = opts.variant || 'info';
    var title = opts.title || (variant === 'danger' ? 'Please confirm' : 'Notice');
    var message = opts.message || '';
    var confirmLabel = opts.confirmLabel || (opts.showCancel === false ? 'OK' : 'Confirm');
    var cancelLabel = opts.cancelLabel || 'Cancel';
    var showCancel = opts.showCancel !== false;

    return new Promise(function (resolve) {
      var root = document.createElement('div');
      root.className = 'nsms-dlg-root';
      root.setAttribute('role', 'dialog');
      root.setAttribute('aria-modal', 'true');
      root.innerHTML =
        '<div class="nsms-dlg-bg" data-nsms-dlg-bg></div>' +
        '<div class="nsms-dlg-card">' +
          '<div class="nsms-dlg-icon ' + variant + '">' + iconSvg(variant) + '</div>' +
          '<h3 class="nsms-dlg-title"></h3>' +
          '<p class="nsms-dlg-msg"></p>' +
          '<div class="nsms-dlg-actions"></div>' +
        '</div>';
      root.querySelector('.nsms-dlg-title').textContent = title;
      root.querySelector('.nsms-dlg-msg').textContent = message;

      var actions = root.querySelector('.nsms-dlg-actions');
      if (showCancel) {
        var cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.className = 'nsms-dlg-btn ghost';
        cancelBtn.textContent = cancelLabel;
        cancelBtn.addEventListener('click', function () { cleanup(false); });
        actions.appendChild(cancelBtn);
      }
      var okBtn = document.createElement('button');
      okBtn.type = 'button';
      okBtn.className = 'nsms-dlg-btn ' + (variant === 'danger' ? 'danger' : 'primary');
      okBtn.textContent = confirmLabel;
      okBtn.addEventListener('click', function () { cleanup(true); });
      actions.appendChild(okBtn);

      function onKey(e) {
        if (e.key === 'Escape') { e.preventDefault(); cleanup(false); }
        if (e.key === 'Enter' && e.target === okBtn) cleanup(true);
      }
      function cleanup(result) {
        document.removeEventListener('keydown', onKey);
        if (root.parentNode) root.parentNode.removeChild(root);
        resolve(result);
      }

      root.querySelector('[data-nsms-dlg-bg]').addEventListener('click', function () {
        if (showCancel) cleanup(false);
      });
      document.addEventListener('keydown', onKey);
      document.body.appendChild(root);
      setTimeout(function () { okBtn.focus(); }, 10);
    });
  }

  NSMS.confirm = function (messageOrOpts, maybeOpts) {
    var opts = normalizeOpts(messageOrOpts, maybeOpts);
    if (!opts.variant) {
      var msg = (opts.message || '').toLowerCase();
      if (/delete|remove|clear|reset|cannot be undone|destructive/.test(msg)) opts.variant = 'danger';
      else if (/approve|publish|send|remind/.test(msg)) opts.variant = 'warn';
      else opts.variant = 'info';
    }
    if (!opts.title) {
      if (opts.variant === 'danger') opts.title = 'Confirm action';
      else if (opts.variant === 'warn') opts.title = 'Please confirm';
      else opts.title = 'Confirm';
    }
    if (!opts.confirmLabel) {
      opts.confirmLabel = opts.variant === 'danger' ? 'Yes, continue' : 'Confirm';
    }
    opts.showCancel = true;
    return openDialog(opts);
  };

  NSMS.alert = function (messageOrOpts, maybeOpts) {
    var opts = normalizeOpts(messageOrOpts, maybeOpts);
    opts.variant = opts.variant || 'info';
    opts.title = opts.title || 'Notice';
    opts.confirmLabel = opts.confirmLabel || 'OK';
    opts.showCancel = false;
    return openDialog(opts).then(function () { return true; });
  };

  NSMS.toast = function (message, opts) {
    opts = opts || {};
    var wrap = document.querySelector('.nsms-toast-wrap');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.className = 'nsms-toast-wrap';
      document.body.appendChild(wrap);
    }
    var el = document.createElement('div');
    el.className = 'nsms-toast ' + (opts.variant || 'info');
    el.textContent = message;
    wrap.appendChild(el);
    var ms = opts.duration || 3200;
    setTimeout(function () {
      if (el.parentNode) el.parentNode.removeChild(el);
      if (wrap && !wrap.children.length && wrap.parentNode) wrap.parentNode.removeChild(wrap);
    }, ms);
  };

  // Async-friendly polyfill: window.confirm becomes Promise if caller uses await
  // Keep native available as NSMS.nativeConfirm for edge cases
  NSMS.nativeConfirm = window.confirm.bind(window);
  NSMS.nativeAlert = window.alert.bind(window);

  window.confirm = function (message) {
    console.warn('[NSMS] window.confirm blocked — use await NSMS.confirm()', message);
    try { if (NSMS.toast) NSMS.toast('Please use the in-app confirmation dialog.', { variant: 'info' }); } catch (e) {}
    return false;
  };
  window.alert = function (message) {
    if (NSMS.alert) { NSMS.alert({ message: String(message), title: 'Notice' }); return; }
    console.warn('[NSMS] alert:', message);
  };
})(window, document);
