/**
 * Shared chrome mount helpers for the progressive SPA shell.
 * Expects window.NSMSNavbar / NSMSSidebar from built nsms-shared.js when available.
 */
(function (global) {
  function mountShell(options) {
    options = options || {};
    var root = options.root || document.getElementById('spa-root');
    if (!root || typeof React === 'undefined' || typeof ReactDOM === 'undefined') return null;

    function Shell() {
      var page = options.page || 'dashboard';
      return React.createElement(
        'div',
        { className: 'nsms-spa' },
        typeof global.NSMSNavbar === 'function'
          ? React.createElement(global.NSMSNavbar, { activePage: page })
          : null,
        typeof global.NSMSSidebar === 'function'
          ? React.createElement(global.NSMSSidebar, { activePage: page })
          : null,
        React.createElement('main', { className: 'nsms-main nsms-spa-main', id: 'spa-main' },
          options.children || null
        )
      );
    }

    var el = React.createElement(Shell);
    if (ReactDOM.createRoot) {
      var r = ReactDOM.createRoot(root);
      r.render(el);
      return r;
    }
    ReactDOM.render(el, root);
    return null;
  }

  global.NSMSAppShell = { mount: mountShell };
})(window);
