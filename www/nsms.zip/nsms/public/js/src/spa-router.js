/**
 * Lightweight hash router for the optional SPA entry (public/spa.html).
 * Existing /public/admin/*.html URLs remain the primary production paths.
 */
(function (global) {
  var routes = {
    '': 'dashboard',
    'dashboard': 'dashboard',
    'students': 'students',
    'teachers': 'teachers',
    'finance': 'finance',
    'settings': 'settings'
  };

  function current() {
    var h = (location.hash || '#dashboard').replace(/^#\/?/, '');
    return routes[h] || 'dashboard';
  }

  function navigate(name) {
    location.hash = '#' + name;
  }

  function onChange(cb) {
    window.addEventListener('hashchange', function () { cb(current()); });
    cb(current());
  }

  global.NSMSRouter = { current: current, navigate: navigate, onChange: onChange, routes: routes };
})(window);
