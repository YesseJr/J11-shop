/* ═══════════════════════════════════════════════════════════════
   NSMS PARENT SHARED COMPONENTS  —  nsms/public/includes/js/parent-shared.js
   Self-contained — no dependency on nsms-shared.js
   Exposes globals: ParentNavbar, ParentSidebar

   Requires: React loaded before this file.

   ── Bell architecture (mirrors NSMSBell in nsms-shared.js) ────
   • PrBell is fully tabbed (Messages + Alerts) with live polling,
     per-alert mark-as-read, and a bell-pulse animation — identical
     pattern to NSMSBell.
   • Messages tab is bound to J11 Pulse (parent/messages.html)
     so unread message counts appear in the same panel as alerts.
   • API endpoints: parent-panel.php?action=notifications_count
                    parent-panel.php?action=notifications
                    parent-panel.php?action=mark_notifications_read
                    parent-panel.php?action=generate_notifications
   • Fast poll (10 s) refreshes badge + alert list silently.
   • Slow poll (5 min) also re-seeds notifications via
     generate_notifications — same pattern as NSMSBell calling
     generate_reminders in auth.php.

   ── Navbar / Sidebar alignment ────────────────────────────────
   • <nav> uses className "nsms-nav"   (matches NSMSNavbar)
   • toggle button uses "nav-toggle"   (matches NSMSNavbar)
   • <aside> uses "nsms-sidebar"       (already matched)
   • All other shared layout classes identical to nsms-shared.js
═══════════════════════════════════════════════════════════════ */

/* ── Avatar helpers ── */
var PR_AV_COLORS = ['#10B981','#2563EB','#F59E0B','#8B5CF6','#EF4444','#0891B2'];
var prAvColor    = function(n) { return n ? PR_AV_COLORS[n.charCodeAt(0) % PR_AV_COLORS.length] : '#94A3B8'; };
var prInitials   = function(n) { return n ? n.split(' ').map(function(w){ return w[0]; }).join('').toUpperCase().slice(0,2) : '?'; };

/* ── Parent sidebar items ── */
var PARENT_SIDEBAR_ITEMS = [
    { key: 'dashboard',    icon: '🏠', label: 'Dashboard',    href: '/nsms/public/parent/dashboard.html'    },
    { key: 'daily_diary',  icon: '📅', label: 'Daily Diary',  href: '/nsms/public/parent/daily-diary.html'  },
    { key: 'reports',      icon: '📋', label: 'Reports',      href: '/nsms/public/parent/reports.html'      },
    { key: 'attendance',   icon: '📊', label: 'Attendance',   href: '/nsms/public/parent/attendance.html'   },
    { key: 'fee_payments', icon: '💰', label: 'Fee Payments', href: '/nsms/public/parent/fee-payments.html' },
    { key: 'messages',     icon: '💬', label: 'Messages',     href: '/nsms/public/parent/messages.html'     },
];

/* ── Parent navbar quick-links (right-aligned, 4 items) ── */
var PARENT_NAV_LINKS = [
    { key: 'dashboard',    label: 'Home',         href: '/nsms/public/parent/dashboard.html'    },
    { key: 'daily_diary',  label: 'Daily Diary',  href: '/nsms/public/parent/daily-diary.html'  },
    { key: 'attendance',   label: 'Attendance',   href: '/nsms/public/parent/attendance.html'   },
    { key: 'fee_payments', label: 'Fee Payments', href: '/nsms/public/parent/fee-payments.html' },
];

/* ── Module-level logo cache — one fetch per page load ── */
var _prLogoCache   = { loaded: false, url: '' };
var _prLogoWaiters = [];
function _prLoadLogo(cb) {
    if (_prLogoCache.loaded) { cb(_prLogoCache.url); return; }
    _prLogoWaiters.push(cb);
    if (_prLogoWaiters.length > 1) return;
    fetch('/nsms/api/settings.php?action=get_public')
        .then(function(r){ return r.json(); })
        .then(function(d){ if (d.success && d.data) _prLogoCache.url = d.data.school_logo || ''; })
        .catch(function(){})
        .finally(function(){
            _prLogoCache.loaded = true;
            var waiters = _prLogoWaiters.slice(); _prLogoWaiters = [];
            waiters.forEach(function(fn){ fn(_prLogoCache.url); });
        });
}

/* ── School logo mark ── */
function PrLogoMark(props) {
    var logoUrl = props.logoUrl || '';
    if (logoUrl) {
        return (
            <img src={logoUrl} alt="School Logo"
                 style={{width:'100%',height:'100%',objectFit:'contain',borderRadius:'6px',display:'block'}}
                 onError={function(e){ e.target.style.display='none'; }} />
        );
    }
    return (
        <svg viewBox="0 0 24 24" fill="none">
            <path d="M3 21h18M5 21V7l7-4 7 4v14" stroke="rgba(255,255,255,.7)" strokeWidth="1.5" strokeLinejoin="round"/>
            <rect x="10" y="14" width="4" height="7" rx=".5" fill="rgba(255,255,255,.9)"/>
            <rect x="6.5" y="9.5" width="3" height="3" rx=".5" fill="rgba(255,255,255,.8)"/>
            <rect x="14.5" y="9.5" width="3" height="3" rx=".5" fill="rgba(255,255,255,.8)"/>
            <line x1="12" y1="3.2" x2="12" y2="1" stroke="rgba(255,255,255,.7)" strokeWidth="1.2"/>
            <polygon points="12,1 15,2.2 12,3.4" fill="rgba(255,255,255,.9)"/>
        </svg>
    );
}

/* ═══════════════════════════════════════════════════════════════
   LIVE CLOCK  (centre of navbar — identical to NavClock in nsms-shared)
═══════════════════════════════════════════════════════════════ */
function PrNavClock() {
    var useState  = React.useState;
    var useEffect = React.useEffect;

    var nowSt = useState(new Date()); var now = nowSt[0]; var setNow = nowSt[1];
    useEffect(function() {
        var t = setInterval(function(){ setNow(new Date()); }, 1000);
        return function(){ clearInterval(t); };
    }, []);

    function ordinal(n) {
        var s = ['th','st','nd','rd'], v = n % 100;
        return n + (s[(v-20)%10] || s[v] || s[0]);
    }
    var MONTHS = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];
    var dateStr = ordinal(now.getDate()) + ' ' + MONTHS[now.getMonth()] + ' ' + now.getFullYear();
    var hh = String(now.getHours()).padStart(2,'0');
    var mm = String(now.getMinutes()).padStart(2,'0');
    var ss = String(now.getSeconds()).padStart(2,'0');

    return (
        <div className="nav-center">
            <div className="nav-date-block">
                <div className="nav-date-icon">📅</div>
                <span className="nav-date-text">{dateStr}</span>
            </div>
            <div className="nav-center-sep" />
            <div className="nav-time-block">
                <div className="nav-time-icon">🕐</div>
                <span className="nav-time-text">{hh}:{mm}:{ss}</span>
            </div>
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   PARENT PROFILE MODAL
═══════════════════════════════════════════════════════════════ */
function ParentProfileModal(props) {
    var open    = props.open;
    var onClose = props.onClose;

    var useState  = React.useState;
    var useEffect = React.useEffect;
    var useRef    = React.useRef;

    var profSt    = useState(null);  var profile   = profSt[0];    var setProfile   = profSt[1];
    var loadSt    = useState(true);  var loading   = loadSt[0];    var setLoading   = loadSt[1];
    var saveSt    = useState(false); var saving    = saveSt[0];    var setSaving    = saveSt[1];
    var alertSt   = useState(null);  var alert     = alertSt[0];   var setAlert     = alertSt[1];
    var editSt    = useState(false); var editMode  = editSt[0];    var setEditMode  = editSt[1];
    var showPwSt  = useState(false); var showPw    = showPwSt[0];  var setShowPw    = showPwSt[1];
    var prevSt    = useState(null);  var preview   = prevSt[0];    var setPreview   = prevSt[1];
    var upSt      = useState(false); var uploading = upSt[0];      var setUploading = upSt[1];
    var photoErrSt= useState(false); var photoErr  = photoErrSt[0];var setPhotoErr  = photoErrSt[1];

    var formSt = useState({ full_name:'', email:'', phone:'' });
    var form   = formSt[0]; var setForm = formSt[1];
    var pwSt   = useState({ current:'', newPw:'', confirm:'' });
    var pw     = pwSt[0];   var setPw   = pwSt[1];

    var fileRef = useRef(null);

    useEffect(function() {
        if (!open) return;
        setLoading(true); setAlert(null); setEditMode(false);
        setShowPw(false); setPreview(null); setPhotoErr(false);
        setPw({ current:'', newPw:'', confirm:'' });

        fetch('/nsms/api/parent-panel.php?action=get_profile')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setProfile(d.data);
                    setForm({
                        full_name: d.data.full_name || '',
                        email:     d.data.email     || '',
                        phone:     d.data.phone     || ''
                    });
                } else {
                    setAlert({ type:'error', msg: d.error || 'Failed to load profile.' });
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error loading profile.' }); })
            .finally(function(){ setLoading(false); });
    }, [open]);

    useEffect(function() {
        if (!open) return;
        var onKey = function(e){ if (e.key === 'Escape') onClose(); };
        document.addEventListener('keydown', onKey);
        return function(){ document.removeEventListener('keydown', onKey); };
    }, [open]);

    if (!open) return null;

    var hasPhoto = !photoErr && profile && profile.photo_url;
    var dispPhoto = preview || (hasPhoto ? profile.photo_url : null);

    function handlePhotoChange(e) {
        var file = e.target.files && e.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function(ev){ setPreview(ev.target.result); };
        reader.readAsDataURL(file);

        var fd = new FormData();
        fd.append('photo', file);
        setUploading(true); setAlert(null);
        fetch('/nsms/api/parent-panel.php?action=upload_photo', { method:'POST', body:fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setProfile(function(p){ return Object.assign({}, p, { photo_url: d.data.photo_url }); });
                    setAlert({ type:'success', msg:'Photo updated.' });
                } else {
                    setAlert({ type:'error', msg: d.error || 'Upload failed.' });
                    setPreview(null);
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error during upload.' }); setPreview(null); })
            .finally(function(){ setUploading(false); });
    }

    function handleSave() {
        setSaving(true); setAlert(null);
        fetch('/nsms/api/parent-panel.php?action=update_profile', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ full_name: form.full_name, phone: form.phone })
        })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setProfile(function(p){ return Object.assign({}, p, { full_name: form.full_name, phone: form.phone }); });
                    setAlert({ type:'success', msg:'Profile updated successfully.' });
                    setEditMode(false);
                } else {
                    setAlert({ type:'error', msg: d.error || 'Update failed.' });
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error.' }); })
            .finally(function(){ setSaving(false); });
    }

    function handleChangePassword() {
        if (!pw.current || !pw.newPw || !pw.confirm) {
            setAlert({ type:'error', msg:'All password fields are required.' }); return;
        }
        if (pw.newPw !== pw.confirm) {
            setAlert({ type:'error', msg:'New passwords do not match.' }); return;
        }
        setSaving(true); setAlert(null);
        fetch('/nsms/api/parent-panel.php?action=change_password', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ current: pw.current, new: pw.newPw, confirm: pw.confirm })
        })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setAlert({ type:'success', msg:'Password changed successfully.' });
                    setPw({ current:'', newPw:'', confirm:'' });
                    setShowPw(false);
                } else {
                    setAlert({ type:'error', msg: d.error || 'Password change failed.' });
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error.' }); })
            .finally(function(){ setSaving(false); });
    }

    return (
        <div className="modal-overlay" onClick={function(e){ if (e.target === e.currentTarget) onClose(); }}>
            <div className="modal-box" style={{maxWidth:480}}>

                {/* Header */}
                <div className="modal-head">
                    <div className="modal-title">👤 My Profile</div>
                    <button className="modal-close" onClick={onClose}>✕</button>
                </div>

                {alert && (
                    <div className={'modal-alert ' + (alert.type === 'success' ? 'alert-ok' : 'alert-err')}>
                        {alert.msg}
                    </div>
                )}

                {loading ? (
                    <div style={{padding:32,textAlign:'center',color:'var(--text-muted)'}}>Loading…</div>
                ) : (
                    <div className="modal-body">

                        {/* Avatar */}
                        <div style={{display:'flex',flexDirection:'column',alignItems:'center',marginBottom:24}}>
                            <div style={{
                                width:80,height:80,borderRadius:'50%',overflow:'hidden',
                                background: prAvColor(profile ? profile.full_name : ''),
                                display:'flex',alignItems:'center',justifyContent:'center',
                                fontSize:28,fontWeight:700,color:'#fff',
                                border:'3px solid var(--border)',marginBottom:10,
                                position:'relative'
                            }}>
                                {dispPhoto
                                    ? <img src={dispPhoto} alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}
                                           onError={function(){ setPhotoErr(true); }} />
                                    : prInitials(profile ? profile.full_name : '')}
                                {uploading && (
                                    <div style={{
                                        position:'absolute',inset:0,background:'rgba(0,0,0,.5)',
                                        display:'flex',alignItems:'center',justifyContent:'center',
                                        color:'#fff',fontSize:11
                                    }}>…</div>
                                )}
                            </div>
                            <input ref={fileRef} type="file" accept="image/*" style={{display:'none'}}
                                   onChange={handlePhotoChange} />
                            <button className="btn-link" style={{fontSize:12}}
                                    onClick={function(){ fileRef.current && fileRef.current.click(); }}>
                                Change photo
                            </button>
                        </div>

                        {/* Info */}
                        {!editMode ? (
                            <div>
                                <div className="pf-row">
                                    <div className="pf-label">Full Name</div>
                                    <div className="pf-val">{profile.full_name}</div>
                                </div>
                                <div className="pf-row">
                                    <div className="pf-label">Email</div>
                                    <div className="pf-val">{profile.email}</div>
                                </div>
                                <div className="pf-row">
                                    <div className="pf-label">Phone</div>
                                    <div className="pf-val">{profile.phone || '—'}</div>
                                </div>
                                {profile.children && profile.children.length > 0 && (
                                    <div className="pf-row">
                                        <div className="pf-label">Children</div>
                                        <div className="pf-val">
                                            {profile.children.map(function(c, i){
                                                return (
                                                    <span key={i} style={{
                                                        display:'inline-block',
                                                        background:'var(--blue-light)',
                                                        color:'var(--blue)',
                                                        borderRadius:20,
                                                        padding:'2px 10px',
                                                        fontSize:12,fontWeight:600,
                                                        marginRight:6,marginBottom:4
                                                    }}>
                                                        {c.student_name}
                                                    </span>
                                                );
                                            })}
                                        </div>
                                    </div>
                                )}
                                <div style={{display:'flex',gap:10,marginTop:20}}>
                                    <button className="btn-primary" onClick={function(){ setEditMode(true); setAlert(null); }}>
                                        Edit Profile
                                    </button>
                                    <button className="btn-secondary" onClick={function(){ setShowPw(function(v){ return !v; }); setAlert(null); }}>
                                        Change Password
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <div>
                                <div className="form-group">
                                    <label className="form-label">Full Name</label>
                                    <input className="form-input" value={form.full_name}
                                           onChange={function(e){ setForm(function(f){ return Object.assign({},f,{full_name:e.target.value}); }); }} />
                                </div>
                                <div className="form-group">
                                    <label className="form-label">Email</label>
                                    <input className="form-input" value={form.email} readOnly style={{opacity:.6}} />
                                </div>
                                <div className="form-group">
                                    <label className="form-label">Phone</label>
                                    <input className="form-input" value={form.phone}
                                           onChange={function(e){ setForm(function(f){ return Object.assign({},f,{phone:e.target.value}); }); }} />
                                </div>
                                <div style={{display:'flex',gap:10,marginTop:20}}>
                                    <button className="btn-primary" onClick={handleSave} disabled={saving}>
                                        {saving ? 'Saving…' : 'Save Changes'}
                                    </button>
                                    <button className="btn-secondary" onClick={function(){ setEditMode(false); setAlert(null); }}>
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Change password section */}
                        {showPw && !editMode && (
                            <div style={{marginTop:24,paddingTop:20,borderTop:'1px solid var(--border)'}}>
                                <div style={{fontSize:13,fontWeight:700,color:'var(--text-mid)',marginBottom:14}}>
                                    🔐 Change Password
                                </div>
                                <div className="form-group">
                                    <label className="form-label">Current Password</label>
                                    <input className="form-input" type="password" value={pw.current}
                                           onChange={function(e){ setPw(function(p){ return Object.assign({},p,{current:e.target.value}); }); }} />
                                </div>
                                <div className="form-group">
                                    <label className="form-label">New Password</label>
                                    <input className="form-input" type="password" value={pw.newPw}
                                           onChange={function(e){ setPw(function(p){ return Object.assign({},p,{newPw:e.target.value}); }); }} />
                                </div>
                                <div className="form-group">
                                    <label className="form-label">Confirm New Password</label>
                                    <input className="form-input" type="password" value={pw.confirm}
                                           onChange={function(e){ setPw(function(p){ return Object.assign({},p,{confirm:e.target.value}); }); }} />
                                </div>
                                <button className="btn-primary" onClick={handleChangePassword} disabled={saving}
                                        style={{marginTop:8}}>
                                    {saving ? 'Updating…' : 'Update Password'}
                                </button>
                            </div>
                        )}

                    </div>
                )}
            </div>
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   BELL KEYFRAME INJECTION
   Same animation as nsmsBellPulse in nsms-shared.js.
   Injected once per page load; safe to call multiple times.
═══════════════════════════════════════════════════════════════ */
(function() {
    if (document.getElementById('pr-bell-kf')) return;
    var s = document.createElement('style');
    s.id = 'pr-bell-kf';
    s.textContent = [
        '@keyframes prBellPulse {',
        '  0%   { transform: rotate(0deg)   scale(1);    }',
        '  15%  { transform: rotate(-18deg) scale(1.18); }',
        '  30%  { transform: rotate(14deg)  scale(1.18); }',
        '  45%  { transform: rotate(-10deg) scale(1.12); }',
        '  60%  { transform: rotate(8deg)   scale(1.08); }',
        '  75%  { transform: rotate(-4deg)  scale(1.04); }',
        '  100% { transform: rotate(0deg)   scale(1);    }',
        '}'
    ].join('\n');
    document.head.appendChild(s);
}());

/* ── Parent bell sync constants (mirrors NSMS_BELL_POLL_MS / NSMS_REMINDER_MS) ── */
var PR_BELL_POLL_MS = 10000;   /* badge + silent list refresh — 10 s  */
var PR_REMINDER_MS  = 300000;  /* re-seed notifications + count sync  — 5 min */

/* ═══════════════════════════════════════════════════════════════
   NOTIFICATION BELL  (PrBell)
   Full port of NSMSBell from nsms-shared.js.
   • Two tabs: 💬 Messages  |  📣 Alerts
   • Messages tab links to parent/messages.html (J11 Pulse for parents)
   • Alerts tab reads from pulse_alert_recipients via parent-panel.php
   • Bell animates (prBellPulse) when total count increases
   • Shimmer placeholders while loading
   • Per-alert colour coding + mark-as-read (single or all)
   • Fast poll (PR_BELL_POLL_MS) + slow poll with notification re-seed
═══════════════════════════════════════════════════════════════ */
function PrBell() {
    var useState  = React.useState;
    var useEffect = React.useEffect;
    var useRef    = React.useRef;

    /* ── state ── */
    var countsSt  = useState({ msgs: 0, alerts: 0 });
    var counts    = countsSt[0];  var setCounts    = countsSt[1];

    var openSt    = useState(false);
    var open      = openSt[0];    var setOpen      = openSt[1];

    var tabSt     = useState('alerts');
    var activeTab = tabSt[0];     var setActiveTab = tabSt[1];

    var alertsSt  = useState([]);
    var alerts    = alertsSt[0];  var setAlerts    = alertsSt[1];

    var alLoadSt  = useState(false);
    var alLoading = alLoadSt[0];  var setAlLoading = alLoadSt[1];

    var prevTotalRef = useRef(-1);
    var pulseSt      = useState(false);
    var isPulsing    = pulseSt[0]; var setIsPulsing = pulseSt[1];

    var panelRef = useRef(null);
    /* Single pulse source: only prevTotalRef (in fetchCounts) drives the
       bell animation — prevents double-ring on the same event. */

    /* ── helpers ── */
    function timeAgo(ts) {
        if (!ts) return '';
        var d    = new Date(ts.replace(' ', 'T'));
        var diff = Math.floor((Date.now() - d.getTime()) / 1000);
        if (diff < 60)    return 'Just now';
        if (diff < 3600)  return Math.floor(diff / 60)   + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        return Math.floor(diff / 86400) + 'd ago';
    }

    function alertIcon(type) {
        var MAP = {
            'attendance'        : '📊',
            'attendance_issue'  : '⚠️',
            'homework'          : '📚',
            'homework_deadline' : '✏️',
            'fee'               : '💰',
            'fee_payment'       : '💰',
            'announcement'      : '📢',
            'report'            : '📋',
            'exam_reminder'     : '📝',
            'new_student'       : '🎒',
            'class_assignment'  : '🏫',
            'subject_assignment': '📚',
            'admin_message'     : '📩',
            'teacher_message'   : '💬',
            'parent_message'    : '👨‍👩‍👧',
            'system'            : '⚙️',
            'info'              : '📣',
            'pulse_alert'       : '🔔',
        };
        return MAP[type] || '📣';
    }

    function alertColors(type, unread) {
        if (!unread) return { bg:'#FAFBFC', border:'#F1F5F9', iconBg:'#F1F5F9' };
        var T = {
            'attendance'        : { bg:'#FFF1F2', border:'#FECDD3', iconBg:'#FFE4E6' },
            'attendance_issue'  : { bg:'#FFF1F2', border:'#FECDD3', iconBg:'#FFE4E6' },
            'homework'          : { bg:'#F5F3FF', border:'#DDD6FE', iconBg:'#EDE9FE' },
            'homework_deadline' : { bg:'#FFFBEB', border:'#FDE68A', iconBg:'#FEF3C7' },
            'fee'               : { bg:'#F0FDF4', border:'#BBF7D0', iconBg:'#DCFCE7' },
            'fee_payment'       : { bg:'#F0FDF4', border:'#BBF7D0', iconBg:'#DCFCE7' },
            'exam_reminder'     : { bg:'#FFF7ED', border:'#FED7AA', iconBg:'#FFEDD5' },
            'class_assignment'  : { bg:'#EFF6FF', border:'#BFDBFE', iconBg:'#DBEAFE' },
            'subject_assignment': { bg:'#F5F3FF', border:'#DDD6FE', iconBg:'#EDE9FE' },
            'announcement'      : { bg:'#F0F9FF', border:'#BAE6FD', iconBg:'#E0F2FE' },
            'teacher_message'   : { bg:'#F0F9FF', border:'#BAE6FD', iconBg:'#E0F2FE' },
            'parent_message'    : { bg:'#F5F3FF', border:'#DDD6FE', iconBg:'#EDE9FE' },
            'pulse_alert'       : { bg:'#FFF7ED', border:'#FED7AA', iconBg:'#FFEDD5' },
        };
        return T[type] || { bg:'#FFFBEB', border:'#FDE68A', iconBg:'#FEF3C7' };
    }

    /* ── API ── */
    function fetchCounts() {
        fetch('/nsms/api/parent-panel.php?action=notifications_count')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (!d.success) return;
                var nm  = d.data.messages      || 0;
                var na  = d.data.notifications || 0;
                var tot = nm + na;
                if (tot > prevTotalRef.current && prevTotalRef.current !== -1) {
                    setIsPulsing(true);
                    setTimeout(function(){ setIsPulsing(false); }, 820);
                }
                prevTotalRef.current = tot;
                setCounts({ msgs: nm, alerts: na });
            })
            .catch(function(){});
    }

    /* Full fetch: shows shimmer, used on first panel open. */
    function fetchAlerts() {
        setAlLoading(true);
        fetch('/nsms/api/parent-panel.php?action=notifications')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    var raw = d.data || [];
                    setAlerts(raw);
                    var unread = raw.filter(function(a){ return !a.is_read || a.is_read == 0; }).length;
                    setCounts(function(c){ return Object.assign({}, c, { alerts: unread }); });
                    fetchCounts();
                }
            })
            .catch(function(){})
            .finally(function(){ setAlLoading(false); });
    }

    /* Silent refresh: no shimmer — runs on fast tick (panel open or closed). */
    function silentRefresh() {
        fetch('/nsms/api/parent-panel.php?action=notifications')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (!d.success) return;
                var raw    = d.data || [];
                setAlerts(raw);
                var unread = raw.filter(function(a){ return !a.is_read || a.is_read == 0; }).length;
                setCounts(function(c){ return Object.assign({}, c, { alerts: unread }); });
            })
            .catch(function(){});
    }

    function markRead(id) {
        fetch('/nsms/api/parent-panel.php?action=mark_notifications_read', {
            method : 'POST',
            headers: { 'Content-Type':'application/json' },
            body   : JSON.stringify({ id: id })
        })
        .then(function(){
            setAlerts(function(prev){
                return prev.map(function(a){
                    return (id === 0 || a.id === id)
                        ? Object.assign({}, a, { is_read: 1 }) : a;
                });
            });
            setCounts(function(c){
                var newAlerts = id === 0 ? 0 : Math.max(0, c.alerts - 1);
                return Object.assign({}, c, { alerts: newAlerts });
            });
        })
        .catch(function(){});
    }

    /* ── effects ── */
    useEffect(function() {
        prevTotalRef.current = -1;

        /* Seed notifications in background on mount */
        fetch('/nsms/api/parent-panel.php?action=generate_notifications').catch(function(){});

        fetchCounts();
        silentRefresh(); /* init alert badge from list on mount */

        /* fastT — refresh count + alert list every PR_BELL_POLL_MS */
        var fastT = setInterval(function(){
            fetchCounts();
            silentRefresh();
        }, PR_BELL_POLL_MS);

        /* slowT — re-seed notifications + sync counts every 5 min */
        var slowT = setInterval(function(){
            fetch('/nsms/api/parent-panel.php?action=generate_notifications').catch(function(){});
            fetchCounts();
        }, PR_REMINDER_MS);

        return function(){ clearInterval(fastT); clearInterval(slowT); };
    }, []);

    useEffect(function() {
        if (!open) return;
        fetchAlerts();
        /* Fast tick already runs silentRefresh every PR_BELL_POLL_MS;
           just wire up outside-click close. */
        var close = function(e){
            if (panelRef.current && !panelRef.current.contains(e.target)) setOpen(false);
        };
        document.addEventListener('mousedown', close);
        return function(){ document.removeEventListener('mousedown', close); };
    }, [open]);

    var total    = counts.msgs + counts.alerts;
    var badgeNum = total > 99 ? '99+' : total;

    /* ── render ── */
    return (
        <div ref={panelRef} style={{ position:'relative', display:'flex', alignItems:'center' }}>

            {/* ── Bell button ── */}
            <button
                onClick={function(){ setOpen(function(o){ return !o; }); }}
                style={{
                    position:'relative', width:40, height:40, borderRadius:9,
                    border:'none', background: open ? 'var(--blue-light)' : 'none',
                    cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:20, transition:'background .15s', flexShrink:0
                }}
                title="Notifications"
            >
                <span style={{
                    display:'inline-block', transformOrigin:'50% 10%',
                    animation: isPulsing ? 'prBellPulse .82s ease' : 'none'
                }}>🔔</span>
                {total > 0 && (
                    <span style={{
                        position:'absolute', top:3, right:3,
                        minWidth:16, height:16, borderRadius:8,
                        background:'#EF4444', color:'white',
                        fontSize:9, fontWeight:800, lineHeight:'16px',
                        textAlign:'center', padding:'0 3px',
                        border:'1.5px solid white', fontFamily:'var(--font)'
                    }}>{badgeNum}</span>
                )}
            </button>

            {/* ── Drop-down panel ── */}
            {open && (
                <div style={{
                    position:'absolute', top:'calc(var(--nav-h) + 4px)', right:0,
                    background:'white', border:'1px solid var(--border)',
                    borderRadius:14, boxShadow:'0 12px 40px rgba(0,0,0,.15)',
                    width:330, overflow:'hidden', zIndex:1100,
                    animation:'navDrop .18s ease'
                }}>
                    {/* ── Header + tabs ── */}
                    <div style={{ background:'linear-gradient(135deg,#2563EB,#1E40AF)', padding:'14px 16px 0' }}>
                        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
                            <span style={{ fontSize:13, fontWeight:700, color:'white' }}>🔔 Notifications</span>
                            {total > 0 && (
                                <span style={{
                                    background:'rgba(255,255,255,.22)', color:'white',
                                    fontSize:11, fontWeight:700, padding:'2px 8px', borderRadius:20
                                }}>{total} unread</span>
                            )}
                        </div>
                        {/* Tab row */}
                        <div style={{ display:'flex', gap:4 }}>
                            {[
                                { id:'messages', label:'💬 Messages', badge: counts.msgs   },
                                { id:'alerts',   label:'📣 Alerts',   badge: counts.alerts }
                            ].map(function(tab) {
                                var isActive = activeTab === tab.id;
                                return (
                                    <button key={tab.id} onClick={function(){ setActiveTab(tab.id); }}
                                        style={{
                                            flex:1, padding:'8px 6px', borderRadius:'8px 8px 0 0',
                                            border:'none', cursor:'pointer', fontSize:12.5, fontWeight:700,
                                            display:'flex', alignItems:'center', justifyContent:'center', gap:5,
                                            background : isActive ? 'white' : 'rgba(255,255,255,.16)',
                                            color      : isActive ? '#1E40AF' : 'rgba(255,255,255,.88)',
                                            transition :'all .15s', fontFamily:'var(--font)'
                                        }}>
                                        {tab.label}
                                        {tab.badge > 0 && (
                                            <span style={{
                                                background: isActive ? '#EF4444' : 'rgba(255,255,255,.28)',
                                                color:'white', fontSize:10, fontWeight:800,
                                                padding:'1px 5px', borderRadius:10,
                                                minWidth:16, textAlign:'center'
                                            }}>{tab.badge}</span>
                                        )}
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* ── Tab body ── */}
                    <div style={{ maxHeight:360, overflowY:'auto' }}>

                        {/* Messages tab */}
                        {activeTab === 'messages' && (
                            <div style={{ padding:'12px 10px' }}>
                                <a href="/nsms/public/parent/messages.html"
                                   style={{
                                       display:'flex', alignItems:'center', gap:12,
                                       padding:'13px 14px', borderRadius:11,
                                       background : counts.msgs > 0 ? '#F0F9FF' : '#FAFBFC',
                                       border     : counts.msgs > 0 ? '1.5px solid #BFDBFE' : '1.5px solid #F1F5F9',
                                       color:'var(--text-mid)', textDecoration:'none', transition:'background .15s'
                                   }}
                                   onMouseOver={function(e){ e.currentTarget.style.background='#EFF6FF'; }}
                                   onMouseOut={function(e){ e.currentTarget.style.background=counts.msgs>0?'#F0F9FF':'#FAFBFC'; }}>
                                    <span style={{ fontSize:28 }}>💬</span>
                                    <div style={{ flex:1 }}>
                                        <div style={{ fontSize:13.5, fontWeight:700, color:'var(--text-dark)' }}>Messages</div>
                                        <div style={{ fontSize:12, color:'var(--text-muted)', marginTop:2 }}>
                                            {counts.msgs > 0
                                                ? counts.msgs + ' unread message' + (counts.msgs > 1 ? 's' : '')
                                                : 'No unread messages'}
                                        </div>
                                    </div>
                                    {counts.msgs > 0 && (
                                        <span style={{
                                            background:'#2563EB', color:'white',
                                            fontSize:12, fontWeight:800, padding:'3px 10px', borderRadius:20
                                        }}>{counts.msgs}</span>
                                    )}
                                </a>
                                {counts.msgs === 0 && (
                                    <div style={{ textAlign:'center', padding:'18px 0 10px', color:'var(--text-muted)', fontSize:12.5 }}>
                                        <div style={{ fontSize:26, marginBottom:5 }}>✅</div>
                                        All messages read
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Alerts tab */}
                        {activeTab === 'alerts' && (
                            <div>
                                {alLoading ? (
                                    <div style={{ padding:'14px 12px', display:'flex', flexDirection:'column', gap:8 }}>
                                        {[1,2,3].map(function(i){
                                            return (
                                                <div key={i} style={{
                                                    height:60, borderRadius:10,
                                                    background:'linear-gradient(90deg,#F1F5F9 25%,#E9EEF3 50%,#F1F5F9 75%)',
                                                    backgroundSize:'200% 100%', animation:'shim 1.4s infinite'
                                                }}></div>
                                            );
                                        })}
                                    </div>
                                ) : alerts.length === 0 ? (
                                    <div style={{ textAlign:'center', padding:'32px 0', color:'var(--text-muted)', fontSize:12.5 }}>
                                        <div style={{ fontSize:28, marginBottom:6 }}>📭</div>
                                        No system alerts
                                    </div>
                                ) : (
                                    <>
                                        {counts.alerts > 0 && (
                                            <div style={{ display:'flex', justifyContent:'flex-end', padding:'8px 14px 2px' }}>
                                                <button onClick={function(){ markRead(0); }}
                                                    style={{
                                                        border:'none', background:'none', color:'var(--blue)',
                                                        fontSize:11.5, fontWeight:700, cursor:'pointer',
                                                        fontFamily:'var(--font)', padding:'2px 6px', borderRadius:5
                                                    }}>✓ Mark all read</button>
                                            </div>
                                        )}
                                        <div style={{ padding:'4px 10px 10px' }}>
                                            {alerts.map(function(al) {
                                                var unread = !al.is_read || al.is_read == 0;
                                                var clr    = alertColors(al.type, unread);
                                                return (
                                                    <div key={al.id} style={{
                                                        display:'flex', gap:10,
                                                        padding:'11px 12px', borderRadius:11, marginBottom:7,
                                                        background: clr.bg, border:'1.5px solid ' + clr.border,
                                                        transition:'background .15s, border-color .15s'
                                                    }}>
                                                        <div style={{
                                                            width:34, height:34, borderRadius:9, flexShrink:0,
                                                            background: clr.iconBg,
                                                            display:'flex', alignItems:'center', justifyContent:'center', fontSize:17
                                                        }}>{alertIcon(al.type)}</div>
                                                        <div style={{ flex:1, minWidth:0 }}>
                                                            <div style={{
                                                                fontSize:13, fontWeight: unread ? 700 : 600,
                                                                color:'var(--text-dark)',
                                                                whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'
                                                            }}>{al.title || 'Alert'}</div>
                                                            <div style={{
                                                                fontSize:11.5, color:'var(--text-soft)', marginTop:2, lineHeight:1.4,
                                                                display:'-webkit-box', WebkitLineClamp:2,
                                                                WebkitBoxOrient:'vertical', overflow:'hidden'
                                                            }}>{al.message}</div>
                                                            <div style={{ fontSize:10.5, color:'var(--text-muted)', marginTop:5 }}>
                                                                {timeAgo(al.created_at)}
                                                            </div>
                                                        </div>
                                                        {unread && (
                                                            <button onClick={function(){ markRead(al.id); }}
                                                                title="Mark as read"
                                                                style={{
                                                                    border:'none', background:'none', cursor:'pointer',
                                                                    padding:'2px 4px', color:'#94A3B8', fontSize:14,
                                                                    alignSelf:'flex-start', flexShrink:0,
                                                                    fontFamily:'var(--font)', lineHeight:1
                                                                }}>✕</button>
                                                        )}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </>
                                )}
                            </div>
                        )}
                    </div>{/* /tab body */}

                    {/* ── Footer ── */}
                    <div style={{ borderTop:'1px solid var(--border)', padding:'8px 10px', background:'#FAFBFC' }}>
                        {activeTab === 'messages' ? (
                            <a href="/nsms/public/parent/messages.html"
                               style={{
                                   display:'block', textAlign:'center', padding:'8px', borderRadius:7,
                                   color:'var(--blue)', fontSize:12, fontWeight:700,
                                   textDecoration:'none', transition:'background .15s'
                               }}
                               onMouseOver={function(e){ e.currentTarget.style.background='var(--blue-light)'; }}
                               onMouseOut={function(e){ e.currentTarget.style.background='none'; }}>
                                Open Messages →
                            </a>
                        ) : (
                            counts.alerts > 0 ? (
                                <button onClick={function(){ markRead(0); }}
                                    style={{
                                        display:'block', width:'100%', textAlign:'center',
                                        padding:'8px', borderRadius:7, border:'none',
                                        background:'none', color:'var(--blue)',
                                        fontSize:12, fontWeight:700, cursor:'pointer',
                                        transition:'background .15s', fontFamily:'var(--font)'
                                    }}
                                    onMouseOver={function(e){ e.currentTarget.style.background='var(--blue-light)'; }}
                                    onMouseOut={function(e){ e.currentTarget.style.background='none'; }}>
                                    ✓ Mark all alerts as read
                                </button>
                            ) : (
                                <div style={{ textAlign:'center', padding:'6px 0', color:'var(--text-muted)', fontSize:12, fontWeight:600 }}>
                                    ✅ All caught up
                                </div>
                            )
                        )}
                    </div>
                </div>
            )}{/* /open */}
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   PARENT NAVBAR
   Layout:  [toggle] [brand] [child-selector] | [links] [clock] [bell + user]
   CSS classes match NSMSNavbar: nsms-nav, nav-toggle, nav-brand,
   nav-links, nav-center, nav-right, nav-user-btn, nav-dd, etc.
═══════════════════════════════════════════════════════════════ */
function ParentNavbar(props) {
    var activePage       = props.activePage       || 'dashboard';
    var sidebarOpen      = props.sidebarOpen;
    var setSidebar       = props.setSidebar;
    var unreadMsg        = props.unreadMsg        || 0;
    var children         = props.children         || [];
    var selectedChild    = props.selectedChild;
    var setSelectedChild = props.setSelectedChild;

    var useState  = React.useState;
    var useEffect = React.useEffect;
    var useRef    = React.useRef;

    var ddOpenSt = useState(false); var ddOpen  = ddOpenSt[0]; var setDdOpen  = ddOpenSt[1];
    var pfOpenSt = useState(false); var pfOpen  = pfOpenSt[0]; var setPfOpen  = pfOpenSt[1];
    var loadSt   = useState(true);  var loading = loadSt[0];   var setLoading = loadSt[1];
    var userSt   = useState(null);  var user    = userSt[0];   var setUser    = userSt[1];
    var logoSt   = useState('');    var logoUrl = logoSt[0];   var setLogoUrl = logoSt[1];
    var schNmSt  = useState('');    var schName = schNmSt[0];  var setSchName = schNmSt[1];
    var imgErrSt = useState(false); var imgErr  = imgErrSt[0]; var setImgErr  = imgErrSt[1];
    var ddRef    = useRef(null);

    var go = function(href){ window.location.href = href; };

    /* Load session + logo + school name */
    useEffect(function(){
        fetch('/nsms/api/parent-panel.php?action=session')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setUser(d.data);
                    if (d.data.children && d.data.children.length > 0 && !selectedChild) {
                        if (setSelectedChild) setSelectedChild(d.data.children[0]);
                    }
                } else if (d.error === 'unauthorized') {
                    window.location.href = '/nsms/public/index.html';
                }
            })
            .catch(function(){})
            .finally(function(){ setLoading(false); });

        _prLoadLogo(function(url){ setLogoUrl(url); });

        fetch('/nsms/api/settings.php?action=get_public')
            .then(function(r){ return r.json(); })
            .then(function(d){ if (d.success && d.data) setSchName(d.data.school_name || ''); })
            .catch(function(){});
    }, []);

    /* Close dropdown on outside click */
    useEffect(function(){
        if (!ddOpen) return;
        function onOut(e){
            if (ddRef.current && !ddRef.current.contains(e.target)) setDdOpen(false);
        }
        document.addEventListener('mousedown', onOut);
        return function(){ document.removeEventListener('mousedown', onOut); };
    }, [ddOpen]);

    function handleSignOut() {
        fetch('/nsms/api/parent-panel.php?action=signout')
            .finally(function(){ window.location.href = '/nsms/public/index.html'; });
    }

    var dispName = schName || 'NSMS';
    var hasPhoto = !imgErr && user && user.photo_url;

    /* ── Child selector dropdown ─────────────────────────────────────────────── */
    var kidListSt = useState(false); var kidOpen = kidListSt[0]; var setKidOpen = kidListSt[1];
    var kidRef    = useRef(null);

    useEffect(function(){
        if (!kidOpen) return;
        function onOut(e){ if (kidRef.current && !kidRef.current.contains(e.target)) setKidOpen(false); }
        document.addEventListener('mousedown', onOut);
        return function(){ document.removeEventListener('mousedown', onOut); };
    }, [kidOpen]);

    var userChildren = (user && user.children) ? user.children : children;

    return (
        <>
            {/* nav class "nsms-nav" matches NSMSNavbar */}
            <nav className="nsms-nav">

                {/* ── Hamburger toggle — "nav-toggle" matches NSMSNavbar ── */}
                <button className="nav-toggle"
                        onClick={function(){ setSidebar(function(o){ return !o; }); }}
                        title="Toggle sidebar">
                    {sidebarOpen ? '✕' : '☰'}
                </button>

                {/* ── Brand block ── */}
                <div className="nav-brand">
                    <div className="nav-logo"><PrLogoMark logoUrl={logoUrl} /></div>
                    <div className="nav-school-name">
                        {loading ? (
                            <div>
                                <div className="nav-shimmer" style={{height:13,width:120,marginBottom:4}} />
                                <div className="nav-shimmer" style={{height:9,width:72}} />
                            </div>
                        ) : (
                            <div>
                                <div className="nav-school-title">{dispName}</div>
                                <div className="nav-school-sub">Parent Portal</div>
                            </div>
                        )}
                    </div>
                </div>

                {/* ── Child selector (parent-specific) ── */}
                {userChildren.length > 0 && (
                    <div ref={kidRef} style={{position:'relative',marginLeft:8}}>
                        <button
                            onClick={function(){ setKidOpen(function(o){ return !o; }); }}
                            style={{
                                display:'flex',alignItems:'center',gap:8,
                                background:'rgba(255,255,255,.12)',
                                border:'1px solid rgba(255,255,255,.2)',
                                borderRadius:8,padding:'5px 12px',
                                color:'#fff',fontSize:13,fontWeight:600,cursor:'pointer',
                                transition:'background .2s'
                            }}>
                            <span style={{fontSize:16}}>👦</span>
                            <span>{selectedChild ? selectedChild.student_name : (userChildren[0] && userChildren[0].student_name)}</span>
                            <span style={{fontSize:10,opacity:.8}}>▾</span>
                        </button>
                        {kidOpen && userChildren.length > 1 && (
                            <div style={{
                                position:'absolute',top:'calc(100% + 6px)',left:0,
                                background:'#fff',borderRadius:10,
                                boxShadow:'0 8px 24px rgba(0,0,0,.12)',
                                minWidth:180,zIndex:300,overflow:'hidden'
                            }}>
                                {userChildren.map(function(child){
                                    var isSel = selectedChild && selectedChild.id === child.id;
                                    return (
                                        <button key={child.id}
                                                onClick={function(){
                                                    if (setSelectedChild) setSelectedChild(child);
                                                    setKidOpen(false);
                                                }}
                                                style={{
                                                    display:'flex',alignItems:'center',gap:10,
                                                    width:'100%',padding:'10px 14px',
                                                    background: isSel ? '#EFF6FF' : 'transparent',
                                                    border:'none',cursor:'pointer',textAlign:'left',
                                                    color: isSel ? 'var(--blue)' : 'var(--text-dark)',
                                                    fontSize:13,fontWeight: isSel ? 700 : 500
                                                }}>
                                            <div style={{
                                                width:28,height:28,borderRadius:'50%',
                                                background: isSel ? '#BFDBFE' : '#F1F5F9',
                                                display:'flex',alignItems:'center',justifyContent:'center',
                                                fontSize:14
                                            }}>👦</div>
                                            <div>
                                                <div>{child.student_name}</div>
                                                <div style={{fontSize:11,color:'var(--text-muted)'}}>{child.class_name}</div>
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                )}

                {/* ── Left nav links ── */}
                <div className="nav-links">
                    {PARENT_NAV_LINKS.map(function(item) {
                        return (
                            <button key={item.key}
                                    className={'nav-link' + (activePage === item.key ? ' active' : '')}
                                    onClick={function(){ go(item.href); }}>
                                {item.label}
                            </button>
                        );
                    })}
                </div>

                {/* ── Centre: live clock ── */}
                <PrNavClock />

                {/* ── Right: bell + user dropdown ── */}
                <div className="nav-right" style={{gap:8}}>

                    <PrBell />
                    <div className="nav-divider" />

                    <div ref={ddRef} style={{position:'relative'}}>
                        <button className={'nav-user-btn' + (ddOpen ? ' open' : '')}
                                onClick={function(){ setDdOpen(function(o){ return !o; }); }}>
                            <div className="nav-avatar"
                                 style={{background: user ? prAvColor(user.full_name) : '#E2E8F0'}}>
                                {hasPhoto
                                    ? <img src={user.photo_url} alt=""
                                           onError={function(){ setImgErr(true); }} />
                                    : user ? prInitials(user.full_name) : '?'}
                            </div>
                            <div>
                                <div className="nav-user-name">
                                    {loading ? '…' : user ? user.full_name.split(' ')[0] : 'Parent'}
                                </div>
                                <div className="nav-user-role">Parent</div>
                            </div>
                            <span className="nav-chevron">▾</span>
                        </button>

                        {ddOpen && (
                            <div className="nav-dd">
                                <div className="nav-dd-head">
                                    <div className="nav-dd-av"
                                         style={{background: user ? prAvColor(user.full_name) : 'rgba(255,255,255,.2)'}}>
                                        {hasPhoto
                                            ? <img src={user.photo_url} alt="" />
                                            : user ? prInitials(user.full_name) : '?'}
                                    </div>
                                    <div>
                                        <div className="nav-dd-name">{user ? user.full_name : 'Parent'}</div>
                                        <div className="nav-dd-email">{user ? user.email : ''}</div>
                                        <span className="nav-dd-role">🏠 Parent Portal</span>
                                    </div>
                                </div>
                                <div className="nav-dd-body">
                                    <button className="nav-dd-item"
                                            onClick={function(){ setDdOpen(false); setPfOpen(true); }}>
                                        <span className="nav-dd-icon">👤</span> My Profile
                                    </button>
                                    <button className="nav-dd-item"
                                            onClick={function(){ setDdOpen(false); go('/nsms/public/parent/messages.html'); }}>
                                        <span className="nav-dd-icon">💬</span> Messages
                                        {unreadMsg > 0 && (
                                            <span style={{
                                                marginLeft:'auto',background:'#EF4444',color:'#fff',
                                                borderRadius:20,padding:'1px 7px',fontSize:11,fontWeight:700
                                            }}>{unreadMsg}</span>
                                        )}
                                    </button>
                                    <div className="nav-dd-sep" />
                                    <button className="nav-dd-item danger" onClick={handleSignOut}>
                                        <span className="nav-dd-icon">🚪</span> Sign Out
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>{/* /ddRef */}
                </div>{/* /nav-right */}
            </nav>

            <ParentProfileModal open={pfOpen} onClose={function(){ setPfOpen(false); }} />
        </>
    );
}

/* ═══════════════════════════════════════════════════════════════
   PARENT SIDEBAR
   Matches NSMSSidebar exactly:
   • Collapsed by default; hover → expands; mouse-leave → collapses
     after 180 ms delay.
   • Toggle pin from navbar (sidebarOpen prop).
   • Uses nsms-sidebar / sb-item / sb-icon / sb-label CSS classes.
   • Messages item shows unread badge when unreadMsg > 0.
═══════════════════════════════════════════════════════════════ */
function ParentSidebar(props) {
    var activePage  = props.activePage  || 'dashboard';
    var sidebarOpen = props.sidebarOpen;
    var unreadMsg   = props.unreadMsg   || 0;
    var go          = function(href){ window.location.href = href; };

    var useState = React.useState;
    var useRef   = React.useRef;

    var hoverSt    = useState(false); var isHovered  = hoverSt[0];  var setIsHovered  = hoverSt[1];
    var leaveTimer = useRef(null);

    function handleEnter() {
        if (leaveTimer.current) { clearTimeout(leaveTimer.current); leaveTimer.current = null; }
        setIsHovered(true);
    }
    function handleLeave() {
        leaveTimer.current = setTimeout(function(){ setIsHovered(false); }, 180);
    }

    var isExpanded = sidebarOpen || isHovered;

    return (
        <aside className={'nsms-sidebar' + (isExpanded ? '' : ' collapsed')}
               onMouseEnter={handleEnter}
               onMouseLeave={handleLeave}>
            {PARENT_SIDEBAR_ITEMS.map(function(item) {
                var badge = (item.key === 'messages' && unreadMsg > 0) ? unreadMsg : 0;
                return (
                    <button key={item.key}
                            className={'sb-item' + (activePage === item.key ? ' active' : '')}
                            data-tip={item.label}
                            onClick={function(){ go(item.href); }}>
                        <span className="sb-icon">{item.icon}</span>
                        <span className="sb-label">{item.label}</span>
                        {badge > 0 && (
                            <span className="sb-badge">{badge > 9 ? '9+' : badge}</span>
                        )}
                    </button>
                );
            })}
            <div className="sb-spacer" />
        </aside>
    );
}
