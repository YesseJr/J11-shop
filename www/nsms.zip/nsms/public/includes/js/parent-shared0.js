/* ═══════════════════════════════════════════════════════════════
   NSMS PARENT SHARED COMPONENTS  —  nsms/public/includes/js/parent-shared.js
   Self-contained — no dependency on nsms-shared.js
   Exposes globals: ParentNavbar, ParentSidebar
   Requires: React 18 loaded before this file.
═══════════════════════════════════════════════════════════════ */

/* ── Avatar helpers ── */
var PR_AV_COLORS = ['#10B981','#2563EB','#F59E0B','#8B5CF6','#EF4444','#0891B2'];
var prAvColor    = function(n) { return n ? PR_AV_COLORS[n.charCodeAt(0) % PR_AV_COLORS.length] : '#94A3B8'; };
var prInitials   = function(n) { return n ? n.split(' ').map(function(w){ return w[0]; }).join('').toUpperCase().slice(0,2) : '?'; };

/* ── Parent sidebar items ── */
var PARENT_SIDEBAR_ITEMS = [
    { key: 'dashboard',    icon: '🏠', label: 'Dashboard',    href: '/nsms/public/parent/dashboard.html'    },
    { key: 'daily_diary',  icon: '📅', label: 'Daily Diary',  href: '/nsms/public/parent/daily-diary.html'  },
    { key: 'reports',      icon: '📋', label: 'Reports',      href: '/nsms/public/parent/reports.html'      },
    { key: 'attendance',   icon: '📊', label: 'Attendance',   href: '/nsms/public/parent/attendance.html'   },
    { key: 'fee_payments', icon: '💰', label: 'Fee Payments', href: '/nsms/public/parent/fee-payments.html' },
    { key: 'messages',     icon: '💬', label: 'Messages',     href: '/nsms/public/parent/messages.html'     },
];

/* ── Parent navbar links ── */
var PARENT_NAV_LINKS = [
    { key: 'dashboard',    label: 'Home',         href: '/nsms/public/parent/dashboard.html'    },
    { key: 'daily_diary',  label: 'Daily Diary',  href: '/nsms/public/parent/daily-diary.html'  },
    { key: 'attendance',   label: 'Attendance',   href: '/nsms/public/parent/attendance.html'   },
    { key: 'fee_payments', label: 'Fee Payments', href: '/nsms/public/parent/fee-payments.html' },
    { key: 'messages',     label: 'Messages',     href: '/nsms/public/parent/messages.html'     },
];

/* ── Module-level logo cache ── */
var _prLogoCache   = { loaded: false, url: '' };
var _prLogoWaiters = [];
function _prLoadLogo(cb) {
    if (_prLogoCache.loaded) { cb(_prLogoCache.url); return; }
    _prLogoWaiters.push(cb);
    if (_prLogoWaiters.length > 1) return;
    fetch('/nsms/api/settings.php?action=get_public')
        .then(function(r){ return r.json(); })
        .then(function(d){ if (d.success && d.data) _prLogoCache.url = d.data.school_logo || ''; })
        .catch(function(){})
        .finally(function(){
            _prLogoCache.loaded = true;
            var waiters = _prLogoWaiters.slice(); _prLogoWaiters = [];
            waiters.forEach(function(fn){ fn(_prLogoCache.url); });
        });
}

/* ── School logo mark ── */
function PrLogoMark(props) {
    var logoUrl = props.logoUrl || '';
    if (logoUrl) {
        return (
            <img src={logoUrl} alt="School Logo"
                 style={{width:'100%',height:'100%',objectFit:'contain',borderRadius:'6px',display:'block'}}
                 onError={function(e){ e.target.style.display='none'; }} />
        );
    }
    return (
        <svg viewBox="0 0 24 24" fill="none">
            <path d="M3 21h18M5 21V7l7-4 7 4v14" stroke="rgba(255,255,255,.7)" strokeWidth="1.5" strokeLinejoin="round"/>
            <rect x="10" y="14" width="4" height="7" rx=".5" fill="rgba(255,255,255,.9)"/>
            <rect x="6.5" y="9.5" width="3" height="3" rx=".5" fill="rgba(255,255,255,.8)"/>
            <rect x="14.5" y="9.5" width="3" height="3" rx=".5" fill="rgba(255,255,255,.8)"/>
        </svg>
    );
}

/* ═══════════════════════════════════════════════════════════════
   LIVE CLOCK
═══════════════════════════════════════════════════════════════ */
function PrNavClock() {
    var useState  = React.useState;
    var useEffect = React.useEffect;

    var nowSt = useState(new Date()); var now = nowSt[0]; var setNow = nowSt[1];
    useEffect(function() {
        var t = setInterval(function(){ setNow(new Date()); }, 1000);
        return function(){ clearInterval(t); };
    }, []);

    function ordinal(n) {
        var s = ['th','st','nd','rd'], v = n % 100;
        return n + (s[(v-20)%10] || s[v] || s[0]);
    }
    var MONTHS = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];
    var dateStr = ordinal(now.getDate()) + ' ' + MONTHS[now.getMonth()] + ' ' + now.getFullYear();
    var hh = String(now.getHours()).padStart(2,'0');
    var mm = String(now.getMinutes()).padStart(2,'0');
    var ss = String(now.getSeconds()).padStart(2,'0');

    return (
        <div className="nav-center">
            <div className="nav-date-block">
                <div className="nav-date-icon">📅</div>
                <span className="nav-date-text">{dateStr}</span>
            </div>
            <div className="nav-center-sep" />
            <div className="nav-time-block">
                <div className="nav-time-icon">🕐</div>
                <span className="nav-time-text">{hh}:{mm}:{ss}</span>
            </div>
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   PARENT PROFILE MODAL
═══════════════════════════════════════════════════════════════ */
function ParentProfileModal(props) {
    var open    = props.open;
    var onClose = props.onClose;

    var useState  = React.useState;
    var useEffect = React.useEffect;
    var useRef    = React.useRef;

    var profSt    = useState(null);  var profile   = profSt[0];    var setProfile   = profSt[1];
    var loadSt    = useState(true);  var loading   = loadSt[0];    var setLoading   = loadSt[1];
    var saveSt    = useState(false); var saving    = saveSt[0];    var setSaving    = saveSt[1];
    var alertSt   = useState(null);  var alert     = alertSt[0];   var setAlert     = alertSt[1];
    var editSt    = useState(false); var editMode  = editSt[0];    var setEditMode  = editSt[1];
    var showPwSt  = useState(false); var showPw    = showPwSt[0];  var setShowPw    = showPwSt[1];
    var prevSt    = useState(null);  var preview   = prevSt[0];    var setPreview   = prevSt[1];
    var upSt      = useState(false); var uploading = upSt[0];      var setUploading = upSt[1];
    var photoErrSt= useState(false); var photoErr  = photoErrSt[0];var setPhotoErr  = photoErrSt[1];

    var formSt = useState({ full_name:'', email:'', phone:'' });
    var form   = formSt[0]; var setForm = formSt[1];
    var pwSt   = useState({ current:'', newPw:'', confirm:'' });
    var pw     = pwSt[0];   var setPw   = pwSt[1];

    var fileRef = useRef(null);

    useEffect(function() {
        if (!open) return;
        setLoading(true); setAlert(null); setEditMode(false);
        setShowPw(false); setPreview(null); setPhotoErr(false);
        setPw({ current:'', newPw:'', confirm:'' });

        fetch('/nsms/api/parent-panel.php?action=get_profile')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setProfile(d.data);
                    setForm({
                        full_name: d.data.full_name || '',
                        email:     d.data.email     || '',
                        phone:     d.data.phone     || ''
                    });
                } else {
                    setAlert({ type:'error', msg: d.error || 'Failed to load profile.' });
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error loading profile.' }); })
            .finally(function(){ setLoading(false); });
    }, [open]);

    useEffect(function() {
        if (!open) return;
        var onKey = function(e){ if (e.key === 'Escape') onClose(); };
        document.addEventListener('keydown', onKey);
        return function(){ document.removeEventListener('keydown', onKey); };
    }, [open]);

    if (!open) return null;

    var hasPhoto = !photoErr && profile && profile.photo_url;
    var dispPhoto = preview || (hasPhoto ? profile.photo_url : null);

    function handlePhotoChange(e) {
        var file = e.target.files && e.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function(ev){ setPreview(ev.target.result); };
        reader.readAsDataURL(file);

        var fd = new FormData();
        fd.append('photo', file);
        setUploading(true); setAlert(null);
        fetch('/nsms/api/parent-panel.php?action=upload_photo', { method:'POST', body:fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setProfile(function(p){ return Object.assign({}, p, { photo_url: d.data.photo_url }); });
                    setAlert({ type:'success', msg:'Photo updated.' });
                } else {
                    setAlert({ type:'error', msg: d.error || 'Upload failed.' });
                    setPreview(null);
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error during upload.' }); setPreview(null); })
            .finally(function(){ setUploading(false); });
    }

    function handleSave() {
        setSaving(true); setAlert(null);
        fetch('/nsms/api/parent-panel.php?action=update_profile', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ full_name: form.full_name, phone: form.phone })
        })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setProfile(function(p){ return Object.assign({}, p, { full_name: form.full_name, phone: form.phone }); });
                    setAlert({ type:'success', msg:'Profile updated successfully.' });
                    setEditMode(false);
                } else {
                    setAlert({ type:'error', msg: d.error || 'Update failed.' });
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error.' }); })
            .finally(function(){ setSaving(false); });
    }

    function handleChangePassword() {
        if (!pw.current || !pw.newPw || !pw.confirm) {
            setAlert({ type:'error', msg:'All password fields are required.' }); return;
        }
        if (pw.newPw !== pw.confirm) {
            setAlert({ type:'error', msg:'New passwords do not match.' }); return;
        }
        setSaving(true); setAlert(null);
        fetch('/nsms/api/parent-panel.php?action=change_password', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ current: pw.current, new: pw.newPw, confirm: pw.confirm })
        })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setAlert({ type:'success', msg:'Password changed successfully.' });
                    setPw({ current:'', newPw:'', confirm:'' });
                    setShowPw(false);
                } else {
                    setAlert({ type:'error', msg: d.error || 'Password change failed.' });
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error.' }); })
            .finally(function(){ setSaving(false); });
    }

    return (
        <div className="modal-overlay" onClick={function(e){ if (e.target === e.currentTarget) onClose(); }}>
            <div className="modal-box" style={{maxWidth:480}}>

                {/* Header */}
                <div className="modal-head">
                    <div className="modal-title">👤 My Profile</div>
                    <button className="modal-close" onClick={onClose}>✕</button>
                </div>

                {alert && (
                    <div className={'modal-alert ' + (alert.type === 'success' ? 'alert-ok' : 'alert-err')}>
                        {alert.msg}
                    </div>
                )}

                {loading ? (
                    <div style={{padding:32,textAlign:'center',color:'var(--text-muted)'}}>Loading…</div>
                ) : (
                    <div className="modal-body">

                        {/* Avatar */}
                        <div style={{display:'flex',flexDirection:'column',alignItems:'center',marginBottom:24}}>
                            <div style={{
                                width:80,height:80,borderRadius:'50%',overflow:'hidden',
                                background: prAvColor(profile ? profile.full_name : ''),
                                display:'flex',alignItems:'center',justifyContent:'center',
                                fontSize:28,fontWeight:700,color:'#fff',
                                border:'3px solid var(--border)',marginBottom:10,
                                position:'relative'
                            }}>
                                {dispPhoto
                                    ? <img src={dispPhoto} alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}
                                           onError={function(){ setPhotoErr(true); }} />
                                    : prInitials(profile ? profile.full_name : '')}
                                {uploading && (
                                    <div style={{
                                        position:'absolute',inset:0,background:'rgba(0,0,0,.5)',
                                        display:'flex',alignItems:'center',justifyContent:'center',
                                        color:'#fff',fontSize:11
                                    }}>…</div>
                                )}
                            </div>
                            <input ref={fileRef} type="file" accept="image/*" style={{display:'none'}}
                                   onChange={handlePhotoChange} />
                            <button className="btn-link" style={{fontSize:12}}
                                    onClick={function(){ fileRef.current && fileRef.current.click(); }}>
                                Change photo
                            </button>
                        </div>

                        {/* Info */}
                        {!editMode ? (
                            <div>
                                <div className="pf-row">
                                    <div className="pf-label">Full Name</div>
                                    <div className="pf-val">{profile.full_name}</div>
                                </div>
                                <div className="pf-row">
                                    <div className="pf-label">Email</div>
                                    <div className="pf-val">{profile.email}</div>
                                </div>
                                <div className="pf-row">
                                    <div className="pf-label">Phone</div>
                                    <div className="pf-val">{profile.phone || '—'}</div>
                                </div>
                                {profile.children && profile.children.length > 0 && (
                                    <div className="pf-row">
                                        <div className="pf-label">Children</div>
                                        <div className="pf-val">
                                            {profile.children.map(function(c, i){
                                                return (
                                                    <span key={i} style={{
                                                        display:'inline-block',
                                                        background:'var(--blue-light)',
                                                        color:'var(--blue)',
                                                        borderRadius:20,
                                                        padding:'2px 10px',
                                                        fontSize:12,fontWeight:600,
                                                        marginRight:6,marginBottom:4
                                                    }}>
                                                        {c.student_name}
                                                    </span>
                                                );
                                            })}
                                        </div>
                                    </div>
                                )}
                                <div style={{display:'flex',gap:10,marginTop:20}}>
                                    <button className="btn-primary" onClick={function(){ setEditMode(true); setAlert(null); }}>
                                        Edit Profile
                                    </button>
                                    <button className="btn-secondary" onClick={function(){ setShowPw(function(v){ return !v; }); setAlert(null); }}>
                                        Change Password
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <div>
                                <div className="form-group">
                                    <label className="form-label">Full Name</label>
                                    <input className="form-input" value={form.full_name}
                                           onChange={function(e){ setForm(function(f){ return Object.assign({},f,{full_name:e.target.value}); }); }} />
                                </div>
                                <div className="form-group">
                                    <label className="form-label">Email</label>
                                    <input className="form-input" value={form.email} readOnly style={{opacity:.6}} />
                                </div>
                                <div className="form-group">
                                    <label className="form-label">Phone</label>
                                    <input className="form-input" value={form.phone}
                                           onChange={function(e){ setForm(function(f){ return Object.assign({},f,{phone:e.target.value}); }); }} />
                                </div>
                                <div style={{display:'flex',gap:10,marginTop:20}}>
                                    <button className="btn-primary" onClick={handleSave} disabled={saving}>
                                        {saving ? 'Saving…' : 'Save Changes'}
                                    </button>
                                    <button className="btn-secondary" onClick={function(){ setEditMode(false); setAlert(null); }}>
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Change password section */}
                        {showPw && !editMode && (
                            <div style={{marginTop:24,paddingTop:20,borderTop:'1px solid var(--border)'}}>
                                <div style={{fontSize:13,fontWeight:700,color:'var(--text-mid)',marginBottom:14}}>
                                    🔐 Change Password
                                </div>
                                <div className="form-group">
                                    <label className="form-label">Current Password</label>
                                    <input className="form-input" type="password" value={pw.current}
                                           onChange={function(e){ setPw(function(p){ return Object.assign({},p,{current:e.target.value}); }); }} />
                                </div>
                                <div className="form-group">
                                    <label className="form-label">New Password</label>
                                    <input className="form-input" type="password" value={pw.newPw}
                                           onChange={function(e){ setPw(function(p){ return Object.assign({},p,{newPw:e.target.value}); }); }} />
                                </div>
                                <div className="form-group">
                                    <label className="form-label">Confirm New Password</label>
                                    <input className="form-input" type="password" value={pw.confirm}
                                           onChange={function(e){ setPw(function(p){ return Object.assign({},p,{confirm:e.target.value}); }); }} />
                                </div>
                                <button className="btn-primary" onClick={handleChangePassword} disabled={saving}
                                        style={{marginTop:8}}>
                                    {saving ? 'Updating…' : 'Update Password'}
                                </button>
                            </div>
                        )}

                    </div>
                )}
            </div>
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   NOTIFICATION BELL
═══════════════════════════════════════════════════════════════ */
function PrBell() {
    var useState  = React.useState;
    var useEffect = React.useEffect;
    var useRef    = React.useRef;

    var openSt   = useState(false); var open    = openSt[0];  var setOpen   = openSt[1];
    var notifsSt = useState([]);    var notifs  = notifsSt[0]; var setNotifs = notifsSt[1];
    var ddRef    = useRef(null);

    function fetchNotifs() {
        // Trigger notification generation then fetch latest
        fetch('/nsms/api/parent-panel.php?action=generate_notifications')
            .catch(function(){});

        fetch('/nsms/api/notifications.php?action=list&limit=10')
            .then(function(r){ return r.json(); })
            .then(function(d){ if (d.success) setNotifs(d.data || []); })
            .catch(function(){});
    }

    useEffect(function() {
        fetchNotifs();
        var t = setInterval(fetchNotifs, 60000);
        return function(){ clearInterval(t); };
    }, []);

    useEffect(function() {
        if (!open) return;
        function onOut(e) {
            if (ddRef.current && !ddRef.current.contains(e.target)) setOpen(false);
        }
        document.addEventListener('mousedown', onOut);
        return function(){ document.removeEventListener('mousedown', onOut); };
    }, [open]);

    var unread = notifs.filter(function(n){ return !n.is_read; }).length;

    function markRead(id) {
        fetch('/nsms/api/notifications.php?action=mark_read&id=' + id).catch(function(){});
        setNotifs(function(ns){ return ns.map(function(n){ return n.id === id ? Object.assign({},n,{is_read:1}) : n; }); });
    }

    function markAllRead() {
        fetch('/nsms/api/notifications.php?action=mark_all_read').catch(function(){});
        setNotifs(function(ns){ return ns.map(function(n){ return Object.assign({},n,{is_read:1}); }); });
    }

    var NOTIF_ICONS = {
        attendance: '📊', homework: '📚', fee: '💰',
        announcement: '📢', report: '📋', message: '💬'
    };

    return (
        <div ref={ddRef} style={{position:'relative'}}>
            <button className="nav-bell-btn" onClick={function(){ setOpen(function(o){ return !o; }); }}>
                🔔
                {unread > 0 && (
                    <span className="bell-badge">{unread > 9 ? '9+' : unread}</span>
                )}
            </button>

            {open && (
                <div className="nav-notif-dd">
                    <div className="notif-head">
                        <span style={{fontWeight:700,fontSize:13}}>🔔 Notifications</span>
                        {unread > 0 && (
                            <button className="btn-link" style={{fontSize:11}} onClick={markAllRead}>
                                Mark all read
                            </button>
                        )}
                    </div>
                    <div className="notif-list">
                        {notifs.length === 0 ? (
                            <div style={{padding:'20px 16px',textAlign:'center',color:'var(--text-muted)',fontSize:12}}>
                                No notifications yet
                            </div>
                        ) : notifs.map(function(n){
                            return (
                                <div key={n.id}
                                     className={'notif-item' + (n.is_read ? '' : ' unread')}
                                     onClick={function(){ markRead(n.id); }}>
                                    <div className="notif-icon">
                                        {NOTIF_ICONS[n.type] || '🔔'}
                                    </div>
                                    <div style={{flex:1,minWidth:0}}>
                                        <div className="notif-title">{n.title}</div>
                                        <div className="notif-msg">{n.message}</div>
                                        <div className="notif-time">
                                            {n.created_at ? n.created_at.slice(0,16).replace('T',' ') : ''}
                                        </div>
                                    </div>
                                    {!n.is_read && <div className="notif-dot" />}
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   PARENT NAVBAR
═══════════════════════════════════════════════════════════════ */
function ParentNavbar(props) {
    var activePage  = props.activePage  || 'dashboard';
    var sidebarOpen = props.sidebarOpen;
    var setSidebar  = props.setSidebar;
    var unreadMsg   = props.unreadMsg   || 0;  // from dashboard data
    var children    = props.children    || []; // list of children for selector
    var selectedChild    = props.selectedChild;
    var setSelectedChild = props.setSelectedChild;

    var useState  = React.useState;
    var useEffect = React.useEffect;
    var useRef    = React.useRef;

    var ddOpenSt = useState(false); var ddOpen = ddOpenSt[0]; var setDdOpen = ddOpenSt[1];
    var pfOpenSt = useState(false); var pfOpen = pfOpenSt[0]; var setPfOpen = pfOpenSt[1];
    var loadSt   = useState(true);  var loading = loadSt[0];  var setLoading = loadSt[1];
    var userSt   = useState(null);  var user = userSt[0];     var setUser = userSt[1];
    var logoSt   = useState('');    var logoUrl = logoSt[0];  var setLogoUrl = logoSt[1];
    var schNmSt  = useState('');    var schName = schNmSt[0]; var setSchName = schNmSt[1];
    var imgErrSt = useState(false); var imgErr  = imgErrSt[0];var setImgErr  = imgErrSt[1];
    var ddRef    = useRef(null);

    var go = function(href){ window.location.href = href; };

    // Load session + logo
    useEffect(function(){
        fetch('/nsms/api/parent-panel.php?action=session')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setUser(d.data);
                    if (d.data.children && d.data.children.length > 0 && !selectedChild) {
                        if (setSelectedChild) setSelectedChild(d.data.children[0]);
                    }
                } else if (d.error === 'unauthorized') {
                    window.location.href = '/nsms/public/login.html';
                }
            })
            .catch(function(){})
            .finally(function(){ setLoading(false); });

        _prLoadLogo(function(url){ setLogoUrl(url); });

        fetch('/nsms/api/settings.php?action=get_public')
            .then(function(r){ return r.json(); })
            .then(function(d){ if (d.success && d.data) setSchName(d.data.school_name || ''); })
            .catch(function(){});
    }, []);

    // Close dropdown on outside click
    useEffect(function(){
        if (!ddOpen) return;
        function onOut(e){
            if (ddRef.current && !ddRef.current.contains(e.target)) setDdOpen(false);
        }
        document.addEventListener('mousedown', onOut);
        return function(){ document.removeEventListener('mousedown', onOut); };
    }, [ddOpen]);

    function handleSignOut() {
        fetch('/nsms/api/parent-panel.php?action=signout')
            .finally(function(){ window.location.href = '/nsms/public/login.html'; });
    }

    var dispName = schName || 'NSMS';
    var hasPhoto = !imgErr && user && user.photo_url;

    // ── Child selector dropdown ───────────────────────────────────────────────
    var kidListSt = useState(false); var kidOpen = kidListSt[0]; var setKidOpen = kidListSt[1];
    var kidRef    = useRef(null);

    useEffect(function(){
        if (!kidOpen) return;
        function onOut(e){ if (kidRef.current && !kidRef.current.contains(e.target)) setKidOpen(false); }
        document.addEventListener('mousedown', onOut);
        return function(){ document.removeEventListener('mousedown', onOut); };
    }, [kidOpen]);

    var userChildren = (user && user.children) ? user.children : children;

    return (
        <>
            <nav className="nsms-navbar">
                {/* Hamburger */}
                <button className="nav-hamburger"
                        onClick={function(){ setSidebar(function(o){ return !o; }); }}
                        title="Toggle sidebar">
                    {sidebarOpen ? '✕' : '☰'}
                </button>

                {/* Brand */}
                <div className="nav-brand">
                    <div className="nav-logo"><PrLogoMark logoUrl={logoUrl} /></div>
                    <div className="nav-school-name">
                        {loading ? (
                            <div>
                                <div className="nav-shimmer" style={{height:13,width:120,marginBottom:4}} />
                                <div className="nav-shimmer" style={{height:9,width:72}} />
                            </div>
                        ) : (
                            <div>
                                <div className="nav-school-title">{dispName}</div>
                                <div className="nav-school-sub">Parent Portal</div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Child selector (show when parent has children) */}
                {userChildren.length > 0 && (
                    <div ref={kidRef} style={{position:'relative',marginLeft:8}}>
                        <button
                            onClick={function(){ setKidOpen(function(o){ return !o; }); }}
                            style={{
                                display:'flex',alignItems:'center',gap:8,
                                background:'rgba(255,255,255,.12)',
                                border:'1px solid rgba(255,255,255,.2)',
                                borderRadius:8,padding:'5px 12px',
                                color:'#fff',fontSize:13,fontWeight:600,cursor:'pointer',
                                transition:'background .2s'
                            }}>
                            <span style={{fontSize:16}}>👦</span>
                            <span>{selectedChild ? selectedChild.student_name : (userChildren[0] && userChildren[0].student_name)}</span>
                            <span style={{fontSize:10,opacity:.8}}>▾</span>
                        </button>
                        {kidOpen && userChildren.length > 1 && (
                            <div style={{
                                position:'absolute',top:'calc(100% + 6px)',left:0,
                                background:'#fff',borderRadius:10,
                                boxShadow:'0 8px 24px rgba(0,0,0,.12)',
                                minWidth:180,zIndex:300,overflow:'hidden'
                            }}>
                                {userChildren.map(function(child){
                                    var isSel = selectedChild && selectedChild.id === child.id;
                                    return (
                                        <button key={child.id}
                                                onClick={function(){
                                                    if (setSelectedChild) setSelectedChild(child);
                                                    setKidOpen(false);
                                                }}
                                                style={{
                                                    display:'flex',alignItems:'center',gap:10,
                                                    width:'100%',padding:'10px 14px',
                                                    background: isSel ? '#EFF6FF' : 'transparent',
                                                    border:'none',cursor:'pointer',textAlign:'left',
                                                    color: isSel ? 'var(--blue)' : 'var(--text-dark)',
                                                    fontSize:13,fontWeight: isSel ? 700 : 500
                                                }}>
                                            <div style={{
                                                width:28,height:28,borderRadius:'50%',
                                                background: isSel ? '#BFDBFE' : '#F1F5F9',
                                                display:'flex',alignItems:'center',justifyContent:'center',
                                                fontSize:14
                                            }}>👦</div>
                                            <div>
                                                <div>{child.student_name}</div>
                                                <div style={{fontSize:11,color:'var(--text-muted)'}}>{child.class_name}</div>
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                )}

                {/* Nav links */}
                <div className="nav-links">
                    {PARENT_NAV_LINKS.map(function(item) {
                        var badge = (item.key === 'messages' && unreadMsg > 0) ? unreadMsg : 0;
                        return (
                            <button key={item.key}
                                    className={'nav-link' + (activePage === item.key ? ' active' : '')}
                                    onClick={function(){ go(item.href); }}
                                    style={{position:'relative'}}>
                                {item.label}
                                {badge > 0 && (
                                    <span style={{
                                        position:'absolute',top:-4,right:-8,
                                        background:'#EF4444',color:'#fff',
                                        borderRadius:'50%',width:16,height:16,
                                        fontSize:10,fontWeight:700,
                                        display:'flex',alignItems:'center',justifyContent:'center'
                                    }}>{badge > 9 ? '9+' : badge}</span>
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* Clock */}
                <PrNavClock />

                {/* Right: bell + profile */}
                <div className="nav-right" style={{gap:8}}>
                    <PrBell />
                    <div className="nav-divider" />
                    <div ref={ddRef} style={{position:'relative'}}>
                        <button className={'nav-user-btn' + (ddOpen ? ' open' : '')}
                                onClick={function(){ setDdOpen(function(o){ return !o; }); }}>
                            <div className="nav-avatar"
                                 style={{background: user ? prAvColor(user.full_name) : '#E2E8F0'}}>
                                {hasPhoto
                                    ? <img src={user.photo_url} alt=""
                                           onError={function(){ setImgErr(true); }} />
                                    : user ? prInitials(user.full_name) : '?'}
                            </div>
                            <div>
                                <div className="nav-user-name">
                                    {loading ? '…' : user ? user.full_name.split(' ')[0] : 'Parent'}
                                </div>
                                <div className="nav-user-role">Parent</div>
                            </div>
                            <span className="nav-chevron">▾</span>
                        </button>

                        {ddOpen && (
                            <div className="nav-dd">
                                <div className="nav-dd-head">
                                    <div className="nav-dd-av"
                                         style={{background: user ? prAvColor(user.full_name) : 'rgba(255,255,255,.2)'}}>
                                        {hasPhoto
                                            ? <img src={user.photo_url} alt="" />
                                            : user ? prInitials(user.full_name) : '?'}
                                    </div>
                                    <div>
                                        <div className="nav-dd-name">{user ? user.full_name : 'Parent'}</div>
                                        <div className="nav-dd-email">{user ? user.email : ''}</div>
                                        <span className="nav-dd-role">🏠 Parent Portal</span>
                                    </div>
                                </div>
                                <div className="nav-dd-body">
                                    <button className="nav-dd-item"
                                            onClick={function(){ setDdOpen(false); setPfOpen(true); }}>
                                        <span className="nav-dd-icon">👤</span> My Profile
                                    </button>
                                    <button className="nav-dd-item"
                                            onClick={function(){ setDdOpen(false); go('/nsms/public/parent/messages.html'); }}>
                                        <span className="nav-dd-icon">💬</span> Messages
                                        {unreadMsg > 0 && (
                                            <span style={{
                                                marginLeft:'auto',background:'#EF4444',color:'#fff',
                                                borderRadius:20,padding:'1px 7px',fontSize:11,fontWeight:700
                                            }}>{unreadMsg}</span>
                                        )}
                                    </button>
                                    <div className="nav-dd-sep" />
                                    <button className="nav-dd-item danger" onClick={handleSignOut}>
                                        <span className="nav-dd-icon">🚪</span> Sign Out
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </nav>

            <ParentProfileModal open={pfOpen} onClose={function(){ setPfOpen(false); }} />
        </>
    );
}

/* ═══════════════════════════════════════════════════════════════
   PARENT SIDEBAR
═══════════════════════════════════════════════════════════════ */
function ParentSidebar(props) {
    var activePage  = props.activePage  || 'dashboard';
    var sidebarOpen = props.sidebarOpen;
    var unreadMsg   = props.unreadMsg   || 0;
    var go          = function(href){ window.location.href = href; };

    var useState = React.useState;
    var useRef   = React.useRef;

    var hoverSt    = useState(false); var isHovered  = hoverSt[0];  var setIsHovered  = hoverSt[1];
    var leaveTimer = useRef(null);

    function handleEnter() {
        if (leaveTimer.current) { clearTimeout(leaveTimer.current); leaveTimer.current = null; }
        setIsHovered(true);
    }
    function handleLeave() {
        leaveTimer.current = setTimeout(function(){ setIsHovered(false); }, 180);
    }

    var isExpanded = sidebarOpen || isHovered;

    return (
        <aside className={'nsms-sidebar' + (isExpanded ? '' : ' collapsed')}
               onMouseEnter={handleEnter}
               onMouseLeave={handleLeave}>
            {PARENT_SIDEBAR_ITEMS.map(function(item) {
                var badge = (item.key === 'messages' && unreadMsg > 0) ? unreadMsg : 0;
                return (
                    <button key={item.key}
                            className={'sb-item' + (activePage === item.key ? ' active' : '')}
                            data-tip={item.label}
                            onClick={function(){ go(item.href); }}>
                        <span className="sb-icon">{item.icon}</span>
                        <span className="sb-label">{item.label}</span>
                        {badge > 0 && (
                            <span className="sb-badge">{badge > 9 ? '9+' : badge}</span>
                        )}
                    </button>
                );
            })}
            <div className="sb-spacer" />
        </aside>
    );
}
