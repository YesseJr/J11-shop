/* ═══════════════════════════════════════════════════════════════
   NSMS TEACHER SHARED COMPONENTS  —  nsms/public/includes/js/teacher-shared.js
   Self-contained — no dependency on nsms-shared.js
   Exposes globals: TeacherNavbar, TeacherSidebar
   Requires: React 18 loaded before this file.
═══════════════════════════════════════════════════════════════ */

/* ── Avatar helpers (duplicated from nsms-shared so this file is standalone) ── */
var TC_AV_COLORS = ['#2563EB','#10B981','#8B5CF6','#F59E0B','#EF4444','#0891B2'];
var tcAvColor    = function(n) { return n ? TC_AV_COLORS[n.charCodeAt(0) % TC_AV_COLORS.length] : '#94A3B8'; };
var tcInitials   = function(n) { return n ? n.split(' ').map(function(w){ return w[0]; }).join('').toUpperCase().slice(0,2) : '?'; };

/* ── Teacher sidebar items ── */
var TEACHER_SIDEBAR_ITEMS = [
    { key: 'dashboard',  icon: '🏠', label: 'Dashboard',   href: '/nsms/public/teacher/dashboard.html'  },
    { key: 'my_class',   icon: '👥', label: 'My Class',    href: '/nsms/public/teacher/my-class.html'   },
    { key: 'attendance', icon: '✅', label: 'Attendance',  href: '/nsms/public/teacher/attendance.html' },
    { key: 'homework',   icon: '✏️',  label: 'Homework',    href: '/nsms/public/teacher/homework.html'   },
    { key: 'gradebook',  icon: '📒', label: 'Gradebook',   href: '/nsms/public/teacher/gradebook.html'  },
    { key: 'reports',    icon: '📋', label: 'Reports',     href: '/nsms/public/teacher/reports.html'    },
    { key: 'pulse', icon: '⚡', label: 'J11 Pulse', href: '/nsms/public/teacher/teacher-pulse.html' },
];

/* ── Teacher navbar links ── */
var TEACHER_NAV_LINKS = [
    { key: 'dashboard',  label: 'Home',       href: '/nsms/public/teacher/dashboard.html'  },
    { key: 'my_class',   label: 'My Class',   href: '/nsms/public/teacher/my-class.html'   },
    { key: 'attendance', label: 'Attendance', href: '/nsms/public/teacher/attendance.html' },
    { key: 'gradebook',  label: 'Gradebook',  href: '/nsms/public/teacher/gradebook.html'  },
    { key: 'reports',    label: 'Reports',    href: '/nsms/public/teacher/reports.html'    },
];

/* ── Module-level logo cache (same pattern as nsms-shared.js) ── */
var _tcLogoCache   = { loaded: false, url: '' };
var _tcLogoWaiters = [];
function _tcLoadLogo(cb) {
    if (_tcLogoCache.loaded) { cb(_tcLogoCache.url); return; }
    _tcLogoWaiters.push(cb);
    if (_tcLogoWaiters.length > 1) return;
    fetch('/nsms/api/settings.php?action=get_public')
        .then(function(r){ return r.json(); })
        .then(function(d){ if (d.success && d.data) _tcLogoCache.url = d.data.school_logo || ''; })
        .catch(function(){})
        .finally(function(){
            _tcLogoCache.loaded = true;
            var waiters = _tcLogoWaiters.slice(); _tcLogoWaiters = [];
            waiters.forEach(function(fn){ fn(_tcLogoCache.url); });
        });
}

/* ── School logo mark ── */
function TcLogoMark(props) {
    var logoUrl = props.logoUrl || '';
    if (logoUrl) {
        return (
            <img src={logoUrl} alt="School Logo"
                 style={{width:'100%',height:'100%',objectFit:'contain',borderRadius:'6px',display:'block'}}
                 onError={function(e){ e.target.style.display='none'; }} />
        );
    }
    return (
        <svg viewBox="0 0 24 24" fill="none">
            <path d="M3 21h18M5 21V7l7-4 7 4v14" stroke="rgba(255,255,255,.7)" strokeWidth="1.5" strokeLinejoin="round"/>
            <rect x="10" y="14" width="4" height="7" rx=".5" fill="rgba(255,255,255,.9)"/>
            <rect x="6.5" y="9.5" width="3" height="3" rx=".5" fill="rgba(255,255,255,.8)"/>
            <rect x="14.5" y="9.5" width="3" height="3" rx=".5" fill="rgba(255,255,255,.8)"/>
        </svg>
    );
}

/* ═══════════════════════════════════════════════════════════════
   LIVE CLOCK  (same as nsms-shared NavClock)
═══════════════════════════════════════════════════════════════ */
function TcNavClock() {
    var useState  = React.useState;
    var useEffect = React.useEffect;

    var nowSt = useState(new Date()); var now = nowSt[0]; var setNow = nowSt[1];
    useEffect(function() {
        var t = setInterval(function(){ setNow(new Date()); }, 1000);
        return function(){ clearInterval(t); };
    }, []);

    function ordinal(n) {
        var s = ['th','st','nd','rd'], v = n % 100;
        return n + (s[(v-20)%10] || s[v] || s[0]);
    }
    var MONTHS = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];
    var dateStr = ordinal(now.getDate()) + ' ' + MONTHS[now.getMonth()] + ' ' + now.getFullYear();
    var hh = String(now.getHours()).padStart(2,'0');
    var mm = String(now.getMinutes()).padStart(2,'0');
    var ss = String(now.getSeconds()).padStart(2,'0');

    return (
        <div className="nav-center">
            <div className="nav-date-block">
                <div className="nav-date-icon">📅</div>
                <span className="nav-date-text">{dateStr}</span>
            </div>
            <div className="nav-center-sep" />
            <div className="nav-time-block">
                <div className="nav-time-icon">🕐</div>
                <span className="nav-time-text">{hh}:{mm}:{ss}</span>
            </div>
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   TEACHER PROFILE MODAL
   Uses /nsms/api/teacher-profile.php instead of admin_profile.php
═══════════════════════════════════════════════════════════════ */
function TeacherProfileModal(props) {
    var open    = props.open;
    var onClose = props.onClose;

    var useState  = React.useState;
    var useEffect = React.useEffect;
    var useRef    = React.useRef;

    var profSt    = useState(null);  var profile   = profSt[0];    var setProfile   = profSt[1];
    var loadSt    = useState(true);  var loading   = loadSt[0];    var setLoading   = loadSt[1];
    var saveSt    = useState(false); var saving    = saveSt[0];    var setSaving    = saveSt[1];
    var alertSt   = useState(null);  var alert     = alertSt[0];   var setAlert     = alertSt[1];
    var editSt    = useState(false); var editMode  = editSt[0];    var setEditMode  = editSt[1];
    var showPwSt  = useState(false); var showPw    = showPwSt[0];  var setShowPw    = showPwSt[1];
    var prevSt    = useState(null);  var preview   = prevSt[0];    var setPreview   = prevSt[1];
    var upSt      = useState(false); var uploading = upSt[0];      var setUploading = upSt[1];
    var photoErrSt= useState(false); var photoErr  = photoErrSt[0];var setPhotoErr  = photoErrSt[1];

    var formSt = useState({ full_name:'', email:'', phone:'' });
    var form   = formSt[0]; var setForm = formSt[1];
    var pwSt   = useState({ current:'', newPw:'', confirm:'' });
    var pw     = pwSt[0];   var setPw   = pwSt[1];

    var fileRef = useRef(null);

    useEffect(function() {
        if (!open) return;
        setLoading(true); setAlert(null); setEditMode(false);
        setShowPw(false); setPreview(null); setPhotoErr(false);
        setPw({ current:'', newPw:'', confirm:'' });

        fetch('/nsms/api/teacher-profile.php?action=get')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setProfile(d.data);
                    setForm({ full_name: d.data.full_name||'', email: d.data.email||'', phone: d.data.phone||'' });
                } else {
                    setAlert({ type:'error', msg: d.error || 'Failed to load profile.' });
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error loading profile.' }); })
            .finally(function(){ setLoading(false); });
    }, [open]);

    useEffect(function() {
        if (!open) return;
        var onKey = function(e){ if (e.key === 'Escape') onClose(); };
        document.addEventListener('keydown', onKey);
        return function(){ document.removeEventListener('keydown', onKey); };
    }, [open]);

    if (!open) return null;

    var user     = profile;
    var hasPhoto = user && user.photo_url && !photoErr;
    var dispPrev = preview || (hasPhoto ? user.photo_url : null);

    function setF(k,v){ setForm(function(f){ var n=Object.assign({},f); n[k]=v; return n; }); }
    function setP(k,v){ setPw(function(p){   var n=Object.assign({},p); n[k]=v; return n; }); }

    function handleFileChange(e) {
        var file = e.target.files[0];
        if (!file) return;
        if (file.size > 3*1024*1024) { setAlert({ type:'error', msg:'Image must be under 3 MB.' }); return; }
        var reader = new FileReader();
        reader.onload = function(ev){ setPreview(ev.target.result); };
        reader.readAsDataURL(file);
    }

    function handleUploadPhoto() {
        var file = fileRef.current && fileRef.current.files[0];
        if (!file) { fileRef.current && fileRef.current.click(); return; }
        setUploading(true); setAlert(null);
        var fd = new FormData();
        fd.append('action', 'upload_photo');
        fd.append('photo', file);
        fetch('/nsms/api/teacher-profile.php', { method:'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) {
                    setAlert({ type:'success', msg:'Photo updated.' });
                    setPhotoErr(false);
                    setProfile(function(p){ return Object.assign({}, p, { photo_url: (d.data && d.data.photo_url) || p.photo_url }); });
                    setPreview(null);
                } else {
                    setAlert({ type:'error', msg: d.error || 'Photo upload failed.' });
                }
            })
            .catch(function(){ setAlert({ type:'error', msg:'Network error uploading photo.' }); })
            .finally(function(){ setUploading(false); });
    }

    function handleSave() {
        if (!form.full_name.trim()) { setAlert({ type:'error', msg:'Full name is required.' }); return; }
        if (!form.email.trim())     { setAlert({ type:'error', msg:'Email is required.' }); return; }

        var body = {
            action: 'update_profile',
            full_name: form.full_name.trim(),
            email: form.email.trim(),
            phone: form.phone.trim()
        };
        if (showPw) {
            if (!pw.current)          { setAlert({ type:'error', msg:'Enter your current password.' }); return; }
            if (!pw.newPw)             { setAlert({ type:'error', msg:'Enter a new password.' }); return; }
            if (pw.newPw.length < 6)   { setAlert({ type:'error', msg:'New password must be at least 6 characters.' }); return; }
            if (pw.newPw !== pw.confirm){ setAlert({ type:'error', msg:'New passwords do not match.' }); return; }
            body.change_password   = true;
            body.current_password  = pw.current;
            body.new_password      = pw.newPw;
            body.confirm_password  = pw.confirm;
        }

        setSaving(true); setAlert(null);
        fetch('/nsms/api/teacher-profile.php', {
            method: 'POST',
            headers: { 'Content-Type':'application/json' },
            body: JSON.stringify(body)
        })
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (d.success) {
                setAlert({ type:'success', msg:'Profile saved.' });
                setProfile(function(p){ return Object.assign({}, p, { full_name: form.full_name, email: form.email, phone: form.phone }); });
                setEditMode(false); setShowPw(false); setPw({ current:'', newPw:'', confirm:'' });
            } else {
                setAlert({ type:'error', msg: d.error || 'Save failed.' });
            }
        })
        .catch(function(){ setAlert({ type:'error', msg:'Network error.' }); })
        .finally(function(){ setSaving(false); });
    }

    return (
        <div className="pf-overlay" onClick={function(e){ if(e.target===e.currentTarget) onClose(); }}>
            <div className="pf-modal">
                <div className="pf-header">
                    <span className="pf-header-title">👤 My Profile</span>
                    <button className="pf-close" onClick={onClose}>✕</button>
                </div>

                <div className="pf-body">
                    {loading ? (
                        <div style={{display:'flex',alignItems:'center',justifyContent:'center',padding:'60px 0'}}>
                            <div className="spinner"></div>
                        </div>
                    ) : (
                        <>
                            {alert && (
                                <div className={'pf-alert ' + (alert.type === 'success' ? 'pf-alert-success' : 'pf-alert-error')}>
                                    <span>{alert.type==='success' ? '✅' : '⚠️'}</span>
                                    <span>{alert.msg}</span>
                                </div>
                            )}

                            {/* Photo */}
                            <div className="pf-photo-section">
                                <div className="pf-photo-ring">
                                    {dispPrev ? (
                                        <img className="pf-photo" src={dispPrev} alt="Profile"
                                             onError={function(){ setPhotoErr(true); }} />
                                    ) : (
                                        <div className="pf-photo-initials"
                                             style={{background: user ? tcAvColor(user.full_name) : '#94A3B8'}}>
                                            {user ? tcInitials(user.full_name) : '?'}
                                        </div>
                                    )}
                                    <button className="pf-photo-btn" title="Change photo"
                                            onClick={function(){ fileRef.current && fileRef.current.click(); }}>📷</button>
                                </div>
                                <input ref={fileRef} type="file" accept="image/*"
                                       style={{display:'none'}} onChange={handleFileChange} />
                                <div className="pf-role-badge">🎓 Teacher</div>
                                {user && user.class_name && (
                                    <div style={{
                                        display:'inline-flex', alignItems:'center', gap:5,
                                        padding:'3px 10px', borderRadius:20,
                                        background: user.class_color || '#2563EB', color:'white',
                                        fontSize:11.5, fontWeight:700
                                    }}>
                                        🏫 {user.class_name}
                                    </div>
                                )}
                                {user && user.subjects && (
                                    <div style={{fontSize:11.5, color:'#64748B', textAlign:'center'}}>
                                        📚 {user.subjects}
                                    </div>
                                )}
                                <div className="pf-photo-change-text">
                                    {preview ? (
                                        <span>
                                            <button onClick={handleUploadPhoto} disabled={uploading}
                                                    style={{color:'#10B981'}}>
                                                {uploading ? 'Uploading…' : '✔ Save this photo'}
                                            </button>
                                            {' · '}
                                            <button onClick={function(){ setPreview(null); if(fileRef.current) fileRef.current.value=''; }}>
                                                Cancel
                                            </button>
                                        </span>
                                    ) : (
                                        <span>
                                            <button onClick={function(){ fileRef.current && fileRef.current.click(); }}>
                                                Click to change photo
                                            </button>
                                            {' (JPG / PNG, max 3 MB)'}
                                        </span>
                                    )}
                                </div>
                            </div>

                            <div className="pf-sep" />

                            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
                                <span style={{fontSize:13,fontWeight:700,color:'var(--text-mid)',textTransform:'uppercase',letterSpacing:'.5px'}}>
                                    Personal Information
                                </span>
                                {!editMode && (
                                    <button onClick={function(){ setEditMode(true); setAlert(null); }}
                                            style={{border:'none',background:'var(--blue-light)',color:'var(--blue)',
                                                   padding:'5px 12px',borderRadius:7,fontSize:12,fontWeight:700,
                                                   cursor:'pointer',fontFamily:'var(--font)'}}>
                                        ✏️ Edit
                                    </button>
                                )}
                            </div>

                            <div className="pf-field">
                                <label className="pf-label">Full Name</label>
                                {editMode
                                    ? <input className="pf-input" value={form.full_name}
                                             onChange={function(e){ setF('full_name', e.target.value); }}
                                             placeholder="Your full name" />
                                    : <div className="pf-input-ro">{user ? user.full_name : '—'}</div>}
                            </div>

                            <div className="pf-row">
                                <div className="pf-field">
                                    <label className="pf-label">Email</label>
                                    {editMode
                                        ? <input className="pf-input" type="email" value={form.email}
                                                 onChange={function(e){ setF('email', e.target.value); }} />
                                        : <div className="pf-input-ro">{user ? user.email : '—'}</div>}
                                </div>
                                <div className="pf-field">
                                    <label className="pf-label">Phone</label>
                                    {editMode
                                        ? <input className="pf-input" type="tel" value={form.phone}
                                                 onChange={function(e){ setF('phone', e.target.value); }}
                                                 placeholder="+255 7xx xxx xxx" />
                                        : <div className="pf-input-ro">{user && user.phone ? user.phone : '—'}</div>}
                                </div>
                            </div>

                            {editMode && (
                                <>
                                    <div className="pf-sep" />
                                    <div className="pf-pw-toggle"
                                         onClick={function(){ setShowPw(function(v){ return !v; }); }}>
                                        <div className={'pf-pw-toggle-icon' + (showPw ? ' checked' : '')}>
                                            {showPw ? '✓' : ''}
                                        </div>
                                        <span className="pf-pw-toggle-label">Change password</span>
                                    </div>
                                    {showPw && (
                                        <div className="pf-pw-section">
                                            <div className="pf-field">
                                                <label className="pf-label">Current Password</label>
                                                <input className="pf-input" type="password" value={pw.current}
                                                       onChange={function(e){ setP('current', e.target.value); }}
                                                       placeholder="Enter current password" />
                                            </div>
                                            <div className="pf-row">
                                                <div className="pf-field">
                                                    <label className="pf-label">New Password</label>
                                                    <input className="pf-input" type="password" value={pw.newPw}
                                                           onChange={function(e){ setP('newPw', e.target.value); }}
                                                           placeholder="Min. 6 characters" />
                                                </div>
                                                <div className="pf-field">
                                                    <label className="pf-label">Confirm Password</label>
                                                    <input className="pf-input" type="password" value={pw.confirm}
                                                           onChange={function(e){ setP('confirm', e.target.value); }}
                                                           placeholder="Repeat new password" />
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </>
                            )}
                        </>
                    )}
                </div>

                <div className="pf-footer">
                    {editMode ? (
                        <>
                            <button className="pf-btn-cancel"
                                    onClick={function(){
                                        setEditMode(false); setAlert(null); setShowPw(false);
                                        setPw({ current:'', newPw:'', confirm:'' });
                                        if (profile) setForm({ full_name: profile.full_name||'', email: profile.email||'', phone: profile.phone||'' });
                                    }}>Cancel</button>
                            <button className="pf-btn-save" onClick={handleSave} disabled={saving}>
                                {saving
                                    ? <><span className="spinner" style={{width:14,height:14,border:'2px solid rgba(255,255,255,.4)',borderTopColor:'white'}}></span> Saving…</>
                                    : '💾 Save Changes'}
                            </button>
                        </>
                    ) : (
                        <button className="pf-btn-cancel" onClick={onClose}>Close</button>
                    )}
                </div>
            </div>
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   NOTIFICATION BELL  —  TcBell
   ┌ Two separate tabs ────────────────────────────────────────┐
   │  💬 Messages  — unread message count, links to inbox      │
   │  📣 Alerts    — real system alert items from DB,          │
   │                 mark-as-read (one or all), timeAgo         │
   └───────────────────────────────────────────────────────────┘
   Sync schedule:
     BELL_POLL_MS  (10 s) — badge counts + silent list refresh
     REMINDER_MS   (5 min) — generate_reminders (DB scan)
   Change BELL_POLL_MS to 3000 for 3-second sync if needed.
═══════════════════════════════════════════════════════════════ */
var BELL_POLL_MS = 10000;   /* badge + silent list refresh — 10 s   */
var REMINDER_MS  = 300000;  /* generate_reminders scan    — 5 min   */

function TcBell() {
    var useState  = React.useState;
    var useEffect = React.useEffect;
    var useRef    = React.useRef;

    // ── state ──────────────────────────────────────────────────
    var countsSt  = useState({ msgs: 0, alerts: 0 });
    var counts    = countsSt[0];  var setCounts    = countsSt[1];

    var openSt    = useState(false);
    var open      = openSt[0];    var setOpen      = openSt[1];

    var tabSt     = useState('alerts');
    var activeTab = tabSt[0];     var setActiveTab = tabSt[1];

    var alertsSt  = useState([]);
    var alerts    = alertsSt[0];  var setAlerts    = alertsSt[1];

    var alLoadSt  = useState(false);
    var alLoading = alLoadSt[0];  var setAlLoading = alLoadSt[1];

    // Bell pulse — fires when unread count increases
    var prevTotalRef = useRef(-1);
    var pulseSt      = useState(false);
    var isPulsing    = pulseSt[0]; var setIsPulsing = pulseSt[1];

    var panelRef = useRef(null);
    /* Single pulse source: only prevTotalRef (in fetchCounts) drives the bell animation.
       prevAlertsRef removed — it caused double-ringing on every new alert (one pulse
       from fetchCounts total increase, a second from the old silentRefreshAlerts path). */

    // ── helpers ────────────────────────────────────────────────
    function timeAgo(ts) {
        if (!ts) return '';
        var d    = new Date(ts.replace(' ', 'T'));
        var diff = Math.floor((Date.now() - d.getTime()) / 1000);
        if (diff < 60)    return 'Just now';
        if (diff < 3600)  return Math.floor(diff / 60)   + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        return Math.floor(diff / 86400) + 'd ago';
    }

    function alertIcon(type) {
        var MAP = {
            'class_assignment'  : '🏫',
            'subject_assignment': '📚',
            'new_student'       : '🎒',
            'transfer_out'      : '↩️',
            'admin_message'     : '📩',
            'system'            : '⚙️',
            'announcement'      : '📢',
            'exam_reminder'     : '📝',
            'homework_deadline' : '✏️',
            'attendance_issue'  : '⚠️',
            'info'              : '📣',
        };
        return MAP[type] || '📣';
    }

    // Per-type colour tints — unread rows glow their category colour
    function alertColors(type, unread) {
        if (!unread) return { bg:'#FAFBFC', border:'#F1F5F9', iconBg:'#F1F5F9' };
        var T = {
            'class_assignment'  : { bg:'#EFF6FF', border:'#BFDBFE', iconBg:'#DBEAFE' },
            'subject_assignment': { bg:'#F5F3FF', border:'#DDD6FE', iconBg:'#EDE9FE' },
            'new_student'       : { bg:'#F0FDF4', border:'#BBF7D0', iconBg:'#DCFCE7' },
            'transfer_out'      : { bg:'#F0FDF4', border:'#BBF7D0', iconBg:'#DCFCE7' },
            'exam_reminder'     : { bg:'#FFF7ED', border:'#FED7AA', iconBg:'#FFEDD5' },
            'homework_deadline' : { bg:'#FFFBEB', border:'#FDE68A', iconBg:'#FEF3C7' },
            'attendance_issue'  : { bg:'#FFF1F2', border:'#FECDD3', iconBg:'#FFE4E6' },
            'announcement'      : { bg:'#F0F9FF', border:'#BAE6FD', iconBg:'#E0F2FE' },
        };
        return T[type] || { bg:'#FFFBEB', border:'#FDE68A', iconBg:'#FEF3C7' };
    }

    // ── API calls ──────────────────────────────────────────────

    // Lightweight — two COUNT queries. Safe to call on every fast tick.
    function fetchCounts() {
        fetch('/nsms/api/teacher.php?action=notifications_count')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (!d.success) return;
                var nm  = d.data.messages      || 0;
                var na  = d.data.notifications || 0;
                var tot = nm + na;
                // Pulse bell when count goes up
                if (tot > prevTotalRef.current && prevTotalRef.current !== -1) {
                    setIsPulsing(true);
                    setTimeout(function(){ setIsPulsing(false); }, 820);
                }
                prevTotalRef.current = tot;
                setCounts({ msgs: nm, alerts: na });
            })
            .catch(function(){});
    }

    /* Notification types that belong to the Messages tab only.
       Exclude them from the Alerts tab and alerts badge entirely. */
    var MSG_TYPES = ['admin_message', 'teacher_message', 'parent_message'];

    // Heavy — generate_reminders first, then full list. Shows shimmer.
    // Only called on first panel open and on the slow reminder cycle.
    function fetchAlerts() {
        setAlLoading(true);
        fetch('/nsms/api/teacher.php?action=generate_reminders')
            .catch(function(){})
            .finally(function() {
                fetch('/nsms/api/teacher.php?action=notifications')
                    .then(function(r){ return r.json(); })
                    .then(function(d){
                        if (d.success) {
                            var raw        = d.data || [];
                            var alertsList = raw.filter(function(a){ return MSG_TYPES.indexOf(a.type) === -1; });
                            setAlerts(alertsList);
                            var unread = alertsList.filter(function(a){ return !a.is_read || a.is_read == 0; }).length;
                            setCounts(function(c){ return Object.assign({}, c, { alerts: unread }); });
                            fetchCounts(); // sync messages badge after generation
                        }
                    })
                    .catch(function(){})
                    .finally(function(){ setAlLoading(false); });
            });
    }

    // Lightweight — list only, no shimmer. Runs on the fast tick always (panel open or closed).
    // Derives unread alert count from the FILTERED list (message types excluded).
    // Pulse is handled solely by fetchCounts via prevTotalRef — no independent pulse here.
    function silentRefreshAlerts() {
        fetch('/nsms/api/teacher.php?action=notifications')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (!d.success) return;
                var raw        = d.data || [];
                var alertsList = raw.filter(function(a){ return MSG_TYPES.indexOf(a.type) === -1; });
                setAlerts(alertsList);
                var unread = alertsList.filter(function(a){ return !a.is_read || a.is_read == 0; }).length;
                setCounts(function(c){ return Object.assign({}, c, { alerts: unread }); });
            })
            .catch(function(){});
    }

    function markRead(id) {
        fetch('/nsms/api/teacher.php?action=mark_notifications_read', {
            method : 'POST',
            headers: { 'Content-Type': 'application/json' },
            body   : JSON.stringify({ id: id })
        })
        .then(function(){
            setAlerts(function(prev){
                return prev.map(function(a){
                    return (id === 0 || a.id === id)
                        ? Object.assign({}, a, { is_read: 1 }) : a;
                });
            });
            setCounts(function(c){
                var newAlerts = id === 0 ? 0 : Math.max(0, c.alerts - 1);
                return Object.assign({}, c, { alerts: newAlerts });
            });
        })
        .catch(function(){});
    }

    // ── effects ────────────────────────────────────────────────

    // Mount: run generate_reminders once, then start dual-interval polling.
    // -1 sentinel prevents a false pulse on the very first load.
    useEffect(function() {
        prevTotalRef.current = -1;
        fetch('/nsms/api/teacher.php?action=generate_reminders')
            .catch(function(){})
            .finally(function(){
                fetchCounts();
                silentRefreshAlerts(); // init alert badge from list on mount
            });

        // Fast tick: refresh both message count and alert list every BELL_POLL_MS
        var fastT = setInterval(function(){
            fetchCounts();
            silentRefreshAlerts();
        }, BELL_POLL_MS);
        // Slow tick: re-run generate_reminders every 5 min to catch reminder events
        var slowT = setInterval(function() {
            fetch('/nsms/api/teacher.php?action=generate_reminders')
                .catch(function(){})
                .finally(fetchCounts);
        }, REMINDER_MS);

        return function(){ clearInterval(fastT); clearInterval(slowT); };
    }, []);

    // Panel open: full alert load (with shimmer). The fast tick already keeps the
    // list + badge fresh every BELL_POLL_MS so no extra interval is needed here.
    useEffect(function() {
        if (!open) return;
        fetchAlerts();
        var close = function(e){
            if (panelRef.current && !panelRef.current.contains(e.target)) setOpen(false);
        };
        document.addEventListener('mousedown', close);
        return function(){
            document.removeEventListener('mousedown', close);
        };
    }, [open]);

    // ── derived ────────────────────────────────────────────────
    var total    = counts.msgs + counts.alerts;
    var badgeNum = total > 99 ? '99+' : total;

    // ── render ─────────────────────────────────────────────────
    return (
        <div ref={panelRef} style={{ position:'relative', display:'flex', alignItems:'center' }}>

            {/* Bell pulse keyframes */}
            <style>{'\
                @keyframes bellPulse {\
                    0%   { transform: rotate(0deg)   scale(1);    }\
                    15%  { transform: rotate(-18deg) scale(1.18); }\
                    30%  { transform: rotate(14deg)  scale(1.18); }\
                    45%  { transform: rotate(-10deg) scale(1.12); }\
                    60%  { transform: rotate(8deg)   scale(1.08); }\
                    75%  { transform: rotate(-4deg)  scale(1.04); }\
                    100% { transform: rotate(0deg)   scale(1);    }\
                }\
            '}</style>

            {/* ── Bell button ── */}
            <button
                onClick={function(){ setOpen(function(o){ return !o; }); }}
                style={{
                    position:'relative', width:40, height:40, borderRadius:9,
                    border:'none', background: open ? 'var(--blue-light)' : 'none',
                    cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:20, transition:'background .15s', flexShrink:0
                }}
                title="Notifications"
            >
                <span style={{
                    display:'inline-block', transformOrigin:'50% 10%',
                    animation: isPulsing ? 'bellPulse .82s ease' : 'none'
                }}>🔔</span>
                {total > 0 && (
                    <span style={{
                        position:'absolute', top:3, right:3,
                        minWidth:16, height:16, borderRadius:8,
                        background:'#EF4444', color:'white',
                        fontSize:9, fontWeight:800, lineHeight:'16px',
                        textAlign:'center', padding:'0 3px',
                        border:'1.5px solid white', fontFamily:'var(--font)'
                    }}>{badgeNum}</span>
                )}
            </button>

            {/* ── Drop-down panel ── */}
            {open && (
                <div style={{
                    position:'absolute', top:'calc(var(--nav-h) + 4px)', right:0,
                    background:'white', border:'1px solid var(--border)',
                    borderRadius:14, boxShadow:'0 12px 40px rgba(0,0,0,.15)',
                    width:330, overflow:'hidden', zIndex:1100,
                    animation:'navDrop .18s ease'
                }}>

                    {/* ── Header + tabs ── */}
                    <div style={{ background:'linear-gradient(135deg,#2563EB,#1E40AF)', padding:'14px 16px 0' }}>
                        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
                            <span style={{ fontSize:13, fontWeight:700, color:'white' }}>🔔 Notifications</span>
                            {total > 0 && (
                                <span style={{
                                    background:'rgba(255,255,255,.22)', color:'white',
                                    fontSize:11, fontWeight:700, padding:'2px 8px', borderRadius:20
                                }}>{total} unread</span>
                            )}
                        </div>
                        <div style={{ display:'flex', gap:4 }}>
                            {[
                                { id:'messages', label:'💬 Messages', badge: counts.msgs   },
                                { id:'alerts',   label:'📣 Alerts',   badge: counts.alerts }
                            ].map(function(tab) {
                                var isActive = activeTab === tab.id;
                                return (
                                    <button key={tab.id} onClick={function(){ setActiveTab(tab.id); }}
                                        style={{
                                            flex:1, padding:'8px 6px', borderRadius:'8px 8px 0 0',
                                            border:'none', cursor:'pointer', fontSize:12.5, fontWeight:700,
                                            display:'flex', alignItems:'center', justifyContent:'center', gap:5,
                                            background : isActive ? 'white' : 'rgba(255,255,255,.16)',
                                            color      : isActive ? '#1E40AF' : 'rgba(255,255,255,.88)',
                                            transition :'all .15s', fontFamily:'var(--font)'
                                        }}>
                                        {tab.label}
                                        {tab.badge > 0 && (
                                            <span style={{
                                                background  : isActive ? '#EF4444' : 'rgba(255,255,255,.28)',
                                                color:'white', fontSize:10, fontWeight:800,
                                                padding:'1px 5px', borderRadius:10,
                                                minWidth:16, textAlign:'center'
                                            }}>{tab.badge}</span>
                                        )}
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* ── Tab body ── */}
                    <div style={{ maxHeight:360, overflowY:'auto' }}>

                        {/* Messages tab */}
                        {activeTab === 'messages' && (
                            <div style={{ padding:'12px 10px' }}>
                                <a href="/nsms/public/teacher/teacher-pulse.html"
                                   style={{
                                       display:'flex', alignItems:'center', gap:12,
                                       padding:'13px 14px', borderRadius:11,
                                       background : counts.msgs > 0 ? '#F0F9FF' : '#FAFBFC',
                                       border     : counts.msgs > 0 ? '1.5px solid #BFDBFE' : '1.5px solid #F1F5F9',
                                       color:'var(--text-mid)', textDecoration:'none', transition:'background .15s'
                                   }}
                                   onMouseOver={function(e){ e.currentTarget.style.background='#EFF6FF'; }}
                                   onMouseOut={function(e){ e.currentTarget.style.background=counts.msgs>0?'#F0F9FF':'#FAFBFC'; }}>
                                    <span style={{ fontSize:28 }}>💬</span>
                                    <div style={{ flex:1 }}>
                                        <div style={{ fontSize:13.5, fontWeight:700, color:'var(--text-dark)' }}>Messages</div>
                                        <div style={{ fontSize:12, color:'var(--text-muted)', marginTop:2 }}>
                                            {counts.msgs > 0
                                                ? counts.msgs + ' unread message' + (counts.msgs > 1 ? 's' : '')
                                                : 'No unread messages'}
                                        </div>
                                    </div>
                                    {counts.msgs > 0 && (
                                        <span style={{
                                            background:'#2563EB', color:'white',
                                            fontSize:12, fontWeight:800, padding:'3px 10px', borderRadius:20
                                        }}>{counts.msgs}</span>
                                    )}
                                </a>
                                {counts.msgs === 0 && (
                                    <div style={{ textAlign:'center', padding:'18px 0 10px', color:'var(--text-muted)', fontSize:12.5 }}>
                                        <div style={{ fontSize:26, marginBottom:5 }}>✅</div>
                                        All messages read
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Alerts tab */}
                        {activeTab === 'alerts' && (
                            <div>
                                {alLoading ? (
                                    <div style={{ padding:'14px 12px', display:'flex', flexDirection:'column', gap:8 }}>
                                        {[1,2,3].map(function(i){
                                            return (
                                                <div key={i} style={{
                                                    height:60, borderRadius:10,
                                                    background:'linear-gradient(90deg,#F1F5F9 25%,#E9EEF3 50%,#F1F5F9 75%)',
                                                    backgroundSize:'200% 100%', animation:'shim 1.4s infinite'
                                                }}></div>
                                            );
                                        })}
                                    </div>
                                ) : alerts.length === 0 ? (
                                    <div style={{ textAlign:'center', padding:'32px 0', color:'var(--text-muted)', fontSize:12.5 }}>
                                        <div style={{ fontSize:28, marginBottom:6 }}>📭</div>
                                        No system alerts
                                    </div>
                                ) : (
                                    <>
                                        {counts.alerts > 0 && (
                                            <div style={{ display:'flex', justifyContent:'flex-end', padding:'8px 14px 2px' }}>
                                                <button onClick={function(){ markRead(0); }}
                                                    style={{
                                                        border:'none', background:'none', color:'var(--blue)',
                                                        fontSize:11.5, fontWeight:700, cursor:'pointer',
                                                        fontFamily:'var(--font)', padding:'2px 6px', borderRadius:5
                                                    }}>✓ Mark all read</button>
                                            </div>
                                        )}
                                        <div style={{ padding:'4px 10px 10px' }}>
                                            {alerts.map(function(al) {
                                                var unread = !al.is_read || al.is_read == 0;
                                                var clr    = alertColors(al.type, unread);
                                                return (
                                                    <div key={al.id} style={{
                                                        display:'flex', gap:10,
                                                        padding:'11px 12px', borderRadius:11, marginBottom:7,
                                                        background: clr.bg,
                                                        border    : '1.5px solid ' + clr.border,
                                                        transition:'background .15s, border-color .15s'
                                                    }}>
                                                        <div style={{
                                                            width:34, height:34, borderRadius:9, flexShrink:0,
                                                            background: clr.iconBg,
                                                            display:'flex', alignItems:'center',
                                                            justifyContent:'center', fontSize:17
                                                        }}>{alertIcon(al.type)}</div>
                                                        <div style={{ flex:1, minWidth:0 }}>
                                                            <div style={{
                                                                fontSize:13, fontWeight: unread ? 700 : 600,
                                                                color:'var(--text-dark)',
                                                                whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'
                                                            }}>{al.title || 'System Alert'}</div>
                                                            <div style={{
                                                                fontSize:11.5, color:'var(--text-soft)',
                                                                marginTop:2, lineHeight:1.4,
                                                                display:'-webkit-box', WebkitLineClamp:2,
                                                                WebkitBoxOrient:'vertical', overflow:'hidden'
                                                            }}>{al.message}</div>
                                                            <div style={{ fontSize:10.5, color:'var(--text-muted)', marginTop:5 }}>
                                                                {timeAgo(al.created_at)}
                                                            </div>
                                                        </div>
                                                        {unread && (
                                                            <button onClick={function(){ markRead(al.id); }}
                                                                title="Mark as read"
                                                                style={{
                                                                    border:'none', background:'none', cursor:'pointer',
                                                                    padding:'2px 4px', color:'#94A3B8', fontSize:14,
                                                                    alignSelf:'flex-start', flexShrink:0,
                                                                    fontFamily:'var(--font)', lineHeight:1
                                                                }}>✕</button>
                                                        )}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </>
                                )}
                            </div>
                        )}
                    </div>{/* /tab body */}

                    {/* ── Footer ── */}
                    <div style={{ borderTop:'1px solid var(--border)', padding:'8px 10px', background:'#FAFBFC' }}>
                        {activeTab === 'messages' ? (
                            <a href="/nsms/public/teacher/teacher-pulse.html"
                               style={{
                                   display:'block', textAlign:'center', padding:'8px', borderRadius:7,
                                   color:'var(--blue)', fontSize:12, fontWeight:700,
                                   textDecoration:'none', transition:'background .15s'
                               }}
                               onMouseOver={function(e){ e.currentTarget.style.background='var(--blue-light)'; }}
                               onMouseOut={function(e){ e.currentTarget.style.background='none'; }}>
                                Open J11 Pulse →
                            </a>
                        ) : (
                            counts.alerts > 0 ? (
                                <button onClick={function(){ markRead(0); }}
                                    style={{
                                        display:'block', width:'100%', textAlign:'center',
                                        padding:'8px', borderRadius:7, border:'none',
                                        background:'none', color:'var(--blue)',
                                        fontSize:12, fontWeight:700, cursor:'pointer',
                                        transition:'background .15s', fontFamily:'var(--font)'
                                    }}
                                    onMouseOver={function(e){ e.currentTarget.style.background='var(--blue-light)'; }}
                                    onMouseOut={function(e){ e.currentTarget.style.background='none'; }}>
                                    ✓ Mark all alerts as read
                                </button>
                            ) : (
                                <div style={{ textAlign:'center', padding:'6px 0', color:'var(--text-muted)', fontSize:12, fontWeight:600 }}>
                                    ✅ All caught up
                                </div>
                            )
                        )}
                    </div>

                </div>
            )}{/* /open */}
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   TEACHER NAVBAR
   Layout: [toggle][brand] | [nav links] [clock] [bell][profile]
═══════════════════════════════════════════════════════════════ */
function TeacherNavbar(props) {
    var activePage     = props.activePage     || 'dashboard';
    var sidebarOpen    = props.sidebarOpen;
    var setSidebarOpen = props.setSidebarOpen;
    var schoolName     = props.schoolName     || '';

    var useState  = React.useState;
    var useEffect = React.useEffect;
    var useRef    = React.useRef;

    var userSt   = useState(null);  var user    = userSt[0];   var setUser    = userSt[1];
    var loadSt   = useState(true);  var loading = loadSt[0];   var setLoading = loadSt[1];
    var ddSt     = useState(false); var ddOpen  = ddSt[0];     var setDdOpen  = ddSt[1];
    var imgErrSt = useState(false); var imgErr  = imgErrSt[0]; var setImgErr  = imgErrSt[1];
    var pfSt     = useState(false); var pfOpen  = pfSt[0];     var setPfOpen  = pfSt[1];
    var logoSt   = useState('');    var logoUrl = logoSt[0];   var setLogoUrl = logoSt[1];
    var schNameSt= useState('');    var schName = schNameSt[0];var setSchName = schNameSt[1];
    var ddRef    = useRef(null);

    // Fetch teacher session data (name, photo, class)
    useEffect(function() {
        fetch('/nsms/api/teacher.php?action=session')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success) setUser(d.data);
            })
            .catch(function(){})
            .finally(function(){ setLoading(false); });
    }, []);

    // Fetch school logo + name
    useEffect(function() {
        _tcLoadLogo(function(url){ setLogoUrl(url); });
        fetch('/nsms/api/settings.php?action=get_public')
            .then(function(r){ return r.json(); })
            .then(function(d){ if (d.success && d.data) setSchName(d.data.school_name || ''); })
            .catch(function(){});
    }, []);

    // Close dropdown on outside click
    useEffect(function() {
        if (!ddOpen) return;
        var close = function(e){
            if (ddRef.current && !ddRef.current.contains(e.target)) setDdOpen(false);
        };
        document.addEventListener('mousedown', close);
        return function(){ document.removeEventListener('mousedown', close); };
    }, [ddOpen]);

    function go(href){ window.location.href = href; }

    var hasPhoto = user && user.photo_url && !imgErr;
    var dispName = schoolName || schName || 'Our School';

    // Sign out
    function handleSignOut() {
        setDdOpen(false);
        fetch('/nsms/api/auth.php?action=logout', { method:'POST' })
            .catch(function(){})
            .finally(function(){
                window.location.href = '/nsms/public/index.html';
            });
    }

    return (
        <>
            <nav className="nsms-nav">
                {/* Hamburger */}
                <button className="nav-toggle"
                        onClick={function(){ setSidebarOpen(function(o){ return !o; }); }}
                        title="Toggle sidebar">
                    {sidebarOpen ? '✕' : '☰'}
                </button>

                {/* Brand */}
                <div className="nav-brand">
                    <div className="nav-logo">
                        <TcLogoMark logoUrl={logoUrl} />
                    </div>
                    <div className="nav-school-name">
                        {loading ? (
                            <div>
                                <div className="nav-shimmer" style={{height:13,width:120,marginBottom:4}} />
                                <div className="nav-shimmer" style={{height:9,width:72}} />
                            </div>
                        ) : (
                            <div>
                                <div className="nav-school-title">{dispName}</div>
                                <div className="nav-school-sub">Teacher Panel</div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Nav links */}
                <div className="nav-links">
                    {TEACHER_NAV_LINKS.map(function(item) {
                        return (
                            <button key={item.key}
                                    className={'nav-link' + (activePage === item.key ? ' active' : '')}
                                    onClick={function(){ go(item.href); }}>
                                {item.label}
                            </button>
                        );
                    })}
                </div>

                {/* Clock */}
                <TcNavClock />

                {/* Right: bell + profile */}
                <div className="nav-right" style={{gap:8}}>

                    {/* Notification bell */}
                    <TcBell />

                    {/* Divider */}
                    <div className="nav-divider" />

                    {/* Profile dropdown */}
                    <div ref={ddRef} style={{position:'relative'}}>
                        <button className={'nav-user-btn' + (ddOpen ? ' open' : '')}
                                onClick={function(){ setDdOpen(function(o){ return !o; }); }}>
                            <div className="nav-avatar"
                                 style={{background: user ? tcAvColor(user.full_name) : '#E2E8F0'}}>
                                {hasPhoto
                                    ? <img src={user.photo_url} alt=""
                                           onError={function(){ setImgErr(true); }} />
                                    : user ? tcInitials(user.full_name) : '?'}
                            </div>
                            <div>
                                <div className="nav-user-name">
                                    {loading ? '…' : user ? user.full_name.split(' ')[0] : 'Teacher'}
                                </div>
                                <div className="nav-user-role">
                                    {user && user.class_name ? user.class_name : 'Teacher'}
                                </div>
                            </div>
                            <span className="nav-chevron">▾</span>
                        </button>

                        {ddOpen && (
                            <div className="nav-dd">
                                {/* Dropdown header with teacher info */}
                                <div className="nav-dd-head">
                                    <div className="nav-dd-av"
                                         style={{background: user ? tcAvColor(user.full_name) : 'rgba(255,255,255,.2)'}}>
                                        {hasPhoto
                                            ? <img src={user.photo_url} alt="" />
                                            : user ? tcInitials(user.full_name) : '?'}
                                    </div>
                                    <div>
                                        <div className="nav-dd-name">{user ? user.full_name : 'Teacher'}</div>
                                        <div className="nav-dd-email">{user ? user.email : ''}</div>
                                        <span className="nav-dd-role">
                                            {user && user.class_name ? '🏫 ' + user.class_name : 'Teacher'}
                                        </span>
                                    </div>
                                </div>

                                <div className="nav-dd-body">
                                    <button className="nav-dd-item"
                                            onClick={function(){ setDdOpen(false); setPfOpen(true); }}>
                                        <span className="nav-dd-icon">👤</span> My Profile
                                    </button>
                                    <button className="nav-dd-item"
                                            onClick={function(){ setDdOpen(false); go('/nsms/public/teacher/teacher-pulse.html'); }}>
                                        <span className="nav-dd-icon">💬</span> Messages
                                    </button>
                                    <div className="nav-dd-sep" />
                                    <button className="nav-dd-item danger" onClick={handleSignOut}>
                                        <span className="nav-dd-icon">🚪</span> Sign Out
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </nav>

            {/* Teacher profile modal */}
            <TeacherProfileModal open={pfOpen} onClose={function(){ setPfOpen(false); }} />
        </>
    );
}

/* ═══════════════════════════════════════════════════════════════
   TEACHER SIDEBAR
   Behaviour:
     • Collapsed by default (parent pages should init sidebarOpen=false)
     • Hover over sidebar → temporarily expands (hover state, internal)
     • Toggle button (☰ / ✕) in navbar → pin expanded / unpin (sidebarOpen prop)
     • Small debounce (180 ms) on mouse-leave so accidental micro-exits don't flicker
═══════════════════════════════════════════════════════════════ */
function TeacherSidebar(props) {
    var activePage  = props.activePage  || 'dashboard';
    var sidebarOpen = props.sidebarOpen; // true = pinned-open by user toggle
    var go          = function(href){ window.location.href = href; };

    var useState = React.useState;
    var useRef   = React.useRef;

    var hoverSt   = useState(false); var isHovered   = hoverSt[0];  var setIsHovered  = hoverSt[1];
    var leaveTimer = useRef(null);

    function handleEnter() {
        if (leaveTimer.current) { clearTimeout(leaveTimer.current); leaveTimer.current = null; }
        setIsHovered(true);
    }
    function handleLeave() {
        leaveTimer.current = setTimeout(function(){ setIsHovered(false); }, 180);
    }

    var isExpanded = sidebarOpen || isHovered;

    return (
        <aside
            className={'nsms-sidebar' + (isExpanded ? '' : ' collapsed')}
            onMouseEnter={handleEnter}
            onMouseLeave={handleLeave}
        >
            {TEACHER_SIDEBAR_ITEMS.map(function(item) {
                return (
                    <button key={item.key}
                            className={'sb-item' + (activePage === item.key ? ' active' : '')}
                            data-tip={item.label}
                            onClick={function(){ go(item.href); }}>
                        <span className="sb-icon">{item.icon}</span>
                        <span className="sb-label">{item.label}</span>
                    </button>
                );
            })}
            <div className="sb-spacer" />
        </aside>
    );
}
