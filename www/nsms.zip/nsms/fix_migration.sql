-- ================================================================
-- NSMS Fix Migration — Toleo la Uhakika (Stored Procedure Approach)
-- Salama 100% kuendesha mara nyingi bila kutoa kosa lolote (#1060).
-- ================================================================

DELIMITER $$

CREATE PROCEDURE IF NOT EXISTS `run_nsms_safe_migration`()
BEGIN
    -- ------------------------------------------------------------
    -- FIX 1: messages.reply_to_id
    -- ------------------------------------------------------------
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'messages' AND COLUMN_NAME = 'reply_to_id'
    ) THEN
        ALTER TABLE `messages` ADD COLUMN `reply_to_id` INT NULL DEFAULT NULL;
        ALTER TABLE `messages` ADD INDEX `idx_msg_reply` (`reply_to_id`);
    END IF;

    -- ------------------------------------------------------------
    -- FIX 2: notifications.type ENUM
    -- ------------------------------------------------------------
    ALTER TABLE `notifications` MODIFY COLUMN `type` ENUM('attendance','homework','fee','announcement','report','message','payment') NOT NULL;

    -- ------------------------------------------------------------
    -- FIX 3: typing_status (target_id & is_typing)
    -- ------------------------------------------------------------
    -- A: Ongeza target_id kama haipo
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'typing_status' AND COLUMN_NAME = 'target_id'
    ) THEN
        ALTER TABLE `typing_status` ADD COLUMN `target_id` INT NULL DEFAULT NULL;
    END IF;

    -- B: Ongeza is_typing kama haipo
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'typing_status' AND COLUMN_NAME = 'is_typing'
    ) THEN
        ALTER TABLE `typing_status` ADD COLUMN `is_typing` TINYINT(1) NOT NULL DEFAULT 0;
    END IF;

    -- C: Sawazisha data kwa usalama
    UPDATE `typing_status` 
    SET `target_id` = `contact_id` 
    WHERE (`target_id` IS NULL OR `target_id` = 0) AND `contact_id` != 0;

    -- D: Weka kizuizi cha NOT NULL sasa hivi kwa usalama
    ALTER TABLE `typing_status` MODIFY COLUMN `target_id` INT NOT NULL;

END $$

DELIMITER ;

-- Run the procedure to execute the migration
CALL `run_nsms_safe_migration`();

-- Clean up and drop the procedure after execution
DROP PROCEDURE IF EXISTS `run_nsms_safe_migration`;


-- ================================================================
-- SEHEMU YA PILI: VIEWS NA TABLES (Haziitaji Stored Procedure)
-- ================================================================

-- ── FIX 4: class_teachers compatibility view ────────────────────
CREATE OR REPLACE VIEW `class_teachers` AS 
SELECT `id` AS `class_id`, `teacher_id` 
FROM `classes` 
WHERE `teacher_id` IS NOT NULL;

-- ── FIX 5: student_parents compatibility view ───────────────────
CREATE OR REPLACE VIEW `student_parents` AS 
SELECT `student_id`, `user_id` AS `parent_id` 
FROM `parents`;

-- ── FIX 6: group_resources table ─────────────────────────────────
CREATE TABLE IF NOT EXISTS `group_resources` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `group_id` INT NOT NULL,
  `uploaded_by` INT NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `description` TEXT,
  `stored_name` VARCHAR(255),
  `original_name` VARCHAR(255),
  `mime_type` VARCHAR(120),
  `file_size` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_gr_group` (`group_id`),
  INDEX `idx_gr_user` (`uploaded_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;