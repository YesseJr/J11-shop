<?php
declare(strict_types=1);

// ============================================================================
//  J11 TECHNOLOGIES  —  LARAGON CONTROL DECK
//  Local development environment dashboard with live system telemetry.
// ============================================================================

function h($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$isLocal = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);

function execAllowed(): bool {
    if (!function_exists('exec')) return false;
    $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));
    return !in_array('exec', $disabled, true);
}

function safeExec(string $cmd): ?array {
    if (!execAllowed()) return null;
    $output = [];
    $returnCode = 0;
    @exec($cmd . ' 2>NUL', $output, $returnCode);
    return $output ?: null;
}

function wmicValue(array $lines, string $key): ?string {
    foreach ($lines as $line) {
        if (stripos($line, $key . '=') === 0) {
            $val = trim(substr($line, strlen($key) + 1));
            return $val === '' ? null : $val;
        }
    }
    return null;
}

function getOsDetails(): array {
    $family = PHP_OS_FAMILY;
    $details = [
        'family'  => $family,
        'name'    => php_uname('s'),
        'version' => null,
        'build'   => null,
        'arch'    => php_uname('m'),
        'exact'   => null,
    ];

    if ($family === 'Windows') {
        $out = safeExec('wmic os get Caption,Version,BuildNumber,OSArchitecture /value');
        if ($out) {
            $details['name']    = wmicValue($out, 'Caption') ?? $details['name'];
            $details['version'] = wmicValue($out, 'Version');
            $details['build']   = wmicValue($out, 'BuildNumber');
            $details['arch']    = wmicValue($out, 'OSArchitecture') ?? $details['arch'];
        }
        if ($details['version']) {
            $details['exact'] = $details['version'] . ($details['build'] ? " (Build {$details['build']})" : '');
        }
    } elseif (is_readable('/etc/os-release')) {
        $parsed = @parse_ini_file('/etc/os-release');
        if ($parsed && !empty($parsed['PRETTY_NAME'])) {
            $details['name'] = $parsed['PRETTY_NAME'];
        }
        $details['version'] = php_uname('r');
        $details['exact']   = php_uname('r');
    } else {
        $details['version'] = php_uname('r');
        $details['exact']   = php_uname('r');
    }

    return $details;
}

function getCpuUsage(): ?int {
    if (PHP_OS_FAMILY === 'Windows') {
        $out = safeExec('wmic cpu get loadpercentage /value');
        if ($out) {
            $v = wmicValue($out, 'LoadPercentage');
            if ($v !== null) return (int) $v;
        }
        return null;
    }
    if (function_exists('sys_getloadavg')) {
        $load  = sys_getloadavg();
        $nproc = safeExec('nproc');
        $cores = $nproc ? (int) $nproc[0] : 1;
        if ($load && $cores > 0) return (int) min(100, round(($load[0] / $cores) * 100));
    }
    return null;
}

function getMemoryUsage(): ?array {
    if (PHP_OS_FAMILY === 'Windows') {
        $out = safeExec('wmic OS get FreePhysicalMemory,TotalVisibleMemorySize /value');
        if ($out) {
            $free  = wmicValue($out, 'FreePhysicalMemory');
            $total = wmicValue($out, 'TotalVisibleMemorySize');
            if ($free !== null && $total !== null && (float) $total > 0) {
                $freeF = (float) $free;
                $totalF = (float) $total;
                return [
                    'total_gb' => round($totalF / 1048576, 1),
                    'free_gb'  => round($freeF / 1048576, 1),
                    'used_pct' => (int) round((($totalF - $freeF) / $totalF) * 100),
                ];
            }
        }
        return null;
    }
    if (is_readable('/proc/meminfo')) {
        $meminfo = file_get_contents('/proc/meminfo');
        preg_match('/MemTotal:\s+(\d+)/', $meminfo, $mt);
        preg_match('/MemAvailable:\s+(\d+)/', $meminfo, $ma);
        if ($mt && $ma) {
            $total = (float) $mt[1];
            $avail = (float) $ma[1];
            return [
                'total_gb' => round($total / 1048576, 1),
                'free_gb'  => round($avail / 1048576, 1),
                'used_pct' => (int) round((($total - $avail) / $total) * 100),
            ];
        }
    }
    return null;
}

function getUptime(): ?string {
    if (PHP_OS_FAMILY === 'Windows') {
        $out = safeExec('wmic OS get LastBootUpTime /value');
        if ($out) {
            $raw = wmicValue($out, 'LastBootUpTime');
            if ($raw) {
                $stamp = substr($raw, 0, 14);
                $boot = DateTime::createFromFormat('YmdHis', $stamp);
                if ($boot) {
                    $diff = (new DateTime())->diff($boot);
                    return trim(sprintf('%dd %dh %dm', $diff->days, $diff->h, $diff->i));
                }
            }
        }
        return null;
    }
    if (is_readable('/proc/uptime')) {
        $seconds = (int) floatval(explode(' ', file_get_contents('/proc/uptime'))[0]);
        $d = intdiv($seconds, 86400);
        $hh = intdiv($seconds % 86400, 3600);
        $m = intdiv($seconds % 3600, 60);
        return "{$d}d {$hh}h {$m}m";
    }
    return null;
}

function getDiskUsage(string $path): ?array {
    $total = @disk_total_space($path);
    $free  = @disk_free_space($path);
    if ($total && $free) {
        return [
            'total_gb' => round($total / 1073741824, 1),
            'free_gb'  => round($free / 1073741824, 1),
            'used_pct' => (int) round((($total - $free) / $total) * 100),
        ];
    }
    return null;
}

function checkPort(string $host, int $port, float $timeout = 0.35): array {
    $start = microtime(true);
    $conn = @fsockopen($host, $port, $errno, $errstr, $timeout);
    $latency = (int) round((microtime(true) - $start) * 1000);
    if ($conn) { fclose($conn); return ['up' => true, 'latency' => $latency]; }
    return ['up' => false, 'latency' => null];
}

function scanProjects(string $docRoot): array {
    $projects = [];
    if (!is_dir($docRoot)) return $projects;
    foreach (scandir($docRoot) as $entry) {
        if ($entry === '.' || $entry === '..' || $entry[0] === '.') continue;
        $full = $docRoot . DIRECTORY_SEPARATOR . $entry;
        if (!is_dir($full)) continue;
        $stack = [];
        if (file_exists($full . '/composer.json')) $stack[] = 'PHP';
        if (file_exists($full . '/artisan'))        $stack[] = 'Laravel';
        if (file_exists($full . '/package.json'))   $stack[] = 'Node';
        if (is_dir($full . '/.git'))                $stack[] = 'Git';
        $projects[] = [
            'name'  => $entry,
            'stack' => $stack,
            'mtime' => @filemtime($full) ?: 0,
        ];
    }
    usort($projects, fn($a, $b) => $b['mtime'] <=> $a['mtime']);
    return $projects;
}

// ============================================================================
//  QUERY ROUTER (allow-list)
// ============================================================================
if (isset($_GET['q'])) {
    $query = $_GET['q'];

    if ($query === 'info') {
        if ($isLocal) { phpinfo(); exit; }
        http_response_code(403);
        exit('Forbidden! phpinfo() is allowed on localhost only.');
    }

    if ($query === 'stats') {
        header('Content-Type: application/json');
        echo json_encode([
            'cpu'         => getCpuUsage(),
            'memory'      => getMemoryUsage(),
            'disk'        => getDiskUsage($_SERVER['DOCUMENT_ROOT'] ?? __DIR__),
            'uptime'      => getUptime(),
            'server_time' => date('H:i:s'),
        ]);
        exit;
    }

    http_response_code(404);
    exit('Invalid query parameter.');
}

// ============================================================================
//  GATHER PAGE DATA
// ============================================================================
$computerName   = gethostname() ?: 'UNKNOWN-DEVICE';
$os             = getOsDetails();
$cpu            = getCpuUsage();
$memory         = getMemoryUsage();
$disk           = getDiskUsage($_SERVER['DOCUMENT_ROOT'] ?? __DIR__);
$uptime         = getUptime();
$phpVersion     = PHP_VERSION;
$serverSoftware = $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown';
$docRoot        = $_SERVER['DOCUMENT_ROOT'] ?? __DIR__;
$localIp        = $_SERVER['SERVER_ADDR'] ?? (gethostbyname($computerName) ?: '127.0.0.1');
$extCount       = count(get_loaded_extensions());
$mysql          = checkPort('127.0.0.1', 3306);
$projects       = scanProjects($docRoot);

$isApache = stripos($serverSoftware, 'apache') !== false;
$isNginx  = stripos($serverSoftware, 'nginx') !== false;
$webServerName = $isApache ? 'Apache' : ($isNginx ? 'Nginx' : 'Web Server');

$healthScores = array_values(array_filter(
    [$cpu, $memory['used_pct'] ?? null, $disk['used_pct'] ?? null],
    fn($v) => $v !== null
));
$overallHealth = 'OPTIMAL';
if ($healthScores) {
    $max = max($healthScores);
    if ($max >= 90) $overallHealth = 'CRITICAL';
    elseif ($max >= 75) $overallHealth = 'ELEVATED';
    elseif ($max >= 50) $overallHealth = 'NORMAL';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>J11 Technologies — Control Deck</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
    :root{
        --bg:#0A0E14;
        --bg-glow: radial-gradient(circle at 20% -10%, rgba(33,199,168,0.10), transparent 45%),
                   radial-gradient(circle at 85% 10%, rgba(255,159,67,0.06), transparent 40%);
        --panel:#101722;
        --panel-alt:#0D1420;
        --border: rgba(255,255,255,0.07);
        --primary:#21C7A8;
        --primary-dim: rgba(33,199,168,0.14);
        --accent:#FF9F43;
        --accent-dim: rgba(255,159,67,0.14);
        --danger:#FF5C5C;
        --text:#E9EEF3;
        --muted:#7C8896;
        --mono:'JetBrains Mono', ui-monospace, monospace;
        --sans:'Inter', sans-serif;
    }
    *{box-sizing:border-box;}
    html,body{margin:0;padding:0;min-height:100%;background:var(--bg);color:var(--text);font-family:var(--sans);}
    body{
        background-image:
            var(--bg-glow),
            linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px);
        background-size: auto, 42px 42px, 42px 42px;
        background-position: 0 0, -1px -1px, -1px -1px;
    }
    .wrap{max-width:1080px;margin:0 auto;padding:28px 20px 60px;}

    /* ---------- Top bar ---------- */
    .topbar{
        display:flex;align-items:center;justify-content:space-between;
        padding:14px 20px;background:var(--panel);border:1px solid var(--border);
        border-radius:12px;margin-bottom:22px;flex-wrap:wrap;gap:12px;
    }
    .brand{display:flex;align-items:center;gap:10px;}
    .brand-mark{
        width:34px;height:34px;border-radius:8px;
        background:linear-gradient(135deg,var(--primary),#0f8f78);
        display:flex;align-items:center;justify-content:center;
        font-family:var(--mono);font-weight:700;color:#04140f;font-size:15px;
    }
    .brand-text{line-height:1.15;}
    .brand-text b{font-size:14px;letter-spacing:0.4px;}
    .brand-text span{display:block;font-size:11px;color:var(--muted);font-family:var(--mono);letter-spacing:1px;}
    .topbar-right{display:flex;align-items:center;gap:18px;flex-wrap:wrap;}
    .health-pill{
        display:flex;align-items:center;gap:8px;font-family:var(--mono);font-size:12px;
        padding:6px 12px;border-radius:999px;background:var(--panel-alt);border:1px solid var(--border);
        text-transform:uppercase;letter-spacing:1px;
    }
    .dot{width:8px;height:8px;border-radius:50%;background:var(--primary);position:relative;flex:none;}
    .dot::after{
        content:'';position:absolute;inset:-4px;border-radius:50%;background:inherit;opacity:0.4;
        animation:pulse 2s ease-out infinite;
    }
    @keyframes pulse{0%{transform:scale(0.6);opacity:0.5;}100%{transform:scale(2.2);opacity:0;}}
    .health-optimal .dot{background:var(--primary);}
    .health-normal .dot{background:#5FB8FF;}
    .health-elevated .dot{background:var(--accent);}
    .health-critical .dot{background:var(--danger);}
    .clock-box{text-align:right;font-family:var(--mono);}
    #live-date{font-size:11px;color:var(--muted);letter-spacing:0.5px;}
    #live-time{font-size:18px;font-weight:700;color:var(--primary);letter-spacing:1px;}

    /* ---------- Hero / terminal ---------- */
    .hero{
        background:var(--panel);border:1px solid var(--border);border-radius:14px;
        padding:26px 28px;margin-bottom:22px;position:relative;overflow:hidden;
    }
    .hero::before{
        content:'';position:absolute;top:0;left:0;right:0;height:1px;
        background:linear-gradient(90deg,transparent,var(--primary),transparent);opacity:0.6;
    }
    .terminal-line{font-family:var(--mono);font-size:14px;color:var(--muted);margin-bottom:6px;}
    .terminal-line .prompt-user{color:var(--primary);}
    .terminal-line .prompt-path{color:var(--accent);}
    .hero h1{
        font-family:var(--mono);font-size:clamp(24px,4vw,34px);margin:6px 0 8px;font-weight:700;
        letter-spacing:-0.5px;
    }
    .hero h1 .caret{display:inline-block;width:10px;height:1em;background:var(--primary);
        margin-left:4px;vertical-align:-3px;animation:blink 1s steps(1) infinite;}
    @keyframes blink{50%{opacity:0;}}
    .hero p{color:var(--muted);font-size:14px;margin:0;}

    /* ---------- Section headers ---------- */
    .section-label{
        font-family:var(--mono);font-size:11px;letter-spacing:2px;text-transform:uppercase;
        color:var(--accent);margin:0 0 12px 4px;font-weight:700;
    }

    /* ---------- Gauges ---------- */
    .gauge-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:22px;}
    .gauge-card{
        background:var(--panel);border:1px solid var(--border);border-radius:14px;
        padding:20px;display:flex;flex-direction:column;align-items:center;gap:10px;
    }
    .gauge-card .g-label{font-family:var(--mono);font-size:11px;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase;}
    .gauge-svg{width:128px;height:128px;}
    .gauge-track{fill:none;stroke:rgba(255,255,255,0.06);stroke-width:9;}
    .gauge-fill{fill:none;stroke:var(--primary);stroke-width:9;stroke-linecap:round;
        stroke-dasharray:339.292;stroke-dashoffset:339.292;
        transform:rotate(-90deg);transform-origin:64px 64px;transition:stroke-dashoffset 1s ease, stroke 0.4s ease;}
    .gauge-pct{font-family:var(--mono);font-size:22px;font-weight:700;}
    .gauge-sub{font-size:11px;color:var(--muted);text-align:center;}
    .gauge-na{color:var(--muted);font-size:11px;font-family:var(--mono);text-align:center;}

    /* ---------- Info grid ---------- */
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:22px;}
    @media (max-width:700px){.info-grid{grid-template-columns:1fr;} .gauge-grid{grid-template-columns:1fr 1fr;}}
    @media (max-width:460px){.gauge-grid{grid-template-columns:1fr;}}
    .panel{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:18px 20px;}
    .panel-title{font-family:var(--mono);font-size:11px;text-transform:uppercase;letter-spacing:1.5px;
        color:var(--accent);margin-bottom:12px;font-weight:700;}
    .info-item{display:flex;justify-content:space-between;gap:10px;padding:8px 0;
        border-bottom:1px solid var(--border);font-size:13px;}
    .info-item:last-child{border-bottom:none;}
    .info-label{color:var(--muted);}
    .info-value{font-weight:600;font-family:var(--mono);font-size:12.5px;text-align:right;}
    .info-value.accent{color:var(--primary);}
    .info-value a{color:var(--primary);text-decoration:none;background:var(--primary-dim);
        padding:2px 8px;border-radius:5px;font-size:11px;}
    .info-value a:hover{background:rgba(33,199,168,0.28);}

    /* ---------- Services ---------- */
    .service-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:22px;}
    @media (max-width:700px){.service-grid{grid-template-columns:1fr;}}
    .service-card{
        background:var(--panel);border:1px solid var(--border);border-radius:12px;
        padding:16px 18px;display:flex;align-items:center;justify-content:space-between;
    }
    .service-name{font-size:13px;font-weight:700;}
    .service-meta{font-family:var(--mono);font-size:11px;color:var(--muted);margin-top:2px;}
    .status-chip{display:flex;align-items:center;gap:6px;font-family:var(--mono);font-size:11px;
        padding:4px 10px;border-radius:999px;text-transform:uppercase;letter-spacing:0.5px;}
    .status-up{background:var(--primary-dim);color:var(--primary);}
    .status-down{background:rgba(255,92,92,0.14);color:var(--danger);}
    .status-chip .dot{width:6px;height:6px;}
    .status-up .dot{background:var(--primary);}
    .status-down .dot{background:var(--danger);}
    .status-down .dot::after{display:none;}

    /* ---------- Projects ---------- */
    .projects-panel{background:var(--panel);border:1px solid var(--border);border-radius:14px;
        padding:18px 20px;margin-bottom:22px;}
    .project-list{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;}
    @media (max-width:700px){.project-list{grid-template-columns:1fr;}}
    .project-item{
        display:flex;align-items:center;justify-content:space-between;gap:10px;
        padding:11px 14px;background:var(--panel-alt);border:1px solid var(--border);
        border-radius:10px;text-decoration:none;color:var(--text);transition:border-color .2s, transform .2s;
    }
    .project-item:hover{border-color:var(--primary);transform:translateY(-1px);}
    .project-name{font-family:var(--mono);font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
    .project-badges{display:flex;gap:4px;flex:none;}
    .badge{font-size:9px;font-family:var(--mono);padding:2px 6px;border-radius:4px;
        background:var(--accent-dim);color:var(--accent);text-transform:uppercase;letter-spacing:0.5px;}
    .empty-note{color:var(--muted);font-size:13px;font-family:var(--mono);}

    /* ---------- Actions ---------- */
    .btn-group{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:22px;}
    .btn{
        flex:1;min-width:150px;padding:13px 20px;font-size:13px;font-weight:700;
        text-decoration:none;border-radius:10px;text-align:center;font-family:var(--mono);
        letter-spacing:0.3px;transition:transform .15s ease, opacity .15s ease;border:1px solid transparent;
        cursor:pointer;
    }
    .btn-primary{background:var(--primary);color:#04140f;}
    .btn-primary:hover{transform:translateY(-2px);opacity:0.92;}
    .btn-secondary{background:var(--panel-alt);color:var(--text);border-color:var(--border);}
    .btn-secondary:hover{transform:translateY(-2px);border-color:var(--primary);}

    /* ---------- Footer ---------- */
    .footer{
        text-align:center;font-family:var(--mono);font-size:11px;color:var(--muted);
        padding-top:8px;display:flex;flex-direction:column;gap:4px;
    }
    .footer .sync{color:var(--primary);}
</style>
</head>
<body>
<div class="wrap">

    <!-- ================= TOP BAR ================= -->
    <div class="topbar">
        <div class="brand">
            <div class="brand-mark">J11</div>
            <div class="brand-text">
                <b>J11 TECHNOLOGIES</b>
                <span>CONTROL DECK</span>
            </div>
        </div>
        <div class="topbar-right">
            <div class="health-pill health-<?= strtolower($overallHealth) ?>" id="health-pill">
                <span class="dot"></span> SYSTEM <?= h($overallHealth) ?>
            </div>
            <div class="clock-box">
                <div id="live-date">Loading date…</div>
                <div id="live-time">00:00:00</div>
            </div>
        </div>
    </div>

    <!-- ================= HERO / TERMINAL ================= -->
    <div class="hero">
        <div class="terminal-line"><span class="prompt-user">j11@<?= h($computerName) ?></span>:<span class="prompt-path">~/www</span>$ whoami</div>
        <h1><?= h($computerName) ?><span class="caret"></span></h1>
        <p>Local development environment · Dar es Salaam, Tanzania · live telemetry refreshes automatically</p>
    </div>

    <!-- ================= GAUGES ================= -->
    <div class="section-label">Live Resource Monitor</div>
    <div class="gauge-grid">
        <div class="gauge-card">
            <div class="g-label">CPU Load</div>
            <svg class="gauge-svg" viewBox="0 0 128 128" id="gauge-cpu" data-pct="<?= $cpu !== null ? (int)$cpu : '' ?>">
                <circle class="gauge-track" cx="64" cy="64" r="54"></circle>
                <circle class="gauge-fill" cx="64" cy="64" r="54"></circle>
                <text x="64" y="70" text-anchor="middle" class="gauge-pct-text" fill="currentColor"></text>
            </svg>
            <div class="gauge-pct" id="cpu-pct-label"><?= $cpu !== null ? h($cpu) . '%' : 'N/A' ?></div>
            <div class="gauge-sub"><?= $cpu !== null ? 'Processor utilization' : 'exec() disabled on this host' ?></div>
        </div>
        <div class="gauge-card">
            <div class="g-label">Memory</div>
            <svg class="gauge-svg" viewBox="0 0 128 128" id="gauge-ram" data-pct="<?= $memory['used_pct'] ?? '' ?>">
                <circle class="gauge-track" cx="64" cy="64" r="54"></circle>
                <circle class="gauge-fill" cx="64" cy="64" r="54"></circle>
            </svg>
            <div class="gauge-pct" id="ram-pct-label"><?= isset($memory['used_pct']) ? h($memory['used_pct']) . '%' : 'N/A' ?></div>
            <div class="gauge-sub" id="ram-sub"><?= isset($memory['free_gb']) ? h($memory['free_gb']) . ' GB free of ' . h($memory['total_gb']) . ' GB' : 'Unavailable on this host' ?></div>
        </div>
        <div class="gauge-card">
            <div class="g-label">Disk (<?= h(strtoupper(substr($docRoot, 0, 1))) ?>:)</div>
            <svg class="gauge-svg" viewBox="0 0 128 128" id="gauge-disk" data-pct="<?= $disk['used_pct'] ?? '' ?>">
                <circle class="gauge-track" cx="64" cy="64" r="54"></circle>
                <circle class="gauge-fill" cx="64" cy="64" r="54"></circle>
            </svg>
            <div class="gauge-pct" id="disk-pct-label"><?= isset($disk['used_pct']) ? h($disk['used_pct']) . '%' : 'N/A' ?></div>
            <div class="gauge-sub" id="disk-sub"><?= isset($disk['free_gb']) ? h($disk['free_gb']) . ' GB free of ' . h($disk['total_gb']) . ' GB' : 'Unavailable' ?></div>
        </div>
    </div>

    <!-- ================= INFO GRID ================= -->
    <div class="info-grid">
        <div class="panel">
            <div class="panel-title">Host Machine</div>
            <div class="info-item"><span class="info-label">Computer Name</span><span class="info-value accent"><?= h($computerName) ?></span></div>
            <div class="info-item"><span class="info-label">Operating System</span><span class="info-value"><?= h($os['name']) ?></span></div>
            <div class="info-item"><span class="info-label">Version</span><span class="info-value"><?= h($os['exact'] ?? 'Unknown') ?></span></div>
            <div class="info-item"><span class="info-label">Architecture</span><span class="info-value"><?= h($os['arch']) ?></span></div>
            <div class="info-item"><span class="info-label">Uptime</span><span class="info-value" id="uptime-value"><?= h($uptime ?? 'N/A') ?></span></div>
            <div class="info-item"><span class="info-label">Local IP</span><span class="info-value"><?= h($localIp) ?></span></div>
        </div>
        <div class="panel">
            <div class="panel-title">Server Environment</div>
            <?php if ($isLocal): ?>
                <div class="info-item"><span class="info-label">Server Software</span><span class="info-value"><?= h($serverSoftware) ?></span></div>
                <div class="info-item"><span class="info-label">PHP Version</span><span class="info-value"><?= h($phpVersion) ?> <a href="/?q=info">info()</a></span></div>
                <div class="info-item"><span class="info-label">Loaded Extensions</span><span class="info-value"><?= h($extCount) ?></span></div>
                <div class="info-item"><span class="info-label">Document Root</span><span class="info-value" style="font-size:11px;" id="docroot-value"><?= h($docRoot) ?></span></div>
                <div class="info-item"><span class="info-label">Last Sync</span><span class="info-value sync" id="last-sync">just now</span></div>
            <?php else: ?>
                <div class="info-item"><span class="info-label">Server Status</span><span class="info-value accent">Reachable on network</span></div>
                <div class="info-item"><span class="info-label">PHP Engine</span><span class="info-value accent">Active</span></div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ================= SERVICES ================= -->
    <div class="section-label">Services</div>
    <div class="service-grid">
        <div class="service-card">
            <div>
                <div class="service-name"><?= h($webServerName) ?></div>
                <div class="service-meta">Web server</div>
            </div>
            <div class="status-chip status-up"><span class="dot"></span>Online</div>
        </div>
        <div class="service-card">
            <div>
                <div class="service-name">MySQL / MariaDB</div>
                <div class="service-meta"><?= $mysql['up'] ? h($mysql['latency']) . 'ms · port 3306' : 'port 3306' ?></div>
            </div>
            <div class="status-chip <?= $mysql['up'] ? 'status-up' : 'status-down' ?>">
                <span class="dot"></span><?= $mysql['up'] ? 'Online' : 'Offline' ?>
            </div>
        </div>
        <div class="service-card">
            <div>
                <div class="service-name">PHP Engine</div>
                <div class="service-meta">v<?= h($phpVersion) ?></div>
            </div>
            <div class="status-chip status-up"><span class="dot"></span>Active</div>
        </div>
    </div>

    <!-- ================= PROJECTS ================= -->
    <div class="projects-panel">
        <div class="panel-title">Projects in <?= h(basename($docRoot)) ?> (<?= count($projects) ?>)</div>
        <?php if ($projects): ?>
            <div class="project-list">
                <?php foreach ($projects as $p): ?>
                    <a class="project-item" href="/<?= rawurlencode($p['name']) ?>/" title="Open <?= h($p['name']) ?>">
                        <span class="project-name">📁 <?= h($p['name']) ?></span>
                        <span class="project-badges">
                            <?php foreach ($p['stack'] as $tag): ?>
                                <span class="badge"><?= h($tag) ?></span>
                            <?php endforeach; ?>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-note">No project folders detected in the document root yet.</div>
        <?php endif; ?>
    </div>

    <!-- ================= ACTIONS ================= -->
    <div class="btn-group">
        <a href="https://laragon.org/docs" target="_blank" rel="noopener" class="btn btn-primary">Laragon Docs</a>
        <a href="/phpmyadmin" class="btn btn-secondary">phpMyAdmin</a>
        <button type="button" class="btn btn-secondary" id="copy-root-btn">Copy Document Root</button>
    </div>

    <div class="footer">
        <div>&copy; <?= date('Y'); ?> J11 Technologies. All Rights Reserved.</div>
        <div>Telemetry auto-refreshes every 5s · <span class="sync" id="sync-status">connected</span></div>
    </div>
</div>

<script>
const CIRCUMFERENCE = 339.292;

function setGauge(id, pct) {
    const svg = document.getElementById(id);
    if (!svg) return;
    const fill = svg.querySelector('.gauge-fill');
    if (pct === null || pct === undefined || pct === '' || isNaN(pct)) {
        fill.style.stroke = 'rgba(255,255,255,0.06)';
        fill.style.strokeDashoffset = CIRCUMFERENCE;
        return;
    }
    pct = Math.max(0, Math.min(100, Number(pct)));
    const offset = CIRCUMFERENCE * (1 - pct / 100);
    fill.style.strokeDashoffset = offset;
    let color = 'var(--primary)';
    if (pct >= 90) color = 'var(--danger)';
    else if (pct >= 75) color = 'var(--accent)';
    fill.style.stroke = color;
}

function initGauges() {
    ['gauge-cpu', 'gauge-ram', 'gauge-disk'].forEach(id => {
        const svg = document.getElementById(id);
        const pct = svg.dataset.pct;
        requestAnimationFrame(() => setGauge(id, pct === '' ? null : pct));
    });
}

function updateClock() {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');
    document.getElementById('live-time').textContent = `${hh}:${mm}:${ss}`;
    const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    document.getElementById('live-date').textContent =
        `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
}

let lastSyncSeconds = 0;
function tickSyncLabel() {
    lastSyncSeconds++;
    const el = document.getElementById('last-sync');
    if (el) el.textContent = lastSyncSeconds <= 1 ? 'just now' : `${lastSyncSeconds}s ago`;
}

async function refreshStats() {
    try {
        const res = await fetch('/?q=stats', { cache: 'no-store' });
        if (!res.ok) throw new Error('bad response');
        const data = await res.json();

        setGauge('gauge-cpu', data.cpu);
        document.getElementById('cpu-pct-label').textContent = data.cpu !== null ? `${data.cpu}%` : 'N/A';

        if (data.memory) {
            setGauge('gauge-ram', data.memory.used_pct);
            document.getElementById('ram-pct-label').textContent = `${data.memory.used_pct}%`;
            document.getElementById('ram-sub').textContent = `${data.memory.free_gb} GB free of ${data.memory.total_gb} GB`;
        }

        if (data.disk) {
            setGauge('gauge-disk', data.disk.used_pct);
            document.getElementById('disk-pct-label').textContent = `${data.disk.used_pct}%`;
            document.getElementById('disk-sub').textContent = `${data.disk.free_gb} GB free of ${data.disk.total_gb} GB`;
        }

        if (data.uptime) {
            const up = document.getElementById('uptime-value');
            if (up) up.textContent = data.uptime;
        }

        const sync = document.getElementById('sync-status');
        if (sync) { sync.textContent = 'connected'; sync.style.color = 'var(--primary)'; }
        lastSyncSeconds = 0;
    } catch (e) {
        const sync = document.getElementById('sync-status');
        if (sync) { sync.textContent = 'connection lost — retrying'; sync.style.color = 'var(--danger)'; }
    }
}

document.getElementById('copy-root-btn')?.addEventListener('click', () => {
    const path = document.getElementById('docroot-value')?.textContent?.trim();
    if (!path) return;
    navigator.clipboard.writeText(path).then(() => {
        const btn = document.getElementById('copy-root-btn');
        const original = btn.textContent;
        btn.textContent = 'Copied!';
        setTimeout(() => { btn.textContent = original; }, 1500);
    });
});

initGauges();
updateClock();
setInterval(updateClock, 1000);
setInterval(tickSyncLabel, 1000);
setInterval(refreshStats, 5000);
</script>
</body>
</html>
