<?php
/**
 * Vote Management System
 * Create Election Page
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../classes/Admin.php';

// Check if user is logged in and is admin
if (!isLoggedIn()) {
    redirect(SITE_URL . '/public/login.php');
}

if (!isAdmin()) {
    setFlashMessage('error', 'Access denied. Admin privileges required.');
    redirect(SITE_URL . '/public/dashboard.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $name = sanitizeInput($_POST['name'] ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    $election_type = sanitizeInput($_POST['election_type'] ?? '');
    $constituency = sanitizeInput($_POST['constituency'] ?? '');
    $start_date = sanitizeInput($_POST['start_date'] ?? '');
    $end_date = sanitizeInput($_POST['end_date'] ?? '');
    $total_voters = intval($_POST['total_voters'] ?? 0);
    $status = sanitizeInput($_POST['status'] ?? 'draft');
    
    // Validation
    $errors = [];
    
    if (empty($name)) $errors[] = 'Election name is required';
    if (empty($election_type)) $errors[] = 'Election type is required';
    if (empty($constituency)) $errors[] = 'Constituency is required';
    if (empty($start_date)) $errors[] = 'Start date is required';
    if (empty($end_date)) $errors[] = 'End date is required';
    if ($total_voters <= 0) $errors[] = 'Total voters must be greater than 0';
    
    if (strtotime($end_date) <= strtotime($start_date)) {
        $errors[] = 'End date must be after start date';
    }
    
    if (empty($errors)) {
        try {
            $database = new Database();
            $db = $database->connect();
            $admin = new Admin($db);
            
            $election_data = [
                'name' => $name,
                'description' => $description,
                'election_type' => $election_type,
                'constituency' => $constituency,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'status' => $status,
                'total_voters' => $total_voters,
                'created_by' => getCurrentUserId()
            ];
            
            $election_id = $admin->createElection($election_data);
            
            if ($election_id) {
                setFlashMessage('success', 'Election created successfully!');
                redirect(SITE_URL . '/admin/elections/view.php?id=' . $election_id);
            } else {
                $errors[] = 'Failed to create election';
            }
            
        } catch (Exception $e) {
            $errors[] = 'Error: ' . $e->getMessage();
        }
    }
    
    $_SESSION['election_errors'] = $errors;
}

$errors = $_SESSION['election_errors'] ?? [];
unset($_SESSION['election_errors']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Election | Admin</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        body { background: #f5f5f5; margin: 0; font-family: Arial, sans-serif; }
        .container { max-width: 800px; margin: 40px auto; padding: 20px; }
        .card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .form-header { margin-bottom: 30px; }
        .form-header h1 { margin: 0 0 10px 0; color: #333; }
        .form-header p { margin: 0; color: #666; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .back-btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 6px; margin-bottom: 20px; }
        .back-btn:hover { background: #5a6268; }
        textarea { min-height: 100px; resize: vertical; }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    
    <div class="container">
        <a href="../index.php" class="back-btn">← Back to Dashboard</a>
        
        <div class="card">
            <div class="form-header">
                <h1>🗳️ Create New Election</h1>
                <p>Fill in the details below to create a new election</p>
            </div>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error" style="margin-bottom: 20px;">
                    <span>⚠️</span>
                    <div>
                        <?php foreach ($errors as $error): ?>
                            <p style="margin: 5px 0;"><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <!-- Election Name -->
                <div class="form-group">
                    <label for="name" class="form-label">Election Name <span class="required">*</span></label>
                    <input type="text" id="name" name="name" class="form-input" 
                           placeholder="e.g., Mbinga Urban - Village Chairperson Election 2026"
                           value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                </div>
                
                <!-- Description -->
                <div class="form-group">
                    <label for="description" class="form-label">Description</label>
                    <textarea id="description" name="description" class="form-input" 
                              placeholder="Brief description of the election"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                </div>
                
                <!-- Election Type & Constituency -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="election_type" class="form-label">Election Type <span class="required">*</span></label>
                        <select id="election_type" name="election_type" class="form-input" required>
                            <option value="">Select Type</option>
                            <option value="Village Chairperson">Village Chairperson</option>
                            <option value="Street Chairperson">Street Chairperson</option>
                            <option value="Ward Councilor">Ward Councilor</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="constituency" class="form-label">Constituency <span class="required">*</span></label>
                        <input type="text" id="constituency" name="constituency" class="form-input" 
                               placeholder="e.g., Mbinga Urban"
                               value="<?php echo htmlspecialchars($_POST['constituency'] ?? ''); ?>" required>
                    </div>
                </div>
                
                <!-- Start & End Date -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="start_date" class="form-label">Start Date & Time <span class="required">*</span></label>
                        <input type="datetime-local" id="start_date" name="start_date" class="form-input" 
                               value="<?php echo $_POST['start_date'] ?? ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="end_date" class="form-label">End Date & Time <span class="required">*</span></label>
                        <input type="datetime-local" id="end_date" name="end_date" class="form-input" 
                               value="<?php echo $_POST['end_date'] ?? ''; ?>" required>
                    </div>
                </div>
                
                <!-- Total Voters & Status -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="total_voters" class="form-label">Total Eligible Voters <span class="required">*</span></label>
                        <input type="number" id="total_voters" name="total_voters" class="form-input" 
                               placeholder="e.g., 1500" min="1"
                               value="<?php echo htmlspecialchars($_POST['total_voters'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="status" class="form-label">Initial Status <span class="required">*</span></label>
                        <select id="status" name="status" class="form-input" required>
                            <option value="draft">Draft</option>
                            <option value="active">Active</option>
                        </select>
                    </div>
                </div>
                
                <!-- Submit Button -->
                <div style="margin-top: 30px; display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                        Create Election
                    </button>
                    <a href="../index.php" class="btn" style="flex: 1; background: #6c757d; color: white; text-align: center; text-decoration: none; padding: 14px;">
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
