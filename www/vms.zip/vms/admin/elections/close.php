<?php
/**
 * Vote Management System
 * Close Election
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../classes/Admin.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect(SITE_URL . '/public/login.php');
}

$election_id = intval($_GET['id'] ?? 0);

if ($election_id === 0) {
    setFlashMessage('error', 'Invalid election ID');
    redirect(SITE_URL . '/admin/index.php');
}

$database = new Database();
$db = $database->connect();
$admin = new Admin($db);

// Close the election
if ($admin->closeElection($election_id)) {
    setFlashMessage('success', 'Election closed successfully!');
} else {
    setFlashMessage('error', 'Failed to close election');
}

redirect(SITE_URL . '/admin/elections/view.php?id=' . $election_id);
?>
