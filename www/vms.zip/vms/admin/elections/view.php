<?php
/**
 * Vote Management System
 * View Election Details (Admin)
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../classes/Admin.php';
require_once '../../classes/Vote.php';

// Check admin access
if (!isLoggedIn() || !isAdmin()) {
    redirect(SITE_URL . '/public/login.php');
}

$election_id = intval($_GET['id'] ?? 0);

if ($election_id === 0) {
    redirect(SITE_URL . '/admin/index.php');
}

$database = new Database();
$db = $database->connect();
$admin = new Admin($db);
$vote = new Vote($db);

// Get election details
$query = "SELECT * FROM elections WHERE election_id = :id LIMIT 1";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $election_id);
$stmt->execute();
$election = $stmt->fetch();

if (!$election) {
    setFlashMessage('error', 'Election not found');
    redirect(SITE_URL . '/admin/index.php');
}

// Get candidates
$candidates = $vote->getCandidates($election_id);

// Get voters count
$query = "SELECT COUNT(*) as count FROM voters_list WHERE election_id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $election_id);
$stmt->execute();
$voters_count = $stmt->fetch()['count'];

// Get votes count
$query = "SELECT COUNT(*) as count FROM encrypted_votes WHERE election_id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $election_id);
$stmt->execute();
$votes_count = $stmt->fetch()['count'];

// Calculate turnout
$turnout = $election['total_voters'] > 0 ? round(($election['votes_cast'] / $election['total_voters']) * 100, 2) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Election Details | Admin</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        body { background: #f5f5f5; margin: 0; font-family: Arial, sans-serif; }
        .container { max-width: 1200px; margin: 40px auto; padding: 20px; }
        .header-card { background: white; padding: 30px; border-radius: 12px; margin-bottom: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .election-title { font-size: 28px; margin: 0 0 10px 0; color: #333; }
        .election-meta { color: #666; font-size: 15px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); text-align: center; }
        .stat-value { font-size: 36px; font-weight: bold; color: #333; margin-bottom: 5px; }
        .stat-label { font-size: 14px; color: #666; }
        .section-card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .section-title { font-size: 22px; margin: 0 0 20px 0; color: #333; }
        table { width: 100%; border-collapse: collapse; }
        thead { background: #f8f9fa; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        .back-btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 6px; margin-bottom: 20px; }
        .action-btn { padding: 8px 16px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: 600; display: inline-block; margin-right: 10px; }
        .btn-close { background: #e74c3c; color: white; }
        .btn-certify { background: #2ecc71; color: white; }
        .status-badge { padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }
        .status-draft { background: #f0f0f0; color: #666; }
        .status-active { background: #d4edda; color: #155724; }
        .status-closed { background: #fff3cd; color: #856404; }
        .status-certified { background: #d1ecf1; color: #0c5460; }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    
    <div class="container">
        <a href="../index.php" class="back-btn">← Back to Dashboard</a>
        
        <!-- Election Header -->
        <div class="header-card">
            <h1 class="election-title"><?php echo htmlspecialchars($election['name']); ?></h1>
            <div class="election-meta">
                <span class="status-badge status-<?php echo strtolower($election['status']); ?>">
                    <?php echo ucfirst($election['status']); ?>
                </span>
                <span style="margin-left: 15px;">
                    📅 <?php echo date('M j, Y', strtotime($election['start_date'])); ?> - 
                    <?php echo date('M j, Y', strtotime($election['end_date'])); ?>
                </span>
                <span style="margin-left: 15px;">
                    📍 <?php echo htmlspecialchars($election['constituency']); ?>
                </span>
            </div>
            
            <?php if ($election['description']): ?>
                <p style="margin-top: 15px; color: #666;">
                    <?php echo htmlspecialchars($election['description']); ?>
                </p>
            <?php endif; ?>
            
            <div style="margin-top: 20px;">
                <?php if ($election['status'] === 'active'): ?>
                    <a href="close.php?id=<?php echo $election_id; ?>" 
                       class="action-btn btn-close"
                       onclick="return confirm('Close this election? Voting will stop immediately.')">
                        🔒 Close Election
                    </a>
                <?php endif; ?>
                
                <?php if ($election['status'] === 'closed'): ?>
                    <a href="certify.php?id=<?php echo $election_id; ?>" 
                       class="action-btn btn-certify"
                       onclick="return confirm('Certify this election? Results will be finalized.')">
                        ✓ Certify Results
                    </a>
                <?php endif; ?>
                
                <a href="../../public/results.php?election_id=<?php echo $election_id; ?>" 
                   class="action-btn" style="background: #3498db; color: white;">
                    📊 View Results
                </a>
            </div>
        </div>
        
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($election['votes_cast']); ?></div>
                <div class="stat-label">Votes Cast</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($election['total_voters']); ?></div>
                <div class="stat-label">Eligible Voters</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-value"><?php echo $turnout; ?>%</div>
                <div class="stat-label">Voter Turnout</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-value"><?php echo count($candidates); ?></div>
                <div class="stat-label">Candidates</div>
            </div>
        </div>
        
        <!-- Candidates List -->
        <div class="section-card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 class="section-title" style="margin: 0;">Candidates</h2>
                <a href="../candidates/add.php?election_id=<?php echo $election_id; ?>" 
                   class="action-btn" style="background: #2ecc71; color: white;">
                    + Add Candidate
                </a>
            </div>
            
            <?php if (count($candidates) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Position</th>
                            <th>Name</th>
                            <th>Party</th>
                            <th>NIDA ID</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($candidates as $candidate): ?>
                            <tr>
                                <td><strong>#<?php echo $candidate['ballot_position']; ?></strong></td>
                                <td><?php echo htmlspecialchars($candidate['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($candidate['party_affiliation']); ?></td>
                                <td><?php echo htmlspecialchars($candidate['nida_id']); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo strtolower($candidate['status']); ?>">
                                        <?php echo ucfirst($candidate['status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="text-align: center; padding: 40px; color: #666;">
                    No candidates added yet. <a href="../candidates/add.php?election_id=<?php echo $election_id; ?>">Add the first candidate</a>
                </p>
            <?php endif; ?>
        </div>
        
        <!-- Election Timeline -->
        <div class="section-card">
            <h2 class="section-title">Timeline</h2>
            <div style="padding: 20px;">
                <div style="margin-bottom: 15px;">
                    <strong>Created:</strong> 
                    <?php echo date('M j, Y \a\t g:i A', strtotime($election['created_at'])); ?>
                </div>
                <div style="margin-bottom: 15px;">
                    <strong>Voting Starts:</strong> 
                    <?php echo date('M j, Y \a\t g:i A', strtotime($election['start_date'])); ?>
                </div>
                <div style="margin-bottom: 15px;">
                    <strong>Voting Ends:</strong> 
                    <?php echo date('M j, Y \a\t g:i A', strtotime($election['end_date'])); ?>
                </div>
                <?php if ($election['closed_at']): ?>
                    <div style="margin-bottom: 15px;">
                        <strong>Closed:</strong> 
                        <?php echo date('M j, Y \a\t g:i A', strtotime($election['closed_at'])); ?>
                    </div>
                <?php endif; ?>
                <?php if ($election['certified_at']): ?>
                    <div>
                        <strong>Certified:</strong> 
                        <?php echo date('M j, Y \a\t g:i A', strtotime($election['certified_at'])); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
