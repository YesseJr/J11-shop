<?php
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../classes/Admin.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect(SITE_URL . '/public/login.php');
}

$database = new Database();
$db = $database->connect();
$admin = new Admin($db);
$elections = $admin->getAllElections();
$flash_message = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Elections | Admin</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        body { background: #f5f5f5; margin: 0; font-family: Arial, sans-serif; }
        .container { max-width: 1200px; margin: 40px auto; padding: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; background: white; padding: 20px 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .back-btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 6px; margin-bottom: 20px; }
        .btn-primary { background: #4472C4; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600; }
        .elections-table { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; font-weight: 600; }
        .status-badge { padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }
        .status-draft { background: #f0f0f0; color: #666; }
        .status-active { background: #d4edda; color: #155724; }
        .status-closed { background: #fff3cd; color: #856404; }
        .action-btn { padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 13px; margin-right: 5px; display: inline-block; }
        .btn-view { background: #2ecc71; color: white; }
        .btn-edit { background: #3498db; color: white; }
        .btn-close { background: #e74c3c; color: white; }
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-error { background: #fee; color: #c33; }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    <div class="container">
        <a href="../index.php" class="back-btn">← Back to Dashboard</a>
        
        <?php if ($flash_message): ?>
            <div class="alert alert-<?php echo htmlspecialchars($flash_message['type']); ?>">
                <?php echo htmlspecialchars($flash_message['message']); ?>
            </div>
        <?php endif; ?>
        
        <div class="header">
            <h1 style="margin: 0; color: #333;">🗳️ Manage Elections</h1>
            <a href="create.php" class="btn-primary">+ Create Election</a>
        </div>
        
        <div class="elections-table">
            <?php if (count($elections) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Election Name</th>
                            <th>Type</th>
                            <th>Constituency</th>
                            <th>Dates</th>
                            <th>Status</th>
                            <th>Votes</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($elections as $election): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($election['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($election['election_type']); ?></td>
                                <td><?php echo htmlspecialchars($election['constituency']); ?></td>
                                <td><?php echo date('M j', strtotime($election['start_date'])) . ' - ' . date('M j, Y', strtotime($election['end_date'])); ?></td>
                                <td><span class="status-badge status-<?php echo strtolower($election['status']); ?>"><?php echo ucfirst($election['status']); ?></span></td>
                                <td><?php echo $election['votes_cast']; ?> / <?php echo $election['total_voters']; ?></td>
                                <td>
                                    <a href="view.php?id=<?php echo $election['election_id']; ?>" class="action-btn btn-view">View</a>
                                    <a href="edit.php?id=<?php echo $election['election_id']; ?>" class="action-btn btn-edit">Edit</a>
                                    <?php if ($election['status'] === 'active'): ?>
                                        <a href="close.php?id=<?php echo $election['election_id']; ?>" class="action-btn btn-close" onclick="return confirm('Close this election?')">Close</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="text-align: center; padding: 60px; color: #666;">
                    No elections found. <a href="create.php" style="color: #4472C4; font-weight: bold;">Create your first election</a>
                </p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
