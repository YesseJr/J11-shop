<?php
/**
 * Debug Page - Check Votes
 * Temporary page to debug vote counting issue
 */

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/Encryption.php';

// Only accessible to admins
if (!isLoggedIn() || !isAdmin()) {
    die('Access denied');
}

$database = new Database();
$db = $database->connect();
$encryption = new Encryption();

// Get election ID from URL
$election_id = $_GET['election_id'] ?? 1;

// Get election info
$query = "SELECT * FROM elections WHERE election_id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $election_id);
$stmt->execute();
$election = $stmt->fetch();

// Get encrypted votes
$query = "SELECT * FROM encrypted_votes WHERE election_id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $election_id);
$stmt->execute();
$votes = $stmt->fetchAll();

// Get candidates
$query = "SELECT * FROM candidates WHERE election_id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $election_id);
$stmt->execute();
$candidates = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Debug Votes</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .card { background: white; padding: 20px; margin-bottom: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h2 { color: #333; border-bottom: 2px solid #4472C4; padding-bottom: 10px; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 4px; overflow-x: auto; }
        .success { color: #155724; background: #d4edda; padding: 10px; border-radius: 4px; }
        .error { color: #721c24; background: #f8d7da; padding: 10px; border-radius: 4px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f8f9fa; font-weight: bold; }
    </style>
</head>
<body>
    <h1>🔍 Vote Debugging Tool</h1>
    
    <div class="card">
        <h2>Election Information</h2>
        <?php if ($election): ?>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($election['name']); ?></p>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($election['status']); ?></p>
            <p><strong>Votes Cast (recorded):</strong> <?php echo $election['votes_cast']; ?></p>
            <p><strong>Election ID:</strong> <?php echo $election_id; ?></p>
        <?php else: ?>
            <p class="error">Election not found!</p>
        <?php endif; ?>
    </div>
    
    <div class="card">
        <h2>Candidates (<?php echo count($candidates); ?>)</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Party</th>
                <th>Position</th>
            </tr>
            <?php foreach ($candidates as $candidate): ?>
                <tr>
                    <td><?php echo $candidate['candidate_id']; ?></td>
                    <td><?php echo htmlspecialchars($candidate['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($candidate['party_affiliation']); ?></td>
                    <td><?php echo $candidate['ballot_position']; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
    
    <div class="card">
        <h2>Encrypted Votes in Database (<?php echo count($votes); ?>)</h2>
        <?php if (count($votes) > 0): ?>
            <p class="success">✅ Found <?php echo count($votes); ?> encrypted votes in database!</p>
            
            <h3>Attempting to decrypt votes...</h3>
            <?php
            $successful = 0;
            $failed = 0;
            $vote_counts = [];
            
            foreach ($votes as $index => $vote):
                echo "<div style='border: 1px solid #ddd; padding: 10px; margin: 10px 0; border-radius: 4px;'>";
                echo "<strong>Vote #" . ($index + 1) . " (ID: {$vote['vote_id']})</strong><br>";
                echo "<small>Timestamp: {$vote['timestamp']}</small><br>";
                
                try {
                    $decrypted = $encryption->decrypt($vote['encrypted_vote_data']);
                    
                    if ($decrypted && !empty($decrypted)) {
                        $vote_data = json_decode($decrypted, true);
                        
                        if ($vote_data && isset($vote_data['candidate_id'])) {
                            echo "<span class='success'>✅ DECRYPTION SUCCESS</span><br>";
                            echo "<strong>Candidate ID:</strong> " . $vote_data['candidate_id'] . "<br>";
                            echo "<strong>Candidate Name:</strong> " . htmlspecialchars($vote_data['candidate_name'] ?? 'N/A') . "<br>";
                            echo "<strong>Timestamp:</strong> " . htmlspecialchars($vote_data['timestamp'] ?? 'N/A') . "<br>";
                            $successful++;
                            
                            // Count votes
                            if (!isset($vote_counts[$vote_data['candidate_id']])) {
                                $vote_counts[$vote_data['candidate_id']] = 0;
                            }
                            $vote_counts[$vote_data['candidate_id']]++;
                        } else {
                            echo "<span class='error'>❌ Invalid vote data structure</span><br>";
                            echo "<pre>" . htmlspecialchars(print_r($vote_data, true)) . "</pre>";
                            $failed++;
                        }
                    } else {
                        echo "<span class='error'>❌ DECRYPTION FAILED - returned false/empty</span><br>";
                        $failed++;
                    }
                } catch (Exception $e) {
                    echo "<span class='error'>❌ EXCEPTION: " . htmlspecialchars($e->getMessage()) . "</span><br>";
                    $failed++;
                }
                
                echo "</div>";
            endforeach;
            ?>
            
            <h3>Summary</h3>
            <p><strong>Successful Decryptions:</strong> <?php echo $successful; ?> / <?php echo count($votes); ?></p>
            <p><strong>Failed Decryptions:</strong> <?php echo $failed; ?> / <?php echo count($votes); ?></p>
            
            <?php if (!empty($vote_counts)): ?>
                <h3>Vote Counts by Candidate</h3>
                <table>
                    <tr>
                        <th>Candidate ID</th>
                        <th>Candidate Name</th>
                        <th>Votes</th>
                    </tr>
                    <?php foreach ($vote_counts as $cand_id => $count): ?>
                        <?php
                        $cand = array_filter($candidates, function($c) use ($cand_id) {
                            return $c['candidate_id'] == $cand_id;
                        });
                        $cand = reset($cand);
                        ?>
                        <tr>
                            <td><?php echo $cand_id; ?></td>
                            <td><?php echo $cand ? htmlspecialchars($cand['full_name']) : 'Unknown'; ?></td>
                            <td><strong><?php echo $count; ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endif; ?>
            
        <?php else: ?>
            <p class="error">❌ No votes found in encrypted_votes table!</p>
            
            <h3>Possible reasons:</h3>
            <ul>
                <li>No votes have been cast yet</li>
                <li>Votes are in different election_id</li>
                <li>Database connection issue</li>
            </ul>
            
            <h3>Check all votes in database:</h3>
            <?php
            $query = "SELECT election_id, COUNT(*) as count FROM encrypted_votes GROUP BY election_id";
            $stmt = $db->prepare($query);
            $stmt->execute();
            $all_votes = $stmt->fetchAll();
            
            if (count($all_votes) > 0):
            ?>
                <table>
                    <tr>
                        <th>Election ID</th>
                        <th>Vote Count</th>
                    </tr>
                    <?php foreach ($all_votes as $ev): ?>
                        <tr>
                            <td><a href="?election_id=<?php echo $ev['election_id']; ?>"><?php echo $ev['election_id']; ?></a></td>
                            <td><?php echo $ev['count']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php else: ?>
                <p><em>No votes in entire database!</em></p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    
    <div class="card">
        <h2>Actions</h2>
        <p><a href="../public/results.php?election_id=<?php echo $election_id; ?>" style="color: #4472C4;">View Results Page</a></p>
        <p><a href="index.php" style="color: #4472C4;">Back to Admin Dashboard</a></p>
    </div>
</body>
</html>
