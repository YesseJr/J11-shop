<?php
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../classes/Admin.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect(SITE_URL . '/public/login.php');
}

$candidate_id = intval($_GET['id'] ?? 0);

$database = new Database();
$db = $database->connect();
$admin = new Admin($db);

// Get candidate details
$query = "SELECT c.*, e.name as election_name FROM candidates c 
          LEFT JOIN elections e ON c.election_id = e.election_id 
          WHERE c.candidate_id = :id LIMIT 1";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $candidate_id);
$stmt->execute();
$candidate = $stmt->fetch();

if (!$candidate) {
    setFlashMessage('error', 'Candidate not found');
    redirect(SITE_URL . '/admin/candidates/index.php');
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitizeInput($_POST['full_name'] ?? '');
    $party = sanitizeInput($_POST['party_affiliation'] ?? '');
    $biography = sanitizeInput($_POST['biography'] ?? '');
    $manifesto = sanitizeInput($_POST['manifesto'] ?? '');
    $ballot_position = intval($_POST['ballot_position'] ?? 0);
    $status = sanitizeInput($_POST['status'] ?? 'active');
    
    $errors = [];
    
    if (empty($full_name)) $errors[] = 'Candidate name is required';
    if (empty($party)) $errors[] = 'Party is required';
    if ($ballot_position <= 0) $errors[] = 'Invalid ballot position';
    
    // Handle photo upload
    $photo_url = $candidate['photo_url'];
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../../uploads/candidates/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_extension, $allowed)) {
            $new_filename = 'candidate_' . $candidate_id . '_' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $upload_path)) {
                $photo_url = 'uploads/candidates/' . $new_filename;
            } else {
                $errors[] = 'Failed to upload photo';
            }
        } else {
            $errors[] = 'Invalid file type. Only JPG, PNG, GIF allowed';
        }
    }
    
    if (empty($errors)) {
        $data = [
            'full_name' => $full_name,
            'party_affiliation' => $party,
            'biography' => $biography,
            'manifesto' => $manifesto,
            'ballot_position' => $ballot_position,
            'photo_url' => $photo_url,
            'status' => $status
        ];
        
        if ($admin->updateCandidate($candidate_id, $data)) {
            setFlashMessage('success', 'Candidate updated successfully!');
            redirect(SITE_URL . '/admin/candidates/index.php');
        } else {
            $errors[] = 'Failed to update candidate';
        }
    }
    
    $_SESSION['edit_errors'] = $errors;
}

$errors = $_SESSION['edit_errors'] ?? [];
unset($_SESSION['edit_errors']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Candidate | Admin</title>
    <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
    <div class="flag-stripe"></div>
    <div class="container">
        <a href="index.php" class="back-btn">← Back to Candidates</a>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo htmlspecialchars($error); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h1>✏️ Edit Candidate</h1>
            <p style="color: #666; margin-bottom: 20px;">Election: <?php echo htmlspecialchars($candidate['election_name']); ?></p>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label class="form-label">Full Name *</label>
                    <input type="text" name="full_name" class="form-input" 
                           value="<?php echo htmlspecialchars($candidate['full_name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Party Affiliation *</label>
                    <input type="text" name="party_affiliation" class="form-input" 
                           value="<?php echo htmlspecialchars($candidate['party_affiliation']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Ballot Position *</label>
                    <input type="number" name="ballot_position" class="form-input" 
                           value="<?php echo $candidate['ballot_position']; ?>" min="1" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Biography</label>
                    <textarea name="biography" class="form-input" rows="4"><?php echo htmlspecialchars($candidate['biography'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Manifesto</label>
                    <textarea name="manifesto" class="form-input" rows="4"><?php echo htmlspecialchars($candidate['manifesto'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-input">
                        <option value="active" <?php echo $candidate['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="withdrawn" <?php echo $candidate['status'] === 'withdrawn' ? 'selected' : ''; ?>>Withdrawn</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Candidate Photo</label>
                    <?php if ($candidate['photo_url']): ?>
                        <div style="margin-bottom: 10px;">
                            <img src="../../<?php echo htmlspecialchars($candidate['photo_url']); ?>" 
                                 alt="Current photo" style="max-width: 200px; border-radius: 8px;">
                            <p style="color: #666; font-size: 13px; margin-top: 5px;">Current photo</p>
                        </div>
                    <?php endif; ?>
                    <input type="file" name="photo" class="form-input" accept="image/*">
                    <small style="color: #666;">JPG, PNG, or GIF. Max 2MB. Leave empty to keep current photo.</small>
                </div>
                
                <button type="submit" class="btn btn-primary">Update Candidate</button>
            </form>
        </div>
    </div>
</body>
</html>
