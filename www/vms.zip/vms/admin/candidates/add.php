<?php
/**
 * Vote Management System
 * Add Candidate Page
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../classes/Admin.php';

// Check admin access
if (!isLoggedIn() || !isAdmin()) {
    redirect(SITE_URL . '/public/login.php');
}

$election_id = intval($_GET['election_id'] ?? 0);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitizeInput($_POST['full_name'] ?? '');
    $nida_id = sanitizeInput($_POST['nida_id'] ?? '');
    $party = sanitizeInput($_POST['party_affiliation'] ?? '');
    $biography = sanitizeInput($_POST['biography'] ?? '');
    $manifesto = sanitizeInput($_POST['manifesto'] ?? '');
    $ballot_position = intval($_POST['ballot_position'] ?? 0);
    $constituency = sanitizeInput($_POST['constituency'] ?? '');
    $election_id_post = intval($_POST['election_id'] ?? 0);
    
    $errors = [];
    
    if (empty($full_name)) $errors[] = 'Candidate name is required';
    if (empty($nida_id)) $errors[] = 'NIDA ID is required';
    if (empty($party)) $errors[] = 'Party affiliation is required';
    if ($ballot_position <= 0) $errors[] = 'Ballot position must be greater than 0';
    
    // Handle photo upload
    $photo_url = null;
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../../uploads/candidates/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_extension, $allowed)) {
            $new_filename = 'candidate_' . uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $upload_path)) {
                $photo_url = 'uploads/candidates/' . $new_filename;
            }
        }
    }
    
    if (empty($errors)) {
        try {
            $database = new Database();
            $db = $database->connect();
            $admin = new Admin($db);
            
            $candidate_data = [
                'election_id' => $election_id_post,
                'nida_id' => $nida_id,
                'full_name' => $full_name,
                'party_affiliation' => $party,
                'constituency' => $constituency,
                'biography' => $biography,
                'manifesto' => $manifesto,
                'ballot_position' => $ballot_position,
                'photo_url' => null,
                'registered_by' => getCurrentUserId()
            ];
            
            $candidate_id = $admin->addCandidate($candidate_data);
            
            if ($candidate_id) {
                setFlashMessage('success', 'Candidate added successfully!');
                redirect(SITE_URL . '/admin/index.php');
            } else {
                $errors[] = 'Failed to add candidate';
            }
        } catch (Exception $e) {
            $errors[] = 'Error: ' . $e->getMessage();
        }
    }
    $_SESSION['candidate_errors'] = $errors;
}

$errors = $_SESSION['candidate_errors'] ?? [];
unset($_SESSION['candidate_errors']);

// Get elections for dropdown
$database = new Database();
$db = $database->connect();
$admin = new Admin($db);
$elections = $admin->getAllElections();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Candidate | Admin</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        body { background: #f5f5f5; margin: 0; font-family: Arial, sans-serif; }
        .container { max-width: 800px; margin: 40px auto; padding: 20px; }
        .card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        textarea { min-height: 100px; resize: vertical; }
        .back-btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 6px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    <div class="container">
        <a href="../index.php" class="back-btn">← Back to Dashboard</a>
        
        <div class="card">
            <h1>👤 Add New Candidate</h1>
            <p style="color: #666; margin-bottom: 30px;">Enter candidate details below</p>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error" style="margin-bottom: 20px;">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label class="form-label">Select Election <span class="required">*</span></label>
                    <select name="election_id" class="form-input" required>
                        <option value="">Choose Election</option>
                        <?php foreach ($elections as $election): ?>
                            <option value="<?php echo $election['election_id']; ?>" 
                                    <?php echo ($election_id == $election['election_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($election['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Full Name <span class="required">*</span></label>
                        <input type="text" name="full_name" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">NIDA ID <span class="required">*</span></label>
                        <input type="text" name="nida_id" class="form-input" 
                               pattern="\d{8}-\d{5}-\d{5}-\d{2}" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Party Affiliation <span class="required">*</span></label>
                        <input type="text" name="party_affiliation" class="form-input" 
                               placeholder="e.g., Party A" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Constituency <span class="required">*</span></label>
                        <input type="text" name="constituency" class="form-input" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Ballot Position <span class="required">*</span></label>
                    <input type="number" name="ballot_position" class="form-input" 
                           min="1" placeholder="e.g., 1" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Biography</label>
                    <textarea name="biography" class="form-input"></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Manifesto</label>
                    <textarea name="manifesto" class="form-input"></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Candidate Photo (Optional)</label>
                    <input type="file" name="photo" class="form-input" accept="image/*">
                    <small style="color: #666; display: block; margin-top: 5px;">JPG, PNG, or GIF. Max 2MB. Recommended: Square image, at least 300x300px</small>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 20px;">
                    Add Candidate
                </button>
            </form>
        </div>
    </div>
</body>
</html>
