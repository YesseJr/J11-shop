<?php
require_once '../../config/config.php';
require_once '../../config/database.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect(SITE_URL . '/public/login.php');
}

$database = new Database();
$db = $database->connect();

// Get all candidates with election info
$query = "SELECT c.*, e.name as election_name, e.status as election_status
          FROM candidates c
          LEFT JOIN elections e ON c.election_id = e.election_id
          ORDER BY e.start_date DESC, c.ballot_position ASC";
$stmt = $db->prepare($query);
$stmt->execute();
$candidates = $stmt->fetchAll();

$flash_message = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Candidates | Admin</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        body { background: #f5f5f5; margin: 0; font-family: Arial, sans-serif; }
        .container { max-width: 1200px; margin: 40px auto; padding: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; background: white; padding: 20px 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .back-btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 6px; margin-bottom: 20px; }
        .btn-primary { background: #4472C4; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600; }
        .candidates-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        .candidate-card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .candidate-photo { width: 80px; height: 80px; border-radius: 50%; background: #ddd; display: flex; align-items: center; justify-content: center; font-size: 32px; margin-bottom: 15px; }
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #d4edda; color: #155724; }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    <div class="container">
        <a href="../index.php" class="back-btn">← Back to Dashboard</a>
        
        <?php if ($flash_message): ?>
            <div class="alert alert-<?php echo htmlspecialchars($flash_message['type']); ?>">
                <?php echo htmlspecialchars($flash_message['message']); ?>
            </div>
        <?php endif; ?>
        
        <div class="header">
            <h1 style="margin: 0; color: #333;">👥 Manage Candidates</h1>
            <a href="add.php" class="btn-primary">+ Add Candidate</a>
        </div>
        
        <?php if (count($candidates) > 0): ?>
            <div class="candidates-grid">
                <?php foreach ($candidates as $candidate): ?>
                    <div class="candidate-card">
                        <div class="candidate-photo"><?php echo strtoupper(substr($candidate['full_name'], 0, 1)); ?></div>
                        <h3 style="margin: 0 0 10px 0;"><?php echo htmlspecialchars($candidate['full_name']); ?></h3>
                        <p style="margin: 5px 0; color: #666;"><strong>Party:</strong> <?php echo htmlspecialchars($candidate['party_affiliation']); ?></p>
                        <p style="margin: 5px 0; color: #666;"><strong>Election:</strong> <?php echo htmlspecialchars($candidate['election_name']); ?></p>
                        <p style="margin: 5px 0; color: #666;"><strong>Position:</strong> #<?php echo $candidate['ballot_position']; ?></p>
                        <div style="margin-top: 15px;">
                            <a href="edit_candidate.php?id=<?php echo $candidate['candidate_id']; ?>" style="color: #4472C4; text-decoration: none; font-weight: 600;">Edit</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div style="background: white; padding: 60px; border-radius: 12px; text-align: center;">
                <p style="color: #666;">No candidates found. <a href="add.php" style="color: #4472C4; font-weight: bold;">Add your first candidate</a></p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
