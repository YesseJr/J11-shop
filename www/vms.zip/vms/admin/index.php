<?php
/**
 * Vote Management System
 * Admin Dashboard
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/Admin.php';

// Check if user is logged in and is admin
if (!isLoggedIn()) {
    redirect(SITE_URL . '/public/login.php');
}

if (!isAdmin()) {
    setFlashMessage('error', 'Access denied. Admin privileges required.');
    redirect(SITE_URL . '/public/dashboard.php');
}

// Get admin info
$admin_name = $_SESSION['full_name'] ?? 'Admin';

// Create database connection
$database = new Database();
$db = $database->connect();

// Create Admin instance
$admin = new Admin($db);

// Get dashboard statistics
$stats = $admin->getDashboardStats();

// Get all elections
$elections = $admin->getAllElections();

// Get flash message
$flash_message = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | VMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background: #f5f5f5;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #2C3E50;
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h2 {
            margin: 0 0 5px 0;
            font-size: 20px;
        }
        
        .sidebar-header p {
            margin: 0;
            font-size: 13px;
            opacity: 0.8;
        }
        
        .nav-menu {
            margin-top: 20px;
        }
        
        .nav-item {
            display: block;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.1);
            border-left-color: #3498db;
        }
        
        .nav-item i {
            margin-right: 10px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        
        .top-bar {
            background: white;
            padding: 15px 25px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .page-title {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        
        .admin-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .logout-btn {
            background: #e74c3c;
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
        }
        
        .logout-btn:hover {
            background: #c0392b;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
        }
        
        .stat-card.blue::before { background: #3498db; }
        .stat-card.green::before { background: #2ecc71; }
        .stat-card.orange::before { background: #e67e22; }
        .stat-card.purple::before { background: #9b59b6; }
        .stat-card.red::before { background: #e74c3c; }
        
        .stat-icon {
            font-size: 36px;
            margin-bottom: 10px;
        }
        
        .stat-value {
            font-size: 32px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            color: #666;
        }
        
        .section-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-title {
            margin: 0;
            font-size: 20px;
            color: #333;
        }
        
        .btn-primary {
            background: #3498db;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            display: inline-block;
        }
        
        .btn-primary:hover {
            background: #2980b9;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: #f8f9fa;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            font-weight: 600;
            color: #333;
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .status-draft { background: #f0f0f0; color: #666; }
        .status-active { background: #d4edda; color: #155724; }
        .status-closed { background: #fff3cd; color: #856404; }
        .status-certified { background: #d1ecf1; color: #0c5460; }
        
        .action-btn {
            padding: 5px 10px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 13px;
            margin-right: 5px;
            display: inline-block;
        }
        
        .btn-edit { background: #3498db; color: white; }
        .btn-view { background: #2ecc71; color: white; }
        .btn-delete { background: #e74c3c; color: white; }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    
    <div class="admin-container">
        
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>🛡️ Admin Panel</h2>
                <p><?php echo htmlspecialchars($admin_name); ?></p>
            </div>
            
            <nav class="nav-menu">
                <a href="index.php" class="nav-item active">📊 Dashboard</a>
                <a href="elections/index.php" class="nav-item">🗳️ Elections</a>
                <a href="candidates/index.php" class="nav-item">👥 Candidates</a>
                <a href="voters/index.php" class="nav-item">📋 Voters</a>
                <a href="../public/results.php" class="nav-item">📈 Results</a>
                <a href="../public/dashboard.php" class="nav-item">🏠 Voter View</a>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            
            <!-- Top Bar -->
            <div class="top-bar">
                <h1 class="page-title">Dashboard Overview</h1>
                <div class="admin-info">
                    <span style="color: #666;">👤 <?php echo htmlspecialchars($admin_name); ?></span>
                    <a href="../public/logout.php" class="logout-btn">Logout</a>
                </div>
            </div>
            
            <!-- Flash Messages -->
            <?php if ($flash_message): ?>
                <div class="alert alert-<?php echo htmlspecialchars($flash_message['type']); ?>" style="margin-bottom: 20px;">
                    <span><?php echo $flash_message['type'] === 'success' ? '✓' : '⚠️'; ?></span>
                    <span><?php echo htmlspecialchars($flash_message['message']); ?></span>
                </div>
            <?php endif; ?>
            
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card blue">
                    <div class="stat-icon">🗳️</div>
                    <div class="stat-value"><?php echo number_format($stats['total_elections']); ?></div>
                    <div class="stat-label">Total Elections</div>
                </div>
                
                <div class="stat-card green">
                    <div class="stat-icon">✅</div>
                    <div class="stat-value"><?php echo number_format($stats['active_elections']); ?></div>
                    <div class="stat-label">Active Elections</div>
                </div>
                
                <div class="stat-card orange">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value"><?php echo number_format($stats['total_voters']); ?></div>
                    <div class="stat-label">Registered Voters</div>
                </div>
                
                <div class="stat-card purple">
                    <div class="stat-icon">📊</div>
                    <div class="stat-value"><?php echo number_format($stats['total_votes']); ?></div>
                    <div class="stat-label">Total Votes Cast</div>
                </div>
                
                <div class="stat-card red">
                    <div class="stat-icon">🎯</div>
                    <div class="stat-value"><?php echo number_format($stats['total_candidates']); ?></div>
                    <div class="stat-label">Total Candidates</div>
                </div>
            </div>
            
            <!-- Elections List -->
            <div class="section-card">
                <div class="section-header">
                    <h2 class="section-title">Recent Elections</h2>
                    <a href="elections/create.php" class="btn-primary">+ Create Election</a>
                </div>
                
                <?php if (count($elections) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Election Name</th>
                                <th>Constituency</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Status</th>
                                <th>Votes</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($elections as $election): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($election['name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($election['constituency']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($election['start_date'])); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($election['end_date'])); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($election['status']); ?>">
                                            <?php echo ucfirst($election['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo number_format($election['votes_cast']); ?> / <?php echo number_format($election['total_voters']); ?></td>
                                    <td>
                                        <a href="elections/view.php?id=<?php echo $election['election_id']; ?>" class="action-btn btn-view">View</a>
                                        <a href="elections/edit.php?id=<?php echo $election['election_id']; ?>" class="action-btn btn-edit">Edit</a>
                                        <?php if ($election['status'] === 'active'): ?>
                                            <a href="elections/close.php?id=<?php echo $election['election_id']; ?>" class="action-btn btn-delete" 
                                               onclick="return confirm('Close this election?')">Close</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p style="text-align: center; padding: 40px; color: #666;">
                        No elections found. <a href="elections/create.php">Create your first election</a>
                    </p>
                <?php endif; ?>
            </div>
            
        </div>
        
    </div>
</body>
</html>
