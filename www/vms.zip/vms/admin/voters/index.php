<?php
require_once '../../config/config.php';
require_once '../../config/database.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect(SITE_URL . '/public/login.php');
}

$database = new Database();
$db = $database->connect();

// Handle adding all voters to election
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_all_voters'])) {
    $election_id = intval($_POST['election_id']);
    $constituency = sanitizeInput($_POST['constituency']);
    
    // Add all voters to this election
    $query = "INSERT INTO voters_list (user_id, election_id, constituency, is_eligible, has_voted)
              SELECT user_id, :election_id, :constituency, TRUE, FALSE
              FROM users
              WHERE role = 'voter'
              AND user_id NOT IN (SELECT user_id FROM voters_list WHERE election_id = :election_id2)";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':election_id', $election_id);
    $stmt->bindParam(':election_id2', $election_id);
    $stmt->bindParam(':constituency', $constituency);
    
    if ($stmt->execute()) {
        $added = $stmt->rowCount();
        setFlashMessage('success', "Added {$added} voters to election!");
    } else {
        setFlashMessage('error', 'Failed to add voters');
    }
    
    redirect(SITE_URL . '/admin/voters/index.php');
}

// Get all elections
$query = "SELECT * FROM elections ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$elections = $stmt->fetchAll();

// Get all voters
$query = "SELECT * FROM users WHERE role = 'voter' ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$voters = $stmt->fetchAll();

$flash_message = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Voters | Admin</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        body { background: #f5f5f5; margin: 0; font-family: Arial, sans-serif; }
        .container { max-width: 1200px; margin: 40px auto; padding: 20px; }
        .card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 30px; }
        .back-btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 6px; margin-bottom: 20px; }
        .btn-primary { background: #4472C4; color: white; padding: 12px 24px; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; }
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-weight: 600; margin-bottom: 8px; }
        .form-input, .form-select { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; font-weight: 600; }
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #d4edda; color: #155724; }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    <div class="container">
        <a href="../index.php" class="back-btn">← Back to Dashboard</a>
        
        <?php if ($flash_message): ?>
            <div class="alert alert-<?php echo htmlspecialchars($flash_message['type']); ?>">
                <?php echo htmlspecialchars($flash_message['message']); ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h1 style="margin: 0 0 20px 0;">📋 Manage Voters</h1>
            
            <h2 style="font-size: 20px; color: #333; margin-bottom: 15px;">Add All Voters to Election</h2>
            <p style="color: #666; margin-bottom: 20px;">This will add all registered voters to the selected election.</p>
            
            <form method="POST">
                <div class="form-group">
                    <label class="form-label">Select Election:</label>
                    <select name="election_id" class="form-select" required>
                        <option value="">Choose Election</option>
                        <?php foreach ($elections as $election): ?>
                            <option value="<?php echo $election['election_id']; ?>">
                                <?php echo htmlspecialchars($election['name']); ?> - <?php echo ucfirst($election['status']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Constituency:</label>
                    <input type="text" name="constituency" class="form-input" placeholder="e.g., Mbinga Urban" required>
                </div>
                
                <button type="submit" name="add_all_voters" class="btn-primary">
                    ✓ Add All Voters to Election
                </button>
            </form>
        </div>
        
        <div class="card">
            <h2 style="margin: 0 0 20px 0;">All Registered Voters (<?php echo count($voters); ?>)</h2>
            
            <?php if (count($voters) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>NIDA ID</th>
                            <th>Status</th>
                            <th>Registered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($voters as $voter): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($voter['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($voter['email']); ?></td>
                                <td><?php echo htmlspecialchars($voter['phone']); ?></td>
                                <td><?php echo htmlspecialchars($voter['nida_id'] ?? $voter['vote_id'] ?? 'N/A'); ?></td>
                                <td><?php echo ucfirst($voter['account_status']); ?></td>
                                <td><?php echo date('M j, Y', strtotime($voter['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="text-align: center; color: #666; padding: 40px;">No voters registered yet.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
