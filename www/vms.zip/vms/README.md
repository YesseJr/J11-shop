# 🗳️ VOTE MANAGEMENT SYSTEM - COMPLETE SETUP GUIDE

**Author:** Waython Yesse Luoga  
**Reg No:** 230229401347  
**Class:** OD23IT

---

## 📦 PACKAGE CONTENTS

This package contains a **complete foundation** for the Vote Management System:

### ✅ **What's Included:**

```
vms-fresh/
├── sql/
│   └── schema.sql                    ✅ Complete database schema (9 tables)
│
├── config/
│   ├── database.php                  ✅ Database connection class
│   └── config.php                    ✅ Site configuration & helper functions
│
├── classes/
│   └── User.php                      ✅ Complete User class (registration, auth)
│
├── assets/
│   ├── css/
│   │   └── style.css                 ✅ Professional CSS
│   ├── js/
│   │   └── registration.js           ✅ Form validation JavaScript
│   └── images/                       ⚠️  ADD YOUR IMAGES HERE
│
├── public/
│   ├── register.php                  ✅ Registration page (HTML)
│   └── register_process.php          ✅ Backend processing
│
└── uploads/
    └── candidates/                   📁 For candidate photos
```

---

## 🚀 QUICK START (5 STEPS)

### **STEP 1: Install XAMPP/WAMP/MAMP**

Download and install:
- **Windows:** XAMPP from https://www.apachefriends.org
- **Mac:** MAMP from https://www.mamp.info
- **Linux:** `sudo apt install apache2 mysql-server php`

---

### **STEP 2: Extract Project**

```bash
# Copy project to web server directory

# XAMPP (Windows):
C:\xampp\htdocs\vms-fresh\

# XAMPP (Mac):
/Applications/XAMPP/htdocs/vms-fresh/

# XAMPP (Linux):
/opt/lampp/htdocs/vms-fresh/

# MAMP (Mac):
/Applications/MAMP/htdocs/vms-fresh/

# Linux Apache:
/var/www/html/vms-fresh/
```

---

### **STEP 3: Create Database**

**Option A: Using phpMyAdmin**

1. Open http://localhost/phpmyadmin
2. Click "Import" tab
3. Choose file: `vms-fresh/sql/schema.sql`
4. Click "Go"
5. ✅ Database created with sample data!

**Option B: Using Command Line**

```bash
# Login to MySQL
mysql -u root -p

# Run the schema
source /path/to/vms-fresh/sql/schema.sql

# Or copy-paste the SQL file contents
```

---

### **STEP 4: Configure Database Connection**

Edit `config/database.php` (lines 13-16):

```php
private $host = 'localhost';           // Keep as localhost
private $db_name = 'vote_management_system';  // Keep as is
private $username = 'root';            // Change if different
private $password = '';                // Add password if you have one
```

**Test connection:**
```
http://localhost/vms-fresh/config/database.php
```

You should see: ✅ "Database connection successful!"

---

### **STEP 5: Add Images**

Add these 2 images to `assets/images/`:

1. **emblem.png** - Tanzania national emblem (200x200px)
2. **bg-kilimanjaro.jpg** - Mount Kilimanjaro photo (1920x1080px)

**Where to get them:**
- Tanzania Emblem: Search "Tanzania coat of arms PNG"
- Kilimanjaro: Free from Unsplash.com or Pexels.com

---

## 🎯 TEST THE SYSTEM

### **Test Registration:**

1. Open: `http://localhost/vms-fresh/public/register.php`
2. Fill in the form:
   - NIDA ID: `20000101-12345-67890-12`
   - Full Name: Your Name
   - DOB: `2000-01-01` (must be 18+)
   - Phone: `+255 712 345 678`
   - Email: `test@example.com`
   - Password: `Test@12345` (meets all requirements)
3. Click "Register Account"
4. ✅ Success! You should see: "Registration successful!"

### **Verify in Database:**

```sql
-- Check if user was created
SELECT * FROM users ORDER BY created_at DESC LIMIT 1;

-- You should see your newly registered user!
```

---

## 📊 DATABASE STRUCTURE

### **9 Tables Created:**

1. **users** - All user accounts (voters, admins, observers)
2. **elections** - Election information
3. **candidates** - Candidate details
4. **voters_list** - Links voters to specific elections
5. **encrypted_votes** - Encrypted votes (NO voter ID for anonymity)
6. **vote_receipts** - Proof of voting receipts
7. **audit_logs** - Complete system activity log
8. **otp_codes** - One-time passwords for MFA
9. **sessions** - Active user sessions

### **Sample Users Included:**

| Email | Password | Role |
|-------|----------|------|
| admin@votems.go.tz | Admin@123 | admin |
| voter@example.com | Voter@123 | voter |

---

## ✨ FEATURES WORKING RIGHT NOW

### **Registration Page:**
✅ Beautiful UI matching Tanzania branding  
✅ Tab switching (NIDA ID / VOTE ID)  
✅ Real-time form validation  
✅ Password strength indicator  
✅ Password requirements checker  
✅ Phone number auto-formatting  
✅ Age verification (18+)  
✅ NIDA ID format validation  
✅ Email validation  
✅ Responsive design (mobile to desktop)  

### **Backend Processing:**
✅ Complete server-side validation  
✅ Duplicate checking (NIDA, VOTE ID, Email)  
✅ Password hashing (Bcrypt cost 12)  
✅ SQL injection prevention  
✅ Session-based error handling  
✅ Flash messages  
✅ Secure redirects  

### **Security:**
✅ Prepared statements (SQL injection proof)  
✅ Password hashing (Bcrypt)  
✅ Input sanitization  
✅ XSS protection  
✅ Session security  
✅ IP hashing for privacy  

---

## 🔧 CONFIGURATION OPTIONS

### **In `config/config.php`:**

```php
// Change site URL for production
define('SITE_URL', 'http://localhost/vms-fresh');

// Password requirements
define('MIN_PASSWORD_LENGTH', 8);
define('MAX_LOGIN_ATTEMPTS', 5);
define('ACCOUNT_LOCKOUT_DURATION', 30); // minutes

// Session timeout
define('SESSION_TIMEOUT', 1800); // 30 minutes

// OTP settings
define('OTP_LENGTH', 6);
define('OTP_EXPIRY', 5); // minutes
```

---

## 🐛 TROUBLESHOOTING

### **Problem: Database connection failed**

**Solution:**
1. Check MySQL is running: `sudo service mysql status`
2. Verify credentials in `config/database.php`
3. Check database exists: `SHOW DATABASES;`
4. Test connection: Open `http://localhost/vms-fresh/config/database.php`

---

### **Problem: Registration shows "undefined function"**

**Solution:**
1. Ensure `config/config.php` is included first
2. Check `classes/User.php` exists
3. Verify autoloader is working

---

### **Problem: Images not showing**

**Solution:**
1. Check file paths in HTML: `../assets/images/`
2. Verify images exist in correct folder
3. Check file permissions: `chmod 755 assets/images/`

---

### **Problem: Form submission does nothing**

**Solution:**
1. Check form action points to `register_process.php`
2. Verify PHP is processing files (not downloading)
3. Check error logs: `tail -f /var/log/apache2/error.log`

---

## 📝 WHAT TO BUILD NEXT

Now that registration is complete, build these in order:

### **Next: Login Page** ✅ Recommended

Files to create:
1. `public/login.php` - Login form
2. `public/login_process.php` - Authentication
3. `public/logout.php` - Session cleanup

**I can create these next if you want!**

---

### **Then: Voter Dashboard**

Files to create:
1. `public/dashboard.php` - Main voter interface
2. Show eligibility status
3. Display elections
4. Navigation menu

---

### **Then: Voting Flow**

Files to create:
1. `public/vote.php` - Candidate selection
2. `public/vote-confirm.php` - Confirmation
3. `public/vote-success.php` - Success screen
4. `classes/Vote.php` - Voting logic
5. `classes/Encryption.php` - Vote encryption

---

## 📚 HELPER FUNCTIONS AVAILABLE

In `config/config.php`:

```php
// Input sanitization
sanitizeInput($data)

// Redirects
redirect($url)

// User checks
isLoggedIn()
isAdmin()
getCurrentUserId()
getCurrentUserRole()

// Flash messages
setFlashMessage($type, $message)
getFlashMessage()

// CSRF protection
generateCSRFToken()
verifyCSRFToken($token)

// Date functions
formatDate($date, $format)
isEligibleAge($dob)

// Security
hashIP($ip)
```

---

## 🎓 CODE STRUCTURE

### **Database Class (config/database.php)**
- Handles all database connections
- Uses PDO with prepared statements
- Error handling included

### **User Class (classes/User.php)**
- `register()` - Create new user
- `getUserById()` - Fetch user data
- `emailExists()` - Check duplicate email
- `nidaExists()` - Check duplicate NIDA ID
- `hashPassword()` - Bcrypt hashing
- `verifyPassword()` - Password checking
- `lockAccount()` - Account locking
- Many more methods...

### **Config File (config/config.php)**
- Site-wide settings
- Helper functions
- Session management
- Autoloader for classes

---

## 🔒 SECURITY BEST PRACTICES

✅ **Implemented:**
- Prepared statements (SQL injection proof)
- Password hashing with bcrypt
- Input sanitization
- Session security
- CSRF token generation
- IP address hashing
- Account lockout after failed attempts

⚠️ **TODO for Production:**
- Enable HTTPS/SSL
- Change database password
- Implement rate limiting
- Add CAPTCHA to registration
- Enable email verification
- Set up SMS OTP
- Regular security audits

---

## 📞 SUPPORT

If you encounter issues:

1. Check error logs
2. Test database connection
3. Verify file permissions
4. Review configuration settings

---

## 🎉 SUCCESS CHECKLIST

- [ ] Database created successfully
- [ ] Connection test passes
- [ ] Registration page loads
- [ ] Can register new user
- [ ] User appears in database
- [ ] Form validation works
- [ ] Password strength works
- [ ] Error messages display

**All checked? You're ready to build the login page!** 🚀

---

**Ready for the next step? Let me know and I'll create the login page!**

