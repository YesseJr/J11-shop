// ========================================
// VOTE MANAGEMENT SYSTEM - REGISTRATION JS
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    
    // === TAB SWITCHING ===
    const tabButtons = document.querySelectorAll('.tab-button');
    const nidaFields = document.getElementById('nida-fields');
    const voteIdFields = document.getElementById('voteid-fields');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            tabButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            // Toggle field visibility
            if (this.dataset.tab === 'nida') {
                nidaFields?.classList.remove('hidden');
                voteIdFields?.classList.add('hidden');
            } else {
                nidaFields?.classList.add('hidden');
                voteIdFields?.classList.remove('hidden');
            }
        });
    });
    
    // === PASSWORD VISIBILITY TOGGLE ===
    const toggleButtons = document.querySelectorAll('.toggle-password');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.previousElementSibling;
            const icon = this.querySelector('i') || this;
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.textContent = '👁️';
            } else {
                input.type = 'password';
                icon.textContent = '👁️‍🗨️';
            }
        });
    });
    
    // === PASSWORD STRENGTH CHECKER ===
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const strengthBars = document.querySelectorAll('.strength-bar');
    const strengthText = document.querySelector('.strength-text');
    const requirements = document.querySelectorAll('.requirement-item');
    
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            const strength = checkPasswordStrength(password);
            updatePasswordStrength(strength);
            checkPasswordRequirements(password);
        });
    }
    
    function checkPasswordStrength(password) {
        let strength = 0;
        
        if (password.length >= 8) strength++;
        if (password.match(/[a-z]/)) strength++;
        if (password.match(/[A-Z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^a-zA-Z0-9]/)) strength++;
        
        return strength;
    }
    
    function updatePasswordStrength(strength) {
        strengthBars.forEach((bar, index) => {
            if (index < strength) {
                bar.classList.add('active');
                if (strength <= 2) {
                    bar.classList.remove('medium', 'strong');
                } else if (strength <= 3) {
                    bar.classList.add('medium');
                    bar.classList.remove('strong');
                } else {
                    bar.classList.add('strong');
                    bar.classList.remove('medium');
                }
            } else {
                bar.classList.remove('active', 'medium', 'strong');
            }
        });
        
        // Update strength text
        if (strengthText) {
            if (strength <= 2) {
                strengthText.textContent = 'Password strength: Weak';
                strengthText.style.color = '#F44336';
            } else if (strength <= 3) {
                strengthText.textContent = 'Password strength: Medium';
                strengthText.style.color = '#FFC107';
            } else {
                strengthText.textContent = 'Password strength: Strong';
                strengthText.style.color = '#4CAF50';
            }
        }
    }
    
    function checkPasswordRequirements(password) {
        // Check minimum length
        const lengthReq = document.getElementById('req-length');
        if (password.length >= 8) {
            lengthReq?.classList.add('met');
        } else {
            lengthReq?.classList.remove('met');
        }
        
        // Check uppercase
        const upperReq = document.getElementById('req-upper');
        if (password.match(/[A-Z]/)) {
            upperReq?.classList.add('met');
        } else {
            upperReq?.classList.remove('met');
        }
        
        // Check lowercase
        const lowerReq = document.getElementById('req-lower');
        if (password.match(/[a-z]/)) {
            lowerReq?.classList.add('met');
        } else {
            lowerReq?.classList.remove('met');
        }
        
        // Check number
        const numberReq = document.getElementById('req-number');
        if (password.match(/[0-9]/)) {
            numberReq?.classList.add('met');
        } else {
            numberReq?.classList.remove('met');
        }
        
        // Check special character
        const specialReq = document.getElementById('req-special');
        if (password.match(/[^a-zA-Z0-9]/)) {
            specialReq?.classList.add('met');
        } else {
            specialReq?.classList.remove('met');
        }
    }
    
    // === CONFIRM PASSWORD VALIDATION ===
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            validatePasswordMatch();
        });
    }
    
    function validatePasswordMatch() {
        const password = passwordInput?.value || '';
        const confirmPassword = confirmPasswordInput?.value || '';
        const errorMsg = document.getElementById('confirm-password-error');
        
        if (confirmPassword.length > 0) {
            if (password === confirmPassword) {
                confirmPasswordInput.classList.remove('error');
                confirmPasswordInput.classList.add('success');
                if (errorMsg) {
                    errorMsg.classList.remove('show');
                }
            } else {
                confirmPasswordInput.classList.add('error');
                confirmPasswordInput.classList.remove('success');
                if (errorMsg) {
                    errorMsg.textContent = 'Passwords do not match';
                    errorMsg.classList.add('show');
                }
            }
        }
    }
    
    // === REAL-TIME FIELD VALIDATION ===
    
    // NIDA ID Validation
    const nidaInput = document.getElementById('nida_id');
    if (nidaInput) {
        nidaInput.addEventListener('blur', function() {
            validateNidaId(this.value);
        });
    }
    
    function validateNidaId(nidaId) {
        const errorMsg = document.getElementById('nida-error');
        const pattern = /^\d{8}-\d{5}-\d{5}-\d{2}$/;
        
        if (nidaId.length === 0) {
            nidaInput.classList.remove('error', 'success');
            if (errorMsg) errorMsg.classList.remove('show');
            return;
        }
        
        if (!pattern.test(nidaId)) {
            nidaInput.classList.add('error');
            nidaInput.classList.remove('success');
            if (errorMsg) {
                errorMsg.textContent = 'Invalid NIDA ID format (YYYYMMDD-XXXXX-XXXXX-XX)';
                errorMsg.classList.add('show');
            }
        } else {
            nidaInput.classList.remove('error');
            nidaInput.classList.add('success');
            if (errorMsg) errorMsg.classList.remove('show');
        }
    }
    
    // Email Validation
    const emailInput = document.getElementById('email');
    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            validateEmail(this.value);
        });
    }
    
    function validateEmail(email) {
        const errorMsg = document.getElementById('email-error');
        const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (email.length === 0) {
            emailInput.classList.remove('error', 'success');
            if (errorMsg) errorMsg.classList.remove('show');
            return;
        }
        
        if (!pattern.test(email)) {
            emailInput.classList.add('error');
            emailInput.classList.remove('success');
            if (errorMsg) {
                errorMsg.textContent = 'Please enter a valid email address';
                errorMsg.classList.add('show');
            }
        } else {
            emailInput.classList.remove('error');
            emailInput.classList.add('success');
            if (errorMsg) errorMsg.classList.remove('show');
        }
    }
    
    // Phone Number Validation
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        // Auto-format phone number
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, ''); // Remove non-digits
            
            // Ensure it starts with +255
            if (!value.startsWith('255')) {
                value = '255' + value;
            }
            
            // Limit to 12 digits (255 + 9 digits)
            value = value.substring(0, 12);
            
            // Format as +255 XXX XXX XXX
            if (value.length > 3) {
                value = '+' + value.substring(0, 3) + ' ' + value.substring(3);
            }
            if (value.length > 8) {
                value = value.substring(0, 8) + ' ' + value.substring(8);
            }
            if (value.length > 12) {
                value = value.substring(0, 12) + ' ' + value.substring(12);
            }
            
            e.target.value = value;
        });
        
        phoneInput.addEventListener('blur', function() {
            validatePhone(this.value);
        });
    }
    
    function validatePhone(phone) {
        const errorMsg = document.getElementById('phone-error');
        const digitsOnly = phone.replace(/\D/g, '');
        
        if (phone.length === 0) {
            phoneInput.classList.remove('error', 'success');
            if (errorMsg) errorMsg.classList.remove('show');
            return;
        }
        
        if (digitsOnly.length !== 12 || !digitsOnly.startsWith('255')) {
            phoneInput.classList.add('error');
            phoneInput.classList.remove('success');
            if (errorMsg) {
                errorMsg.textContent = 'Please enter a valid Tanzanian phone number';
                errorMsg.classList.add('show');
            }
        } else {
            phoneInput.classList.remove('error');
            phoneInput.classList.add('success');
            if (errorMsg) errorMsg.classList.remove('show');
        }
    }
    
    // Date of Birth Validation (Age 18+)
    const dobInput = document.getElementById('dob');
    if (dobInput) {
        dobInput.addEventListener('change', function() {
            validateAge(this.value);
        });
    }
    
    function validateAge(dob) {
        const errorMsg = document.getElementById('dob-error');
        
        if (!dob) {
            dobInput.classList.remove('error', 'success');
            if (errorMsg) errorMsg.classList.remove('show');
            return;
        }
        
        const today = new Date();
        const birthDate = new Date(dob);
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        
        if (age < 18) {
            dobInput.classList.add('error');
            dobInput.classList.remove('success');
            if (errorMsg) {
                errorMsg.textContent = 'You must be at least 18 years old to register';
                errorMsg.classList.add('show');
            }
        } else {
            dobInput.classList.remove('error');
            dobInput.classList.add('success');
            if (errorMsg) errorMsg.classList.remove('show');
        }
    }
    
    // === FORM SUBMISSION ===
    const registrationForm = document.getElementById('registration-form');
    
    if (registrationForm) {
        registrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validate all fields
            let isValid = true;
            
            const nidaId = document.getElementById('nida_id')?.value;
            const email = document.getElementById('email')?.value;
            const phone = document.getElementById('phone')?.value;
            const dob = document.getElementById('dob')?.value;
            const password = document.getElementById('password')?.value;
            const confirmPassword = document.getElementById('confirm_password')?.value;
            
            // Run validations
            if (nidaId) validateNidaId(nidaId);
            if (email) validateEmail(email);
            if (phone) validatePhone(phone);
            if (dob) validateAge(dob);
            
            // Check if any field has error class
            const errorFields = document.querySelectorAll('.form-input.error');
            if (errorFields.length > 0) {
                isValid = false;
            }
            
            // Check password match
            if (password !== confirmPassword) {
                isValid = false;
                validatePasswordMatch();
            }
            
            // Check password strength
            if (checkPasswordStrength(password) < 3) {
                isValid = false;
                alert('Password is too weak. Please use a stronger password.');
                return;
            }
            
            if (isValid) {
                // Show loading state
                const submitBtn = this.querySelector('button[type="submit"]');
                submitBtn.classList.add('loading');
                submitBtn.disabled = true;
                
                // Submit form
                this.submit();
            } else {
                // Show error message
                showAlert('error', 'Please correct the errors in the form before submitting.');
            }
        });
    }
    
    // === ALERT FUNCTION ===
    function showAlert(type, message) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        alertDiv.innerHTML = `
            <span>${type === 'error' ? '⚠️' : '✓'}</span>
            <span>${message}</span>
        `;
        
        const form = document.getElementById('registration-form');
        form.insertBefore(alertDiv, form.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
});
