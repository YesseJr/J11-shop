// ========================================
// VOTE MANAGEMENT SYSTEM - LOGIN JS
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    
    // === TAB SWITCHING ===
    const tabButtons = document.querySelectorAll('.tab-button');
    const nidaFields = document.getElementById('nida-fields');
    const voteIdFields = document.getElementById('voteid-fields');
    const nidaInput = document.getElementById('nida_id');
    const voteIdInput = document.getElementById('vote_id');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            tabButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            // Toggle field visibility
            if (this.dataset.tab === 'nida') {
                nidaFields?.classList.remove('hidden');
                voteIdFields?.classList.add('hidden');
                // Make NIDA required, VOTE ID not required
                if (nidaInput) nidaInput.required = true;
                if (voteIdInput) voteIdInput.required = false;
            } else {
                nidaFields?.classList.add('hidden');
                voteIdFields?.classList.remove('hidden');
                // Make VOTE ID required, NIDA not required
                if (voteIdInput) voteIdInput.required = true;
                if (nidaInput) nidaInput.required = false;
            }
        });
    });
    
    // === PASSWORD VISIBILITY TOGGLE ===
    const toggleButtons = document.querySelectorAll('.toggle-password');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.previousElementSibling;
            const icon = this;
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.textContent = '👁️';
            } else {
                input.type = 'password';
                icon.textContent = '👁️‍🗨️';
            }
        });
    });
    
    // === NIDA ID VALIDATION ===
    if (nidaInput) {
        nidaInput.addEventListener('blur', function() {
            validateNidaId(this.value);
        });
        
        nidaInput.addEventListener('input', function() {
            // Clear error on input
            const errorMsg = document.getElementById('nida-error');
            if (errorMsg) errorMsg.classList.remove('show');
            this.classList.remove('error');
        });
    }
    
    function validateNidaId(nidaId) {
        const errorMsg = document.getElementById('nida-error');
        const pattern = /^\d{8}-\d{5}-\d{5}-\d{2}$/;
        
        if (nidaId.length === 0) {
            nidaInput.classList.remove('error', 'success');
            if (errorMsg) errorMsg.classList.remove('show');
            return true;
        }
        
        if (!pattern.test(nidaId)) {
            nidaInput.classList.add('error');
            nidaInput.classList.remove('success');
            if (errorMsg) {
                errorMsg.textContent = 'Invalid NIDA ID format (YYYYMMDD-XXXXX-XXXXX-XX)';
                errorMsg.classList.add('show');
            }
            return false;
        } else {
            nidaInput.classList.remove('error');
            nidaInput.classList.add('success');
            if (errorMsg) errorMsg.classList.remove('show');
            return true;
        }
    }
    
    // === VOTE ID VALIDATION ===
    if (voteIdInput) {
        voteIdInput.addEventListener('blur', function() {
            validateVoteId(this.value);
        });
        
        voteIdInput.addEventListener('input', function() {
            // Clear error on input
            const errorMsg = document.getElementById('voteid-error');
            if (errorMsg) errorMsg.classList.remove('show');
            this.classList.remove('error');
        });
    }
    
    function validateVoteId(voteId) {
        const errorMsg = document.getElementById('voteid-error');
        
        if (voteId.length === 0) {
            voteIdInput.classList.remove('error', 'success');
            if (errorMsg) errorMsg.classList.remove('show');
            return true;
        }
        
        if (voteId.length < 10) {
            voteIdInput.classList.add('error');
            voteIdInput.classList.remove('success');
            if (errorMsg) {
                errorMsg.textContent = 'VOTE ID is too short';
                errorMsg.classList.add('show');
            }
            return false;
        } else {
            voteIdInput.classList.remove('error');
            voteIdInput.classList.add('success');
            if (errorMsg) errorMsg.classList.remove('show');
            return true;
        }
    }
    
    // === PASSWORD VALIDATION ===
    const passwordInput = document.getElementById('password');
    
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            // Clear error on input
            const errorMsg = document.getElementById('password-error');
            if (errorMsg) errorMsg.classList.remove('show');
            this.classList.remove('error');
        });
    }
    
    function validatePassword(password) {
        const errorMsg = document.getElementById('password-error');
        
        if (password.length === 0) {
            passwordInput.classList.add('error');
            if (errorMsg) {
                errorMsg.textContent = 'Password is required';
                errorMsg.classList.add('show');
            }
            return false;
        }
        
        if (password.length < 6) {
            passwordInput.classList.add('error');
            if (errorMsg) {
                errorMsg.textContent = 'Password is too short';
                errorMsg.classList.add('show');
            }
            return false;
        }
        
        passwordInput.classList.remove('error');
        if (errorMsg) errorMsg.classList.remove('show');
        return true;
    }
    
    // === FORM SUBMISSION ===
    const loginForm = document.getElementById('login-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get current login method
            const loginMethod = document.getElementById('login_method').value;
            const password = passwordInput.value;
            
            let isValid = true;
            
            // Validate based on login method
            if (loginMethod === 'nida') {
                const nidaId = nidaInput?.value || '';
                if (!nidaId) {
                    showFieldError('nida_id', 'NIDA ID is required');
                    isValid = false;
                } else if (!validateNidaId(nidaId)) {
                    isValid = false;
                }
            } else {
                const voteId = voteIdInput?.value || '';
                if (!voteId) {
                    showFieldError('vote_id', 'VOTE ID is required');
                    isValid = false;
                } else if (!validateVoteId(voteId)) {
                    isValid = false;
                }
            }
            
            // Validate password
            if (!validatePassword(password)) {
                isValid = false;
            }
            
            if (isValid) {
                // Show loading state
                const submitBtn = this.querySelector('button[type="submit"]');
                submitBtn.classList.add('loading');
                submitBtn.disabled = true;
                
                // Submit form
                this.submit();
            } else {
                // Scroll to first error
                const firstError = document.querySelector('.form-input.error');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
            }
        });
    }
    
    // === HELPER FUNCTIONS ===
    function showFieldError(fieldId, message) {
        const field = document.getElementById(fieldId);
        const errorMsgId = fieldId + '-error';
        const errorMsg = document.getElementById(errorMsgId);
        
        if (field) {
            field.classList.add('error');
            field.classList.remove('success');
        }
        
        if (errorMsg) {
            errorMsg.textContent = message;
            errorMsg.classList.add('show');
        }
    }
    
    // Auto-hide alerts after 10 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.5s';
            setTimeout(() => {
                alert.style.display = 'none';
            }, 500);
        }, 10000);
    });
});
