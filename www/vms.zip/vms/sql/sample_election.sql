-- ========================================
-- SAMPLE ELECTION DATA FOR TESTING
-- ========================================
-- Run this after setting up the main schema

USE vms;

-- Insert sample election
INSERT INTO elections (
    election_id,
    name,
    description,
    election_type,
    constituency,
    start_date,
    end_date,
    status,
    total_voters,
    created_by
) VALUES (
    1,
    'Mbinga Urban - Village Chairperson Election 2026',
    'Election for Village/Street Chairperson in Mbinga Urban constituency',
    'Village Chairperson',
    'Mbinga Urban',
    '2026-03-10 06:00:00',
    '2026-03-11 18:00:00',
    'active',
    1500,
    1  -- Admin user
);

-- Insert sample candidates
INSERT INTO candidates (
    candidate_id,
    election_id,
    nida_id,
    full_name,
    party_affiliation,
    constituency,
    biography,
    ballot_position,
    registered_by
) VALUES
(1, 1, '19800410-11111-22222-33', 'Joseph Komba', 'Party A', 'Mbinga Urban',
 'Joseph Komba is a dedicated community leader with 15 years of experience in local governance.',
 1, 1),

(2, 1, '19850620-33333-44444-55', 'Anna Mwafula', 'Party B', 'Mbinga Urban',
 'Anna Mwafula is a passionate advocate for education and women empowerment in our community.',
 2, 1),

(3, 1, '19900315-66666-77777-88', 'Michael Ntembo', 'Party C', 'Mbinga Urban',
 'Michael Ntembo brings fresh ideas and modern solutions to traditional community challenges.',
 3, 1);

-- Add registered voters to voters_list
-- User ID 2 (sample voter) for election 1
INSERT INTO voters_list (
    user_id,
    election_id,
    constituency,
    is_eligible,
    has_voted
) VALUES
(2, 1, 'Mbinga Urban', TRUE, FALSE);

-- Add any newly registered users to voters_list automatically
-- This would normally be done through an admin interface
-- For testing, you can manually add your registered user:

-- INSERT INTO voters_list (user_id, election_id, constituency, is_eligible, has_voted)
-- SELECT user_id, 1, 'Mbinga Urban', TRUE, FALSE
-- FROM users
-- WHERE user_id NOT IN (SELECT user_id FROM voters_list WHERE election_id = 1)
-- AND role = 'voter';

-- ========================================
-- VERIFICATION QUERIES
-- ========================================

-- Check election created
SELECT * FROM elections;

-- Check candidates
SELECT * FROM candidates;

-- Check voters list
SELECT * FROM voters_list;

-- ========================================
-- DONE!
-- ========================================
