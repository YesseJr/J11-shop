-- ========================================
-- VOTE MANAGEMENT SYSTEM - DATABASE SCHEMA
-- ========================================
-- Author: Waython Yesse Luoga
-- Reg No: 230229401347
-- Class: OD23IT
-- ========================================

-- Create database
CREATE DATABASE IF NOT EXISTS vms
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

USE vms;

-- ========================================
-- TABLE 1: USERS
-- Purpose: Store all user accounts (voters, admins, observers)
-- ========================================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    nida_id VARCHAR(25) UNIQUE NULL COMMENT 'National ID (Format: YYYYMMDD-XXXXX-XXXXX-XX)',
    vote_id VARCHAR(20) UNIQUE NULL COMMENT 'Alternative voter ID',
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL COMMENT 'Format: +255XXXXXXXXX',
    password_hash VARCHAR(255) NOT NULL COMMENT 'Bcrypt hashed password',
    date_of_birth DATE NOT NULL,
    role ENUM('voter', 'admin', 'observer') DEFAULT 'voter',
    account_status ENUM('active', 'locked', 'disabled') DEFAULT 'active',
    failed_login_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL,
    email_verified BOOLEAN DEFAULT FALSE,
    phone_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Indexes for performance
    INDEX idx_nida (nida_id),
    INDEX idx_email (email),
    INDEX idx_vote_id (vote_id),
    INDEX idx_role (role),
    INDEX idx_status (account_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABLE 2: ELECTIONS
-- Purpose: Store election information
-- ========================================
CREATE TABLE elections (
    election_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    election_type VARCHAR(50) NOT NULL COMMENT 'e.g., Village Chairperson, Street Chairperson',
    constituency VARCHAR(100) NOT NULL COMMENT 'e.g., Mbinga Urban',
    start_date TIMESTAMP NOT NULL,
    end_date TIMESTAMP NOT NULL,
    status ENUM('draft', 'active', 'closed', 'certified') DEFAULT 'draft',
    total_voters INT DEFAULT 0,
    votes_cast INT DEFAULT 0,
    encryption_key_id VARCHAR(100) COMMENT 'Reference to encryption key used',
    created_by INT NOT NULL COMMENT 'Admin who created the election',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP NULL,
    certified_at TIMESTAMP NULL,
    
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE RESTRICT,
    INDEX idx_status (status),
    INDEX idx_constituency (constituency),
    INDEX idx_dates (start_date, end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABLE 3: CANDIDATES
-- Purpose: Store candidate information for elections
-- ========================================
CREATE TABLE candidates (
    candidate_id INT AUTO_INCREMENT PRIMARY KEY,
    election_id INT NOT NULL,
    nida_id VARCHAR(25) NOT NULL COMMENT 'Candidate NIDA ID',
    full_name VARCHAR(100) NOT NULL,
    party_affiliation VARCHAR(100) NOT NULL,
    constituency VARCHAR(100) NOT NULL,
    photo_url VARCHAR(255) COMMENT 'Path to candidate photo',
    biography TEXT,
    manifesto TEXT,
    ballot_position INT NOT NULL COMMENT 'Position on ballot paper',
    vote_count INT DEFAULT 0 COMMENT 'Final vote count after tallying',
    status ENUM('active', 'withdrawn', 'disqualified') DEFAULT 'active',
    registered_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (election_id) REFERENCES elections(election_id) ON DELETE CASCADE,
    FOREIGN KEY (registered_by) REFERENCES users(user_id) ON DELETE RESTRICT,
    INDEX idx_election (election_id),
    INDEX idx_constituency (constituency),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABLE 4: VOTERS_LIST
-- Purpose: Link voters to specific elections
-- ========================================
CREATE TABLE voters_list (
    voter_list_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    election_id INT NOT NULL,
    constituency VARCHAR(100) NOT NULL,
    is_eligible BOOLEAN DEFAULT TRUE,
    has_voted BOOLEAN DEFAULT FALSE,
    voted_at TIMESTAMP NULL,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (election_id) REFERENCES elections(election_id) ON DELETE CASCADE,
    UNIQUE KEY unique_voter_election (user_id, election_id),
    INDEX idx_user (user_id),
    INDEX idx_election (election_id),
    INDEX idx_has_voted (has_voted)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABLE 5: ENCRYPTED_VOTES
-- Purpose: Store encrypted votes (NO VOTER IDENTIFICATION)
-- ⚠️ CRITICAL: This table contains NO user_id to ensure anonymity
-- ========================================
CREATE TABLE encrypted_votes (
    vote_id INT AUTO_INCREMENT PRIMARY KEY,
    election_id INT NOT NULL,
    encrypted_vote_data TEXT NOT NULL COMMENT 'AES-256 encrypted vote content',
    vote_hash VARCHAR(64) UNIQUE NOT NULL COMMENT 'SHA-256 hash for verification',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    client_ip_hash VARCHAR(64) NOT NULL COMMENT 'Hashed IP for security audit',
    encryption_method VARCHAR(20) DEFAULT 'AES-256-CBC',
    
    FOREIGN KEY (election_id) REFERENCES elections(election_id) ON DELETE RESTRICT,
    INDEX idx_election (election_id),
    INDEX idx_timestamp (timestamp),
    UNIQUE INDEX idx_vote_hash (vote_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABLE 6: VOTE_RECEIPTS
-- Purpose: Give voters proof they voted without revealing their choice
-- ========================================
CREATE TABLE vote_receipts (
    receipt_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    election_id INT NOT NULL,
    receipt_code VARCHAR(50) UNIQUE NOT NULL COMMENT 'Unique code for verification',
    vote_hash VARCHAR(64) NOT NULL COMMENT 'Links to encrypted vote (not vote content)',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMP NULL,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (election_id) REFERENCES elections(election_id) ON DELETE CASCADE,
    UNIQUE INDEX idx_receipt_code (receipt_code),
    INDEX idx_user (user_id),
    INDEX idx_vote_hash (vote_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABLE 7: AUDIT_LOGS
-- Purpose: Complete audit trail of all system activities
-- ========================================
CREATE TABLE audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL COMMENT 'NULL for anonymous actions',
    action_type VARCHAR(50) NOT NULL COMMENT 'LOGIN, VOTE_CAST, ELECTION_CREATED, etc.',
    resource_type VARCHAR(50) NOT NULL COMMENT 'user, election, vote, etc.',
    resource_id INT NULL,
    description TEXT NOT NULL,
    ip_address_hash VARCHAR(64) NOT NULL,
    user_agent VARCHAR(255),
    status ENUM('success', 'failure', 'error') NOT NULL,
    error_message TEXT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_action (action_type),
    INDEX idx_timestamp (timestamp),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABLE 8: OTP_CODES
-- Purpose: Store one-time passwords for MFA
-- ========================================
CREATE TABLE otp_codes (
    otp_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    otp_type ENUM('login', 'registration', 'password_reset') NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    used_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- TABLE 9: SESSIONS
-- Purpose: Track active user sessions
-- ========================================
CREATE TABLE sessions (
    session_id VARCHAR(128) PRIMARY KEY,
    user_id INT NOT NULL,
    ip_address_hash VARCHAR(64) NOT NULL,
    user_agent VARCHAR(255),
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- SAMPLE DATA FOR TESTING
-- ========================================

-- Insert test admin user
-- Password: Admin@123 (bcrypt hashed)
INSERT INTO users (nida_id, full_name, email, phone, password_hash, date_of_birth, role, account_status) VALUES
('19900115-12345-67890-12', 'System Administrator', 'admin@votems.go.tz', '+255712345678', 
 '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lE3jzYWrJbIm', 
 '1990-01-15', 'admin', 'active');

-- Insert test voter
-- Password: Voter@123
INSERT INTO users (nida_id, full_name, email, phone, password_hash, date_of_birth, role, account_status) VALUES
('19950620-12345-67890-13', 'Test Voter', 'voter@example.com', '+255712345679',
 '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lE3jzYWrJbIm',
 '1995-06-20', 'voter', 'active');

-- ========================================
-- USEFUL QUERIES FOR TESTING
-- ========================================

-- Check all tables
-- SHOW TABLES;

-- Count users
-- SELECT COUNT(*) as total_users FROM users;

-- Check user roles
-- SELECT role, COUNT(*) as count FROM users GROUP BY role;

-- View recent registrations
-- SELECT user_id, full_name, email, role, created_at 
-- FROM users 
-- ORDER BY created_at DESC 
-- LIMIT 10;

-- ========================================
-- DATABASE SETUP COMPLETE
-- ========================================
