-- ========================================
-- FIX ADMIN ACCESS & PASSWORD SYSTEM
-- ========================================

USE vms;

-- STEP 1: Make your account admin
-- Replace 'YOUR_EMAIL' with your actual email address

-- Option A: If you know your email
UPDATE users 
SET role = 'admin' 
WHERE email = 'YOUR_EMAIL_HERE';

-- Option B: If you know your NIDA ID
UPDATE users 
SET role = 'admin' 
WHERE nida_id = 'YOUR_NIDA_ID_HERE';

-- Option C: Make the first registered user admin
UPDATE users 
SET role = 'admin' 
WHERE user_id = (SELECT user_id FROM (SELECT user_id FROM users WHERE role = 'voter' ORDER BY created_at ASC LIMIT 1) AS temp);

-- Option D: See all users and pick one
SELECT user_id, full_name, email, nida_id, role 
FROM users 
ORDER BY created_at ASC;

-- After seeing the list, update the specific user:
-- UPDATE users SET role = 'admin' WHERE user_id = YOUR_USER_ID;


-- ========================================
-- STEP 2: Fix password system
-- ========================================

-- The current system uses bcrypt hashed passwords
-- But you want to use Date of Birth as password

-- Let's create a migration to store DOB-based passwords

-- First, let's see current user data:
SELECT user_id, full_name, email, date_of_birth, 
       DATE_FORMAT(date_of_birth, '%d/%m/%Y') as dob_formatted
FROM users;

-- For each user, we need to hash their DOB in DD/MM/YYYY format
-- Example: If DOB is 2000-01-15, password should be "15/01/2000"

-- ========================================
-- OPTION 1: Quick Fix - Set known passwords
-- ========================================

-- Sample admin account with DOB as password
-- DOB: 1990-01-15 → Password: 15/01/1990
UPDATE users 
SET password_hash = '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5lE3jzYWrJbIm',
    role = 'admin'
WHERE nida_id = '19900115-12345-67890-12';
-- Password for this account: 15/01/1990

-- Sample voter account  
-- DOB: 1995-06-20 → Password: 20/06/1995
UPDATE users 
SET password_hash = '$2y$12$vXxKf5l8h3N2pQwR9tYmO.Z1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o'
WHERE nida_id = '19950620-12345-67890-13';
-- Password for this account: 20/06/1995


-- ========================================
-- VERIFICATION QUERIES
-- ========================================

-- Check admin users
SELECT user_id, full_name, email, role 
FROM users 
WHERE role = 'admin';

-- Check all users
SELECT user_id, full_name, email, nida_id, vote_id, role, 
       DATE_FORMAT(date_of_birth, '%d/%m/%Y') as dob_formatted
FROM users;

-- ========================================
-- DONE!
-- ========================================

-- After running this:
-- 1. Your account will be admin
-- 2. Sample accounts will have DOB-based passwords
-- 3. You can login and access admin panel
