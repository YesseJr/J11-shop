-- ==========================================
-- VOTE DEBUGGING - RUN THIS IN phpMyAdmin
-- ==========================================

-- 1. Check if votes exist in database
SELECT 'VOTES IN DATABASE' as check_name, COUNT(*) as count 
FROM encrypted_votes;

-- 2. Check votes per election
SELECT 'VOTES PER ELECTION' as info, election_id, COUNT(*) as vote_count 
FROM encrypted_votes 
GROUP BY election_id;

-- 3. Check election votes_cast counter
SELECT 'ELECTION COUNTERS' as info, election_id, name, votes_cast, status 
FROM elections;

-- 4. Check if there's a mismatch
SELECT 
    e.election_id,
    e.name,
    e.votes_cast as recorded_count,
    COUNT(ev.vote_id) as actual_count,
    (e.votes_cast - COUNT(ev.vote_id)) as difference
FROM elections e
LEFT JOIN encrypted_votes ev ON e.election_id = ev.election_id
GROUP BY e.election_id;

-- 5. Sample encrypted vote (see if data exists)
SELECT vote_id, election_id, 
       LEFT(encrypted_vote_data, 50) as encrypted_preview,
       LENGTH(encrypted_vote_data) as data_length,
       timestamp 
FROM encrypted_votes 
LIMIT 3;

-- ==========================================
-- QUICK FIX: Update election vote counter
-- ==========================================

-- Run this to sync the counter with actual votes:
UPDATE elections e
SET votes_cast = (
    SELECT COUNT(*) 
    FROM encrypted_votes ev 
    WHERE ev.election_id = e.election_id
)
WHERE election_id = 1;  -- Change to your election ID

-- Verify it worked:
SELECT election_id, name, votes_cast, status FROM elections WHERE election_id = 1;
