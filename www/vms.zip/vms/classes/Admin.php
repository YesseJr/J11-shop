<?php
/**
 * Vote Management System
 * Admin Class
 * 
 * Handles administrative operations
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

class Admin {
    private $conn;
    
    /**
     * Constructor
     * @param PDO $db Database connection
     */
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Create a new election
     * @param array $data Election data
     * @return int|false Election ID or false
     */
    public function createElection($data) {
        try {
            $query = "INSERT INTO elections 
                      (name, description, election_type, constituency, 
                       start_date, end_date, status, total_voters, created_by) 
                      VALUES 
                      (:name, :description, :type, :constituency, 
                       :start_date, :end_date, :status, :total_voters, :created_by)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':name', $data['name']);
            $stmt->bindParam(':description', $data['description']);
            $stmt->bindParam(':type', $data['election_type']);
            $stmt->bindParam(':constituency', $data['constituency']);
            $stmt->bindParam(':start_date', $data['start_date']);
            $stmt->bindParam(':end_date', $data['end_date']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':total_voters', $data['total_voters']);
            $stmt->bindParam(':created_by', $data['created_by']);
            
            if ($stmt->execute()) {
                return $this->conn->lastInsertId();
            }
            
            return false;
            
        } catch (PDOException $e) {
            error_log('Create Election Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Update election
     * @param int $election_id Election ID
     * @param array $data Updated data
     * @return bool Success status
     */
    public function updateElection($election_id, $data) {
        try {
            $query = "UPDATE elections SET 
                      name = :name, 
                      description = :description, 
                      election_type = :type, 
                      constituency = :constituency, 
                      start_date = :start_date, 
                      end_date = :end_date, 
                      status = :status, 
                      total_voters = :total_voters 
                      WHERE election_id = :election_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':name', $data['name']);
            $stmt->bindParam(':description', $data['description']);
            $stmt->bindParam(':type', $data['election_type']);
            $stmt->bindParam(':constituency', $data['constituency']);
            $stmt->bindParam(':start_date', $data['start_date']);
            $stmt->bindParam(':end_date', $data['end_date']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':total_voters', $data['total_voters']);
            $stmt->bindParam(':election_id', $election_id);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log('Update Election Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Delete election
     * @param int $election_id Election ID
     * @return bool Success status
     */
    public function deleteElection($election_id) {
        try {
            // Check if election has votes
            $query = "SELECT COUNT(*) as count FROM encrypted_votes 
                      WHERE election_id = :election_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            $result = $stmt->fetch();
            
            if ($result['count'] > 0) {
                return false; // Cannot delete election with votes
            }
            
            // Delete election
            $query = "DELETE FROM elections WHERE election_id = :election_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log('Delete Election Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Add candidate
     * @param array $data Candidate data
     * @return int|false Candidate ID or false
     */
    public function addCandidate($data) {
        try {
            $query = "INSERT INTO candidates 
                      (election_id, nida_id, full_name, party_affiliation, 
                       constituency, biography, manifesto, ballot_position, 
                       photo_url, registered_by) 
                      VALUES 
                      (:election_id, :nida_id, :full_name, :party, 
                       :constituency, :biography, :manifesto, :ballot_position, 
                       :photo_url, :registered_by)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $data['election_id']);
            $stmt->bindParam(':nida_id', $data['nida_id']);
            $stmt->bindParam(':full_name', $data['full_name']);
            $stmt->bindParam(':party', $data['party_affiliation']);
            $stmt->bindParam(':constituency', $data['constituency']);
            $stmt->bindParam(':biography', $data['biography']);
            $stmt->bindParam(':manifesto', $data['manifesto']);
            $stmt->bindParam(':ballot_position', $data['ballot_position']);
            $stmt->bindParam(':photo_url', $data['photo_url']);
            $stmt->bindParam(':registered_by', $data['registered_by']);
            
            if ($stmt->execute()) {
                return $this->conn->lastInsertId();
            }
            
            return false;
            
        } catch (PDOException $e) {
            error_log('Add Candidate Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Update candidate
     * @param int $candidate_id Candidate ID
     * @param array $data Updated data
     * @return bool Success status
     */
    public function updateCandidate($candidate_id, $data) {
        try {
            $query = "UPDATE candidates SET 
                      full_name = :full_name, 
                      party_affiliation = :party, 
                      biography = :biography, 
                      manifesto = :manifesto, 
                      ballot_position = :ballot_position, 
                      photo_url = :photo_url, 
                      status = :status 
                      WHERE candidate_id = :candidate_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':full_name', $data['full_name']);
            $stmt->bindParam(':party', $data['party_affiliation']);
            $stmt->bindParam(':biography', $data['biography']);
            $stmt->bindParam(':manifesto', $data['manifesto']);
            $stmt->bindParam(':ballot_position', $data['ballot_position']);
            $stmt->bindParam(':photo_url', $data['photo_url']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':candidate_id', $candidate_id);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log('Update Candidate Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Delete candidate
     * @param int $candidate_id Candidate ID
     * @return bool Success status
     */
    public function deleteCandidate($candidate_id) {
        try {
            $query = "DELETE FROM candidates WHERE candidate_id = :candidate_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':candidate_id', $candidate_id);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log('Delete Candidate Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get all elections
     * @return array Elections list
     */
    public function getAllElections() {
        try {
            $query = "SELECT e.*, u.full_name as created_by_name 
                      FROM elections e 
                      LEFT JOIN users u ON e.created_by = u.user_id 
                      ORDER BY e.created_at DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch (PDOException $e) {
            error_log('Get All Elections Error: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get dashboard statistics
     * @return array Statistics
     */
    public function getDashboardStats() {
        try {
            // Total elections
            $query = "SELECT COUNT(*) as count FROM elections";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $total_elections = $stmt->fetch()['count'];
            
            // Active elections
            $query = "SELECT COUNT(*) as count FROM elections WHERE status = 'active'";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $active_elections = $stmt->fetch()['count'];
            
            // Total voters
            $query = "SELECT COUNT(*) as count FROM users WHERE role = 'voter'";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $total_voters = $stmt->fetch()['count'];
            
            // Total votes cast
            $query = "SELECT COUNT(*) as count FROM encrypted_votes";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $total_votes = $stmt->fetch()['count'];
            
            // Total candidates
            $query = "SELECT COUNT(*) as count FROM candidates";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $total_candidates = $stmt->fetch()['count'];
            
            return [
                'total_elections' => $total_elections,
                'active_elections' => $active_elections,
                'total_voters' => $total_voters,
                'total_votes' => $total_votes,
                'total_candidates' => $total_candidates
            ];
            
        } catch (PDOException $e) {
            error_log('Get Dashboard Stats Error: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get recent activity
     * @param int $limit Number of records
     * @return array Activity log
     */
    public function getRecentActivity($limit = 10) {
        try {
            $query = "SELECT * FROM audit_logs 
                      ORDER BY timestamp DESC 
                      LIMIT :limit";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch (PDOException $e) {
            error_log('Get Recent Activity Error: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Close election
     * @param int $election_id Election ID
     * @return bool Success status
     */
    public function closeElection($election_id) {
        try {
            $query = "UPDATE elections 
                      SET status = 'closed', closed_at = NOW() 
                      WHERE election_id = :election_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log('Close Election Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Certify election results
     * @param int $election_id Election ID
     * @return bool Success status
     */
    public function certifyElection($election_id) {
        try {
            $query = "UPDATE elections 
                      SET status = 'certified', certified_at = NOW() 
                      WHERE election_id = :election_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log('Certify Election Error: ' . $e->getMessage());
            return false;
        }
    }
}
?>
