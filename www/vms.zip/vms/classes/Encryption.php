<?php
/**
 * Vote Management System
 * Encryption Class
 * 
 * Handles vote encryption and anonymization
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

class Encryption {
    private $method = 'AES-256-CBC';
    private $key;
    private $iv_length;
    
    /**
     * Constructor
     * @param string $key Encryption key (optional, uses config default if not provided)
     */
    public function __construct($key = null) {
        if ($key === null) {
            // Use a consistent key from config
            $this->key = $this->getDefaultKey();
        } else {
            $this->key = $key;
        }
        
        $this->iv_length = openssl_cipher_iv_length($this->method);
    }
    
    /**
     * Get default encryption key (consistent across system)
     * @return string Base64 encoded key
     */
    private function getDefaultKey() {
        // Use a consistent key - in production, this should be in environment variable
        // For now, we use a fixed key so all encryptions/decryptions work
        $fixed_key = 'VMS_ENCRYPTION_KEY_2026_SECURE_VOTING_SYSTEM_TANZANIA';
        return base64_encode(hash('sha256', $fixed_key, true));
    }
    
    /**
     * Generate a secure encryption key
     * @return string Base64 encoded key
     */
    public function generateKey() {
        return base64_encode(random_bytes(32)); // 256 bits
    }
    
    /**
     * Encrypt data
     * @param string $data Data to encrypt
     * @return string Base64 encoded encrypted data with IV
     */
    public function encrypt($data) {
        // Generate a random IV for this encryption
        $iv = openssl_random_pseudo_bytes($this->iv_length);
        
        // Encrypt the data
        $encrypted = openssl_encrypt(
            $data,
            $this->method,
            base64_decode($this->key),
            OPENSSL_RAW_DATA,
            $iv
        );
        
        // Combine IV and encrypted data
        $encrypted_with_iv = $iv . $encrypted;
        
        // Return base64 encoded result
        return base64_encode($encrypted_with_iv);
    }
    
    /**
     * Decrypt data
     * @param string $encrypted_data Base64 encoded encrypted data
     * @return string|false Decrypted data or false on failure
     */
    public function decrypt($encrypted_data) {
        // Decode from base64
        $encrypted_with_iv = base64_decode($encrypted_data);
        
        // Extract IV and encrypted data
        $iv = substr($encrypted_with_iv, 0, $this->iv_length);
        $encrypted = substr($encrypted_with_iv, $this->iv_length);
        
        // Decrypt
        $decrypted = openssl_decrypt(
            $encrypted,
            $this->method,
            base64_decode($this->key),
            OPENSSL_RAW_DATA,
            $iv
        );
        
        return $decrypted;
    }
    
    /**
     * Generate hash for vote verification
     * @param string $data Data to hash
     * @return string SHA-256 hash
     */
    public function generateHash($data) {
        return hash('sha256', $data);
    }
    
    /**
     * Generate unique receipt code
     * @return string Receipt code (format: VMS-YYYY-XXXXXXXX)
     */
    public function generateReceiptCode() {
        $year = date('Y');
        $random = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
        return "VMS-{$year}-{$random}";
    }
    
    /**
     * Encrypt vote data (returns encrypted vote + hash)
     * @param array $vote_data Vote information
     * @return array ['encrypted' => string, 'hash' => string]
     */
    public function encryptVote($vote_data) {
        // Convert vote data to JSON
        $json_data = json_encode($vote_data);
        
        // Encrypt the vote
        $encrypted = $this->encrypt($json_data);
        
        // Generate hash for verification (hash of encrypted data)
        $hash = $this->generateHash($encrypted);
        
        return [
            'encrypted' => $encrypted,
            'hash' => $hash
        ];
    }
    
    /**
     * Decrypt vote data
     * @param string $encrypted_vote Encrypted vote
     * @return array|false Vote data or false on failure
     */
    public function decryptVote($encrypted_vote) {
        $decrypted_json = $this->decrypt($encrypted_vote);
        
        if ($decrypted_json === false) {
            return false;
        }
        
        return json_decode($decrypted_json, true);
    }
    
    /**
     * Verify vote hash
     * @param string $encrypted_vote Encrypted vote
     * @param string $stored_hash Stored hash
     * @return bool True if hash matches
     */
    public function verifyVoteHash($encrypted_vote, $stored_hash) {
        $calculated_hash = $this->generateHash($encrypted_vote);
        return hash_equals($stored_hash, $calculated_hash);
    }
}
?>
