<?php
/**
 * Vote Management System
 * User Class
 * 
 * Handles user registration, authentication, and management
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

class User {
    private $conn;
    private $table = 'users';
    
    // User properties
    public $user_id;
    public $nida_id;
    public $vote_id;
    public $full_name;
    public $email;
    public $phone;
    public $password_hash;
    public $date_of_birth;
    public $role;
    public $account_status;
    
    /**
     * Constructor
     * @param PDO $db Database connection
     */
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Register a new user
     * @param array $data User data
     * @return int|false User ID if successful, false otherwise
     */
    public function register($data) {
        try {
            // Prepare SQL
            $query = "INSERT INTO " . $this->table . " 
                      (nida_id, vote_id, full_name, email, phone, password_hash, 
                       date_of_birth, role, account_status) 
                      VALUES 
                      (:nida_id, :vote_id, :full_name, :email, :phone, :password_hash, 
                       :dob, :role, :account_status)";
            
            $stmt = $this->conn->prepare($query);
            
            // Bind parameters
            $stmt->bindParam(':nida_id', $data['nida_id']);
            $stmt->bindParam(':vote_id', $data['vote_id']);
            $stmt->bindParam(':full_name', $data['full_name']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':phone', $data['phone']);
            $stmt->bindParam(':password_hash', $data['password_hash']);
            $stmt->bindParam(':dob', $data['date_of_birth']);
            $stmt->bindParam(':role', $data['role']);
            $stmt->bindParam(':account_status', $data['account_status']);
            
            // Execute
            if ($stmt->execute()) {
                return $this->conn->lastInsertId();
            }
            
            return false;
            
        } catch (PDOException $e) {
            error_log('Registration Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if NIDA ID exists
     * @param string $nida_id NIDA ID
     * @return bool True if exists, false otherwise
     */
    public function nidaExists($nida_id) {
        try {
            $query = "SELECT user_id FROM " . $this->table . " 
                      WHERE nida_id = :nida_id LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':nida_id', $nida_id);
            $stmt->execute();
            
            return $stmt->rowCount() > 0;
            
        } catch (PDOException $e) {
            error_log('NIDA Check Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if VOTE ID exists
     * @param string $vote_id VOTE ID
     * @return bool True if exists, false otherwise
     */
    public function voteIdExists($vote_id) {
        try {
            $query = "SELECT user_id FROM " . $this->table . " 
                      WHERE vote_id = :vote_id LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':vote_id', $vote_id);
            $stmt->execute();
            
            return $stmt->rowCount() > 0;
            
        } catch (PDOException $e) {
            error_log('VOTE ID Check Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if email exists
     * @param string $email Email address
     * @return bool True if exists, false otherwise
     */
    public function emailExists($email) {
        try {
            $query = "SELECT user_id FROM " . $this->table . " 
                      WHERE email = :email LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            return $stmt->rowCount() > 0;
            
        } catch (PDOException $e) {
            error_log('Email Check Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get user by ID
     * @param int $user_id User ID
     * @return array|false User data or false
     */
    public function getUserById($user_id) {
        try {
            $query = "SELECT * FROM " . $this->table . " 
                      WHERE user_id = :user_id LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            return $stmt->fetch();
            
        } catch (PDOException $e) {
            error_log('Get User Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get user by email
     * @param string $email Email address
     * @return array|false User data or false
     */
    public function getUserByEmail($email) {
        try {
            $query = "SELECT * FROM " . $this->table . " 
                      WHERE email = :email LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            return $stmt->fetch();
            
        } catch (PDOException $e) {
            error_log('Get User By Email Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get user by NIDA ID
     * @param string $nida_id NIDA ID
     * @return array|false User data or false
     */
    public function getUserByNidaId($nida_id) {
        try {
            $query = "SELECT * FROM " . $this->table . " 
                      WHERE nida_id = :nida_id LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':nida_id', $nida_id);
            $stmt->execute();
            
            return $stmt->fetch();
            
        } catch (PDOException $e) {
            error_log('Get User By NIDA Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Verify user password
     * @param string $password Plain text password
     * @param string $hash Password hash from database
     * @return bool True if password matches, false otherwise
     */
    public function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * Hash password
     * @param string $password Plain text password
     * @return string Hashed password
     */
    public function hashPassword($password) {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }
    
    /**
     * Update user information
     * @param int $user_id User ID
     * @param array $data Data to update
     * @return bool True if successful, false otherwise
     */
    public function updateUser($user_id, $data) {
        try {
            $query = "UPDATE " . $this->table . " SET ";
            $params = [];
            
            // Build dynamic query based on provided data
            foreach ($data as $key => $value) {
                $query .= "$key = :$key, ";
                $params[":$key"] = $value;
            }
            
            // Remove trailing comma and space
            $query = rtrim($query, ', ');
            
            // Add WHERE clause
            $query .= " WHERE user_id = :user_id";
            $params[':user_id'] = $user_id;
            
            $stmt = $this->conn->prepare($query);
            return $stmt->execute($params);
            
        } catch (PDOException $e) {
            error_log('Update User Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Increment failed login attempts
     * @param int $user_id User ID
     * @return bool True if successful, false otherwise
     */
    public function incrementFailedAttempts($user_id) {
        try {
            $query = "UPDATE " . $this->table . " 
                      SET failed_login_attempts = failed_login_attempts + 1 
                      WHERE user_id = :user_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log('Increment Failed Attempts Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Reset failed login attempts
     * @param int $user_id User ID
     * @return bool True if successful, false otherwise
     */
    public function resetFailedAttempts($user_id) {
        try {
            $query = "UPDATE " . $this->table . " 
                      SET failed_login_attempts = 0, locked_until = NULL 
                      WHERE user_id = :user_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log('Reset Failed Attempts Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Lock user account
     * @param int $user_id User ID
     * @param int $minutes Lock duration in minutes
     * @return bool True if successful, false otherwise
     */
    public function lockAccount($user_id, $minutes = 30) {
        try {
            $locked_until = date('Y-m-d H:i:s', strtotime("+$minutes minutes"));
            
            $query = "UPDATE " . $this->table . " 
                      SET account_status = 'locked', locked_until = :locked_until 
                      WHERE user_id = :user_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':locked_until', $locked_until);
            $stmt->bindParam(':user_id', $user_id);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log('Lock Account Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if account is locked
     * @param int $user_id User ID
     * @return bool True if locked, false otherwise
     */
    public function isAccountLocked($user_id) {
        try {
            $query = "SELECT locked_until FROM " . $this->table . " 
                      WHERE user_id = :user_id LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            
            $result = $stmt->fetch();
            
            if ($result && $result['locked_until']) {
                return strtotime($result['locked_until']) > time();
            }
            
            return false;
            
        } catch (PDOException $e) {
            error_log('Check Account Lock Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get total user count
     * @param string $role Optional role filter
     * @return int User count
     */
    public function getUserCount($role = null) {
        try {
            if ($role) {
                $query = "SELECT COUNT(*) as count FROM " . $this->table . " 
                          WHERE role = :role";
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(':role', $role);
            } else {
                $query = "SELECT COUNT(*) as count FROM " . $this->table;
                $stmt = $this->conn->prepare($query);
            }
            
            $stmt->execute();
            $result = $stmt->fetch();
            
            return $result['count'] ?? 0;
            
        } catch (PDOException $e) {
            error_log('Get User Count Error: ' . $e->getMessage());
            return 0;
        }
    }
}
?>
