<?php
/**
 * Vote Management System
 * Vote Class
 * 
 * Handles voting operations with complete anonymization
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once 'Encryption.php';

class Vote {
    private $conn;
    private $encryption;
    
    /**
     * Constructor
     * @param PDO $db Database connection
     */
    public function __construct($db) {
        $this->conn = $db;
        $this->encryption = new Encryption();
    }
    
    /**
     * Check if user is eligible to vote in an election
     * @param int $user_id User ID
     * @param int $election_id Election ID
     * @return array ['eligible' => bool, 'reason' => string]
     */
    public function checkEligibility($user_id, $election_id) {
        try {
            // Check if user is in voters list for this election
            $query = "SELECT * FROM voters_list 
                      WHERE user_id = :user_id 
                      AND election_id = :election_id 
                      LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            
            $voter_record = $stmt->fetch();
            
            if (!$voter_record) {
                return [
                    'eligible' => false,
                    'reason' => 'You are not registered for this election'
                ];
            }
            
            if (!$voter_record['is_eligible']) {
                return [
                    'eligible' => false,
                    'reason' => 'You are not eligible to vote in this election'
                ];
            }
            
            if ($voter_record['has_voted']) {
                return [
                    'eligible' => false,
                    'reason' => 'You have already voted in this election',
                    'voted_at' => $voter_record['voted_at']
                ];
            }
            
            // Check if election is active
            $query = "SELECT status, start_date, end_date FROM elections 
                      WHERE election_id = :election_id LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            
            $election = $stmt->fetch();
            
            if (!$election) {
                return [
                    'eligible' => false,
                    'reason' => 'Election not found'
                ];
            }
            
            if ($election['status'] !== 'active') {
                return [
                    'eligible' => false,
                    'reason' => 'Election is not currently active'
                ];
            }
            
            // Check if election period is valid
            $now = time();
            $start = strtotime($election['start_date']);
            $end = strtotime($election['end_date']);
            
            if ($now < $start) {
                return [
                    'eligible' => false,
                    'reason' => 'Election has not started yet'
                ];
            }
            
            if ($now > $end) {
                return [
                    'eligible' => false,
                    'reason' => 'Election has ended'
                ];
            }
            
            return [
                'eligible' => true,
                'reason' => 'Eligible to vote'
            ];
            
        } catch (PDOException $e) {
            error_log('Check Eligibility Error: ' . $e->getMessage());
            return [
                'eligible' => false,
                'reason' => 'Error checking eligibility'
            ];
        }
    }
    
    /**
     * Cast a vote (with complete anonymization)
     * @param int $user_id User ID
     * @param int $election_id Election ID
     * @param int $candidate_id Candidate ID
     * @return array ['success' => bool, 'receipt_code' => string, 'message' => string]
     */
    public function castVote($user_id, $election_id, $candidate_id) {
        try {
            // Start transaction
            $this->conn->beginTransaction();
            
            // 1. Check eligibility
            $eligibility = $this->checkEligibility($user_id, $election_id);
            if (!$eligibility['eligible']) {
                $this->conn->rollBack();
                return [
                    'success' => false,
                    'message' => $eligibility['reason']
                ];
            }
            
            // 2. Verify candidate exists and belongs to this election
            $query = "SELECT * FROM candidates 
                      WHERE candidate_id = :candidate_id 
                      AND election_id = :election_id 
                      AND status = 'active' 
                      LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':candidate_id', $candidate_id);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            
            $candidate = $stmt->fetch();
            
            if (!$candidate) {
                $this->conn->rollBack();
                return [
                    'success' => false,
                    'message' => 'Invalid candidate selection'
                ];
            }
            
            // 3. Prepare vote data (to be encrypted)
            $vote_data = [
                'election_id' => $election_id,
                'candidate_id' => $candidate_id,
                'candidate_name' => $candidate['full_name'],
                'timestamp' => date('Y-m-d H:i:s')
            ];
            
            // 4. Encrypt the vote
            $encrypted_result = $this->encryption->encryptVote($vote_data);
            
            // 5. Store encrypted vote (NO user_id - this ensures anonymity!)
            $query = "INSERT INTO encrypted_votes 
                      (election_id, encrypted_vote_data, vote_hash, client_ip_hash) 
                      VALUES (:election_id, :encrypted_vote, :vote_hash, :ip_hash)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->bindParam(':encrypted_vote', $encrypted_result['encrypted']);
            $stmt->bindParam(':vote_hash', $encrypted_result['hash']);
            
            // Hash IP address for privacy
            $ip_hash = hash('sha256', $_SERVER['REMOTE_ADDR'] . 'VMS_SALT');
            $stmt->bindParam(':ip_hash', $ip_hash);
            
            $stmt->execute();
            $vote_id = $this->conn->lastInsertId();
            
            // 6. Generate receipt code
            $receipt_code = $this->encryption->generateReceiptCode();
            
            // 7. Store receipt (links user to vote hash, NOT vote content!)
            $query = "INSERT INTO vote_receipts 
                      (user_id, election_id, receipt_code, vote_hash) 
                      VALUES (:user_id, :election_id, :receipt_code, :vote_hash)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->bindParam(':receipt_code', $receipt_code);
            $stmt->bindParam(':vote_hash', $encrypted_result['hash']);
            $stmt->execute();
            
            // 8. Update voters_list (mark as voted)
            $query = "UPDATE voters_list 
                      SET has_voted = TRUE, voted_at = NOW() 
                      WHERE user_id = :user_id 
                      AND election_id = :election_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            
            // 9. Update election vote count
            $query = "UPDATE elections 
                      SET votes_cast = votes_cast + 1 
                      WHERE election_id = :election_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            
            // Commit transaction
            $this->conn->commit();
            
            return [
                'success' => true,
                'receipt_code' => $receipt_code,
                'vote_hash' => $encrypted_result['hash'],
                'message' => 'Vote cast successfully!'
            ];
            
        } catch (Exception $e) {
            // Rollback on error
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            
            error_log('Cast Vote Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Error casting vote. Please try again.'
            ];
        }
    }
    
    /**
     * Get candidates for an election
     * @param int $election_id Election ID
     * @return array|false Array of candidates or false
     */
    public function getCandidates($election_id) {
        try {
            $query = "SELECT * FROM candidates 
                      WHERE election_id = :election_id 
                      AND status = 'active' 
                      ORDER BY ballot_position ASC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch (PDOException $e) {
            error_log('Get Candidates Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get election details
     * @param int $election_id Election ID
     * @return array|false Election data or false
     */
    public function getElection($election_id) {
        try {
            $query = "SELECT * FROM elections 
                      WHERE election_id = :election_id LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            
            return $stmt->fetch();
            
        } catch (PDOException $e) {
            error_log('Get Election Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Verify vote receipt
     * @param string $receipt_code Receipt code
     * @return array|false Receipt data or false
     */
    public function verifyReceipt($receipt_code) {
        try {
            $query = "SELECT vr.*, e.name as election_name 
                      FROM vote_receipts vr 
                      JOIN elections e ON vr.election_id = e.election_id 
                      WHERE vr.receipt_code = :receipt_code LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':receipt_code', $receipt_code);
            $stmt->execute();
            
            $receipt = $stmt->fetch();
            
            if ($receipt) {
                // Check if vote exists with this hash
                $query = "SELECT COUNT(*) as count FROM encrypted_votes 
                          WHERE vote_hash = :vote_hash";
                
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(':vote_hash', $receipt['vote_hash']);
                $stmt->execute();
                
                $vote_exists = $stmt->fetch();
                $receipt['vote_verified'] = $vote_exists['count'] > 0;
                
                // Mark receipt as verified
                if (!$receipt['verified']) {
                    $query = "UPDATE vote_receipts 
                              SET verified = TRUE, verified_at = NOW() 
                              WHERE receipt_code = :receipt_code";
                    
                    $stmt = $this->conn->prepare($query);
                    $stmt->bindParam(':receipt_code', $receipt_code);
                    $stmt->execute();
                }
            }
            
            return $receipt;
            
        } catch (PDOException $e) {
            error_log('Verify Receipt Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get active elections
     * @return array|false Array of elections or false
     */
    public function getActiveElections() {
        try {
            $query = "SELECT * FROM elections 
                      WHERE status = 'active' 
                      AND start_date <= NOW() 
                      AND end_date >= NOW() 
                      ORDER BY start_date ASC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch (PDOException $e) {
            error_log('Get Active Elections Error: ' . $e->getMessage());
            return false;
        }
    }
}
?>
