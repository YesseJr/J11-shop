<?php
/**
 * Vote Management System
 * Results Class
 * 
 * Handles vote tallying, decryption, and results display
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once 'Encryption.php';

class Results {
    private $conn;
    private $encryption;
    
    /**
     * Constructor
     * @param PDO $db Database connection
     */
    public function __construct($db) {
        $this->conn = $db;
        $this->encryption = new Encryption();
    }
    
    /**
     * Tally votes for an election (decrypt and count)
     * @param int $election_id Election ID
     * @return array Results with candidate vote counts
     */
    public function tallyVotes($election_id) {
        try {
            // Get all encrypted votes for this election
            $query = "SELECT vote_id, encrypted_vote_data FROM encrypted_votes 
                      WHERE election_id = :election_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            
            $encrypted_votes = $stmt->fetchAll();
            
            // Debug: Log vote count
            error_log("Tally Votes: Found " . count($encrypted_votes) . " encrypted votes for election {$election_id}");
            
            // Initialize vote counts
            $vote_counts = [];
            $total_votes = 0;
            $decryption_errors = 0;
            
            // Decrypt each vote and count
            foreach ($encrypted_votes as $vote_record) {
                try {
                    // Decrypt the vote
                    $decrypted = $this->encryption->decrypt($vote_record['encrypted_vote_data']);
                    
                    if ($decrypted !== false && !empty($decrypted)) {
                        $vote_data = json_decode($decrypted, true);
                        
                        // Debug: Log decrypted vote
                        error_log("Decrypted vote {$vote_record['vote_id']}: " . print_r($vote_data, true));
                        
                        if ($vote_data && isset($vote_data['candidate_id'])) {
                            $candidate_id = $vote_data['candidate_id'];
                            
                            // Increment count for this candidate
                            if (!isset($vote_counts[$candidate_id])) {
                                $vote_counts[$candidate_id] = 0;
                            }
                            $vote_counts[$candidate_id]++;
                            $total_votes++;
                        } else {
                            error_log("Vote {$vote_record['vote_id']}: Invalid vote data structure");
                            $decryption_errors++;
                        }
                    } else {
                        error_log("Vote {$vote_record['vote_id']}: Decryption returned false or empty");
                        $decryption_errors++;
                    }
                } catch (Exception $e) {
                    $decryption_errors++;
                    error_log("Vote {$vote_record['vote_id']}: Decryption error - " . $e->getMessage());
                }
            }
            
            // Debug: Log results
            error_log("Tally complete: {$total_votes} votes counted, {$decryption_errors} errors");
            error_log("Vote counts: " . print_r($vote_counts, true));
            
            return [
                'success' => true,
                'vote_counts' => $vote_counts,
                'total_votes' => $total_votes,
                'decryption_errors' => $decryption_errors,
                'total_encrypted' => count($encrypted_votes)
            ];
            
        } catch (PDOException $e) {
            error_log('Tally Votes Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Error tallying votes',
                'vote_counts' => [],
                'total_votes' => 0,
                'decryption_errors' => 0
            ];
        }
    }
    
    /**
     * Get election results with candidate details
     * @param int $election_id Election ID
     * @return array Complete results with candidate info
     */
    public function getResults($election_id) {
        try {
            // Get election details
            $query = "SELECT * FROM elections WHERE election_id = :election_id LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            $election = $stmt->fetch();
            
            if (!$election) {
                return [
                    'success' => false,
                    'message' => 'Election not found'
                ];
            }
            
            // Get all candidates
            $query = "SELECT * FROM candidates 
                      WHERE election_id = :election_id 
                      ORDER BY ballot_position ASC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            $candidates = $stmt->fetchAll();
            
            // Tally votes
            $tally_result = $this->tallyVotes($election_id);
            
            if (!$tally_result['success']) {
                return $tally_result;
            }
            
            $vote_counts = $tally_result['vote_counts'];
            $total_votes = $tally_result['total_votes'];
            
            // Calculate results for each candidate
            $results = [];
            $winner = null;
            $max_votes = 0;
            
            foreach ($candidates as $candidate) {
                $candidate_id = $candidate['candidate_id'];
                $votes = $vote_counts[$candidate_id] ?? 0;
                $percentage = $total_votes > 0 ? ($votes / $total_votes) * 100 : 0;
                
                $candidate_result = [
                    'candidate_id' => $candidate_id,
                    'full_name' => $candidate['full_name'],
                    'party_affiliation' => $candidate['party_affiliation'],
                    'ballot_position' => $candidate['ballot_position'],
                    'votes' => $votes,
                    'percentage' => round($percentage, 2)
                ];
                
                $results[] = $candidate_result;
                
                // Determine winner
                if ($votes > $max_votes) {
                    $max_votes = $votes;
                    $winner = $candidate_result;
                }
            }
            
            // Sort by votes (descending)
            usort($results, function($a, $b) {
                return $b['votes'] - $a['votes'];
            });
            
            return [
                'success' => true,
                'election' => $election,
                'results' => $results,
                'winner' => $winner,
                'total_votes' => $total_votes,
                'total_eligible_voters' => $election['total_voters'],
                'turnout_percentage' => $election['total_voters'] > 0 
                    ? round(($total_votes / $election['total_voters']) * 100, 2) 
                    : 0
            ];
            
        } catch (Exception $e) {
            error_log('Get Results Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Error retrieving results'
            ];
        }
    }
    
    /**
     * Update candidate vote counts in database
     * @param int $election_id Election ID
     * @return bool Success status
     */
    public function updateCandidateVoteCounts($election_id) {
        try {
            $tally = $this->tallyVotes($election_id);
            
            if (!$tally['success']) {
                return false;
            }
            
            $vote_counts = $tally['vote_counts'];
            
            // Update each candidate's vote count
            foreach ($vote_counts as $candidate_id => $votes) {
                $query = "UPDATE candidates 
                          SET vote_count = :votes 
                          WHERE candidate_id = :candidate_id 
                          AND election_id = :election_id";
                
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(':votes', $votes);
                $stmt->bindParam(':candidate_id', $candidate_id);
                $stmt->bindParam(':election_id', $election_id);
                $stmt->execute();
            }
            
            return true;
            
        } catch (PDOException $e) {
            error_log('Update Vote Counts Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if results can be viewed
     * @param int $election_id Election ID
     * @return array Status and message
     */
    /**
     * Check if results can be viewed
     * @param int $election_id Election ID
     * @return array Status and message
     */
    public function canViewResults($election_id) {
        try {
            $query = "SELECT status, end_date, votes_cast FROM elections 
                      WHERE election_id = :election_id LIMIT 1";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            
            $election = $stmt->fetch();
            
            if (!$election) {
                return [
                    'can_view' => false,
                    'reason' => 'Election not found'
                ];
            }
            
            // Check ACTUAL votes in encrypted_votes table (not just the counter)
            // This works for ALL elections regardless of status
            $query = "SELECT COUNT(*) as actual_votes FROM encrypted_votes 
                      WHERE election_id = :election_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':election_id', $election_id);
            $stmt->execute();
            $actual_votes = $stmt->fetch()['actual_votes'];
            
            error_log("Results check for election {$election_id}: {$actual_votes} votes found");
            
            // Show results if there are ANY votes in the database
            // Works for old elections, new elections, any status
            if ($actual_votes > 0) {
                return [
                    'can_view' => true,
                    'reason' => 'Results available',
                    'live' => ($election['status'] === 'active'), // Flag for live results
                    'actual_votes' => $actual_votes
                ];
            }
            
            // No votes yet
            return [
                'can_view' => false,
                'reason' => 'No votes have been cast yet',
                'actual_votes' => 0
            ];
            
        } catch (PDOException $e) {
            error_log('Can View Results Error: ' . $e->getMessage());
            return [
                'can_view' => false,
                'reason' => 'Error checking status: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Get all available elections for results viewing
     * @return array List of elections
     */
    public function getAvailableElections() {
        try {
            $query = "SELECT election_id, name, election_type, constituency, 
                             start_date, end_date, status, votes_cast, total_voters
                      FROM elections 
                      WHERE status IN ('active', 'closed', 'certified')
                      ORDER BY end_date DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            return $stmt->fetchAll();
            
        } catch (PDOException $e) {
            error_log('Get Available Elections Error: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Generate results summary
     * @param int $election_id Election ID
     * @return array Summary statistics
     */
    public function getResultsSummary($election_id) {
        $results_data = $this->getResults($election_id);
        
        if (!$results_data['success']) {
            return $results_data;
        }
        
        $election = $results_data['election'];
        $winner = $results_data['winner'];
        $total_votes = $results_data['total_votes'];
        
        return [
            'success' => true,
            'election_name' => $election['name'],
            'election_type' => $election['election_type'],
            'constituency' => $election['constituency'],
            'total_votes_cast' => $total_votes,
            'total_eligible_voters' => $election['total_voters'],
            'turnout_percentage' => $results_data['turnout_percentage'],
            'winner_name' => $winner ? $winner['full_name'] : 'No votes cast',
            'winner_party' => $winner ? $winner['party_affiliation'] : 'N/A',
            'winner_votes' => $winner ? $winner['votes'] : 0,
            'winner_percentage' => $winner ? $winner['percentage'] : 0,
            'election_start' => $election['start_date'],
            'election_end' => $election['end_date'],
            'status' => $election['status']
        ];
    }
}
?>
