<?php
/**
 * Vote Management System
 * Landing Page
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once 'config/config.php';

// If user is logged in, redirect to dashboard
if (isLoggedIn()) {
    $role = getCurrentUserRole();
    if ($role === 'admin') {
        redirect(SITE_URL . '/admin/index.php');
    } else {
        redirect(SITE_URL . '/public/dashboard.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote Management System | Secure Online Voting</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; }
        
        /* Header */
        .header {
            background: white;
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            width: 100%;
            top: 8px;
            z-index: 100;
        }
        
        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 20px;
            font-weight: bold;
            color: #333;
        }
        
        .logo img { width: 40px; height: 40px; }
        
        .nav-buttons { display: flex; gap: 15px; }
        
        .btn {
            padding: 10px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
            display: inline-block;
        }
        
        .btn-outline {
            border: 2px solid #4472C4;
            color: #4472C4;
        }
        
        .btn-outline:hover {
            background: #4472C4;
            color: white;
        }
        
        .btn-primary {
            background: #4472C4;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2E5C8A;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(68,114,196,0.3);
        }
        
        /* Hero */
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 120px 20px 80px;
            text-align: center;
            color: white;
        }
        
        .hero-content {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .hero h1 {
            font-size: 48px;
            margin-bottom: 20px;
            line-height: 1.2;
        }
        
        .hero p {
            font-size: 20px;
            margin-bottom: 30px;
            opacity: 0.95;
        }
        
        .hero-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 40px;
        }
        
        .btn-large {
            padding: 16px 36px;
            font-size: 18px;
        }
        
        /* Features */
        .features {
            padding: 80px 20px;
            background: #f5f5f5;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .section-title {
            text-align: center;
            font-size: 36px;
            margin-bottom: 50px;
            color: #333;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .feature-card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
        }
        
        .feature-icon {
            font-size: 50px;
            margin-bottom: 20px;
        }
        
        .feature-title {
            font-size: 22px;
            margin-bottom: 15px;
            color: #333;
        }
        
        .feature-description {
            color: #666;
            line-height: 1.6;
        }
        
        /* How It Works */
        .how-it-works {
            padding: 80px 20px;
            background: white;
        }
        
        .steps {
            max-width: 900px;
            margin: 0 auto;
        }
        
        .step {
            display: flex;
            align-items: flex-start;
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .step-number {
            flex-shrink: 0;
            width: 60px;
            height: 60px;
            background: #4472C4;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            font-weight: bold;
        }
        
        .step-content h3 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #333;
        }
        
        .step-content p {
            color: #666;
            line-height: 1.6;
        }
        
        /* CTA */
        .cta {
            background: linear-gradient(135deg, #4472C4, #2E5C8A);
            color: white;
            padding: 80px 20px;
            text-align: center;
        }
        
        .cta h2 {
            font-size: 40px;
            margin-bottom: 20px;
        }
        
        .cta p {
            font-size: 20px;
            margin-bottom: 40px;
            opacity: 0.95;
        }
        
        /* Footer */
        .footer {
            background: #2C3E50;
            color: white;
            padding: 40px 20px 20px;
            text-align: center;
        }
        
        .footer p {
            margin: 10px 0;
            opacity: 0.9;
        }
        
        @media (max-width: 768px) {
            .hero h1 { font-size: 32px; }
            .hero p { font-size: 16px; }
            .hero-buttons { flex-direction: column; }
            .step { flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    
    <!-- Header -->
    <header class="header">
        <div class="nav-container">
            <div class="logo">
                <img src="assets/images/emblem.png" alt="Tanzania Emblem" onerror="this.style.display='none'">
                <span>VMS</span>
            </div>
            <div class="nav-buttons">
                <a href="public/login.php" class="btn btn-outline">Sign In</a>
                <a href="public/register.php" class="btn btn-primary">Register</a>
            </div>
        </div>
    </header>
    
    <!-- Hero -->
    <section class="hero">
        <div class="hero-content">
            <h1>🗳️ Secure Online Voting for Tanzania</h1>
            <p>Cast your vote from anywhere, anytime. Transparent, secure, and accessible local government elections.</p>
            <div class="hero-buttons">
                <a href="public/register.php" class="btn btn-primary btn-large">Get Started</a>
                <a href="public/results.php" class="btn btn-outline btn-large" style="color: white; border-color: white;">View Results</a>
            </div>
        </div>
    </section>
    
    <!-- Features -->
    <section class="features">
        <div class="container">
            <h2 class="section-title">Why Vote Online?</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">🔒</div>
                    <h3 class="feature-title">100% Secure</h3>
                    <p class="feature-description">
                        Military-grade AES-256 encryption ensures your vote is completely secure and anonymous.
                    </p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">✓</div>
                    <h3 class="feature-title">NIDA Verified</h3>
                    <p class="feature-description">
                        Integrated with National ID Authority for instant identity verification. One person, one vote.
                    </p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">📱</div>
                    <h3 class="feature-title">Vote Anywhere</h3>
                    <p class="feature-description">
                        Vote from your phone, tablet, or computer. Works on any device with internet connection.
                    </p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">⚡</div>
                    <h3 class="feature-title">Instant Results</h3>
                    <p class="feature-description">
                        See election results instantly after polls close. Transparent and publicly accessible.
                    </p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🎯</div>
                    <h3 class="feature-title">Easy to Use</h3>
                    <p class="feature-description">
                        Simple 3-step process. Clear instructions in English and Swahili. No technical knowledge required.
                    </p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🎫</div>
                    <h3 class="feature-title">Receipt Verification</h3>
                    <p class="feature-description">
                        Get a unique receipt code to verify your vote was counted, without revealing your choice.
                    </p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- How It Works -->
    <section class="how-it-works">
        <div class="container">
            <h2 class="section-title">How It Works</h2>
            <div class="steps">
                <div class="step">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h3>Register & Verify</h3>
                        <p>Create your account using your NIDA ID or VOTE ID. We'll verify your identity and eligibility to vote.</p>
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h3>Login Securely</h3>
                        <p>Sign in with multi-factor authentication. Your account is protected with industry-standard security.</p>
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h3>Cast Your Vote</h3>
                        <p>View candidates and make your choice. Your vote is encrypted and completely anonymous.</p>
                    </div>
                </div>
                
                <div class="step">
                    <div class="step-number">4</div>
                    <div class="step-content">
                        <h3>Get Confirmation</h3>
                        <p>Receive a unique receipt code via SMS. Use it to verify your vote was counted.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- CTA -->
    <section class="cta">
        <h2>Ready to Make Your Voice Heard?</h2>
        <p>Join thousands of Tanzanians participating in secure, transparent local elections</p>
        <div style="display: flex; gap: 20px; justify-content: center;">
            <a href="public/register.php" class="btn btn-large" style="background: white; color: #4472C4;">
                Register Now
            </a>
            <a href="public/verify_receipt.php" class="btn btn-outline btn-large" style="color: white; border-color: white;">
                Verify Receipt
            </a>
        </div>
    </section>
    
    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2026 Local Government Electoral Commission. All rights reserved.</p>
        <p>Developed by <strong>Waython Yesse Luoga</strong> | Reg No: 230229401347</p>
        <p style="margin-top: 20px; font-size: 14px;">
            <a href="public/login.php" style="color: white; margin: 0 10px;">Sign In</a> |
            <a href="public/register.php" style="color: white; margin: 0 10px;">Register</a> |
            <a href="public/results.php" style="color: white; margin: 0 10px;">Results</a> |
            <a href="public/verify_receipt.php" style="color: white; margin: 0 10px;">Verify</a>
        </p>
    </footer>
</body>
</html>
