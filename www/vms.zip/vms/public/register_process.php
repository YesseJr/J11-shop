<?php
/**
 * Vote Management System
 * Registration Processing Script
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

// Include configuration
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/User.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(SITE_URL . '/public/register.php');
}

// Sanitize and validate inputs
$registration_method = sanitizeInput($_POST['registration_method'] ?? 'nida');
$nida_id = sanitizeInput($_POST['nida_id'] ?? '');
$vote_id = sanitizeInput($_POST['vote_id'] ?? '');
$full_name = sanitizeInput($_POST['full_name'] ?? '');
$dob = sanitizeInput($_POST['dob'] ?? '');
$phone = sanitizeInput($_POST['phone'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';

// Validation errors array
$errors = [];

// 1. Check registration method and validate ID
if ($registration_method === 'nida') {
    if (empty($nida_id)) {
        $errors[] = 'NIDA ID is required';
    } elseif (!preg_match(NIDA_PATTERN, $nida_id)) {
        $errors[] = 'Invalid NIDA ID format. Expected: YYYYMMDD-XXXXX-XXXXX-XX';
    }
    $vote_id = null; // Set vote_id to null for NIDA registration
} else {
    if (empty($vote_id)) {
        $errors[] = 'VOTE ID is required';
    } elseif (strlen($vote_id) < 10) {
        $errors[] = 'Invalid VOTE ID format';
    }
    $nida_id = null; // Set nida_id to null for VOTE ID registration
}

// 2. Validate full name
if (empty($full_name)) {
    $errors[] = 'Full name is required';
} elseif (strlen($full_name) < 3) {
    $errors[] = 'Full name must be at least 3 characters';
} elseif (!preg_match('/^[a-zA-Z\s]+$/', $full_name)) {
    $errors[] = 'Full name can only contain letters and spaces';
}

// 3. Validate date of birth (must be 18+)
if (empty($dob)) {
    $errors[] = 'Date of birth is required';
} else {
    // Date comes in YYYY-MM-DD format from date picker
    $dob_timestamp = strtotime($dob);
    
    if (!$dob_timestamp) {
        $errors[] = 'Invalid date of birth';
    } else {
        // Check if date is not in the future
        if ($dob_timestamp > time()) {
            $errors[] = 'Date of birth cannot be in the future';
        }
        
        // Check if user is 18+
        $age = floor((time() - $dob_timestamp) / (365 * 24 * 60 * 60));
        if ($age < 18) {
            $errors[] = 'You must be at least 18 years old to register';
        }
    }
}

// 4. Validate phone number
if (empty($phone)) {
    $errors[] = 'Phone number is required';
} else {
    // Remove all non-digit characters for validation
    $phone_digits = preg_replace('/\D/', '', $phone);
    
    // Check Tanzanian phone format: must start with 255 and have 12 digits total
    if (!preg_match('/^255[67]\d{8}$/', $phone_digits)) {
        $errors[] = 'Invalid Tanzanian phone number. Must be +255 6XX XXX XXX or +255 7XX XXX XXX';
    }
    
    // Format phone number for storage
    $phone = '+' . $phone_digits;
}

// 5. Validate email
if (empty($email)) {
    $errors[] = 'Email address is required';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Invalid email address format';
} elseif (strlen($email) > 100) {
    $errors[] = 'Email address is too long';
}

// 6. Validate password (can be any password, including DOB)
if (empty($password)) {
    $errors[] = 'Password is required';
} elseif (strlen($password) < 8) {
    $errors[] = 'Password must be at least 8 characters long';
}

// 7. Validate password confirmation
if ($password !== $confirm_password) {
    $errors[] = 'Passwords do not match';
}

// If there are validation errors, redirect back with errors
if (!empty($errors)) {
    $_SESSION['registration_errors'] = $errors;
    $_SESSION['registration_old_data'] = $_POST;
    redirect(SITE_URL . '/public/register.php');
}

try {
    // Create database connection
    $database = new Database();
    $db = $database->connect();
    
    // Create User instance
    $user = new User($db);
    
    // Check if NIDA ID, VOTE ID, or Email already exists
    if ($registration_method === 'nida' && $nida_id) {
        if ($user->nidaExists($nida_id)) {
            $_SESSION['registration_errors'] = ['This NIDA ID is already registered. Please login or use a different ID.'];
            $_SESSION['registration_old_data'] = $_POST;
            redirect(SITE_URL . '/public/register.php');
        }
    }
    
    if ($registration_method === 'voteid' && $vote_id) {
        if ($user->voteIdExists($vote_id)) {
            $_SESSION['registration_errors'] = ['This VOTE ID is already registered. Please login or use a different ID.'];
            $_SESSION['registration_old_data'] = $_POST;
            redirect(SITE_URL . '/public/register.php');
        }
    }
    
    if ($user->emailExists($email)) {
        $_SESSION['registration_errors'] = ['This email address is already registered. Please login or use a different email.'];
        $_SESSION['registration_old_data'] = $_POST;
        redirect(SITE_URL . '/public/register.php');
    }
    
    // Hash password using bcrypt
    $password_hash = $user->hashPassword($password);
    
    // Prepare user data
    $userData = [
        'nida_id' => $nida_id,
        'vote_id' => $vote_id,
        'full_name' => $full_name,
        'email' => $email,
        'phone' => $phone,
        'date_of_birth' => $dob,
        'password_hash' => $password_hash,
        'role' => 'voter',
        'account_status' => 'active'
    ];
    
    // Register user
    $user_id = $user->register($userData);
    
    if ($user_id) {
        // Log the registration (optional - implement audit logging)
        // $audit->log('REGISTRATION', 'user', $user_id, 'User registered successfully');
        
        // TODO: Send verification email/SMS in production
        // sendVerificationEmail($email, $full_name);
        // sendVerificationSMS($phone, $full_name);
        
        // Set success message
        setFlashMessage('success', 'Registration successful! You can now log in with your credentials.');
        
        // Clear old form data
        unset($_SESSION['registration_old_data']);
        
        // Redirect to login page
        redirect(SITE_URL . '/public/login.php');
    } else {
        throw new Exception('Registration failed. Please try again.');
    }
    
} catch (Exception $e) {
    // Log error
    error_log('Registration Error: ' . $e->getMessage());
    
    // Set error message
    $_SESSION['registration_errors'] = ['An error occurred during registration. Please try again later.'];
    $_SESSION['registration_old_data'] = $_POST;
    redirect(SITE_URL . '/public/register.php');
}
?>
