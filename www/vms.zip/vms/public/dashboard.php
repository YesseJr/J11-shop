<?php
/**
 * Vote Management System
 * Voter Dashboard
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

// Include configuration
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/Vote.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect(SITE_URL . '/public/login.php');
}

// Get user info from session
$user_id = getCurrentUserId();
$full_name = $_SESSION['full_name'] ?? 'Voter';
$email = $_SESSION['email'] ?? '';
$role = getCurrentUserRole();

// Get database connection
$database = new Database();
$db = $database->connect();
$vote = new Vote($db);

// Get active elections
$active_elections = $vote->getActiveElections();

// Get voter's elections and voting status
$query = "SELECT vl.*, e.name as election_name, e.start_date, e.end_date, e.status 
          FROM voters_list vl 
          JOIN elections e ON vl.election_id = e.election_id 
          WHERE vl.user_id = :user_id 
          ORDER BY e.start_date DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$my_elections = $stmt->fetchAll();

// Count votes cast by user
$query = "SELECT COUNT(*) as count FROM vote_receipts WHERE user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$votes_cast = $stmt->fetch()['count'];

// Get flash message if any
$flash_message = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | VMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f5f5f5;
        }
        
        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .dashboard-header {
            background: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .welcome-text h1 {
            margin: 0 0 5px 0;
            color: #333;
            font-size: 28px;
        }
        
        .welcome-text p {
            margin: 0;
            color: #666;
        }
        
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .logout-btn:hover {
            background: #c82333;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .dashboard-card {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .dashboard-card h2 {
            margin: 0 0 15px 0;
            color: #333;
            font-size: 20px;
        }
        
        .dashboard-card p {
            color: #666;
            line-height: 1.6;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
        }
        
        .status-active {
            background: #d4edda;
            color: #155724;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: bold;
            color: #333;
        }
        
        .info-value {
            color: #666;
        }
    </style>
</head>
<body>
    <!-- Tanzania Flag Stripe -->
    <div class="flag-stripe"></div>
    
    <div class="dashboard-container">
        
        <!-- Display Flash Messages -->
        <?php if ($flash_message): ?>
            <div class="alert alert-<?php echo htmlspecialchars($flash_message['type']); ?>" style="margin-bottom: 20px;">
                <span><?php echo $flash_message['type'] === 'success' ? '✓' : '⚠️'; ?></span>
                <span><?php echo htmlspecialchars($flash_message['message']); ?></span>
            </div>
        <?php endif; ?>
        
        <!-- Dashboard Header -->
        <div class="dashboard-header">
            <div class="welcome-text">
                <h1>Welcome, <?php echo htmlspecialchars($full_name); ?>! 👋</h1>
                <p>Your dashboard - Vote Management System</p>
            </div>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
        
        <!-- Dashboard Grid -->
        <div class="dashboard-grid">
            
            <!-- Account Info Card -->
            <div class="dashboard-card">
                <h2>👤 Account Information</h2>
                <div class="info-row">
                    <span class="info-label">Full Name:</span>
                    <span class="info-value"><?php echo htmlspecialchars($full_name); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Email:</span>
                    <span class="info-value"><?php echo htmlspecialchars($email); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Role:</span>
                    <span class="info-value"><?php echo htmlspecialchars(ucfirst($role)); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Status:</span>
                    <span class="status-badge status-active">Active</span>
                </div>
            </div>
            
            <!-- Voting Status Card -->
            <div class="dashboard-card">
                <h2>🗳️ Your Elections</h2>
                
                <?php if (count($my_elections) > 0): ?>
                    <?php foreach ($my_elections as $election): ?>
                        <div style="margin: 15px 0; padding: 15px; background: #f9f9f9; border-radius: 8px;">
                            <strong style="color: #333;"><?php echo htmlspecialchars($election['election_name']); ?></strong>
                            <div style="margin-top: 8px; font-size: 14px;">
                                <span class="status-badge status-<?php echo $election['has_voted'] ? 'active' : 'pending'; ?>">
                                    <?php echo $election['has_voted'] ? '✓ Voted' : '⏳ Not Voted'; ?>
                                </span>
                                <?php if (!$election['has_voted'] && $election['status'] === 'active'): ?>
                                    <div style="margin-top: 10px;">
                                        <a href="vote.php?election_id=<?php echo $election['election_id']; ?>" 
                                           style="color: #4472C4; font-weight: bold; text-decoration: none;">
                                            → Cast Your Vote
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="color: #666;">You are not registered for any elections yet.</p>
                <?php endif; ?>
            </div>
            
            <!-- Quick Stats Card -->
            <div class="dashboard-card">
                <h2>📊 Your Statistics</h2>
                <div class="info-row">
                    <span class="info-label">Elections Participated:</span>
                    <span class="info-value"><?php echo count($my_elections); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Votes Cast:</span>
                    <span class="info-value"><?php echo $votes_cast; ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Active Elections:</span>
                    <span class="info-value"><?php echo count($active_elections); ?></span>
                </div>
            </div>
            
            <!-- Quick Actions Card -->
            <div class="dashboard-card">
                <h2>⚡ Quick Actions</h2>
                <?php if (count($active_elections) > 0): ?>
                    <p>
                        <a href="vote.php?election_id=<?php echo $active_elections[0]['election_id']; ?>" 
                           style="color: #4472C4; text-decoration: none; font-weight: bold;">
                            → Cast Your Vote
                        </a>
                    </p>
                <?php else: ?>
                    <p style="color: #999;">
                        → Cast Your Vote (No active elections)
                    </p>
                <?php endif; ?>
                <p>
                    <a href="results.php?election_id=<?php echo count($my_elections) > 0 ? $my_elections[0]['election_id'] : '1'; ?>" 
                       style="color: #4472C4; text-decoration: none; font-weight: bold;">
                        → View Election Results
                    </a>
                </p>
                <p>
                    <a href="profile.php" style="color: #4472C4; text-decoration: none; font-weight: bold;">
                        → Update Profile
                    </a>
                </p>
                <p>
                    <a href="verify_receipt.php" style="color: #4472C4; text-decoration: none; font-weight: bold;">
                        → Verify Vote Receipt
                    </a>
                </p>
            </div>
            
        </div>
        
        <!-- Additional Info -->
        <div class="dashboard-card">
            <h2>📢 Important Information</h2>
            <ul style="color: #666; line-height: 1.8;">
                <li>✅ <strong>Your account is registered and verified</strong></li>
                <li>🗳️ <strong>You can vote once per election</strong></li>
                <li>🔒 <strong>Your vote is completely anonymous and encrypted</strong></li>
                <li>📱 <strong>You will receive an SMS confirmation after voting</strong></li>
                <li>⏰ <strong>Make sure to vote before the election closes</strong></li>
            </ul>
        </div>
        
    </div>
    
    <script>
        // Auto-hide flash messages after 5 seconds
        setTimeout(() => {
            const alert = document.querySelector('.alert');
            if (alert) {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.5s';
                setTimeout(() => {
                    alert.style.display = 'none';
                }, 500);
            }
        }, 5000);
    </script>
</body>
</html>
