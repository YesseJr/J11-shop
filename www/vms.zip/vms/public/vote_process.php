<?php
/**
 * Vote Management System
 * Vote Processing Script
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/Vote.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect(SITE_URL . '/public/login.php');
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(SITE_URL . '/public/vote.php');
}

// Get form data
$user_id = getCurrentUserId();
$election_id = intval($_POST['election_id'] ?? 0);
$candidate_id = intval($_POST['candidate_id'] ?? 0);
$candidate_name = sanitizeInput($_POST['candidate_name'] ?? '');
$candidate_party = sanitizeInput($_POST['candidate_party'] ?? '');

// Validate inputs
if ($election_id === 0 || $candidate_id === 0) {
    setFlashMessage('error', 'Invalid vote submission. Please try again.');
    redirect(SITE_URL . '/public/vote.php?election_id=' . $election_id);
}

try {
    // Create database connection
    $database = new Database();
    $db = $database->connect();
    
    // Create Vote instance
    $vote = new Vote($db);
    
    // Cast the vote
    $result = $vote->castVote($user_id, $election_id, $candidate_id);
    
    if ($result['success']) {
        // Store receipt info in session for success page
        $_SESSION['vote_success'] = [
            'candidate_name' => $candidate_name,
            'candidate_party' => $candidate_party,
            'receipt_code' => $result['receipt_code'],
            'election_id' => $election_id
        ];
        
        // Redirect to success page
        redirect(SITE_URL . '/public/vote_success.php');
    } else {
        // Vote failed
        setFlashMessage('error', $result['message']);
        redirect(SITE_URL . '/public/vote.php?election_id=' . $election_id);
    }
    
} catch (Exception $e) {
    error_log('Vote Processing Error: ' . $e->getMessage());
    setFlashMessage('error', 'An error occurred while processing your vote. Please try again.');
    redirect(SITE_URL . '/public/vote.php?election_id=' . $election_id);
}
?>
