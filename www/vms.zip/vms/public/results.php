<?php
/**
 * Vote Management System
 * Election Results Page
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/Results.php';

// Get election ID from URL
$election_id = $_GET['election_id'] ?? 1;

// Create database connection
$database = new Database();
$db = $database->connect();

// Create Results instance
$results_manager = new Results($db);

// Check if results can be viewed
$can_view = $results_manager->canViewResults($election_id);

// Get results
$results_data = $results_manager->getResults($election_id);

// Get available elections
$available_elections = $results_manager->getAvailableElections();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Election Results | VMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        body {
            background: #f5f5f5;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        
        .results-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .results-header {
            background: linear-gradient(135deg, #4472C4, #2E5C8A);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .results-header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
        }
        
        .results-header .subtitle {
            opacity: 0.95;
            font-size: 18px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .stat-icon {
            font-size: 40px;
            margin-bottom: 10px;
        }
        
        .stat-value {
            font-size: 36px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #666;
            font-size: 14px;
        }
        
        .winner-card {
            background: linear-gradient(135deg, #4CAF50, #45a049);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
            text-align: center;
        }
        
        .winner-icon {
            font-size: 60px;
            margin-bottom: 15px;
        }
        
        .winner-title {
            font-size: 24px;
            margin-bottom: 10px;
        }
        
        .winner-name {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .winner-details {
            font-size: 18px;
            opacity: 0.95;
        }
        
        .results-table {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .results-table h2 {
            margin: 0 0 20px 0;
            color: #333;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: #f9f9f9;
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            font-weight: bold;
            color: #333;
        }
        
        .rank-badge {
            display: inline-block;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #4472C4;
            color: white;
            line-height: 30px;
            text-align: center;
            font-weight: bold;
        }
        
        .rank-badge.first {
            background: #FFD700;
            color: #333;
        }
        
        .rank-badge.second {
            background: #C0C0C0;
            color: #333;
        }
        
        .rank-badge.third {
            background: #CD7F32;
            color: white;
        }
        
        .progress-bar {
            height: 25px;
            background: #e0e0e0;
            border-radius: 12px;
            overflow: hidden;
            position: relative;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4472C4, #2E5C8A);
            transition: width 1s ease;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding-right: 10px;
            color: white;
            font-weight: bold;
            font-size: 12px;
        }
        
        .charts-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .chart-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .chart-card h3 {
            margin: 0 0 20px 0;
            color: #333;
        }
        
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        
        .back-button:hover {
            background: #5a6268;
        }
        
        .not-available {
            background: #fff3cd;
            border: 2px solid #ffc107;
            padding: 40px;
            border-radius: 12px;
            text-align: center;
        }
        
        .not-available h2 {
            color: #856404;
            margin: 0 0 15px 0;
        }
        
        .not-available p {
            color: #856404;
            font-size: 16px;
        }
        
        @media (max-width: 768px) {
            .charts-section {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    
    <div class="results-container">
        
        <?php if (isLoggedIn()): ?>
            <a href="dashboard.php" class="back-button">← Back to Dashboard</a>
        <?php endif; ?>
        
        <?php if (!$can_view['can_view']): ?>
            <!-- Results Not Available -->
            <div class="not-available">
                <h2>⏳ Results Not Available Yet</h2>
                <p><?php echo htmlspecialchars($can_view['reason']); ?></p>
                <p style="margin-top: 20px;">
                    <a href="dashboard.php" class="back-button">Return to Dashboard</a>
                </p>
            </div>
            
        <?php elseif (!$results_data['success']): ?>
            <!-- Error Loading Results -->
            <div class="not-available">
                <h2>⚠️ Error Loading Results</h2>
                <p><?php echo htmlspecialchars($results_data['message'] ?? 'Unknown error'); ?></p>
            </div>
            
        <?php else: ?>
            
            <?php
            $election = $results_data['election'];
            $results = $results_data['results'];
            $winner = $results_data['winner'];
            $total_votes = $results_data['total_votes'];
            $turnout = $results_data['turnout_percentage'];
            ?>
            
            <!-- Header -->
            <div class="results-header">
                <h1>🏆 Election Results<?php echo (isset($can_view['live']) && $can_view['live']) ? ' <span style="color: #FFD700;">● LIVE</span>' : ''; ?></h1>
                <div class="subtitle">
                    <?php echo htmlspecialchars($election['name']); ?>
                </div>
                <?php if (isset($can_view['live']) && $can_view['live']): ?>
                    <div style="margin-top: 10px; padding: 8px 16px; background: rgba(255, 215, 0, 0.2); border-radius: 6px; display: inline-block;">
                        <small style="color: #856404;">⚡ Live Results - Voting in progress</small>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">🗳️</div>
                    <div class="stat-value"><?php echo number_format($total_votes); ?></div>
                    <div class="stat-label">Total Votes Cast</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value"><?php echo number_format($election['total_voters']); ?></div>
                    <div class="stat-label">Eligible Voters</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-value"><?php echo $turnout; ?>%</div>
                    <div class="stat-label">Voter Turnout</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">🎯</div>
                    <div class="stat-value"><?php echo count($results); ?></div>
                    <div class="stat-label">Candidates</div>
                </div>
            </div>
            
            <!-- Winner Card -->
            <?php if ($winner && $total_votes > 0): ?>
                <div class="winner-card">
                    <div class="winner-icon">👑</div>
                    <div class="winner-title">Election Winner</div>
                    <div class="winner-name"><?php echo htmlspecialchars($winner['full_name']); ?></div>
                    <div class="winner-details">
                        <?php echo htmlspecialchars($winner['party_affiliation']); ?> • 
                        <?php echo number_format($winner['votes']); ?> votes (<?php echo $winner['percentage']; ?>%)
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Results Table -->
            <div class="results-table">
                <h2>📋 Detailed Results</h2>
                
                <table>
                    <thead>
                        <tr>
                            <th style="width: 60px;">Rank</th>
                            <th>Candidate</th>
                            <th>Party</th>
                            <th style="width: 100px; text-align: center;">Votes</th>
                            <th style="width: 300px;">Vote Share</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $index => $candidate): ?>
                            <tr>
                                <td>
                                    <span class="rank-badge <?php 
                                        echo $index === 0 ? 'first' : ($index === 1 ? 'second' : ($index === 2 ? 'third' : ''));
                                    ?>">
                                        <?php echo $index + 1; ?>
                                    </span>
                                </td>
                                <td><strong><?php echo htmlspecialchars($candidate['full_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($candidate['party_affiliation']); ?></td>
                                <td style="text-align: center; font-weight: bold;">
                                    <?php echo number_format($candidate['votes']); ?>
                                </td>
                                <td>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: <?php echo $candidate['percentage']; ?>%;">
                                            <?php echo $candidate['percentage']; ?>%
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Charts -->
            <div class="charts-section">
                <div class="chart-card">
                    <h3>📊 Vote Distribution</h3>
                    <canvas id="barChart" height="300"></canvas>
                </div>
                
                <div class="chart-card">
                    <h3>🥧 Vote Share</h3>
                    <canvas id="pieChart" height="300"></canvas>
                </div>
            </div>
            
            <!-- Chart JavaScript -->
            <script>
                const labels = <?php echo json_encode(array_column($results, 'full_name')); ?>;
                const votes = <?php echo json_encode(array_column($results, 'votes')); ?>;
                const colors = ['#4472C4', '#70AD47', '#ED7D31', '#FFC000', '#5B9BD5'];
                
                // Bar Chart
                new Chart(document.getElementById('barChart'), {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Votes',
                            data: votes,
                            backgroundColor: colors,
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false }
                        },
                        scales: {
                            y: { beginAtZero: true }
                        }
                    }
                });
                
                // Pie Chart
                new Chart(document.getElementById('pieChart'), {
                    type: 'pie',
                    data: {
                        labels: labels,
                        datasets: [{
                            data: votes,
                            backgroundColor: colors,
                            borderWidth: 2,
                            borderColor: '#fff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            }
                        }
                    }
                });
            </script>
            
        <?php endif; ?>
        
    </div>
</body>
</html>
