<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Vote Management System - Voter Registration">
    <title>Voter Registration | VMS</title>
    
    <!-- Stylesheet -->
    <link rel="stylesheet" href="../assets/css/style.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="../assets/images/emblem.png">
</head>
<body>
    <!-- Tanzania Flag Stripe -->
    <div class="flag-stripe"></div>
    
    <!-- Authentication Wrapper -->
    <div class="auth-wrapper" style="background-image: url('../assets/images/bg-kilimanjaro.jpg');">
        
        <!-- Registration Card -->
        <div class="auth-card large">
            
            <!-- Header with Emblem -->
            <div class="auth-header">
                <div class="emblem">
                    <img src="../assets/images/emblem.png" alt="Tanzania Emblem">
                </div>
                <h1 class="auth-title">Voter Registration</h1>
                <p class="auth-subtitle">Register by entering your NIDA ID or VOTE ID to access the voting system</p>
            </div>
            
            <!-- Tab Switcher -->
            <div class="tab-switcher">
                <button type="button" class="tab-button active" data-tab="nida">
                    <span class="tab-icon">🆔</span>
                    <span>NIDA ID</span>
                </button>
                <button type="button" class="tab-button" data-tab="voteid">
                    <span class="tab-icon">🗳️</span>
                    <span>VOTE ID</span>
                </button>
            </div>
            
            <!-- Registration Form -->
            <form id="registration-form" action="register_process.php" method="POST">
                
                <!-- Hidden field for registration method -->
                <input type="hidden" name="registration_method" id="registration_method" value="nida">
                
                <!-- NIDA ID Fields (Default visible) -->
                <div id="nida-fields">
                    <div class="form-group">
                        <label for="nida_id" class="form-label">NIDA ID Number <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <span class="input-icon">🆔</span>
                            <input 
                                type="text" 
                                id="nida_id" 
                                name="nida_id" 
                                class="form-input" 
                                placeholder="Enter your NIDA ID"
                                pattern="\d{8}-\d{5}-\d{5}-\d{2}"
                                required
                            >
                        </div>
                        <div id="nida-error" class="error-message"></div>
                        <div class="help-text">Format: YYYYMMDD-XXXXX-XXXXX-XX</div>
                    </div>
                </div>
                
                <!-- VOTE ID Fields (Hidden by default) -->
                <div id="voteid-fields" class="hidden">
                    <div class="form-group">
                        <label for="vote_id" class="form-label">VOTE ID Number <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <span class="input-icon">🗳️</span>
                            <input 
                                type="text" 
                                id="vote_id" 
                                name="vote_id" 
                                class="form-input" 
                                placeholder="Enter your VOTE ID"
                            >
                        </div>
                        <div id="voteid-error" class="error-message"></div>
                    </div>
                </div>
                
                <!-- Full Name -->
                <div class="form-group">
                    <label for="full_name" class="form-label">Full Name <span class="required">*</span></label>
                    <div class="input-wrapper">
                        <span class="input-icon">👤</span>
                        <input 
                            type="text" 
                            id="full_name" 
                            name="full_name" 
                            class="form-input" 
                            placeholder="Enter your full name"
                            required
                        >
                    </div>
                    <div id="name-error" class="error-message"></div>
                </div>
                
                <!-- Date of Birth & Phone (Two columns) -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="dob" class="form-label">Date of Birth <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <span class="input-icon">📅</span>
                            <input 
                                type="date" 
                                id="dob" 
                                name="dob" 
                                class="form-input" 
                                required
                            >
                            <button type="button" class="toggle-password">👁️‍🗨️</button>
                        </div>
                        <div id="dob-error" class="error-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone" class="form-label">Phone Number <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <span class="input-icon">📱</span>
                            <input 
                                type="tel" 
                                id="phone" 
                                name="phone" 
                                class="form-input" 
                                placeholder="+255 XXX XXX XXX"
                                value="+255 "
                                required
                            >
                        </div>
                        <div id="phone-error" class="error-message"></div>
                    </div>
                </div>
                
                <!-- Email Address -->
                <div class="form-group">
                    <label for="email" class="form-label">Email Address <span class="required">*</span></label>
                    <div class="input-wrapper">
                        <span class="input-icon">📧</span>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            class="form-input" 
                            placeholder="Enter your email address"
                            required
                        >
                    </div>
                    <div id="email-error" class="error-message"></div>
                </div>
                
                <!-- Password & Confirm Password (Two columns) -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="password" class="form-label">Create Password <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <span class="input-icon">🔒</span>
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                class="form-input" 
                                placeholder="At least 8 characters"
                                required
                            >
                            <button type="button" class="toggle-password">👁️‍🗨️</button>
                        </div>
                        <div id="password-error" class="error-message"></div>
                        
                        <!-- Password Strength Indicator -->
                        <div class="password-strength">
                            <div class="strength-bar"></div>
                            <div class="strength-bar"></div>
                            <div class="strength-bar"></div>
                            <div class="strength-bar"></div>
                        </div>
                        <div class="strength-text">Password strength: Weak</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password" class="form-label">Confirm Password <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <span class="input-icon">🔒</span>
                            <input 
                                type="password" 
                                id="confirm_password" 
                                name="confirm_password" 
                                class="form-input" 
                                placeholder="Confirm your password"
                                required
                            >
                            <button type="button" class="toggle-password">👁️‍🗨️</button>
                        </div>
                        <div id="confirm-password-error" class="error-message"></div>
                    </div>
                </div>
                
                <!-- Password Requirements -->
                <div class="password-requirements">
                    <p><strong>Password must contain:</strong></p>
                    <div class="requirement-item" id="req-length">At least 8 characters</div>
                    <div class="requirement-item" id="req-upper">At least one uppercase letter</div>
                    <div class="requirement-item" id="req-lower">At least one lowercase letter</div>
                    <div class="requirement-item" id="req-number">At least one number</div>
                    <div class="requirement-item" id="req-special">At least one special character (!@#$%^&*)</div>
                </div>
                
                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary mt-3">
                    <span class="spinner"></span>
                    <span class="btn-text">Register Account</span>
                </button>
                
            </form>
            
            <!-- Footer -->
            <div class="auth-footer">
                <p>Already have an account? <a href="login.php">Sign In</a></p>
            </div>
            
            <!-- Support Link -->
            <div class="support-link">
                <p>Need help? <a href="support.php">Contact Support</a></p>
            </div>
            
        </div>
        
    </div>
    
    <!-- JavaScript -->
    <script src="../assets/js/registration.js"></script>
    
    <script>
        // Update hidden field when tab is switched
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', function() {
                document.getElementById('registration_method').value = this.dataset.tab;
            });
        });
    </script>
</body>
</html>
