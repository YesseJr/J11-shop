<?php
/**
 * Vote Management System
 * Logout Script
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

// Include configuration
require_once '../config/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect(SITE_URL . '/public/login.php');
}

// Get user info before destroying session
$user_name = $_SESSION['full_name'] ?? 'User';

// Log logout (optional - implement audit logging)
// $user_id = getCurrentUserId();
// $audit->log('LOGOUT', 'user', $user_id, 'User logged out');

// Remove remember me cookie if exists
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 3600, '/', '', false, true);
    unset($_COOKIE['remember_token']);
    
    // TODO: Remove token from database
    // $query = "DELETE FROM remember_tokens WHERE token = ?";
}

// Destroy all session data
session_unset();
session_destroy();

// Start new session for flash message
session_start();
setFlashMessage('success', 'You have been logged out successfully. See you next time!');

// Redirect to login page
redirect(SITE_URL . '/public/login.php');
?>
