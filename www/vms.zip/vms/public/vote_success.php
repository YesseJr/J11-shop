<?php
/**
 * Vote Management System
 * Vote Success Page
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../config/config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect(SITE_URL . '/public/login.php');
}

// Check if vote success data exists
if (!isset($_SESSION['vote_success'])) {
    redirect(SITE_URL . '/public/dashboard.php');
}

// Get vote success data
$vote_data = $_SESSION['vote_success'];
$candidate_name = htmlspecialchars($vote_data['candidate_name']);
$candidate_party = htmlspecialchars($vote_data['candidate_party']);
$receipt_code = htmlspecialchars($vote_data['receipt_code']);

// Clear the session data
unset($_SESSION['vote_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote Submitted Successfully | VMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        
        .success-container {
            background: white;
            padding: 50px;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            text-align: center;
            animation: slideUp 0.5s ease;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .success-icon {
            width: 100px;
            height: 100px;
            background: #4CAF50;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            animation: scaleIn 0.6s ease 0.2s both;
        }
        
        @keyframes scaleIn {
            from {
                transform: scale(0);
            }
            to {
                transform: scale(1);
            }
        }
        
        .success-icon::after {
            content: '✓';
            font-size: 60px;
            color: white;
            font-weight: bold;
        }
        
        .success-title {
            font-size: 32px;
            font-weight: bold;
            margin: 0 0 15px 0;
            color: #333;
        }
        
        .success-message {
            font-size: 18px;
            color: #666;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .vote-details {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            text-align: left;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        
        .detail-row:last-child {
            border-bottom: none;
        }
        
        .detail-label {
            font-weight: bold;
            color: #333;
        }
        
        .detail-value {
            color: #666;
        }
        
        .receipt-code {
            background: #4472C4;
            color: white;
            padding: 15px;
            border-radius: 8px;
            font-size: 24px;
            font-weight: bold;
            letter-spacing: 2px;
            margin: 20px 0;
            font-family: 'Courier New', monospace;
        }
        
        .actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
        }
        
        .btn {
            padding: 14px 28px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
            display: inline-block;
        }
        
        .btn-primary {
            background: #4472C4;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2E5C8A;
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: white;
            color: #4472C4;
            border: 2px solid #4472C4;
        }
        
        .btn-secondary:hover {
            background: #4472C4;
            color: white;
        }
        
        .important-note {
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            color: #856404;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="success-container">
        <div class="success-icon"></div>
        
        <h1 class="success-title">Your vote has been submitted!</h1>
        
        <p class="success-message">
            Thank you for voting in the <strong>Village / Street Chairperson</strong> Election. 
            Your vote for <strong><?php echo $candidate_name; ?></strong> has been recorded.
        </p>
        
        <div class="vote-details">
            <h3 style="margin: 0 0 15px 0; color: #333;">📋 Vote Confirmation</h3>
            <div class="detail-row">
                <span class="detail-label">Candidate:</span>
                <span class="detail-value"><?php echo $candidate_name; ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Party:</span>
                <span class="detail-value"><?php echo $candidate_party; ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Time:</span>
                <span class="detail-value"><?php echo date('F j, Y \a\t g:i A'); ?></span>
            </div>
        </div>
        
        <div>
            <h3 style="margin: 0 0 10px 0; color: #333;">🎫 Your Receipt Code</h3>
            <p style="color: #666; font-size: 14px; margin: 0 0 10px 0;">
                Save this code to verify your vote was counted:
            </p>
            <div class="receipt-code">
                <?php echo $receipt_code; ?>
            </div>
        </div>
        
        <div class="important-note">
            <strong>⚠️ Important:</strong> This receipt proves you voted but does NOT reveal your choice. 
            Keep it safe to verify your vote was counted.
        </div>
        
        <div class="actions">
            <a href="dashboard.php" class="btn btn-primary">
                ✓ Return to Dashboard
            </a>
            <a href="verify_receipt.php?code=<?php echo urlencode($receipt_code); ?>" class="btn btn-secondary">
                🔍 Verify Receipt
            </a>
        </div>
        
        <p style="margin-top: 30px; color: #999; font-size: 13px;">
            © 2026 Local Government Electoral Commission | Privacy Policy | Terms
        </p>
    </div>
    
    <script>
        // Auto-redirect after 30 seconds
        setTimeout(() => {
            if (confirm('Auto-redirecting to dashboard. Click Cancel to stay.')) {
                window.location.href = 'dashboard.php';
            }
        }, 30000);
    </script>
</body>
</html>
