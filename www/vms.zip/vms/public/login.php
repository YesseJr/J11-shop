<?php
/**
 * Vote Management System
 * Login Page
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

// Include configuration
require_once '../config/config.php';

// If already logged in, redirect to dashboard
if (isLoggedIn()) {
    redirect(SITE_URL . '/public/dashboard.php');
}

// Get flash message if any
$flash_message = getFlashMessage();

// Get old input data if form had errors
$old_data = $_SESSION['login_old_data'] ?? [];
$errors = $_SESSION['login_errors'] ?? [];

// Clear old data and errors
unset($_SESSION['login_old_data']);
unset($_SESSION['login_errors']);

// Check if redirected due to session timeout
$timeout_message = isset($_GET['timeout']) ? 'Your session has expired. Please login again.' : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Vote Management System - Secure Login">
    <title>Sign In | VMS</title>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: url('../assets/images/bg-kilimanjaro.jpg') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        /* Tanzania Flag Stripe */
        .flag-stripe {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 8px;
            background: linear-gradient(to right, 
                #1EB53A 0%, #1EB53A 33%, 
                #000000 33%, #000000 36%,
                #FCD116 36%, #FCD116 39%,
                #000000 39%, #000000 42%,
                #00A3DD 42%, #00A3DD 100%);
            z-index: 1000;
        }
        
        /* Auth Card */
        .auth-card {
            background: white;
            border-radius: 16px;
            padding: 40px;
            width: 100%;
            max-width: 480px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        
        /* Header */
        .auth-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .emblem img {
            width: 80px;
            height: 80px;
            object-fit: contain;
            margin-bottom: 20px;
        }
        
        .auth-title {
            font-size: 28px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .auth-subtitle {
            font-size: 15px;
            color: #666;
            line-height: 1.5;
        }
        
        /* Tab Switcher */
        .tab-switcher {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 25px;
        }
        
        .tab-button {
            padding: 12px;
            border: none;
            background: #f5f5f5;
            color: #666;
            font-size: 15px;
            font-weight: 500;
            cursor: pointer;
            border-radius: 8px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .tab-button.active {
            background: #e8f0fe;
            color: #1a73e8;
        }
        
        /* Form Groups */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 8px;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .form-input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s;
            background: #f8f9fa;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #1a73e8;
            background: white;
        }
        
        .form-input::placeholder {
            color: #999;
        }
        
        .toggle-password {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            font-size: 20px;
            color: #666;
        }
        
        /* Sign In Button */
        .btn-primary {
            width: 100%;
            padding: 14px;
            background: #1e3a8a;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }
        
        .btn-primary:hover {
            background: #1e40af;
        }
        
        /* Footer Text */
        .footer-text {
            text-align: center;
            font-size: 13px;
            color: #666;
            margin-top: 20px;
            line-height: 1.6;
        }
        
        .support-link {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
            color: #666;
        }
        
        .support-link a {
            color: #2c3e50;
            font-weight: 600;
            text-decoration: none;
        }
        
        /* Alerts */
        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }
        
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffc107;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .hidden {
            display: none;
        }
        
        @media (max-width: 480px) {
            .auth-card {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Tanzania Flag Stripe -->
    <div class="flag-stripe"></div>
    
    <!-- Login Card -->
    <div class="auth-card">
        
        <!-- Header with Emblem -->
        <div class="auth-header">
            <div class="emblem">
                <img src="../assets/images/emblem.png" alt="Tanzania Emblem" onerror="this.style.display='none'">
            </div>
            <h1 class="auth-title">Voter Authentication</h1>
            <p class="auth-subtitle">Sign in with your NIDA or VOTE ID to access the voting system</p>
        </div>
        
        <!-- Display Flash Messages -->
        <?php if ($flash_message): ?>
            <div class="alert alert-<?php echo htmlspecialchars($flash_message['type']); ?>">
                <?php echo htmlspecialchars($flash_message['message']); ?>
            </div>
        <?php endif; ?>
        
        <!-- Display Timeout Message -->
        <?php if ($timeout_message): ?>
            <div class="alert alert-warning">
                <?php echo htmlspecialchars($timeout_message); ?>
            </div>
        <?php endif; ?>
        
        <!-- Display Errors -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $error): ?>
                    <p style="margin: 5px 0;"><?php echo htmlspecialchars($error); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <!-- Tab Switcher -->
        <div class="tab-switcher">
            <button type="button" class="tab-button active" data-tab="nida">
                <span>🆔</span>
                <span>NIDA ID</span>
            </button>
            <button type="button" class="tab-button" data-tab="voteid">
                <span>🗳️</span>
                <span>VOTE ID</span>
            </button>
        </div>
        
        <!-- Login Form -->
        <form id="login-form" action="login_process.php" method="POST">
            
            <!-- Hidden field for login method -->
            <input type="hidden" name="login_method" id="login_method" value="nida">
            
            <!-- NIDA ID Fields (Default visible) -->
            <div id="nida-fields">
                <div class="form-group">
                    <label for="nida_id" class="form-label">Enter your NIDA ID</label>
                    <input 
                        type="text" 
                        id="nida_id" 
                        name="nida_id" 
                        class="form-input" 
                        placeholder="Enter your NIDA ID"
                        value="<?php echo htmlspecialchars($old_data['nida_id'] ?? ''); ?>"
                    >
                </div>
            </div>
            
            <!-- VOTE ID Fields (Hidden by default) -->
            <div id="voteid-fields" class="hidden">
                <div class="form-group">
                    <label for="vote_id" class="form-label">Enter your VOTE ID</label>
                    <input 
                        type="text" 
                        id="vote_id" 
                        name="vote_id" 
                        class="form-input" 
                        placeholder="Enter your VOTE ID"
                        value="<?php echo htmlspecialchars($old_data['vote_id'] ?? ''); ?>"
                    >
                </div>
            </div>
            
            <!-- Password -->
            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <div class="input-wrapper">
                    <input 
                        type="text" 
                        id="password" 
                        name="password" 
                        class="form-input" 
                        placeholder="Enter your password"
                        required
                    >
                    <button type="button" class="toggle-password" onclick="togglePassword()">👁️</button>
                </div>
                <small style="color: #666; display: block; margin-top: 5px;">
                    💡 Tip: You can use your date of birth (DD/MM/YYYY) as password
                </small>
            </div>
            
            <!-- Submit Button -->
            <button type="submit" class="btn-primary">
                Sign In with NIDA ID
            </button>
            
        </form>
        
        <!-- Footer -->
        <div class="footer-text">
            Your credentials will be verified before granting access to voting system
        </div>
        
        <div class="support-link">
            Need help? <a href="#">Contact support</a>
        </div>
        
    </div>
    
    <!-- JavaScript -->
    <script>
        // Tab switching
        const tabButtons = document.querySelectorAll('.tab-button');
        const nidaFields = document.getElementById('nida-fields');
        const voteIdFields = document.getElementById('voteid-fields');
        const nidaInput = document.getElementById('nida_id');
        const voteIdInput = document.getElementById('vote_id');
        const submitBtn = document.querySelector('.btn-primary');
        
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                tabButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                // Toggle field visibility
                if (this.dataset.tab === 'nida') {
                    nidaFields.classList.remove('hidden');
                    voteIdFields.classList.add('hidden');
                    nidaInput.required = true;
                    voteIdInput.required = false;
                    document.getElementById('login_method').value = 'nida';
                    submitBtn.textContent = 'Sign In with NIDA ID';
                } else {
                    nidaFields.classList.add('hidden');
                    voteIdFields.classList.remove('hidden');
                    voteIdInput.required = true;
                    nidaInput.required = false;
                    document.getElementById('login_method').value = 'voteid';
                    submitBtn.textContent = 'Sign In with VOTE ID';
                }
            });
        });
        
        // Password visibility toggle
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleBtn = document.querySelector('.toggle-password');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleBtn.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                toggleBtn.textContent = '👁️';
            }
        }
    </script>
</body>
</html>
