<?php
require_once '../config/config.php';
if (isLoggedIn()) { redirect(SITE_URL . '/public/dashboard.php'); }
$errors = $_SESSION['registration_errors'] ?? [];
$old_data = $_SESSION['registration_old_data'] ?? [];
unset($_SESSION['registration_errors'], $_SESSION['registration_old_data']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voter Registration | VMS</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: url('../assets/images/bg-kilimanjaro.jpg') no-repeat center center fixed; background-size: cover; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .flag-stripe { position: fixed; top: 0; left: 0; right: 0; height: 8px; background: linear-gradient(to right, #1EB53A 0% 33%, #000 33% 36%, #FCD116 36% 39%, #000 39% 42%, #00A3DD 42% 100%); z-index: 1000; }
        .auth-card { background: white; border-radius: 16px; padding: 40px; width: 100%; max-width: 480px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); max-height: 90vh; overflow-y: auto; }
        .auth-header { text-align: center; margin-bottom: 25px; }
        .emblem img { width: 80px; height: 80px; margin-bottom: 20px; }
        .auth-title { font-size: 28px; font-weight: 600; color: #2c3e50; margin-bottom: 10px; }
        .auth-subtitle { font-size: 14px; color: #666; line-height: 1.5; }
        .tab-switcher { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 25px; }
        .tab-button { padding: 12px; border: none; background: #f5f5f5; color: #666; font-size: 15px; font-weight: 500; cursor: pointer; border-radius: 8px; transition: all 0.3s; display: flex; align-items: center; justify-content: center; gap: 8px; }
        .tab-button.active { background: #e8f0fe; color: #1a73e8; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px; }
        .form-group { margin-bottom: 15px; }
        .form-label { display: block; font-size: 14px; font-weight: 500; color: #2c3e50; margin-bottom: 6px; }
        .form-input { width: 100%; padding: 12px 14px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px; background: #f8f9fa; }
        .form-input:focus { outline: none; border-color: #1a73e8; background: white; }
        .form-input::placeholder { color: #999; font-size: 13px; }
        .phone-input-wrapper { position: relative; }
        .phone-prefix { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #666; font-size: 14px; }
        .phone-input-wrapper input { padding-left: 55px; }
        .input-wrapper { position: relative; }
        .toggle-password { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; font-size: 18px; color: #666; }
        .btn-primary { width: 100%; padding: 14px; background: #1e3a8a; color: white; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; margin-top: 10px; }
        .btn-primary:hover { background: #1e40af; }
        .footer-text { text-align: center; margin-top: 20px; font-size: 14px; color: #666; }
        .footer-text a { color: #1a73e8; text-decoration: none; font-weight: 600; }
        .alert { padding: 12px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; background: #fee; color: #c33; border: 1px solid #fcc; }
        .hidden { display: none; }
        @media (max-width: 480px) { .auth-card { padding: 30px 20px; } .form-row { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    <div class="auth-card">
        <div class="auth-header">
            <div class="emblem"><img src="../assets/images/emblem.png" alt="Tanzania Emblem" onerror="this.style.display='none'"></div>
            <h1 class="auth-title">Voter Registration</h1>
            <p class="auth-subtitle">Register by entering your NIDA ID or VOTE ID to access the voting system</p>
        </div>
        <?php if (!empty($errors)): ?>
            <div class="alert"><?php foreach ($errors as $error): ?><p style="margin:3px 0;"><?php echo htmlspecialchars($error); ?></p><?php endforeach; ?></div>
        <?php endif; ?>
        <div class="tab-switcher">
            <button type="button" class="tab-button active" data-tab="nida"><span>🆔</span><span>NIDA ID</span></button>
            <button type="button" class="tab-button" data-tab="voteid"><span>🗳️</span><span>VOTE ID</span></button>
        </div>
        <form action="register_process.php" method="POST">
            <input type="hidden" name="registration_method" id="registration_method" value="nida">
            <div id="nida-field">
                <div class="form-group">
                    <label for="nida_id" class="form-label">NIDA ID Number</label>
                    <input type="text" id="nida_id" name="nida_id" class="form-input" placeholder="Enter your NIDA ID" value="<?php echo htmlspecialchars($old_data['nida_id'] ?? ''); ?>">
                </div>
            </div>
            <div id="voteid-field" class="hidden">
                <div class="form-group">
                    <label for="vote_id" class="form-label">VOTE ID Number</label>
                    <input type="text" id="vote_id" name="vote_id" class="form-input" placeholder="Enter your VOTE ID" value="<?php echo htmlspecialchars($old_data['vote_id'] ?? ''); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="full_name" class="form-input" placeholder="Enter your full name" value="<?php echo htmlspecialchars($old_data['full_name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Date of Birth</label>
                    <input type="date" name="dob" class="form-input" max="<?php echo date('Y-m-d', strtotime('-18 years')); ?>" value="<?php echo htmlspecialchars($old_data['dob'] ?? ''); ?>" required>
                    <small style="color: #666; display: block; margin-top: 5px;">You must be 18 years or older</small>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <div class="phone-input-wrapper">
                        <span class="phone-prefix">+255</span>
                        <input type="tel" name="phone" class="form-input" placeholder="Enter your phone number" value="<?php echo htmlspecialchars($old_data['phone'] ?? ''); ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-input" placeholder="Enter your email address" value="<?php echo htmlspecialchars($old_data['email'] ?? ''); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Create Password</label>
                    <div class="input-wrapper">
                        <input type="password" id="password" name="password" class="form-input" placeholder="At least 8 characters" required>
                        <button type="button" class="toggle-password" onclick="togglePassword('password')">👁️</button>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Confirm Password</label>
                    <div class="input-wrapper">
                        <input type="password" id="confirm_password" name="confirm_password" class="form-input" placeholder="Confirm your password" required>
                        <button type="button" class="toggle-password" onclick="togglePassword('confirm_password')">👁️</button>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn-primary">Register Account</button>
        </form>
        <div class="footer-text">Already have an account? <a href="login.php">Sign In</a></div>
    </div>
    <script>
        const tabs = document.querySelectorAll('.tab-button');
        const nidaField = document.getElementById('nida-field');
        const voteidField = document.getElementById('voteid-field');
        const nidaInput = document.getElementById('nida_id');
        const voteidInput = document.getElementById('vote_id');
        tabs.forEach(btn => {
            btn.addEventListener('click', function() {
                tabs.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                if (this.dataset.tab === 'nida') {
                    nidaField.classList.remove('hidden');
                    voteidField.classList.add('hidden');
                    nidaInput.required = true;
                    voteidInput.required = false;
                    document.getElementById('registration_method').value = 'nida';
                } else {
                    nidaField.classList.add('hidden');
                    voteidField.classList.remove('hidden');
                    voteidInput.required = true;
                    nidaInput.required = false;
                    document.getElementById('registration_method').value = 'voteid';
                }
            });
        });
        function togglePassword(id) {
            const field = document.getElementById(id);
            const btn = field.nextElementSibling;
            if (field.type === 'password') {
                field.type = 'text';
                btn.textContent = '🙈';
            } else {
                field.type = 'password';
                btn.textContent = '👁️';
            }
        }
    </script>
</body>
</html>
