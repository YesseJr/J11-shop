<?php
/**
 * Vote Management System
 * Login Processing Script
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

// Include configuration
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/User.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(SITE_URL . '/public/login.php');
}

// Sanitize and validate inputs
$login_method = sanitizeInput($_POST['login_method'] ?? 'nida');
$nida_id = sanitizeInput($_POST['nida_id'] ?? '');
$vote_id = sanitizeInput($_POST['vote_id'] ?? '');
$password = $_POST['password'] ?? '';
$remember_me = isset($_POST['remember_me']) && $_POST['remember_me'] == '1';

// Validation errors
$errors = [];

// 1. Validate login credentials based on method
if ($login_method === 'nida') {
    if (empty($nida_id)) {
        $errors[] = 'NIDA ID is required';
    } elseif (!preg_match(NIDA_PATTERN, $nida_id)) {
        $errors[] = 'Invalid NIDA ID format';
    }
    $identifier = $nida_id;
    $identifier_type = 'nida_id';
} else {
    if (empty($vote_id)) {
        $errors[] = 'VOTE ID is required';
    } elseif (strlen($vote_id) < 10) {
        $errors[] = 'Invalid VOTE ID';
    }
    $identifier = $vote_id;
    $identifier_type = 'vote_id';
}

// 2. Validate password
if (empty($password)) {
    $errors[] = 'Password is required';
}

// If validation errors, redirect back
if (!empty($errors)) {
    $_SESSION['login_errors'] = $errors;
    $_SESSION['login_old_data'] = $_POST;
    redirect(SITE_URL . '/public/login.php');
}

try {
    // Create database connection
    $database = new Database();
    $db = $database->connect();
    
    // Create User instance
    $user = new User($db);
    
    // Get user by identifier
    if ($login_method === 'nida') {
        $userData = $user->getUserByNidaId($identifier);
    } else {
        // Get user by vote_id
        $query = "SELECT * FROM users WHERE vote_id = :vote_id LIMIT 1";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':vote_id', $identifier);
        $stmt->execute();
        $userData = $stmt->fetch();
    }
    
    // Check if user exists
    if (!$userData) {
        $_SESSION['login_errors'] = ['Invalid credentials. Please check your ID and password.'];
        $_SESSION['login_old_data'] = $_POST;
        redirect(SITE_URL . '/public/login.php');
    }
    
    // Check if account is locked
    if ($user->isAccountLocked($userData['user_id'])) {
        $locked_until = date('H:i', strtotime($userData['locked_until']));
        $_SESSION['login_errors'] = ["Account is locked due to multiple failed attempts. Please try again after {$locked_until}."];
        redirect(SITE_URL . '/public/login.php');
    }
    
    // Check if account is disabled
    if ($userData['account_status'] === 'disabled') {
        $_SESSION['login_errors'] = ['Your account has been disabled. Please contact support.'];
        redirect(SITE_URL . '/public/login.php');
    }
    
    // Verify password
    if (!$user->verifyPassword($password, $userData['password_hash'])) {
        // Increment failed attempts
        $user->incrementFailedAttempts($userData['user_id']);
        
        // Get updated failed attempts count
        $failedAttempts = ($userData['failed_login_attempts'] ?? 0) + 1;
        
        // Lock account if max attempts reached
        if ($failedAttempts >= MAX_LOGIN_ATTEMPTS) {
            $user->lockAccount($userData['user_id'], ACCOUNT_LOCKOUT_DURATION);
            $_SESSION['login_errors'] = ['Too many failed login attempts. Your account has been locked for ' . ACCOUNT_LOCKOUT_DURATION . ' minutes.'];
        } else {
            $remainingAttempts = MAX_LOGIN_ATTEMPTS - $failedAttempts;
            $_SESSION['login_errors'] = ["Invalid password. {$remainingAttempts} attempt(s) remaining before account lockout."];
        }
        
        $_SESSION['login_old_data'] = $_POST;
        redirect(SITE_URL . '/public/login.php');
    }
    
    // ✅ LOGIN SUCCESSFUL!
    
    // Reset failed login attempts
    $user->resetFailedAttempts($userData['user_id']);
    
    // Regenerate session ID for security
    session_regenerate_id(true);
    
    // Set session variables
    $_SESSION['user_id'] = $userData['user_id'];
    $_SESSION['email'] = $userData['email'];
    $_SESSION['full_name'] = $userData['full_name'];
    $_SESSION['role'] = $userData['role'];
    $_SESSION['account_status'] = $userData['account_status'];
    $_SESSION['logged_in'] = true;
    $_SESSION['login_time'] = time();
    $_SESSION['last_activity'] = time();
    
    // Set remember me cookie (optional - 30 days)
    if ($remember_me) {
        $token = bin2hex(random_bytes(32));
        setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/', '', false, true);
        
        // TODO: Store token in database for validation
        // $query = "INSERT INTO remember_tokens (user_id, token, expires_at) VALUES (?, ?, ?)";
    }
    
    // Log successful login (optional - implement audit logging)
    // $audit->log('LOGIN', 'user', $userData['user_id'], 'User logged in successfully');
    
    // Clear old login data
    unset($_SESSION['login_old_data']);
    unset($_SESSION['login_errors']);
    
    // Set success message
    setFlashMessage('success', 'Welcome back, ' . htmlspecialchars($userData['full_name']) . '!');
    
    // Redirect based on role
    if ($userData['role'] === 'admin') {
        redirect(SITE_URL . '/admin/index.php');
    } elseif ($userData['role'] === 'observer') {
        redirect(SITE_URL . '/observer/index.php');
    } else {
        // Default: voter dashboard
        redirect(SITE_URL . '/public/dashboard.php');
    }
    
} catch (Exception $e) {
    // Log error
    error_log('Login Error: ' . $e->getMessage());
    
    // Set error message
    $_SESSION['login_errors'] = ['An error occurred during login. Please try again later.'];
    $_SESSION['login_old_data'] = $_POST;
    redirect(SITE_URL . '/public/login.php');
}
?>
