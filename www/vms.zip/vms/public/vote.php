<?php
/**
 * Vote Management System
 * Vote/Candidate Selection Page
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/Vote.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect(SITE_URL . '/public/login.php');
}

// Get user info
$user_id = getCurrentUserId();
$full_name = $_SESSION['full_name'] ?? 'Voter';

// Get election ID from URL (for now, default to 1)
$election_id = $_GET['election_id'] ?? 1;

// Create database connection
$database = new Database();
$db = $database->connect();

// Create Vote instance
$vote = new Vote($db);

// Get active elections
$active_elections = $vote->getActiveElections();

// Get election details
$election = $vote->getElection($election_id);

// Check eligibility only if election exists
if ($election) {
    $eligibility = $vote->checkEligibility($user_id, $election_id);
    $candidates = $vote->getCandidates($election_id);
} else {
    $eligibility = ['eligible' => false, 'reason' => 'Election not found'];
    $candidates = [];
}

// Get flash message
$flash_message = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cast Your Vote | VMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background: #f5f5f5;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        
        .vote-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .vote-header {
            background: white;
            padding: 20px 30px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .vote-header h1 {
            margin: 0 0 10px 0;
            color: #333;
        }
        
        .vote-header .subtitle {
            color: #666;
            font-size: 16px;
        }
        
        .candidates-section {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .section-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
        }
        
        .instruction {
            color: #666;
            margin-bottom: 30px;
            font-size: 16px;
        }
        
        .candidates-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .candidate-card {
            background: #f9f9f9;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .candidate-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border-color: #4472C4;
        }
        
        .candidate-photo {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: #ddd;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
        }
        
        .candidate-name {
            font-size: 22px;
            font-weight: bold;
            margin: 10px 0;
            color: #333;
        }
        
        .candidate-party {
            color: #666;
            margin-bottom: 15px;
            font-size: 16px;
        }
        
        .vote-button {
            padding: 12px 32px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            color: white;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
        }
        
        .vote-button.party-a { background: #4472C4; }
        .vote-button.party-b { background: #70AD47; }
        .vote-button.party-c { background: #ED7D31; }
        
        .vote-button:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        
        .info-sidebar {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .info-sidebar h3 {
            margin: 0 0 15px 0;
            color: #333;
        }
        
        .info-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: bold;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }
        
        .info-value {
            color: #666;
        }
        
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        
        .back-button:hover {
            background: #5a6268;
        }
        
        .not-eligible {
            background: #fff3cd;
            border: 2px solid #ffc107;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .not-eligible h2 {
            color: #856404;
            margin: 0 0 10px 0;
        }
        
        .not-eligible p {
            color: #856404;
            margin: 0;
        }
    </style>
    
    <script>
        function confirmVote(candidateName, party) {
            return confirm(
                "⚠️ CONFIRM YOUR VOTE\n\n" +
                "You are about to vote for:\n\n" +
                "📝 Candidate: " + candidateName + "\n" +
                "🎯 Party: " + party + "\n\n" +
                "⚠️ WARNING: This action cannot be undone!\n" +
                "Once you vote, you cannot change your choice.\n\n" +
                "Are you sure you want to proceed?"
            );
        }
    </script>
</head>
<body>
    <div class="flag-stripe"></div>
    
    <div class="vote-container">
        
        <a href="dashboard.php" class="back-button">← Back to Dashboard</a>
        
        <!-- Flash Messages -->
        <?php if ($flash_message): ?>
            <div class="alert alert-<?php echo htmlspecialchars($flash_message['type']); ?>">
                <span><?php echo $flash_message['type'] === 'success' ? '✓' : '⚠️'; ?></span>
                <span><?php echo htmlspecialchars($flash_message['message']); ?></span>
            </div>
        <?php endif; ?>
        
        <!-- Header -->
        <div class="vote-header">
            <h1>🗳️ Vote – Candidate Selection</h1>
            <div class="subtitle">
                <strong><?php echo htmlspecialchars($election['name'] ?? 'Election'); ?></strong>
            </div>
        </div>
        
        <?php 
        // Check if election exists
        if (!$election): ?>
            <!-- No Election Found -->
            <div style="background: #e8f0fe; border: 2px solid #1a73e8; padding: 40px; border-radius: 12px; text-align: center;">
                <h2 style="color: #1a73e8; margin: 0 0 15px 0;">📅 No Election Available</h2>
                <p style="color: #666; font-size: 16px; margin: 0 0 15px 0;">
                    <?php if (count($active_elections) === 0): ?>
                        There are currently no active elections. Please check back later or contact your local electoral office for more information.
                    <?php else: ?>
                        The requested election was not found. Please check your dashboard for available elections.
                    <?php endif; ?>
                </p>
                <div style="margin-top: 20px;">
                    <a href="dashboard.php" style="display: inline-block; padding: 12px 24px; background: #1a73e8; color: white; text-decoration: none; border-radius: 6px; font-weight: 600;">
                        Return to Dashboard
                    </a>
                </div>
            </div>
        <?php elseif (!$eligibility['eligible']): ?>
            <!-- Not Eligible Message -->
            <div class="not-eligible">
                <h2>⚠️ Not Eligible to Vote</h2>
                <p><?php echo htmlspecialchars($eligibility['reason']); ?></p>
                <?php if (isset($eligibility['voted_at'])): ?>
                    <p>You voted on: <?php echo date('F j, Y \a\t g:i A', strtotime($eligibility['voted_at'])); ?></p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            
            <!-- Candidates Section -->
            <div class="candidates-section">
                <h2 class="section-title">Cast Your Vote</h2>
                <p class="instruction">
                    Please choose your preferred candidate for <strong><?php echo htmlspecialchars($election['election_type'] ?? 'this position'); ?></strong>.
                </p>
                
                <div class="candidates-grid">
                    <?php if ($candidates && count($candidates) > 0): ?>
                        <?php foreach ($candidates as $index => $candidate): ?>
                            <div class="candidate-card">
                                <div class="candidate-photo">
                                    <?php if (!empty($candidate['photo_url'])): ?>
                                        <img src="../<?php echo htmlspecialchars($candidate['photo_url']); ?>" 
                                             alt="<?php echo htmlspecialchars($candidate['full_name']); ?>"
                                             style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;"
                                             onerror="this.style.display='none'; this.parentElement.innerHTML='<?php echo strtoupper(substr($candidate['full_name'], 0, 1)); ?>';">
                                    <?php else: ?>
                                        <?php echo strtoupper(substr($candidate['full_name'], 0, 1)); ?>
                                    <?php endif; ?>
                                </div>
                                <h3 class="candidate-name"><?php echo htmlspecialchars($candidate['full_name']); ?></h3>
                                <p class="candidate-party"><?php echo htmlspecialchars($candidate['party_affiliation']); ?></p>
                                
                                <form method="POST" action="vote_process.php" style="margin: 0;" onsubmit="return confirmVote('<?php echo htmlspecialchars($candidate['full_name']); ?>', '<?php echo htmlspecialchars($candidate['party_affiliation']); ?>');">
                                    <input type="hidden" name="election_id" value="<?php echo htmlspecialchars($election_id); ?>">
                                    <input type="hidden" name="candidate_id" value="<?php echo htmlspecialchars($candidate['candidate_id']); ?>">
                                    <input type="hidden" name="candidate_name" value="<?php echo htmlspecialchars($candidate['full_name']); ?>">
                                    <input type="hidden" name="candidate_party" value="<?php echo htmlspecialchars($candidate['party_affiliation']); ?>">
                                    <button type="submit" class="vote-button party-<?php echo strtolower(str_replace(' ', '-', $candidate['party_affiliation'])); ?>">
                                        Vote
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No candidates available for this election.</p>
                    <?php endif; ?>
                </div>
                
                <p style="margin-top: 30px; color: #666; text-align: center;">
                    <strong>Note:</strong> You can only select one candidate. Your vote will be kept confidential and final.
                </p>
            </div>
            
            <!-- Election Info Sidebar -->
            <div class="info-sidebar">
                <h3>📅 Election Information</h3>
                
                <div class="info-item">
                    <span class="info-label">Election Date:</span>
                    <span class="info-value">
                        <?php 
                        echo date('M j, Y', strtotime($election['start_date'])) . ' - ' . 
                             date('M j, Y', strtotime($election['end_date'])); 
                        ?>
                    </span>
                </div>
                
                <div class="info-item">
                    <span class="info-label">Important:</span>
                    <ul style="margin: 5px 0; padding-left: 20px; color: #666;">
                        <li>Votes are final and cannot be changed</li>
                        <li>One voter, one vote</li>
                    </ul>
                </div>
            </div>
            
        <?php endif; ?>
        
    </div>
</body>
</html>
