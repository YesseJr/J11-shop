<?php
/**
 * Vote Management System
 * Receipt Verification Page
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/Vote.php';

// Get receipt code from URL or form
$receipt_code = sanitizeInput($_GET['code'] ?? $_POST['receipt_code'] ?? '');
$verification_result = null;

if (!empty($receipt_code)) {
    $database = new Database();
    $db = $database->connect();
    $vote = new Vote($db);
    
    $verification_result = $vote->verifyReceipt($receipt_code);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Vote Receipt | VMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        
        .verify-container {
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 500px;
            width: 100%;
            margin: 20px;
        }
        
        .verify-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .verify-icon {
            width: 80px;
            height: 80px;
            background: #667eea;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
        }
        
        .verify-title {
            font-size: 28px;
            font-weight: bold;
            margin: 0 0 10px 0;
            color: #333;
        }
        
        .verify-subtitle {
            color: #666;
            font-size: 15px;
        }
        
        .receipt-input {
            position: relative;
            margin-bottom: 25px;
        }
        
        .receipt-input input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            font-family: 'Courier New', monospace;
            letter-spacing: 1px;
            text-align: center;
            transition: all 0.3s;
        }
        
        .receipt-input input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .verify-btn {
            width: 100%;
            padding: 15px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .verify-btn:hover {
            background: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .result-card {
            margin-top: 30px;
            padding: 25px;
            border-radius: 12px;
            animation: slideUp 0.4s ease;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .result-success {
            background: linear-gradient(135deg, #4CAF50, #45a049);
            color: white;
        }
        
        .result-error {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            color: white;
        }
        
        .result-icon {
            font-size: 50px;
            text-align: center;
            margin-bottom: 15px;
        }
        
        .result-title {
            font-size: 22px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        
        .result-details {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        
        .detail-row:last-child {
            border-bottom: none;
        }
        
        .detail-label {
            font-weight: 600;
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="verify-container">
        <div class="verify-header">
            <div class="verify-icon">🔍</div>
            <h1 class="verify-title">Verify Your Vote</h1>
            <p class="verify-subtitle">Enter your receipt code to verify your vote was counted</p>
        </div>
        
        <form method="POST">
            <div class="receipt-input">
                <input 
                    type="text" 
                    name="receipt_code" 
                    placeholder="VMS-2026-XXXXXXXX"
                    value="<?php echo htmlspecialchars($receipt_code); ?>"
                    required
                    pattern="VMS-\d{4}-[A-Z0-9]{8}"
                    maxlength="21"
                >
            </div>
            
            <button type="submit" class="verify-btn">
                🔍 Verify Receipt
            </button>
        </form>
        
        <?php if ($verification_result !== null): ?>
            <?php if ($verification_result): ?>
                <!-- Success -->
                <div class="result-card result-success">
                    <div class="result-icon">✅</div>
                    <div class="result-title">Vote Successfully Verified!</div>
                    
                    <div class="result-details">
                        <div class="detail-row">
                            <span class="detail-label">Receipt Code:</span>
                            <span><?php echo htmlspecialchars($verification_result['receipt_code']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Election:</span>
                            <span><?php echo htmlspecialchars($verification_result['election_name']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Voted On:</span>
                            <span><?php echo date('M j, Y \a\t g:i A', strtotime($verification_result['timestamp'])); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Status:</span>
                            <span>
                                <?php if ($verification_result['vote_verified']): ?>
                                    ✅ Vote Counted
                                <?php else: ?>
                                    ⚠️ Processing
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    
                    <p style="text-align: center; margin: 15px 0 0 0; font-size: 14px; opacity: 0.9;">
                        Your vote has been securely recorded and will be counted in the final results.
                    </p>
                </div>
            <?php else: ?>
                <!-- Error -->
                <div class="result-card result-error">
                    <div class="result-icon">❌</div>
                    <div class="result-title">Receipt Not Found</div>
                    
                    <p style="text-align: center; margin: 0; font-size: 15px;">
                        The receipt code you entered is invalid or does not exist in our system.
                    </p>
                    
                    <p style="text-align: center; margin: 20px 0 0 0; font-size: 14px; opacity: 0.9;">
                        Please check the code and try again, or contact support if you believe this is an error.
                    </p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <a href="<?php echo isLoggedIn() ? 'dashboard.php' : '../index.php'; ?>" class="back-link">
            ← Back to <?php echo isLoggedIn() ? 'Dashboard' : 'Home'; ?>
        </a>
    </div>
</body>
</html>
