<?php
/**
 * Vote Management System
 * Voter Profile Page
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/User.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect(SITE_URL . '/public/login.php');
}

// Get user info
$user_id = getCurrentUserId();
$database = new Database();
$db = $database->connect();
$user_class = new User($db);
$user_data = $user_class->getUserById($user_id);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitizeInput($_POST['full_name'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $phone = sanitizeInput($_POST['phone'] ?? '');
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $errors = [];
    
    // Validate full name
    if (empty($full_name)) {
        $errors[] = 'Full name is required';
    }
    
    // Validate email
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    }
    
    // Validate phone
    if (empty($phone)) {
        $errors[] = 'Phone number is required';
    }
    
    // Check if email is taken by another user
    if ($email !== $user_data['email']) {
        if ($user_class->emailExists($email)) {
            $errors[] = 'Email is already taken';
        }
    }
    
    // If changing password
    if (!empty($new_password)) {
        if (empty($current_password)) {
            $errors[] = 'Current password is required to change password';
        } elseif (!$user_class->verifyPassword($current_password, $user_data['password_hash'])) {
            $errors[] = 'Current password is incorrect';
        } elseif (strlen($new_password) < 8) {
            $errors[] = 'New password must be at least 8 characters';
        } elseif ($new_password !== $confirm_password) {
            $errors[] = 'New passwords do not match';
        }
    }
    
    if (empty($errors)) {
        try {
            $update_data = [
                'full_name' => $full_name,
                'email' => $email,
                'phone' => $phone
            ];
            
            // Add password if changing
            if (!empty($new_password)) {
                $update_data['password_hash'] = $user_class->hashPassword($new_password);
            }
            
            if ($user_class->updateUser($user_id, $update_data)) {
                // Update session
                $_SESSION['full_name'] = $full_name;
                $_SESSION['email'] = $email;
                
                setFlashMessage('success', 'Profile updated successfully!');
                redirect(SITE_URL . '/public/profile.php');
            } else {
                $errors[] = 'Failed to update profile';
            }
        } catch (Exception $e) {
            $errors[] = 'Error updating profile: ' . $e->getMessage();
        }
    }
    
    $_SESSION['profile_errors'] = $errors;
}

$errors = $_SESSION['profile_errors'] ?? [];
unset($_SESSION['profile_errors']);

$flash_message = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile | VMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { background: #f5f5f5; margin: 0; font-family: Arial, sans-serif; }
        .container { max-width: 800px; margin: 40px auto; padding: 20px; }
        .profile-card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .profile-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .profile-header h1 { margin: 0; font-size: 28px; color: #333; }
        .back-btn { padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 6px; }
        .back-btn:hover { background: #5a6268; }
        .form-section { margin-bottom: 30px; padding-bottom: 30px; border-bottom: 1px solid #eee; }
        .form-section:last-child { border-bottom: none; }
        .section-title { font-size: 18px; font-weight: bold; color: #333; margin-bottom: 20px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-weight: 600; color: #333; margin-bottom: 8px; }
        .form-input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 15px; }
        .form-input:focus { outline: none; border-color: #4472C4; }
        .form-input:disabled { background: #f5f5f5; cursor: not-allowed; }
        .btn-primary { padding: 12px 24px; background: #4472C4; color: white; border: none; border-radius: 6px; font-size: 16px; font-weight: 600; cursor: pointer; }
        .btn-primary:hover { background: #2E5C8A; }
        .alert { padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .info-badge { display: inline-block; padding: 4px 12px; background: #e8f0fe; color: #1a73e8; border-radius: 12px; font-size: 13px; font-weight: 600; }
        @media (max-width: 768px) { .form-row { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="flag-stripe"></div>
    
    <div class="container">
        <div class="profile-header">
            <h1>👤 Edit Profile</h1>
            <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
        </div>
        
        <?php if ($flash_message): ?>
            <div class="alert alert-<?php echo htmlspecialchars($flash_message['type']); ?>">
                <?php echo htmlspecialchars($flash_message['message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $error): ?>
                    <p style="margin: 3px 0;"><?php echo htmlspecialchars($error); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <div class="profile-card">
            <form method="POST">
                <!-- Account Information -->
                <div class="form-section">
                    <div class="section-title">Account Information</div>
                    
                    <div class="form-group">
                        <label class="form-label">NIDA ID / VOTE ID</label>
                        <input type="text" class="form-input" 
                               value="<?php echo htmlspecialchars($user_data['nida_id'] ?? $user_data['vote_id'] ?? 'N/A'); ?>" 
                               disabled>
                        <small style="color: #666;">Cannot be changed</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Account Role</label>
                        <span class="info-badge"><?php echo ucfirst($user_data['role']); ?></span>
                    </div>
                </div>
                
                <!-- Personal Information -->
                <div class="form-section">
                    <div class="section-title">Personal Information</div>
                    
                    <div class="form-group">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="full_name" class="form-input" 
                               value="<?php echo htmlspecialchars($user_data['full_name']); ?>" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" class="form-input" 
                                   value="<?php echo htmlspecialchars($user_data['date_of_birth']); ?>" disabled>
                            <small style="color: #666;">Cannot be changed</small>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" name="phone" class="form-input" 
                                   value="<?php echo htmlspecialchars($user_data['phone']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-input" 
                               value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
                    </div>
                </div>
                
                <!-- Change Password (Optional) -->
                <div class="form-section">
                    <div class="section-title">Change Password (Optional)</div>
                    <p style="color: #666; margin-bottom: 20px; font-size: 14px;">Leave blank if you don't want to change your password</p>
                    
                    <div class="form-group">
                        <label class="form-label">Current Password</label>
                        <input type="password" name="current_password" class="form-input" 
                               placeholder="Enter current password">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">New Password</label>
                            <input type="password" name="new_password" class="form-input" 
                                   placeholder="At least 8 characters">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-input" 
                                   placeholder="Confirm new password">
                        </div>
                    </div>
                </div>
                
                <!-- Submit Button -->
                <button type="submit" class="btn-primary">💾 Save Changes</button>
            </form>
        </div>
    </div>
</body>
</html>
