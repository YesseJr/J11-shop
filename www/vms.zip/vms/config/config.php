<?php
/**
 * Vote Management System
 * General Configuration
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ========================================
// SITE CONFIGURATION
// ========================================

define('SITE_NAME', 'Vote Management System');
define('SITE_TAGLINE', 'Secure Online Voting for Local Government Elections');
define('SITE_URL', 'http://localhost/vms-fresh');  // Change for production
define('ADMIN_EMAIL', 'admin@votems.go.tz');

// ========================================
// PATH CONFIGURATION
// ========================================

define('ROOT_PATH', dirname(__DIR__));
define('CONFIG_PATH', ROOT_PATH . '/config');
define('CLASSES_PATH', ROOT_PATH . '/classes');
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');

// ========================================
// SECURITY CONFIGURATION
// ========================================

// Password requirements
define('MIN_PASSWORD_LENGTH', 8);
define('MAX_LOGIN_ATTEMPTS', 5);
define('ACCOUNT_LOCKOUT_DURATION', 30); // minutes

// Session configuration
define('SESSION_TIMEOUT', 1800); // 30 minutes in seconds
define('SESSION_NAME', 'VMS_SESSION');

// Encryption
define('ENCRYPTION_METHOD', 'AES-256-CBC');

// ========================================
// VALIDATION RULES
// ========================================

// NIDA ID format: YYYYMMDD-XXXXX-XXXXX-XX
define('NIDA_PATTERN', '/^\d{8}-\d{5}-\d{5}-\d{2}$/');

// Phone format: +255 followed by 9 digits
define('PHONE_PATTERN', '/^(\+255|255)[67]\d{8}$/');

// ========================================
// OTP CONFIGURATION
// ========================================

define('OTP_LENGTH', 6);
define('OTP_EXPIRY', 5); // minutes
define('OTP_MAX_ATTEMPTS', 3);

// ========================================
// PAGINATION
// ========================================

define('ITEMS_PER_PAGE', 20);

// ========================================
// FILE UPLOAD CONFIGURATION
// ========================================

define('MAX_UPLOAD_SIZE', 5242880); // 5MB in bytes
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/jpg']);
define('CANDIDATE_PHOTO_PATH', UPLOADS_PATH . '/candidates');

// ========================================
// TIMEZONE
// ========================================

date_default_timezone_set('Africa/Dar_es_Salaam');

// ========================================
// ERROR REPORTING (Change for production)
// ========================================

if ($_SERVER['SERVER_NAME'] === 'localhost') {
    // Development mode
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    define('DEBUG_MODE', true);
} else {
    // Production mode
    error_reporting(0);
    ini_set('display_errors', 0);
    define('DEBUG_MODE', false);
}

// ========================================
// HELPER FUNCTIONS
// ========================================

/**
 * Sanitize input data
 * @param string $data Input data
 * @return string Sanitized data
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Redirect to a page
 * @param string $url URL to redirect to
 */
function redirect($url) {
    header("Location: " . $url);
    exit();
}

/**
 * Check if user is logged in
 * @return bool True if logged in, false otherwise
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check if user is admin
 * @return bool True if admin, false otherwise
 */
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Get current user ID
 * @return int|null User ID or null if not logged in
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current user role
 * @return string|null User role or null if not logged in
 */
function getCurrentUserRole() {
    return $_SESSION['role'] ?? null;
}

/**
 * Set flash message
 * @param string $type success, error, warning, info
 * @param string $message Message to display
 */
function setFlashMessage($type, $message) {
    $_SESSION['flash_message'] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Get and clear flash message
 * @return array|null Flash message array or null
 */
function getFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $message;
    }
    return null;
}

/**
 * Generate CSRF token
 * @return string CSRF token
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 * @param string $token Token to verify
 * @return bool True if valid, false otherwise
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Hash IP address for privacy
 * @param string $ip IP address
 * @return string Hashed IP
 */
function hashIP($ip) {
    return hash('sha256', $ip . 'VMS_SALT_KEY'); // Change salt in production
}

/**
 * Format date for display
 * @param string $date Date string
 * @param string $format Date format
 * @return string Formatted date
 */
function formatDate($date, $format = 'Y-m-d H:i:s') {
    return date($format, strtotime($date));
}

/**
 * Check if age is 18+
 * @param string $dob Date of birth (Y-m-d format)
 * @return bool True if 18+, false otherwise
 */
function isEligibleAge($dob) {
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    $age = $today->diff($birthDate)->y;
    return $age >= 18;
}

// ========================================
// AUTOLOAD CLASSES
// ========================================

spl_autoload_register(function ($class_name) {
    $file = CLASSES_PATH . '/' . $class_name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// ========================================
// SESSION SECURITY
// ========================================

// Regenerate session ID periodically
if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} else if (time() - $_SESSION['created'] > 3600) {
    // Regenerate session ID every hour
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}

// Check session timeout
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
    session_unset();
    session_destroy();
    if (isLoggedIn()) {
        redirect(SITE_URL . '/public/login.php?timeout=1');
    }
}
$_SESSION['last_activity'] = time();

?>
