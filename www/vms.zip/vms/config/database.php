<?php
/**
 * Vote Management System
 * Database Configuration
 * 
 * Author: Waython Yesse Luoga
 * Reg No: 230229401347
 */

class Database {
    // Database credentials
    private $host = 'localhost';
    private $port = '3307';
    private $db_name = 'vms';
    private $username = 'root';          // Change this for production
    private $password = '';              // Change this for production
    private $charset = 'utf8mb4';
    
    // Connection object
    private $conn = null;
    
    /**
     * Establish database connection
     * @return PDO|null Database connection object
     */
    public function connect() {
        // Return existing connection if already established
        if ($this->conn !== null) {
            return $this->conn;
        }
        
        try {
            // Create DSN (Data Source Name)
            $dsn = "mysql:host={$this->host};port=3307;dbname={$this->db_name};charset=utf8mb4";
            
            // PDO options for better security and error handling
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,  // Throw exceptions on errors
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // Fetch associative arrays
                PDO::ATTR_EMULATE_PREPARES   => false,                   // Use real prepared statements
                PDO::ATTR_PERSISTENT         => false,                   // Don't use persistent connections
            ];
            
            // Create PDO instance
            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
            
            return $this->conn;
            
        } catch (PDOException $e) {
            // Log error (in production, log to file instead of displaying)
            error_log('Database Connection Error: ' . $e->getMessage());
            
            // Show user-friendly error (remove in production)
            die('Database connection failed. Please contact the administrator.');
        }
    }
    
    /**
     * Close database connection
     */
    public function disconnect() {
        $this->conn = null;
    }
    
    /**
     * Get connection status
     * @return bool True if connected, false otherwise
     */
    public function isConnected() {
        return $this->conn !== null;
    }
    
    /**
     * Test database connection
     * @return bool True if connection successful
     */
    public function testConnection() {
        try {
            $conn = $this->connect();
            return $conn !== null;
        } catch (Exception $e) {
            return false;
        }
    }
}

// Test connection (comment out after initial setup)
if (basename(__FILE__) == basename($_SERVER['SCRIPT_FILENAME'])) {
    echo "<h2>Testing Database Connection...</h2>";
    
    $database = new Database();
    
    if ($database->testConnection()) {
        echo "<p style='color: green; font-weight: bold;'>✓ Database connection successful!</p>";
        echo "<p>Database: vote_management_system</p>";
        echo "<p>Status: Connected</p>";
    } else {
        echo "<p style='color: red; font-weight: bold;'>✗ Database connection failed!</p>";
        echo "<p>Please check your database credentials in config/database.php</p>";
    }
}
?>
