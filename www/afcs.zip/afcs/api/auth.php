<?php
require_once __DIR__ . '/bootstrap.php';
session_start();

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$body   = json_body();

// ── POST /api/auth.php?action=login ──────────────────────────────────────────
if ($action === 'login') {
    $username = trim($body['username'] ?? '');
    $password = $body['password'] ?? '';

    if (!$username || !$password) json_err('Username and password required.');

    $db   = get_db();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND active = 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        json_err('Invalid username or password.', 401);
    }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user']    = [
        'id'       => $user['id'],
        'username' => $user['username'],
        'name'     => $user['first_name'] . ' ' . $user['last_name'],
        'role'     => $user['role'],
        'terminal' => $user['terminal'],
    ];
    unset($_SESSION['cashier_session_id']);

    $resume_session  = null;
    $blocked_session = null;

    // Admins don't run cashier sessions on a terminal — this check only
    // applies to cashiers/supervisors clocking in at a physical terminal.
    if ($user['role'] !== 'admin') {
        $open = $db->prepare("
            SELECT cs.id, cs.user_id, cs.started_at,
                   CONCAT(u.first_name,' ',u.last_name) AS cashier_name
            FROM cashier_sessions cs
            JOIN users u ON u.id = cs.user_id
            WHERE cs.terminal = ? AND cs.ended_at IS NULL
            LIMIT 1
        ");
        $open->execute([$user['terminal']]);
        $openSession = $open->fetch();

        if ($openSession) {
            if ((int)$openSession['user_id'] === (int)$user['id']) {
                // Same cashier logging back in — pick up exactly where they left off.
                $_SESSION['cashier_session_id'] = $openSession['id'];
                $resume_session = ['session_id' => $openSession['id'], 'started_at' => $openSession['started_at']];
            } else {
                // A different cashier's session is still open on this terminal —
                // they can log in, but can't start or end it. Only that cashier
                // or an admin can.
                $blocked_session = [
                    'cashier_name' => $openSession['cashier_name'],
                    'started_at'   => $openSession['started_at'],
                ];
            }
        }
    }

    json_ok(array_merge($_SESSION['user'], [
        'resume_session'  => $resume_session,
        'blocked_session' => $blocked_session,
    ]), 'Login successful');
}

// ── POST /api/auth.php?action=start_session ───────────────────────────────────
if ($action === 'start_session') {
    $user = require_auth();
    $db   = get_db();

    // Defense in depth — the frontend already disables "Start Session" when a
    // login response reports a blocked_session, but the backend must not trust
    // that: refuse here too if another cashier's session is still open on this
    // terminal.
    $open = $db->prepare("
        SELECT cs.id, cs.user_id, CONCAT(u.first_name,' ',u.last_name) AS cashier_name
        FROM cashier_sessions cs JOIN users u ON u.id = cs.user_id
        WHERE cs.terminal = ? AND cs.ended_at IS NULL LIMIT 1
    ");
    $open->execute([$user['terminal']]);
    $openSession = $open->fetch();

    if ($openSession && (int)$openSession['user_id'] !== (int)$user['id']) {
        json_err("Terminal has an open session started by {$openSession['cashier_name']}. Ask them to log back in, or contact an admin.", 409);
    }
    if ($openSession) {
        // Somehow already resumed (e.g. stale client state) — just reuse it.
        $_SESSION['cashier_session_id'] = $openSession['id'];
        json_ok(['session_id' => $openSession['id'], 'terminal' => $user['terminal']], 'Resumed existing session');
    }

    $stmt = $db->prepare("INSERT INTO cashier_sessions (user_id, terminal) VALUES (?, ?)");
    $stmt->execute([$user['id'], $user['terminal']]);
    $sid = $db->lastInsertId();

    $_SESSION['cashier_session_id'] = $sid;

    json_ok([
        'session_id' => $sid,
        'started_at' => date('Y-m-d H:i:s'),
        'terminal'   => $user['terminal'],
    ], 'Session started');
}

// ── POST /api/auth.php?action=end_session ─────────────────────────────────────
if ($action === 'end_session') {
    $user = require_auth();
    $sid  = $_SESSION['cashier_session_id'] ?? null;

    if ($sid) {
        $db = get_db();

        // Count how many sessions this cashier has had TODAY (including current)
        $countStmt = $db->prepare("
            SELECT COUNT(*) FROM cashier_sessions
            WHERE user_id = ?
              AND DATE(started_at) = CURDATE()
              AND id <= ?
        ");
        $countStmt->execute([$user['id'], $sid]);
        $sessionNum  = (int)$countStmt->fetchColumn();
        $sessionCode = 'SS' . str_pad($sessionNum, 2, '0', STR_PAD_LEFT);

        $db->prepare("
            UPDATE cashier_sessions
            SET ended_at = NOW(), session_code = ?, closed_by = ?
            WHERE id = ? AND ended_at IS NULL
        ")->execute([$sessionCode, $user['id'], $sid]);
    }

    unset($_SESSION['cashier_session_id']);

    json_ok([
        'ended_session_id' => $sid,
        'session_code'     => $sessionCode ?? null,
    ], 'Session ended');
}

// ── POST /api/auth.php?action=logout ─────────────────────────────────────────
if ($action === 'logout') {
    // Deliberately does NOT end the cashier_session. Logging out is just
    // stepping away from the terminal — the session (and its running totals)
    // stays open so the same cashier can log back in later and continue
    // exactly where they left off. Only end_session (self) or an admin
    // force-close actually closes it.
    session_destroy();
    json_ok(null, 'Logged out successfully');
}

// ── GET /api/auth.php?action=me ──────────────────────────────────────────────
if ($action === 'me') {
    if (empty($_SESSION['user_id'])) json_err('Not authenticated', 401);
    json_ok([
        'user'       => $_SESSION['user'],
        'session_id' => $_SESSION['cashier_session_id'] ?? null,
    ]);
}

// ── POST /api/auth.php?action=change_password ────────────────────────────────
if ($action === 'change_password') {
    $user    = require_auth();
    $current = $body['current_password'] ?? '';
    $new_p   = $body['new_password'] ?? '';
    $confirm = $body['confirm_password'] ?? '';

    if (!$current || !$new_p)   json_err('All fields required.');
    if ($new_p !== $confirm)    json_err('New passwords do not match.');
    if (strlen($new_p) < 4)    json_err('Password must be at least 4 characters.');

    $db   = get_db();
    $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = ?");
    $stmt->execute([$user['id']]);
    $row  = $stmt->fetch();

    if (!password_verify($current, $row['password_hash'])) json_err('Current password is incorrect.');

    $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?")
       ->execute([password_hash($new_p, PASSWORD_DEFAULT), $user['id']]);

    json_ok(null, 'Password changed successfully');
}

// ── GET /api/auth.php?action=admin_open_sessions ─────────────────────────────
// Admin-only. Every cashier session currently left open (logged out or not),
// across every terminal, with live running totals — this is how an admin
// finds the session a departed cashier left behind.
if ($action === 'admin_open_sessions') {
    require_admin();
    $db   = get_db();
    $stmt = $db->query("
        SELECT
            cs.id, cs.terminal, cs.started_at,
            cs.user_id, CONCAT(u.first_name,' ',u.last_name) AS cashier_name, u.username,
            (SELECT COUNT(*) FROM transactions t WHERE t.session_id=cs.id AND t.type='qr_sale')                 AS qr_qty,
            (SELECT COALESCE(SUM(amount),0) FROM transactions t WHERE t.session_id=cs.id AND t.type='qr_sale')  AS qr_total,
            (SELECT COUNT(*) FROM transactions t WHERE t.session_id=cs.id AND t.type='topup')                    AS topup_qty,
            (SELECT COALESCE(SUM(amount),0) FROM transactions t WHERE t.session_id=cs.id AND t.type='topup')    AS topup_total,
            (SELECT COUNT(*) FROM transactions t WHERE t.session_id=cs.id AND t.type='card_sale')                AS cards_issued
        FROM cashier_sessions cs
        JOIN users u ON u.id = cs.user_id
        WHERE cs.ended_at IS NULL
        ORDER BY cs.started_at ASC
    ");
    json_ok($stmt->fetchAll());
}

// ── POST /api/auth.php?action=admin_end_session ──────────────────────────────
// Admin-only override: force-close any cashier's open session (e.g. one left
// behind after they logged out without ending it, or an abandoned terminal).
// Marked in the audit trail as closed_by the admin, not the cashier.
if ($action === 'admin_end_session') {
    $admin = require_admin();
    $sid   = (int)($body['session_id'] ?? 0);
    if (!$sid) json_err('session_id required.');

    $db   = get_db();
    $stmt = $db->prepare("SELECT * FROM cashier_sessions WHERE id = ?");
    $stmt->execute([$sid]);
    $session = $stmt->fetch();

    if (!$session)               json_err('Session not found.', 404);
    if ($session['ended_at'])    json_err('Session is already closed.');

    $countStmt = $db->prepare("
        SELECT COUNT(*) FROM cashier_sessions
        WHERE user_id = ? AND DATE(started_at) = DATE(?) AND id <= ?
    ");
    $countStmt->execute([$session['user_id'], $session['started_at'], $sid]);
    $sessionCode = 'SS' . str_pad((int)$countStmt->fetchColumn(), 2, '0', STR_PAD_LEFT);

    $db->prepare("
        UPDATE cashier_sessions SET ended_at = NOW(), session_code = ?, closed_by = ?
        WHERE id = ?
    ")->execute([$sessionCode, $admin['id'], $sid]);

    // If the cashier who owned this session happens to be logged in right
    // now (rare, since logging out is how sessions get left open, but
    // possible if an admin closes it out from under them), clear their
    // active cashier_session_id so their client falls back to standby.
    if (($_SESSION['cashier_session_id'] ?? null) == $sid) {
        unset($_SESSION['cashier_session_id']);
    }

    json_ok(['session_id' => $sid, 'session_code' => $sessionCode], 'Session closed by admin');
}

json_err('Unknown action', 404);
