<?php
// ── Bootstrap ─────────────────────────────────────────────────────────────────
// Single include point for every endpoint file: wires up the DB connection,
// JSON/auth helpers, and dev CORS headers. Endpoints just do:
//   require_once __DIR__ . "/bootstrap.php";

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/response.php';
require_once __DIR__ . '/helpers/auth.php';

// ── CORS (dev) ────────────────────────────────────────────────────────────────
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
