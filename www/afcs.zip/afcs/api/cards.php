<?php
require_once __DIR__ . '/bootstrap.php';
session_start();

$body   = json_body();
$action = $_GET['action'] ?? $body['action'] ?? '';

// ── GET /api/cards.php?action=lookup&card_number=xxx ─────────────────────────
if ($action === 'lookup') {
    require_auth();
    $card_number = trim($_GET['card_number'] ?? '');
    if (!$card_number) json_err('Card number required.');

    $db   = get_db();
    $stmt = $db->prepare("
        SELECT c.*, CONCAT(u.first_name, ' ', u.last_name) AS registered_by_name
        FROM cards c
        LEFT JOIN users u ON u.id = c.registered_by
        WHERE c.card_number = ?
    ");
    $stmt->execute([$card_number]);
    $card = $stmt->fetch();

    if (!$card) {
        // Card not in system — return as unregistered 'new' card
        // This allows the registration screen to accept it
        json_ok([
            'id'           => null,
            'card_number'  => $card_number,
            'holder_name'  => null,
            'phone'        => null,
            'gender'       => null,
            'dob'          => null,
            'card_type'    => null,
            'balance'      => 0,
            'status'       => 'new',
            'penalty_flag' => 0,
            'registered_by_name' => null,
            'registered_at' => null,
            'recent_transactions' => [],
        ]);
    }

    // Recent transactions
    $txns = $db->prepare("
        SELECT t.*, cs.terminal FROM transactions t
        JOIN cashier_sessions cs ON cs.id = t.session_id
        WHERE t.card_id = ?
        ORDER BY t.created_at DESC LIMIT 10
    ");
    $txns->execute([$card['id']]);
    $card['recent_transactions'] = $txns->fetchAll();

    json_ok($card);
}

// ── GET /api/cards.php?action=next_blank ─────────────────────────────────────
// Pulls the oldest still-unregistered card from real inventory (status='new'),
// instead of the old approach of randomly tapping demo cards and hoping to land
// on one that wasn't already registered. Guarantees a card that is genuinely
// available — two cashiers can't be handed the same blank card because once
// one of them registers it, its status flips to 'active' and it drops out of
// this pool immediately.
if ($action === 'next_blank') {
    require_auth();
    $db   = get_db();
    $stmt = $db->query("SELECT card_number FROM cards WHERE status = 'new' ORDER BY id ASC LIMIT 1");
    $row  = $stmt->fetch();

    if (!$row) json_err('No unregistered cards left in stock. Ask an admin to add more to inventory.', 409);

    json_ok(['card_number' => $row['card_number']]);
}

// ── GET /api/cards.php?action=blank_stock ────────────────────────────────────
// Lets the registration screen (and admin dashboard) show a live "X blank
// cards remaining" count, so cashiers see the problem coming before they hit
// the reader and get a "no stock" error mid-transaction.
if ($action === 'blank_stock') {
    require_auth();
    $db  = get_db();
    $cnt = $db->query("SELECT COUNT(*) AS n FROM cards WHERE status = 'new'")->fetch();
    json_ok(['available' => (int)$cnt['n']]);
}

// ── POST /api/cards.php?action=admin_add_blank_cards ─────────────────────────
// Admin-only. Batch-generates sequential blank cards into inventory so
// cashiers never run dry. This is the top-level management control the
// cashier-facing "Scan New Card" flow depends on — cashiers can pull cards
// out of stock, but only an admin can put more in.
if ($action === 'admin_add_blank_cards') {
    require_admin();

    $start_number = trim($body['start_number'] ?? '');
    $quantity     = (int)($body['quantity'] ?? 0);

    if (!ctype_digit($start_number))   json_err('Start number must be numeric (e.g. 994160000026).');
    if ($quantity < 1 || $quantity > 500) json_err('Quantity must be between 1 and 500.');

    $db     = get_db();
    $width  = strlen($start_number);
    $start  = (int)$start_number;
    $stmt   = $db->prepare("INSERT IGNORE INTO cards (card_number, status) VALUES (?, 'new')");

    $added = 0; $skipped = 0;
    for ($i = 0; $i < $quantity; $i++) {
        $no = str_pad((string)($start + $i), $width, '0', STR_PAD_LEFT);
        $stmt->execute([$no]);
        if ($stmt->rowCount() > 0) $added++; else $skipped++;
    }

    json_ok(['added' => $added, 'skipped' => $skipped], "$added blank card(s) added to inventory" . ($skipped ? " ($skipped already existed and were skipped)" : ''));
}

// ── GET /api/cards.php?action=admin_inventory ─────────────────────────────────
// Admin-only overview: how many cards exist in each status/type, for the
// Card Inventory management screen.
if ($action === 'admin_inventory') {
    require_admin();
    $db = get_db();

    $byStatus = $db->query("SELECT status, COUNT(*) AS n FROM cards GROUP BY status")->fetchAll();
    $byType   = $db->query("SELECT card_type, COUNT(*) AS n FROM cards WHERE status != 'new' GROUP BY card_type")->fetchAll();
    $blanks   = $db->query("SELECT card_number, created_at FROM cards WHERE status = 'new' ORDER BY id ASC")->fetchAll();

    json_ok([
        'by_status' => $byStatus,
        'by_type'   => $byType,
        'blank_cards' => $blanks,
    ]);
}

// ── POST /api/cards.php?action=register ──────────────────────────────────────
if ($action === 'register') {
    $user       = require_auth();
    $session_id = get_active_session_id();

    $card_number = trim($body['card_number'] ?? '');
    $holder_name = strtoupper(trim($body['holder_name'] ?? ''));
    $phone       = trim($body['phone'] ?? '');
    $card_type   = $body['card_type'] ?? 'Adult';
    $gender      = $body['gender'] ?? 'M';
    $dob         = $body['dob'] ?? null;

    if (!$card_number) json_err('Card number required.');
    if (!$holder_name) json_err('Holder name required.');
    if (!$phone)       json_err('Phone number required.');
    if (!in_array($card_type, ['Adult', 'Staff'])) json_err('Invalid card type — only Adult and Staff cards are issued.');

    $db = get_db();

    // Check not already registered
    $exists = $db->prepare("SELECT id, status FROM cards WHERE card_number = ?");
    $exists->execute([$card_number]);
    $existing = $exists->fetch();
    if ($existing && $existing['status'] !== 'new') {
        json_err('Card is already registered.');
    }

    if ($existing) {
        // Update the blank card record
        $db->prepare("
            UPDATE cards SET
                holder_name   = ?, phone = ?, card_type = ?, gender = ?, dob = ?,
                status        = 'active',
                registered_by = ?, registered_at = CURRENT_TIMESTAMP,
                activated_at  = CURRENT_TIMESTAMP
            WHERE card_number = ?
        ")->execute([$holder_name, $phone, $card_type, $gender, $dob, $user['id'], $card_number]);
        $card_id = $existing['id'];
    } else {
        // Insert brand new
        $db->prepare("
            INSERT INTO cards (card_number, holder_name, phone, card_type, gender, dob,
                               status, registered_by, registered_at, activated_at)
            VALUES (?, ?, ?, ?, ?, ?, 'active', ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ")->execute([$card_number, $holder_name, $phone, $card_type, $gender, $dob, $user['id']]);
        $card_id = $db->lastInsertId();
    }

    // Log transaction
    $db->prepare("
        INSERT INTO transactions (session_id, type, card_id, amount, notes)
        VALUES (?, 'card_sale', ?, 0, ?)
    ")->execute([$session_id, $card_id, "Card registered: $card_type"]);

    json_ok(['card_id' => $card_id, 'card_number' => $card_number, 'holder_name' => $holder_name], 'Card registered and activated successfully');
}

// ── POST /api/cards.php?action=topup ─────────────────────────────────────────
if ($action === 'topup') {
    $user       = require_auth();
    $session_id = get_active_session_id();

    $card_number = trim($body['card_number'] ?? '');
    $amount      = (float)($body['amount'] ?? 0);

    if (!$card_number)  json_err('Card number required.');
    if ($amount <= 0)   json_err('Amount must be greater than 0.');
    if ($amount > 500000) json_err('Amount exceeds maximum topup limit (500,000 Tshs).');

    $db   = get_db();
    $stmt = $db->prepare("SELECT * FROM cards WHERE card_number = ?");
    $stmt->execute([$card_number]);
    $card = $stmt->fetch();

    if (!$card)                      json_err('Card not found.', 404);
    if ($card['status'] !== 'active') json_err("Card is {$card['status']} — topup not allowed.");
    if ($card['card_type'] === 'Staff') json_err('Staff cards cannot be topped up — staff have unlimited service access and do not carry a balance.');

    $new_balance = $card['balance'] + $amount;

    $db->prepare("UPDATE cards SET balance = ? WHERE id = ?")
       ->execute([$new_balance, $card['id']]);

    $db->prepare("
        INSERT INTO transactions (session_id, type, card_id, amount, notes)
        VALUES (?, 'topup', ?, ?, ?)
    ")->execute([$session_id, $card['id'], $amount, "Topup by {$user['name']}"]);

    json_ok([
        'card_number'  => $card_number,
        'holder_name'  => $card['holder_name'],
        'amount_added' => $amount,
        'new_balance'  => $new_balance,
        'old_balance'  => $card['balance'],
    ], 'Topup successful');
}

// ── POST /api/cards.php?action=activate ──────────────────────────────────────
if ($action === 'activate') {
    $user       = require_auth();
    $session_id = get_active_session_id();

    $card_number = trim($body['card_number'] ?? '');
    $reason      = trim($body['reason'] ?? 'Manual activation');

    if (!$card_number) json_err('Card number required.');

    $db   = get_db();
    $stmt = $db->prepare("SELECT * FROM cards WHERE card_number = ?");
    $stmt->execute([$card_number]);
    $card = $stmt->fetch();

    if (!$card)                        json_err('Card not found.', 404);
    if ($card['status'] === 'active')  json_err('Card is already active.');

    $db->prepare("UPDATE cards SET status = 'active', activated_at = CURRENT_TIMESTAMP WHERE id = ?")
       ->execute([$card['id']]);

    $db->prepare("
        INSERT INTO transactions (session_id, type, card_id, notes)
        VALUES (?, 'activate', ?, ?)
    ")->execute([$session_id, $card['id'], $reason]);

    json_ok(['card_number' => $card_number, 'holder_name' => $card['holder_name']], 'Card activated successfully');
}

// ── POST /api/cards.php?action=deactivate ────────────────────────────────────
if ($action === 'deactivate') {
    $user       = require_auth();
    $session_id = get_active_session_id();

    $card_number = trim($body['card_number'] ?? '');
    $reason      = trim($body['reason'] ?? 'Manual deactivation');

    if (!$card_number) json_err('Card number required.');

    $db   = get_db();
    $stmt = $db->prepare("SELECT * FROM cards WHERE card_number = ?");
    $stmt->execute([$card_number]);
    $card = $stmt->fetch();

    if (!$card)                          json_err('Card not found.', 404);
    if ($card['status'] === 'inactive')  json_err('Card is already inactive.');

    $db->prepare("UPDATE cards SET status = 'inactive', deactivated_at = CURRENT_TIMESTAMP WHERE id = ?")
       ->execute([$card['id']]);

    $db->prepare("
        INSERT INTO transactions (session_id, type, card_id, notes)
        VALUES (?, 'deactivate', ?, ?)
    ")->execute([$session_id, $card['id'], $reason]);

    json_ok(['card_number' => $card_number, 'holder_name' => $card['holder_name']], 'Card deactivated');
}

// ── POST /api/cards.php?action=balance_transfer ──────────────────────────────
if ($action === 'balance_transfer') {
    $user       = require_auth();
    $session_id = get_active_session_id();

    $from_number = trim($body['from_card'] ?? '');
    $to_number   = trim($body['to_card'] ?? '');
    $amount      = (float)($body['amount'] ?? 0);

    if (!$from_number || !$to_number) json_err('Both card numbers required.');
    if ($from_number === $to_number)  json_err('Source and destination cards cannot be the same.');
    if ($amount <= 0)                 json_err('Amount must be greater than 0.');

    $db = get_db();
    $stmt = $db->prepare("SELECT * FROM cards WHERE card_number = ?");
    $stmt->execute([$from_number]); $fromCard = $stmt->fetch();
    $stmt->execute([$to_number]);   $toCard   = $stmt->fetch();

    if (!$fromCard) json_err("Source card not found.");
    if (!$toCard)   json_err("Destination card not found.");
    if ($fromCard['status'] !== 'active') json_err("Source card is not active.");
    if ($toCard['status']   !== 'active') json_err("Destination card is not active.");
    if ($fromCard['balance'] < $amount)   json_err("Insufficient balance on source card.");

    $db->prepare("UPDATE cards SET balance = balance - ? WHERE id = ?")->execute([$amount, $fromCard['id']]);
    $db->prepare("UPDATE cards SET balance = balance + ? WHERE id = ?")->execute([$amount, $toCard['id']]);

    $db->prepare("INSERT INTO transactions (session_id, type, card_id, amount, notes) VALUES (?, 'balance_transfer', ?, ?, ?)")
       ->execute([$session_id, $fromCard['id'], -$amount, "Transfer to {$to_number}"]);
    $db->prepare("INSERT INTO transactions (session_id, type, card_id, amount, notes) VALUES (?, 'balance_transfer', ?, ?, ?)")
       ->execute([$session_id, $toCard['id'], $amount, "Transfer from {$from_number}"]);

    json_ok([
        'from_card'       => $from_number,
        'to_card'         => $to_number,
        'amount'          => $amount,
        'from_new_balance'=> $fromCard['balance'] - $amount,
        'to_new_balance'  => $toCard['balance'] + $amount,
    ], 'Balance transferred successfully');
}

// ── POST /api/cards.php?action=penalty ───────────────────────────────────────
if ($action === 'penalty') {
    $user       = require_auth();
    $session_id = get_active_session_id();

    $card_number = trim($body['card_number'] ?? '');
    $flag        = (int)($body['flag'] ?? 1); // 1=flag, 0=unflag

    if (!$card_number) json_err('Card number required.');

    $db = get_db();
    $stmt = $db->prepare("SELECT * FROM cards WHERE card_number = ?");
    $stmt->execute([$card_number]);
    $card = $stmt->fetch();

    if (!$card) json_err('Card not found.', 404);

    $db->prepare("UPDATE cards SET penalty_flag = ? WHERE id = ?")->execute([$flag, $card['id']]);

    $db->prepare("INSERT INTO transactions (session_id, type, card_id, notes) VALUES (?, 'penalty', ?, ?)")
       ->execute([$session_id, $card['id'], $flag ? 'Penalty flag set' : 'Penalty flag removed']);

    json_ok(null, $flag ? 'Penalty flag set on card' : 'Penalty flag removed');
}

json_err('Unknown action', 404);
