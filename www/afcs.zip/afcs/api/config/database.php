<?php
// ── MySQL Configuration ───────────────────────────────────────────────────────
// Change these to match your XAMPP MySQL setup
define('DB_HOST', 'localhost');
define('DB_PORT', '3307');
define('DB_NAME', 'afcs');
define('DB_USER', 'root');
define('DB_PASS', '');       // XAMPP default is empty password

function get_db() {
    static $pdo = null;
    if ($pdo) return $pdo;

    try {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed: ' . $e->getMessage() .
                         ' — Make sure MySQL is running and the "' . DB_NAME . '" database exists.',
            'data'    => null,
        ]);
        exit;
    }

    init_schema($pdo);
    return $pdo;
}

function init_schema(PDO $db) {

    $db->exec("
        CREATE TABLE IF NOT EXISTS users (
            id            INT             AUTO_INCREMENT PRIMARY KEY,
            username      VARCHAR(50)     UNIQUE NOT NULL,
            password_hash VARCHAR(255)    NOT NULL,
            first_name    VARCHAR(100)    NOT NULL,
            last_name     VARCHAR(100)    NOT NULL,
            role          ENUM('cashier','supervisor','admin') NOT NULL DEFAULT 'cashier',
            terminal      VARCHAR(100)    NOT NULL DEFAULT 'KIGAMBONI TERMINAL',
            active        TINYINT(1)      NOT NULL DEFAULT 1,
            created_at    DATETIME        DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    $db->exec("
        CREATE TABLE IF NOT EXISTS cards (
            id              INT             AUTO_INCREMENT PRIMARY KEY,
            card_number     VARCHAR(30)     UNIQUE NOT NULL,
            holder_name     VARCHAR(150),
            phone           VARCHAR(20),
            gender          CHAR(1),
            dob             DATE,
            card_type       ENUM('Adult','Staff') NOT NULL DEFAULT 'Adult',
            balance         DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
            status          ENUM('new','active','inactive')             NOT NULL DEFAULT 'new',
            penalty_flag    TINYINT(1)      NOT NULL DEFAULT 0,
            registered_by   INT,
            registered_at   DATETIME,
            activated_at    DATETIME,
            deactivated_at  DATETIME,
            created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (registered_by) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // ── Migration: collapse old card types (Regular/Student/Elderly) into Adult ──
    // Students now ride on printable QR tickets, not physical cards, so the only
    // card types left are Adult (general public) and Staff (service access).
    try {
        $col = $db->query("SHOW COLUMNS FROM cards LIKE 'card_type'")->fetch();
        if ($col && strpos($col['Type'], "'Regular'") !== false) {
            $db->exec("ALTER TABLE cards MODIFY card_type ENUM('Adult','Staff','Regular','Student','Elderly') NOT NULL DEFAULT 'Adult'");
            $db->exec("UPDATE cards SET card_type='Adult' WHERE card_type IN ('Regular','Student','Elderly')");
            $db->exec("ALTER TABLE cards MODIFY card_type ENUM('Adult','Staff') NOT NULL DEFAULT 'Adult'");
        }
    } catch (PDOException $e) { /* best-effort migration — ignore if already migrated */ }

    $db->exec("
        CREATE TABLE IF NOT EXISTS cashier_sessions (
            id           INT          AUTO_INCREMENT PRIMARY KEY,
            user_id      INT          NOT NULL,
            terminal     VARCHAR(100) NOT NULL DEFAULT 'KIGAMBONI TERMINAL',
            session_code VARCHAR(10)  DEFAULT NULL,
            started_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
            ended_at     DATETIME,
            closed_by    INT          DEFAULT NULL,
            FOREIGN KEY (user_id)   REFERENCES users(id),
            FOREIGN KEY (closed_by) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // ── Migration: audit trail for who closed a session ──────────────────────
    // A session can now be closed by the cashier who owns it OR by an admin
    // force-closing it on their behalf — this records which one happened.
    try {
        $col = $db->query("SHOW COLUMNS FROM cashier_sessions LIKE 'closed_by'")->fetch();
        if (!$col) {
            $db->exec("ALTER TABLE cashier_sessions ADD COLUMN closed_by INT DEFAULT NULL AFTER ended_at");
            $db->exec("ALTER TABLE cashier_sessions ADD FOREIGN KEY (closed_by) REFERENCES users(id) ON DELETE SET NULL");
        }
    } catch (PDOException $e) { /* best-effort migration — ignore if already migrated */ }

    $db->exec("
        CREATE TABLE IF NOT EXISTS transactions (
            id          INT           AUTO_INCREMENT PRIMARY KEY,
            session_id  INT           NOT NULL,
            type        VARCHAR(30)   NOT NULL,
            card_id     INT,
            amount      DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            quantity    INT           NOT NULL DEFAULT 1,
            route       VARCHAR(100),
            notes       TEXT,
            created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES cashier_sessions(id),
            FOREIGN KEY (card_id)    REFERENCES cards(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    $db->exec("
        CREATE TABLE IF NOT EXISTS qr_tickets (
            id           INT           AUTO_INCREMENT PRIMARY KEY,
            ticket_code  VARCHAR(60)   UNIQUE NOT NULL,
            session_id   INT           NOT NULL,
            route        VARCHAR(100)  NOT NULL,
            price        DECIMAL(12,2) NOT NULL,
            status       ENUM('valid','used','expired','cancelled') NOT NULL DEFAULT 'valid',
            qr_payload   TEXT,
            issued_at    DATETIME      DEFAULT CURRENT_TIMESTAMP,
            expires_at   DATETIME,
            used_at      DATETIME,
            FOREIGN KEY (session_id) REFERENCES cashier_sessions(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Seed default users only once
    $count = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($count == 0) {
        $hash      = password_hash('1234',      PASSWORD_DEFAULT);
        $hashAdmin = password_hash('admin123',  PASSWORD_DEFAULT);
        $stmt = $db->prepare("
            INSERT INTO users (username, password_hash, first_name, last_name, role, terminal)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute(['luogaw',    $hash,      'Wayton', 'Luoga',   'cashier', 'KIGAMBONI TERMINAL']);
        $stmt->execute(['mbangalae', $hash,      'Edward', 'Mbangala','cashier', 'KIGAMBONI TERMINAL']);
        $stmt->execute(['admin',     $hashAdmin, 'System', 'Admin',   'admin',   'HQ']);
    }

    // ── Seed registered demo cards ───────────────────────────────────────────
    $stmt = $db->prepare("
        INSERT IGNORE INTO cards (card_number, holder_name, phone, card_type, gender, balance, status, registered_at, activated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ");
    $stmt->execute(['994160222206', 'JAMES MWANGI',      '0712111001', 'Adult', 'M', 3000.00, 'active']);
    $stmt->execute(['994160232770', 'SABRINA A MEDARD',  '0754222002', 'Adult', 'F', 1500.00, 'active']);
    $stmt->execute(['994160199001', 'JOHN KAMAU',        '0765333003', 'Adult', 'M',  850.00, 'active']);
    $stmt->execute(['994160009988', 'ANN CHELSEA',       '0778444004', 'Adult', 'F',  200.00, 'inactive']);
    $stmt->execute(['994160187650', 'FATUMA OMAR',       '0756234101', 'Adult', 'F',  500.00, 'active']);
    $stmt->execute(['994160187651', 'IBRAHIM HASSAN',    '0712234102', 'Adult', 'M', 1200.00, 'active']);
    $stmt->execute(['994160187652', 'LUCIA MWAMBA',      '0765234103', 'Adult', 'F',  750.00, 'active']);
    $stmt->execute(['994160187653', 'PETER NJOROGE',     '0778234104', 'Staff', 'M', 5000.00, 'active']);
    $stmt->execute(['994160187654', 'AMINA SALEHE',      '0754234105', 'Adult', 'F',  300.00, 'active']);
    $stmt->execute(['994160187655', 'DAVID OCHIENG',     '0712234106', 'Adult', 'M',  950.00, 'active']);

    // ── Seed 25 blank unregistered cards for registration simulation ──────────
    $blank = $db->prepare("INSERT IGNORE INTO cards (card_number, status) VALUES (?, 'new')");
    $blankNos = [
        '994160000001','994160000002','994160000003','994160000004','994160000005',
        '994160000006','994160000007','994160000008','994160000009','994160000010',
        '994160000011','994160000012','994160000013','994160000014','994160000015',
        '994160000016','994160000017','994160000018','994160000019','994160000020',
        '994160000021','994160000022','994160000023','994160000024','994160000025',
    ];
    foreach ($blankNos as $no) { $blank->execute([$no]); }
}
