<?php
// ── Auth / session guards ─────────────────────────────────────────────────────
// Shared by every endpoint that requires a logged-in cashier or an active
// cashier_session (i.e. everything except login itself).

function require_auth() {
    // Guard against double session_start(): each caller file already starts the
    // session at the top, so calling it again here emits an E_NOTICE that gets
    // injected before the JSON body and corrupts the response.
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['user_id'])) json_err('Not authenticated', 401);
    return $_SESSION['user'] ?? [];
}

function get_active_session_id() {
    $sid = $_SESSION['cashier_session_id'] ?? 0;
    if (!$sid) json_err('No active cashier session.', 403);
    return (int)$sid;
}

function require_admin() {
    $user = require_auth();
    if (($user['role'] ?? '') !== 'admin') {
        json_err('Admin access required for this action.', 403);
    }
    return $user;
}
