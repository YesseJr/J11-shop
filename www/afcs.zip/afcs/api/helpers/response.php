<?php
// ── JSON response helpers ─────────────────────────────────────────────────────
// Every endpoint uses these instead of hand-rolling json_encode() calls, so the
// response envelope ({ success, message, data }) stays consistent everywhere.

// ── JSON helpers ──────────────────────────────────────────────────────────────
function json_ok($data = null, string $msg = 'OK') {
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => $msg, 'data' => $data]);
    exit;
}

function json_err(string $msg, int $code = 400) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $msg, 'data' => null]);
    exit;
}

function json_body() {
    return json_decode(file_get_contents('php://input'), true) ?? [];
}
