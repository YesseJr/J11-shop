<?php
require_once __DIR__ . '/bootstrap.php';
session_start();

$action = $_GET['action'] ?? '';
$body   = json_body();

// One flat student ticket, valid system-wide from Kigamboni — no per-route
// pricing or zones since every destination costs the same.
const STUDENT_FARE  = 200.00;
const TICKET_LABEL  = 'KIGAMBONI STUDENT TICKET';
const TICKET_FROM   = 'Kigamboni';
const TICKET_TO     = 'All Destinations';

// ── POST /api/qr.php?action=sell ─────────────────────────────────────────────
if ($action === 'sell') {
    $user       = require_auth();
    $session_id = get_active_session_id();

    $qty       = max(1, (int)($body['quantity']  ?? 1));
    $price     = STUDENT_FARE; // flat fare — client-submitted price is ignored
    $cash_in   = (float)($body['cash_received'] ?? 0);

    if ($qty > 20)   json_err('Maximum 20 tickets per transaction.');

    $route     = TICKET_LABEL;
    $total     = $price * $qty;
    $expires   = date('Y-m-d H:i:s', strtotime('+24 hours'));
    $db        = get_db();
    $tickets   = [];

    // Get terminal info from session
    $sessStmt = $db->prepare("SELECT cs.terminal, CONCAT(u.first_name,' ',u.last_name) AS cashier_name
                               FROM cashier_sessions cs JOIN users u ON u.id=cs.user_id WHERE cs.id=?");
    $sessStmt->execute([$session_id]);
    $sessInfo = $sessStmt->fetch();

    for ($i = 0; $i < $qty; $i++) {
        $code = 'TKT-' . strtoupper(bin2hex(random_bytes(6))) . '-' . date('ymdHis');

        // ── QR payload — everything the gate needs to verify ─────────────────
        $qr_payload = json_encode([
            'ticket_code' => $code,
            'route'       => $route,
            'from'        => TICKET_FROM,
            'to'          => TICKET_TO,
            'price'       => $price,
            'currency'    => 'TZS',
            'type'        => 'STUDENT',
            'issued_at'   => date('Y-m-d H:i:s'),
            'expires_at'  => $expires,
            'terminal'    => $sessInfo['terminal'] ?? 'KIGAMBONI TERMINAL',
            'cashier'     => $sessInfo['cashier_name'] ?? '',
            'issuer'       => 'DART AFCS v3',
        ]);

        $db->prepare("
            INSERT INTO qr_tickets (ticket_code, session_id, route, price, expires_at, qr_payload)
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute([$code, $session_id, $route, $price, $expires, $qr_payload]);

        $tickets[] = [
            'ticket_code' => $code,
            'qr_payload'  => $qr_payload,   // ← frontend uses this to generate the QR image
            'route'       => $route,
            'from'        => TICKET_FROM,
            'to'          => TICKET_TO,
            'price'       => $price,
            'expires_at'  => $expires,
            'ticket_id'   => $db->lastInsertId(),
        ];
    }

    $db->prepare("
        INSERT INTO transactions (session_id, type, amount, quantity, route, notes)
        VALUES (?, 'qr_sale', ?, ?, ?, ?)
    ")->execute([$session_id, $total, $qty, $route, "QR sale: {$qty} student ticket(s) — {$route}"]);

    json_ok([
        'tickets'       => $tickets,
        'total'         => $total,
        'cash_received' => $cash_in,
        'change'        => $cash_in > 0 ? max(0, $cash_in - $total) : null,
        'quantity'      => $qty,
        'route'         => $route,
    ], "{$qty} QR ticket(s) issued successfully");
}

// ── GET /api/qr.php?action=validate&code=TKT-xxx ─────────────────────────────
if ($action === 'validate') {
    $code = trim($_GET['code'] ?? '');
    if (!$code) json_err('Ticket code required.');

    $db   = get_db();
    $stmt = $db->prepare("SELECT * FROM qr_tickets WHERE ticket_code = ?");
    $stmt->execute([$code]);
    $ticket = $stmt->fetch();

    if (!$ticket)                          json_err('Ticket not found.', 404);
    if ($ticket['status'] === 'used')      json_err('Ticket already used.', 409);
    if ($ticket['status'] === 'cancelled') json_err('Ticket cancelled.', 409);
    if ($ticket['status'] === 'expired' || strtotime($ticket['expires_at']) < time()) {
        $db->prepare("UPDATE qr_tickets SET status='expired' WHERE id=?")->execute([$ticket['id']]);
        json_err('Ticket has expired.', 410);
    }

    $db->prepare("UPDATE qr_tickets SET status='used', used_at=NOW() WHERE id=?")
       ->execute([$ticket['id']]);

    $payload = json_decode($ticket['qr_payload'] ?? '{}', true);

    json_ok([
        'ticket_code' => $ticket['ticket_code'],
        'route'       => $ticket['route'],
        'from'        => $payload['from'] ?? '',
        'to'          => $payload['to']   ?? '',
        'issued_at'   => $ticket['issued_at'],
        'expires_at'  => $ticket['expires_at'],
        'used_at'     => date('Y-m-d H:i:s'),
    ], 'Ticket valid — gate open ✓');
}

// ── GET /api/qr.php?action=list ──────────────────────────────────────────────
if ($action === 'list') {
    require_auth();
    $sid  = (int)($_GET['session_id'] ?? get_active_session_id());
    $db   = get_db();
    $stmt = $db->prepare("SELECT * FROM qr_tickets WHERE session_id=? ORDER BY issued_at DESC");
    $stmt->execute([$sid]);
    json_ok($stmt->fetchAll());
}

json_err('Unknown action', 404);
