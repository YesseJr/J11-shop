// ── API client ───────────────────────────────────────────────────────────────
// Thin wrappers around fetch() for talking to the PHP backend in /api.
const API = 'api'; // relative path — works when served by php -S

async function api(file, action, body = null, method = 'POST') {
  try {
    const url = `${API}/${file}.php?action=${action}`;
    const opts = {
      method: body ? 'POST' : 'GET',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(url, opts);
    const json = await res.json();
    return json; // { success, message, data }
  } catch (e) {
    return { success: false, message: 'Network error — is the PHP server running?', data: null };
  }
}

async function apiGet(file, action, params = {}) {
  const qs = new URLSearchParams({ action, ...params }).toString();
  try {
    const res = await fetch(`${API}/${file}.php?${qs}`, { credentials: 'same-origin' });
    return await res.json();
  } catch {
    return { success: false, message: 'Network error', data: null };
  }
}

