// ── End Session Modal ─────────────────────────────────────────────────────────
function EndSessionModal({ onConfirm, onCancel }) {
  const [step,    setStep]    = useState('confirm'); // confirm | report | done
  const [report,  setReport]  = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchAndShow = async () => {
    setLoading(true);
    const res = await apiGet('reports', 'session');
    setLoading(false);
    if (!res.success) return;
    setReport(res.data);
    setStep('report');
  };

  const confirmEnd = async () => {
    setStep('done');
    // End session on backend (generates session code)
    const res = await api('auth', 'end_session', {});
    // Fetch the final report with session code + printed_at
    if (res.success && res.data.ended_session_id) {
      const r = await apiGet('reports', 'session_by_id', { session_id: res.data.ended_session_id });
      if (r.success) {
        setReport(r.data);
        // Auto-print after short delay
        setTimeout(() => window.print(), 600);
      }
    }
    await onConfirm();
  };

  const fmtMon = n => Number(n||0).toLocaleString();

  return (
    <>
      {/* Print-only styles */}
      <style>{`
        @media print {
          body > * { display: none !important; }
          #print-root { display: block !important; }
        }
        #print-root { display: none; }
      `}</style>
      {report && (
        <div id="print-root">
          <SessionReportPrint report={report}/>
        </div>
      )}

      <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.75)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:9999, backdropFilter:'blur(4px)' }}>
        <div className="slide-up" style={{ background:'var(--bg-panel)', border:'1px solid var(--border-bright)', borderRadius:24, padding:'36px 40px', width: step==='report' ? 560 : 440, maxHeight:'88vh', overflowY:'auto', boxShadow:'0 40px 80px rgba(0,0,0,.7)' }}>

          {/* ── Step 1: Confirm ── */}
          {step === 'confirm' && (
            <div style={{ textAlign:'center' }}>
              <div style={{ fontSize:56, marginBottom:16 }}>🔒</div>
              <div style={{ fontFamily:"'Syne',sans-serif", fontWeight:800, fontSize:22, color:'var(--text-primary)', marginBottom:10 }}>End Current Session?</div>
              <div style={{ fontSize:14, color:'var(--text-muted)', marginBottom:28, lineHeight:1.6 }}>
                The session report will be generated and printed automatically. The terminal will return to standby mode.
              </div>
              <div style={{ display:'flex', gap:12 }}>
                <button className="btn-ghost" onClick={onCancel} style={{ flex:1, padding:'14px' }}>Cancel</button>
                <button onClick={fetchAndShow} disabled={loading} style={{ flex:1, padding:'14px', background:'linear-gradient(135deg,#ff4757,#c0392b)', color:'#fff', border:'none', borderRadius:12, fontFamily:"'Syne',sans-serif", fontWeight:700, fontSize:14, cursor:'pointer' }}>
                  {loading ? <><Spinner/> Loading...</> : 'Preview Report →'}
                </button>
              </div>
            </div>
          )}

          {/* ── Step 2: Report Preview ── */}
          {step === 'report' && report && (
            <div>
              <div style={{ textAlign:'center', marginBottom:20 }}>
                <div style={{ fontFamily:"'Syne',sans-serif", fontWeight:800, fontSize:20, color:'var(--text-primary)', marginBottom:4 }}>Session Report Preview</div>
                <div style={{ fontSize:12, color:'var(--text-muted)' }}>Review before printing and ending session</div>
              </div>

              {/* Compact stats */}
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:16 }}>
                {[
                  { label:'QR Tickets',  value: report.qr_sales.count,   sub:`Tshs ${fmtMon(report.qr_sales.total)}`,  icon:'🎫', color:'#4a9eff' },
                  { label:'Topups',      value: report.topups.count,      sub:`Tshs ${fmtMon(report.topups.total)}`,    icon:'💳', color:'#ffb830' },
                  { label:'Transactions',value: report.total_txns,        sub:'total operations',                        icon:'📊', color:'#a78bfa' },
                  { label:'Grand Total', value:`Tshs ${fmtMon(report.grand_total)}`, sub:'session revenue',             icon:'💰', color:'#00d4b4' },
                ].map(c => (
                  <div key={c.label} style={{ background:'var(--bg-card)', border:`1px solid var(--border)`, borderRadius:14, padding:'14px', borderLeft:`3px solid ${c.color}` }}>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                      <span style={{ fontSize:10, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:1 }}>{c.label}</span>
                      <span>{c.icon}</span>
                    </div>
                    <div style={{ fontFamily:"'DM Mono',monospace", fontSize:20, color:c.color, fontWeight:500 }}>{c.value}</div>
                    <div style={{ fontSize:10, color:'var(--text-dim)', marginTop:3 }}>{c.sub}</div>
                  </div>
                ))}
              </div>

              {/* Cashier info */}
              <div style={{ background:'var(--bg-card)', border:'1px solid var(--border)', borderRadius:12, padding:'12px 16px', marginBottom:16, fontSize:12 }}>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'6px 16px' }}>
                  {[['Cashier', report.session.cashier_name], ['Terminal', report.session.terminal],
                    ['Login', new Date(report.session.started_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})],
                    ['Card Reg.', `${report.card_sales.count} card(s)`]
                  ].map(([k,v]) => (
                    <div key={k} style={{ display:'flex', gap:6 }}>
                      <span style={{ color:'var(--text-dim)' }}>{k}:</span>
                      <span style={{ color:'var(--text-primary)', fontWeight:500 }}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div style={{ background:'rgba(255,184,48,.08)', border:'1px solid rgba(255,184,48,.3)', borderRadius:10, padding:'10px 14px', marginBottom:16, fontSize:12, color:'var(--accent-amber)' }}>
                🖨️ The report will print automatically when you confirm. A session code (SS01, SS02...) will be assigned.
              </div>

              <div style={{ display:'flex', gap:10 }}>
                <button className="btn-ghost" onClick={onCancel} style={{ flex:1, padding:'12px', fontSize:13 }}>← Keep Working</button>
                <button onClick={confirmEnd} style={{ flex:1.5, padding:'12px', background:'linear-gradient(135deg,#ff4757,#c0392b)', color:'#fff', border:'none', borderRadius:12, fontFamily:"'Syne',sans-serif", fontWeight:700, fontSize:13, cursor:'pointer' }}>
                  ✓ Confirm &amp; Print Report
                </button>
              </div>
            </div>
          )}

          {/* ── Step 3: Done ── */}
          {step === 'done' && (
            <div style={{ textAlign:'center', padding:'20px 0' }}>
              <div style={{ fontSize:56, marginBottom:16 }}>✅</div>
              <div style={{ fontFamily:"'Syne',sans-serif", fontWeight:800, fontSize:22, color:'var(--success)', marginBottom:8 }}>Session Closed</div>
              <div style={{ fontSize:14, color:'var(--text-muted)' }}>Report sent to printer. Returning to standby...</div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

