// ── Login ─────────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [u,setU]=useState(''); const [p,setP]=useState('');
  const [sp,setSp]=useState(false); const [loading,setLoading]=useState(false); const [err,setErr]=useState('');

  const login = async () => {
    if (!u||!p) { setErr('Please enter credentials.'); return; }
    setLoading(true); setErr('');
    const res = await api('auth','login',{ username:u, password:p });
    if (res.success) onLogin(res.data);
    else { setErr(res.message); setLoading(false); }
  };

  return (
    <div style={{ width:'100vw',height:'100vh',background:'var(--bg-deep)',display:'flex',alignItems:'center',justifyContent:'center',position:'relative',overflow:'hidden' }}>
      <div style={{ position:'absolute',inset:0,backgroundImage:'linear-gradient(var(--border) 1px,transparent 1px),linear-gradient(90deg,var(--border) 1px,transparent 1px)',backgroundSize:'60px 60px',opacity:.4 }}/>
      <div style={{ position:'absolute',top:'20%',left:'15%',width:300,height:300,borderRadius:'50%',background:'radial-gradient(circle,rgba(0,212,180,.08),transparent 70%)' }}/>
      <div className="slide-up" style={{ background:'var(--bg-panel)',border:'1px solid var(--border-bright)',borderRadius:24,padding:'48px 44px',width:420,boxShadow:'0 40px 80px rgba(0,0,0,.6)' }}>
        <div style={{ textAlign:'center',marginBottom:36 }}>
          <div style={{ display:'inline-flex',alignItems:'center',gap:12,marginBottom:12 }}>
            <div style={{ width:48,height:48,borderRadius:14,background:'linear-gradient(135deg,#00d4b4,#007a6e)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:24 }}>🚇</div>
            <div>
              <div style={{ fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:28,color:'var(--accent-teal)',letterSpacing:2 }}>J11</div>
              <div style={{ fontSize:9,color:'var(--text-muted)',letterSpacing:3,textTransform:'uppercase' }}>J11 Rapid Transit</div>
            </div>
          </div>
          <div style={{ fontSize:13,color:'var(--text-muted)' }}>Automated Fare Collection System</div>
          <div style={{ width:40,height:2,background:'linear-gradient(90deg,transparent,var(--accent-teal),transparent)',margin:'14px auto 0' }}/>
        </div>
        <div style={{ display:'flex',flexDirection:'column',gap:16 }}>
          <div>
            <label style={{ display:'block',fontSize:11,fontWeight:600,color:'var(--text-muted)',marginBottom:8,letterSpacing:1,textTransform:'uppercase' }}>Username</label>
            <input className="input-field" value={u} onChange={e=>setU(e.target.value)} placeholder="e.g. luogaw" onKeyDown={e=>e.key==='Enter'&&login()}/>
          </div>
          <div>
            <label style={{ display:'block',fontSize:11,fontWeight:600,color:'var(--text-muted)',marginBottom:8,letterSpacing:1,textTransform:'uppercase' }}>Password</label>
            <div style={{ position:'relative' }}>
              <input className="input-field" type={sp?'text':'password'} value={p} onChange={e=>setP(e.target.value)} placeholder="••••••••" style={{ paddingRight:44 }} onKeyDown={e=>e.key==='Enter'&&login()}/>
              <button onClick={()=>setSp(!sp)} style={{ position:'absolute',right:14,top:'50%',transform:'translateY(-50%)',background:'none',border:'none',color:'var(--text-dim)',cursor:'pointer',fontSize:14 }}>{sp?'🙈':'👁'}</button>
            </div>
          </div>
          {err&&<div style={{ background:'rgba(255,71,87,.1)',border:'1px solid rgba(255,71,87,.3)',borderRadius:8,padding:'10px 14px',fontSize:13,color:'var(--accent-red)' }}>⚠️ {err}</div>}
          <button className="btn-primary" onClick={login} disabled={loading} style={{ padding:'15px',marginTop:8,fontSize:14,letterSpacing:1 }}>
            {loading?<><Spinner/> AUTHENTICATING...</>:'LOGIN →'}
          </button>
        </div>
        <div style={{ marginTop:20,textAlign:'center',fontSize:11,color:'var(--text-dim)' }}>
          Default: <span style={{ color:'var(--accent-teal)',fontFamily:"'DM Mono',monospace" }}>luogaw</span> / <span style={{ color:'var(--accent-teal)',fontFamily:"'DM Mono',monospace" }}>1234</span>
        </div>
      </div>
    </div>
  );
}

