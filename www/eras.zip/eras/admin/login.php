<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include('./db_connect.php');
?>
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Login | Event Registration and Attendance System</title>
 	

<?php include('./header.php'); ?>
<?php 
if(isset($_SESSION['login_id']))
header("location:index.php?page=home");

?>

</head>
<style>
	body{
		width: 100%;
	    height: calc(100%);
	    position: fixed;
	    top:0;
	    left: 0;
	    background: radial-gradient(circle at 20% 20%, #3730A3, #1E1B4B 60%) !important;
	    font-family: 'Inter', sans-serif;
	}
	main#main{
		width:100%;
		height: calc(100%);
		display: flex;
	}
	#login-center .card{
		border: none;
		border-radius: 20px;
		box-shadow: 0 20px 50px rgba(0,0,0,0.35);
		overflow: hidden;
	}
	#login-center .card-body{
		padding: 2.25rem 2rem;
	}
	.login-brand-icon{
		width: 56px;
		height: 56px;
		border-radius: 14px;
		background: linear-gradient(135deg,#4F46E5,#4338CA);
		display: flex;
		align-items: center;
		justify-content: center;
		margin: 0 auto 1rem;
		box-shadow: 0 8px 20px rgba(67,56,202,0.4);
	}
	.login-brand-icon i{ color:#fff; font-size: 1.6rem; }
	#login-form .btn-primary{
		background: #4F46E5;
		border-color: #4F46E5;
		border-radius: 999px;
		font-weight: 600;
		padding: .55rem 0;
	}
	#login-form .btn-primary:hover{ background:#4338CA; border-color:#4338CA; }
	#login-form .form-control{ border-radius: 10px; }

</style>

<body class="bg-dark">


  <main id="main" >
  	
  		<div class="align-self-center w-100">
		<div class="login-brand-icon"><i class="fas fa-calendar-check"></i></div>
		<h4 class="text-white text-center mb-4"><b>Event Registration and Attendance System</b><br><small class="font-weight-normal" style="opacity:.75">Admin Portal</small></h4>
  		<div id="login-center" class="row justify-content-center">
  			<div class="card col-md-4">
  				<div class="card-body">
  					<form id="login-form" >
  						<div class="form-group">
  							<label for="email" class="control-label text-dark">Email</label>
  							<input type="text" id="email" name="email" class="form-control form-control-sm">
  						</div>
  						<div class="form-group">
  							<label for="password" class="control-label text-dark">Password</label>
  							<input type="password" id="password" name="password" class="form-control form-control-sm">
  						</div>
  						<center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Login</button></center>
  					</form>
  				</div>
  			</div>
  		</div>
  		</div>
  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>


</body>
<script>
	$('#login-form').submit(function(e){
		e.preventDefault()
		$('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
		if($(this).find('.alert-danger').length > 0 )
			$(this).find('.alert-danger').remove();
		$.ajax({
			url:'ajax.php?action=login',
			method:'POST',
			data:$(this).serialize(),
			error:err=>{
				console.log(err)
		$('#login-form button[type="button"]').removeAttr('disabled').html('Login');

			},
			success:function(resp){
				if(resp == 1){
					location.href ='index.php?page=home';
				}else{
					$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				}
			}
		})
	})
	$('.number').on('input keyup keypress',function(){
        var val = $(this).val()
        val = val.replace(/[^0-9 \,]/, '');
        val = val.toLocaleString('en-US')
        $(this).val(val)
    })
</script>	
</html>