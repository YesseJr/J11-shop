<?php include('db_connect.php') ?>
<!-- Info boxes -->
<?php if($_SESSION['login_type'] == 1): ?>
        <div class="d-flex flex-wrap justify-content-between align-items-end mb-3">
          <div>
            <h2 class="mb-1">Welcome back, <?php echo explode(' ',trim($_SESSION['login_firstname']))[0] ?> 👋</h2>
            <p class="text-muted mb-0">Here's what's happening across your events today.</p>
          </div>
          <div class="d-flex" style="gap:.5rem;">
            <a href="./index.php?page=new_event" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> New Event</a>
            <a href="./index.php?page=new_user" class="btn btn-default btn-sm border"><i class="fa fa-user-plus"></i> New User</a>
          </div>
        </div>
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-users"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Total Registrars</span>
                <span class="info-box-number">
                  <?php echo $conn->query("SELECT * FROM users where type = 2")->num_rows; ?>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-success elevation-1"><i class="fas fa-user-graduate"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Total Students</span>
                <span class="info-box-number">
                  <?php echo $conn->query("SELECT * FROM users where type = 3")->num_rows; ?>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
           <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-primary elevation-1"><i class="fas fa-th-list"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Total Events</span>
                <span class="info-box-number">
                  <?php echo $conn->query("SELECT * FROM events")->num_rows; ?>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <div class="col-12 col-sm-6 col-md-3">
            <a href="./index.php?page=analytics" class="info-box">
              <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-chart-bar"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Analytics</span>
                <span class="info-box-number">View reports</span>
              </div>
              <!-- /.info-box-content -->
            </a>
            <!-- /.info-box -->
          </div>
          
      </div>

      <div class="row">
        <div class="col-md-7">
          <div class="card card-outline card-primary">
            <div class="card-header">
              <h3 class="card-title"><i class="fa fa-calendar-alt mr-1"></i> Upcoming & Active Events</h3>
              <div class="card-tools">
                <a href="./index.php?page=event_list" class="btn btn-sm btn-default border">View all</a>
              </div>
            </div>
            <div class="card-body p-0">
              <table class="table table-hover mb-0">
                <thead><tr><th>Event</th><th>Date</th><th>Status</th></tr></thead>
                <tbody>
                <?php
                  $upcoming = $conn->query("SELECT * FROM events where status != 2 order by event_datetime asc limit 6");
                  if($upcoming->num_rows == 0){
                    echo '<tr><td colspan="3" class="text-center text-muted py-4">No upcoming events.</td></tr>';
                  }
                  while($ev = $upcoming->fetch_assoc()):
                ?>
                  <tr>
                    <td class="pl-4"><b><?php echo ucwords($ev['event']) ?></b></td>
                    <td><?php echo date('M d, Y h:i A', strtotime($ev['event_datetime'])) ?></td>
                    <td class="pr-4">
                      <?php if($ev['status'] == 1): ?>
                        <span class="badge badge-success">Open</span>
                      <?php elseif($ev['status'] == 0): ?>
                        <span class="badge badge-warning">Pending</span>
                      <?php else: ?>
                        <span class="badge badge-secondary">Closed</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="col-md-5">
          <div class="card card-outline card-success">
            <div class="card-header">
              <h3 class="card-title"><i class="fa fa-user-check mr-1"></i> Recent Check-Ins</h3>
            </div>
            <div class="card-body p-0" id="dashboard-activity">
              <div class="text-center text-muted py-4"><i class="fa fa-spinner fa-spin"></i> Loading...</div>
            </div>
          </div>
        </div>
      </div>

      <script>
        $.ajax({
          url: 'ajax.php?action=get_recent_activity',
          method: 'GET',
          dataType: 'json',
          success: function(data){
            var box = $('#dashboard-activity');
            if(!data.recent || data.recent.length == 0){
              box.html('<div class="text-center text-muted py-4">No check-ins yet.</div>')
              return;
            }
            var html = '<ul class="list-group list-group-flush">'
            data.recent.forEach(function(r){
              html += '<li class="list-group-item d-flex justify-content-between align-items-center">'+
                '<span><i class="fa fa-check-circle text-success mr-2"></i>'+r.name+' <span class="text-muted">— '+r.event+'</span></span>'+
                '<small class="text-muted">'+r.checked_in_at+'</small></li>'
            })
            html += '</ul>'
            box.html(html)
          },
          error: function(){
            $('#dashboard-activity').html('<div class="text-center text-muted py-4">Could not load activity.</div>')
          }
        })
      </script>

<?php else: ?>
	 <div class="col-12">
          <div class="card">
          	<div class="card-body">
          		Welcome <?php echo $_SESSION['login_name'] ?>!
          	</div>
          </div>
      </div>
          
<?php endif; ?>
