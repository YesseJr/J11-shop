<?php 

$conn= new mysqli('localhost:3307','root','','eras_db')or die("Could not connect to mysql".mysqli_error($conn));
// Without this, mysqli defaults to its own charset (often not utf8mb4) even
// though the tables are utf8mb4. That mismatch silently corrupts any
// non-ASCII text (accented characters, Swahili text, curly quotes pasted
// from Word, emoji, etc.) into invalid byte sequences. That in turn makes
// json_encode() fail outright for any endpoint touching that data (e.g.
// Analytics), with no visible PHP error -- the request just comes back
// empty. Setting the charset explicitly keeps what's stored consistent
// with what's actually in the columns.
$conn->set_charset('utf8mb4');

// Events are created as "Pending" and an admin can manually flip them to
// "Open". But if nobody remembers to do that right when the event starts,
// registrars and students stay locked out even though the scheduled time
// has already arrived. This runs on every page load and auto-promotes any
// Pending event whose scheduled date/time has passed to Open, so the app
// self-corrects without needing a manual toggle or a cron job. It never
// touches events an admin has explicitly Closed (status=2).
// NOTE: we use PHP's clock (date()) rather than MySQL's NOW(). Laragon's
// bundled MySQL commonly defaults its time zone to UTC while PHP/Windows
// is set to the local time zone -- comparing against NOW() in that case
// silently stays "not yet arrived" for however many hours the two clocks
// are apart. PHP's clock matches whatever time zone the event_datetime
// was originally entered in (the browser's local wall-clock time), so
// comparing against it is consistent regardless of MySQL's own setting.
$conn->query("UPDATE events SET status = 1 WHERE status = 0 AND event_datetime <= '".date('Y-m-d H:i:s')."'");
