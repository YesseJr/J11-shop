<!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-primary navbar-dark ">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <?php if(isset($_SESSION['login_id'])): ?>
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="" role="button"><i class="fas fa-bars"></i></a>
      </li>
    <?php endif; ?>
      <li>
        <a class="nav-link text-white"  href="./" role="button"> <large><b>Event Registration and Attendance System</b></large></a>
      </li>
    </ul>

    <ul class="navbar-nav ml-auto">
      <?php if(isset($_SESSION['login_id'])): ?>
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge" id="notif_badge" style="display:none">0</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" id="notif_list">
          <span class="dropdown-item dropdown-header">Recent Check-Ins</span>
          <div class="dropdown-divider"></div>
          <span class="dropdown-item text-muted text-center" id="notif_empty">No check-ins yet</span>
        </div>
      </li>
      <?php endif; ?>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->
<?php if(isset($_SESSION['login_id'])): ?>
<script>
	function refresh_notifications(){
		$.ajax({
			url: 'ajax.php?action=get_recent_activity',
			method: 'GET',
			dataType: 'json',
			success: function(data){
				var badge = $('#notif_badge');
				if(data.today_count > 0){
					badge.text(data.today_count).show()
				}else{
					badge.hide()
				}
				var list = $('#notif_list');
				list.find('.notif-row').remove();
				if(data.recent.length == 0){
					$('#notif_empty').show()
				}else{
					$('#notif_empty').hide()
					data.recent.forEach(function(r){
						list.append('<a href="javascript:void(0)" class="dropdown-item notif-row"><i class="fas fa-user-check mr-2 text-success"></i> '+r.name+' checked in to <b>'+r.event+'</b><br><span class="text-muted text-sm">'+r.checked_in_at+'</span></a><div class="dropdown-divider notif-row"></div>')
					})
				}
			}
		})
	}
	$(document).ready(function(){
		refresh_notifications()
		setInterval(refresh_notifications, 15000)
	})
</script>
<?php endif; ?>
