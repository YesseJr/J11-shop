<?php
session_start();
ini_set('display_errors', 1);
Class Action {
	private $db;

	public function __construct() {
		ob_start();
   	include 'db_connect.php';
    
    $this->db = $conn;
	}
	function __destruct() {
	    $this->db->close();
	    ob_end_flush();
	}

	// Generates a short, unique, human-readable code used to verify an
	// attendee's identity at check-in (prevents marking someone else present).
	private function gen_unique_code(){
		$chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I to avoid confusion
		do {
			$code = '';
			for($i=0;$i<8;$i++){
				$code .= $chars[random_int(0, strlen($chars)-1)];
			}
			$exists = $this->db->query("SELECT id FROM attendees where unique_code = '".$this->db->real_escape_string($code)."'")->num_rows;
		} while($exists > 0);
		return $code;
	}

	// Verifies a password against a stored hash. Supports the modern
	// bcrypt hashes (password_hash) as well as the legacy md5 hashes
	// from older installs -- and transparently upgrades a legacy hash
	// to bcrypt the moment someone logs in successfully with it.
	private function verify_and_upgrade_password($plain, $stored, $user_id){
		if(password_verify($plain, $stored)){
			return true;
		}
		if($stored === md5($plain)){
			$new_hash = password_hash($plain, PASSWORD_BCRYPT);
			$this->db->query("UPDATE users set password = '".$new_hash."' where id = ".(int)$user_id);
			return true;
		}
		return false;
	}

	// Authorization helpers -- enforced server-side so a Registrar or
	// Student can't perform admin-only actions (or manage another
	// registrar's event) just by calling the ajax endpoint directly,
	// even though the UI already hides those actions from them.
	private function is_admin(){
		return isset($_SESSION['login_id']) && $_SESSION['login_type'] == 1;
	}
	private function can_manage_event($event_id){
		if($this->is_admin()) return true;
		if(!isset($_SESSION['login_id']) || $_SESSION['login_type'] != 2) return false;
		$chk = $this->db->query("SELECT id FROM assigned_registrar where event_id = ".(int)$event_id." and user_id = ".(int)$_SESSION['login_id'])->num_rows;
		return $chk > 0;
	}
	// Looks up the event_id an attendee belongs to, for ownership checks
	// on actions that only receive the attendee id (not the event id).
	private function event_of_attendee($attendee_id){
		$row = $this->db->query("SELECT event_id FROM attendees where id = ".(int)$attendee_id)->fetch_assoc();
		return $row ? $row['event_id'] : 0;
	}

	function login(){
		extract($_POST);
			$qry = $this->db->query("SELECT *,concat(lastname,', ',firstname,' ',middlename) as name FROM users where email = '".$this->db->real_escape_string($email)."' and type= 1 ");
		if($qry->num_rows > 0){
			$row = $qry->fetch_array();
			if($this->verify_and_upgrade_password($password, $row['password'], $row['id'])){
				foreach ($row as $key => $value) {
					if($key != 'password' && !is_numeric($key))
						$_SESSION['login_'.$key] = $value;
				}
				session_regenerate_id(true);
				return 1;
			}
		}
		return 3;
	}
	function logout(){
		session_destroy();
		foreach ($_SESSION as $key => $value) {
			unset($_SESSION[$key]);
		}
		header("location:login.php");
	}
	function login2(){
		extract($_POST);
			$qry = $this->db->query("SELECT *,concat(lastname,', ',firstname,' ',middlename) as name FROM users where email = '".$this->db->real_escape_string($email)."'  and type in (2,3) ");
		if($qry->num_rows > 0){
			$row = $qry->fetch_array();
			if($this->verify_and_upgrade_password($password, $row['password'], $row['id'])){
				foreach ($row as $key => $value) {
					if($key != 'password' && !is_numeric($key))
						$_SESSION['login_'.$key] = $value;
				}
				session_regenerate_id(true);
				return 1;
			}
		}
		return 3;
	}
	function logout2(){
		session_destroy();
		foreach ($_SESSION as $key => $value) {
			unset($_SESSION[$key]);
		}
		header("location:../index.php");
	}
	function save_user(){
		if(!$this->is_admin()) return 0;
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','cpass','password')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		if(!empty($cpass) && !empty($password)){
					$data .= ", password='".password_hash($password, PASSWORD_BCRYPT)."' ";

		}
		$check = $this->db->query("SELECT * FROM users where email ='$email' ".(!empty($id) ? " and id != {$id} " : ''))->num_rows;
		if($check > 0){
			return 2;
			exit;
		}
		if(isset($_FILES['img']) && $_FILES['img']['tmp_name'] != ''){
			$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
			$move = move_uploaded_file($_FILES['img']['tmp_name'],'../assets/uploads/'. $fname);
			$data .= ", avatar = '$fname' ";

		}
		if(empty($id)){
			$save = $this->db->query("INSERT INTO users set $data");
		}else{
			$save = $this->db->query("UPDATE users set $data where id = $id");
		}

		if($save){
			return 1;
		}
	}
	function signup(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','cpass')) && !is_numeric($k)){
				if($k =='password'){
					if(empty($v))
						continue;
					$v = password_hash($v, PASSWORD_BCRYPT);

				}
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}

		$check = $this->db->query("SELECT * FROM users where email ='$email' ".(!empty($id) ? " and id != {$id} " : ''))->num_rows;
		if($check > 0){
			return 2;
			exit;
		}
		if(isset($_FILES['img']) && $_FILES['img']['tmp_name'] != ''){
			$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
			$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
			$data .= ", avatar = '$fname' ";

		}
		if(empty($id)){
			$save = $this->db->query("INSERT INTO users set $data");

		}else{
			$save = $this->db->query("UPDATE users set $data where id = $id");
		}

		if($save){
			if(empty($id))
				$id = $this->db->insert_id;
			foreach ($_POST as $key => $value) {
				if(!in_array($key, array('id','cpass','password')) && !is_numeric($key))
					$_SESSION['login_'.$key] = $value;
			}
					$_SESSION['login_id'] = $id;
			return 1;
		}
	}

	function update_user(){
		if(!$this->is_admin()) return 0;
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','cpass','table','password')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		if(!empty($password)){
			$data .= ", password='".password_hash($password, PASSWORD_BCRYPT)."' ";
		}
		if(isset($_FILES['img']) && $_FILES['img']['tmp_name'] != ''){
			$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
			$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
			$data .= ", avatar = '$fname' ";

		}
		$check = $this->db->query("SELECT * FROM users where email ='$email' ".(!empty($id) ? " and id != {$id} " : ''))->num_rows;
		if($check > 0){
			return 2;
			exit;
		}
		if(empty($id)){
			$save = $this->db->query("INSERT INTO users set $data");
		}else{
			$save = $this->db->query("UPDATE users set $data where id = $id");
		}

		if($save){
			foreach ($_POST as $key => $value) {
				if($key != 'password' && !is_numeric($key))
					$_SESSION['login_'.$key] = $value;
			}
			if(isset($_FILES['img']) && $_FILES['img']['tmp_name'] != '')
			$_SESSION['login_avatar'] = $fname;
			return 1;
		}
	}
	function delete_user(){
		if(!$this->is_admin()) return 0;
		extract($_POST);
		$delete = $this->db->query("DELETE FROM users where id = ".$id);
		if($delete)
			return 1;
	}
	function save_event(){
		if(!$this->is_admin()) return 0;
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}

		if(empty($id)){
			$save = $this->db->query("INSERT INTO events set $data");
		}else{
			$save = $this->db->query("UPDATE events set $data where id = $id");
		}
		if($save){
			return 1;
		}
	}
	function update_event_stats(){
		if(!$this->is_admin()) return 0;
		extract($_POST);
			$save = $this->db->query("UPDATE events set status = $status where id = $id");
			if($save)
				return 1;
	}
	function delete_event(){
		if(!$this->is_admin()) return 0;
		extract($_POST);
		$delete = $this->db->query("DELETE FROM events where id = $id");
		if($delete){
			return 1;
		}
	}
	function save_attendee(){
		extract($_POST);
		if(!$this->can_manage_event(!empty($event_id) ? $event_id : $this->event_of_attendee(isset($id) ? $id : 0))) return 0;
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','status')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		if(isset($status)){
					$data .= ", status=1 ";
		}else{
					$data .= ", status=0 ";
		}
		if(empty($id)){
			$data .= ", unique_code='".$this->gen_unique_code()."' ";
			$save = $this->db->query("INSERT INTO attendees set $data");
		}else{
			$save = $this->db->query("UPDATE attendees set $data where id = $id");
		}
		if($save){
			return 1;
		}
	}
	function delete_attendee(){
		extract($_POST);
		if(!$this->can_manage_event($this->event_of_attendee($id))) return 0;
		$delete = $this->db->query("DELETE FROM attendees where id = $id");
		if($delete){
			return 1;
		}
	}
	function assign_registrar(){
		if(!$this->is_admin()) return 0;
		extract($_POST);
		$uids = array();
		foreach ($user_id as $k => $v) {
			$data = " event_id = $event_id ";
			$data .= ", user_id = $v ";
			$ins = $this->db->query("INSERT INTO assigned_registrar set $data");
			if($ins){
				$uids[] = $this->db->insert_id;
			}
		}
		$this->db->query("DELETE FROM assigned_registrar where event_id = $event_id ".(count($uids) > 0 ? " and id not in (".implode(',',$uids).") " : ''));
		return 1;
	}
	function update_attendee_stats(){
		extract($_POST);
			$event_id = $this->db->query("SELECT * FROM attendees where id = $id")->fetch_array()['event_id'];
			if(!$this->can_manage_event($event_id)) return 0;
			$chk = $this->db->query("SELECT * FROM events where id = $event_id")->fetch_array()['status'];
			if($chk == 2){
				return 2;
				exit;

			}
			$stamp = $status == 1 ? "checked_in_at = NOW()" : "checked_in_at = NULL";
			$save = $this->db->query("UPDATE attendees set status = $status, $stamp where id = $id");
			if($save)
				return 1;
	}

	// Student self-registers for an event. Returns:
	// 1|CODE  = success, CODE is the attendee's unique check-in code
	// 2 = event registration/attendance is closed
	// 3 = event is not open yet
	// 4 = student already registered for this event
	// 5 = not logged in as a student
	function student_register(){
		extract($_POST);
		if(!isset($_SESSION['login_id']) || $_SESSION['login_type'] != 3){
			return 5;
		}
		$student_id = (int)$_SESSION['login_id'];
		$event_id = (int)$event_id;

		$event = $this->db->query("SELECT * FROM events where id = $event_id")->fetch_array();
		if(!$event) return 3;
		if($event['status'] == 2) return 2;
		if($event['status'] == 0) return 3;

		$dup = $this->db->query("SELECT id FROM attendees where event_id = $event_id and user_id = $student_id")->num_rows;
		if($dup > 0) return 4;

		$me = $this->db->query("SELECT * FROM users where id = $student_id")->fetch_array();

		$code = $this->gen_unique_code();
		$data  = " event_id = $event_id ";
		$data .= ", firstname = '".$this->db->real_escape_string($me['firstname'])."' ";
		$data .= ", lastname = '".$this->db->real_escape_string($me['lastname'])."' ";
		$data .= ", middlename = '".$this->db->real_escape_string($me['middlename'])."' ";
		$data .= ", contact = '".$this->db->real_escape_string($me['contact'])."' ";
		$data .= ", gender = '".$this->db->real_escape_string($me['gender'])."' ";
		$data .= ", email = '".$this->db->real_escape_string($me['email'])."' ";
		$data .= ", address = '".$this->db->real_escape_string($me['address'])."' ";
		$data .= ", status = 0 ";
		$data .= ", unique_code = '$code' ";
		$data .= ", user_id = $student_id ";

		$save = $this->db->query("INSERT INTO attendees set $data");
		if($save){
			return "1|$code";
		}
	}

	// Registrar checks an attendee in by typing the code the student shows them.
	// Returns:
	// 1|Name = success
	// 2 = event closed
	// 3 = code not found for this event
	// 4 = already checked in
	function checkin_by_code(){
		extract($_POST);
		if(!isset($_SESSION['login_id'])){
			return 5;
		}
		$event_id = (int)$event_id;
		if(!$this->can_manage_event($event_id)){
			return 5;
		}
		$code = strtoupper(trim($code));

		$event = $this->db->query("SELECT * FROM events where id = $event_id")->fetch_array();
		if(!$event) return 3;
		if($event['status'] == 2) return 2;

		$attendee = $this->db->query("SELECT * FROM attendees where event_id = $event_id and unique_code = '".$this->db->real_escape_string($code)."'")->fetch_array();
		if(!$attendee) return 3;
		if($attendee['status'] == 1) return 4;

		$save = $this->db->query("UPDATE attendees set status = 1, checked_in_at = NOW() where id = ".$attendee['id']);
		if($save){
			$name = ucwords($attendee['firstname'].' '.$attendee['lastname']);
			return "1|$name";
		}
	}

	// Aggregated stats for the admin Analytics page (Chart.js).
	function get_analytics(){
		$empty = json_encode(array('events'=>array(),'total_registered'=>0,'total_present'=>0,'total_absent'=>0,'by_month'=>array()));
		if(!$this->is_admin()) return $empty;
		$events = array();
		$qry = $this->db->query("SELECT e.id,e.event,e.status,
			(SELECT COUNT(*) FROM attendees a where a.event_id = e.id) as registered,
			(SELECT COUNT(*) FROM attendees a where a.event_id = e.id and a.status = 1) as present
			FROM events e ORDER BY e.date_created desc LIMIT 10");
		while($row = $qry->fetch_assoc()){
			$events[] = $row;
		}

		$total_registered = $this->db->query("SELECT COUNT(*) as c FROM attendees")->fetch_assoc()['c'];
		$total_present = $this->db->query("SELECT COUNT(*) as c FROM attendees where status = 1")->fetch_assoc()['c'];
		$total_absent = $total_registered - $total_present;

		$by_month = array();
		$qry2 = $this->db->query("SELECT DATE_FORMAT(date_created,'%Y-%m-01') as ym_sort, DATE_FORMAT(date_created,'%b %Y') as ym, COUNT(*) as c FROM attendees GROUP BY DATE_FORMAT(date_created,'%Y-%m-01'), DATE_FORMAT(date_created,'%b %Y') ORDER BY ym_sort asc LIMIT 12");
		while($row = $qry2->fetch_assoc()){
			$by_month[] = $row;
		}

		return json_encode(array(
			'events' => $events,
			'total_registered' => (int)$total_registered,
			'total_present' => (int)$total_present,
			'total_absent' => (int)$total_absent,
			'by_month' => $by_month
		), JSON_INVALID_UTF8_SUBSTITUTE);
	}

	// Lightweight polling endpoint so the check-in desk can show a live
	// "X of Y Present" counter without reloading the whole attendee table.
	function get_event_counts(){
		extract($_POST);
		$event_id = (int)$event_id;
		if(!$this->can_manage_event($event_id)){
			return json_encode(array('registered' => 0, 'present' => 0));
		}
		$registered = $this->db->query("SELECT COUNT(*) as c FROM attendees where event_id = $event_id")->fetch_assoc()['c'];
		$present = $this->db->query("SELECT COUNT(*) as c FROM attendees where event_id = $event_id and status = 1")->fetch_assoc()['c'];
		return json_encode(array('registered' => (int)$registered, 'present' => (int)$present), JSON_INVALID_UTF8_SUBSTITUTE);
	}

	// Recent check-in activity, used to populate the notification bell.
	function get_recent_activity(){
		if(!$this->is_admin()) return json_encode(array('recent' => array(), 'today_count' => 0));
		$rows = array();
		$qry = $this->db->query("SELECT a.id,concat(a.firstname,' ',a.lastname) as name,e.event,a.checked_in_at
			FROM attendees a inner join events e on e.id = a.event_id
			where a.checked_in_at is not null
			order by a.checked_in_at desc limit 8");
		while($row = $qry->fetch_assoc()){
			$rows[] = $row;
		}
		$today = $this->db->query("SELECT COUNT(*) as c FROM attendees where date(checked_in_at) = curdate()")->fetch_assoc()['c'];
		return json_encode(array('recent' => $rows, 'today_count' => (int)$today), JSON_INVALID_UTF8_SUBSTITUTE);
	}
}