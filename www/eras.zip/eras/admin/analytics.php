<?php if($_SESSION['login_type'] != 1){ echo '<div class="alert alert-danger">You are not authorized to view this page.</div>'; return; } ?>
<div class="col-lg-12">
	<div class="mb-3">
		<h2 class="mb-1">Analytics</h2>
		<p class="text-muted mb-0">A quick look at how your events are performing.</p>
	</div>
	<div class="row mb-1" id="analytics-summary">
		<div class="col-12 col-sm-4">
			<div class="info-box">
				<span class="info-box-icon bg-info elevation-1"><i class="fas fa-user-friends"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Total Registrations</span>
					<span class="info-box-number" id="stat-registered">—</span>
				</div>
			</div>
		</div>
		<div class="col-12 col-sm-4">
			<div class="info-box">
				<span class="info-box-icon bg-success elevation-1"><i class="fas fa-user-check"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Present</span>
					<span class="info-box-number" id="stat-present">—</span>
				</div>
			</div>
		</div>
		<div class="col-12 col-sm-4">
			<div class="info-box">
				<span class="info-box-icon bg-warning elevation-1"><i class="fas fa-percentage"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Attendance Rate</span>
					<span class="info-box-number" id="stat-rate">—</span>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6">
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Registered vs Present per Event</h3>
				</div>
				<div class="card-body">
					<canvas id="eventsChart" style="min-height: 300px"></canvas>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card card-outline card-success">
				<div class="card-header">
					<h3 class="card-title">Overall Attendance</h3>
				</div>
				<div class="card-body">
					<canvas id="overallChart" style="min-height: 300px"></canvas>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<div class="card card-outline card-warning">
				<div class="card-header">
					<h3 class="card-title">Registrations Over Time</h3>
				</div>
				<div class="card-body">
					<canvas id="trendChart" style="min-height: 250px"></canvas>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="../assets/plugins/chart.js/Chart.min.js"></script>
<script>
	$.ajax({
		url: 'ajax.php?action=get_analytics',
		method: 'GET',
		dataType: 'json',
		error: function(xhr){
			console.error('Analytics load failed:', xhr.status, xhr.responseText)
			alert_toast('Could not load analytics data (HTTP '+xhr.status+'). Check the browser console for details.','error')
			$('#stat-registered, #stat-present, #stat-rate').text('0')
		},
		success: function(data){
			if(!data || !data.events){
				console.error('Analytics returned an unexpected response:', data)
				alert_toast('Analytics data came back empty or in an unexpected format.','error')
				$('#stat-registered, #stat-present, #stat-rate').text('0')
				return;
			}
			var labels = data.events.map(function(e){ return e.event });
			var registered = data.events.map(function(e){ return parseInt(e.registered) });
			var present = data.events.map(function(e){ return parseInt(e.present) });

			$('#stat-registered').text(data.total_registered)
			$('#stat-present').text(data.total_present)
			var rate = data.total_registered > 0 ? Math.round((data.total_present / data.total_registered) * 100) : 0;
			$('#stat-rate').text(rate + '%')

			new Chart(document.getElementById('eventsChart').getContext('2d'), {
				type: 'bar',
				data: {
					labels: labels,
					datasets: [
						{ label: 'Registered', backgroundColor:'#4F46E5', data: registered },
						{ label: 'Present', backgroundColor:'#10B981', data: present }
					]
				},
				options: {
					responsive: true,
					scales: { yAxes: [{ ticks: { beginAtZero: true, precision: 0 } }] }
				}
			});

			new Chart(document.getElementById('overallChart').getContext('2d'), {
				type: 'doughnut',
				data: {
					labels: ['Present', 'Absent / Waiting'],
					datasets: [{
						backgroundColor: ['#10B981', '#F43F5E'],
						data: [data.total_present, data.total_absent]
					}]
				},
				options: { responsive: true }
			});

			var trendLabels = data.by_month.map(function(m){ return m.ym });
			var trendData = data.by_month.map(function(m){ return parseInt(m.c) });

			new Chart(document.getElementById('trendChart').getContext('2d'), {
				type: 'line',
				data: {
					labels: trendLabels,
					datasets: [{
						label: 'Registrations',
						borderColor: '#F59E0B',
						backgroundColor: 'rgba(245,158,11,0.15)',
						data: trendData,
						fill: true
					}]
				},
				options: {
					responsive: true,
					scales: { yAxes: [{ ticks: { beginAtZero: true, precision: 0 } }] }
				}
			});
		}
	})
</script>
