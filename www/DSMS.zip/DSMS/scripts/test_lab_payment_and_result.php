<?php
require __DIR__ . '/../src/Database.php';
require __DIR__ . '/../src/Models/Patient.php';
require __DIR__ . '/../src/Models/Consultation.php';
require __DIR__ . '/../src/Models/LabRequest.php';
require __DIR__ . '/../src/Models/Payment.php';
require __DIR__ . '/../src/Models/LabResult.php';
require __DIR__ . '/../src/Models/Staff.php';

$pdo = Database::getConnection();
try {
    // create patient
    $patientId = Patient::create([ 'full_name' => 'Flow Test', 'gender' => 'Other', 'date_of_birth' => '1990-01-01', 'phone' => '111', 'email' => 'flow@example.com', 'address' => 'Nowhere', 'emergency_contact' => '' ]);
    echo "Patient: $patientId\n";

    // ensure doctor and lab staff
    $stmt = $pdo->query("SELECT id FROM staff WHERE role='doctor' LIMIT 1");
    $doc = $stmt->fetch();
    if (!$doc) { $docId = Staff::create('doc_flow','doc@local','Doc Flow','doctor','pass'); } else { $docId = $doc['id']; }
    $stmt = $pdo->query("SELECT id FROM staff WHERE role='lab' LIMIT 1");
    $lab = $stmt->fetch();
    if (!$lab) { $labId = Staff::create('lab_flow','lab@local','Lab Flow','lab','pass'); } else { $labId = $lab['id']; }

    $consultationId = Consultation::create($patientId, $docId, 'sym', 'exam', 'diag', 'Lab Investigation Required', null);
    echo "Consultation: $consultationId\n";

    $labId = LabRequest::create($consultationId, 'CBC', 200.0);
    echo "LabRequest: $labId\n";

    $paymentId = Payment::recordLabPayment($labId, 200.0, $labId);
    echo "Lab Payment recorded: $paymentId\n";

    $resultId = LabResult::upload($labId, 'All normal', 'No issues');
    echo "Lab Result uploaded: $resultId\n";

    $labRequest = LabRequest::find($labId);
    $consult = Consultation::find($consultationId);
    echo "Lab status: " . ($labRequest['status'] ?? 'N/A') . "\n";
    echo "Consultation status: " . ($consult['status'] ?? 'N/A') . "\n";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
