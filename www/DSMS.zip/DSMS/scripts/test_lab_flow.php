<?php
require __DIR__ . '/../src/Database.php';
require __DIR__ . '/../src/Models/Patient.php';
require __DIR__ . '/../src/Models/Consultation.php';
require __DIR__ . '/../src/Models/LabRequest.php';

$pdo = Database::getConnection();
try {
    $patientId = Patient::create([ 'full_name' => 'Test Patient', 'gender' => 'Other', 'date_of_birth' => '2000-01-01', 'phone' => '000', 'email' => 'test@example.com', 'address' => 'Nowhere', 'emergency_contact' => '' ]);
    echo "Created patient id: $patientId\n";

    // create a dummy doctor account if none exists
    $stmt = $pdo->query("SELECT id FROM staff WHERE role='doctor' LIMIT 1");
    $doc = $stmt->fetch();
    if (!$doc) {
        require __DIR__ . '/../src/Models/Staff.php';
        $docId = Staff::create('doc_test', 'doc@local', 'Doc Test', 'doctor', 'password');
    } else {
        $docId = $doc['id'];
    }

    $consultationId = Consultation::create($patientId, $docId, 'symptom', 'exam', 'diag', 'Lab Investigation Required', 'note');
    echo "Created consultation id: $consultationId\n";

    $labId = LabRequest::create($consultationId, 'CHECK UP', 15000.0);
    echo "Created lab request id: $labId\n";
} catch (\Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
