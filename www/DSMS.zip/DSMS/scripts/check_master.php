<?php
$db = __DIR__ . '/../data/database.sqlite';
$pdo = new PDO('sqlite:'.$db);
$stmt = $pdo->query("SELECT type,name,sql FROM sqlite_master WHERE sql LIKE '%consultations_old%';");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($rows, JSON_PRETTY_PRINT);
