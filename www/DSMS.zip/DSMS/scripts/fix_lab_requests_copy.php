<?php
$orig = __DIR__ . '/../data/database.sqlite';
$copy = __DIR__ . '/../data/database_fix.sqlite';
if (!copy($orig, $copy)) {
    echo "Failed to copy DB file\n";
    exit(1);
}
$pdo = new PDO('sqlite:'.$copy);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->exec('PRAGMA busy_timeout = 5000');
try {
    $stmt = $pdo->query("SELECT sql FROM sqlite_master WHERE type='table' AND name='lab_requests'");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row && strpos($row['sql'], 'consultations_old') !== false) {
        echo "Rebuilding lab_requests in copy...\n";
        $pdo->exec('PRAGMA foreign_keys = OFF');
        $pdo->beginTransaction();
        $pdo->exec('ALTER TABLE lab_requests RENAME TO lab_requests_old');
        $create = <<<SQL
CREATE TABLE lab_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    consultation_id INTEGER NOT NULL,
    test_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending Payment',
    bill REAL NOT NULL,
    created_at TEXT NOT NULL,
    paid_at TEXT,
    FOREIGN KEY(consultation_id) REFERENCES consultations(id) ON DELETE CASCADE
);
SQL;
        $pdo->exec($create);
        $pdo->exec('INSERT INTO lab_requests (id, consultation_id, test_type, status, bill, created_at, paid_at) SELECT id, consultation_id, test_type, status, bill, created_at, paid_at FROM lab_requests_old');
        $pdo->exec('DROP TABLE lab_requests_old');
        $pdo->commit();
        $pdo->exec('PRAGMA foreign_keys = ON');
        echo "lab_requests rebuilt in copy.\n";
    } else {
        echo "lab_requests does not reference consultations_old in copy. No action needed.\n";
    }
    // replace original with fixed copy
    if (!rename($copy, $orig)) {
        echo "Failed to replace original DB with fixed copy.\n";
    } else {
        echo "Replaced original DB with fixed copy.\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    @unlink($copy);
}
