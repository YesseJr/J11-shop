<?php
require __DIR__ . '/../src/Database.php';
Database::getConnection();
echo "DB initialized\n";
