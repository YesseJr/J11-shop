<?php
$orig = __DIR__ . '/../data/database.sqlite';
$new = __DIR__ . '/../data/database_rebuilt.sqlite';
@unlink($new);
$read = new PDO('sqlite:'.$orig);
$read->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$read->exec('PRAGMA busy_timeout = 5000');
$write = new PDO('sqlite:'.$new);
$write->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$write->exec('PRAGMA foreign_keys = OFF');
try {
    $tables = $read->query("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($tables as $tbl) {
        $name = $tbl['name'];
        $sql = $tbl['sql'];
        if ($name === 'lab_requests') {
            $sql = str_replace('consultations_old', 'consultations', $sql);
        }
        if (empty($sql)) continue;
        echo "Creating table: $name\n";
        $write->exec($sql);
        // copy data
        $colsStmt = $read->query("PRAGMA table_info('$name')");
        $cols = $colsStmt->fetchAll(PDO::FETCH_ASSOC);
        if (!$cols) continue;
        $colNames = array_map(function($c){ return $c['name']; }, $cols);
        $colList = implode(", ", array_map(function($c){return '"'.$c.'"';}, $colNames));
        $select = $read->query("SELECT $colList FROM $name");
        $rows = $select->fetchAll(PDO::FETCH_ASSOC);
        if (empty($rows)) continue;
        $placeholders = implode(',', array_fill(0, count($colNames), '?'));
        $insert = $write->prepare("INSERT INTO $name ($colList) VALUES ($placeholders)");
        foreach ($rows as $r) {
            $insert->execute(array_values($r));
        }
    }
    $write->exec('PRAGMA foreign_keys = ON');
    echo "Rebuilt DB written to $new\n";
    // backup original
    copy($orig, $orig . '.bak.' . time());
    // replace
    rename($new, $orig);
    echo "Replaced original DB with rebuilt DB\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    @unlink($new);
}
