# DSMS - Hospital & Dispensary Management System

A modern, role-based hospital management system with staff authentication and separate dashboards for different roles.

## Features

- **Staff-Only Authentication**: No patient login. Hospital staff only.
- **Role-Based Access**:
  - **Admin**: System administration, staff management, monitoring
  - **Doctor**: Consultation management, patient consultations, medical records
  - **Receptionist**: Patient registration, queue management
- **Patient Workflow**:
  1. Reception registers patient → generates Patient ID
  2. Patient added to consultation queue
  3. Doctor accepts patient and records vitals/consultation
  4. Lab investigations if required
  5. Payment tracking
- **Professional UI**: Teal/white/cyan color scheme, responsive design
- **Security**: CSRF protection, password hashing, role-based access control

## Default Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin123` |

## Installation & Usage

1. Place files in `xampp/htdocs/DSMS`
2. Open `http://localhost/DSMS/public/index.php`
3. Login with admin credentials
4. Create new staff accounts (Doctor, Receptionist) from Admin dashboard
5. Staff can login with their credentials

## Project Structure

```
DSMS/
├── public/
│   ├── index.php                 # Main application router
│   └── assets/
│       ├── styles.css            # Professional styling
│       └── app.js                # Client-side interactions
├── src/
│   ├── Database.php              # SQLite connection & schema
│   └── Models/
│       ├── Staff.php             # Staff authentication
│       ├── Patient.php           # Patient records
│       ├── QueueManager.php       # Queue operations
│       ├── Vital.php             # Vital signs recording
│       ├── Consultation.php       # Doctor consultations
│       ├── Payment.php           # Payment tracking
│       ├── LabRequest.php        # Lab request management
│       └── LabResult.php         # Lab result uploads
└── data/
    └── database.sqlite           # SQLite database (auto-created)
```

## Dashboard Features

### Admin Dashboard
- Staff directory and management
- Create new staff accounts
- System statistics
- User activity monitoring

### Doctor Dashboard
- View waiting patients queue
- Accept and consult patients
- Record vital signs
- Document symptoms, examination, diagnosis
- Create lab investigation requests

### Receptionist Dashboard
- Register new patients
- Add patients to consultation queue
- View current queue status
- Patient information management

## Color Scheme

- **Primary**: Teal (`#0f766e`)
- **Primary Light**: Cyan (`#14b8a6`)
- **Accent**: Sky Cyan (`#06b6d4`)
- **Backgrounds**: Mint green gradient
- **Professional**: Clean, modern, accessible

## Security Features

- Session-based authentication
- CSRF token validation on forms
- Password hashing with bcrypt
- Role-based access control (RBAC)
- SQL injection prevention via prepared statements
- XSS protection via HTML escaping

## Database Tables

- `staff`: Staff user accounts with roles
- `patients`: Patient demographic data
- `queue_entries`: Consultation queue management
- `vitals`: Patient vital signs records
- `payments`: Payment transaction records
- `consultations`: Doctor consultation notes
- `lab_requests`: Laboratory investigation requests
- `lab_results`: Lab result records

## Development Notes

- Built with plain PHP + SQLite
- No external dependencies required
- Fully functional workflow from reception to lab
- Ready for extension with additional features

## Future Enhancements

- Patient search and filtering
- Consultation history viewer
- Lab result viewing
- Financial reports
- SMS/Email notifications
- Mobile-responsive improvements
