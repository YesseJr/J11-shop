<?php
/**
 * DSMS One-Time Migration Script
 * ---------------------------------
 * Drop this file in the ROOT of your DSMS project (same level as /data, /src, /public).
 * Open it in your browser: http://your-server/migrate.php
 * Delete it from your server once it reports SUCCESS.
 *
 * What it does:
 *   Your app was previously forking to data/database_fixed.sqlite whenever it
 *   detected a stale schema. All your registered staff are in that file. This
 *   script promotes it to the canonical data/database.sqlite so the fixed code
 *   can find everyone again.
 */

$dataDir   = __DIR__ . '/data';
$liveDb    = $dataDir . '/database.sqlite';
$fixedDb   = $dataDir . '/database_fixed.sqlite';
$backupDb  = $dataDir . '/database.sqlite.pre-migration-backup';

header('Content-Type: text/plain; charset=utf-8');

// ── Guards ────────────────────────────────────────────────────────────────────

if (!file_exists($fixedDb)) {
    die("SKIP: data/database_fixed.sqlite does not exist.\n"
      . "Nothing to migrate — your app was always writing to database.sqlite already.\n"
      . "Delete this file from your server.\n");
}

if (!is_writable($dataDir)) {
    die("ERROR: data/ directory is not writable by the web server.\n"
      . "Fix permissions and try again.\n");
}

// ── Count staff in each file ──────────────────────────────────────────────────

try {
    $pdoLive  = new PDO('sqlite:' . $liveDb);
    $pdoFixed = new PDO('sqlite:' . $fixedDb);
    $pdoLive->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdoFixed->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $staffLive  = (int) $pdoLive ->query('SELECT COUNT(*) FROM staff')->fetchColumn();
    $staffFixed = (int) $pdoFixed->query('SELECT COUNT(*) FROM staff')->fetchColumn();
} catch (Exception $e) {
    die("ERROR reading databases: " . $e->getMessage() . "\n");
}

echo "database.sqlite         staff rows: $staffLive\n";
echo "database_fixed.sqlite   staff rows: $staffFixed\n\n";

if ($staffFixed === 0) {
    die("SKIP: database_fixed.sqlite has no staff rows — nothing useful to migrate.\n"
      . "Delete this file from your server.\n");
}

// ── Check whether migration was already run ───────────────────────────────────

if ($staffFixed <= $staffLive && !str_contains(
    (string) $pdoLive->query("SELECT COUNT(*) FROM sqlite_master WHERE sql LIKE '%consultations_old%'")->fetchColumn(),
    '0'
)) {
    // refined check below
}

$brokenCount = (int) $pdoLive
    ->query("SELECT COUNT(*) FROM sqlite_master WHERE sql LIKE '%consultations_old%' OR sql LIKE '%staff_old%'")
    ->fetchColumn();

if ($brokenCount === 0 && $staffLive >= $staffFixed) {
    die("SKIP: database.sqlite already looks healthy and has at least as many staff.\n"
      . "Migration may have already run. Verify your logins, then delete this file.\n");
}

// ── Backup current database.sqlite ───────────────────────────────────────────

if (!copy($liveDb, $backupDb)) {
    die("ERROR: Could not create backup at data/database.sqlite.pre-migration-backup\n");
}
echo "Backup created: data/database.sqlite.pre-migration-backup\n\n";

// ── Promote database_fixed.sqlite → database.sqlite ──────────────────────────

if (!copy($fixedDb, $liveDb)) {
    // Roll back
    copy($backupDb, $liveDb);
    die("ERROR: Could not replace database.sqlite with database_fixed.sqlite.\n"
      . "Rolled back. Check file permissions.\n");
}

// ── Verify the promoted file is healthy ──────────────────────────────────────

try {
    $pdoNew = new PDO('sqlite:' . $liveDb);
    $pdoNew->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $newCount = (int) $pdoNew->query('SELECT COUNT(*) FROM staff')->fetchColumn();
    $rows = $pdoNew->query('SELECT id, username, role FROM staff ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    copy($backupDb, $liveDb);
    die("ERROR: Promoted database failed integrity check: " . $e->getMessage() . "\n"
      . "Rolled back to original. No changes were kept.\n");
}

echo "database.sqlite now contains $newCount staff:\n";
echo str_pad('ID', 5) . str_pad('Username', 20) . "Role\n";
echo str_repeat('-', 40) . "\n";
foreach ($rows as $r) {
    echo str_pad($r['id'], 5) . str_pad($r['username'], 20) . $r['role'] . "\n";
}

echo "\n✓ SUCCESS\n\n";
echo "Next steps:\n";
echo "  1. Test that all staff can log in now.\n";
echo "  2. DELETE this migrate.php file from your server.\n";
echo "  3. data/database_fixed.sqlite is no longer used — you may archive or delete it.\n";
echo "  4. data/database.sqlite.pre-migration-backup is your safety net — keep it until you're satisfied.\n";