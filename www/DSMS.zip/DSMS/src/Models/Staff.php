<?php

require_once __DIR__ . '/../../src/Database.php';

class Staff
{
    public static function authenticate(string $username, string $password): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM staff WHERE username = ? AND is_active = 1');
        $stmt->execute([$username]);
        $staff = $stmt->fetch();

        if (!$staff) {
            return null;
        }

        if (!password_verify($password, $staff['password_hash'])) {
            return null;
        }

        $stmt = $pdo->prepare('UPDATE staff SET last_login = ? WHERE id = ?');
        $stmt->execute([date('c'), $staff['id']]);

        return $staff;
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM staff WHERE id = ? AND is_active = 1');
        $stmt->execute([$id]);

        return $stmt->fetch() ?: null;
    }

    public static function create(string $username, string $email, string $fullName, string $role, string $password): int
    {
        $pdo = Database::getConnection();
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $now = date('c');

        $stmt = $pdo->prepare(
            'INSERT INTO staff (username, email, password_hash, full_name, role, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$username, $email, $hashedPassword, $fullName, $role, $now, $now]);

        return (int)$pdo->lastInsertId();
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT id, username, email, full_name, role, is_active, last_login, created_at FROM staff ORDER BY created_at DESC');

        return $stmt->fetchAll();
    }

    public static function updateStatus(int $id, bool $isActive): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE staff SET is_active = ?, updated_at = ? WHERE id = ?');
        $stmt->execute([$isActive ? 1 : 0, date('c'), $id]);
    }

    public static function getById(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM staff WHERE id = ?');
        $stmt->execute([$id]);

        return $stmt->fetch() ?: null;
    }

    public static function update(int $id, string $username, string $email, string $fullName, string $role, bool $isActive, ?string $password = null): void
    {
        $pdo = Database::getConnection();
        $params = [$username, $email, $fullName, $role, $isActive ? 1 : 0, date('c'), $id];
        $sql = 'UPDATE staff SET username = ?, email = ?, full_name = ?, role = ?, is_active = ?, updated_at = ?';

        if ($password !== null && $password !== '') {
            $sql .= ', password_hash = ?';
            $params = [$username, $email, $fullName, $role, $isActive ? 1 : 0, date('c'), password_hash($password, PASSWORD_BCRYPT), $id];
        }

        $sql .= ' WHERE id = ?';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    }

    public static function delete(int $id): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('DELETE FROM staff WHERE id = ?');
        $stmt->execute([$id]);
    }

    public static function getByRole(string $role): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT id, username, full_name, email, role FROM staff WHERE role = ? AND is_active = 1 ORDER BY full_name ASC');
        $stmt->execute([$role]);

        return $stmt->fetchAll();
    }
}
