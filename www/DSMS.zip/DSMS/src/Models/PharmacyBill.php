<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Payment.php';
require_once __DIR__ . '/Patient.php';

class PharmacyBill
{
    public static function create(int $patientId, int $pharmacistStaffId, float $amount): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO pharmacy_bills (patient_id, pharmacist_staff_id, amount, created_at)
             VALUES (:patient_id, :pharmacist_staff_id, :amount, :created_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':pharmacist_staff_id' => $pharmacistStaffId,
            ':amount' => $amount,
            ':created_at' => date('c'),
        ]);

        Patient::updateStatus($patientId, 'Pharmacy Billing Pending');
        return (int)$pdo->lastInsertId();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT b.*, pt.patient_id AS patient_code, pt.full_name, s.full_name AS pharmacist_name
             FROM pharmacy_bills b
             JOIN patients pt ON pt.id = b.patient_id
             JOIN staff s ON s.id = b.pharmacist_staff_id
             WHERE b.id = :id'
        );
        $stmt->execute([':id' => $id]);

        $bill = $stmt->fetch();
        return $bill ?: null;
    }

    public static function getPending(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT b.*, pt.patient_id AS patient_code, pt.full_name
             FROM pharmacy_bills b
             JOIN patients pt ON pt.id = b.patient_id
             WHERE b.paid_at IS NULL
             ORDER BY b.created_at DESC'
        );

        return $stmt->fetchAll();
    }

    public static function markPaid(int $billId, int $paidByStaffId): int
    {
        $bill = self::find($billId);
        if (!$bill) {
            throw new \Exception('Pharmacy bill not found.');
        }
        if ($bill['paid_at'] !== null) {
            throw new \Exception('This pharmacy bill has already been paid.');
        }

        $paymentId = Payment::record((int)$bill['patient_id'], 'Pharmacy', (float)$bill['amount'], $paidByStaffId);

        $stmt = Database::getConnection()->prepare(
            'UPDATE pharmacy_bills SET paid_at = :paid_at, paid_by_staff_id = :paid_by_staff_id WHERE id = :id'
        );
        $stmt->execute([
            ':paid_at' => date('c'),
            ':paid_by_staff_id' => $paidByStaffId,
            ':id' => $billId,
        ]);

        Patient::updateStatus((int)$bill['patient_id'], 'Paid for Pharmacy');

        return $paymentId;
    }

    public static function getForPatient(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM pharmacy_bills WHERE patient_id = :patient_id ORDER BY created_at DESC'
        );
        $stmt->execute([':patient_id' => $patientId]);

        return $stmt->fetchAll();
    }
}
