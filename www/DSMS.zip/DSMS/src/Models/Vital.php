<?php

require_once __DIR__ . '/../../src/Database.php';

class Vital
{
    public static function record(int $patientId, array $data): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO vitals (patient_id, weight, height, temperature, blood_pressure, pulse_rate, recorded_at)
             VALUES (:patient_id, :weight, :height, :temperature, :blood_pressure, :pulse_rate, :recorded_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':weight' => $data['weight'],
            ':height' => $data['height'],
            ':temperature' => $data['temperature'],
            ':blood_pressure' => $data['blood_pressure'],
            ':pulse_rate' => $data['pulse_rate'],
            ':recorded_at' => date('c'),
        ]);

        Patient::updateStatus($patientId, 'Vitals Recorded');
        return (int)$pdo->lastInsertId();
    }
}
