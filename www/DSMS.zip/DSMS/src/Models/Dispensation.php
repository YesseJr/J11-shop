<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Patient.php';
require_once __DIR__ . '/Prescription.php';
require_once __DIR__ . '/MedicationHistory.php';

class Dispensation
{
    public static function record(int $prescriptionId, int $pharmacyStaffId, int $quantity, ?string $note = null): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO dispensations (prescription_id, pharmacy_staff_id, quantity, note, dispensed_at)
             VALUES (:prescription_id, :pharmacy_staff_id, :quantity, :note, :dispensed_at)'
        );
        $stmt->execute([
            ':prescription_id' => $prescriptionId,
            ':pharmacy_staff_id' => $pharmacyStaffId,
            ':quantity' => $quantity,
            ':note' => $note,
            ':dispensed_at' => date('c'),
        ]);

        $prescription = Prescription::find($prescriptionId);
        if ($prescription) {
            Patient::updateStatus((int)$prescription['patient_id'], 'Medicine Dispensed');
            // Record medication history for tracking
            try {
                MedicationHistory::record((int)$prescription['patient_id'], $prescriptionId, $pharmacyStaffId, $quantity, $note ?: null, date('c'));
            } catch (\Exception $e) {
                // ignore history failures but keep dispense successful
            }
        }

        return (int)$pdo->lastInsertId();
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT d.*, p.medication, pt.patient_id AS patient_code, pt.full_name AS patient_name, s.full_name AS staff_name
             FROM dispensations d
             JOIN prescriptions p ON p.id = d.prescription_id
             JOIN patients pt ON pt.id = p.patient_id
             JOIN staff s ON s.id = d.pharmacy_staff_id
             ORDER BY d.dispensed_at DESC'
        );

        return $stmt->fetchAll();
    }
}
