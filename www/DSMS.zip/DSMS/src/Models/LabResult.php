<?php

require_once __DIR__ . '/../../src/Database.php';

class LabResult
{
    public static function upload(int $labRequestId, string $result, string $comments = null): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO lab_results (lab_request_id, result, comments, uploaded_at)
             VALUES (:lab_request_id, :result, :comments, :uploaded_at)'
        );
        $stmt->execute([
            ':lab_request_id' => $labRequestId,
            ':result' => $result,
            ':comments' => $comments,
            ':uploaded_at' => date('c'),
        ]);

        $labRequest = LabRequest::find($labRequestId);
        if ($labRequest) {
            // mark consultation as results ready and update lab request status
            $stmt = $pdo->prepare('UPDATE consultations SET status = :status WHERE id = :id');
            $stmt->execute([':status' => 'Results Ready', ':id' => $labRequest['consultation_id']]);

            $stmt = $pdo->prepare('UPDATE lab_requests SET status = :status WHERE id = :id');
            $stmt->execute([':status' => 'Completed', ':id' => $labRequestId]);

            $patientId = self::fetchPatientIdForLabRequest($labRequestId);
            if ($patientId) {
                Patient::updateStatus($patientId, 'Results Ready');
            }
        }

        return (int)$pdo->lastInsertId();
    }

    public static function findByLabRequestId(int $labRequestId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM lab_results WHERE lab_request_id = :id');
        $stmt->execute([':id' => $labRequestId]);

        return $stmt->fetch() ?: null;
    }

    private static function fetchPatientIdForLabRequest(int $labRequestId): ?int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT c.patient_id FROM consultations c
             JOIN lab_requests l ON l.consultation_id = c.id
             WHERE l.id = :id'
        );
        $stmt->execute([':id' => $labRequestId]);
        $row = $stmt->fetch();
        return $row ? (int)$row['patient_id'] : null;
    }
}
