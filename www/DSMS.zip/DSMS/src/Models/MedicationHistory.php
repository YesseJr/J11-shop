<?php

require_once __DIR__ . '/../../src/Database.php';
require_once __DIR__ . '/Patient.php';

class MedicationHistory
{
    public static function record(int $patientId, ?int $prescriptionId, int $pharmacyStaffId, int $quantity, ?string $note = null, ?string $dispensedAt = null): int
    {
        $pdo = Database::getConnection();
        $now = date('c');
        $dispensedAt = $dispensedAt ?: date('c');

        $stmt = $pdo->prepare(
            'INSERT INTO medication_history (patient_id, prescription_id, pharmacy_staff_id, quantity, note, dispensed_at, created_at)
             VALUES (:patient_id, :prescription_id, :pharmacy_staff_id, :quantity, :note, :dispensed_at, :created_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':prescription_id' => $prescriptionId,
            ':pharmacy_staff_id' => $pharmacyStaffId,
            ':quantity' => $quantity,
            ':note' => $note,
            ':dispensed_at' => $dispensedAt,
            ':created_at' => $now,
        ]);

        return (int)$pdo->lastInsertId();
    }

    public static function getForPatient(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT mh.*, p.medication, p.dosage, p.frequency, s.full_name AS pharmacist_name
             FROM medication_history mh
             LEFT JOIN prescriptions p ON p.id = mh.prescription_id
             LEFT JOIN staff s ON s.id = mh.pharmacy_staff_id
             WHERE mh.patient_id = :patient_id
             ORDER BY mh.dispensed_at DESC'
        );
        $stmt->execute([':patient_id' => $patientId]);
        return $stmt->fetchAll();
    }
}
