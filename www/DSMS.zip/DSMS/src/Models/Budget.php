<?php

require_once __DIR__ . '/../../src/Database.php';

class Budget
{
    public static function create(string $department, float $allocated, ?string $fiscalYear = null): int
    {
        $pdo = Database::getConnection();
        $now = date('c');
        $stmt = $pdo->prepare('INSERT INTO budgets (department, allocated, spent, fiscal_year, created_at, updated_at) VALUES (:department, :allocated, 0, :fiscal_year, :created_at, :updated_at)');
        $stmt->execute([
            ':department' => $department,
            ':allocated' => $allocated,
            ':fiscal_year' => $fiscalYear,
            ':created_at' => $now,
            ':updated_at' => $now,
        ]);

        return (int)$pdo->lastInsertId();
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT * FROM budgets ORDER BY fiscal_year DESC, department ASC');
        return $stmt->fetchAll();
    }

    public static function updateSpent(int $id, float $spent): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE budgets SET spent = spent + :spent, updated_at = :updated_at WHERE id = :id');
        $stmt->execute([':spent' => $spent, ':updated_at' => date('c'), ':id' => $id]);
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM budgets WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }
}
