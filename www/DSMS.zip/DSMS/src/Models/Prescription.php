<?php

require_once __DIR__ . '/../../src/Database.php';

class Prescription
{
    public static function create(int $patientId, int $doctorStaffId, string $medication, string $dosage, string $frequency, ?string $instructions = null): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO prescriptions (patient_id, doctor_staff_id, medication, dosage, frequency, instructions, created_at)
             VALUES (:patient_id, :doctor_staff_id, :medication, :dosage, :frequency, :instructions, :created_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':doctor_staff_id' => $doctorStaffId,
            ':medication' => $medication,
            ':dosage' => $dosage,
            ':frequency' => $frequency,
            ':instructions' => $instructions,
            ':created_at' => date('c'),
        ]);

        return (int)$pdo->lastInsertId();
    }

    public static function getForPatient(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT * FROM prescriptions WHERE patient_id = :patient_id ORDER BY created_at DESC'
        );
        $stmt->execute([':patient_id' => $patientId]);

        return $stmt->fetchAll();
    }

    public static function getPendingForPatient(int $patientId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT p.*
             FROM prescriptions p
             LEFT JOIN dispensations d ON d.prescription_id = p.id
             WHERE p.patient_id = :patient_id AND d.id IS NULL
             ORDER BY p.created_at DESC'
        );
        $stmt->execute([':patient_id' => $patientId]);

        return $stmt->fetchAll();
    }

    public static function getPending(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT p.*, pt.patient_id AS patient_code, pt.full_name, s.full_name AS doctor_name
             FROM prescriptions p
             JOIN patients pt ON pt.id = p.patient_id
             JOIN staff s ON s.id = p.doctor_staff_id
             LEFT JOIN dispensations d ON d.prescription_id = p.id
             WHERE d.id IS NULL
             ORDER BY p.created_at DESC'
        );

        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT p.*, pt.patient_id AS patient_code, pt.full_name
             FROM prescriptions p
             JOIN patients pt ON pt.id = p.patient_id
             WHERE p.id = :id'
        );
        $stmt->execute([':id' => $id]);

        $prescription = $stmt->fetch();
        return $prescription ?: null;
    }
}
