<?php

require_once __DIR__ . '/../../src/Database.php';

class Consultation
{
    public static function create(int $patientId, int $doctorId, string $symptoms, string $examination, string $diagnosis, string $status, ?string $note = null): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO consultations (patient_id, doctor_staff_id, symptoms, examination, diagnosis, note, status, created_at)
             VALUES (:patient_id, :doctor_staff_id, :symptoms, :examination, :diagnosis, :note, :status, :created_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':doctor_staff_id' => $doctorId,
            ':symptoms' => $symptoms,
            ':examination' => $examination,
            ':diagnosis' => $diagnosis,
            ':note' => $note,
            ':status' => $status,
            ':created_at' => date('c'),
        ]);

        Patient::updateStatus($patientId, self::normalizeStatus($status));
        return (int)$pdo->lastInsertId();
    }

    private static function normalizeStatus(string $status): string
    {
        return match ($status) {
            'Healthy' => 'Consultation Completed',
            'Lab Investigation Required' => 'Lab Investigation Required',
            'Medicine Required' => 'Prescription Issued',
            'Results Reviewed Healthy' => 'Visit Completed',
            'Results Reviewed Medicine Required' => 'Prescription Issued',
            'Results Reviewed Referred' => 'Referred',
            default => $status,
        };
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM consultations WHERE id = :id');
        $stmt->execute([':id' => $id]);

        return $stmt->fetch() ?: null;
    }
}
