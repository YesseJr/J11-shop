<?php

require_once __DIR__ . '/../../src/Database.php';

class Patient
{
    public static function generatePatientId(int $id): string
    {
        return sprintf('PT-%05d', $id);
    }

    public static function create(array $data): int
    {
        $pdo = Database::getConnection();
        $now = date('c');

        $stmt = $pdo->prepare(
            'INSERT INTO patients (full_name, gender, date_of_birth, phone, email, address, emergency_contact, status, created_at, updated_at)
             VALUES (:full_name, :gender, :date_of_birth, :phone, :email, :address, :emergency_contact, :status, :created_at, :updated_at)'
        );

        $stmt->execute([
            ':full_name' => $data['full_name'],
            ':gender' => $data['gender'],
            ':date_of_birth' => $data['date_of_birth'],
            ':phone' => $data['phone'],
            ':email' => $data['email'],
            ':address' => $data['address'],
            ':emergency_contact' => $data['emergency_contact'],
            ':status' => 'Registered',
            ':created_at' => $now,
            ':updated_at' => $now,
        ]);

        $id = (int)$pdo->lastInsertId();
        $patientId = self::generatePatientId($id);
        $pdo->prepare('UPDATE patients SET patient_id = :patient_id WHERE id = :id')
            ->execute([':patient_id' => $patientId, ':id' => $id]);

        return $id;
    }

    public static function find(int $id): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT * FROM patients WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $patient = $stmt->fetch();

        return $patient ?: null;
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        return $pdo->query('SELECT * FROM patients ORDER BY created_at DESC')->fetchAll();
    }

    public static function updateStatus(int $id, string $status): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE patients SET status = :status, updated_at = :updated_at WHERE id = :id');
        $stmt->execute([':status' => $status, ':updated_at' => date('c'), ':id' => $id]);
    }
}
