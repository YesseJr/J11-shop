<?php

require_once __DIR__ . '/../../src/Database.php';

class Payment
{
    public static function record(int $patientId, string $type, float $amount, ?int $recordedByStaffId = null): int
    {
        $pdo = Database::getConnection();
        $receipt = self::generateReceiptNumber();
        $stmt = $pdo->prepare(
            'INSERT INTO payments (patient_id, type, amount, receipt_number, recorded_by_staff_id, paid_at)
             VALUES (:patient_id, :type, :amount, :receipt_number, :recorded_by_staff_id, :paid_at)'
        );
        $stmt->execute([
            ':patient_id' => $patientId,
            ':type' => $type,
            ':amount' => $amount,
            ':receipt_number' => $receipt,
            ':recorded_by_staff_id' => $recordedByStaffId,
            ':paid_at' => date('c'),
        ]);

        $status = match ($type) {
            'Consultation' => 'Consultation Paid',
            'Lab' => 'Lab Payment Completed',
            'Pharmacy' => 'Pharmacy Payment Completed',
            default => 'Payment Recorded',
        };

        Patient::updateStatus($patientId, $status);
        return (int)$pdo->lastInsertId();
    }

    public static function recordConsultation(int $queueId, float $amount, ?int $recordedByStaffId = null): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT patient_id FROM queue_entries WHERE id = :id AND status = :status');
        $stmt->execute([':id' => $queueId, ':status' => 'Accepted']);
        $queue = $stmt->fetch();

        if (!$queue) {
            throw new \Exception('Queue entry must be accepted before payment can be recorded.');
        }

        $paymentId = self::record((int)$queue['patient_id'], 'Consultation', $amount, $recordedByStaffId);
        $stmt = $pdo->prepare('UPDATE queue_entries SET status = :status WHERE id = :id');
        $stmt->execute([':status' => 'Paid', ':id' => $queueId]);

        return $paymentId;
    }

    public static function recordLabPayment(int $labRequestId, float $amount, ?int $recordedByStaffId = null): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT consultation_id FROM lab_requests WHERE id = :id AND status = :status');
        $stmt->execute([':id' => $labRequestId, ':status' => 'Pending Payment']);
        $request = $stmt->fetch();

        if (!$request) {
            throw new \Exception('Lab request must be pending payment before it can be recorded.');
        }

        $stmt = $pdo->prepare('SELECT patient_id FROM consultations WHERE id = :id');
        $stmt->execute([':id' => $request['consultation_id']]);
        $consultation = $stmt->fetch();

        if (!$consultation) {
            throw new \Exception('Related consultation not found.');
        }

        $paymentId = self::record((int)$consultation['patient_id'], 'Lab', $amount, $recordedByStaffId);
        LabRequest::pay($labRequestId);

        return $paymentId;
    }

    public static function recordPharmacyPayment(int $prescriptionId, float $amount, ?int $recordedByStaffId = null): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT patient_id FROM prescriptions WHERE id = :id');
        $stmt->execute([':id' => $prescriptionId]);
        $prescription = $stmt->fetch();

        if (!$prescription) {
            throw new \Exception('Prescription not found.');
        }

        return self::record((int)$prescription['patient_id'], 'Pharmacy', $amount, $recordedByStaffId);
    }

    public static function hasPharmacyPaymentForPatient(int $patientId): bool
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM payments WHERE patient_id = :patient_id AND type = :type');
        $stmt->execute([':patient_id' => $patientId, ':type' => 'Pharmacy']);
        $row = $stmt->fetch();

        return $row && (int)$row['cnt'] > 0;
    }

    public static function recordMedicinePayment(int $patientId, float $amount, ?int $recordedByStaffId = null): int
    {
        $pdo = Database::getConnection();
        $patient = Patient::find($patientId);

        if (!$patient || $patient['status'] !== 'Prescribed') {
            throw new \Exception('Patient must be prescribed before medicine payment can be recorded.');
        }

        return self::record($patientId, 'Medicine', $amount, $recordedByStaffId);
    }

    public static function all(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query('SELECT p.*, pt.patient_id AS patient_code, pt.full_name FROM payments p JOIN patients pt ON pt.id = p.patient_id ORDER BY p.paid_at DESC');
        return $stmt->fetchAll();
    }

    private static function generateReceiptNumber(): string
    {
        return 'RCPT-' . strtoupper(bin2hex(random_bytes(4)));
    }
}
