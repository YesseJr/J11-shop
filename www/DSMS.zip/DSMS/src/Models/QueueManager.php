<?php

require_once __DIR__ . '/../../src/Database.php';

class QueueManager
{
    public static function addToQueue(int $patientId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('INSERT INTO queue_entries (patient_id, queued_at, status) VALUES (:patient_id, :queued_at, :status)');
        $stmt->execute([
            ':patient_id' => $patientId,
            ':queued_at' => date('c'),
            ':status' => 'Waiting for Consultation',
        ]);
    }

    public static function getWaiting(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code, q.queued_at, q.status
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.status = "Waiting for Consultation"
             ORDER BY q.queued_at ASC'
        );

        return $stmt->fetchAll();
    }

    public static function getActive(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code, q.queued_at, q.status
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.status IN ("Waiting for Consultation", "Accepted")
             ORDER BY q.queued_at ASC'
        );

        return $stmt->fetchAll();
    }

    public static function getAccepted(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code, q.queued_at, q.status
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.status = "Accepted"
             ORDER BY q.accepted_at ASC'
        );

        return $stmt->fetchAll();
    }

    public static function find(int $queueId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code, q.status, q.queued_at, q.accepted_at
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.id = :id'
        );
        $stmt->execute([':id' => $queueId]);

        return $stmt->fetch() ?: null;
    }

    public static function accept(int $queueId, int $staffId): ?array
    {
        $entry = self::find($queueId);
        if (!$entry) {
            return null;
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE queue_entries SET status = :status, accepted_at = :accepted_at, accepted_by_staff_id = :staff_id WHERE id = :id');
        $stmt->execute([
            ':status' => 'Accepted',
            ':accepted_at' => date('c'),
            ':staff_id' => $staffId,
            ':id' => $queueId,
        ]);

        Patient::updateStatus($entry['patient_row_id'], 'Awaiting Payment');
        $entry['status'] = 'Accepted';
        $entry['accepted_at'] = date('c');

        return $entry;
    }

    public static function getPaid(): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->query(
            'SELECT q.id AS queue_id, q.patient_id AS patient_row_id, p.full_name, p.patient_id AS patient_code, q.queued_at, q.status
             FROM queue_entries q
             JOIN patients p ON p.id = q.patient_id
             WHERE q.status = "Paid"
             ORDER BY q.accepted_at ASC'
        );

        return $stmt->fetchAll();
    }

    public static function startConsultation(int $queueId): ?array
    {
        $entry = self::find($queueId);
        if (!$entry || $entry['status'] !== 'Paid') {
            return null;
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE queue_entries SET status = :status WHERE id = :id');
        $stmt->execute([
            ':status' => 'In Consultation',
            ':id' => $queueId,
        ]);

        Patient::updateStatus($entry['patient_row_id'], 'In Consultation');
        $entry['status'] = 'In Consultation';

        return $entry;
    }

    public static function acceptNext(): ?array
    {
        $waiting = self::getWaiting();

        if (empty($waiting)) {
            return null;
        }

        return self::accept((int)$waiting[0]['queue_id'], 0);
    }

    public static function delay(int $queueId): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('UPDATE queue_entries SET status = :status, delayed_at = :delayed_at WHERE id = :id');
        $stmt->execute([
            ':status' => 'Delayed',
            ':delayed_at' => date('c'),
            ':id' => $queueId,
        ]);
    }
}
