<?php

class Database
{
    private static ?\PDO $pdo = null;

    public static function getConnection(): \PDO
    {
        if (self::$pdo) {
            return self::$pdo;
        }

        $dbFile = __DIR__ . '/../data/database.sqlite';
        $dsn = 'sqlite:' . $dbFile;

        if (!file_exists($dbFile)) {
            touch($dbFile);
        }

        $pdo = new \PDO($dsn);
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA busy_timeout = 5000');

        // NOTE: this used to silently switch to a second, separate database file
        // (data/database_fixed.sqlite) whenever it detected a stale "_old" table
        // reference left over from a previous repair. That meant any staff member
        // registered while the schema was in that state were saved into a database
        // file that the rest of the app would stop reading from on the very next
        // request - so they were created successfully but could never log in again.
        // We now always keep using this single database file and repair it in place
        // instead, so there is only ever one source of truth for staff accounts.
        self::$pdo = $pdo;

        self::initializeSchema();

        return self::$pdo;
    }

    private static function initializeSchema(): void
    {
        $sql = <<<SQL
CREATE TABLE IF NOT EXISTS staff (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin', 'doctor', 'receptionist', 'billing', 'pharmacy', 'lab')),
    is_active INTEGER DEFAULT 1,
    last_login TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id TEXT UNIQUE,
    full_name TEXT NOT NULL,
    gender TEXT,
    date_of_birth TEXT,
    phone TEXT,
    email TEXT,
    address TEXT,
    emergency_contact TEXT,
    status TEXT NOT NULL DEFAULT 'Registered',
    registered_by_staff_id INTEGER,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(registered_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS queue_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    queued_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Waiting for Consultation',
    accepted_at TEXT,
    accepted_by_staff_id INTEGER,
    delayed_at TEXT,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(accepted_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS vitals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    weight REAL,
    height REAL,
    temperature REAL,
    blood_pressure TEXT,
    pulse_rate INTEGER,
    recorded_by_staff_id INTEGER,
    recorded_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(recorded_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    amount REAL NOT NULL,
    receipt_number TEXT UNIQUE,
    recorded_by_staff_id INTEGER,
    paid_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(recorded_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS consultations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    doctor_staff_id INTEGER NOT NULL,
    symptoms TEXT,
    examination TEXT,
    diagnosis TEXT,
    note TEXT,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(doctor_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS prescriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    doctor_staff_id INTEGER NOT NULL,
    medication TEXT NOT NULL,
    dosage TEXT NOT NULL,
    frequency TEXT NOT NULL,
    instructions TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(doctor_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS dispensations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    prescription_id INTEGER NOT NULL,
    pharmacy_staff_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    note TEXT,
    dispensed_at TEXT NOT NULL,
    FOREIGN KEY(prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE,
    FOREIGN KEY(pharmacy_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS pharmacy_bills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    pharmacist_staff_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    created_at TEXT NOT NULL,
    paid_at TEXT,
    paid_by_staff_id INTEGER,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(pharmacist_staff_id) REFERENCES staff(id) ON DELETE SET NULL,
    FOREIGN KEY(paid_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS lab_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    consultation_id INTEGER NOT NULL,
    test_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending Payment',
    bill REAL NOT NULL,
    created_at TEXT NOT NULL,
    paid_at TEXT,
    FOREIGN KEY(consultation_id) REFERENCES consultations(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS lab_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lab_request_id INTEGER NOT NULL,
    result TEXT NOT NULL,
    comments TEXT,
    uploaded_at TEXT NOT NULL,
    FOREIGN KEY(lab_request_id) REFERENCES lab_requests(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS medication_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    prescription_id INTEGER,
    pharmacy_staff_id INTEGER,
    quantity INTEGER,
    note TEXT,
    dispensed_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(prescription_id) REFERENCES prescriptions(id) ON DELETE SET NULL,
    FOREIGN KEY(pharmacy_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    department TEXT NOT NULL,
    allocated REAL NOT NULL DEFAULT 0,
    spent REAL NOT NULL DEFAULT 0,
    fiscal_year TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
SQL;

        self::$pdo->exec($sql);
        self::ensureStaffRoleConstraint();
        self::repairStaffOldReferences();
        self::repairConsultationsOldReferences();
        self::seedDefaultAdmin();
    }

    private static function repairConsultationsOldReferences(): void
    {
        $stmt = self::$pdo->query("SELECT name, sql FROM sqlite_master WHERE type='table'");
        $rows = $stmt->fetchAll();

        foreach ($rows as $row) {
            if (strpos($row['sql'] ?? '', 'consultations_old') !== false) {
                // rebuild the table to refresh foreign keys to the current consultations table
                self::rebuildTableSchema($row['name']);
            }
        }
    }

    private static function ensureStaffRoleConstraint(): void
    {
        $stmt = self::$pdo->prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='staff'");
        $stmt->execute();
        $row = $stmt->fetch();
        $stmt = null;

        if (!$row) {
            return;
        }

        if (strpos($row['sql'], "CHECK(role IN ('admin', 'doctor', 'receptionist', 'billing', 'pharmacy', 'lab'))") !== false) {
            return;
        }

        self::rebuildStaffTable();
    }

    private static function repairStaffOldReferences(): void
    {
        $affectedTables = ['patients', 'queue_entries', 'vitals', 'payments', 'consultations', 'prescriptions', 'dispensations', 'pharmacy_bills', 'medication_history'];

        foreach ($affectedTables as $table) {
            $stmt = self::$pdo->prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name = :table");
            $stmt->execute([':table' => $table]);
            $row = $stmt->fetch();
            $stmt = null;

            if ($row && strpos($row['sql'], 'staff_old') !== false) {
                self::rebuildTableSchema($table);
            }
        }
    }

    private static function rebuildTableSchema(string $table): void
    {
        $tableSql = self::getTableSql($table);
        if ($tableSql === '') {
            return;
        }

        self::$pdo->exec('PRAGMA foreign_keys = OFF');
        self::$pdo->beginTransaction();
        self::$pdo->exec('ALTER TABLE ' . $table . ' RENAME TO ' . $table . '_old');
        self::$pdo->exec($tableSql);
        self::$pdo->exec('INSERT INTO ' . $table . ' SELECT * FROM ' . $table . '_old');
        self::$pdo->exec('DROP TABLE ' . $table . '_old');
        self::$pdo->commit();
        self::$pdo->exec('PRAGMA foreign_keys = ON');
    }

    private static function getTableSql(string $table): string
    {
        return match ($table) {
            'patients' => <<<'SQL'
CREATE TABLE patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id TEXT UNIQUE,
    full_name TEXT NOT NULL,
    gender TEXT,
    date_of_birth TEXT,
    phone TEXT,
    email TEXT,
    address TEXT,
    emergency_contact TEXT,
    status TEXT NOT NULL DEFAULT 'Registered',
    registered_by_staff_id INTEGER,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(registered_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);
SQL,
            'queue_entries' => <<<'SQL'
CREATE TABLE queue_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    queued_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Waiting for Consultation',
    accepted_at TEXT,
    accepted_by_staff_id INTEGER,
    delayed_at TEXT,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(accepted_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);
SQL,
            'vitals' => <<<'SQL'
CREATE TABLE vitals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    weight REAL,
    height REAL,
    temperature REAL,
    blood_pressure TEXT,
    pulse_rate INTEGER,
    recorded_by_staff_id INTEGER,
    recorded_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(recorded_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);
SQL,
            'payments' => <<<'SQL'
CREATE TABLE payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    amount REAL NOT NULL,
    receipt_number TEXT UNIQUE,
    recorded_by_staff_id INTEGER,
    paid_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(recorded_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);
SQL,
            'consultations' => <<<'SQL'
CREATE TABLE consultations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    doctor_staff_id INTEGER NOT NULL,
    symptoms TEXT,
    examination TEXT,
    diagnosis TEXT,
    note TEXT,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(doctor_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);
SQL,
            'prescriptions' => <<<'SQL'
CREATE TABLE prescriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    doctor_staff_id INTEGER NOT NULL,
    medication TEXT NOT NULL,
    dosage TEXT NOT NULL,
    frequency TEXT NOT NULL,
    instructions TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(doctor_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);
SQL,
            'dispensations' => <<<'SQL'
CREATE TABLE dispensations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    prescription_id INTEGER NOT NULL,
    pharmacy_staff_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    note TEXT,
    dispensed_at TEXT NOT NULL,
    FOREIGN KEY(prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE,
    FOREIGN KEY(pharmacy_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);
SQL,
            'pharmacy_bills' => <<<'SQL'
CREATE TABLE pharmacy_bills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    pharmacist_staff_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    created_at TEXT NOT NULL,
    paid_at TEXT,
    paid_by_staff_id INTEGER,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(pharmacist_staff_id) REFERENCES staff(id) ON DELETE SET NULL,
    FOREIGN KEY(paid_by_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);
SQL,
            'lab_requests' => <<<'SQL'
CREATE TABLE lab_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    consultation_id INTEGER NOT NULL,
    test_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending Payment',
    bill REAL NOT NULL,
    created_at TEXT NOT NULL,
    paid_at TEXT,
    FOREIGN KEY(consultation_id) REFERENCES consultations(id) ON DELETE CASCADE
);
SQL,
            'medication_history' => <<<'SQL'
CREATE TABLE medication_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    prescription_id INTEGER,
    pharmacy_staff_id INTEGER,
    quantity INTEGER,
    note TEXT,
    dispensed_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY(prescription_id) REFERENCES prescriptions(id) ON DELETE SET NULL,
    FOREIGN KEY(pharmacy_staff_id) REFERENCES staff(id) ON DELETE SET NULL
);
SQL,
            default => '',
        };
    }

    private static function rebuildStaffTable(): void
    {
        self::$pdo->exec('PRAGMA foreign_keys = OFF');
        self::$pdo->beginTransaction();

        self::$pdo->exec('ALTER TABLE staff RENAME TO staff_old');
        $create = <<<'SQL'
CREATE TABLE staff (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin', 'doctor', 'receptionist', 'billing', 'pharmacy', 'lab')),
    is_active INTEGER DEFAULT 1,
    last_login TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
SQL;
        self::$pdo->exec($create);
        self::$pdo->exec('INSERT INTO staff (id, username, email, password_hash, full_name, role, is_active, last_login, created_at, updated_at)
            SELECT id, username, email, password_hash, full_name, role, is_active, last_login, created_at, updated_at FROM staff_old');
        self::$pdo->exec('DROP TABLE staff_old');

        self::$pdo->commit();
        self::$pdo->exec('PRAGMA foreign_keys = ON');
    }

    private static function seedDefaultAdmin(): void
    {
        try {
            $stmt = self::$pdo->prepare('SELECT COUNT(*) as cnt FROM staff WHERE role = ?');
            $stmt->execute(['admin']);
            $result = $stmt->fetch();

            if ($result['cnt'] === 0) {
                $hashedPassword = password_hash('admin123', PASSWORD_BCRYPT);
                $now = date('c');
                $stmt = self::$pdo->prepare(
                    'INSERT INTO staff (username, email, password_hash, full_name, role, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?)'
                );
                $stmt->execute(['admin', 'admin@dsms.local', $hashedPassword, 'Administrator', 'admin', $now, $now]);
            }
        } catch (\Exception $e) {
            // Silently fail on duplicate
        }
    }
}
