<?php

session_start();

require_once __DIR__ . '/../src/Database.php';
require_once __DIR__ . '/../src/Models/Staff.php';
require_once __DIR__ . '/../src/Models/Patient.php';
require_once __DIR__ . '/../src/Models/QueueManager.php';
require_once __DIR__ . '/../src/Models/Vital.php';
require_once __DIR__ . '/../src/Models/Consultation.php';
require_once __DIR__ . '/../src/Models/Payment.php';
require_once __DIR__ . '/../src/Models/Prescription.php';
require_once __DIR__ . '/../src/Models/Dispensation.php';
require_once __DIR__ . '/../src/Models/PharmacyBill.php';
require_once __DIR__ . '/../src/Models/LabRequest.php';
require_once __DIR__ . '/../src/Models/LabResult.php';
require_once __DIR__ . '/../src/Models/MedicationHistory.php';
require_once __DIR__ . '/../src/Models/Budget.php';

// Initialize database
Database::getConnection();

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function getCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
    }

    return $_SESSION['csrf_token'];
}

function validateCsrfToken(string $token): bool
{
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function setFlash(string $message, string $type = 'success'): void
{
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
}

function getFlash(): array
{
    $message = $_SESSION['flash_message'] ?? '';
    $type = $_SESSION['flash_type'] ?? 'success';
    unset($_SESSION['flash_message'], $_SESSION['flash_type']);

    return ['message' => $message, 'type' => $type];
}

function isLoggedIn(): bool
{
    return isset($_SESSION['staff_id']) && isset($_SESSION['staff_role']);
}

function getCurrentStaff(): ?array
{
    if (!isLoggedIn()) {
        return null;
    }

    return Staff::find((int)$_SESSION['staff_id']);
}

function requireLogin(): void
{
    if (!isLoggedIn()) {
        header('Location: ?action=login');
        exit;
    }
}

function requireRole(string $role): void
{
    requireLogin();
    if ($_SESSION['staff_role'] !== $role) {
        http_response_code(403);
        echo 'Unauthorized access';
        exit;
    }
}

// Handle login
if (isset($_GET['action']) && $_GET['action'] === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $staff = Staff::authenticate($username, $password);

        if ($staff) {
            $_SESSION['staff_id'] = $staff['id'];
            $_SESSION['staff_role'] = $staff['role'];
            $_SESSION['staff_name'] = $staff['full_name'];
            setFlash('Welcome, ' . h($staff['full_name']) . '!');
            header('Location: ?action=dashboard');
            exit;
        } else {
            setFlash('Invalid username or password', 'error');
        }
    }
}

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header('Location: ?action=login');
    exit;
}

// Determine current action and role
$action = $_GET['action'] ?? 'dashboard';

if (!isLoggedIn() && $action !== 'login' && $action !== 'landing') {
    $action = 'login';
}

$flash = getFlash();
$currentStaff = getCurrentStaff();

// Login page
if ($action === 'login') {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>DSMS - Hospital Staff Login</title>
        <link rel="stylesheet" href="assets/styles.css">
    </head>

    <body>
        <div class="auth-container">
            <div class="login-card">
                <h1>DSMS</h1>
                <p>Hospital & Dispensary Management System</p>

                <?php if ($flash['message']) {
                    echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
                } ?>

                <form method="post" action="?action=login">
                    <div class="form-group">
                        <label>Staff Username</label>
                        <input type="text" name="username" required autofocus>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>

                <p style="text-align: center; margin-top: 20px; color: var(--text-muted); font-size: 0.9rem;">
                    Demo: username <code>admin</code> | password <code>admin123</code>
                </p>
                <p style="text-align: center; margin-top: 12px; font-size: 0.9rem;">
                    <a href="landing.php">Explore system landing page</a>
                </p>
            </div>
        </div>
        <script src="assets/app.js"></script>
    </body>

    </html>
    <?php
    exit;
}

if ($action === 'landing') {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>DSMS - Landing Page</title>
        <link rel="stylesheet" href="assets/styles.css">
    </head>

    <body>
        <div class="landing-page">
            <section class="landing-hero">
                <div class="landing-copy">
                    <span class="label">Hospital & Dispensary Experience</span>
                    <h1>Welcome to DSMS — where patient care and staff coordination meet in harmony.</h1>
                    <p>Explore a clean, professional workflow designed for administrators, doctors, and reception teams. Manage staff, queue patients, and keep treatment moving.</p>
                    <div class="hero-actions">
                        <a href="?action=login" class="btn btn-primary">Staff Login</a>
                        <a href="?action=login" class="btn btn-secondary">View Control Panel</a>
                    </div>
                </div>
                <div class="landing-panel">
                    <div class="panel-card panel-highlight">
                        <h3>Admin Management</h3>
                        <p>Create, edit and remove staff accounts with secure role access and audit-ready operations.</p>
                    </div>
                    <div class="panel-card">
                        <h3>Patient Reception</h3>
                        <p>Register patients, manage the consultation queue, and track arrival details in a single dashboard.</p>
                    </div>
                    <div class="panel-card">
                        <h3>Doctor Workflow</h3>
                        <p>Review patients, record vitals, and save consultation notes as part of a modern clinical workflow.</p>
                    </div>
                </div>
            </section>
        </div>
    </body>

    </html>
    <?php
    exit;
}

// All other pages require login
requireLogin();

// Handle role-specific actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!validateCsrfToken($csrfToken)) {
        setFlash('Invalid request. Please try again.', 'error');
        header('Location: ?action=' . urlencode($_SESSION['staff_role'] . '_dashboard'));
        exit;
    }

    // RECEPTIONIST actions
    if ($_SESSION['staff_role'] === 'receptionist' && $action === 'register_patient') {
        $patientId = Patient::create([
            'full_name' => trim($_POST['full_name'] ?? ''),
            'gender' => trim($_POST['gender'] ?? ''),
            'date_of_birth' => trim($_POST['date_of_birth'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
            'emergency_contact' => trim($_POST['emergency_contact'] ?? ''),
        ]);
        $patient = Patient::find($patientId);
        setFlash('Patient registered successfully. ID: ' . h($patient['patient_id']));
        header('Location: ?action=receptionist_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'receptionist' && $action === 'add_to_queue') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        if ($patientId > 0) {
            QueueManager::addToQueue($patientId);
            Patient::updateStatus($patientId, 'Waiting for Consultation');
            setFlash('Patient added to consultation queue.');
        }
        header('Location: ?action=receptionist_dashboard');
        exit;
    }

    // DOCTOR actions
    if ($_SESSION['staff_role'] === 'doctor' && $action === 'accept_patient') {
        $queueId = (int)($_POST['queue_id'] ?? 0);
        if ($queueId > 0) {
            $queue = $GLOBALS['db_queue'] ?? null;
            setFlash('Patient consultation started.');
        }
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'receptionist' && $action === 'record_vitals') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        if ($patientId > 0) {
            Vital::record($patientId, [
                'weight' => (float)($_POST['weight'] ?? 0),
                'height' => (float)($_POST['height'] ?? 0),
                'temperature' => (float)($_POST['temperature'] ?? 0),
                'blood_pressure' => trim($_POST['blood_pressure'] ?? ''),
                'pulse_rate' => (int)($_POST['pulse_rate'] ?? 0),
            ]);
            setFlash('Vitals recorded successfully.');
        }
        header('Location: ?action=receptionist_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'doctor' && $action === 'save_consultation') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        $outcome = trim($_POST['outcome'] ?? 'Healthy');
        if ($patientId > 0) {
            $consultationId = Consultation::create(
                $patientId,
                (int)$_SESSION['staff_id'],
                trim($_POST['symptoms'] ?? ''),
                trim($_POST['examination'] ?? ''),
                trim($_POST['diagnosis'] ?? ''),
                $outcome,
                trim($_POST['note'] ?? '') ?: null
            );

            if ($outcome === 'Lab Investigation Required') {
                $testType = trim($_POST['lab_test_type'] ?? '');
                $bill = (float)($_POST['lab_bill'] ?? 0);

                if ($testType && $bill > 0) {
                    LabRequest::create($consultationId, $testType, $bill);
                    setFlash('Consultation saved and lab request created.');
                } else {
                    setFlash('Consultation saved. Please create a lab request with a test type and bill amount if required.');
                }
            } else {
                setFlash('Consultation saved.');
            }
        }
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'doctor' && $action === 'create_prescription') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        $queueId = (int)($_POST['queue_id'] ?? 0);
        if ($patientId > 0) {
            $medications = $_POST['medication'] ?? [];
            $dosages = $_POST['dosage'] ?? [];
            $frequencies = $_POST['frequency'] ?? [];
            $instructions = $_POST['instructions'] ?? [];

            if (!is_array($medications)) {
                $medications = [$medications];
            }
            if (!is_array($dosages)) {
                $dosages = [$dosages];
            }
            if (!is_array($frequencies)) {
                $frequencies = [$frequencies];
            }
            if (!is_array($instructions)) {
                $instructions = [$instructions];
            }
            $createdCount = 0;

            foreach ($medications as $index => $medication) {
                $medication = trim($medication);
                $dosage = trim($dosages[$index] ?? '');
                $frequency = trim($frequencies[$index] ?? '');
                $instruction = trim($instructions[$index] ?? '');

                if ($medication && $dosage && $frequency) {
                    Prescription::create(
                        $patientId,
                        (int)$_SESSION['staff_id'],
                        $medication,
                        $dosage,
                        $frequency,
                        $instruction ?: null
                    );
                    $createdCount++;
                }
            }

            if ($createdCount > 0) {
                Patient::updateStatus($patientId, 'Prescription Uploaded');
                setFlash('Prescription uploaded successfully to pharmacy.');
            } else {
                setFlash('Please enter at least one medicine, dosage, and frequency.', 'error');
            }
        }
        
        // Redirect based on where the prescription was created from
        if ($queueId > 0) {
            header('Location: ?action=doctor_consult&queue_id=' . urlencode($queueId));
        } else {
            header('Location: ?action=doctor_dashboard');
        }
        exit;
    }

    // ADMIN actions
    if ($_SESSION['staff_role'] === 'admin' && $action === 'create_staff') {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $fullName = trim($_POST['full_name'] ?? '');
        $role = trim($_POST['role'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username && $email && $fullName && $role && $password) {
            try {
                Staff::create($username, $email, $fullName, $role, $password);
                setFlash('Staff account created successfully.');
            } catch (\Exception $e) {
                setFlash('Error creating staff: ' . $e->getMessage(), 'error');
            }
        }
        header('Location: ?action=admin_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'save_budget') {
        $department = trim($_POST['department'] ?? '');
        $allocated = (float)($_POST['allocated'] ?? 0);
        $fiscalYear = trim($_POST['fiscal_year'] ?? '');

        if ($department && $allocated > 0) {
            try {
                Budget::create($department, $allocated, $fiscalYear ?: null);
                setFlash('Budget created successfully.');
            } catch (\Exception $e) {
                setFlash('Error creating budget: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please provide a department name and valid allocated amount.', 'error');
        }

        header('Location: ?action=budget_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'billing' && $action === 'record_payment') {
        $queueId = (int)($_POST['queue_id'] ?? 0);
        $amount = (float)($_POST['amount'] ?? 0);

        if ($queueId > 0 && $amount > 0) {
            try {
                Payment::recordConsultation($queueId, $amount, (int)$_SESSION['staff_id']);
                setFlash('Consultation payment recorded successfully.');
            } catch (\Exception $e) {
                setFlash('Error recording payment: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please select a valid accepted consultation and enter a payment amount.', 'error');
        }

        header('Location: ?action=billing_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'billing' && $action === 'record_medicine_payment') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        $queueId = (int)($_POST['queue_id'] ?? 0);
        $amount = (float)($_POST['amount'] ?? 0);

        if ($patientId > 0 && $amount > 0) {
            try {
                // Record payment for medicine
                Payment::recordMedicinePayment($patientId, $amount, (int)$_SESSION['staff_id']);
                
                // Update patient status to "Paid for Medicine" so they can go to pharmacy
                Patient::updateStatus($patientId, 'Paid for Medicine');
                
                setFlash('Medicine payment recorded successfully. Patient can now go to the pharmacy.');
            } catch (\Exception $e) {
                setFlash('Error recording medicine payment: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please select a valid patient and enter a payment amount.', 'error');
        }

        header('Location: ?action=billing_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'billing' && $action === 'record_pharmacy_bill_payment') {
        $billId = (int)($_POST['bill_id'] ?? 0);
        $paidByStaffId = (int)$_SESSION['staff_id'];

        if ($billId > 0) {
            try {
                PharmacyBill::markPaid($billId, $paidByStaffId);
                setFlash('Pharmacy bill payment recorded successfully.');
            } catch (\Exception $e) {
                setFlash('Error recording pharmacy bill payment: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please select a valid pharmacy bill to pay.', 'error');
        }

        header('Location: ?action=billing_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'pharmacy' && $action === 'create_pharmacy_bill') {
        $patientId = (int)($_GET['patient_id'] ?? 0);
        $patient = Patient::find($patientId);
        if (!$patient || $patient['status'] !== 'Prescription Uploaded') {
            setFlash('Selected patient is not ready for pharmacy billing.', 'error');
            header('Location: ?action=pharmacy_dashboard');
            exit;
        }

        $pendingPrescriptions = Prescription::getPendingForPatient($patientId);
        renderHeader('Create Pharmacy Bill', 'pharmacy');
        echo '<div class="page-title"><h2>Create Pharmacy Bill</h2><p>Enter pharmacy charges for the patient before dispensing.</p></div>';
        echo '<div class="card" style="max-width: 680px;">';
        echo '<form method="post" action="?action=save_pharmacy_bill">';
        echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
        echo '<input type="hidden" name="patient_id" value="' . h($patientId) . '">';
        echo '<p><strong>Patient:</strong> ' . h($patient['patient_id'] . ' - ' . $patient['full_name']) . '</p>';
        echo '<div style="margin-bottom: 16px; padding: 12px; background-color: #f0f8ff; border-radius: 4px;">';
        foreach ($pendingPrescriptions as $rx) {
            echo '<p><strong>' . h($rx['medication']) . '</strong> - ' . h($rx['dosage']) . ' (' . h($rx['frequency']) . ')</p>';
        }
        echo '</div>';
        echo '<div class="form-row">';
        echo '<label>Bill Amount<br><input type="number" step="0.01" name="amount" required></label>';
        echo '</div>';
        echo '<button type="submit" class="btn btn-primary">Create Pharmacy Bill</button>';
        echo '<a href="?action=pharmacy_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>';
        echo '</form>';
        echo '</div>';
        renderFooter();
        exit;
    }

    if ($_SESSION['staff_role'] === 'pharmacy' && $action === 'save_pharmacy_bill') {
        $patientId = (int)($_POST['patient_id'] ?? 0);
        $amount = (float)($_POST['amount'] ?? 0);
        if ($patientId > 0 && $amount > 0) {
            try {
                PharmacyBill::create($patientId, (int)$_SESSION['staff_id'], $amount);
                setFlash('Pharmacy bill created successfully. Send it to billing for payment collection.');
            } catch (\Exception $e) {
                setFlash('Error creating pharmacy bill: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please select a valid patient and enter a bill amount.', 'error');
        }
        header('Location: ?action=pharmacy_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'billing' && $action === 'collect_pharmacy_bill_payment') {
        $billId = (int)($_GET['bill_id'] ?? 0);
        $bill = PharmacyBill::find($billId);
        if (!$bill || $bill['paid_at'] !== null) {
            setFlash('Selected pharmacy bill is not available for payment.', 'error');
            header('Location: ?action=billing_dashboard');
            exit;
        }

        renderHeader('Collect Pharmacy Bill Payment', 'billing');
        echo '<div class="page-title"><h2>Collect Pharmacy Bill Payment</h2><p>Record payment for the selected pharmacy bill before dispensing.</p></div>';
        echo '<div class="card" style="max-width: 680px;">';
        echo '<form method="post" action="?action=record_pharmacy_bill_payment">';
        echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
        echo '<input type="hidden" name="bill_id" value="' . h($bill['id']) . '">';
        echo '<p><strong>Patient:</strong> ' . h($bill['patient_code'] . ' - ' . $bill['full_name']) . '</p>';
        echo '<p><strong>Amount Due:</strong> ' . h(number_format((float)$bill['amount'], 2)) . '</p>';
        echo '<div class="form-row">';
        echo '<label>Payment Amount<br><input type="number" step="0.01" name="amount" value="' . h(number_format((float)$bill['amount'], 2)) . '" required></label>';
        echo '</div>';
        echo '<button type="submit" class="btn btn-primary">Record Payment</button>';
        echo '<a href="?action=billing_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>';
        echo '</form>';
        echo '</div>';
        renderFooter();
        exit;
    }

    if ($_SESSION['staff_role'] === 'lab' && $action === 'record_lab_payment') {
        $labRequestId = (int)($_POST['lab_request_id'] ?? 0);
        $amount = (float)($_POST['amount'] ?? 0);

        if ($labRequestId > 0 && $amount > 0) {
            try {
                Payment::recordLabPayment($labRequestId, $amount, (int)$_SESSION['staff_id']);
                setFlash('Lab payment recorded successfully.');
            } catch (\Exception $e) {
                setFlash('Error recording lab payment: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please select a valid lab request and enter a payment amount.', 'error');
        }

        header('Location: ?action=lab_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'lab' && $action === 'upload_lab_result') {
        $labRequestId = (int)($_POST['lab_request_id'] ?? 0);
        $result = trim($_POST['result'] ?? '');
        $comments = trim($_POST['comments'] ?? '');

        if ($labRequestId > 0 && $result) {
            try {
                LabResult::upload($labRequestId, $result, $comments ?: null);
                setFlash('Lab result uploaded successfully.');
            } catch (\Exception $e) {
                setFlash('Error uploading result: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please provide a valid lab request and result details.', 'error');
        }

        header('Location: ?action=lab_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'pharmacy' && $action === 'record_dispense') {
        $prescriptionId = (int)($_POST['prescription_id'] ?? 0);
        $quantity = (int)($_POST['quantity'] ?? 0);
        $note = trim($_POST['note'] ?? '');

        if ($prescriptionId > 0 && $quantity > 0) {
            try {
                Dispensation::record($prescriptionId, (int)$_SESSION['staff_id'], $quantity, $note ?: null);
                
                // Get patient ID and check if all prescriptions have been dispensed
                $pdo = Database::getConnection();
                $stmt = $pdo->prepare('SELECT patient_id FROM prescriptions WHERE id = :id');
                $stmt->execute([':id' => $prescriptionId]);
                $rx = $stmt->fetch();
                
                if ($rx) {
                    $patientId = (int)$rx['patient_id'];
                    
                    // Check if all prescriptions for this patient have been dispensed
                    $stmt = $pdo->prepare('
                        SELECT COUNT(*) as pending
                        FROM prescriptions p
                        LEFT JOIN dispensations d ON p.id = d.prescription_id
                        WHERE p.patient_id = :patient_id AND d.id IS NULL
                    ');
                    $stmt->execute([':patient_id' => $patientId]);
                    $pending = $stmt->fetch();
                    
                    // If no pending prescriptions remain, update patient status to "Completed"
                    if (!$pending || (int)$pending['pending'] === 0) {
                        Patient::updateStatus($patientId, 'Completed');
                    }
                }
                
                setFlash('Medication dispensed and recorded.');
            } catch (\Exception $e) {
                setFlash('Error dispensing medication: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Please enter a valid prescription and quantity.', 'error');
        }

        header('Location: ?action=pharmacy_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'update_staff') {
        $staffId = (int)($_POST['staff_id'] ?? 0);
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $fullName = trim($_POST['full_name'] ?? '');
        $role = trim($_POST['role'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $isActive = isset($_POST['is_active']) ? true : false;

        if ($staffId > 0 && $username && $email && $fullName && $role) {
            try {
                Staff::update($staffId, $username, $email, $fullName, $role, $isActive, $password !== '' ? $password : null);
                setFlash('Staff record updated successfully.');
            } catch (\Exception $e) {
                setFlash('Error updating staff: ' . $e->getMessage(), 'error');
            }
        }
        header('Location: ?action=admin_dashboard');
        exit;
    }

    if ($_SESSION['staff_role'] === 'admin' && $action === 'delete_staff') {
        $staffId = (int)($_POST['staff_id'] ?? 0);

        if ($staffId > 0 && $staffId !== (int)$_SESSION['staff_id']) {
            try {
                Staff::delete($staffId);
                setFlash('Staff account removed successfully.');
            } catch (\Exception $e) {
                setFlash('Unable to remove staff account: ' . $e->getMessage(), 'error');
            }
        } else {
            setFlash('Cannot delete the active admin account.', 'error');
        }

        header('Location: ?action=admin_dashboard');
        exit;
    }
}

// Determine dashboard to show based on role
if ($action === 'dashboard') {
    $role = $_SESSION['staff_role'] ?? null;
    $action = $role ? $role . '_dashboard' : 'login';
}

// Include header for all pages
function renderHeader(string $title, string $role): void
{
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo h($title); ?> - DSMS</title>
        <link rel="stylesheet" href="assets/styles.css">
    </head>

    <body>
        <header class="header">
            <div class="container">
                <div class="header-top">
                    <div class="header-title">
                        <h1>DSMS</h1>
                        <p><?php echo h($title); ?></p>
                    </div>
                    <div class="header-user">
                        <div class="user-badge">
                            <strong><?php echo h($_SESSION['staff_name'] ?? 'Staff'); ?></strong><br>
                            <small><?php echo h($role); ?></small>
                        </div>

                        <a href="?action=logout" class="logout-btn">Logout</a>
                    </div>
                </div>
                <?php if (isset($_SESSION['staff_role']) && $_SESSION['staff_role'] === 'admin'): ?>
                    <div class="header-nav">
                        <a href="?action=admin_dashboard">Admin Home</a>
                        <a href="?action=moic_dashboard">MOIC Dashboard</a>
                        <a href="?action=budget_dashboard">Budgets</a>
                    </div>
                <?php endif; ?>
            </div>
        </header>

        <div class="container">
            <div class="dashboard">
    <?php
}

function renderFooter(): void
{
    ?>
            </div>
        </div>
        <script src="assets/app.js"></script>
    </body>

    </html>
    <?php
}

// RECEPTIONIST DASHBOARD
if ($action === 'receptionist_dashboard') {
    renderHeader('Reception - Patient Registration', 'receptionist');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $patients = Patient::all();
    $waitingQueue = QueueManager::getActive();

    echo '<div class="page-title"><h2>Reception Desk</h2><p>Register new patients, manage the queue, and record patient vitals.</p></div>';

    echo '<div class="grid grid-2">';

    // New Patient Registration
    echo '<div class="card"><h3>Register New Patient</h3>
    <form method="post" action="?action=register_patient">
        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
        <div class="form-row">
            <label>Full Name<br><input name="full_name" required></label>
            <label>Gender<br><select name="gender"><option>Male</option><option>Female</option><option>Other</option></select></label>
        </div>
        <div class="form-row">
            <label>Date of Birth<br><input type="date" name="date_of_birth" required></label>
            <label>Phone<br><input name="phone" type="tel"></label>
        </div>
        <div class="form-row full">
            <label>Email<br><input type="email" name="email"></label>
        </div>
        <div class="form-row full">
            <label>Address<br><textarea name="address" rows="3"></textarea></label>
        </div>
        <div class="form-row full">
            <label>Emergency Contact<br><input name="emergency_contact"></label>
        </div>
        <button type="submit" class="btn btn-primary">Register Patient</button>
    </form>
    </div>';

    // Record Vitals
    echo '<div class="card"><h3>Record Patient Vitals</h3>';
    if (empty($patients)) {
        echo '<p>No registered patients available.</p>';
    } else {
        echo '<form method="post" action="?action=record_vitals">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <label>Select Patient<br><select name="patient_id">';
        foreach ($patients as $p) {
            echo '<option value="' . h($p['id']) . '">' . h($p['patient_id'] . ' - ' . $p['full_name']) . '</option>';
        }
        echo '</select></label>
            <div class="form-row">
                <label>Weight (kg)<br><input type="number" step="0.1" name="weight" required></label>
                <label>Height (cm)<br><input type="number" step="0.1" name="height" required></label>
            </div>
            <div class="form-row">
                <label>Temperature (°C)<br><input type="number" step="0.1" name="temperature" required></label>
                <label>Pulse Rate<br><input type="number" name="pulse_rate" required></label>
            </div>
            <div class="form-row full">
                <label>Blood Pressure<br><input name="blood_pressure" required></label>
            </div>
            <button type="submit" class="btn btn-primary">Save Vitals</button>
        </form>';
    }
    echo '</div>';

    // Add to Queue
    echo '<div class="card"><h3>Add to Consultation Queue</h3>';
    if (empty($patients)) {
        echo '<p>No registered patients yet.</p>';
    } else {
        echo '<form method="post" action="?action=add_to_queue">
        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
        <label>Select Patient<br><select name="patient_id">';
        foreach ($patients as $p) {
            echo '<option value="' . h($p['id']) . '">' . h($p['patient_id'] . ' - ' . $p['full_name']) . '</option>';
        }
        echo '</select></label>
        <button type="submit" class="btn btn-primary" style="margin-top: 12px;">Add to Queue</button>
    </form>';
    }
    echo '</div>';

    echo '</div>';

    // Waiting Queue Table
    echo '<div class="card" style="margin-top: 24px;"><h3>Current Consultation Queue (' . count($waitingQueue) . ')</h3>';
    if (empty($waitingQueue)) {
        echo '<div class="no-data"><p>No patients in the queue.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
        <thead><tr><th>Patient ID</th><th>Name</th><th>Queued At</th><th>Status</th></tr></thead>
        <tbody>';
        foreach ($waitingQueue as $entry) {
            $statusLabel = $entry['status'] === 'Accepted' ? 'Accepted' : 'Waiting';
            $statusClass = $entry['status'] === 'Accepted' ? 'status-accepted' : 'status-waiting';
            echo '<tr>
            <td>' . h($entry['patient_code']) . '</td>
            <td>' . h($entry['full_name']) . '</td>
            <td>' . h(date('M d, H:i', strtotime($entry['queued_at']))) . '</td>
            <td><span class="status-badge ' . $statusClass . '">' . h($statusLabel) . '</span></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

// DOCTOR DASHBOARD
if ($action === 'doctor_dashboard') {
    renderHeader('Doctor - Consultations', 'doctor');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $waitingQueue = QueueManager::getWaiting();
    $readyQueue = QueueManager::getPaid();
    
    // Get patients with lab results ready
    $pdo = Database::getConnection();
    $stmt = $pdo->query('
        SELECT DISTINCT p.id, p.patient_id, p.full_name, q.id as queue_id, q.queued_at, q.status
        FROM patients p
        JOIN queue_entries q ON p.id = q.patient_id
        WHERE p.status = "Results Ready"
        ORDER BY q.queued_at DESC
    ');
    $resultsReadyQueue = $stmt->fetchAll() ?: [];

    echo '<div class="page-title"><h2>Consultation Management</h2><p>Review patients waiting for billing, lab results, and start consultation.</p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3>📋 Waiting for Billing</h3><div class="card-stat"><div class="card-stat-text"><h4>Pending</h4><p>' . count($waitingQueue) . '</p></div></div></div>';
    echo '<div class="card"><h3>🔬 Lab Results Ready</h3><div class="card-stat"><div class="card-stat-text"><h4>Ready</h4><p>' . count($resultsReadyQueue) . '</p></div></div></div>';
    echo '<div class="card"><h3>🟢 Ready for Consultation</h3><div class="card-stat"><div class="card-stat-text"><h4>Paid</h4><p>' . count($readyQueue) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Patients with Lab Results Ready - Review & Prescribe</h3>';
    if (empty($resultsReadyQueue)) {
        echo '<div class="no-data"><p>No patients have lab results ready for review.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
        <thead><tr><th>Patient ID</th><th>Name</th><th>Results At</th><th>Action</th></tr></thead>
        <tbody>';
        foreach ($resultsReadyQueue as $entry) {
            echo '<tr>
            <td><strong>' . h($entry['patient_id']) . '</strong></td>
            <td>' . h($entry['full_name']) . '</td>
            <td>' . h(date('M d, H:i', strtotime($entry['queued_at']))) . '</td>
            <td><a href="?action=doctor_review_lab&queue_id=' . h($entry['queue_id']) . '" class="btn btn-info btn-small">Review & Prescribe</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Patients Accepted for Billing</h3>';
    if (empty($waitingQueue)) {
        echo '<div class="no-data"><p>No patients have been accepted yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
        <thead><tr><th>Patient ID</th><th>Name</th><th>Queued At</th><th>Action</th></tr></thead>
        <tbody>';
        foreach ($waitingQueue as $entry) {
            echo '<tr>
            <td><strong>' . h($entry['patient_code']) . '</strong></td>
            <td>' . h($entry['full_name']) . '</td>
            <td>' . h(date('M d, H:i', strtotime($entry['queued_at']))) . '</td>
            <td><a href="?action=accept_for_billing&queue_id=' . h($entry['queue_id']) . '" class="btn btn-secondary btn-small">Accept for Billing</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Patients Ready for Consultation</h3>';
    if (empty($readyQueue)) {
        echo '<div class="no-data"><p>No patients have completed payment yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
        <thead><tr><th>Patient ID</th><th>Name</th><th>Paid At</th><th>Action</th></tr></thead>
        <tbody>';
        foreach ($readyQueue as $entry) {
            echo '<tr>
            <td><strong>' . h($entry['patient_code']) . '</strong></td>
            <td>' . h($entry['full_name']) . '</td>
            <td>' . h(date('M d, H:i', strtotime($entry['accepted_at'] ?? $entry['queued_at']))) . '</td>
            <td><a href="?action=doctor_consult&queue_id=' . h($entry['queue_id']) . '" class="btn btn-primary btn-small">Start Consultation</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'accept_for_billing') {
    requireRole('doctor');

    $queueId = (int)($_GET['queue_id'] ?? 0);
    if ($queueId <= 0) {
        setFlash('Please select a patient from the queue.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    $queueEntry = QueueManager::find($queueId);
    if (!$queueEntry || $queueEntry['status'] !== 'Waiting for Consultation') {
        setFlash('Selected patient cannot be accepted for billing.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    QueueManager::accept($queueId, (int)$_SESSION['staff_id']);
    setFlash('Patient accepted for billing. Please process payment before consultation.');
    header('Location: ?action=doctor_dashboard');
    exit;
}

// DOCTOR REVIEW LAB RESULTS & PRESCRIBE
if ($action === 'doctor_review_lab') {
    requireRole('doctor');

    $queueId = (int)($_GET['queue_id'] ?? 0);
    if ($queueId <= 0) {
        setFlash('Please select a patient from the queue.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    $queueEntry = QueueManager::find($queueId);
    if (!$queueEntry) {
        setFlash('Queue entry not found.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    $patient = Patient::find((int)$queueEntry['patient_row_id']);
    if (!$patient) {
        setFlash('Patient record not found.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    renderHeader('Review Lab Results & Prescribe', 'doctor');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Lab Results Review for ' . h($patient['full_name']) . '</h2><p>Review lab investigation results and prescribe medication based on findings.</p></div>';

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3>Patient Details</h3>';
    echo '<p><strong>ID:</strong> ' . h($patient['patient_id']) . '</p>';
    echo '<p><strong>Name:</strong> ' . h($patient['full_name']) . '</p>';
    echo '<p><strong>Gender:</strong> ' . h($patient['gender']) . '</p>';
    echo '<p><strong>Phone:</strong> ' . h($patient['phone']) . '</p>';
    echo '<p><strong>Email:</strong> ' . h($patient['email']) . '</p>';
    echo '<p><strong>Current Status:</strong> <span class="status-badge status-accepted">Results Ready</span></p>';
    echo '</div>';

    // Get lab requests with results
    $labRequests = LabRequest::getForPatient($patient['id']);
    echo '<div class="card"><h3>Lab Investigation Results</h3>';
    if (empty($labRequests)) {
        echo '<div class="no-data"><p>No lab requests found for this patient.</p></div>';
    } else {
        foreach ($labRequests as $request) {
            $labResult = LabResult::findByLabRequestId((int)$request['id']);
            echo '<div style="margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #eee;">';
            echo '<p><strong>Test Type:</strong> ' . h($request['test_type']) . '</p>';
            echo '<p><strong>Status:</strong> ' . h($request['status']) . '</p>';
            echo '<p><strong>Requested:</strong> ' . h(date('M d, H:i', strtotime($request['created_at']))) . '</p>';
            if ($labResult) {
                echo '<p><strong>Result:</strong> <span style="background-color: #f0f8ff; padding: 8px; border-radius: 4px; display: block; margin-top: 8px;">' . h($labResult['result']) . '</span></p>';
                if ($labResult['comments']) {
                    echo '<p><strong>Comments:</strong> ' . h($labResult['comments']) . '</p>';
                }
            } else {
                echo '<p><strong>Result:</strong> <em>Pending</em></p>';
            }
            echo '</div>';
        }
    }
    echo '</div>';

    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Prescribe Medication Based on Lab Findings</h3>';
    echo '<form method="post" action="?action=create_prescription">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<input type="hidden" name="patient_id" value="' . h($patient['id']) . '">';
    echo '<input type="hidden" name="queue_id" value="' . h($queueEntry['queue_id']) . '">';
    echo '<div id="prescription-entries">';
    echo '<div class="prescription-row">';
    echo '<div class="form-row">';
    echo '<label>Medication<br><input name="medication[]" placeholder="e.g., Paracetamol, Ibuprofen" required></label>';
    echo '<label>Dosage<br><input name="dosage[]" placeholder="e.g., 500mg" required></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Frequency<br><input name="frequency[]" placeholder="e.g., 3 times daily" required></label>';
    echo '</div>';
    echo '<div class="form-row full">';
    echo '<label>Instructions<br><textarea name="instructions[]" placeholder="e.g., Take after meals, avoid dairy" rows="4"></textarea></label>';
    echo '</div>';
    echo '<button type="button" class="btn btn-secondary btn-small remove-prescription" style="margin-top: 12px;">Remove</button>';
    echo '</div>';
    echo '</div>';
    echo '<button type="button" class="btn btn-secondary" id="add-prescription">Add Another Medicine</button>';
    echo '<button type="submit" class="btn btn-primary">Create Prescription</button>';
    echo '<a href="?action=doctor_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Back to Dashboard</a>';
    echo '</form>';
    echo '<script>
        document.getElementById("add-prescription").addEventListener("click", function () {
            var container = document.getElementById("prescription-entries");
            var row = container.querySelector(".prescription-row").cloneNode(true);
            row.querySelectorAll("input, textarea").forEach(function (field) {
                field.value = "";
            });
            container.appendChild(row);
        });
        document.getElementById("prescription-entries").addEventListener("click", function (event) {
            if (event.target.matches(".remove-prescription")) {
                var rows = document.querySelectorAll(".prescription-row");
                if (rows.length > 1) {
                    event.target.closest(".prescription-row").remove();
                }
            }
        });
    </script>';
    echo '</div>';

    renderFooter();
    exit;
}

// DOCTOR CONSULTATION PAGE
if ($action === 'doctor_consult') {
    requireRole('doctor');

    $queueId = (int)($_GET['queue_id'] ?? 0);
    if ($queueId <= 0) {
        setFlash('Please select a patient from the queue.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    $queueEntry = QueueManager::find($queueId);
    if (!$queueEntry) {
        setFlash('Queue entry not found.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    if ($queueEntry['status'] === 'Waiting for Consultation' || $queueEntry['status'] === 'Accepted') {
        setFlash('The patient must pay the consultation fee before starting the consultation.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    if ($queueEntry['status'] === 'Paid') {
        QueueManager::startConsultation($queueId);
        $queueEntry['status'] = 'In Consultation';
    }

    $patient = Patient::find((int)$queueEntry['patient_row_id']);
    if (!$patient) {
        setFlash('Patient record not found.');
        header('Location: ?action=doctor_dashboard');
        exit;
    }

    renderHeader('Doctor Consultation', 'doctor');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Consultation for ' . h($patient['full_name']) . '</h2><p>Patient details and vital records are shown below.</p></div>';

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3>Patient Details</h3>';
    echo '<p><strong>ID:</strong> ' . h($patient['patient_id']) . '</p>';
    echo '<p><strong>Name:</strong> ' . h($patient['full_name']) . '</p>';
    echo '<p><strong>Gender:</strong> ' . h($patient['gender']) . '</p>';
    echo '<p><strong>Date of Birth:</strong> ' . h($patient['date_of_birth']) . '</p>';
    echo '<p><strong>Phone:</strong> ' . h($patient['phone']) . '</p>';
    echo '<p><strong>Email:</strong> ' . h($patient['email']) . '</p>';
    echo '<p><strong>Address:</strong> ' . h($patient['address']) . '</p>';
    echo '<p><strong>Emergency Contact:</strong> ' . h($patient['emergency_contact']) . '</p>';
    echo '<p><strong>Queue Status:</strong> <span class="status-badge ' . ($queueEntry['status'] === 'Accepted' ? 'status-accepted' : 'status-waiting') . '">' . h($queueEntry['status']) . '</span></p>';
    echo '<p><strong>Accepted At:</strong> ' . ($queueEntry['accepted_at'] ? h(date('M d, H:i', strtotime($queueEntry['accepted_at']))) : 'Not yet accepted') . '</p>';
    echo '</div>';

    echo '<div class="card"><h3>Reception Vitals</h3>';
    echo '<p>Vitals are recorded only at reception before the doctor begins consultation.</p>';
    echo '<p>If you need to review recent vital measurements, view the patient record from the admin dashboard or add a dedicated view later.</p>';
    echo '</div>';

    echo '<div class="card"><h3>Consultation Notes</h3>';
    echo '<form method="post" action="?action=save_consultation">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<input type="hidden" name="patient_id" value="' . h($patient['id']) . '">';
    echo '<div class="form-row">';
    echo '<label>Symptoms<br><textarea name="symptoms" required></textarea></label>';
    echo '<label>Examination<br><textarea name="examination" required></textarea></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Diagnosis<br><textarea name="diagnosis" required></textarea></label>';
    echo '<label>Outcome<br><select name="outcome">';
    echo '<option value="Healthy">Healthy</option>';
    echo '<option value="Lab Investigation Required">Lab Investigation Required</option>';
    echo '<option value="Medicine Required">Medicine Required</option>';
    echo '</select></label>';
    echo '</div>';
    echo '<div class="form-row full lab-fields">';
    echo '<label>Lab Test Type<br><input name="lab_test_type"></label>';
    echo '<label>Lab Bill<br><input type="number" step="0.01" name="lab_bill"></label>';
    echo '</div>';
    echo '<div class="form-row full">';
    echo '<label>Notes<br><textarea name="note"></textarea></label>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary">Save Consultation</button>';
    echo '</form>';
    echo '</div>';

    echo '<div class="card"><h3>Prescribe Medication</h3>';
    echo '<form method="post" action="?action=create_prescription">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<input type="hidden" name="patient_id" value="' . h($patient['id']) . '">';
    echo '<input type="hidden" name="queue_id" value="' . h($queueEntry['queue_id']) . '">';
    echo '<div class="form-row">';
    echo '<label>Medication<br><input name="medication" required></label>';
    echo '<label>Dosage<br><input name="dosage" required></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Frequency<br><input name="frequency" required></label>';
    echo '</div>';
    echo '<div class="form-row full">';
    echo '<label>Instructions<br><textarea name="instructions"></textarea></label>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary">Create Prescription</button>';
    echo '</form>';
    echo '</div>';

    $labRequests = LabRequest::getForPatient($patient['id']);
    echo '<div class="card"><h3>Lab Requests</h3>';
    if (empty($labRequests)) {
        echo '<div class="no-data"><p>No lab requests have been created for this patient.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Test</th><th>Status</th><th>Created</th><th>Result</th></tr></thead><tbody>';
        foreach ($labRequests as $request) {
            $labResult = LabResult::findByLabRequestId((int)$request['id']);
            echo '<tr><td>' . h($request['test_type']) . '</td><td>' . h($request['status']) . '</td><td>' . h(date('M d, H:i', strtotime($request['created_at']))) . '</td><td>' . h($labResult['result'] ?? 'Pending') . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    $prescriptions = Prescription::getForPatient($patient['id']);
    echo '<div class="card"><h3>Previous Prescriptions</h3>';
    if (empty($prescriptions)) {
        echo '<div class="no-data"><p>No medication orders have been recorded yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Medication</th><th>Dosage</th><th>Frequency</th><th>Created</th></tr></thead><tbody>';
        foreach ($prescriptions as $prescription) {
            echo '<tr><td>' . h($prescription['medication']) . '</td><td>' . h($prescription['dosage']) . '</td><td>' . h($prescription['frequency']) . '</td><td>' . h(date('M d, H:i', strtotime($prescription['created_at']))) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '<a href="?action=doctor_dashboard" class="btn btn-secondary" style="margin-top: 12px;">Back to Dashboard</a>';
    echo '</div>';
    echo '</div>';

    renderFooter();
    exit;
}

// BILLING DASHBOARD
if ($action === 'billing_dashboard') {
    requireRole('billing');

    renderHeader('Billing & Payments', 'billing');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $acceptedQueue = QueueManager::getAccepted();
    $payments = Payment::all();
    $pharmacyBills = PharmacyBill::getPending();

    echo '<div class="page-title"><h2>Billing Desk</h2><p>Collect payments for consultations, lab tests, and medications.</p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3>💳 Consultations Pending</h3><div class="card-stat"><div class="card-stat-text"><h4>Awaiting</h4><p>' . count($acceptedQueue) . '</p></div></div></div>';
    echo '<div class="card"><h3>🧾 Pharmacy Bills Pending</h3><div class="card-stat"><div class="card-stat-text"><h4>Awaiting</h4><p>' . count($pharmacyBills) . '</p></div></div></div>';
    echo '<div class="card"><h3>✅ Total Collected</h3><div class="card-stat"><div class="card-stat-text"><h4>Payments</h4><p>' . count($payments) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Pharmacy Bills Pending Payment</h3>';
    if (empty($pharmacyBills)) {
        echo '<div class="no-data"><p>No pharmacy bills are awaiting payment.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient ID</th><th>Name</th><th>Amount</th><th>Created</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($pharmacyBills as $bill) {
            echo '<tr>
                <td>' . h($bill['patient_code']) . '</td>
                <td>' . h($bill['full_name']) . '</td>
                <td>' . h(number_format((float)$bill['amount'], 2)) . '</td>
                <td>' . h(date('M d, H:i', strtotime($bill['created_at']))) . '</td>
                <td><a href="?action=collect_pharmacy_bill_payment&bill_id=' . h($bill['id']) . '" class="btn btn-primary btn-small">Collect Payment</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Accepted Consultations - Collect Consultation Payment</h3>';
    if (empty($acceptedQueue)) {
        echo '<div class="no-data"><p>No accepted consultations awaiting payment.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient ID</th><th>Name</th><th>Queued At</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($acceptedQueue as $entry) {
            echo '<tr>
                <td>' . h($entry['patient_code']) . '</td>
                <td>' . h($entry['full_name']) . '</td>
                <td>' . h(date('M d, H:i', strtotime($entry['queued_at']))) . '</td>
                <td><span class="status-badge status-accepted">Accepted</span></td>
                <td><a href="?action=collect_payment&queue_id=' . h($entry['queue_id']) . '" class="btn btn-secondary btn-small">Collect Payment</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Recent Payments</h3>';
    if (empty($payments)) {
        echo '<div class="no-data"><p>No payments have been recorded yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Control Number</th><th>Patient</th><th>Type</th><th>Amount</th><th>Paid At</th></tr></thead>
            <tbody>';
        foreach ($payments as $payment) {
            echo '<tr>
                <td>' . h($payment['receipt_number']) . '</td>
                <td>' . h($payment['patient_code'] . ' - ' . $payment['full_name']) . '</td>
                <td>' . h($payment['type']) . '</td>
                <td>' . h(number_format((float)$payment['amount'], 2)) . '</td>
                <td>' . h(date('M d, H:i', strtotime($payment['paid_at']))) . '</td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'pharmacy_dashboard') {
    requireRole('pharmacy');

    renderHeader('Pharmacy', 'pharmacy');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $pendingPrescriptions = Prescription::getPending();
    $dispensations = Dispensation::all();
    
    // Get patients with prescriptions uploaded and bills pending creation
    $pdo = Database::getConnection();
    $stmt = $pdo->query('
        SELECT DISTINCT p.id, p.patient_id, p.full_name, COUNT(pr.id) as prescription_count
        FROM patients p
        LEFT JOIN prescriptions pr ON p.id = pr.patient_id
        WHERE p.status = "Prescription Uploaded"
        GROUP BY p.id
        ORDER BY p.full_name
    ');
    $prescriptionUploadedPatients = $stmt->fetchAll() ?: [];

    // Get patients with paid pharmacy bills ready to dispense
    $stmt = $pdo->query('
        SELECT DISTINCT p.id, p.patient_id, p.full_name, COUNT(pr.id) as prescription_count
        FROM patients p
        LEFT JOIN prescriptions pr ON p.id = pr.patient_id
        WHERE p.status = "Paid for Pharmacy"
        GROUP BY p.id
        ORDER BY p.full_name
    ');
    $paidPharmacyPatients = $stmt->fetchAll() ?: [];

    echo '<div class="page-title"><h2>Pharmacy Dispensing</h2><p>Dispense medications to patients who have paid. Review pending prescriptions and record dispensed medications.</p></div>';

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3>📝 Awaiting Pharmacy Bill</h3><div class="card-stat"><div class="card-stat-text"><h4>Patients</h4><p>' . count($prescriptionUploadedPatients) . '</p></div></div></div>';
    echo '<div class="card"><h3>🟢 Ready to Dispense</h3><div class="card-stat"><div class="card-stat-text"><h4>Paid</h4><p>' . count($paidPharmacyPatients) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Patients Ready for Dispensing - Pharmacy Paid</h3>';
    if (empty($paidPharmacyPatients)) {
        echo '<div class="no-data"><p>No patients have paid for medicine yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient ID</th><th>Name</th><th>Prescriptions</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($paidPharmacyPatients as $patient) {
            echo '<tr>
                <td>' . h($patient['patient_id']) . '</td>
                <td>' . h($patient['full_name']) . '</td>
                <td>' . h($patient['prescription_count']) . ' pending</td>
                <td><a href="?action=dispense_for_patient&patient_id=' . h($patient['id']) . '" class="btn btn-primary btn-small">Dispense</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Prescription Uploaded - Create Pharmacy Bill</h3>';
    if (empty($prescriptionUploadedPatients)) {
        echo '<div class="no-data"><p>No prescriptions have been uploaded to pharmacy yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient ID</th><th>Name</th><th>Prescriptions</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($prescriptionUploadedPatients as $patient) {
            echo '<tr>
                <td>' . h($patient['patient_id']) . '</td>
                <td>' . h($patient['full_name']) . '</td>
                <td>' . h($patient['prescription_count']) . ' pending</td>
                <td><a href="?action=create_pharmacy_bill&patient_id=' . h($patient['id']) . '" class="btn btn-secondary btn-small">Create Bill</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Pending Prescriptions</h3>';
    if (empty($pendingPrescriptions)) {
        echo '<div class="no-data"><p>No prescriptions are awaiting dispensing.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient</th><th>Medication</th><th>Dosage</th><th>Frequency</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($pendingPrescriptions as $prescription) {
            echo '<tr>
                <td>' . h($prescription['patient_code'] . ' - ' . $prescription['full_name']) . '</td>
                <td>' . h($prescription['medication']) . '</td>
                <td>' . h($prescription['dosage']) . '</td>
                <td>' . h($prescription['frequency']) . '</td>
                <td><a href="?action=dispense_medication&prescription_id=' . h($prescription['id']) . '" class="btn btn-secondary btn-small">Dispense</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Dispensation History</h3>';
    if (empty($dispensations)) {
        echo '<div class="no-data"><p>No dispensed medication records yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Prescription</th><th>Patient</th><th>Qty</th><th>Pharmacist</th><th>Dispensed At</th></tr></thead>
            <tbody>';
        foreach ($dispensations as $dispense) {
            echo '<tr>
                <td>' . h($dispense['medication']) . '</td>
                <td>' . h($dispense['patient_code']) . '</td>
                <td>' . h($dispense['quantity']) . '</td>
                <td>' . h($dispense['staff_name']) . '</td>
                <td>' . h(date('M d, H:i', strtotime($dispense['dispensed_at']))) . '</td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'moic_dashboard') {
    requireRole('admin');

    renderHeader('MOIC Dashboard', 'admin');

    // Summary metrics
    $pdo = Database::getConnection();
    $totalPatients = (int)$pdo->query('SELECT COUNT(*) AS cnt FROM patients')->fetch()['cnt'];
    $totalRevenue = (float)$pdo->query('SELECT IFNULL(SUM(amount),0) AS s FROM payments')->fetch()['s'];
    $paymentsByTypeStmt = $pdo->query('SELECT type, IFNULL(SUM(amount),0) AS total FROM payments GROUP BY type');
    $paymentsByType = $paymentsByTypeStmt->fetchAll();
    $pendingPharmacyBills = PharmacyBill::getPending();
    $outstandingPharmacy = array_reduce($pendingPharmacyBills, function ($carry, $b) { return $carry + (float)$b['amount']; }, 0.0);
    $budgets = Budget::all();

    echo '<div class="page-title"><h2>MOIC Dashboard</h2><p>High-level operational and financial metrics for oversight.</p></div>';
    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3>👥 Total Patients</h3><div class="card-stat"><div class="card-stat-text"><h4>Registered</h4><p>' . h((string)$totalPatients) . '</p></div></div></div>';
    echo '<div class="card"><h3>💰 Total Revenue</h3><div class="card-stat"><div class="card-stat-text"><h4>Collected</h4><p>' . h(number_format($totalRevenue,2)) . '</p></div></div></div>';
    echo '<div class="card"><h3>🧾 Outstanding Pharmacy</h3><div class="card-stat"><div class="card-stat-text"><h4>Due</h4><p>' . h(number_format($outstandingPharmacy,2)) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Revenue by Type</h3>';
    echo '<div class="table-responsive"><table><thead><tr><th>Type</th><th>Total</th></tr></thead><tbody>';
    foreach ($paymentsByType as $row) {
        echo '<tr><td>' . h($row['type']) . '</td><td>' . h(number_format((float)$row['total'],2)) . '</td></tr>';
    }
    echo '</tbody></table></div></div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Budgets</h3>';
    if (empty($budgets)) {
        echo '<div class="no-data"><p>No budgets configured yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Department</th><th>Allocated</th><th>Spent</th><th>Fiscal Year</th></tr></thead><tbody>';
        foreach ($budgets as $b) {
            echo '<tr><td>' . h($b['department']) . '</td><td>' . h(number_format((float)$b['allocated'],2)) . '</td><td>' . h(number_format((float)$b['spent'],2)) . '</td><td>' . h($b['fiscal_year']) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'budget_dashboard') {
    requireRole('admin');

    $budgets = Budget::all();
    renderHeader('Budget Management', 'admin');
    echo '<div class="page-title"><h2>Budget Management</h2><p>Allocate and review departmental budgets for financial oversight.</p></div>';

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3>Create New Budget</h3>';
    echo '<form method="post" action="?action=save_budget">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<div class="form-row">';
    echo '<label>Department<br><input name="department" required></label>';
    echo '<label>Allocated Amount<br><input type="number" step="0.01" name="allocated" required></label>';
    echo '</div>';
    echo '<div class="form-row">';
    echo '<label>Fiscal Year<br><input name="fiscal_year"></label>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary">Create Budget</button>';
    echo '</form>';
    echo '</div>';

    echo '<div class="card"><h3>Current Budgets</h3>';
    if (empty($budgets)) {
        echo '<div class="no-data"><p>No budgets configured yet.</p></div>';
    } else {
        echo '<div class="table-responsive"><table><thead><tr><th>Department</th><th>Allocated</th><th>Spent</th><th>Fiscal Year</th></tr></thead><tbody>';
        foreach ($budgets as $budget) {
            echo '<tr><td>' . h($budget['department']) . '</td><td>' . h(number_format((float)$budget['allocated'],2)) . '</td><td>' . h(number_format((float)$budget['spent'],2)) . '</td><td>' . h($budget['fiscal_year']) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'dispense_for_patient') {
    requireRole('pharmacy');

    $patientId = (int)($_GET['patient_id'] ?? 0);
    $patient = Patient::find($patientId);

    if (!$patient || $patient['status'] !== 'Paid for Medicine') {
        setFlash('Patient is not ready for medicine dispensing.', 'error');
        header('Location: ?action=pharmacy_dashboard');
        exit;
    }

    $pendingPrescriptions = Prescription::getPendingForPatient($patientId);

    if (empty($pendingPrescriptions)) {
        setFlash('No pending prescriptions for this patient.', 'error');
        header('Location: ?action=pharmacy_dashboard');
        exit;
    }

    renderHeader('Dispense for Patient', 'pharmacy');

    echo '<div class="page-title"><h2>Dispense Medications for ' . h($patient['full_name']) . '</h2><p>Review and dispense all pending prescriptions.</p></div>';

    echo '<div class="card"><h3>Patient & Prescriptions</h3>';
    echo '<p><strong>Patient:</strong> ' . h($patient['patient_id'] . ' - ' . $patient['full_name']) . '</p>';
    echo '<p><strong>Status:</strong> <span class="status-badge status-accepted">Paid for Medicine</span></p>';
    echo '<div style="margin-top: 16px; padding: 12px; background-color: #f0f8ff; border-radius: 4px;">';
    foreach ($pendingPrescriptions as $rx) {
        echo '<div style="margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid #ddd;">';
        echo '<p><strong>' . h($rx['medication']) . '</strong> - ' . h($rx['dosage']) . ' (' . h($rx['frequency']) . ')</p>';
        echo '<p><small>Created: ' . h(date('M d, H:i', strtotime($rx['created_at']))) . '</small></p>';
        echo '<a href="?action=dispense_medication&prescription_id=' . h($rx['id']) . '" class="btn btn-primary btn-small">Dispense</a>';
        echo '</div>';
    }
    echo '</div>';
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'dispense_medication') {
    requireRole('pharmacy');

    $prescriptionId = (int)($_GET['prescription_id'] ?? 0);
    $prescription = Prescription::find($prescriptionId);

    if (!$prescription) {
        setFlash('Prescription not found.', 'error');
        header('Location: ?action=pharmacy_dashboard');
        exit;
    }

    renderHeader('Dispense Medication', 'pharmacy');

    echo '<div class="page-title"><h2>Dispense Medication</h2><p>Confirm the quantity dispensed for this prescription.</p></div>';
    echo '<div class="card" style="max-width: 680px;">
        <form method="post" action="?action=record_dispense">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="prescription_id" value="' . h($prescription['id']) . '">
            <p><strong>Patient:</strong> ' . h($prescription['patient_code'] . ' - ' . $prescription['full_name']) . '</p>
            <p><strong>Medication:</strong> ' . h($prescription['medication']) . '</p>
            <p><strong>Dosage:</strong> ' . h($prescription['dosage']) . '</p>
            <p><strong>Frequency:</strong> ' . h($prescription['frequency']) . '</p>
            <div class="form-row">
                <label>Quantity<br><input type="number" name="quantity" min="1" required></label>
            </div>
            <div class="form-row full">
                <label>Notes<br><textarea name="note"></textarea></label>
            </div>
            <button type="submit" class="btn btn-primary">Record Dispense</button>
            <a href="?action=pharmacy_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>
        </form>
    </div>';

    renderFooter();
    exit;
}

if ($action === 'collect_medicine_payment') {
    requireRole('billing');

    $patientId = (int)($_GET['patient_id'] ?? 0);
    $queueId = (int)($_GET['queue_id'] ?? 0);
    
    $patient = Patient::find($patientId);
    if (!$patient || $patient['status'] !== 'Prescribed') {
        setFlash('Patient is not prescribed for medicine payment.', 'error');
        header('Location: ?action=billing_dashboard');
        exit;
    }

    $prescriptions = Prescription::getForPatient($patientId);
    if (empty($prescriptions)) {
        setFlash('No prescriptions found for this patient.', 'error');
        header('Location: ?action=billing_dashboard');
        exit;
    }

    renderHeader('Collect Medicine Payment', 'billing');

    echo '<div class="page-title"><h2>Collect Medicine Payment</h2><p>Patient has been prescribed medication. Collect payment before they go to pharmacy.</p></div>';
    echo '<div class="card" style="max-width: 680px;">';
    echo '<h3>Patient & Prescriptions</h3>';
    echo '<p><strong>Patient:</strong> ' . h($patient['patient_id'] . ' - ' . $patient['full_name']) . '</p>';
    echo '<p><strong>Status:</strong> <span class="status-badge status-warning">Prescribed</span></p>';
    echo '<div style="margin-bottom: 16px; padding: 12px; background-color: #f0f8ff; border-radius: 4px;">';
    foreach ($prescriptions as $rx) {
        echo '<p><strong>' . h($rx['medication']) . '</strong> - ' . h($rx['dosage']) . ' (' . h($rx['frequency']) . ')</p>';
    }
    echo '</div>';
    echo '<form method="post" action="?action=record_medicine_payment">';
    echo '<input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">';
    echo '<input type="hidden" name="patient_id" value="' . h($patientId) . '">';
    echo '<input type="hidden" name="queue_id" value="' . h($queueId) . '">';
    echo '<div class="form-row">';
    echo '<label>Medicine Payment Amount<br><input type="number" step="0.01" name="amount" placeholder="e.g., 5000" required></label>';
    echo '<label>Control Number<br><input type="text" value="Generated on save" disabled></label>';
    echo '</div>';
    echo '<button type="submit" class="btn btn-primary">Record Medicine Payment</button>';
    echo '<a href="?action=billing_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>';
    echo '</form>';
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'collect_payment') {
    requireRole('billing');

    $queueId = (int)($_GET['queue_id'] ?? 0);
    $queueEntry = QueueManager::find($queueId);

    if (!$queueEntry || $queueEntry['status'] !== 'Accepted') {
        setFlash('Selected consultation is not available for payment.', 'error');
        header('Location: ?action=billing_dashboard');
        exit;
    }

    $patient = Patient::find((int)$queueEntry['patient_row_id']);
    if (!$patient) {
        setFlash('Patient record not found.', 'error');
        header('Location: ?action=billing_dashboard');
        exit;
    }

    renderHeader('Collect Payment', 'billing');

    echo '<div class="page-title"><h2>Collect Consultation Payment</h2><p>Enter the control amount and complete the billing.</p></div>';
    echo '<div class="card" style="max-width: 680px;">
        <form method="post" action="?action=record_payment">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="queue_id" value="' . h($queueEntry['queue_id']) . '">
            <p><strong>Patient:</strong> ' . h($patient['patient_id'] . ' - ' . $patient['full_name']) . '</p>
            <p><strong>Status:</strong> <span class="status-badge status-accepted">Accepted</span></p>
            <div class="form-row">
                <label>Payment Amount<br><input type="number" step="0.01" name="amount" required></label>
                <label>Control Number<br><input type="text" value="Generated on save" disabled></label>
            </div>
            <button type="submit" class="btn btn-primary">Record Payment</button>
            <a href="?action=billing_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>
        </form>
    </div>';

    renderFooter();
    exit;
}

if ($action === 'lab_dashboard') {
    requireRole('lab');

    renderHeader('Lab Services', 'lab');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $pendingPayments = LabRequest::getPendingPayment();
    $pendingInvestigations = LabRequest::getPendingInvestigation();

    echo '<div class="page-title"><h2>Lab Workflow</h2><p>Collect payments for lab tests and manage the investigation queue.</p></div>';

    echo '<div class="grid grid-2">';
    echo '<div class="card"><h3>Pending Lab Payments</h3><div class="card-stat"><div class="card-stat-text"><h4>Requests</h4><p>' . count($pendingPayments) . '</p></div></div></div>';
    echo '<div class="card"><h3>Pending Investigations</h3><div class="card-stat"><div class="card-stat-text"><h4>Ready</h4><p>' . count($pendingInvestigations) . '</p></div></div></div>';
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Requests Awaiting Payment</h3>';
    if (empty($pendingPayments)) {
        echo '<div class="no-data"><p>No lab requests awaiting payment.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient</th><th>Test Type</th><th>Bill</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($pendingPayments as $request) {
            echo '<tr>
                <td>' . h($request['patient_code'] . ' - ' . $request['full_name']) . '</td>
                <td>' . h($request['test_type']) . '</td>
                <td>' . h(number_format((float)$request['bill'], 2)) . '</td>
                <td><span class="status-badge status-waiting">' . h($request['status']) . '</span></td>
                <td><a href="?action=lab_collect_payment&lab_request_id=' . h($request['id']) . '" class="btn btn-primary btn-small">Collect Payment</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    echo '<div class="card" style="margin-top: 24px;"><h3>Requests Ready for Investigation</h3>';
    if (empty($pendingInvestigations)) {
        echo '<div class="no-data"><p>No paid lab requests are awaiting results.</p></div>';
    } else {
        echo '<div class="table-responsive"><table>
            <thead><tr><th>Patient</th><th>Test Type</th><th>Bill</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>';
        foreach ($pendingInvestigations as $request) {
            echo '<tr>
                <td>' . h($request['patient_code'] . ' - ' . $request['full_name']) . '</td>
                <td>' . h($request['test_type']) . '</td>
                <td>' . h(number_format((float)$request['bill'], 2)) . '</td>
                <td><span class="status-badge status-accepted">' . h($request['status']) . '</span></td>
                <td><a href="?action=lab_upload_result&lab_request_id=' . h($request['id']) . '" class="btn btn-primary btn-small">Upload Result</a></td>
            </tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '</div>';

    renderFooter();
    exit;
}

if ($action === 'lab_collect_payment') {
    requireRole('lab');

    $labRequestId = (int)($_GET['lab_request_id'] ?? 0);
    $labRequest = LabRequest::find($labRequestId);

    if (!$labRequest || $labRequest['status'] !== 'Pending Payment') {
        setFlash('Selected lab request is not available for payment.', 'error');
        header('Location: ?action=lab_dashboard');
        exit;
    }

    $consultation = Consultation::find((int)$labRequest['consultation_id']);
    $patient = $consultation ? Patient::find((int)$consultation['patient_id']) : null;

    renderHeader('Lab Payment', 'lab');

    echo '<div class="page-title"><h2>Collect Lab Payment</h2><p>Complete payment for the selected lab request.</p></div>';
    echo '<div class="card" style="max-width: 680px;">
        <form method="post" action="?action=record_lab_payment">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="lab_request_id" value="' . h($labRequestId) . '">
            <p><strong>Patient:</strong> ' . h($patient ? $patient['patient_id'] . ' - ' . $patient['full_name'] : 'Unknown') . '</p>
            <p><strong>Test Type:</strong> ' . h($labRequest['test_type']) . '</p>
            <p><strong>Amount Due:</strong> ' . h(number_format((float)$labRequest['bill'], 2)) . '</p>
            <div class="form-row">
                <label>Payment Amount<br><input type="number" step="0.01" name="amount" required value="' . h(number_format((float)$labRequest['bill'], 2)) . '"></label>
            </div>
            <button type="submit" class="btn btn-primary">Record Lab Payment</button>
            <a href="?action=lab_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>
        </form>
    </div>';

    renderFooter();
    exit;
}

if ($action === 'lab_upload_result') {
    requireRole('lab');

    $labRequestId = (int)($_GET['lab_request_id'] ?? 0);
    $labRequest = LabRequest::find($labRequestId);

    if (!$labRequest || $labRequest['status'] !== 'Paid') {
        setFlash('Selected lab request is not ready for result upload.', 'error');
        header('Location: ?action=lab_dashboard');
        exit;
    }

    $consultation = Consultation::find((int)$labRequest['consultation_id']);
    $patient = $consultation ? Patient::find((int)$consultation['patient_id']) : null;

    renderHeader('Upload Lab Result', 'lab');

    echo '<div class="page-title"><h2>Upload Lab Result</h2><p>Provide the test findings and any comments.</p></div>';
    echo '<div class="card" style="max-width: 680px;">
        <form method="post" action="?action=upload_lab_result">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="lab_request_id" value="' . h($labRequestId) . '">
            <p><strong>Patient:</strong> ' . h($patient ? $patient['patient_id'] . ' - ' . $patient['full_name'] : 'Unknown') . '</p>
            <p><strong>Test Type:</strong> ' . h($labRequest['test_type']) . '</p>
            <div class="form-row full">
                <label>Result<br><textarea name="result" rows="4" required></textarea></label>
            </div>
            <div class="form-row full">
                <label>Comments<br><textarea name="comments" rows="3"></textarea></label>
            </div>
            <button type="submit" class="btn btn-primary">Upload Result</button>
            <a href="?action=lab_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>
        </form>
    </div>';

    renderFooter();
    exit;
}

// ADMIN EDIT STAFF PAGE
if ($action === 'edit_staff') {
    requireRole('admin');

    $staffId = (int)($_GET['id'] ?? 0);
    $staff = Staff::getById($staffId);

    if (!$staff) {
        setFlash('Staff member not found.', 'error');
        header('Location: ?action=admin_dashboard');
        exit;
    }

    renderHeader('Edit Staff Member', 'admin');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    echo '<div class="page-title"><h2>Edit Team Member</h2><p>Update account details, role and access status for hospital staff.</p></div>';
    echo '<div class="card" style="max-width: 680px; margin-bottom: 24px;">
        <form method="post" action="?action=update_staff">
            <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
            <input type="hidden" name="staff_id" value="' . h($staff['id']) . '">
            <div class="form-row">
                <label>Username<br><input name="username" value="' . h($staff['username']) . '" required></label>
                <label>Email<br><input type="email" name="email" value="' . h($staff['email']) . '" required></label>
            </div>
            <div class="form-row">
                <label>Full Name<br><input name="full_name" value="' . h($staff['full_name']) . '" required></label>
                <label>Role<br><select name="role">
                    <option value="admin"' . ($staff['role'] === 'admin' ? ' selected' : '') . '>Admin</option>
                    <option value="doctor"' . ($staff['role'] === 'doctor' ? ' selected' : '') . '>Doctor</option>
                    <option value="receptionist"' . ($staff['role'] === 'receptionist' ? ' selected' : '') . '>Receptionist</option>
                    <option value="billing"' . ($staff['role'] === 'billing' ? ' selected' : '') . '>Billing</option>
                    <option value="lab"' . ($staff['role'] === 'lab' ? ' selected' : '') . '>Lab</option>
                    <option value="pharmacy"' . ($staff['role'] === 'pharmacy' ? ' selected' : '') . '>Pharmacy</option>
                </select></label>
            </div>
            <div class="form-row full">
                <label>Status<br><label style="display:block;margin:0;"><input type="checkbox" name="is_active" value="1"' . ($staff['is_active'] ? ' checked' : '') . '> Active</label></label>
            </div>
            <div class="form-row full">
                <label>New Password (leave blank to keep current)<br><input type="password" name="password"></label>
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
            <a href="?action=admin_dashboard" class="btn btn-secondary" style="margin-left: 12px;">Cancel</a>
        </form>
    </div>';

    renderFooter();
    exit;
}

// ADMIN DASHBOARD
if ($action === 'admin_dashboard') {
    renderHeader('Admin - System Management', 'admin');

    if ($flash['message']) {
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
    }

    $allStaff = Staff::all();
    $allPatients = Patient::all();

    echo '<div class="page-title"><h2>System Administration</h2><p>Manage staff, monitor system usage, and view operational metrics.</p></div>';

    echo '<div class="grid grid-3">';
    echo '<div class="card"><h3>👥 Total Staff</h3><div class="card-stat"><div class="card-stat-text"><h4>Active Users</h4><p>' . count($allStaff) . '</p></div></div></div>';
    echo '<div class="card"><h3>🏥 Total Patients</h3><div class="card-stat"><div class="card-stat-text"><h4>Registered</h4><p>' . count($allPatients) . '</p></div></div></div>';
    echo '<div class="card"><h3>📊 System</h3><div class="card-stat"><div class="card-stat-text"><h4>Status</h4><p style="color: var(--success);">Online</p></div></div></div>';
    echo '</div>';

    echo '<div class="grid grid-2" style="margin-top:24px;">';
    echo '<div class="card"><h3>MOIC Oversight</h3><p>View high-level metrics and department reporting.</p><a href="?action=moic_dashboard" class="btn btn-primary">Open MOIC Dashboard</a></div>';
    echo '<div class="card"><h3>Budgets</h3><p>Manage departmental budget allocations and review spend.</p><a href="?action=budget_dashboard" class="btn btn-secondary">Open Budget Manager</a></div>';
    echo '</div>';

    // Create New Staff
    echo '<div class="card" style="margin-top: 24px; max-width: 600px;"><h3>Add New Staff Member</h3>
    <form method="post" action="?action=create_staff">
        <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
        <div class="form-row">
            <label>Username<br><input name="username" required></label>
            <label>Email<br><input type="email" name="email" required></label>
        </div>
        <div class="form-row">
            <label>Full Name<br><input name="full_name" required></label>
            <label>Role<br><select name="role"><option value="receptionist">Receptionist</option><option value="doctor">Doctor</option><option value="billing">Billing</option><option value="lab">Lab</option><option value="pharmacy">Pharmacy</option><option value="admin">Admin</option></select></label>
        </div>
        <div class="form-row full">
            <label>Password<br><input type="password" name="password" required></label>
        </div>
        <button type="submit" class="btn btn-primary">Create Staff Account</button>
    </form>
    </div>';

    // Staff List
    echo '<div class="card" style="margin-top: 24px;"><h3>Staff Directory (' . count($allStaff) . ')</h3>';
    echo '<div class="table-responsive"><table>
    <thead><tr><th>Username</th><th>Name</th><th>Email</th><th>Role</th><th>Last Login</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>';
    foreach ($allStaff as $staff) {
        $lastLogin = $staff['last_login'] ? date('M d, H:i', strtotime($staff['last_login'])) : 'Never';
        echo '<tr>
        <td><strong>' . h($staff['username']) . '</strong></td>
        <td>' . h($staff['full_name']) . '</td>
        <td>' . h($staff['email']) . '</td>
        <td><span class="badge badge-' . ($staff['role'] === 'admin' ? 'primary' : ($staff['role'] === 'doctor' ? 'accent' : ($staff['role'] === 'billing' ? 'success' : 'secondary'))) . '">' . h($staff['role']) . '</span></td>
        <td>' . $lastLogin . '</td>
        <td><span class="status-badge" style="background: var(--primary-lighter); color: var(--primary);">' . ($staff['is_active'] ? 'Active' : 'Inactive') . '</span></td>
        <td><div class="action-buttons">
            <a href="?action=edit_staff&id=' . h($staff['id']) . '" class="btn btn-secondary btn-small">Edit</a>' .
            ((int)$staff['id'] !== (int)$_SESSION['staff_id'] ? '<form method="post" action="?action=delete_staff" style="display:inline;margin:0;">
                <input type="hidden" name="csrf_token" value="' . h(getCsrfToken()) . '">
                <input type="hidden" name="staff_id" value="' . h($staff['id']) . '">
                <button type="submit" class="btn btn-secondary btn-small" style="background: #f8d7da; color: #842029; border-color: #f5c2c7;">Delete</button>
            </form>' : '') .
        '</div></td>
        </tr>';
    }
    echo '</tbody></table></div>';
    echo '</div>';

    renderFooter();
    exit;
}

// Default - show role-based dashboard
requireLogin();
header('Location: ?action=' . $_SESSION['staff_role'] . '_dashboard');
