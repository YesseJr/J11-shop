document.addEventListener('DOMContentLoaded', () => {
    const alertClose = document.querySelector('[data-alert-close]');
    if (alertClose) {
        alertClose.addEventListener('click', () => {
            alertClose.parentElement.style.display = 'none';
        });
    }

    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Processing...';
            }
        });
    });

    document.querySelectorAll('[data-confirm]').forEach(element => {
        element.addEventListener('click', (e) => {
            if (!confirm(element.dataset.confirm)) {
                e.preventDefault();
            }
        });
    });
});
