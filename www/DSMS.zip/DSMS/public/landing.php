<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DSMS - Hospital Workflow Landing Page</title>
    <link rel="stylesheet" href="assets/styles.css">
</head>

<body>
    <div class="landing-page">
        <section class="landing-hero">
            <div class="landing-copy">
                <span class="label">Hospital & Dispensary System</span>
                <h1>Streamline patient flow, staff operations, and clinical care.</h1>
                <p>DSMS brings reception, consultation, and administration together with a crisp, modern interface built for busy healthcare teams.</p>
                <div class="hero-actions">
                    <a href="index.php?action=login" class="btn btn-primary">Staff Login</a>
                    <a href="index.php?action=login" class="btn btn-secondary">Access Control Panel</a>
                </div>
            </div>
            <div class="landing-panel">
                <div class="panel-card panel-highlight">
                    <h3>Admin Console</h3>
                    <p>Manage staff accounts, monitor patient volume, and keep operations running smoothly.</p>
                </div>
                <div class="panel-card">
                    <h3>Reception Workflow</h3>
                    <p>Register patients quickly and assign them to the consultation queue with ease.</p>
                </div>
                <div class="panel-card">
                    <h3>Doctor Hub</h3>
                    <p>Review waiting patients, capture vitals, and log consultation notes from a clean workspace.</p>
                </div>
            </div>
        </section>
    </div>
</body>

</html>
